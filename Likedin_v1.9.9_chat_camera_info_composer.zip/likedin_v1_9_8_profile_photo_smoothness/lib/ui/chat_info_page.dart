import 'dart:io';

import 'package:flutter/material.dart';

import '../backend/realtime_messaging_service.dart';
import '../backend/shared_media_service.dart';
import 'glassmorphism.dart';

/// Conversation information surface. Actions are injected from the chat so
/// this page never changes message/backend behaviour itself.
class ChatInfoPage extends StatelessWidget {
  const ChatInfoPage({
    required this.displayName,
    required this.presence,
    required this.avatarUrl,
    required this.messages,
    required this.mediaService,
    required this.onManageStorage,
    required this.onClearChat,
    required this.onChangeNickname,
    super.key,
  });

  final String displayName;
  final String presence;
  final String? avatarUrl;
  final List<RemoteMessage> messages;
  final SharedMediaService mediaService;
  final VoidCallback onManageStorage;
  final Future<void> Function() onClearChat;
  final VoidCallback onChangeNickname;

  List<Map<String, dynamic>> get _mediaItems => messages
      .where((message) => message.deletedForEveryoneAt == null)
      .map((message) => mediaService.decode(message.text))
      .whereType<Map<String, dynamic>>()
      .toList(growable: false);

  int get _linkCount => messages.where((message) =>
      message.deletedForEveryoneAt == null &&
      RegExp(r'https?://\S+', caseSensitive: false).hasMatch(message.text)).length;

  int get _documentCount => _mediaItems.where((item) {
        final kind = item['kind']?.toString() ?? 'file';
        return kind != 'image' && kind != 'video' && kind != 'audio';
      }).length;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final media = _mediaItems;
    final sharedCount = media.length + _linkCount;
    final images = media.where((item) {
      final kind = item['kind']?.toString();
      return kind == 'image' || kind == 'video';
    }).take(4).toList(growable: false);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: true,
            backgroundColor: theme.scaffoldBackgroundColor,
            surfaceTintColor: Colors.transparent,
            leading: IconButton(
              tooltip: 'Back to chat',
              onPressed: () => Navigator.of(context).pop(),
              icon: const Icon(Icons.arrow_back_rounded),
            ),
            title: const Text('Contact info', style: TextStyle(fontWeight: FontWeight.w700)),
            actions: [
              PopupMenuButton<String>(
                onSelected: (value) {
                  if (value == 'nickname') onChangeNickname();
                  if (value == 'clear') onClearChat();
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'nickname', child: Text('Change chat nickname')),
                  PopupMenuItem(value: 'clear', child: Text('Clear chat on this device')),
                ],
              ),
            ],
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(22, 18, 22, 12),
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(colors: [
                        theme.colorScheme.primary.withValues(alpha: .75),
                        theme.colorScheme.secondary.withValues(alpha: .25),
                      ]),
                    ),
                    child: CircleAvatar(
                      radius: 65,
                      backgroundColor: theme.colorScheme.surfaceContainerHighest,
                      backgroundImage: avatarUrl == null ? null : NetworkImage(avatarUrl!),
                      child: avatarUrl == null
                          ? Icon(Icons.person_rounded, size: 58, color: theme.colorScheme.onSurfaceVariant)
                          : null,
                    ),
                  ),
                  const SizedBox(height: 17),
                  Text(displayName, textAlign: TextAlign.center,
                      style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 5),
                  Text(presence, style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
                  const SizedBox(height: 22),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _QuickAction(icon: Icons.edit_outlined, label: 'Nickname', onTap: onChangeNickname),
                      const SizedBox(width: 28),
                      _QuickAction(icon: Icons.folder_open_outlined, label: 'Storage', onTap: onManageStorage),
                    ],
                  ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 8, 18, 0),
              child: GlassPanel(
                blur: 10,
                glow: false,
                radius: BorderRadius.circular(22),
                padding: const EdgeInsets.fromLTRB(16, 15, 16, 14),
                tint: theme.colorScheme.surface.withValues(alpha: .72),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Row(children: [
                          Expanded(child: Text('Media, links, and docs', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700))),
                          Text('$sharedCount', style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
                        ]),
                    ),
                    if (images.isNotEmpty) ...[
                      const SizedBox(height: 13),
                      SizedBox(
                        height: 76,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: images.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 9),
                          itemBuilder: (_, index) {
                            final item = images[index];
                            final kind = item['kind']?.toString() ?? 'image';
                            return _SharedMediaThumbnail(
                              key: ValueKey('contact-media-${item['path'] ?? index}'),
                              payload: item,
                              service: mediaService,
                              isVideo: kind == 'video',
                            );
                          },
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 28),
            sliver: SliverList.list(children: [
              _InfoAction(
                icon: Icons.storage_outlined,
                title: 'Manage storage',
                subtitle: 'Review saved media, cache and upload queue',
                onTap: onManageStorage,
              ),
              _InfoAction(
                icon: Icons.edit_outlined,
                title: 'Chat nickname',
                subtitle: 'Change how this contact appears in Likedin',
                onTap: onChangeNickname,
              ),
              const SizedBox(height: 8),
              _InfoAction(
                icon: Icons.delete_outline_rounded,
                title: 'Clear chat',
                subtitle: 'Clear this conversation on this device only',
                destructive: true,
                onTap: onClearChat,
              ),
              const SizedBox(height: 12),
              Text('Shared items: ${media.length - _documentCount} media · $_linkCount links · $_documentCount documents',
                  style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
              const SizedBox(height: 6),
              Text('Disappearing messages, chat lock and advanced chat privacy are not currently implemented in this build, so they are intentionally not shown as working controls.',
                  style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
            ]),
          ),
        ],
      ),
    );
  }
}

class _QuickAction extends StatelessWidget {
  const _QuickAction({required this.icon, required this.label, required this.onTap});
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
          child: Column(children: [
            Icon(icon, color: Theme.of(context).colorScheme.primary, size: 23),
            const SizedBox(height: 5),
            Text(label, style: Theme.of(context).textTheme.labelMedium),
          ]),
        ),
      );
}

class _InfoAction extends StatelessWidget {
  const _InfoAction({required this.icon, required this.title, required this.subtitle, required this.onTap, this.destructive = false});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final bool destructive;
  @override
  Widget build(BuildContext context) {
    final color = destructive ? Theme.of(context).colorScheme.error : Theme.of(context).colorScheme.onSurface;
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      leading: Icon(icon, color: destructive ? color : Theme.of(context).colorScheme.onSurfaceVariant),
      title: Text(title, style: TextStyle(color: color, fontWeight: FontWeight.w600)),
      subtitle: Text(subtitle),
      onTap: onTap,
    );
  }
}


class _SharedMediaThumbnail extends StatelessWidget {
  const _SharedMediaThumbnail({super.key, required this.payload, required this.service, required this.isVideo});
  final Map<String, dynamic> payload;
  final SharedMediaService service;
  final bool isVideo;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: SizedBox(
        width: 76,
        height: 76,
        child: FutureBuilder<File>(
          future: service.cachedFile(payload),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              return Stack(fit: StackFit.expand, children: [
                Image.file(snapshot.data!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _fallback(theme)),
                if (isVideo)
                  const Center(child: Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 30)),
              ]);
            }
            return _fallback(theme, loading: snapshot.connectionState == ConnectionState.waiting);
          },
        ),
      ),
    );
  }

  Widget _fallback(ThemeData theme, {bool loading = false}) => Container(
        color: theme.colorScheme.surfaceContainerHighest,
        alignment: Alignment.center,
        child: loading
            ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
            : Icon(isVideo ? Icons.video_library_outlined : Icons.image_outlined,
                color: theme.colorScheme.primary, size: 27),
      );
}
