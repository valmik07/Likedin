# Likedin v2.3.0+122 — Liquid Glass, Light/Dark Chat Themes & Compact ARM64 Build

## What's new in v2.3.0+122
- **APK size reduction:** ARM64-only `abiFilters`, compressed native `.so` packaging (`useLegacyPackaging = true`), English-only Android resource filtering, removal of unused `sqflite` and dead code, and obfuscated symbol splitting in CI.
- **Liquid Glass UI:** Upgraded `GlassPanel` and `AuroraBackdrop` across the entire app (Home, Chat, Calls, Files, Profile, Settings, Contact Info, Shared Media, Gallery, and Dialogs) with zero-blur specular sheen + capped frosted blur on floating chrome.
- **White Mode & Dark Mode Chat Themes:** All 7 chat themes (`Default`, `Ocean`, `Rose`, `Emerald`, `Sunset`, `Lavender`, `Minimal`) now automatically adapt between Light (Arctic) and Dark (Obsidian) palettes.
- **Performance pass (3 GB RAM Android 11):** Bounded `imageCache` (60 entries / 24 MB), capped `BackdropFilter` sigma (<= 10), `cacheExtent: 380` on chat timeline, and reduced per-row theme lookups.

## Build
Use the accompanying `android-build-v2.3.0.yml` GitHub Actions workflow, or locally:
```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --release --target-platform android-arm64 --obfuscate --split-debug-info=build/debug-info
```
