import 'package:flutter/material.dart';

import 'glassmorphism.dart';

/// Theme customization (spec screen 13): live theme cards, accent colours,
/// chat-bubble preview and animation/effects preferences. Every change is
/// applied to the whole app immediately; Reset restores the defaults.
class ThemeCustomizationPage extends StatelessWidget {
  const ThemeCustomizationPage({
    required this.themeMode,
    required this.onSetDark,
    super.key,
  });

  final ValueNotifier<ThemeMode> themeMode;
  final Future<void> Function(bool dark) onSetDark;

  Future<void> _reset(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Reset appearance?'),
        content: const Text('This restores the default theme, accent colour and visual effects.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Reset')),
        ],
      ),
    );
    if (confirmed != true || !context.mounted) return;
    await LikedinAppearance.reset();
    await onSetDark(false);
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Appearance reset to Arctic Glass defaults.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AuroraBackdrop(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          title: const Text('Appearance', style: TextStyle(fontWeight: FontWeight.w800)),
          actions: [
            TextButton(onPressed: () => _reset(context), child: const Text('Reset')),
          ],
        ),
        body: ListenableBuilder(
          listenable: Listenable.merge([themeMode, LikedinAppearance.listenable]),
          builder: (context, _) {
            final brightness = Theme.of(context).brightness;
            final isDark = themeMode.value == ThemeMode.dark;
            return ListView(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 32),
              children: [
                _heading(context, 'Theme'),
                Row(
                  children: [
                    Expanded(
                      child: _ThemeCard(
                        title: 'Obsidian Glass',
                        subtitle: 'Dark',
                        dark: true,
                        selected: isDark,
                        onTap: () => onSetDark(true),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _ThemeCard(
                        title: 'Arctic Glass',
                        subtitle: 'Light',
                        dark: false,
                        selected: !isDark,
                        onTap: () => onSetDark(false),
                      ),
                    ),
                  ],
                ),
                _heading(context, 'Accent colour'),
                GlassPanel(
                  padding: const EdgeInsets.all(16),
                  radius: BorderRadius.circular(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ValueListenableBuilder<int>(
                        valueListenable: LikedinAppearance.accentIndex,
                        builder: (context, selected, _) => Wrap(
                          spacing: 14,
                          runSpacing: 12,
                          children: [
                            for (var i = 0; i < likedinAccents.length; i++)
                              _AccentSwatch(
                                accent: likedinAccents[i],
                                brightness: brightness,
                                selected: i == selected,
                                onTap: () => LikedinAppearance.setAccent(i),
                              ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'Each accent is tuned separately for ${isDark ? 'Obsidian' : 'Arctic'} Glass so '
                        'text and buttons always stay readable.',
                        style: TextStyle(
                          fontSize: 13,
                          height: 1.4,
                          color: likedinMutedText(brightness),
                        ),
                      ),
                    ],
                  ),
                ),
                _heading(context, 'Chat bubbles'),
                GlassPanel(
                  padding: const EdgeInsets.all(16),
                  radius: BorderRadius.circular(20),
                  child: Column(
                    children: [
                      _bubble(context, 'Are we still on for tonight?', outgoing: false),
                      _bubble(context, 'Yes, see you at 8.', outgoing: true),
                    ],
                  ),
                ),
                _heading(context, 'Visual effects'),
                GlassPanel(
                  padding: const EdgeInsets.all(16),
                  radius: BorderRadius.circular(20),
                  child: ValueListenableBuilder<LikedinEffects>(
                    valueListenable: LikedinAppearance.effects,
                    builder: (context, effects, _) => Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: double.infinity,
                          child: SegmentedButton<LikedinEffects>(
                            showSelectedIcon: false,
                            segments: const [
                              ButtonSegment(value: LikedinEffects.full, label: Text('Full')),
                              ButtonSegment(value: LikedinEffects.lighter, label: Text('Lighter')),
                              ButtonSegment(value: LikedinEffects.off, label: Text('Off')),
                            ],
                            selected: {effects},
                            onSelectionChanged: (s) => LikedinAppearance.setEffects(s.first),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          switch (effects) {
                            LikedinEffects.full =>
                              'Liquid Glass sheen, frosted floating bars, ambient orbs and specular edges.',
                            LikedinEffects.lighter =>
                              'No blur or shadows. Translucent glass sheen only. Great for 3 GB phones.',
                            LikedinEffects.off =>
                              'Solid surfaces and a flat background. Fastest and highest contrast.',
                          },
                          style: TextStyle(
                            fontSize: 13,
                            height: 1.4,
                            color: likedinMutedText(brightness),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                GlassPanel(
                  radius: BorderRadius.circular(20),
                  child: ValueListenableBuilder<bool>(
                    valueListenable: LikedinAppearance.reduceMotion,
                    builder: (context, reduced, _) => SwitchListTile.adaptive(
                      value: reduced,
                      onChanged: LikedinAppearance.setReduceMotion,
                      title: const Text('Reduce motion'),
                      subtitle: const Text(
                        'Skips the startup animation and call pulse. Your phone’s system setting is also respected.',
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                OutlinedButton.icon(
                  onPressed: () => _reset(context),
                  icon: const Icon(Icons.restart_alt_rounded, size: 19),
                  label: const Text('Reset appearance'),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _heading(BuildContext context, String text) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 22, 4, 10),
        child: Text(
          text,
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: -.4),
        ),
      );

  Widget _bubble(BuildContext context, String text, {required bool outgoing}) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    return Align(
      alignment: outgoing ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
        constraints: const BoxConstraints(maxWidth: 260),
        decoration: BoxDecoration(
          color: outgoing ? likedinOutgoingBubble(brightness) : likedinIncomingBubble(brightness),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.white.withValues(alpha: dark ? .11 : .70),
              Colors.white.withValues(alpha: 0),
            ],
          ),
          border: Border.all(
            color: outgoing
                ? likedinPrimary(brightness).withValues(alpha: dark ? .52 : .42)
                : (dark ? Colors.white.withValues(alpha: .16) : Colors.white.withValues(alpha: .95)),
          ),
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(20),
            topRight: const Radius.circular(20),
            bottomLeft: Radius.circular(outgoing ? 20 : 6),
            bottomRight: Radius.circular(outgoing ? 6 : 20),
          ),
        ),
        child: Text(
          text,
          style: TextStyle(color: likedinOnSurface(brightness), fontSize: 15),
        ),
      ),
    );
  }
}

/// Mini live preview of a theme. It paints with explicit brightness so both
/// themes can be compared side by side regardless of the current one.
class _ThemeCard extends StatelessWidget {
  const _ThemeCard({
    required this.title,
    required this.subtitle,
    required this.dark,
    required this.selected,
    required this.onTap,
  });

  final String title;
  final String subtitle;
  final bool dark;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final b = dark ? Brightness.dark : Brightness.light;
    final current = Theme.of(context).brightness;
    final primary = likedinPrimary(b);
    return Semantics(
      button: true,
      selected: selected,
      label: '$title theme',
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: LikedinAppearance.motionReduced(context)
              ? Duration.zero
              : const Duration(milliseconds: 180),
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: likedinSurface(current),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(
              color: selected ? likedinPrimary(current) : likedinOutline(current),
              width: selected ? 2 : 1,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: Container(
                  height: 132,
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [likedinBackgroundTop(b), likedinBackground(b)],
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        height: 22,
                        decoration: BoxDecoration(
                          color: likedinSurface(b).withValues(alpha: .85),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: likedinOutline(b)),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Container(
                          width: 70,
                          height: 18,
                          decoration: BoxDecoration(
                            color: likedinSurfaceRaised(b),
                            borderRadius: BorderRadius.circular(9),
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Align(
                        alignment: Alignment.centerRight,
                        child: Container(
                          width: 56,
                          height: 18,
                          decoration: BoxDecoration(
                            color: likedinOutgoingBubble(b),
                            borderRadius: BorderRadius.circular(9),
                            border: Border.all(color: primary.withValues(alpha: .5)),
                          ),
                        ),
                      ),
                      const Spacer(),
                      Container(
                        height: 22,
                        decoration: BoxDecoration(
                          gradient: likedinPrimaryGradient(b),
                          borderRadius: BorderRadius.circular(11),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                            color: likedinOnSurface(current),
                          ),
                        ),
                        Text(
                          subtitle,
                          style: TextStyle(fontSize: 12, color: likedinMutedText(current)),
                        ),
                      ],
                    ),
                  ),
                  if (selected) Icon(Icons.check_circle_rounded, color: likedinPrimary(current), size: 22),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AccentSwatch extends StatelessWidget {
  const _AccentSwatch({
    required this.accent,
    required this.brightness,
    required this.selected,
    required this.onTap,
  });

  final LikedinAccent accent;
  final Brightness brightness;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = accent.forBrightness(brightness);
    return Semantics(
      button: true,
      selected: selected,
      label: '${accent.name} accent',
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [color, accent.gradientEnd],
            ),
            border: Border.all(
              color: selected ? likedinOnSurface(brightness) : Colors.transparent,
              width: 2.5,
            ),
          ),
          child: selected
              ? Icon(
                  Icons.check_rounded,
                  color: color.computeLuminance() > .4 ? const Color(0xFF04122B) : Colors.white,
                  size: 22,
                )
              : null,
        ),
      ),
    );
  }
}
