import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ---------------------------------------------------------------------------
// Likedin design system: Obsidian Glass (dark) and Arctic Glass (light).
//
// Rules from the 15-screen specification:
//  * Readable first: glass never lowers text contrast.
//  * Controlled depth: real backdrop blur is opt-in (`frosted`) and only used
//    on a few surfaces (auth panel, bars, sheets). Everyday rows use a cheap
//    translucent fill + hairline highlight instead.
//  * Performance aware: the user can pick Full / Lighter / Off effects and
//    reduced motion; both are persisted and respected by shared widgets.
// ---------------------------------------------------------------------------

/// Accent choices. Each has a value tuned for text/controls on dark (Obsidian)
/// and on light (Arctic) surfaces so an accent can never drop below readable
/// contrast; [gradientEnd] is the cyan-leaning end of the primary gradient.
class LikedinAccent {
  const LikedinAccent({
    required this.name,
    required this.dark,
    required this.light,
    required this.gradientEnd,
  });

  final String name;
  final Color dark;
  final Color light;
  final Color gradientEnd;

  Color forBrightness(Brightness b) => b == Brightness.dark ? dark : light;
}

const List<LikedinAccent> likedinAccents = [
  LikedinAccent(
    name: 'Electric blue',
    dark: Color(0xFF6FA8FF),
    light: Color(0xFF0A5FD0),
    gradientEnd: Color(0xFF22D3EE),
  ),
  LikedinAccent(
    name: 'Cyan',
    dark: Color(0xFF3DD6F5),
    light: Color(0xFF00758F),
    gradientEnd: Color(0xFF5EEAD4),
  ),
  LikedinAccent(
    name: 'Violet',
    dark: Color(0xFFB39DFF),
    light: Color(0xFF5B3FD6),
    gradientEnd: Color(0xFF7DB8FF),
  ),
  LikedinAccent(
    name: 'Emerald',
    dark: Color(0xFF4FDBA5),
    light: Color(0xFF0B7A55),
    gradientEnd: Color(0xFF5EE1E8),
  ),
  LikedinAccent(
    name: 'Rose',
    dark: Color(0xFFFF8FB1),
    light: Color(0xFFC2255C),
    gradientEnd: Color(0xFFFFB08A),
  ),
];

enum LikedinEffects { full, lighter, off }

/// Persisted appearance preferences shared by every screen.
class LikedinAppearance {
  LikedinAppearance._();

  static const _accentKey = 'likedin_accent_index_v1';
  static const _effectsKey = 'likedin_effects_level_v1';
  static const _motionKey = 'likedin_reduce_motion_v1';

  static final ValueNotifier<int> accentIndex = ValueNotifier<int>(0);
  static final ValueNotifier<LikedinEffects> effects =
      ValueNotifier<LikedinEffects>(LikedinEffects.full);
  static final ValueNotifier<bool> reduceMotion = ValueNotifier<bool>(false);

  /// Rebuilds the MaterialApp when any appearance value changes.
  static final Listenable listenable =
      Listenable.merge([accentIndex, effects, reduceMotion]);

  static LikedinAccent get accent =>
      likedinAccents[accentIndex.value.clamp(0, likedinAccents.length - 1).toInt()];

  static Future<void> load([SharedPreferences? preferences]) async {
    try {
      final prefs = preferences ?? await SharedPreferences.getInstance();
      final a = prefs.getInt(_accentKey) ?? 0;
      accentIndex.value = a.clamp(0, likedinAccents.length - 1).toInt();
      final e = prefs.getInt(_effectsKey) ?? 0;
      effects.value = LikedinEffects.values[e.clamp(0, 2).toInt()];
      reduceMotion.value = prefs.getBool(_motionKey) ?? false;
    } catch (_) {
      // Defaults are fine if preferences are unavailable.
    }
  }

  static Future<void> setAccent(int index) async {
    accentIndex.value = index.clamp(0, likedinAccents.length - 1).toInt();
    await _save((p) => p.setInt(_accentKey, accentIndex.value));
  }

  static Future<void> setEffects(LikedinEffects value) async {
    effects.value = value;
    await _save((p) => p.setInt(_effectsKey, value.index));
  }

  static Future<void> setReduceMotion(bool value) async {
    reduceMotion.value = value;
    await _save((p) => p.setBool(_motionKey, value));
  }

  static Future<void> reset() async {
    accentIndex.value = 0;
    effects.value = LikedinEffects.full;
    reduceMotion.value = false;
    await _save((p) async {
      await p.remove(_accentKey);
      await p.remove(_effectsKey);
      await p.remove(_motionKey);
    });
  }

  static Future<void> _save(Future<void> Function(SharedPreferences) write) async {
    try {
      await write(await SharedPreferences.getInstance());
    } catch (_) {}
  }

  /// True when animations should be skipped or shortened: either the user
  /// chose reduced motion in Likedin or the OS asks for it.
  static bool motionReduced(BuildContext context) =>
      reduceMotion.value || MediaQuery.of(context).disableAnimations;
}

// ---- Palette ---------------------------------------------------------------

Color likedinBackground(Brightness brightness) => brightness == Brightness.dark
    ? const Color(0xFF060B18) // obsidian midnight
    : const Color(0xFFEAF1FB); // arctic frost

Color likedinBackgroundTop(Brightness brightness) =>
    brightness == Brightness.dark
        ? const Color(0xFF0B1530)
        : const Color(0xFFF7FAFF);

Color likedinSurface(Brightness brightness) => brightness == Brightness.dark
    ? const Color(0xFF0E1830)
    : const Color(0xFFFFFFFF);

Color likedinSurfaceRaised(Brightness brightness) =>
    brightness == Brightness.dark
        ? const Color(0xFF16233F)
        : const Color(0xFFE6EEF9);

Color likedinOutline(Brightness brightness) => brightness == Brightness.dark
    ? const Color(0xFF28385A)
    : const Color(0xFFD3DEEE);

Color likedinOnSurface(Brightness brightness) => brightness == Brightness.dark
    ? const Color(0xFFEAF0FF)
    : const Color(0xFF0C1A33);

Color likedinMutedText(Brightness brightness) => brightness == Brightness.dark
    ? const Color(0xFFA3B1CE)
    : const Color(0xFF51617F);

Color likedinPrimary(Brightness brightness) =>
    LikedinAppearance.accent.forBrightness(brightness);

/// Darkens [color] just enough that white text on it reaches [minContrast]
/// (WCAG ratio). This is what keeps every accent choice readable.
Color likedinEnsureWhiteContrast(Color color, {double minContrast = 4.5}) {
  var result = color;
  for (var i = 0; i < 24; i++) {
    final ratio = 1.05 / (result.computeLuminance() + .05);
    if (ratio >= minContrast) return result;
    result = Color.lerp(result, const Color(0xFF000000), .06)!;
  }
  return result;
}

/// Blue-to-cyan (or accent equivalent) gradient for primary actions. Both
/// stops are contrast-corrected for white labels, so it is safe with any accent.
LinearGradient likedinPrimaryGradient(Brightness brightness) {
  final accent = LikedinAppearance.accent;
  final dark = brightness == Brightness.dark;
  final start = likedinEnsureWhiteContrast(
    dark ? Color.lerp(accent.dark, const Color(0xFF2F6BFF), .5)! : accent.light,
  );
  final end = likedinEnsureWhiteContrast(
    dark ? accent.gradientEnd : Color.lerp(accent.light, accent.gradientEnd, .55)!,
  );
  return LinearGradient(
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
    colors: [start, end],
  );
}

/// Outgoing chat-bubble fill. Chosen so on-bubble text stays readable.
Color likedinOutgoingBubble(Brightness brightness) {
  final accent = likedinPrimary(brightness);
  return brightness == Brightness.dark
      ? Color.alphaBlend(accent.withValues(alpha: .32), const Color(0xFF0E1830))
      : Color.alphaBlend(accent.withValues(alpha: .15), Colors.white);
}

/// Incoming chat-bubble fill for Liquid Glass bubbles in both themes.
Color likedinIncomingBubble(Brightness brightness) =>
    brightness == Brightness.dark
        ? const Color(0xD4111E38)
        : const Color(0xEBFFFFFF);

// ---- Surfaces --------------------------------------------------------------

/// Liquid Glass content surface for cards, floating bars and grouped rows.
///
/// Renders a luminous translucent fill with a diagonal specular sheen and
/// crisp glass rim highlight (zero GPU blur cost on scrolling lists). Set
/// [frosted] for real backdrop blur on floating chrome (nav bar, headers,
/// composer, auth card); sigma is capped at 10 for smooth 3 GB RAM playback
/// and skipped automatically when the user picks Lighter or Off effects.
class GlassPanel extends StatelessWidget {
  const GlassPanel({
    required this.child,
    this.padding = EdgeInsets.zero,
    this.radius = const BorderRadius.all(Radius.circular(20)),
    this.blur = 0,
    this.tint,
    this.glow = false,
    this.frosted = false,
    super.key,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final BorderRadius radius;
  final double blur;
  final Color? tint;
  final bool glow;
  final bool frosted;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    return ValueListenableBuilder<LikedinEffects>(
      valueListenable: LikedinAppearance.effects,
      child: Padding(padding: padding, child: child),
      builder: (context, effects, builtChild) {
        final base = tint ?? likedinSurface(brightness);
        final fancy = effects != LikedinEffects.off;
        final isFull = effects == LikedinEffects.full;
        final primary = likedinPrimary(brightness);
        final fillAlpha = !fancy
            ? 1.0
            : frosted
                ? (dark ? .64 : .74)
                : (dark ? .76 : .84);
        final borderColor = !fancy
            ? likedinOutline(brightness)
            : dark
                ? Colors.white.withValues(alpha: isFull ? .18 : .11)
                : Colors.white.withValues(alpha: .95);
        final Widget body = DecoratedBox(
          decoration: BoxDecoration(
            color: base.withValues(alpha: fillAlpha),
            gradient: fancy
                ? LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    stops: const [0.0, 0.36, 1.0],
                    colors: dark
                        ? [
                            Colors.white.withValues(alpha: isFull ? .14 : .07),
                            Colors.white.withValues(alpha: .02),
                            primary.withValues(alpha: isFull ? .07 : .02),
                          ]
                        : [
                            Colors.white.withValues(alpha: isFull ? .86 : .64),
                            Colors.white.withValues(alpha: .28),
                            primary.withValues(alpha: isFull ? .07 : .02),
                          ],
                  )
                : null,
            borderRadius: radius,
            border: Border.all(
              color: borderColor,
              width: isFull ? 1.15 : 1.0,
            ),
          ),
          child: builtChild,
        );
        Widget result;
        if (frosted && isFull) {
          final sigma = (blur <= 0 ? 9.0 : blur).clamp(0.0, 10.0).toDouble();
          result = RepaintBoundary(
            child: ClipRRect(
              borderRadius: radius,
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: sigma, sigmaY: sigma),
                child: body,
              ),
            ),
          );
        } else if (radius == BorderRadius.zero) {
          result = body;
        } else {
          result = ClipRRect(borderRadius: radius, child: body);
        }
        // Soft ambient glass depth & optional accent halo live outside the clip.
        if (fancy) {
          result = DecoratedBox(
            decoration: BoxDecoration(
              borderRadius: radius,
              boxShadow: [
                if (glow && isFull)
                  BoxShadow(
                    color: primary.withValues(alpha: dark ? .24 : .16),
                    blurRadius: 24,
                    spreadRadius: -4,
                  ),
                if (isFull)
                  BoxShadow(
                    color: dark
                        ? Colors.black.withValues(alpha: .26)
                        : Color(0xFF0C1A33).withValues(alpha: .06),
                    blurRadius: 16,
                    offset: const Offset(0, 6),
                    spreadRadius: -4,
                  ),
              ],
            ),
            child: result,
          );
        }
        return result;
      },
    );
  }
}

/// Layered Liquid Glass ambient backdrop: a smooth vertical gradient plus
/// three static soft light orbs. Zero animation and zero blur filters, so it
/// costs one cheap cached paint; with effects Off it collapses to a flat fill.
class AuroraBackdrop extends StatelessWidget {
  const AuroraBackdrop({required this.child, super.key});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    return ValueListenableBuilder<LikedinEffects>(
      valueListenable: LikedinAppearance.effects,
      child: child,
      builder: (context, effects, builtChild) {
        final accent = likedinPrimary(brightness);
        final endAccent = LikedinAppearance.accent.gradientEnd;
        final children = <Widget>[
          if (effects == LikedinEffects.off)
            ColoredBox(color: likedinBackground(brightness))
          else
            RepaintBoundary(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      likedinBackgroundTop(brightness),
                      likedinBackground(brightness),
                    ],
                  ),
                ),
                child: effects == LikedinEffects.full
                    ? Stack(
                        fit: StackFit.expand,
                        children: [
                          DecoratedBox(
                            decoration: BoxDecoration(
                              gradient: RadialGradient(
                                center: const Alignment(-.88, -.92),
                                radius: 1.05,
                                colors: [
                                  accent.withValues(alpha: dark ? .24 : .18),
                                  accent.withValues(alpha: 0),
                                ],
                              ),
                            ),
                          ),
                          DecoratedBox(
                            decoration: BoxDecoration(
                              gradient: RadialGradient(
                                center: const Alignment(.95, .85),
                                radius: .95,
                                colors: [
                                  endAccent.withValues(alpha: dark ? .15 : .14),
                                  endAccent.withValues(alpha: 0),
                                ],
                              ),
                            ),
                          ),
                          DecoratedBox(
                            decoration: BoxDecoration(
                              gradient: RadialGradient(
                                center: const Alignment(.85, -.22),
                                radius: .75,
                                colors: [
                                  accent.withValues(alpha: dark ? .10 : .08),
                                  accent.withValues(alpha: 0),
                                ],
                              ),
                            ),
                          ),
                        ],
                      )
                    : null,
              ),
            ),
          if (builtChild != null) builtChild,
        ];
        // Same Stack(expand) layout contract as before.
        return Stack(fit: StackFit.expand, children: children);
      },
    );
  }
}

/// Primary action button: blue-to-cyan gradient pill with a loading state.
/// Lightweight 90ms press-down scale (0.97) for tactile tap feedback.
/// Automatically becomes a no-op when Reduce Motion is enabled.
class LikedinPressScale extends StatefulWidget {
  const LikedinPressScale({
    required this.child,
    this.enabled = true,
    this.pressedScale = 0.95,
    super.key,
  });

  final Widget child;
  final bool enabled;
  final double pressedScale;

  @override
  State<LikedinPressScale> createState() => _LikedinPressScaleState();
}

class _LikedinPressScaleState extends State<LikedinPressScale> {
  bool _pressed = false;

  void _setPressed(bool value) {
    if (!widget.enabled || LikedinAppearance.reduceMotion.value) return;
    if (_pressed != value && mounted) setState(() => _pressed = value);
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      behavior: HitTestBehavior.translucent,
      onPointerDown: (_) => _setPressed(true),
      onPointerUp: (_) => _setPressed(false),
      onPointerCancel: (_) => _setPressed(false),
      child: AnimatedScale(
        scale: _pressed ? widget.pressedScale : 1.0,
        duration: LikedinAppearance.reduceMotion.value
            ? Duration.zero
            : const Duration(milliseconds: 130),
        curve: Curves.easeOutCubic,
        child: widget.child,
      ),
    );
  }
}

class GradientButton extends StatelessWidget {
  const GradientButton({
    required this.onPressed,
    required this.child,
    this.height = 52,
    super.key,
  });

  final VoidCallback? onPressed;
  final Widget child;
  final double height;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final enabled = onPressed != null;
    return LikedinPressScale(
      enabled: enabled,
      child: Opacity(
        opacity: enabled ? 1 : .55,
        child: Material(
        color: Colors.transparent,
        child: Ink(
          height: height,
          decoration: BoxDecoration(
            gradient: likedinPrimaryGradient(brightness),
            borderRadius: BorderRadius.circular(height),
          ),
          child: InkWell(
            onTap: onPressed,
            borderRadius: BorderRadius.circular(height),
            child: Center(
              child: DefaultTextStyle.merge(
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                ),
                child: IconTheme.merge(
                  data: const IconThemeData(color: Colors.white),
                  child: child,
                ),
              ),
            ),
          ),
        ),
      ),
      ),
    );
  }
}
