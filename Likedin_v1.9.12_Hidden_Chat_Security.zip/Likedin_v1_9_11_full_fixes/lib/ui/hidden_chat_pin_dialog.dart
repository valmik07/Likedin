import 'package:flutter/material.dart';

/// Result from the hidden-chat password dialog.
class HiddenChatPinDialogResult {
  const HiddenChatPinDialogResult({this.password, this.requestRecovery = false});

  final String? password;
  final bool requestRecovery;
}

/// Password dialog used to configure or unlock the device-local hidden-chat
/// section. It returns the entered password to the caller and never persists it.
class HiddenChatPinDialog extends StatefulWidget {
  const HiddenChatPinDialog({required this.setup, super.key});

  final bool setup;

  static Future<HiddenChatPinDialogResult?> show(
    BuildContext context, {
    required bool setup,
  }) {
    return showDialog<HiddenChatPinDialogResult>(
      context: context,
      barrierDismissible: false,
      builder: (_) => HiddenChatPinDialog(setup: setup),
    );
  }

  @override
  State<HiddenChatPinDialog> createState() => _HiddenChatPinDialogState();
}

class _HiddenChatPinDialogState extends State<HiddenChatPinDialog> {
  final TextEditingController _password = TextEditingController();
  final TextEditingController _confirmation = TextEditingController();
  bool _obscure = true;
  String? _error;

  @override
  void dispose() {
    _password.dispose();
    _confirmation.dispose();
    super.dispose();
  }

  void _submit() {
    final password = _password.text;
    if (password.length < 8) {
      setState(() => _error = 'Use at least 8 characters.');
      return;
    }
    if (widget.setup && password != _confirmation.text) {
      setState(() => _error = 'The passwords do not match.');
      return;
    }
    Navigator.of(context).pop(HiddenChatPinDialogResult(password: password));
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.setup ? 'Protect hidden chats' : 'Unlock hidden chats'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.setup
                  ? 'Create a separate password for hidden conversations. Use at least 8 characters.'
                  : 'Enter your hidden-chats password to continue.',
              style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _password,
              autofocus: true,
              obscureText: _obscure,
              autocorrect: false,
              enableSuggestions: false,
              textInputAction: widget.setup ? TextInputAction.next : TextInputAction.done,
              onSubmitted: widget.setup ? null : (_) => _submit(),
              decoration: InputDecoration(
                labelText: 'Password',
                border: const OutlineInputBorder(),
                suffixIcon: IconButton(
                  tooltip: _obscure ? 'Show password' : 'Hide password',
                  onPressed: () => setState(() => _obscure = !_obscure),
                  icon: Icon(_obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                ),
              ),
            ),
            if (widget.setup) ...[
              const SizedBox(height: 12),
              TextField(
                controller: _confirmation,
                obscureText: _obscure,
                autocorrect: false,
                enableSuggestions: false,
                textInputAction: TextInputAction.done,
                onSubmitted: (_) => _submit(),
                decoration: const InputDecoration(
                  labelText: 'Confirm password',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
            if (_error != null) ...[
              const SizedBox(height: 10),
              Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            ],
          ],
        ),
      ),
      actions: [
        if (!widget.setup)
          TextButton(
            onPressed: () => Navigator.of(context).pop(
              const HiddenChatPinDialogResult(requestRecovery: true),
            ),
            child: const Text('Forgot password?'),
          ),
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        FilledButton(
          onPressed: _submit,
          child: Text(widget.setup ? 'Create password' : 'Unlock'),
        ),
      ],
    );
  }
}
