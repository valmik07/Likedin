# Likedin v2.4.3+128 — Final Audit & Stability Release

## Critical & High-Severity Fixes in v2.4.3+128
1. **Eliminated `No Overlay widget found` crash on call buttons:** Replaced `Tooltip` / `tooltip:` inside `_MinimizedAudioCallBar`, `_LiveCallDialog`, and `_IncomingCallDialog` (mounted above `Navigator`'s `Overlay`) with `Semantics`, and guarded `ScaffoldMessenger.maybeOf(context)`.
2. **Fixed cold-start Android Direct Share (`MainActivity.kt`):** Added `shareHandlerReady` gating so shares received before Dart's `AppShell` registers its channel handler are always preserved in `pendingSharePayload` instead of being dropped.
3. **Fixed Android System PiP when minimizing a video call:** System PiP (`width < 260`) now takes priority over the in-app minimized bubble so leaving the app while minimized shows crisp full-bleed video.
4. **Disabled proximity screen-off while audio calls are minimized:** Minimizing an audio call to use Chat/Files/Home automatically releases `PROXIMITY_SCREEN_OFF_WAKE_LOCK` and restores it when expanded.
5. **Fixed minimized incoming-call flash on remote hangup & sign-out teardown:** Remote hangups close cleanly without flashing full-screen, signing out automatically ends any active/minimized call via `LikedinActiveCallHost.forceEndActiveCall()`, and disposed call widgets clear their host callbacks.
