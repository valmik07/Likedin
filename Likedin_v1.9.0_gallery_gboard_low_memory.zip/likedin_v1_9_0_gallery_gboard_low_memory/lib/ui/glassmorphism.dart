import 'package:flutter/material.dart';

/// A restrained frosted-glass surface for cards, sheets and floating panels.
///
/// The tint remains fairly opaque so text stays readable over busy backgrounds.
class GlassPanel extends StatelessWidget {
  const GlassPanel({
    required this.child,
    this.padding = EdgeInsets.zero,
    this.radius = const BorderRadius.all(Radius.circular(22)),
    this.blur = 4,
    this.tint,
    this.glow = false,
    super.key,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final BorderRadius radius;
  final double blur;
  final Color? tint;
  final bool glow;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final base = tint ??
        (dark ? const Color(0xE8122034) : const Color(0xF5FFFFFF));
    final border = dark
        ? Colors.white.withValues(alpha: .12)
        : const Color(0xFF9CBDEB).withValues(alpha: .20);

    // Intentionally avoid BackdropFilter: live Gaussian blur forces extra
    // off-screen compositing and causes visible frame drops on entry-level
    // Android GPUs. The near-opaque tint and thin border preserve the subdued
    // glass appearance without the expensive blur pass.
    return ClipRRect(
      borderRadius: radius,
      child: DecoratedBox(
        decoration: BoxDecoration(
            color: base,
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                base.withValues(alpha: dark ? .98 : .99),
                base.withValues(alpha: dark ? .92 : .96),
              ],
            ),
            borderRadius: radius,
            border: Border.all(color: border, width: 1),
            boxShadow: glow
                ? [
                    BoxShadow(
                      color: dark
                          ? const Color(0xFF45C9F5).withValues(alpha: .035)
                          : const Color(0xFF527CEB).withValues(alpha: .035),
                      blurRadius: 14,
                      offset: const Offset(0, 6),
                    ),
                  ]
                : const [],
          ),
          child: Padding(padding: padding, child: child),
      ),
    );
  }
}

/// A low-cost ambient background. The blurred colour fields are static and
/// do not run animations or consume timers.
class AuroraBackdrop extends StatelessWidget {
  const AuroraBackdrop({required this.child, super.key});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Stack(
      fit: StackFit.expand,
      children: [
        DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: dark
                  ? const [
                      Color(0xFF070D19),
                      Color(0xFF101B31),
                      Color(0xFF080F1D),
                    ]
                  : const [
                      Color(0xFFF4F7FF),
                      Color(0xFFEAF1FF),
                      Color(0xFFF7F9FF),
                    ],
            ),
          ),
        ),
        Positioned(
          top: -110,
          right: -90,
          child: IgnorePointer(
            child: Container(
              width: 280,
              height: 280,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    const Color(0xFF4C7DFF).withValues(alpha: dark ? .24 : .13),
                    const Color(0xFF4C7DFF).withValues(alpha: 0),
                  ],
                ),
              ),
            ),
          ),
        ),
        Positioned(
          left: -120,
          bottom: -140,
          child: IgnorePointer(
            child: Container(
              width: 320,
              height: 320,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    const Color(0xFF21C8E8).withValues(alpha: dark ? .15 : .10),
                    const Color(0xFF21C8E8).withValues(alpha: 0),
                  ],
                ),
              ),
            ),
          ),
        ),
        child,
      ],
    );
  }
}
