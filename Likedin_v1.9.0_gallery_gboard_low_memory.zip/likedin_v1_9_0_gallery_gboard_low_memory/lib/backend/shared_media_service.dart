import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:http/http.dart' as http;
import 'package:mime/mime.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import 'package:video_compress/video_compress.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import 'backend_config.dart';

/// Private shared media transport. Uploads use Supabase Storage's TUS endpoint
/// so offsets survive process death. A persisted queue is retried in the foreground when the user initiates another send.
class SharedMediaService {
  SharedMediaService(this.client);
  final SupabaseClient client;
  static const bucket = 'likedin-media';
  static const maxBytes = 50 * 1024 * 1024;
  static String? lastQueueError;
  static const _queueKey = 'likedin_media_retry_queue_v2';
  static const _quarantineKey = 'likedin_media_retry_queue_quarantine_v1';
  static const _uuid = Uuid();
  static const _chunkSize = 5 * 1024 * 1024;
  static Future<bool>? _processingQueue;
  static Future<void> _queueMutationTail = Future<void>.value();
  static bool _retryRequested = false;
  static String? _quarantineError;
  static int lastQuarantinedCount = 0;

  static const Set<String> _bucketAllowedMimeTypes = <String>{
    'image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/heic', 'image/heif',
    'video/mp4', 'video/quicktime', 'video/webm', 'video/3gpp', 'video/x-matroska',
    'audio/mp4', 'audio/x-m4a', 'audio/m4a', 'audio/aac', 'audio/mpeg', 'audio/mp3',
    'audio/wav', 'audio/x-wav', 'audio/webm', 'audio/ogg',
    'application/pdf', 'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'text/plain', 'text/csv', 'application/json', 'application/zip',
    'application/octet-stream',
  };

  static String _queueKeyFor(String uid) => '$_queueKey:$uid';

  bool isMediaPayload(String value) {
    try {
      final m = jsonDecode(value);
      return m is Map && m['__likedin_media_v1'] == true;
    } catch (_) {
      return false;
    }
  }

  Map<String, dynamic>? decode(String value) {
    try {
      final m = jsonDecode(value);
      if (m is Map && m['__likedin_media_v1'] == true) {
        return Map<String, dynamic>.from(m);
      }
    } catch (_) {}
    return null;
  }

  /// Human-readable summary of a media payload for reply quotes and banners.
  String describePayload(Map<String, dynamic> payload) {
    final kind = payload['kind']?.toString() ?? 'file';
    final name = payload['name']?.toString() ?? 'Attachment';
    switch (kind) {
      case 'image':
        return 'Photo · $name';
      case 'video':
        return 'Video · $name';
      case 'audio':
        return 'Voice message';
      default:
        return 'File · $name';
    }
  }

  static String _normalizeMime(String filename) {
    final ext = p.extension(filename).replaceFirst('.', '').toLowerCase();
    if (ext == 'm4a') return 'audio/mp4';
    final detected = lookupMimeType(filename) ?? 'application/octet-stream';
    if (detected == 'audio/x-m4a' || detected == 'audio/m4a') {
      return 'audio/mp4';
    }
    // Supabase Storage rejects a Content-Type that is not in the bucket's
    // allow-list. Unknown and uncommon formats (RAR/7z/APK/SVG/BMP/HTML, etc.)
    // are still transferable as opaque files using the explicitly allowed
    // application/octet-stream type.
    return _bucketAllowedMimeTypes.contains(detected) ? detected : 'application/octet-stream';
  }

  /// Compresses videos before enqueueing. The original is never modified.
  Future<File> prepare(File source) async {
    final mime = _normalizeMime(source.path);
    if (!mime.startsWith('video/')) return source;
    final result = await VideoCompress.compressVideo(
      source.path,
      quality: VideoQuality.MediumQuality,
      deleteOrigin: false,
      includeAudio: true,
      frameRate: 30,
    );
    final compressed = result?.file;
    if (compressed == null || !await compressed.exists()) return source;
    final originalSize = await source.length();
    final compressedSize = await compressed.length();
    // Keep original when compression does not produce a meaningful reduction.
    if (compressedSize >= originalSize || compressedSize == 0) return source;
    return compressed;
  }

  Future<Map<String, dynamic>> upload(
    File file, {
    String? objectPath,
    String? displayName,
    void Function(double progress)? onProgress,
  }) async {
    final uid = client.auth.currentUser?.id;
    if (uid == null) throw StateError('Sign in before sharing files.');
    final stat = await file.length();
    if (stat <= 0 || stat > maxBytes) {
      throw StateError('Files must be between 1 byte and 50 MB after compression.');
    }
    final name = (displayName?.trim().isNotEmpty == true)
        ? displayName!.trim()
        : p.basename(file.path);
    final mime = _normalizeMime(name);
    final ext = p.extension(name).replaceFirst('.', '').toLowerCase();
    final object = objectPath ?? '$uid/${_uuid.v4()}${ext.isEmpty ? '' : '.$ext'}';
    await _tusUpload(file, object, mime, onProgress: onProgress);
    final kind = mime.startsWith('image/')
        ? 'image'
        : mime.startsWith('video/')
            ? 'video'
            : mime.startsWith('audio/')
                ? 'audio'
                : 'file';
    final metadata = <String, dynamic>{
      '__likedin_media_v1': true,
      'path': object,
      'name': p.basename(name),
      'mime': mime,
      'size': stat,
      'kind': kind,
    };

    // Keep a local copy for the sender before the picker/cache source can be
    // removed. The sender should render the just-uploaded attachment from its
    // own cache instead of immediately downloading the same object through
    // Storage RLS. The receiver continues to download through the private bucket.
    try {
      await _cacheUploadedFile(file, metadata);
    } catch (_) {
      // A cache failure must not turn a successful remote upload into a failed send.
    }
    return metadata;
  }

  Future<File> _cacheUploadedFile(File source, Map<String, dynamic> metadata) async {
    final path = metadata['path']?.toString() ?? '';
    if (path.isEmpty) throw StateError('Uploaded media is missing its storage path.');
    final support = await getApplicationSupportDirectory();
    final cacheDir = Directory(p.join(support.path, 'LikedinMediaCache'));
    await cacheDir.create(recursive: true);
    final key = base64Url.encode(utf8.encode(path)).replaceAll('=', '');
    final ext = p.extension(metadata['name']?.toString() ?? '');
    final cached = File(p.join(cacheDir.path, '$key$ext'));
    final temp = File('${cached.path}.part');
    if (await temp.exists()) await temp.delete();
    await source.copy(temp.path);
    if (await cached.exists()) await cached.delete();
    final result = await temp.rename(cached.path);
    // Uploaded files are already in the local cache for the sender. Include
    // these writes in the same 250 MB eviction policy as downloaded files.
    await _evictMediaCache(cacheDir, preservePath: cached.path);
    return result;
  }

  Future<void> _tusUpload(
    File file,
    String object,
    String mime, {
    void Function(double progress)? onProgress,
  }) async {
    final session = client.auth.currentSession;
    if (session == null) {
      throw StateError('Your session expired. Sign in again to resume media upload.');
    }
    final prefs = await SharedPreferences.getInstance();
    final resumeKey = '$_queueKey:tus:$object';
    final total = await file.length();
    final base = BackendConfig.supabaseUrl;
    final headers = <String, String>{
      'apikey': BackendConfig.supabaseAnonKey,
      'Authorization': 'Bearer ${session.accessToken}',
      'Tus-Resumable': '1.0.0',
    };

    Future<bool> existingObjectMatches() async {
      try {
        // A conflict is success only when Storage confirms this exact immutable
        // object exists and its stored byte length matches the queued file.
        final dynamic info = await client.storage.from(bucket).info(object);
        final dynamic storedMetadata = info.metadata;
        final storedMime = storedMetadata is Map
            ? (storedMetadata['mimetype'] ?? storedMetadata['contentType'])?.toString()
            : null;
        return info.size == total && (storedMime == null || storedMime == mime);
      } catch (_) {
        return false;
      }
    }

    Future<String?> createTusSession() async {
      final metadata = {
        'bucketName': bucket,
        'objectName': object,
        'contentType': mime,
        'cacheControl': '3600',
      }.entries.map((e) => '${e.key} ${base64.encode(utf8.encode(e.value))}').join(',');
      final response = await http.post(
        Uri.parse('$base/storage/v1/upload/resumable'),
        headers: {
          ...headers,
          'Upload-Length': '$total',
          'Upload-Metadata': metadata,
        },
      );
      if (response.statusCode == 409) {
        if (await existingObjectMatches()) {
          await prefs.remove(resumeKey);
          return null;
        }
        throw const HttpException('Storage reported an upload conflict, but the expected complete object was not found. Retry the upload.');
      }
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw HttpException('Could not start resumable upload (${response.statusCode}): ${response.body}');
      }
      final location = response.headers['location'];
      if (location == null) {
        throw const HttpException('Storage did not return a resumable upload location.');
      }
      final createdUrl = Uri.parse(base).resolve(location).toString();
      await prefs.setString(resumeKey, createdUrl);
      return createdUrl;
    }

    var uploadUrl = prefs.getString(resumeKey) ?? await createTusSession();
    if (uploadUrl == null) return; // The object already exists in Storage.
    var head = await http.head(Uri.parse(uploadUrl), headers: headers);
    if (head.statusCode == 404 || head.statusCode == 410 || head.statusCode == 400 || head.statusCode == 403) {
      // Stale or expired TUS session URL; discard and create a fresh session.
      await prefs.remove(resumeKey);
      uploadUrl = await createTusSession();
      if (uploadUrl == null) return; // The object already exists in Storage.
      head = await http.head(Uri.parse(uploadUrl), headers: headers);
    }
    if (head.statusCode < 200 || head.statusCode >= 300) {
      throw HttpException('Could not resume upload (${head.statusCode}).');
    }
    var offset = int.tryParse(head.headers['upload-offset'] ?? '0') ?? 0;
    final raf = await file.open(mode: FileMode.read);
    try {
      while (offset < total) {
        await raf.setPosition(offset);
        final length = min(_chunkSize, total - offset).toInt();
        final chunk = await raf.read(length);
        final response = await http.patch(
          Uri.parse(uploadUrl),
          headers: {
            ...headers,
            'Content-Type': 'application/offset+octet-stream',
            'Upload-Offset': '$offset',
          },
          body: chunk,
        );
        if (response.statusCode == 404 || response.statusCode == 410) {
          await prefs.remove(resumeKey);
        }
        if (response.statusCode < 200 || response.statusCode >= 300) {
          throw HttpException('Upload paused at $offset/$total bytes (${response.statusCode}).');
        }
        offset = int.tryParse(response.headers['upload-offset'] ?? '') ?? (offset + chunk.length);
        onProgress?.call(offset / total);
      }
    } finally {
      await raf.close();
    }
    await prefs.remove(resumeKey);
  }

  Future<void> enqueue(
    File file,
    String recipientId, {
    String? originalName,
    String? replyToMessageId,
  }) async {
    final uid = client.auth.currentUser?.id;
    if (uid == null) throw StateError('Sign in before queuing an attachment.');
    final sourceSize = await file.length();
    if (sourceSize <= 0 || sourceSize > maxBytes) {
      throw StateError('Files must be between 1 byte and 50 MB after compression.');
    }
    final id = _uuid.v4();
    // Picker/cache/recorder files may disappear after the app is closed. Copy
    // each item into app-private persistent storage before registering the job.
    final support = await getApplicationSupportDirectory();
    final pendingDir = Directory(p.join(support.path, 'LikedinPendingMedia'));
    await pendingDir.create(recursive: true);
    final resolvedName = (originalName?.trim().isNotEmpty == true)
        ? originalName!.trim()
        : p.basename(file.path);
    final ext = p.extension(resolvedName).isNotEmpty
        ? p.extension(resolvedName)
        : p.extension(file.path);
    final durableFile = File(p.join(pendingDir.path, '$id$ext'));
    await file.copy(durableFile.path);
    final prefs = await SharedPreferences.getInstance();
    await _withQueueMutationLock(() async {
      final queue = await _readQueueForUser(prefs, uid);
      queue.add({
        'id': id,
        'senderId': uid,
        'path': durableFile.path,
        'recipient': recipientId,
        'replyToMessageId': replyToMessageId,
        'originalName': resolvedName,
        'attempts': 0,
        'nextAttemptAt': null,
        'createdAt': DateTime.now().toUtc().toIso8601String(),
      });
      await prefs.setString(_queueKeyFor(uid), jsonEncode(queue));
    });
  }

  static List<Map<String, dynamic>> _decodeQueue(String raw) {
    try {
      final decoded = jsonDecode(raw) as List;
      return decoded.map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } catch (_) {
      return [];
    }
  }

  static Future<List<Map<String, dynamic>>> _readQueueForUser(
    SharedPreferences prefs,
    String uid,
  ) async {
    // v1.7.x used one global queue without an owner UID. Never guess which
    // account created those uploads: quarantine them for manual recovery.
    final legacy = _decodeQueue(prefs.getString(_queueKey) ?? '[]');
    if (legacy.isNotEmpty) {
      final quarantine = _decodeQueue(prefs.getString(_quarantineKey) ?? '[]');
      final additions = <String, List<Map<String, dynamic>>>{};
      for (final item in legacy) {
        final owner = item['senderId']?.toString();
        if (owner == null || owner.isEmpty) {
          quarantine.add({...item, 'quarantineReason': 'Legacy queue item has no account owner.'});
        } else {
          (additions[owner] ??= <Map<String, dynamic>>[]).add(item);
        }
      }
      for (final entry in additions.entries) {
        final existing = _decodeQueue(prefs.getString(_queueKeyFor(entry.key)) ?? '[]');
        existing.addAll(entry.value);
        await prefs.setString(_queueKeyFor(entry.key), jsonEncode(existing));
      }
      await prefs.setString(_quarantineKey, jsonEncode(quarantine));
      await prefs.remove(_queueKey);
    }
    return _decodeQueue(prefs.getString(_queueKeyFor(uid)) ?? '[]');
  }

  static Future<bool> processRetryQueue(SupabaseClient client) {
    final active = _processingQueue;
    if (active != null) {
      // A send can enqueue after the active run took its queue snapshot. Mark
      // that another pass is required before resolving the shared future.
      _retryRequested = true;
      return active;
    }
    lastQueueError = null;
    lastQuarantinedCount = 0;
    _quarantineError = null;
    final completer = Completer<bool>();
    final operation = completer.future;
    _processingQueue = operation;
    () async {
      try {
        var result = false;
        do {
          _retryRequested = false;
          result = await _processRetryQueue(client);
        } while (_retryRequested);
        completer.complete(result);
      } catch (error, stackTrace) {
        completer.completeError(error, stackTrace);
      } finally {
        if (identical(_processingQueue, operation)) _processingQueue = null;
      }
    }();
    return operation;
  }

  static Future<T> _withQueueMutationLock<T>(Future<T> Function() operation) {
    final previous = _queueMutationTail;
    final released = Completer<void>();
    _queueMutationTail = released.future;
    return (() async {
      await previous;
      try {
        return await operation();
      } finally {
        released.complete();
      }
    })();
  }

  static Future<void> _removeQueuedItemUnlocked(
    SharedPreferences prefs,
    String uid,
    String itemId, {
    Map<String, dynamic>? fallbackItem,
  }) async {
    final queue = _decodeQueue(prefs.getString(_queueKeyFor(uid)) ?? '[]');
    queue.removeWhere((entry) {
      if (itemId.isNotEmpty) return entry['id']?.toString() == itemId;
      return fallbackItem != null && jsonEncode(entry) == jsonEncode(fallbackItem);
    });
    await prefs.setString(_queueKeyFor(uid), jsonEncode(queue));
  }

  static Future<void> _removeQueuedItem(
    SharedPreferences prefs,
    String uid,
    String itemId,
  ) async {
    await _withQueueMutationLock(() => _removeQueuedItemUnlocked(prefs, uid, itemId));
  }

  static Future<void> _updateQueuedItem(
    SharedPreferences prefs,
    String uid,
    Map<String, dynamic> updated,
  ) async {
    await _withQueueMutationLock(() async {
      final queue = _decodeQueue(prefs.getString(_queueKeyFor(uid)) ?? '[]');
      final id = updated['id']?.toString();
      final index = queue.indexWhere((entry) => entry['id']?.toString() == id);
      if (index < 0) return;
      queue[index] = updated;
      await prefs.setString(_queueKeyFor(uid), jsonEncode(queue));
    });
  }

  static Future<void> _quarantineQueuedItem(
    SharedPreferences prefs,
    String uid,
    Map<String, dynamic> item,
    String reason,
  ) async {
    await _withQueueMutationLock(() async {
      final quarantine = _decodeQueue(prefs.getString(_quarantineKey) ?? '[]');
      final id = item['id']?.toString();
      final duplicate = id != null && id.isNotEmpty
          ? quarantine.any((entry) => entry['id']?.toString() == id)
          : quarantine.any((entry) =>
              entry['path'] == item['path'] &&
              entry['createdAt'] == item['createdAt'] &&
              entry['originalName'] == item['originalName']);
      if (!duplicate) {
        quarantine.add({
          ...item,
          'quarantinedAt': DateTime.now().toUtc().toIso8601String(),
          'quarantineReason': reason,
        });
        await prefs.setString(_quarantineKey, jsonEncode(quarantine));
      }
      await _removeQueuedItemUnlocked(prefs, uid, id ?? '', fallbackItem: item);
    });
    lastQuarantinedCount++;
    _quarantineError ??= 'Quarantined: $reason';
    lastQueueError = _quarantineError;
  }

  /// A serialized foreground processor. Failed items are kept with exponential
  /// backoff; startup, resume, connectivity recovery and manual actions share it.
  static Future<bool> _processRetryQueue(SupabaseClient client) async {
    final uid = client.auth.currentUser?.id;
    if (uid == null) {
      lastQueueError = 'Sign in before sending queued attachments.';
      return false;
    }
    final prefs = await SharedPreferences.getInstance();
    final queue = await _withQueueMutationLock(() => _readQueueForUser(prefs, uid));
    if (queue.isEmpty) return lastQuarantinedCount == 0 && _quarantineError == null;
    final service = SharedMediaService(client);
    String? peer;
    try {
      peer = await client.rpc('likedin_get_peer_id') as String?;
    } catch (error) {
      lastQueueError = 'Could not verify the paired recipient: $error';
      return false;
    }
    if (peer == null) {
      for (final item in queue) {
        await _quarantineQueuedItem(
          prefs,
          uid,
          item,
          'The paired recipient is unavailable, so this upload cannot be routed.',
        );
      }
      return false;
    }

    for (final item in List<Map<String, dynamic>>.from(queue)) {
      if (item['senderId']?.toString() != uid) {
        // This should not happen with per-account keys, but fail closed without
        // rewriting a stale queue snapshot over jobs enqueued concurrently.
        await _quarantineQueuedItem(
          prefs,
          uid,
          item,
          'Queue owner does not match the signed-in account.',
        );
        continue;
      }
      final recipient = item['recipient']?.toString() ?? '';
      if (recipient != peer) {
        await _quarantineQueuedItem(
          prefs,
          uid,
          item,
          'The queued upload targets a different account from the current paired recipient.',
        );
        continue;
      }
      final nextAttemptRaw = item['nextAttemptAt']?.toString();
      final nextAttempt = nextAttemptRaw == null ? null : DateTime.tryParse(nextAttemptRaw);
      if (nextAttempt != null && nextAttempt.isAfter(DateTime.now().toUtc())) continue;

      try {
        final path = item['path']?.toString() ?? '';
        if (path.isEmpty || !await File(path).exists()) {
          await _quarantineQueuedItem(prefs, uid, item, 'The durable local media file is missing.');
          continue;
        }
        final file = File(path);
        final fileSize = await file.length();
        if (fileSize <= 0 || fileSize > maxBytes) {
          await _quarantineQueuedItem(
            prefs,
            uid,
            item,
            'The file is empty or exceeds the 50 MB Storage limit ($fileSize bytes).',
          );
          continue;
        }
        final name = (item['originalName']?.toString().trim().isNotEmpty == true)
            ? item['originalName'].toString()
            : p.basename(path);
        final clientMessageId = item['id']?.toString();
        if (clientMessageId == null || clientMessageId.isEmpty) {
          await _quarantineQueuedItem(prefs, uid, item, 'The upload is missing its stable message ID.');
          continue;
        }

        // A previous request may have committed remotely while its response was
        // lost. Reconcile by the same idempotency key before uploading again.
        final existing = await client
            .from('messages')
            .select('id')
            .eq('sender_id', uid)
            .eq('client_message_id', clientMessageId)
            .maybeSingle();
        if (existing == null) {
          final ext = p.extension(name).replaceFirst('.', '').toLowerCase();
          final object = '$uid/$clientMessageId${ext.isEmpty ? '' : '.$ext'}';
          final metadata = await service.upload(file, objectPath: object, displayName: name);
          metadata['name'] = name;
          await client.rpc('likedin_send_message_v2', params: {
            'p_recipient_id': recipient,
            'p_payload': jsonEncode(metadata),
            'p_client_message_id': clientMessageId,
            'p_reply_to_message_id': item['replyToMessageId'],
          });
        }
        await _removeQueuedItem(prefs, uid, clientMessageId);
        try {
          await file.delete();
        } catch (_) {}
      } catch (error) {
        final attempts = (item['attempts'] as num?)?.toInt() ?? 0;
        final nextAttempts = attempts + 1;
        final exponent = min(nextAttempts - 1, 8).toInt();
        final delaySeconds = min(1800, 5 * (1 << exponent)).toInt();
        item['attempts'] = nextAttempts;
        item['nextAttemptAt'] = DateTime.now().toUtc()
            .add(Duration(seconds: delaySeconds))
            .toIso8601String();
        lastQueueError ??= error.toString();
        await _updateQueuedItem(prefs, uid, item);
      }
    }
    final remaining = _decodeQueue(prefs.getString(_queueKeyFor(uid)) ?? '[]');
    if (remaining.isEmpty) {
      lastQueueError = _quarantineError;
      return lastQuarantinedCount == 0;
    }
    return false;
  }

  Future<String> signedUrl(String objectPath) =>
      client.storage.from(bucket).createSignedUrl(objectPath, 900);

  Future<void> _validateMediaPath(String path) async {
    if (path.isEmpty ||
        (!path.startsWith('${client.auth.currentUser?.id ?? ''}/') &&
            !(await _isPeerPath(path)))) {
      throw StateError('This attachment is not accessible to your account.');
    }
  }

  Future<void> _evictMediaCache(Directory directory, {String? preservePath}) async {
    const maxBytes = 250 * 1024 * 1024;
    try {
      final files = await directory.list(followLinks: false).where((entity) => entity is File && !entity.path.endsWith('.part')).cast<File>().toList();
      var total = 0;
      final entries = <({File file, int size, DateTime touched})>[];
      for (final file in files) {
        final stat = await file.stat();
        total += stat.size;
        entries.add((file: file, size: stat.size, touched: stat.modified));
      }
      if (total <= maxBytes) return;
      entries.sort((a, b) => a.touched.compareTo(b.touched));
      for (final entry in entries) {
        if (entry.file.path == preservePath) continue;
        try { await entry.file.delete(); total -= entry.size; } catch (_) {}
        if (total <= maxBytes) break;
      }
    } catch (error) { debugPrint('Media cache eviction skipped: $error'); }
  }

  /// Removes every cached file for a Storage object path on this device.
  /// The message tombstone carries the path so both sender and recipient can
  /// clear their app-private copies after delete-for-everyone.
  /// Deletes an uploaded object through the Storage API (never by deleting
  /// storage.objects rows directly). RLS permits only the owning pair member.
  /// Repeating this operation is safe and lets tombstone reloads retry failures.
  Future<void> deleteRemotePath(String objectPath) async =>
      deleteRemotePaths([objectPath]);

  Future<void> deleteRemotePaths(Iterable<String> objectPaths) async {
    final uid = client.auth.currentUser?.id;
    final paths = objectPaths.toSet().where((path) => path.isNotEmpty).toList();
    if (paths.isEmpty) return;
    if (uid == null || paths.any((path) => !path.startsWith('$uid/'))) {
      throw StateError('Only the owner can delete these media objects.');
    }
    // Supabase Storage accepts a batch. This keeps a long history of deleted
    // attachments from causing one network request per tombstone at startup.
    await client.storage.from(bucket).remove(paths);
  }

  Future<void> deleteCachedPath(String objectPath) async {
    if (objectPath.isEmpty) return;
    final support = await getApplicationSupportDirectory();
    final cacheDir = Directory(p.join(support.path, 'LikedinMediaCache'));
    if (!await cacheDir.exists()) return;
    final key = base64Url.encode(utf8.encode(objectPath)).replaceAll('=', '');
    await for (final entity in cacheDir.list(followLinks: false)) {
      if (entity is! File) continue;
      final base = p.basename(entity.path);
      if (base == key || base.startsWith('$key.') || base.startsWith('$key.part')) {
        try { await entity.delete(); } catch (error) {
          debugPrint('Could not delete cached media file ${entity.path}: $error');
        }
      }
    }
  }

  Future<File> cachedFile(Map<String, dynamic> metadata, {void Function(double progress)? onProgress}) async {
    final path = metadata['path']?.toString() ?? '';
    if (path.isEmpty) throw StateError('This attachment is missing its storage path.');

    // Check the device-private cache first. This is essential for the sender:
    // the sender already owns the uploaded bytes and must not need a Storage
    // read permission check just to display its own outgoing attachment.
    final support = await getApplicationSupportDirectory();
    final cacheDir = Directory(p.join(support.path, 'LikedinMediaCache'));
    await cacheDir.create(recursive: true);
    final key = base64Url.encode(utf8.encode(path)).replaceAll('=', '');
    final ext = p.extension(metadata['name']?.toString() ?? '');
    final cached = File(p.join(cacheDir.path, '$key$ext'));
    await _evictMediaCache(cacheDir, preservePath: cached.path);

    // Prefer the exact metadata filename, but accept an existing path-keyed
    // cache entry with a different extension. This covers older uploads whose
    // display filename was normalized after the bytes were cached.
    File? cachedCandidate;
    if (await cached.exists() && await cached.length() > 0) {
      cachedCandidate = cached;
    } else {
      await for (final entity in cacheDir.list(followLinks: false)) {
        if (entity is! File || entity.path.endsWith('.part')) continue;
        final base = p.basename(entity.path);
        if (base == key || base.startsWith('$key.')) {
          if (await entity.length() > 0) {
            cachedCandidate = entity;
            break;
          }
        }
      }
    }
    if (cachedCandidate != null) {
      try { await cachedCandidate.setLastModified(DateTime.now()); } catch (_) {}
      onProgress?.call(1);
      return cachedCandidate;
    }
    if (await cached.exists()) await cached.delete();

    // Only a cache miss needs a Storage permission/ownership check and
    // download. Receiver devices normally take this path on first display.
    await _validateMediaPath(path);
    final temp = File('${cached.path}.part');
    if (await temp.exists()) await temp.delete();
    final httpClient = http.Client();
    IOSink? sink;
    try {
      final url = await signedUrl(path);
      final response = await httpClient.send(http.Request('GET', Uri.parse(url)));
      if (response.statusCode != 200) {
        throw HttpException('Attachment download failed (${response.statusCode}).');
      }
      sink = temp.openWrite();
      var received = 0;
      final total = response.contentLength ?? 0;
      await for (final chunk in response.stream) {
        sink.add(chunk);
        received += chunk.length;
        if (total > 0) onProgress?.call(received / total * 0.95);
      }
      await sink.flush();
      await sink.close();
      sink = null;
      if (await temp.length() <= 0) throw const HttpException('Downloaded attachment is empty.');
      if (await cached.exists()) await cached.delete();
      await temp.rename(cached.path);
      await _evictMediaCache(cacheDir, preservePath: cached.path);
      onProgress?.call(1);
      return cached;
    } catch (_) {
      if (sink != null) {
        try { await sink.close(); } catch (_) {}
      }
      if (await temp.exists()) {
        try { await temp.delete(); } catch (_) {}
      }
      rethrow;
    } finally {
      httpClient.close();
    }
  }

  Future<File> download(Map<String, dynamic> metadata, Directory destination, {void Function(double progress)? onProgress}) async {
    final cached = await cachedFile(metadata, onProgress: onProgress);
    await destination.create(recursive: true);
    final safe = (metadata['name']?.toString() ?? 'attachment').replaceAll(RegExp(r'[^A-Za-z0-9._ -]'), '_');
    final out = File(p.join(destination.path, '${_uuid.v4()}--$safe'));
    await cached.copy(out.path);
    return out;
  }

  Future<String> downloadToPublicDownloads(Map<String, dynamic> metadata) async {
    final cached = await cachedFile(metadata);
    final originalName = (metadata['name']?.toString() ?? 'attachment').replaceAll(RegExp(r'[^A-Za-z0-9._ -]'), '_');
    final safeName = originalName.isEmpty ? 'attachment' : originalName;
    final mime = metadata['mime']?.toString() ?? _normalizeMime(safeName);
    final tempDir = await getTemporaryDirectory();
    final temp = File(p.join(tempDir.path, 'likedin_download_${_uuid.v4()}'));
    await cached.copy(temp.path);
    try {
      return await const MethodChannel('com.example.likedin/downloads').invokeMethod<String>('saveToDownloads', {
            'sourcePath': temp.path,
            'displayName': safeName,
            'mimeType': mime,
          }) ??
          safeName;
    } finally {
      if (await temp.exists()) await temp.delete();
    }
  }

  Future<bool> _isPeerPath(String path) async {
    final parts = path.split('/');
    if (parts.length < 2) return false;
    final peer = await client.rpc('likedin_get_peer_id') as String?;
    return peer != null && parts.first == peer;
  }
}
