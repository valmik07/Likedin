import 'dart:async';
import 'dart:math' as math;
import 'dart:ui' show ImageFilter, TileMode;

import 'package:flutter/foundation.dart' show ValueListenable;
import 'package:flutter/material.dart';
import 'package:flutter/physics.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ---------------------------------------------------------------------------
// Likedin OriginOS 7 Design System
//
// Combines Vivo OriginOS 7's Light & Shadow Aesthetics with ultra-smooth
// low-RAM performance:
//  * 3 Translucent Glass Textures (+ Off):
//      - Real:    Crystal optical translucency, vivid specular rim, live blur
//                 on floating chrome (Origin Island, elastic dock, auth).
//      - Natural: Balanced clear glass sheen & crisp rim (zero blur cost —
//                 automatic default on 3 GB RAM / Android 11 phones).
//      - Soft:    Silky low-glare satin matte glass for calm night reading.
//      - Off:     Solid high-contrast flat surfaces.
//  * Fluid Motion (Spring Physics): True SpringSimulation elastic squish &
//    rebound on cards/buttons plus a stretchy liquid dock pill indicator.
//  * Dynamic Glow: Interactive contact glow & day/night ambient lighting shift.
//  * Glint Light Effect: Angle-responsive iridescent light beam driven by
//    Android's built-in accelerometer (zero third-party packages; auto-off on
//    3 GB RAM devices and when Reduce Motion is enabled).
// ---------------------------------------------------------------------------

/// Accent choices tuned separately for Dark and Light modes so every accent
/// maintains >= 4.5:1 WCAG contrast across all 7 app themes.
class LikedinAccent {
  const LikedinAccent({
    required this.name,
    required this.dark,
    required this.light,
    required this.gradientEnd,
  });

  final String name;
  final Color dark;
  final Color light;
  final Color gradientEnd;

  Color forBrightness(Brightness b) => b == Brightness.dark ? dark : light;
}

const List<LikedinAccent> likedinAccents = [
  LikedinAccent(
    name: 'Electric blue',
    dark: Color(0xFF6FA8FF),
    light: Color(0xFF0A5FD0),
    gradientEnd: Color(0xFF22D3EE),
  ),
  LikedinAccent(
    name: 'Cyan',
    dark: Color(0xFF3DD6F5),
    light: Color(0xFF006A82),
    gradientEnd: Color(0xFF5EEAD4),
  ),
  LikedinAccent(
    name: 'Violet',
    dark: Color(0xFFB39DFF),
    light: Color(0xFF5B3FD6),
    gradientEnd: Color(0xFF7DB8FF),
  ),
  LikedinAccent(
    name: 'Emerald',
    dark: Color(0xFF4FDBA5),
    light: Color(0xFF09704D),
    gradientEnd: Color(0xFF5EE1E8),
  ),
  LikedinAccent(
    name: 'Rose',
    dark: Color(0xFFFF8FB1),
    light: Color(0xFFC2255C),
    gradientEnd: Color(0xFFFFB08A),
  ),
  LikedinAccent(
    name: 'Sunset',
    dark: Color(0xFFFFB36B),
    light: Color(0xFFA84200),
    gradientEnd: Color(0xFFFF7A9E),
  ),
];

/// Unified app-wide OriginOS 7 theme preset adapting cleanly to Dark & Light.
class LikedinThemePreset {
  const LikedinThemePreset({
    required this.name,
    required this.defaultAccentIndex,
    required this.darkBgTop,
    required this.darkBgMid,
    required this.darkBgBottom,
    required this.darkOrb1,
    required this.darkOrb2,
    required this.darkOrb3,
    required this.darkSurface,
    required this.darkSurfaceRaised,
    required this.darkOutline,
    required this.lightBgTop,
    required this.lightBgMid,
    required this.lightBgBottom,
    required this.lightOrb1,
    required this.lightOrb2,
    required this.lightOrb3,
    required this.lightSurface,
    required this.lightSurfaceRaised,
    required this.lightOutline,
  });

  final String name;
  final int defaultAccentIndex;

  final Color darkBgTop;
  final Color darkBgMid;
  final Color darkBgBottom;
  final Color darkOrb1;
  final Color darkOrb2;
  final Color darkOrb3;
  final Color darkSurface;
  final Color darkSurfaceRaised;
  final Color darkOutline;

  final Color lightBgTop;
  final Color lightBgMid;
  final Color lightBgBottom;
  final Color lightOrb1;
  final Color lightOrb2;
  final Color lightOrb3;
  final Color lightSurface;
  final Color lightSurfaceRaised;
  final Color lightOutline;

  List<Color> previewColors(Brightness b) => b == Brightness.dark
      ? [darkBgTop, darkBgMid, darkBgBottom]
      : [lightBgTop, lightBgMid, lightBgBottom];

  Color primaryOrb(Brightness b) => b == Brightness.dark ? darkOrb1 : lightOrb1;
}

const List<LikedinThemePreset> likedinThemePresets = [
  LikedinThemePreset(
    name: 'Default',
    defaultAccentIndex: 0,
    darkBgTop: Color(0xFF0B1530),
    darkBgMid: Color(0xFF091126),
    darkBgBottom: Color(0xFF060B18),
    darkOrb1: Color(0xFF3B82F6),
    darkOrb2: Color(0xFF22D3EE),
    darkOrb3: Color(0xFF6366F1),
    darkSurface: Color(0xFF0E1830),
    darkSurfaceRaised: Color(0xFF16233F),
    darkOutline: Color(0xFF28385A),
    lightBgTop: Color(0xFFF7FAFF),
    lightBgMid: Color(0xFFEFF5FD),
    lightBgBottom: Color(0xFFEAF1FB),
    lightOrb1: Color(0xFF60A5FA),
    lightOrb2: Color(0xFF38BDF8),
    lightOrb3: Color(0xFF93C5FD),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFEBF1FA),
    lightOutline: Color(0xFFD3DEEE),
  ),
  LikedinThemePreset(
    name: 'Ocean',
    defaultAccentIndex: 1,
    darkBgTop: Color(0xFF0C2748),
    darkBgMid: Color(0xFF081B34),
    darkBgBottom: Color(0xFF051122),
    darkOrb1: Color(0xFF0EA5E9),
    darkOrb2: Color(0xFF2DD4BF),
    darkOrb3: Color(0xFF38BDF8),
    darkSurface: Color(0xFF0C1C34),
    darkSurfaceRaised: Color(0xFF132A4A),
    darkOutline: Color(0xFF21426B),
    lightBgTop: Color(0xFFF3F9FF),
    lightBgMid: Color(0xFFE8F4FF),
    lightBgBottom: Color(0xFFE0EFFF),
    lightOrb1: Color(0xFF38BDF8),
    lightOrb2: Color(0xFF5EEAD4),
    lightOrb3: Color(0xFF7DD3FC),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFE7F2FF),
    lightOutline: Color(0xFFC8E0F8),
  ),
  LikedinThemePreset(
    name: 'Rose',
    defaultAccentIndex: 4,
    darkBgTop: Color(0xFF321129),
    darkBgMid: Color(0xFF220C1E),
    darkBgBottom: Color(0xFF130712),
    darkOrb1: Color(0xFFF43F5E),
    darkOrb2: Color(0xFFEC4899),
    darkOrb3: Color(0xFFFB7185),
    darkSurface: Color(0xFF220E1E),
    darkSurfaceRaised: Color(0xFF31162B),
    darkOutline: Color(0xFF4E2445),
    lightBgTop: Color(0xFFFFF7FA),
    lightBgMid: Color(0xFFFEEEF4),
    lightBgBottom: Color(0xFFFCE7EF),
    lightOrb1: Color(0xFFF472B6),
    lightOrb2: Color(0xFFFDA4AF),
    lightOrb3: Color(0xFFF9A8D4),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFFCECF2),
    lightOutline: Color(0xFFF2CEDC),
  ),
  LikedinThemePreset(
    name: 'Emerald',
    defaultAccentIndex: 3,
    darkBgTop: Color(0xFF0B312A),
    darkBgMid: Color(0xFF08221D),
    darkBgBottom: Color(0xFF051412),
    darkOrb1: Color(0xFF10B981),
    darkOrb2: Color(0xFF14B8A6),
    darkOrb3: Color(0xFF34D399),
    darkSurface: Color(0xFF0B211E),
    darkSurfaceRaised: Color(0xFF12312C),
    darkOutline: Color(0xFF1F4C44),
    lightBgTop: Color(0xFFF3FDF9),
    lightBgMid: Color(0xFFE7FAF2),
    lightBgBottom: Color(0xFFDDF6EB),
    lightOrb1: Color(0xFF34D399),
    lightOrb2: Color(0xFF5EEAD4),
    lightOrb3: Color(0xFF6EE7B7),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFE7F7F0),
    lightOutline: Color(0xFFC4E7D8),
  ),
  LikedinThemePreset(
    name: 'Sunset',
    defaultAccentIndex: 5,
    darkBgTop: Color(0xFF351624),
    darkBgMid: Color(0xFF24101E),
    darkBgBottom: Color(0xFF140A16),
    darkOrb1: Color(0xFFFB923C),
    darkOrb2: Color(0xFFF43F5E),
    darkOrb3: Color(0xFFF59E0B),
    darkSurface: Color(0xFF24101C),
    darkSurfaceRaised: Color(0xFF331828),
    darkOutline: Color(0xFF52283E),
    lightBgTop: Color(0xFFFFF8F4),
    lightBgMid: Color(0xFFFEF1EA),
    lightBgBottom: Color(0xFFFDEBE0),
    lightOrb1: Color(0xFFFB923C),
    lightOrb2: Color(0xFFFDA4AF),
    lightOrb3: Color(0xFFFDBA74),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFFDEEE5),
    lightOutline: Color(0xFFF4D4C2),
  ),
  LikedinThemePreset(
    name: 'Lavender',
    defaultAccentIndex: 2,
    darkBgTop: Color(0xFF201846),
    darkBgMid: Color(0xFF151030),
    darkBgBottom: Color(0xFF0B081C),
    darkOrb1: Color(0xFF8B5CF6),
    darkOrb2: Color(0xFF60A5FA),
    darkOrb3: Color(0xFFC084FC),
    darkSurface: Color(0xFF161130),
    darkSurfaceRaised: Color(0xFF211A45),
    darkOutline: Color(0xFF392E6D),
    lightBgTop: Color(0xFFF8F6FF),
    lightBgMid: Color(0xFFF2EEFF),
    lightBgBottom: Color(0xFFECE7FF),
    lightOrb1: Color(0xFFA78BFA),
    lightOrb2: Color(0xFF93C5FD),
    lightOrb3: Color(0xFFC4B5FD),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFEFEBFF),
    lightOutline: Color(0xFFD6CEFA),
  ),
  LikedinThemePreset(
    name: 'Minimal',
    defaultAccentIndex: 0,
    darkBgTop: Color(0xFF141923),
    darkBgMid: Color(0xFF0D1119),
    darkBgBottom: Color(0xFF07090E),
    darkOrb1: Color(0xFF64748B),
    darkOrb2: Color(0xFF94A3B8),
    darkOrb3: Color(0xFF475569),
    darkSurface: Color(0xFF12161F),
    darkSurfaceRaised: Color(0xFF1B212E),
    darkOutline: Color(0xFF2E3749),
    lightBgTop: Color(0xFFFFFFFF),
    lightBgMid: Color(0xFFF7F9FC),
    lightBgBottom: Color(0xFFF0F4F9),
    lightOrb1: Color(0xFFCBD5E1),
    lightOrb2: Color(0xFF94A3B8),
    lightOrb3: Color(0xFFE2E8F0),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFEEF2F7),
    lightOutline: Color(0xFFD8E0EC),
  ),
];

/// OriginOS 7 glass material textures (+ Off for solid maximum contrast).
enum LikedinEffects {
  /// Crisp optical glass with live backdrop blur on floating chrome & specular rim.
  real,

  /// Balanced clear glass sheen & crisp rim with zero live blur GPU cost.
  natural,

  /// Silky matte satin low-glare glass for calm night optics (zero blur cost).
  soft,

  /// Solid flat surfaces for maximum speed and contrast.
  off,
}

/// Drives OriginOS 7's angle-responsive Glint Light sheen from Android's
/// native accelerometer EventChannel (`com.example.likedin/glint_tilt`).
class OriginGlintController {
  OriginGlintController._();

  static const EventChannel _channel =
      EventChannel('com.example.likedin/glint_tilt');

  /// Normalized device tilt offset in `[-1.0, 1.0]`.
  static final ValueNotifier<Offset> tilt = ValueNotifier<Offset>(Offset.zero);
  static StreamSubscription<dynamic>? _sub;

  static void sync() {
    final active = LikedinAppearance.glintEnabled.value &&
        !LikedinAppearance.reduceMotion.value &&
        LikedinAppearance.effects.value != LikedinEffects.off;
    if (!active) {
      stop();
      return;
    }
    if (_sub != null) return;
    try {
      _sub = _channel.receiveBroadcastStream().listen(
        (dynamic event) {
          if (event is List && event.length >= 2) {
            final dx = ((event[0] as num).toDouble()).clamp(-1.0, 1.0);
            final dy = ((event[1] as num).toDouble()).clamp(-1.0, 1.0);
            tilt.value = Offset(dx, dy);
          }
        },
        onError: (Object _) {
          // Non-Android / emulator / test environments gracefully stay static.
          stop();
        },
        cancelOnError: true,
      );
    } catch (_) {
      stop();
    }
  }

  static void stop() {
    _sub?.cancel();
    _sub = null;
    if (tilt.value != Offset.zero) {
      tilt.value = Offset.zero;
    }
  }
}

/// Persisted OriginOS 7 appearance preferences shared by every screen.
class LikedinAppearance {
  LikedinAppearance._();

  static const _themeKey = 'likedin_theme_preset_v2';
  static const _legacyChatWallpaperKey = 'likedin_chat_wallpaper_preset_v1';
  static const _accentKey = 'likedin_accent_index_v1';
  static const _effectsKeyV2 = 'likedin_origin_texture_v2';
  static const _legacyEffectsKey = 'likedin_effects_level_v1';
  static const _glintKey = 'likedin_origin_glint_v1';
  static const _motionKey = 'likedin_reduce_motion_v1';

  static final ValueNotifier<int> themeIndex = ValueNotifier<int>(0);
  static final ValueNotifier<int> accentIndex = ValueNotifier<int>(0);
  static final ValueNotifier<LikedinEffects> effects =
      ValueNotifier<LikedinEffects>(LikedinEffects.real);
  static final ValueNotifier<bool> glintEnabled = ValueNotifier<bool>(true);
  static final ValueNotifier<bool> reduceMotion = ValueNotifier<bool>(false);
  static bool isLowRamDevice = false;

  /// Rebuilds the MaterialApp when any appearance value changes.
  static final Listenable listenable = Listenable.merge([
    themeIndex,
    accentIndex,
    effects,
    glintEnabled,
    reduceMotion,
  ]);

  static LikedinThemePreset get theme =>
      likedinThemePresets[themeIndex.value.clamp(0, likedinThemePresets.length - 1).toInt()];

  static LikedinAccent get accent =>
      likedinAccents[accentIndex.value.clamp(0, likedinAccents.length - 1).toInt()];

  static String get textureLabel => switch (effects.value) {
        LikedinEffects.real => 'Real',
        LikedinEffects.natural => 'Natural',
        LikedinEffects.soft => 'Soft',
        LikedinEffects.off => 'Off',
      };

  static Future<void> load([
    SharedPreferences? preferences,
    bool lowRamDevice = false,
  ]) async {
    isLowRamDevice = lowRamDevice;
    try {
      final prefs = preferences ?? await SharedPreferences.getInstance();
      final savedTheme = prefs.getInt(_themeKey) ?? prefs.getInt(_legacyChatWallpaperKey) ?? 0;
      themeIndex.value = savedTheme.clamp(0, likedinThemePresets.length - 1).toInt();
      final a = prefs.getInt(_accentKey) ?? 0;
      accentIndex.value = a.clamp(0, likedinAccents.length - 1).toInt();

      final savedV2 = prefs.getInt(_effectsKeyV2);
      if (savedV2 != null) {
        effects.value = LikedinEffects.values[savedV2.clamp(0, LikedinEffects.values.length - 1).toInt()];
      } else {
        final legacy = prefs.getInt(_legacyEffectsKey);
        if (legacy != null) {
          effects.value = switch (legacy) {
            0 => lowRamDevice ? LikedinEffects.natural : LikedinEffects.real,
            1 => LikedinEffects.natural,
            _ => LikedinEffects.off,
          };
        } else {
          // Auto-select Real on 4+ GB devices and zero-blur Natural on 3 GB RAM phones.
          effects.value = lowRamDevice ? LikedinEffects.natural : LikedinEffects.real;
        }
      }

      reduceMotion.value = prefs.getBool(_motionKey) ?? false;
      final savedGlint = prefs.getBool(_glintKey);
      glintEnabled.value = savedGlint ?? !lowRamDevice;
      OriginGlintController.sync();
    } catch (_) {
      // Defaults are fine if preferences are unavailable.
    }
  }

  /// Sets the app-wide theme preset and optionally syncs its harmonious accent.
  static Future<void> setTheme(int index, {bool syncAccent = true}) async {
    final clamped = index.clamp(0, likedinThemePresets.length - 1).toInt();
    themeIndex.value = clamped;
    if (syncAccent) {
      final recommended = likedinThemePresets[clamped]
          .defaultAccentIndex
          .clamp(0, likedinAccents.length - 1)
          .toInt();
      accentIndex.value = recommended;
    }
    await _save((p) async {
      await p.setInt(_themeKey, clamped);
      if (syncAccent) await p.setInt(_accentKey, accentIndex.value);
    });
  }

  static Future<void> setAccent(int index) async {
    accentIndex.value = index.clamp(0, likedinAccents.length - 1).toInt();
    await _save((p) => p.setInt(_accentKey, accentIndex.value));
  }

  static Future<void> setEffects(LikedinEffects value) async {
    effects.value = value;
    OriginGlintController.sync();
    await _save((p) => p.setInt(_effectsKeyV2, value.index));
  }

  static Future<void> setGlintEnabled(bool value) async {
    glintEnabled.value = value;
    OriginGlintController.sync();
    await _save((p) => p.setBool(_glintKey, value));
  }

  static Future<void> setReduceMotion(bool value) async {
    reduceMotion.value = value;
    OriginGlintController.sync();
    await _save((p) => p.setBool(_motionKey, value));
  }

  static Future<void> reset() async {
    themeIndex.value = 0;
    accentIndex.value = 0;
    effects.value = isLowRamDevice ? LikedinEffects.natural : LikedinEffects.real;
    glintEnabled.value = !isLowRamDevice;
    reduceMotion.value = false;
    OriginGlintController.sync();
    await _save((p) async {
      await p.remove(_themeKey);
      await p.remove(_legacyChatWallpaperKey);
      await p.remove(_accentKey);
      await p.remove(_effectsKeyV2);
      await p.remove(_legacyEffectsKey);
      await p.remove(_glintKey);
      await p.remove(_motionKey);
    });
  }

  static Future<void> _save(Future<void> Function(SharedPreferences) write) async {
    try {
      await write(await SharedPreferences.getInstance());
    } catch (_) {}
  }

  /// True when animations should be skipped or shortened.
  static bool motionReduced(BuildContext context) =>
      reduceMotion.value || MediaQuery.of(context).disableAnimations;
}

// ---- Theme-aware Palette ---------------------------------------------------

Color likedinBackground(Brightness brightness) {
  final t = LikedinAppearance.theme;
  return brightness == Brightness.dark ? t.darkBgBottom : t.lightBgBottom;
}

Color likedinBackgroundTop(Brightness brightness) {
  final t = LikedinAppearance.theme;
  return brightness == Brightness.dark ? t.darkBgTop : t.lightBgTop;
}

Color likedinSurface(Brightness brightness) {
  final t = LikedinAppearance.theme;
  return brightness == Brightness.dark ? t.darkSurface : t.lightSurface;
}

Color likedinSurfaceRaised(Brightness brightness) {
  final t = LikedinAppearance.theme;
  return brightness == Brightness.dark ? t.darkSurfaceRaised : t.lightSurfaceRaised;
}

Color likedinOutline(Brightness brightness) {
  final t = LikedinAppearance.theme;
  return brightness == Brightness.dark ? t.darkOutline : t.lightOutline;
}

Color likedinOnSurface(Brightness brightness) => brightness == Brightness.dark
    ? const Color(0xFFEAF0FF)
    : const Color(0xFF0C1A33);

Color likedinMutedText(Brightness brightness) => brightness == Brightness.dark
    ? const Color(0xFFA8B5CF)
    : const Color(0xFF51617F);

Color likedinPrimary(Brightness brightness) =>
    LikedinAppearance.accent.forBrightness(brightness);

/// Darkens [color] just enough that white text on it reaches [minContrast].
Color likedinEnsureWhiteContrast(Color color, {double minContrast = 4.5}) {
  var result = color;
  for (var i = 0; i < 24; i++) {
    final ratio = 1.05 / (result.computeLuminance() + .05);
    if (ratio >= minContrast) return result;
    result = Color.lerp(result, const Color(0xFF000000), .06)!;
  }
  return result;
}

/// Primary accent gradient for action buttons.
LinearGradient likedinPrimaryGradient(Brightness brightness) {
  final accent = LikedinAppearance.accent;
  final dark = brightness == Brightness.dark;
  final start = likedinEnsureWhiteContrast(
    dark ? Color.lerp(accent.dark, const Color(0xFF1D4ED8), .35)! : accent.light,
  );
  final end = likedinEnsureWhiteContrast(
    dark ? accent.gradientEnd : Color.lerp(accent.light, accent.gradientEnd, .55)!,
  );
  return LinearGradient(
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
    colors: [start, end],
  );
}

/// Outgoing chat-bubble fill harmonized with the active theme and accent.
Color likedinOutgoingBubble(Brightness brightness) {
  final accent = likedinPrimary(brightness);
  return brightness == Brightness.dark
      ? Color.alphaBlend(accent.withValues(alpha: .30), likedinSurface(brightness))
      : Color.alphaBlend(accent.withValues(alpha: .16), Colors.white);
}

/// Incoming chat-bubble fill harmonized with the active theme.
Color likedinIncomingBubble(Brightness brightness) =>
    brightness == Brightness.dark
        ? likedinSurface(brightness).withValues(alpha: .58)
        : Colors.white.withValues(alpha: .78);

// ---- OriginOS 7 Glass Optical Painters (Real / Natural / Soft + Glint) -----

final Map<int, ImageFilter> _blurFilterCache = <int, ImageFilter>{};

ImageFilter _cachedBlurFilter(double sigma) {
  final key = (sigma * 10).round();
  return _blurFilterCache.putIfAbsent(
    key,
    () => ImageFilter.blur(
      sigmaX: key / 10.0,
      sigmaY: key / 10.0,
      tileMode: TileMode.mirror,
    ),
  );
}

/// Unified single-pass OriginOS 7 glass fill & optical reflection painter
/// rendered BEHIND the child widget.
///  - Soft mode is preserved verbatim (calm satin low-glare optics).
///  - Real mode paints the translucent glass body, an elliptical curved top
///    meniscus highlight, and a radial bottom caustic bounce in ONE GPU pass
///    (eliminating double ClipRRect / redundant DecoratedBox layers).
class _LiquidGlassFillPainter extends CustomPainter {
  const _LiquidGlassFillPainter({
    required this.radius,
    required this.baseColor,
    required this.dark,
    required this.accent,
    required this.accentEnd,
    required this.texture,
    required this.isFrosted,
  });

  final BorderRadius radius;
  final Color baseColor;
  final bool dark;
  final Color accent;
  final Color accentEnd;
  final LikedinEffects texture;
  final bool isFrosted;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final rect = Offset.zero & size;
    final rrect = radius.toRRect(rect);

    final isReal = texture == LikedinEffects.real;
    final isSoft = texture == LikedinEffects.soft;

    // 0. Translucent glass body fill
    canvas.drawRRect(rrect, Paint()..color = baseColor);

    canvas.save();
    canvas.clipRRect(rrect);

    final whiteZero = Colors.white.withValues(alpha: 0.0);

    if (isReal) {
      // 1. Curved elliptical top specular meniscus (authentic thick-glass reflection)
      final sheenHeight = math.min(size.height * 0.44, 48.0);
      final topSheenRect = Rect.fromLTWH(0, 0, size.width, sheenHeight);
      final double topAlpha = dark
          ? (isFrosted ? .20 : .13)
          : (isFrosted ? .62 : .48);
      final topPaint = Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          stops: const [0.0, 0.36, 1.0],
          colors: [
            Colors.white.withValues(alpha: topAlpha),
            Colors.white.withValues(alpha: topAlpha * 0.30),
            whiteZero,
          ],
        ).createShader(topSheenRect);
      canvas.drawRect(topSheenRect, topPaint);

      // Subtle curved lens catchlight arc near top-left
      final catchRect = Rect.fromLTWH(
        -size.width * 0.12,
        -sheenHeight * 0.65,
        size.width * 0.92,
        sheenHeight * 1.35,
      );
      final catchPaint = Paint()
        ..shader = RadialGradient(
          center: const Alignment(-0.35, -0.2),
          radius: 0.85,
          colors: [
            Colors.white.withValues(alpha: dark ? .11 : .30),
            whiteZero,
          ],
        ).createShader(catchRect);
      canvas.drawOval(catchRect, catchPaint);

      // 2. Bottom radial caustic light bounce tinted with active OriginOS 7 accent
      final bounceH = math.min(size.height * 0.34, 34.0);
      final causticRect = Rect.fromLTWH(
        0,
        size.height - bounceH,
        size.width,
        bounceH,
      );
      final causticColor = Color.lerp(accent, accentEnd, 0.35)!;
      final causticPaint = Paint()
        ..shader = RadialGradient(
          center: const Alignment(0.25, 1.25),
          radius: 1.15,
          colors: [
            causticColor.withValues(alpha: dark ? (isFrosted ? .20 : .13) : .11),
            causticColor.withValues(alpha: 0.0),
          ],
        ).createShader(causticRect);
      canvas.drawRect(causticRect, causticPaint);
    } else {
      // Natural & Soft (Soft kept 100% identical to v2.6.1!)
      final sheenHeight = math.min(size.height * 0.42, isSoft ? 32.0 : 44.0);
      final topSheenRect = Rect.fromLTWH(0, 0, size.width, sheenHeight);
      final double topAlpha = dark
          ? (isSoft ? .05 : .08)
          : (isSoft ? .24 : .34);
      final topSheenPaint = Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          stops: const [0.0, 0.45, 1.0],
          colors: [
            Colors.white.withValues(alpha: topAlpha),
            Colors.white.withValues(alpha: topAlpha * 0.34),
            whiteZero,
          ],
        ).createShader(topSheenRect);
      canvas.drawRect(topSheenRect, topSheenPaint);

      if (!isSoft) {
        final bounceHeight = math.min(size.height * 0.28, 28.0);
        final bottomBounceRect = Rect.fromLTWH(
          0,
          size.height - bounceHeight,
          size.width,
          bounceHeight,
        );
        final bouncePaint = Paint()
          ..shader = LinearGradient(
            begin: Alignment.bottomCenter,
            end: Alignment.topCenter,
            colors: [
              accent.withValues(alpha: dark ? .06 : .05),
              accent.withValues(alpha: 0.0),
            ],
          ).createShader(bottomBounceRect);
        canvas.drawRect(bottomBounceRect, bouncePaint);
      }
    }

    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _LiquidGlassFillPainter old) =>
      old.radius != radius ||
      old.baseColor != baseColor ||
      old.dark != dark ||
      old.accent != accent ||
      old.accentEnd != accentEnd ||
      old.texture != texture ||
      old.isFrosted != isFrosted;
}

/// Paints the directional OriginOS 7 perimeter rim.
///  - Soft mode is preserved verbatim.
///  - Real mode adds prismatic bevel dispersion + a razor-thin inner specular
///    bevel + zero-blur luminous glow contour (fast & richer than BlurStyle.outer!).
class _LiquidGlassRimPainter extends CustomPainter {
  const _LiquidGlassRimPainter({
    required this.radius,
    required this.dark,
    required this.accent,
    required this.accentEnd,
    required this.texture,
    required this.isFrosted,
    required this.glow,
  });

  final BorderRadius radius;
  final bool dark;
  final Color accent;
  final Color accentEnd;
  final LikedinEffects texture;
  final bool isFrosted;
  final bool glow;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final rect = Offset.zero & size;
    final rrect = radius.toRRect(rect);

    final isReal = texture == LikedinEffects.real;
    final isSoft = texture == LikedinEffects.soft;
    final strokeWidth = isReal ? 1.3 : (isSoft ? 0.9 : 1.05);
    final rimRRect = rrect.deflate(strokeWidth * 0.5);
    const topHighlight = Colors.white;
    final bottomRefraction = Color.lerp(Colors.white, accent, dark ? .45 : .28)!;

    if (isReal) {
      // Prismatic OriginOS 7 optical bevel rim
      final prismMid = Color.lerp(accent, accentEnd, 0.5)!;
      final rimPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = strokeWidth
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          stops: const [0.0, 0.22, 0.48, 0.74, 1.0],
          colors: dark
              ? [
                  topHighlight.withValues(alpha: isFrosted ? .68 : .48),
                  prismMid.withValues(alpha: isFrosted ? .26 : .18),
                  Colors.white.withValues(alpha: .07),
                  accent.withValues(alpha: .20),
                  bottomRefraction.withValues(alpha: isFrosted ? .46 : .34),
                ]
              : [
                  topHighlight.withValues(alpha: .98),
                  Colors.white.withValues(alpha: .65),
                  Color(0xFF0C1A33).withValues(alpha: .09),
                  prismMid.withValues(alpha: .24),
                  bottomRefraction.withValues(alpha: .84),
                ],
        ).createShader(rect);
      canvas.drawRRect(rimRRect, rimPaint);

      // Razor-thin inner top specular bevel line (gives thick-glass optical depth)
      final innerBevel = rrect.deflate(strokeWidth + 0.5);
      final innerPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.65
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          stops: const [0.0, 0.35, 1.0],
          colors: [
            Colors.white.withValues(alpha: dark ? (isFrosted ? .26 : .16) : .72),
            Colors.white.withValues(alpha: 0.0),
            Colors.white.withValues(alpha: 0.0),
          ],
        ).createShader(rect);
      canvas.drawRRect(innerBevel, innerPaint);

      // Zero-blur luminous accent aura for `glow: true` hero cards (replaces
      // expensive BlurStyle.outer Gaussian blur stalls during 120Hz scroll!)
      if (glow) {
        final auraPaint = Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.0
          ..shader = LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              accent.withValues(alpha: dark ? .24 : .16),
              accentEnd.withValues(alpha: dark ? .18 : .12),
            ],
          ).createShader(rect);
        canvas.drawRRect(rrect.deflate(1.0), auraPaint);
      }

      if (!dark) {
        final hairline = Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 0.6
          ..color = Color(0xFF0C1A33).withValues(alpha: .09);
        canvas.drawRRect(rrect.deflate(0.3), hairline);
      }
      return;
    }

    // Natural & Soft (Soft kept 100% identical to v2.6.1!)
    final rimPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        stops: const [0.0, 0.24, 0.50, 0.76, 1.0],
        colors: dark
            ? [
                topHighlight.withValues(alpha: isSoft ? .14 : .26),
                Colors.white.withValues(alpha: isSoft ? .06 : .10),
                Colors.white.withValues(alpha: .04),
                bottomRefraction.withValues(alpha: isSoft ? .05 : .09),
                bottomRefraction.withValues(alpha: isSoft ? .11 : .18),
              ]
            : [
                topHighlight.withValues(alpha: isSoft ? .65 : .84),
                Colors.white.withValues(alpha: isSoft ? .26 : .40),
                Color(0xFF0C1A33).withValues(alpha: .06),
                Colors.white.withValues(alpha: isSoft ? .24 : .36),
                bottomRefraction.withValues(alpha: isSoft ? .42 : .62),
              ],
      ).createShader(rect);
    canvas.drawRRect(rimRRect, rimPaint);

    if (!dark) {
      final hairline = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.6
        ..color = Color(0xFF0C1A33).withValues(alpha: .06);
      canvas.drawRRect(rrect.deflate(0.3), hairline);
    }
  }

  @override
  bool shouldRepaint(covariant _LiquidGlassRimPainter old) =>
      old.radius != radius ||
      old.dark != dark ||
      old.accent != accent ||
      old.accentEnd != accentEnd ||
      old.texture != texture ||
      old.isFrosted != isFrosted ||
      old.glow != glow;
}

/// Zero-rebuild angle-responsive OriginOS 7 dual-band prismatic Glint Light
/// painter driven directly via `CustomPainter(repaint: tiltListenable)` inside
/// an isolated RepaintBoundary.
class _OriginGlintPainter extends CustomPainter {
  _OriginGlintPainter({
    required this.radius,
    required this.tiltListenable,
    required this.dark,
    required this.accent,
    required this.accentEnd,
    required this.isReal,
  }) : super(repaint: tiltListenable);

  final BorderRadius radius;
  final ValueListenable<Offset> tiltListenable;
  final bool dark;
  final Color accent;
  final Color accentEnd;
  final bool isReal;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final rect = Offset.zero & size;
    final rrect = radius.toRRect(rect);
    final tilt = tiltListenable.value;

    final shiftX = tilt.dx * 0.95;
    final shiftY = tilt.dy * 0.55;
    final mult = isReal ? 1.18 : 0.85;
    final beam = Paint()
      ..shader = LinearGradient(
        begin: Alignment(-1.15 + shiftX, -1.0 + shiftY),
        end: Alignment(1.15 + shiftX, 1.0 + shiftY),
        stops: const [0.0, 0.30, 0.45, 0.54, 0.70, 1.0],
        colors: dark
            ? [
                accent.withValues(alpha: 0.0),
                accent.withValues(alpha: (.10 * mult).clamp(0.0, 1.0)),
                Colors.white.withValues(alpha: (.18 * mult).clamp(0.0, 1.0)),
                accentEnd.withValues(alpha: (.14 * mult).clamp(0.0, 1.0)),
                accent.withValues(alpha: (.06 * mult).clamp(0.0, 1.0)),
                accentEnd.withValues(alpha: 0.0),
              ]
            : [
                accent.withValues(alpha: 0.0),
                accent.withValues(alpha: (.09 * mult).clamp(0.0, 1.0)),
                Colors.white.withValues(alpha: (.44 * mult).clamp(0.0, 1.0)),
                accentEnd.withValues(alpha: (.13 * mult).clamp(0.0, 1.0)),
                accent.withValues(alpha: (.05 * mult).clamp(0.0, 1.0)),
                accentEnd.withValues(alpha: 0.0),
              ],
      ).createShader(rect);

    canvas.save();
    canvas.clipRRect(rrect);
    canvas.drawRect(rect, beam);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _OriginGlintPainter old) =>
      old.radius != radius ||
      old.tiltListenable != tiltListenable ||
      old.dark != dark ||
      old.accent != accent ||
      old.accentEnd != accentEnd ||
      old.isReal != isReal;
}

// ---- Surfaces --------------------------------------------------------------

/// OriginOS 7 Dynamic Translucent Glass surface supporting Real / Natural /
/// Soft / Off textures, adaptive light-and-shadow contrast, and optional
/// tilt-responsive [glint] iridescence on hero cards.
class GlassPanel extends StatelessWidget {
  const GlassPanel({
    required this.child,
    this.padding = EdgeInsets.zero,
    this.radius = const BorderRadius.all(Radius.circular(24)),
    this.blur = 0,
    this.tint,
    this.glow = false,
    this.frosted = false,
    this.glint = false,
    super.key,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final BorderRadius radius;
  final double blur;
  final Color? tint;
  final bool glow;
  final bool frosted;
  final bool glint;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    return ListenableBuilder(
      listenable: LikedinAppearance.listenable,
      child: Padding(padding: padding, child: child),
      builder: (context, builtChild) {
        final texture = LikedinAppearance.effects.value;
        final base = tint ?? likedinSurface(brightness);
        final fancy = texture != LikedinEffects.off;
        final isReal = texture == LikedinEffects.real;
        final isSoft = texture == LikedinEffects.soft;
        final primary = likedinPrimary(brightness);
        final endAccent = LikedinAppearance.accent.gradientEnd;

        // Soft alphas remain 100% untouched; Real is tuned for crisp optical clarity.
        final fillAlpha = switch (texture) {
          LikedinEffects.off => 1.0,
          LikedinEffects.real => frosted ? (dark ? .36 : .58) : (dark ? .52 : .76),
          LikedinEffects.natural => frosted ? (dark ? .62 : .78) : (dark ? .64 : .82),
          LikedinEffects.soft => frosted ? (dark ? .78 : .88) : (dark ? .76 : .88),
        };

        final baseColor = base.withValues(alpha: fillAlpha);

        Widget surface;
        if (!fancy) {
          surface = DecoratedBox(
            decoration: BoxDecoration(
              color: baseColor,
              borderRadius: radius,
              border: Border.all(color: likedinOutline(brightness), width: 1),
            ),
            child: builtChild,
          );
        } else {
          surface = CustomPaint(
            painter: _LiquidGlassFillPainter(
              radius: radius,
              baseColor: baseColor,
              dark: dark,
              accent: primary,
              accentEnd: endAccent,
              texture: texture,
              isFrosted: frosted,
            ),
            foregroundPainter: _LiquidGlassRimPainter(
              radius: radius,
              dark: dark,
              accent: primary,
              accentEnd: endAccent,
              texture: texture,
              isFrosted: frosted,
              glow: glow,
            ),
            child: builtChild,
          );
        }

        // Zero-rebuild Glint light beam isolated in its own RepaintBoundary.
        if (glint &&
            fancy &&
            !isSoft &&
            LikedinAppearance.glintEnabled.value &&
            !LikedinAppearance.reduceMotion.value) {
          surface = RepaintBoundary(
            child: CustomPaint(
              painter: _OriginGlintPainter(
                radius: radius,
                tiltListenable: OriginGlintController.tilt,
                dark: dark,
                accent: primary,
                accentEnd: endAccent,
                isReal: isReal,
              ),
              child: surface,
            ),
          );
        }

        if (frosted && isReal) {
          // Crisp optical glass blur (<= 6.0 on 4+ GB, <= 4.5 on 3 GB) using
          // cached ImageFilter + BackdropFilter.grouped so Impeller shares one
          // backdrop pass across floating chrome with minimal GPU fill cost.
          final maxSigma = LikedinAppearance.isLowRamDevice ? 4.5 : 6.0;
          final sigma = (blur <= 0 ? 5.5 : blur).clamp(0.0, maxSigma).toDouble();
          return RepaintBoundary(
            child: ClipRRect(
              borderRadius: radius,
              child: BackdropFilter.grouped(
                filter: _cachedBlurFilter(sigma),
                child: surface,
              ),
            ),
          );
        }

        if (radius == BorderRadius.zero) {
          return isReal ? RepaintBoundary(child: surface) : surface;
        }
        final clipped = ClipRRect(borderRadius: radius, child: surface);
        return isReal ? RepaintBoundary(child: clipped) : clipped;
      },
    );
  }
}

/// GPU-native single-draw-call OriginOS 7 chat bubble.
/// Zero ClipRRect, zero CustomPaint shaders — locked at 90/120fps on 3 GB RAM.
class LiquidGlassBubble extends StatelessWidget {
  const LiquidGlassBubble({
    required this.child,
    required this.outgoing,
    required this.borderRadius,
    this.margin = EdgeInsets.zero,
    this.padding = const EdgeInsets.fromLTRB(14, 10, 14, 8),
    this.maxWidth = 310,
    super.key,
  });

  final Widget child;
  final bool outgoing;
  final BorderRadius borderRadius;
  final EdgeInsetsGeometry margin;
  final EdgeInsetsGeometry padding;
  final double maxWidth;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    final texture = LikedinAppearance.effects.value;
    final fancy = texture != LikedinEffects.off;
    final isSoft = texture == LikedinEffects.soft;
    final primary = likedinPrimary(brightness);

    final baseFill = outgoing
        ? likedinOutgoingBubble(brightness)
        : (fancy ? likedinIncomingBubble(brightness) : likedinSurface(brightness));

    final sheenStrength = isSoft ? 0.45 : 1.0;
    final topTint = dark
        ? Color.alphaBlend(
            Colors.white.withValues(alpha: (outgoing ? .10 : .07) * sheenStrength),
            baseFill,
          )
        : Color.alphaBlend(
            Colors.white.withValues(alpha: (outgoing ? .32 : .52) * sheenStrength),
            baseFill,
          );

    final borderColor = !fancy
        ? (outgoing ? primary.withValues(alpha: .45) : likedinOutline(brightness))
        : outgoing
            ? primary.withValues(alpha: dark ? (isSoft ? .34 : .52) : (isSoft ? .26 : .38))
            : (dark
                ? Colors.white.withValues(alpha: isSoft ? .10 : .16)
                : Colors.white.withValues(alpha: isSoft ? .78 : .94));

    final double topAlpha = isSoft
        ? (dark ? (outgoing ? .90 : .80) : (outgoing ? .94 : .92))
        : (dark ? (outgoing ? .84 : .64) : (outgoing ? .90 : .86));
    final double botAlpha = isSoft
        ? (dark ? (outgoing ? .84 : .74) : (outgoing ? .90 : .88))
        : (dark ? (outgoing ? .76 : .54) : (outgoing ? .84 : .78));

    return Padding(
      padding: margin,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: maxWidth),
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: fancy ? null : baseFill,
            gradient: fancy
                ? LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      topTint.withValues(alpha: topAlpha),
                      baseFill.withValues(alpha: botAlpha),
                    ],
                  )
                : null,
            borderRadius: borderRadius,
            border: Border.all(color: borderColor, width: 1.0),
          ),
          child: Padding(padding: padding, child: child),
        ),
      ),
    );
  }
}

class _OriginAuroraPainter extends CustomPainter {
  const _OriginAuroraPainter({
    required this.bgColors,
    required this.showOrbs,
    required this.dark,
    required this.orb1,
    required this.orb2,
    required this.orb3,
    required this.orbMult,
  });

  final List<Color> bgColors;
  final bool showOrbs;
  final bool dark;
  final Color orb1;
  final Color orb2;
  final Color orb3;
  final double orbMult;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          stops: const [0.0, 0.52, 1.0],
          colors: bgColors,
        ).createShader(rect),
    );
    if (!showOrbs) return;

    final maxDim = math.max(size.width, size.height);
    void drawOrb(Alignment center, double radiusFactor, Color color, double alpha) {
      final c = center.alongSize(size);
      final r = maxDim * radiusFactor;
      canvas.drawCircle(
        c,
        r,
        Paint()
          ..shader = RadialGradient(
            colors: [
              color.withValues(alpha: alpha),
              color.withValues(alpha: 0.0),
            ],
          ).createShader(Rect.fromCircle(center: c, radius: r)),
      );
    }

    drawOrb(const Alignment(-0.82, -0.88), 0.68, orb1, (dark ? .34 : .26) * orbMult);
    drawOrb(const Alignment(0.92, 0.82), 0.64, orb2, (dark ? .26 : .22) * orbMult);
    drawOrb(const Alignment(0.78, -0.16), 0.52, orb3, (dark ? .20 : .16) * orbMult);
  }

  @override
  bool shouldRepaint(covariant _OriginAuroraPainter old) =>
      old.showOrbs != showOrbs ||
      old.dark != dark ||
      old.orb1 != orb1 ||
      old.orb2 != orb2 ||
      old.orb3 != orb3 ||
      old.orbMult != orbMult ||
      old.bgColors[0] != bgColors[0] ||
      old.bgColors[2] != bgColors[2];
}

/// Unified app-wide OriginOS 7 ambient backdrop with single-pass GPU-cached
/// aurora orbs and subtle day/night lighting modulation.
class AuroraBackdrop extends StatelessWidget {
  const AuroraBackdrop({required this.child, super.key});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    final hour = DateTime.now().hour;
    final isNightHour = hour < 6 || hour >= 20;
    final orbIntensity = isNightHour ? 0.84 : 1.0;

    return ListenableBuilder(
      listenable: LikedinAppearance.listenable,
      child: child,
      builder: (context, builtChild) {
        final texture = LikedinAppearance.effects.value;
        final theme = LikedinAppearance.theme;
        final orb1 = dark ? theme.darkOrb1 : theme.lightOrb1;
        final orb2 = dark ? theme.darkOrb2 : theme.lightOrb2;
        final orb3 = dark ? theme.darkOrb3 : theme.lightOrb3;
        final bgColors = dark
            ? [theme.darkBgTop, theme.darkBgMid, theme.darkBgBottom]
            : [theme.lightBgTop, theme.lightBgMid, theme.lightBgBottom];
        final showOrbs = texture == LikedinEffects.real || texture == LikedinEffects.natural;
        final orbMult = (texture == LikedinEffects.natural ? 0.82 : 1.0) * orbIntensity;

        return Stack(
          fit: StackFit.expand,
          children: [
            if (texture == LikedinEffects.off)
              ColoredBox(color: likedinBackground(brightness))
            else
              RepaintBoundary(
                child: CustomPaint(
                  isComplex: true,
                  willChange: false,
                  painter: _OriginAuroraPainter(
                    bgColors: bgColors,
                    showOrbs: showOrbs,
                    dark: dark,
                    orb1: orb1,
                    orb2: orb2,
                    orb3: orb3,
                    orbMult: orbMult,
                  ),
                ),
              ),
            if (builtChild != null) builtChild,
          ],
        );
      },
    );
  }
}

/// OriginOS 7 Fluid Motion spring press-and-rebound with subtle Dynamic Glow
/// touch highlight. Automatically becomes a no-op when Reduce Motion is active.
class LikedinPressScale extends StatefulWidget {
  const LikedinPressScale({
    required this.child,
    this.enabled = true,
    this.pressedScale = 0.955,
    this.glowRadius = const BorderRadius.all(Radius.circular(24)),
    super.key,
  });

  final Widget child;
  final bool enabled;
  final double pressedScale;
  final BorderRadius glowRadius;

  @override
  State<LikedinPressScale> createState() => _LikedinPressScaleState();
}

class _LikedinPressScaleState extends State<LikedinPressScale>
    with SingleTickerProviderStateMixin {
  late final AnimationController _spring = AnimationController.unbounded(
    vsync: this,
    value: 1.0,
  );
  Offset? _tapOffset;
  bool _pressed = false;

  static const SpringDescription _pressSpring = SpringDescription(
    mass: 1.0,
    stiffness: 520.0,
    damping: 30.0,
  );

  static const SpringDescription _releaseSpring = SpringDescription(
    mass: 1.0,
    stiffness: 380.0,
    damping: 20.0,
  );

  void _animateTo(double target, SpringDescription spring) {
    if (LikedinAppearance.reduceMotion.value) {
      _spring.value = target;
      return;
    }
    _spring.animateWith(
      SpringSimulation(spring, _spring.value, target, _spring.velocity),
    );
  }

  void _onDown(PointerDownEvent e) {
    if (!widget.enabled || LikedinAppearance.reduceMotion.value) return;
    _pressed = true;
    _tapOffset = e.localPosition;
    _animateTo(widget.pressedScale, _pressSpring);
    if (mounted) setState(() {});
  }

  void _onUp() {
    if (!_pressed) return;
    _pressed = false;
    _animateTo(1.0, _releaseSpring);
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _spring.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    final showGlow = _pressed &&
        _tapOffset != null &&
        LikedinAppearance.effects.value != LikedinEffects.off &&
        !LikedinAppearance.reduceMotion.value;
    final primary = likedinPrimary(brightness);

    // CRITICAL: Keep the widget tree depth above `child` strictly invariant
    // across pointer down/up! Conditionally wrapping `child` in a Stack during
    // onPointerDown unmounts & remounts descendant InkWell/GestureDetectors
    // mid-gesture, silently cancelling onTap. Using CustomPaint.foregroundPainter
    // updates the glow in-place on the same RenderObject with zero unmounting.
    return Listener(
      behavior: HitTestBehavior.translucent,
      onPointerDown: _onDown,
      onPointerUp: (_) => _onUp(),
      onPointerCancel: (_) => _onUp(),
      child: AnimatedBuilder(
        animation: _spring,
        child: widget.child,
        builder: (context, child) {
          final scale = _spring.value.clamp(0.88, 1.05).toDouble();
          return Transform.scale(
            scale: scale,
            child: CustomPaint(
              foregroundPainter: showGlow
                  ? _OriginDynamicGlowPainter(
                      center: _tapOffset!,
                      borderRadius: widget.glowRadius,
                      color: primary,
                      dark: dark,
                    )
                  : null,
              child: child,
            ),
          );
        },
      ),
    );
  }
}

class _OriginDynamicGlowPainter extends CustomPainter {
  const _OriginDynamicGlowPainter({
    required this.center,
    required this.borderRadius,
    required this.color,
    required this.dark,
  });

  final Offset center;
  final BorderRadius borderRadius;
  final Color color;
  final bool dark;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final rect = Offset.zero & size;
    final radius = math.max(size.width, size.height) * 0.72;
    final paint = Paint()
      ..shader = RadialGradient(
        colors: [
          (dark ? Colors.white : color).withValues(alpha: dark ? .16 : .14),
          color.withValues(alpha: dark ? .08 : .06),
          color.withValues(alpha: 0.0),
        ],
        stops: const [0.0, 0.48, 1.0],
      ).createShader(Rect.fromCircle(center: center, radius: radius));
    canvas.save();
    canvas.clipRRect(borderRadius.toRRect(rect));
    canvas.drawCircle(center, radius, paint);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _OriginDynamicGlowPainter old) =>
      old.center != center ||
      old.borderRadius != borderRadius ||
      old.color != color ||
      old.dark != dark;
}

/// OriginOS 7 elastic floating bottom dock with a gliding, spring-stretching
/// Liquid Glass pill indicator and Dynamic Glow halo.
class OriginDockItem {
  const OriginDockItem({
    required this.tab,
    required this.icon,
    required this.activeIcon,
    required this.label,
  });

  final int tab;
  final IconData icon;
  final IconData activeIcon;
  final String label;
}

class OriginFloatingDock extends StatefulWidget {
  const OriginFloatingDock({
    required this.items,
    required this.activeTab,
    required this.onSelect,
    super.key,
  });

  final List<OriginDockItem> items;
  final int activeTab;
  final ValueChanged<int> onSelect;

  @override
  State<OriginFloatingDock> createState() => _OriginFloatingDockState();
}

class _OriginFloatingDockState extends State<OriginFloatingDock>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pillCtrl = AnimationController.unbounded(
    vsync: this,
    value: _indexForTab(widget.activeTab).toDouble(),
  );

  static const SpringDescription _dockSpring = SpringDescription(
    mass: 1.0,
    stiffness: 340.0,
    damping: 24.0,
  );

  int _indexForTab(int tab) {
    final idx = widget.items.indexWhere((e) => e.tab == tab);
    return idx < 0 ? 0 : idx;
  }

  @override
  void didUpdateWidget(covariant OriginFloatingDock oldWidget) {
    super.didUpdateWidget(oldWidget);
    final target = _indexForTab(widget.activeTab).toDouble();
    final maxIdx = math.max(0, widget.items.length - 1).toDouble();
    if (_pillCtrl.value > maxIdx) {
      _pillCtrl.value = target;
      return;
    }
    if ((target - _pillCtrl.value).abs() > 0.001) {
      if (LikedinAppearance.reduceMotion.value) {
        _pillCtrl.value = target;
      } else {
        _pillCtrl.animateWith(
          SpringSimulation(_dockSpring, _pillCtrl.value, target, _pillCtrl.velocity),
        );
      }
    }
  }

  @override
  void dispose() {
    _pillCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    final primary = likedinPrimary(brightness);
    final mutedColor = dark ? const Color(0xFFD2DDF0) : const Color(0xFF475569);
    final count = widget.items.length;

    return SizedBox(
      height: 66,
      child: Stack(
        fit: StackFit.expand,
        children: [
          // Static glass backdrop shell in its own RepaintBoundary so elastic
          // spring animations in the foreground NEVER trigger blur recomputes!
          Positioned.fill(
            child: GlassPanel(
              radius: BorderRadius.circular(34),
              frosted: true,
              blur: 6,
              glow: true,
              child: const SizedBox.expand(),
            ),
          ),
          // Foreground interactive elastic pill & tab row
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 6),
            child: LayoutBuilder(
              builder: (context, constraints) {
                final slotWidth = count > 0 ? constraints.maxWidth / count : constraints.maxWidth;
                return RepaintBoundary(
                  child: Stack(
                    children: [
                      // Elastic gliding OriginOS 7 liquid capsule indicator
                      AnimatedBuilder(
                        animation: _pillCtrl,
                        builder: (context, _) {
                          final maxIdx = math.max(0, count - 1).toDouble();
                          final pos = _pillCtrl.value.clamp(0.0, maxIdx).toDouble();
                          final vel = (_pillCtrl.velocity.abs() / 18.0).clamp(0.0, 0.22).toDouble();
                          final pillW = (slotWidth * (1.0 + vel))
                              .clamp(slotWidth, constraints.maxWidth)
                              .toDouble();
                          final rawLeft = pos * slotWidth - (pillW - slotWidth) * 0.5;
                          final maxLeft = math.max(0.0, constraints.maxWidth - pillW);
                          final left = rawLeft.clamp(0.0, maxLeft).toDouble();
                          return Positioned(
                            left: left,
                            top: 0,
                            bottom: 0,
                            width: pillW,
                            child: IgnorePointer(
                              child: DecoratedBox(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(27),
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: dark
                                        ? [
                                            Colors.white.withValues(alpha: .24),
                                            primary.withValues(alpha: .26),
                                          ]
                                        : [
                                            Colors.white.withValues(alpha: .96),
                                            primary.withValues(alpha: .16),
                                          ],
                                  ),
                                  border: Border.all(
                                    color: dark
                                        ? Colors.white.withValues(alpha: .40)
                                        : Colors.white.withValues(alpha: .98),
                                    width: 1.0,
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                      // Dock tab buttons with micro-spring icon pop
                      Material(
                        type: MaterialType.transparency,
                        child: Row(
                          children: widget.items.map((item) {
                            final selected = widget.activeTab == item.tab;
                            return Expanded(
                              child: LikedinPressScale(
                                pressedScale: 0.90,
                                glowRadius: BorderRadius.circular(26),
                                child: InkWell(
                                  borderRadius: BorderRadius.circular(26),
                                  onTap: () {
                                    HapticFeedback.selectionClick();
                                    widget.onSelect(item.tab);
                                  },
                                  child: Center(
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        AnimatedScale(
                                          scale: selected ? 1.09 : 1.0,
                                          duration: LikedinAppearance.reduceMotion.value
                                              ? Duration.zero
                                              : const Duration(milliseconds: 220),
                                          curve: Curves.easeOutBack,
                                          child: Icon(
                                            selected ? item.activeIcon : item.icon,
                                            size: 22,
                                            color: selected ? primary : mutedColor,
                                          ),
                                        ),
                                        const SizedBox(height: 3),
                                        Text(
                                          item.label,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(
                                            fontSize: 11,
                                            fontWeight: selected ? FontWeight.w800 : FontWeight.w500,
                                            color: selected ? primary : mutedColor,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            );
                          }).toList(growable: false),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

/// Primary action button: OriginOS 7 gradient pill with specular top rim & spring press.
class GradientButton extends StatelessWidget {
  const GradientButton({
    required this.onPressed,
    required this.child,
    this.height = 52,
    super.key,
  });

  final VoidCallback? onPressed;
  final Widget child;
  final double height;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final enabled = onPressed != null;
    final radius = BorderRadius.circular(height);
    return LikedinPressScale(
      enabled: enabled,
      glowRadius: radius,
      child: Opacity(
        opacity: enabled ? 1 : .55,
        child: CustomPaint(
          foregroundPainter: _LiquidGlassRimPainter(
            radius: radius,
            dark: true,
            accent: likedinPrimary(brightness),
            accentEnd: LikedinAppearance.accent.gradientEnd,
            texture: LikedinAppearance.effects.value,
            isFrosted: false,
            glow: false,
          ),
          child: Material(
            color: Colors.transparent,
            child: Ink(
              height: height,
              decoration: BoxDecoration(
                gradient: likedinPrimaryGradient(brightness),
                borderRadius: radius,
              ),
              child: InkWell(
                onTap: onPressed,
                borderRadius: radius,
                child: Center(
                  child: DefaultTextStyle.merge(
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                    ),
                    child: IconTheme.merge(
                      data: const IconThemeData(color: Colors.white),
                      child: child,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
