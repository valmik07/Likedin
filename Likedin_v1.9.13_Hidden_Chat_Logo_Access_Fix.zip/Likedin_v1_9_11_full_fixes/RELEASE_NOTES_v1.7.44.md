# Likedin v1.7.44 — Notification test diagnostics

## Why this update exists
The previous Settings test showed the same generic permission message for multiple failure modes and reused the production message channel. This made it impossible to tell whether Android permission, plugin initialization, the production channel, or the platform notification call was responsible.

## Changes
- Test notification now uses a dedicated `likedin_diagnostics_v1` channel.
- The test channel is silent and high importance; it does not depend on the custom message/call sounds.
- The test refreshes Android's app-level notification permission state and requests permission if Android reports it as blocked.
- The app now displays the actual PlatformException code/message or other thrown error instead of blaming permission generically.
- An uninitialized local notification plugin is reported as a separate condition.
- Existing message, incoming-call, missed-call, media, and WebRTC paths are otherwise preserved.
- No SQL migration or Supabase Edge Function deployment is required for this diagnostic-only update.

## Test
1. Build/install v1.7.44 on the affected phone.
2. Open Settings → Notifications → Send test notification.
3. If it fails, copy the full error text shown in the snackbar or send a screenshot. The error now identifies the failing layer rather than assuming permission is disabled.
4. If the local test succeeds but remote notifications still fail, continue investigating FCM token registration, deployed Edge Functions, database triggers/webhooks, and device background restrictions separately.

## Verification
Source edits and ZIP integrity checked. Not compiled or device-tested in this environment because Flutter/Android build tooling is unavailable here.
