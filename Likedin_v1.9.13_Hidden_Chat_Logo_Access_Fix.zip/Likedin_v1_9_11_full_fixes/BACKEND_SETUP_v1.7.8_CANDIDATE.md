# Backend instructions — 1.7.8 candidate

1. Back up the Supabase database.
2. Inspect `public.messages` columns and currently applied migrations.
3. If the old `likedin_send_message` function or `encrypted_payload` column is
   missing, review and apply
   `supabase/migrations/202611130001_v178_legacy_messaging_compatibility.sql`.
4. Verify the RPC signature is
   `likedin_send_message(uuid, text, uuid)` and the client can load/send messages.
5. This migration does NOT encrypt message contents. The current client still
   transmits plaintext. Do not treat TLS as E2EE.
