# Voice-message upload fix (1.7.35)

The recorder creates `.m4a` audio using AAC-LC. The Android MIME resolver reports `audio/mp4`, which the existing private Supabase Storage bucket did not allow. This caused HTTP 415 when starting the resumable upload.

## Required action for an existing Supabase project
In Supabase Dashboard → SQL Editor, run the contents of:
`supabase/migrations/202611150002_allow_audio_mp4_voice_messages.sql`

This adds `audio/mp4` to the existing `likedin-media` bucket allow-list without removing the other allowed MIME types or changing bucket privacy and policies.

Then rebuild/install 1.7.35 and test:
1. Record a short voice message and release to send.
2. Confirm the upload succeeds.
3. Play the received voice message on the other phone.
4. Test a longer recording and a recording after app restart.

The source ZIP does not itself execute SQL against the user's Supabase project.
