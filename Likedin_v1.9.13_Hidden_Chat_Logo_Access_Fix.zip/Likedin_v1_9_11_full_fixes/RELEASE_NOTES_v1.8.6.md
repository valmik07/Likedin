# Likedin v1.8.6 (build 85) — Chat UI and Media Experience

## Chat composer
- Added a refreshed compact composer footer with a subtle top divider and elevation.
- Preserved the text field's focus after successful message sends and edits when the keyboard was already open.
- Restored focus after a failed send while preserving the unsent draft.

## Gallery, GIFs and stickers
- Added a dedicated Android media/gallery picker alongside the existing general file browser.
- Added a dedicated GIF file picker. GIF files continue through the existing private media upload queue and are rendered with Flutter's animated image decoder.
- Added a built-in sticker tray with one-tap emoji-style stickers, displayed at sticker scale in the conversation.

## Compatibility and scope
- Version updated to `1.8.6+85`.
- No database schema changes or new third-party dependencies.
- Existing Supabase messaging, private media storage, calls, notifications, retry queue, and security implementation retained.
- Compilation and two-device runtime tests remain required.
