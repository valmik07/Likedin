# Notification verification — 1.7.33

1. Deploy the included Supabase Edge Functions using the project's existing secret values. Ensure `LIKEDIN_PUSH_WEBHOOK_SECRET`, `SUPABASE_SERVICE_ROLE_KEY`, and `FIREBASE_SERVICE_ACCOUNT_JSON` are set in Supabase.
2. Confirm the message insert webhook invokes `send-message-push`; confirm incoming-call and missed-call database/webhook paths invoke their respective functions. A GitHub APK build does not deploy these functions or webhooks.
3. Install 1.7.33 on both devices, open Likedin, sign in, and confirm each device has a row in `public.likedin_push_tokens` for its signed-in user.
4. With recipient app open, send a message: confirm the foreground notification appears when the chat is not visible.
5. Swipe Likedin away from Recents (do not force-stop it), lock the screen, and send a message from the other phone. Confirm notification appears with the Likedin monochrome icon and opens the chat when tapped.
6. Repeat with battery saver enabled and after a longer idle period. Record device model, Android version, time, and whether delivery was delayed.
7. Test incoming and missed calls separately, both foreground and background.
8. In Android Settings, verify Likedin notifications are allowed and the `Likedin messages` channel is enabled.

Expected limitation: Android force-stop (Settings → Apps → Likedin → Force stop) prevents normal FCM delivery until the user manually launches the app again. OEM battery controls can also delay background work.
