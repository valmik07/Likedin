# Likedin security verification plan — v1.7.31

Run tests only against your own Supabase project and the two authorized phones. Keep a backup of the Supabase schema and never paste service-role keys, JWTs, passwords, private keys or full access tokens into chat or screenshots.

## 1. Build and static checks

From the repository root in GitHub Actions or a local Flutter environment:

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --release --split-per-abi
```

Expected: analyzer/tests pass and release APKs are produced. The repository currently uses the Android debug signing config for `release`; do not distribute that APK as a production release. Set up a private release keystore through CI secrets first.

## 2. Confirm the current E2EE limitation (important)

Send a unique harmless marker such as `LIKEDIN-PLAINTEXT-CHECK-20261115` from phone A to phone B. In Supabase SQL Editor, as project owner, run:

```sql
select id, sender_id, recipient_id, encrypted_payload
from public.messages
where encrypted_payload like '%LIKEDIN-PLAINTEXT-CHECK-20261115%'
order by created_at desc
limit 5;
```

Expected for the current build: the marker is visible in the database. This is a deliberate diagnostic proving that remote messages are not E2EE today. Delete the test message from the app afterward. Once E2EE is genuinely implemented, this query must return no plaintext marker; inspect only ciphertext metadata, never export private keys.

## 3. Two-account authorization tests

Use phone A and phone B as the two authorized accounts. If possible, create a separate disposable third test account only in a non-production Supabase project.

- A can send to B; B can receive and reply.
- A cannot read B-only private records except conversation rows intentionally shared with the pair.
- A cannot send a message with `sender_id` spoofed as B.
- A cannot read or mutate unrelated users' rows.
- A third authenticated account cannot read either account's messages, media or call signaling.
- A cannot upload an object into B's UUID folder.
- B can download A's shared object; unrelated account C receives an authorization failure.
- Confirm the media bucket remains `public=false` and `file_size_limit=52428800`.

Inspect active policies (do not infer them from migration files alone):

```sql
select schemaname, tablename, policyname, cmd, roles, qual, with_check
from pg_policies
where schemaname in ('public','storage')
order by schemaname, tablename, cmd, policyname;
```

## 4. Media access tests

- Upload an image smaller than 1 MB from A and download it on B.
- Upload a file near 49 MB; verify it is accepted. Verify a file above 50 MB is rejected cleanly.
- Try a disallowed MIME type in a test environment; verify rejection.
- Verify a signed URL expires and cannot be reused after expiry.
- Verify deleting an object from A's own folder works and deleting B's object fails.
- Confirm no public URL is generated or exposed.

## 5. Local data-at-rest tests

On a test device with USB debugging:

```bash
adb shell run-as com.example.likedin ls databases
```

Copy the database only from a debuggable test build and inspect it locally. Search for a harmless test message string. It should not appear in the SQLite database because the local message store uses AES-GCM ciphertext. This test covers only the local SQLite cache; it does not prove remote message E2EE.

Also test:
- Force-stop/reopen: local queued content remains readable in app.
- Invalid/corrupted local ciphertext: app fails safely; it must not display garbage or silently reset the key.
- App data clear/uninstall: document expected key/database loss. Do not assume uninstall backup recovers Keystore-protected secrets.

## 6. Backup codec tests

The current AES-GCM backup codec has unit tests for correct-passphrase round-trip and short-passphrase rejection. Add/run these before treating backup as shippable:
- Wrong passphrase is rejected.
- Flip one byte in ciphertext, MAC, nonce or salt: decrypt must fail.
- Truncate or malformed JSON envelope: reject with a controlled error.
- Unsupported version/KDF/iteration count: reject.
- Large archive limits and memory behavior are bounded.

There is no integrated full remote-history export/restore workflow in this build; do not treat the codec tests as proof of full backup functionality.

## 7. E2EE acceptance tests — only after protocol adapter integration

Do not mark E2EE complete until all pass on two independent Android devices:

1. Compare safety numbers/QR identity fingerprints in person.
2. Send unique messages in both directions; inspect Supabase and confirm no plaintext appears in any message field, Realtime payload, push notification or logs.
3. Modify one ciphertext byte; receiver rejects it without plaintext fallback.
4. Replay a prior ciphertext; it is rejected or safely deduplicated without ratchet rollback.
5. Deliver messages offline/out of order; ratchet state advances correctly and messages decrypt once.
6. Reinstall or rotate device identity; peer receives a visible identity-change warning and old session is not silently trusted.
7. Confirm private identity/prekey/ratchet material never appears in Supabase, SharedPreferences, diagnostics or plaintext backups.
8. Run official protocol test vectors and library tests for the exact pinned library version.

## 8. Video calling regression

- Test A→B and B→A video calls.
- Test camera/microphone permissions denied then granted.
- Test switching Wi-Fi/mobile network, app background/foreground and screen lock.
- Test call teardown followed immediately by a second call.
- Confirm no SDP/ICE credentials or tokens are logged or sent to unrelated users.

## Evidence to keep

Record app version, APK SHA-256, Git commit, test phone Android versions, pass/fail and sanitized logs. Never attach keystores, credentials, private key material, full signed URLs or personal message content.
