# v1.8.0 audit-to-release matrix

Legend: **Implemented in source** means a code/migration change is present, not that it has passed a live test. **Partial** means an explicit compatibility limitation remains. **Deferred** means not included in v1.8.0.

| Audit item | v1.8.0 disposition | Notes |
|---|---|---|
| A01 | Implemented in source | Confirmed users only consume slots; slot assignment runs on confirmation; >2 confirmed users fail safely. |
| A02 | Partial | Pair-member check and per-user rate limit added. Temporary Coturn REST mode is opt-in; current static TURN provider path remains default to protect calling. |
| A03 | Implemented in source; deployment check required | Server expiry function added; Supabase Cron must be enabled and the one-minute job verified. |
| A04 | Implemented in source | Per-account media queues; ownerless legacy queue entries are quarantined. |
| A05 | Implemented in source | Single-flight retry on authenticated startup, resume, and network restoration; foreground retry only. |
| A06 | Implemented in source | Voice note uses durable media outbox and stable message ID. |
| A07 | Implemented in source | ICE signal row IDs are deduplicated across snapshot/realtime paths. |
| A08 | Implemented in source | Shared idempotent call-failure cleanup attempts to persist terminal state. |
| A09 | Implemented in source | Call rejection is committed before best-effort signaling. |
| A10 | Implemented in source | Reuses pending text draft ID and reconciles existing message before retry. |
| A11 | Partial | Reaction query filtered to loaded message IDs; history pagination beyond 500 is deferred. |
| A12 | Deferred | Remote Storage object deletion after delete-for-everyone remains outstanding. |
| A13 | Implemented in source | HTTP 409 requires exact object lookup plus size and available MIME metadata verification. |
| A14 | Implemented in source | Firebase bootstrap retries background-handler registration after successful initialization. |
| A15 | Deferred | Local encrypted SQLite store remains disconnected from live chat path; no E2EE change is implied. |
| A16 | Deferred | Signaling-row retention/cleanup not included. |
| A17 | Implemented in source | Profile/peer, message, call, signaling, reaction, presence, receipts, push-token, media Storage and TURN entry points use pair membership checks. |
| A18 | Deferred | No generated `pubspec.lock`, strict analyzer gate, or expanded automated integration suite in this package. |
| A19 | Deferred | Stale-while-revalidate news fallback not included. |
| A20 | Deferred | XML parser and HTTPS-only story URL validation not included. |
| A21 | Implemented in source | Composer and service enforce the 10,000-character limit. |
| A22 | Deferred | Constant-time webhook secret comparison not included. |
| A23 | Deferred | Full documentation cleanup and project-neutral push webhook URLs not included. |
| A24 | Deferred | `com.example.likedin` kept unchanged to avoid breaking Firebase/package upgrade identity. |
| A25 | Deferred | Local debug-signing fallback not changed; the existing CI signing-secret gate remains. |
| A26 | Deferred | Play full-screen-intent declaration remains a pre-distribution compliance task. |

## Verification required

This workspace did not have Flutter/Dart/Deno/Gradle or a live Supabase connection available. No analyzer, test suite, migration execution, APK compilation, or device testing has been performed here. The source must pass GitHub Actions, the four SQL migrations must be applied in order, the Edge Function must be deployed, Cron must be verified, and device/network regression tests must pass before v1.8.0 is called validated.
