# Likedin v1.7.3.5 — Notification reliability fix

- FCM now sends both a visible notification payload and data payload. Android can display background notifications without depending on Dart background execution.
- Declares `likedin_messages_v1` as the Firebase default Android notification channel.
- Explicitly registers Flutter plugins in the Firebase background isolate.
- Background handler attempts local display before writing the delivery acknowledgement.
- Foreground handling remains local and suppresses alerts while the conversation is visible.

Important: the Supabase Edge Function source has changed and must be deployed separately. A GitHub APK build alone does not update the live Edge Function.
