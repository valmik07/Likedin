# Likedin 1.7.17 — Phase 3 media setup

1. Run the SQL migration shown in `supabase/migrations/202611140003_phase3_shared_media.sql` in Supabase SQL Editor.
2. Build with the existing GitHub Actions workflow. No workflow changes or new secrets are required.
3. Install on both phones and test JPG, MP4 and PDF sharing.

Videos are compressed locally (medium quality, 30 fps; original retained) before upload. Supabase Storage uploads use TUS resumable transfer in 5 MiB chunks. The upload URL and offset are maintained by Supabase; the app persists its pending queue and WorkManager retries queued sends when Android grants network-connected background execution. Android may defer background work under battery restrictions; it is not an instant-delivery guarantee.

Bucket `likedin-media` is private and capped at 25 MiB. Uploads are stored under the sender UUID. Only the two `account_slots` users can read objects; upload and delete are owner-scoped.
