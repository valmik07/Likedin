# Likedin v1.9.0 — In-app Gallery, Gboard Media and Low-memory Pass

Version: `1.9.0+89`

## Media features

- Adds a native in-app device gallery sheet with album selection, All/Photos/Videos filters, paginated thumbnails, multi-select (up to 10 items), and a send action.
- Uses `photo_manager` and `photo_manager_image_provider` for MediaStore asset access and thumbnail-only grid rendering.
- Adds Android keyboard rich-content insertion to the chat composer for GIF, PNG, JPEG, WebP, BMP and TIFF MIME types.
- Handles both keyboard-provided byte data and `content://` URIs. URI-based content is copied by a bounded native Android method channel into the app cache before using the existing media retry/upload pipeline.
- Gboard media size is limited to 8 MB to reduce memory spikes; existing app media uploads retain their existing 50 MB cap.
- No backend schema, SQL migration, Storage bucket, or Edge Function changes are required. GIFs continue through the existing `image/gif` media transport.

## Performance changes

- Limits Flutter's decoded image cache to 80 entries / 32 MB and clears it on Android memory-pressure callbacks.
- Defers creating Calls, Downloads and Preferences pages until the user first opens them; offscreen tabs have tickers disabled.
- Removes live BackdropFilter blur from GlassPanel. The restrained glass look remains through near-opaque tints and thin borders without the expensive blur pass.
- Stops rebuilding the full ChatPage on every keystroke. Composer-only UI now follows the TextEditingController listenable, while typing presence is debounced.
- Materializes the filtered chat message list once per build instead of repeatedly re-creating it inside ListView.builder itemBuilder; this removes avoidable repeated full-list filtering/allocations.
- Reduces inline image decode dimensions for lower-memory devices.

## Android compatibility

- App minimum SDK remains Android 11 / API 30.
- Adds the legacy `READ_EXTERNAL_STORAGE` permission through API 32 and Android 13+ `READ_MEDIA_IMAGES`, `READ_MEDIA_VIDEO`, plus the Android 14 selected-media permission.
- Permissions are requested by the gallery plugin only when the user opens the in-app Gallery.

## Important validation status

The source archive and workflow version check are aligned, and ZIP/YAML/static source checks were performed. This environment does not have Flutter or Dart installed, so `flutter pub get`, `flutter analyze`, `flutter test`, Kotlin/Gradle compilation, and an APK build have **not** been run here. GitHub Actions must complete those checks before installing this build.

## Device test checklist

1. Open a conversation, tap the plus button, then Gallery. Grant media access when asked.
2. Switch between All, Photos and Videos; change albums; select multiple assets; send an image, a GIF and a video.
3. Open Gboard's GIF panel while the message field is focused; tap a GIF. Confirm it arrives as an animated GIF in the conversation and on the other phone.
4. Repeat on Android 11 (Vivo Y12). Test with partial gallery permission on Android 14+ if applicable.
5. Scroll an older chat with many messages, type continuously, open and close tabs, and watch for dropped frames / memory pressure.
6. Verify normal text messages, replies, audio/video calls, notifications, media retry queue and Downloads are unchanged.

## Known caveat

Flutter's keyboard rich-content API transfers content through the platform-to-Dart channel before the app callback. The 8 MB cap protects the subsequent copy and upload, but a particularly large GIF may still cause a brief pause during the keyboard hand-off itself. Prefer smaller Gboard GIFs on 3 GB devices.
