# Likedin 1.7.34 test plan

1. Build through the existing GitHub Actions workflow; inspect dependency resolution and R8 output.
2. Install on both paired Android phones and sign in.
3. Send and receive JPG/PNG images and MP4 videos. Open each from chat and confirm it stays inside Likedin.
4. Open Documents from the bottom navigation. Confirm the shared list includes images, videos, audio and ordinary files from the conversation; tap images/videos to open in-app and save a file to Downloads.
5. Hold the microphone button, record a few seconds, release, and verify the voice message appears and plays on both phones.
6. Test microphone denial and retry after granting permission in Android settings.
7. Test a longer recording, interrupted upload, poor network, and recording cancellation/very short recording.
8. Re-test text messaging, replies, reactions, edits/deletes, media uploads/downloads, and audio/video calls.
9. Test push notifications with the deployed Supabase push functions, registered FCM tokens, app backgrounded, screen locked, and app swiped away. Test force-stop separately (Android blocks delivery until relaunch).
10. Confirm APK size from the actual CI artifact; do not assume the 50 MB target was met.
