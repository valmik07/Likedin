# Likedin 1.7.17 — Shared Media Reliability

- Adds local video compression while preserving originals.
- Uses Supabase Storage TUS resumable uploads in 5 MiB chunks.
- Persists pending media sends and schedules WorkManager network-constrained retries.
- Keeps the private media bucket and paired-account Storage policies.
- Existing message rows and chat RPC contract are reused.

Build and device testing have not been performed in this environment. Android may defer WorkManager tasks based on OS battery policy.
