# Likedin 1.7.20 — Call teardown hardening

Based on inspection of the supplied 1.7.19 source archive.

## Change in this revision
- Made call-resource teardown idempotent. A local hang-up and a remote `end`/`reject` signal can arrive close together; both now await the same cleanup future instead of concurrently closing the same WebRTC peer, media stream, and Realtime channel.
- Cleanup now detaches resource references before awaiting native close/dispose calls and tolerates individual teardown failures, so one failed native cleanup step does not prevent the remaining resources from being released.
- Made `close()` idempotent too, preventing duplicate renderer/stream-controller disposal when widget teardown follows an already-started call teardown.
- Bumped app version to 1.7.20+50.

## Existing 1.7.19 code inspected
The supplied archive already contains the foreground FCM incoming-call dispatch, remote `end`/`reject` cleanup, friendly WebRTC state mapping, deleted-message label guard, and deleted-original reply-preview text. Those paths were retained.

## Verification limits
- ZIP structure and CRC integrity are checked after packaging.
- Source-level assertions are checked for the new cleanup path.
- Flutter and Dart SDKs are not installed in this environment. `flutter analyze`, automated tests, and Android release compilation have NOT been run. Use the existing GitHub Actions workflow before installing this build.
