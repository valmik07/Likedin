# Likedin v1.7.3 — Chat Experience UI Preview

This package is based on v1.7.2.5 and prepares the chat interface for the requested message actions. See `README_V1_7_3_CHAT_UI.txt` for the exact implemented scope and backend limitations.

## Build
Use the existing GitHub Actions workflow for Flutter 3.47.9 / Java 17 / Android SDK 36. Build the ARM64 release APK for the two target phones.

## Important
This is a source update, not a verified APK. Flutter compilation and two-device tests have not been performed here. Several new message actions are UI-only previews until the Supabase backend phase is implemented.

## v1.7.3.2 local chat update

See `README_V1_7_3_CHAT_UI.txt` for implemented local-only chat actions and backend synchronization limitations. This source is based on the original v1.7.3 package; notification code and receipt logic are unchanged intentionally.

## v1.7.3.6
See `README_V1_7_3_6.txt` and `docs/INCOMING_CALL_PUSH_AND_PROXIMITY_v1.7.3.6.md` for incoming-call push setup, proximity behavior, Android limitations, and two-phone test plan.


## Likedin 1.7.10 backend migration

Before testing this build, apply `supabase/migrations/202611140001_v1710_client_sync_integration.sql` in Supabase SQL Editor. Earlier migrations are assumed already applied. No GitHub Actions workflow change is required. See `RELEASE_NOTES_v1.7.10.md`.

## Likedin 1.7.39 visual refresh
See `RELEASE_NOTES_v1.7.39.md`. The home screen is now a personalized daily briefing and intentionally contains no direct Chat, Call, or Files/Document shortcut. Chat and Calls remain in the overflow menu; Files remains in the profile menu. Existing backend and communication flows are unchanged.


## Likedin 1.7.45 reliability hardening

See `RELEASE_NOTES_v1.7.45.md` for the consolidated notification, chat, calling, media, Supabase, and build changes. Apply `supabase/migrations/202611170001_hardening_and_bootstrap_fixes.sql` only after reviewing it against the live project, and deploy the updated `send-missed-call-push` Edge Function. Configure persistent release signing as described in `SIGNING_SETUP_v1.7.45.md`.


## Likedin 1.7.46 daily briefing and backend parity

See `RELEASE_NOTES_v1.7.46.md` and `FIX_LIST_IMPLEMENTATION_MATRIX_v1.7.46.md`. The home briefing shows the five newest stories from the daily feed. Apply `supabase/migrations/202611170002_drop_duplicate_message_push_trigger.sql`; this is idempotent and removes only the unsafe legacy duplicate message push trigger.
