# Likedin 1.7.30 — Immersive Chat Layout

- Hides the global Likedin brand header while a conversation is open.
- Hides the Home/Preferences bottom navigation while a conversation is open.
- Adds a back-to-home control to the conversation header.
- Removes the persistent TLS/non-E2EE information banner from the chat viewport; security status remains available in settings.
- Preserves the existing message list, composer, media handling, storage logic, and call implementation.

Validation: source-level edits and ZIP integrity only. Flutter compilation and device testing have not been performed. Video-call layout remains untested and unchanged in this release.
