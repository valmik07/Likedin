# Likedin 1.7.35

## Voice-message upload compatibility
- Allows `audio/mp4` in the private `likedin-media` Supabase Storage bucket.
- The voice recorder already records AAC-LC in an M4A container; Android reports this container as `audio/mp4`.
- Adds a forward migration for existing Supabase projects: `supabase/migrations/202611150002_allow_audio_mp4_voice_messages.sql`.
- No audio transcoding or reduced recording quality is required.
- Existing app features and the GitHub Actions ARM64 release workflow are retained.

## Required backend step
Run the new migration in the Supabase SQL Editor before testing voice-message uploads on an already-deployed backend. The APK/source ZIP alone cannot change the remote bucket's allowed MIME types.

## Verification status
The ZIP structure is checked. Flutter compilation, GitHub Actions, Supabase migration execution, and physical-device voice upload/playback tests have not been run here.
