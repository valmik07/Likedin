# v1.9.6 Obsidian Glass / Arctic Glass frontend redesign (front end only)

Implements the "Likedin 15-Screen Frontend Design Specification". No backend,
migration, dependency, authentication, messaging, call, notification, encryption
or storage-policy change. Version strings are unchanged.

## Design system (`lib/ui/glassmorphism.dart`)
- Obsidian Glass (dark) and Arctic Glass (light) palettes.
- `GlassPanel`: translucent tonal fill + thin highlight border. Real backdrop blur is
  opt-in (`frosted: true`, blur capped at 12) and used only on the sign-in panel and the
  bottom navigation. Optional accent glow sits outside the clip so it is visible.
- `AuroraBackdrop`: layered gradient with two static light pools (no animation, no blur).
- `GradientButton`: blue-to-cyan primary action. Both gradient stops are auto-darkened so
  white labels always reach 4.5:1 contrast.
- Five accent colours (Electric blue, Cyan, Violet, Emerald, Rose), each tuned per theme.
- `LikedinAppearance`: persisted accent, effects level (Full / Lighter / Off) and reduce-motion.
  Changes re-theme the app live.

## Screens
1. Splash: theme-matched gradient, glass emblem, light sweep, name fade-in; 600 ms, skipped
   when Reduce motion is on. No artificial delay added to startup.
2. Sign in / create account: frosted glass panel, gradient primary action.
3. Home / conversations: new conversation row (avatar, online dot, latest message, time,
   unread badge) and a small compose button. Header has logo, settings shortcut, profile avatar.
4. Chat: outgoing bubbles use the accent; send button follows the accent. (Keyboard-stays-open,
   reply thumbnails, long-press menu etc. were already present and are untouched.)
8-9. Call screens: pulse halo now respects Reduce motion and the system "remove animations" setting.
11. Profile: new tab with large avatar over accent gradient, separate glass panels, shortcuts,
    distinct sign-out.
12. Settings: grouped as Account and profile, Appearance and themes, Notifications,
    Privacy and security, Media and storage, About Likedin.
13. Theme customization (new): live Obsidian/Arctic cards, accent swatches, chat-bubble preview,
    effects level, reduce motion, reset.
14. Storage and media (new): usage summary and category breakdown (images, videos, GIFs,
    stickers, documents, audio), cache vs saved media kept separate, confirmed cleanup that says
    what will be removed, upload-queue status with "Retry now".
- Navigation is now Chats, Calls, Media, Profile. Settings is reachable from the header and Profile.

## Not changed (already present or out of scope for a visual pass)
Attachment picker, GIF/sticker browser, media viewer, call history, incoming-call surface and
notifications keep their existing layouts; they inherit the new palette, panels and theme.
Settings has no "Chat preferences" or "Calls and audio" groups because the app has no such
options yet; they were not invented.

## Known limits
- Many icons still use the fixed brand blue (`brandBlue` is a `const`); accent choice affects
  the theme (buttons, switches, focus, navigation, progress), bubbles, gradients and swatches.
- Not compiled here (no Flutter SDK). Run `flutter pub get`, `flutter analyze`, `flutter test`
  (new `test/design_system_test.dart` enforces the contrast rules), then a device pass in both
  themes and all three effects levels, on a 3 GB Android 11 phone.
