# Likedin v1.7.43 — Sender media cache and notification diagnostics

## Source fixes
- Sender media rendering now checks the app-private cache before any Storage ownership/RLS validation. A sender can render the locally cached copy created during upload without needing to download its own upload again.
- Settings includes a local notification test and reports Android notification permission, Firebase Messaging initialization, and whether the current device token was saved to `public.likedin_push_tokens`.
- FCM token registration retries when a Supabase auth session is restored, signed in, or refreshed. A database token-save failure no longer incorrectly marks Firebase Messaging itself as uninitialized.
- About version label updated to 1.7.43.

## Backend wiring included
- Added `202611160002_message_push_trigger.sql`, which creates an `AFTER INSERT` trigger on `public.messages` and calls the existing `send-message-push` Edge Function using the existing Vault secret `LIKEDIN_PUSH_WEBHOOK_SECRET`.
- This removes the need to rely on a separately configured Dashboard Database Webhook for message inserts.

## Required deployment steps
1. Build/install v1.7.43 on both phones.
2. Deploy the current message and missed-call Edge Functions (these contain visible FCM notification payloads):
   ```bash
   supabase functions deploy send-message-push --no-verify-jwt
   supabase functions deploy send-missed-call-push --no-verify-jwt
   ```
3. In Supabase SQL Editor, run `supabase/migrations/202611160002_message_push_trigger.sql` once.
4. Before applying the migration, check whether a Supabase Dashboard Database Webhook named `likedin-message-push` (or equivalent) already targets `send-message-push`. If it exists, disable that webhook after enabling the SQL trigger, otherwise the same message could generate duplicate notifications.
5. Confirm the existing secrets still exist in Supabase:
   - `LIKEDIN_PUSH_WEBHOOK_SECRET` (also present in Vault with the same value)
   - `FIREBASE_SERVICE_ACCOUNT_JSON`
   - `SUPABASE_SERVICE_ROLE_KEY` (automatically available to Edge Functions)

## Device checks
1. Open Settings > Notifications on each phone.
2. Verify Android permission says Allowed, Firebase Messaging says Initialized, and This phone registered says Yes.
3. Tap Send test notification. This only tests local Android notification posting.
4. Send a new chat message from the other phone while this phone is backgrounded.
5. Test incoming and missed calls independently.
6. If local test works but remote push does not, check Supabase function logs and the SQL trigger/`net` request. If local test does not appear, fix Android notification permission/channel settings first.

## Diagnostic SQL
Run this read-only query to see whether both accounts have registered device tokens (it does not reveal tokens):
```sql
select user_id, count(*) as registered_devices, max(updated_at) as last_registered
from public.likedin_push_tokens
group by user_id
order by last_registered desc;
```

Run this read-only query to inspect message-table triggers:
```sql
select tgname, pg_get_triggerdef(oid)
from pg_trigger
where tgrelid = 'public.messages'::regclass
  and not tgisinternal;
```

## Important
- No new secrets are required and no service-role key belongs in the APK.
- No changes to video/audio call transport.
- No SQL changes to media storage policies.
- This archive has not been compiled or device-tested in this environment.
