# Likedin v1.7.46 — Daily briefing and backend parity

## Changes from v1.7.45

- The home briefing now shows the five newest stories from the current daily feed. It no longer holds the visible five-story selection on a three-day rotation.
- Added an idempotent Supabase migration to remove the unsafe legacy `likedin-message-push` trigger discovered during inspection of the live project. The safe `likedin_message_push` trigger remains in place and calls `likedin_notify_message_push()`.
- Bumped the app version to `1.7.46+76`.

## Relationship to the v1.7.44 PDF fix list

The v1.7.45 source already contains the implementations for the PDF's notification, chat, call, media, Supabase, signing, and housekeeping items. The live database inspection in this conversation confirmed that the duplicate message trigger existed alongside the safe trigger; it was removed manually, and this release adds the same cleanup to the migration history for reproducibility.

## Deployment

1. Apply `supabase/migrations/202611170002_drop_duplicate_message_push_trigger.sql` in Supabase SQL Editor. The live trigger was already removed manually, so this should be a harmless no-op there.
2. Build the ARM64 release APK through the existing GitHub Actions workflow.
3. The workflow requires all four persistent signing secrets documented in `SIGNING_SETUP_v1.7.45.md`. If they are not configured, the workflow intentionally stops before building.

No new Edge Function deployment is required by these v1.7.46 source changes. Keep the existing `send-message-push`, `send-incoming-call-push`, and `send-missed-call-push` deployments.

## Verification limits

- ZIP integrity and targeted source checks can be performed here.
- Flutter/Dart/Gradle toolchains are not available in this environment; no analyzer run, unit/widget test, APK build, or device test has been completed.
- The live backend trigger state was inspected in the conversation. The new cleanup migration has not been executed by the user yet.
