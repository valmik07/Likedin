# Likedin v1.9.8+94 — profile photo viewing, square crop and lower-memory JPEG handling

This release builds on v1.9.7+93. Existing chat, media, calls, notifications,
privacy, backup, storage, theme, gallery and Gboard functionality is retained.
No Supabase schema migration, Storage bucket-policy change or new dependency is
introduced.

## Other person's profile photo
- Tapping the other person's avatar in the chat header opens the full-screen,
  zoomable profile-photo viewer.
- Tapping the other person's avatar in the Home conversation card opens the same
  viewer.
- The viewer continues to use signed URLs for the existing private
  `likedin-media` bucket.

## Profile-photo edit and crop
- A dedicated edit screen appears before any profile-photo upload.
- The editor enforces a 1:1 square crop with pan, pinch zoom and reset.
- The final avatar is a 1024 x 1024 JPEG at quality 88.
- Decoding, resize and encoding run in worker isolates.
- JPEGs up to 50 megapixels can be previewed using JPEG decoder DCT down-sampling
  (1/2, 1/4 or 1/8 scale) rather than allocating a full-resolution bitmap. The
  selected source file is capped at 15 MB.
- PNG and WebP remain supported with a conservative 16 megapixel decoded-pixel
  limit to protect lower-memory Android devices.
- Animated formats and HEIC/HEIF are not offered as profile-photo sources; only
  JPG/JPEG, PNG and WebP are accepted by the picker.
- Existing private Storage bucket and `likedin_set_profile_avatar` RPC are used.
  Previous avatar cleanup still happens only after the new upload and profile
  path update succeed.

## Smoothness and memory preservation
- Retains the prior bounded avatar decoding, RepaintBoundary isolation,
  thumbnail sizing, global image-cache budget and memory-pressure cleanup.
- Avoids synchronous filesystem checks from profile-avatar widget builds.
- The cropper's JPEG preview uses decoder-level sampling to avoid loading a
  50 MP camera image as a full RGBA bitmap on 3 GB devices.
- No existing app tab, backend feature, chat feature, call feature, storage
  feature, gallery feature, keyboard media feature or privacy control is removed.

## Validation
- ZIP integrity, single pubspec, version parity, YAML syntax and workflow shell
  script syntax are checked before handoff.
- Flutter analyze, tests, Android Gradle compilation and physical-device
  performance measurements still need to run in GitHub Actions/on devices; the
  local environment used to prepare this archive does not contain Flutter SDK.
