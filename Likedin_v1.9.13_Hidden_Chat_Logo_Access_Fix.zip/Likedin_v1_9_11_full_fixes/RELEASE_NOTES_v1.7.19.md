# Likedin 1.7.19 — Incoming Call and Call Cleanup Fix

Changes based on inspection of the supplied 1.7.18 source archive:

- Foreground incoming-call FCM data messages now dispatch into the existing incoming-call route instead of being ignored. The existing Realtime subscription remains as a parallel delivery path.
- Remote `end` and `reject` signals now dispose the active peer connection, media tracks, renderers, and call Realtime channel before publishing the terminal state. This targets the consecutive-call lockup.
- WebRTC peer connection states are normalized to friendly app states instead of exposing enum names such as `RTCPeerConnectionStateConnected`.
- Reply previews now show `This message was deleted` when their referenced message has been deleted.
- Deleted messages no longer display the misleading `Edited` label.
- Version bumped to 1.7.19+49.

## Verification

- Source ZIP integrity checked.
- Changes reviewed against the supplied 1.7.18 files.
- Flutter/Dart SDK is not available in this execution environment, so `flutter analyze`, tests, and Android release compilation were not run. Build and test through the existing GitHub Actions workflow before installing.
