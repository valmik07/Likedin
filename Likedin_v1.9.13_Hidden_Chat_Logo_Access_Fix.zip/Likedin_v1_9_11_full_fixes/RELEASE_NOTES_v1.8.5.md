# Likedin v1.8.5 (build 84) — Full Bug Remediation & Modernization Release

## Critical & High-Severity Fixes (B1–B12)
- **B1 (`AndroidManifest.xml`, `MainActivity.kt`)**: Added `android:showWhenLocked="true"` and `android:turnScreenOn="true"` plus runtime `setShowWhenLocked(true)` / `setTurnScreenOn(true)` so full-screen incoming call notifications wake and display over the lock screen on Android 11+.
- **B2 (`likedin_call.wav`, `notification_service.dart`)**: Replaced the 0.39-second single-beep WAV with a 3.2-second dual-burst ringtone and enabled `FLAG_INSISTENT` (`additionalFlags: [4]`), `ongoing: true`, and `AudioAttributesUsage.notificationRingtone` for incoming call notifications.
- **B3 (`call_service.dart`)**: Added `_applyingRemoteAnswer` mutual exclusion and recorded `signal:$signalId` in `_seenIceSignalIds` inside `_listen()` so Realtime and 4-second catch-up polling never call `setRemoteDescription(answer)` concurrently.
- **B4 (`lib/main.dart`)**: Wrapped `_LiveCallDialog` in a `PopScope(canPop: false)` that awaits `call.end()` before closing, preventing system Back gestures from leaving the peer's phone ringing.
- **B5 (`lib/main.dart`)**: Centralized tab switching in `_AppShellState._switchTab()` so leaving `ChatPage` immediately triggers `_recoverIncomingCalls()`, and guarded `_joinChatIncomingCall()` with `_globalCallDialogActive`.
- **B6 (`CallForegroundService.kt`)**: Wrapped `startForeground(...)` in `try/catch` calling `stopSelf()` on failure so Android 14+ (`compileSdk = 36`) never crashes the app if foreground promotion is denied.
- **B7 (`202611220001_v185_call_failure_push_and_media_index.sql`, `send-missed-call-push/index.ts`)**: Added `'failed'` to the `likedin_missed_call_push` trigger and Edge Function so calls that fail during ringing immediately cancel/replace the callee's lock-screen notification.
- **B8 (`lib/main.dart`)**: Added a live `LinearProgressIndicator` and spinner state when `uploading == true`, and deleted temporary compressed videos created by `SharedMediaService.prepare()` in a `finally` block after queueing.
- **B9 (`lib/main.dart`)**: Replaced per-row `VideoPlayerController` instantiation in `_ChatVideoPreview` with a lightweight zero-decoder poster card so multiple downloaded videos in chat never exhaust hardware `MediaCodec` decoders on 3 GB RAM devices.
- **B10 (`android/app/build.gradle.kts`, `android/gradle.properties`)**: Preserved the validated Flutter 3.47.9 + AGP 9.1.0 Gradle plugin template configuration.
- **B11 (`lib/main.dart`, `realtime_messaging_service.dart`)**: Restored the signed-in user's own profile photo from `profiles.avatar_path` in private Storage whenever local preferences or cached files are missing after reinstall or device switch, and cleaned up orphaned local files on upload failure.
- **B12 (`lib/main.dart`)**: Added `ValueKey` to `_VoiceMessagePlayer`, added a shared static `_activePlayer` coordinator to prevent overlapping voice playback, and added `1x / 1.5x / 2x` playback speed control.

## Medium & Small Fixes & Modernizations (S1–S13)
- **S1 (`_IncomingCallDialog`)**: Added `Stopwatch` and 1-second `Timer.periodic` duration counter (`MM:SS`) triggered only when WebRTC ICE reaches `'connected'`.
- **S2 (`call_service.dart`, `MainActivity.kt`)**: Preserved user-toggled speakerphone state across `_createPeer()` and set `AudioManager.MODE_IN_COMMUNICATION` before playing outgoing ringback tone.
- **S3 (`FilesPage`)**: Server-filtered shared media queries using `.like('encrypted_payload', '%"__likedin_media_v1":true%')`, bounded pagination, and respected local hidden/cleared message filters.
- **S4 (`lib/main.dart`)**: Synchronized `likedinVersion` (`'1.8.5+84'`) with `pubspec.yaml`.
- **S5 (`_ChatMediaMessage`)**: Adopted `super.key` to satisfy `use_super_parameters` under `flutter_lints: ^5.0.0`.
- **S6 (`_ChatPageState`)**: Broadcast `sendTyping(false)` when saving or cancelling message edits.
- **S7 (`realtime_messaging_service.dart`, `lib/main.dart`)**: Loaded per-user reaction maps (`loadDetailedReactions`), displayed reaction counts (`❤️ 2`), highlighted the user's own reactions, and added single-tap reaction toggling.
- **S8 (`_clearChatForMe`)**: Added offline fallback to `DateTime.now().toUtc().millisecondsSinceEpoch` when `likedin_server_now` is unreachable.
- **S9 (`HomePage`)**: Preserved partial RSS feed successes when individual feeds time out and added full decimal/hex XML character entity decoding (`&#8217;`, `&#x2019;`, `&ndash;`, `&mdash;`).
- **S10 (`ChatPage`)**: Wrapped message rows in `RepaintBoundary`, animated new messages once (`_animatedMessageIds`), added floating calendar-day headers (*Today*, *Yesterday*, *17 Nov 2026*), and added a **Copy text** action.
- **S11 (`_LikedinVideoViewer`)**: Added `VideoProgressIndicator` scrubbing, `MM:SS / MM:SS` position/duration labels, and automatic pause on app backgrounding (`WidgetsBindingObserver`).
- **S12 (`notification_service.dart`)**: Disabled automatic token refresh (`autoRefreshToken: false`) inside `likedinFirebaseBackgroundHandler` to prevent background/foreground refresh token races.
- **S13 (`SettingsPage`)**: Wired `EncryptedBackupCodec` to an interactive **Export encrypted backup** card in Preferences.
