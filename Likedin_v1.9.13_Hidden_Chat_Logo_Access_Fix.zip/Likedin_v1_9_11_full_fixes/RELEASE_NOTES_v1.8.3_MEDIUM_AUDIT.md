# Likedin v1.8.3+80 — Medium and Small Reliability Audit

## Corrected in this candidate

### Chat, presence, and composer
- Peer presence is refreshed periodically and is derived from a fresh `last_seen_at` value; stale status now falls back to offline.
- Incoming typing state expires locally after five seconds when a stop-typing event is missed.
- Peer lookup retries while the chat is open, including when the initial RPC returns null or throws.
- Secure local chat-state reads are guarded so an Android Keystore/decryption issue does not abort the chat screen.
- Message length is now defined once as 10,000 Unicode code points: Dart `String.runes` on the client and PostgreSQL `char_length` in send/edit RPCs.
- Upload progress is independent from text-message saving. Text can be sent while a file upload/retry is in progress.

### Signup and account-slot integrity
- An unconfirmed signup reserves one of the two account slots, but it is not an approved pair member until email/phone confirmation.
- Signup preflight checks for a free slot and runs stale-signup cleanup; a generic GoTrue database error is rechecked against slot availability before being labeled pair-full.
- Unconfirmed reservations expire after 48 hours; the cleanup function is callable by `service_role` and is scheduled hourly when `pg_cron` is enabled.
- Existing confirmed accounts are backfilled into slots. The migration stops with an explicit reconciliation error if it finds more than two confirmed users instead of silently choosing accounts.
- Email confirmation uses the configured `com.example.likedin://login-callback/` redirect.

### Calls
- An incoming call whose renderer initialization or accept path fails is committed as rejected where possible, reject signaling is best-effort, and the dialog becomes terminal rather than allowing a broken second Accept attempt.
- Connection/setup failures are persisted as the distinct `failed` call status instead of storing `ended` while only the local UI reports `failed`.
- The previously patched call connection-state, answer/ICE catch-up, busy-dialog guard, STUN fallback, and system Back handling are retained.

### Media and cache
- Videos and voice notes no longer automatically download their full media file just because a message enters the viewport; the recipient taps to download/play.
- Delete-for-everyone stores the media object path in the tombstone. Both devices purge their local cached copies, including historical tombstones reconciled on startup/resume; the sender removes the Storage object through the Storage API and owner-only RLS policy, retrying on later reloads if the network is unavailable.
- Cache eviction remains enabled (250 MB cap) for both sender-side upload copies and receiver-side downloads.
- Profile-photo preference keys and filenames are scoped to the signed-in account.

### Backend and CI
- Message and edit limits use the same Unicode code-point contract as the Flutter client.
- The new migration discovers and drops existing core-table policies through `pg_policies` rather than relying on historical policy names; storage policies are matched by policy name or the `likedin-media` bucket expression.
- All three push webhook Edge Functions use one fixed-digest constant-time secret comparison helper.
- `supabase-js` remains pinned to `@2.49.8`.
- CI treats analyzer warnings as failures and runs `flutter test` before building.
- CI bootstraps a lockfile on the first run and uploads it as `likedin-pubspec-lock`; subsequent runs enforce a committed `pubspec.lock`.

## Retained fixes already present in the v1.8.1/v1.8.2 source

- Secure-storage recovery, Android backup disabled, email redirect intent filter, null-safe message payload conversion, reaction error isolation, news stale-cache fallback/partial-fetch handling/cache-key cleanup, HTTPS-only story links, account-specific photo preference key, server-time clear-chat, TURN fallback, delayed call connection state, caller signal catch-up, and single-active-call guard.

## Not changed / known limits

- A killed Android process cannot be guaranteed to play a looping ringtone or force a lock-screen takeover on every device/OEM. The existing high-priority FCM notification remains a single notification sound; this is a known platform limitation and is not represented as fixed.
- Media tombstones created before this migration may not contain the original Storage path because the previous delete flow overwrote the payload. Those historical orphaned objects cannot be mapped automatically; path capture and cleanup apply to deletions performed after the migration.
- No committed `pubspec.lock` could be generated in this environment because Flutter/Dart are not installed. The first CI run produces the lockfile artifact; commit that file at the repository root so later builds enforce it.
- Flutter analysis, APK compilation, Supabase migration application, Edge Function deployment, and physical two-device tests have not been run in this environment.
