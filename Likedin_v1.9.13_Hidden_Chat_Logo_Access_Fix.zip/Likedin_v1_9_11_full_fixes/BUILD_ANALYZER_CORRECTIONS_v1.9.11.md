# v1.9.11 GitHub Actions analyzer corrections

Applied after reviewing the GitHub Actions `Analyze source` failure screenshot.

## Corrected

1. `lib/main.dart`: removed `const` from the two `Color(...)` receiver expressions before `.withValues(...)`. A method call cannot be evaluated as part of a constant expression.
2. `lib/ui/conversation_card.dart`: moved `hidden`, `postClearVisible`, and `clearedBeforeMs` declarations outside the preview-loading `try` block. The unread-count query uses these values after that block, so they must remain in `_load()` scope.

## Validation performed here

- Confirmed the corrected source lines are present.
- Confirmed the three unread-count visibility variables are declared in the outer `_load()` scope and are used later in that same scope.
- Confirmed the two `const Color(...).withValues(...)` expressions no longer remain.
- Confirmed the project version remains `1.9.11+97`.
- Confirmed ZIP archive integrity after packaging.

## Not run

Flutter/Dart are not installed in this environment, so `flutter analyze`, `flutter test`, and the Android release build were not run here. GitHub Actions remains the authoritative validation step.
