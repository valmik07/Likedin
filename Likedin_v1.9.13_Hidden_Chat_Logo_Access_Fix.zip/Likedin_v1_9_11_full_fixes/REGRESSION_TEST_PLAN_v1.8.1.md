# Likedin v1.8.1 — Core reliability regression tests

Run on both paired Android devices after the v1.8.1 APK is installed and `send-message-push` is redeployed.

## 1. Chat history and reactions

1. Use a conversation with at least 1,200 messages, including photos, voice notes, and files mixed into the timeline.
2. Open Chat. Confirm the newest 100 messages load and appear in the correct chronological order.
3. Scroll to the top repeatedly. Confirm older pages append without duplicates, gaps, or jumping the message currently being read.
4. Confirm replies to messages from older pages update from the fallback label to the original message summary when that page is loaded.
5. Confirm reaction queries are split into batches of no more than 100 IDs. Simulate a `message_reactions` request failure; the messages must remain visible and the chat must not turn blank.
6. Open Files with more than 500 messages in the database. Confirm every shared file in the history can be reached, including media sent near the oldest end of the conversation.

## 2. Media outbox

1. Begin an upload while the app is also processing the retry queue (for example, reconnect the network and immediately attach another file). Confirm the new file is not reported as sent until its message is committed and visible on the other phone.
2. Enqueue several files while a previous upload is in flight. Confirm all jobs survive queue updates and are eventually uploaded once, with no lost jobs or duplicate messages.
3. Test an empty file and a file larger than 50 MB. Confirm they are rejected before entering automatic retry.
4. Test with no paired recipient and with a queued item whose recipient no longer matches the paired account. Confirm these jobs are quarantined, removed from automatic retry, and not shown as merely waiting for network retry.
5. Test `.rar`, `.7z`, `.apk`, `.svg`, `.bmp`, and `.html`. Confirm these upload as generic files with `application/octet-stream` and can be opened/downloaded on the other phone.
6. Test supported image, video, audio, PDF, Office, text, and ZIP files to confirm allow-listed MIME types still upload with their normal content type.

## 3. Call lifecycle and navigation

1. Start a call while the recipient app is fully closed. Launch Likedin from the app icon; confirm the ringing call is recovered and shown.
2. Receive a call while Likedin is backgrounded, return to the app, and confirm the ringing state is reconciled even if the realtime insert event was missed.
3. On the incoming-call screen, press Android Back. Confirm the call row becomes `rejected`, the caller sees the call end/reject, and it is not later reported as missed.
4. During an active audio call and an active video call, press Android Back. Confirm the call is ended remotely and the other phone does not remain connected.
5. While on Calls, Files, and Settings, press Android Back. Confirm the app returns to Home; a second Back from Home may exit normally.
6. While the in-chat incoming-call banner is visible, tap Join. Confirm the call answer flow starts immediately, the ringtone stops, and no second Accept tap is needed.
7. Decline from the in-chat banner while signaling is unavailable. Confirm the database status still becomes `rejected` and the caller is notified from the authoritative status update.
8. Leave an incoming-call notification untouched and simulate a lost cancel/missed push. Confirm Android clears it after 60 seconds. Also confirm the user can swipe it away manually.

## 4. ICE fallback

1. Confirm a normal call uses STUN plus the returned TURN servers when the TURN function is available.
2. Temporarily make `get-turn-config` unavailable or rate-limited. Confirm call setup and the answer path are not blocked waiting for the function and that STUN candidates are still gathered.
3. Test on a restrictive network where direct STUN may fail. Confirm TURN is required and the configured TURN provider is reachable; STUN-only success is not guaranteed on every NAT.

## 5. Background delivered receipt

1. Deploy the updated `send-message-push` function.
2. Put the recipient app in the background without force-stopping it. Send a message from the other phone.
3. Confirm the recipient gets a local notification while Likedin remains backgrounded and the sender's message changes to Delivered without the recipient opening Chat.
4. Confirm opening the conversation still changes the receipt to Read.
5. Repeat with screen locked and with Android battery optimization enabled. Record OEM-specific delivery delays.

## 6. Release gate

- GitHub Actions Android build succeeds.
- Both phones install and launch the same v1.8.1 build.
- No regression in send, edit, delete-for-everyone, reply, reactions, presence, audio calls, video calls, call history, and normal foreground delivery/read receipts.
- Verify the deployed Edge Function logs contain successful data-only FCM sends and no invalid-payload errors.

Android may delay high-priority FCM processing due to force-stop, OEM battery controls, connectivity, or notification permissions. A force-stopped app is not a valid test for prompt background delivery.
