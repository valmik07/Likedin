# Likedin v1.9.11 — Contact Info, camera, composer and reliability fixes

This release updates the Flutter source from v1.9.9 and increments the app version to `1.9.11+97`.

## Contact Info and shared media
- Contact Info is stateful and refreshes presence/nickname regularly. Full-history counts refresh periodically and immediately after Clear Chat; a queued refresh prevents a just-cleared snapshot from overwriting the updated state.
- Contact Info receives messages filtered for locally hidden, device-cleared and globally deleted items.
- Full conversation loading now returns one globally chronological list across page boundaries. This fixes latest-media selection and keeps encrypted backup exports chronological.
- Voice notes are excluded from the shared-media count; images, videos, documents and link messages are counted separately.
- The preview strip shows the four newest visual items first. Media thumbnails and the shared-media panel are tappable, and a See all media grid is available.
- The profile photo opens the photo viewer when an avatar URL is available. Contact Info bottom padding includes the device navigation-bar inset.
- New image and video uploads create compact JPEG thumbnail sidecars. Thumbnail generation runs off the UI isolate for images, limits decoding to 16 MP, and caps previews at 480 px. Contact Info decodes tiles at a bounded size. Legacy videos without sidecars show a video icon rather than downloading the entire video just to paint a small tile.
- Duplicate nickname/storage shortcuts were removed; user-facing placeholder/developer text was removed.

## Camera and composer
- Temporary camera captures are deleted after send, discard, retake, failed send, recovered-data review, and screen-close cleanup paths.
- Camera preview cannot be dismissed by tapping outside; discard/retake/send are explicit actions. Attempts made while an upload is active show a message.
- Camera permission failures show friendly copy and offer Android Settings when permission is permanently denied. Android `retrieveLostData()` recovery is handled.
- Voice recording uses press-and-hold, gives tap instructions, supports slide-left cancellation and discards recordings when the app pauses or detaches.
- Permanently denied microphone permission offers an Open settings action. The mic has a screen-reader action and descriptive semantics.
- Attachment tooltip reflects Gallery, camera and files. Typing presence is throttled while the user continues typing, then stopped after inactivity.

## Other screens and reliability
- Album changes use a generation token so old page loads cannot append into a new album or leave its loading state stuck.
- Sign-in only enforces the 8-character minimum for account creation. Mounted checks, autofill hints, keyboard actions, forgot-password email, and recovery-link password update flow are included.
- Home conversation preview reads device-local hidden/Clear Chat state, pages until it finds a visible latest message, retains the last preview during refresh, and refreshes on return. The Home card ripple is clipped to rounded corners.
- Backup passphrase length and confirmation are checked inside the dialog. Export paginates the entire conversation (up to the configured 100,000-message safety limit) rather than silently exporting only the latest 200 messages.
- RSS uses XML parsing, handles double-encoded and numeric entities, derives feed locale from the device, uses a rolling date-based cache key, and refreshes the Home conversation card from the refresh action.
- User-facing upload, notification, call, profile-photo and chat-load failures use friendly messages; raw diagnostics remain in debug logs.

## Performance, structure, accessibility and layout
- `chatDisplayMessages` is memoized, per-message GlobalKey retention is bounded, message animation IDs are added after build, and Contact Info metrics are decoded/counted once per snapshot rather than on every widget build.
- The former large `main.dart` UI is split into Home, Chat, Calls and Settings part files.
- Additional Semantics labels/actions were added, remaining sub-12 px UI labels were raised to at least 12 px, and the microphone is keyboard/screen-reader discoverable.
- User-facing date/time labels use MaterialLocalizations, local time, and Yesterday labels instead of hard-coded numeric/English date formatting.
- Appearance Reset requires confirmation. A See all media screen is included.

## Validation status
- Added `test/chat_info_metrics_test.dart` for hidden/Clear Chat filtering, deleted messages, voice-note exclusion, link/media counts and newest-four ordering.
- Static source checks in the build workspace verified balanced Dart delimiters across all Dart files, parsed `pubspec.yaml`, and parsed the Android manifest.
- Flutter analyze, Dart format, Flutter tests and Android compilation were **not run** because the current environment has no Flutter or Dart SDK installed. Please run the included source through the project's GitHub Actions build before installing the APK.

## Compatibility note
Legacy video messages created before v1.9.11 do not contain a thumbnail sidecar; they display a video icon in Contact Info rather than triggering a full-video download. Newly uploaded videos and supported images receive thumbnails.
