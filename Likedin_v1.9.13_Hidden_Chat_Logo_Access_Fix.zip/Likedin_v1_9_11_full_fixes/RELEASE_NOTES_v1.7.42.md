# Likedin v1.7.42 — Notification delivery reliability

## Changes
- Message pushes now include both a visible FCM notification payload and the existing data payload.
- Android can display background message notifications through its native FCM notification path instead of relying solely on the Dart background isolate.
- Missed-call pushes also include a visible notification payload and use the dedicated `likedin_calls_v1` channel.
- Existing notification tap routing data is retained.
- Incoming-call pushes remain high-priority data-only so the existing Flutter background handler can create the full-screen incoming-call notification.
- In the foreground, incoming-call FCM now posts a visible high-priority local call notification as well as preserving in-app call routing.
- No database schema or SQL migration changes.

## Deployment required
This release changes Supabase Edge Function source. Deploy these functions from the project root:

```bash
supabase functions deploy send-message-push --no-verify-jwt
supabase functions deploy send-missed-call-push --no-verify-jwt
```

Do not redeploy or alter the incoming-call function for this change.

## Verification
1. Build and install v1.7.42 on both phones.
2. Sign in on both phones and verify each account has a row in `public.likedin_push_tokens`.
3. With recipient app open on Home, send a message; verify a foreground notification appears.
4. Swipe recipient app away (do not force-stop), lock screen, send a message; verify Android displays a notification.
5. Repeat for a missed call.
6. Test incoming calls with the app foregrounded and backgrounded; verify the system call notification and full-screen incoming-call flow remain intact.
7. Check Android Settings > Apps > Likedin > Notifications and ensure both `Likedin messages` and `Likedin calls` channels are enabled.

## Important limits
- A successful FCM send response means Firebase accepted the message; it does not prove Android displayed it.
- Android force-stop blocks normal FCM delivery until the app is manually launched again.
- APK build alone does not deploy Edge Functions.
- This source has not been compiled or device-tested in this environment.
