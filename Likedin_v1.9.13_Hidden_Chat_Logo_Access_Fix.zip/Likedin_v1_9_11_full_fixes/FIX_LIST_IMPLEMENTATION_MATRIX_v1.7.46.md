# v1.7.44 PDF fix-list matrix — v1.7.46 source review

| PDF item | Area | v1.7.46 source status |
|---:|---|---|
| 1 | Android resources | Present in v1.7.45: resource-shrinker keep file and notification-plugin R8 rule. |
| 2 | Missed calls | Present in v1.7.45: data-only push; `missed`/pre-answer `ended` shows missed alert; `rejected` cancels ringing alert. |
| 3 | FCM token ownership | Present in v1.7.45: account-bound registration RPC, unregister on sign-out, refresh in Settings. |
| 4 | Startup | Present in v1.7.45: early background handler registration, detached permission/token work, one-time listeners. |
| 5 | Notification IDs | Present in v1.7.45: deterministic positive 31-bit identifiers. |
| 6 | Full-screen intent | Present in v1.7.45: one-time prompt marker. |
| 7 | Database triggers | Present in v1.7.45 plus v1.7.46 cleanup migration: one safe message trigger; call/message pushes are best-effort and send only IDs/metadata. Live DB checks in this conversation confirmed the safe functions and remaining triggers; the duplicate message trigger was manually removed. |
| 8 | Background Supabase | Present in v1.7.45: initialize Supabase in background isolate only if needed. |
| 9 | Push documentation | Present in v1.7.45: visible-notification comment corrected. |
| 10 | Chat send | Present in v1.7.45: only message RPC failure rolls back optimistic send. |
| 11 | Chat realtime | Present in v1.7.45: subscribe before first load; optional initialization tasks are isolated. |
| 12 | Call cleanup | Present in v1.7.45: failed start/accept cleanup, terminal status, null call-ID guard. |
| 13 | Background calls | Present in v1.7.45: Android microphone/camera foreground service and MethodChannel bridge. |
| 14 | Media | Present in v1.7.45: TUS 409 handling, missing retry-file cleanup, streaming downloads. |
| 15 | Downloads | Present in v1.7.45: MediaStore copy runs on a worker thread. |
| 16 | RLS | Present in v1.7.45: removes the broad message/call UPDATE policies named by the PDF. |
| 17 | Realtime | Present in v1.7.45: idempotent membership for listed tables. |
| 18 | Migration order | Present in v1.7.45: `read_at` added before its unread index. |
| 19 | Signup | Present in v1.7.45: account-slot/profile trigger and existing-user backfill. |
| 20 | Release signing | Present in v1.7.45: workflow requires persistent keystore secrets; user configuration is still required. |
| 21 | Version/news | Present and tightened in v1.7.46: unified version constant, daily cache key, and five newest stories shown each day. |
| 22 | Housekeeping | Present in v1.7.45: stale generated registrar absent; E2EE remains out of scope; push payloads omit message text. |

## Important verification boundaries

This matrix records static source inspection, not runtime proof. No Flutter analyzer, Dart tests, Gradle build, Edge Function redeployment, or physical-device test was possible in the current environment. Items involving external services or runtime behavior still require the planned Android 11/Android 16 tests.
