# Likedin v1.7.45 — Consolidated reliability hardening

## Implemented from the v1.7.44 fix list

### Notifications and push
- Added resource-shrinker keep declarations for the custom call/message sounds and monochrome notification icon.
- Kept flutter_local_notifications reflection/plugin classes in R8 rules.
- Made missed-call FCM data-only so the Dart background handler can cancel/replace the ongoing incoming-call notification using the same notification ID. Only `missed` and pre-answer `ended` statuses create a missed-call notice; `rejected` becomes `call_ended` and only cancels the ring alert.
- Added account-bound token registration RPC so a device token is moved to the currently authenticated user; token is unregistered before sign-out.
- Made notification setup retry-safe, detached permission/token work from splash, prevented duplicate FCM listeners, and made local notification readiness independent from permission prompt completion.
- Bounded all notification identifiers to positive signed 32-bit values.
- The full-screen-intent settings screen is prompted at most once per installation.
- Push triggers are best-effort and catch database/network exceptions so message/call writes do not fail. Webhook payloads contain IDs and call metadata only, never message bodies.
- Background handler initializes Supabase only when needed. Message push comments now reflect system-tray behavior for visible notification payloads.

### Chat, calls and media
- A successful message RPC is no longer rolled back locally because a later typing/pull-to-refresh operation fails.
- Chat realtime subscribes before initial message loading and startup requests are isolated so one optional call cannot prevent subscription.
- Failed call setup now moves the call toward a terminal state and disposes tracks/connections; `end()` handles an absent call ID safely.
- Added an Android foreground service for an active microphone/camera call so capture can continue when the app is backgrounded. Service is started only after media permissions are successfully granted and the local stream exists.
- TUS 409 responses are treated as an already-existing immutable upload; missing queued files are removed from retry state.
- Storage downloads stream to a temporary file instead of buffering the full attachment in memory.
- Saving files to Downloads runs on a worker thread.

### Supabase
- Removed broad direct UPDATE policies for messages and call rows; client mutations continue through the existing SECURITY DEFINER RPCs.
- Added idempotent realtime publication membership for messages, profiles, calls, signals and reactions.
- Ensured `read_at` exists before its index is created.
- Added a signup trigger to claim one of the two existing account slots and create the profile, plus a backfill for existing auth users.
- Added `likedin_register_push_token(text)` to move an FCM token between accounts safely.

### Build and housekeeping
- Made GitHub Actions require all four persistent release-keystore secrets before building, preventing accidental APKs signed with a fresh ephemeral runner key. Local Gradle builds can still use the debug fallback when no key.properties exists.
- Added a version constant used by Settings and the news User-Agent; the home briefing cache now rotates daily.
- Removed the stale generated plugin registrant source from the archive.
- E2EE remains outside the current product plan; existing message payload storage is not end-to-end encrypted. Push payloads deliberately exclude message text.

## Required deployment steps

1. Build v1.7.45 through GitHub Actions and install it on both phones.
2. Run `supabase/migrations/202611170001_hardening_and_bootstrap_fixes.sql` in Supabase SQL Editor. Review it against live policy names/state before applying. It is idempotent and includes the token-registration RPC, safe push triggers, account-slot/profile bootstrap, RLS policy removal, and realtime publication setup.
3. Deploy the updated data-only missed-call function:
   `supabase functions deploy send-missed-call-push --no-verify-jwt`
4. Keep the existing `send-message-push` and `send-incoming-call-push` functions deployed. Their runtime payloads do not require redeployment for this change; the SQL triggers are refreshed by the migration.
5. If a Dashboard Database Webhook still sends message INSERT events to `send-message-push`, disable it after confirming the SQL trigger is active, to avoid duplicate pushes.
6. Configure the four `LIKEDIN_*` repository secrets for persistent APK signing before running the CI build; the workflow now stops if they are absent. Switching from the old debug signature requires a one-time uninstall/reinstall; protect and back up the keystore permanently.

## Verification status

- ZIP integrity and targeted source checks were performed.
- No Flutter/Dart SDK is installed in this environment. No Flutter analyzer, tests, Android Gradle build, Supabase migration execution, Edge Function deployment, or physical-device tests were performed.
- Verify notifications, attachment send/receive, foreground/background calls, retries, and app upgrades on both Android 11 and Android 16 devices before treating this release as production-ready.
