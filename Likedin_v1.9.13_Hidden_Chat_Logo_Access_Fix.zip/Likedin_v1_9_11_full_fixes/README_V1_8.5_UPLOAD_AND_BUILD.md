# Likedin v1.8.5 — Upload and Build Guide

This is the complete Likedin Android project archive for version **1.8.5+84**.

## 1. Before building the APK
1. Open `supabase/migrations/202611220001_v185_call_failure_push_and_media_index.sql` in the Supabase SQL Editor and run it once (and ensure `202611210001_v184_profile_avatar_and_usage_optimization.sql` has been applied).
2. Redeploy the `send-missed-call-push` Supabase Edge Function so `'failed'` ringing calls are accepted alongside `'missed'`, `'ended'`, and `'rejected'`.

## 2. GitHub Actions build
Replace the previous project source archive in your repository with the contents of `Likedin_v1.8.5_source.zip` and run the **Likedin Android APK** workflow on `main`.
