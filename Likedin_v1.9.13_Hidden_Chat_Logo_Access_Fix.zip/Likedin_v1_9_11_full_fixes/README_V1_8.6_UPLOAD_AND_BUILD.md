# Likedin v1.8.6 — Upload and Build

This source archive is version **1.8.6+85**, based on the supplied v1.8.5 project.

## Included
- Refreshed chat composer with a cleaner, compact attachment and sticker toolbar.
- Composer keeps keyboard focus after sending or editing a message when it was already open. Failed sends restore the draft and focus.
- Direct Android Gallery picker for photos, videos and supported media.
- Separate file browser and dedicated animated GIF file picker.
- Animated GIF attachments use the existing private media upload pipeline and render as animated images in chat.
- Built-in quick sticker picker; selected stickers send as large emoji-style chat messages.
- Existing messaging, calling, backend, media retry, and security flows are retained.

## Build
1. Replace the previous source archive in the GitHub repository with this ZIP's contents.
2. Run the existing **Likedin Android APK** GitHub Actions workflow on `main`.
3. Install the generated APK on both phones and test gallery access, GIF send/receive, sticker send/receive, and repeated text sends while the keyboard remains open.

No new Supabase migration or Edge Function deployment is required for these UI/media-picker changes. This is a source update; it has not been compiled or tested on physical devices in this environment.
