# Likedin 1.7.12 — Phase 2 backend setup

## Included in the client ZIP
- Call history screen backed by `public.likedin_calls` (last 100 calls).
- Realtime refresh when a call is inserted or its status changes.
- Outgoing calls are marked `missed` after 45 seconds without an answer.
- A missed-call notification routes to Call history.

## Supabase SQL
Run this migration once in Supabase SQL Editor:
`supabase/migrations/202611140002_phase2_call_history_missed_notifications.sql`

## Deploy the missed-call Edge Function
Deploy the included function folder:
`supabase/functions/send-missed-call-push/`

Using Supabase CLI from the project directory:
```bash
supabase functions deploy send-missed-call-push
```

The function uses the same Edge Function secrets as the existing incoming-call push:
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `FIREBASE_SERVICE_ACCOUNT_JSON`

The database trigger uses the existing Vault secret `LIKEDIN_PUSH_WEBHOOK_SECRET`. The Edge Function secret with the same name must match it. If incoming-call push is already configured, reuse those existing secrets; do not create new credentials.

## Notes
- No GitHub Actions workflow change is required.
- Push notifications while the app is backgrounded/closed require Firebase to be configured on both devices and the Edge Function to be deployed. In-app call history works from the existing Supabase call rows.
- The 45-second missed-call timer starts on the caller's device. Android may delay timers if the OS force-stops the app; in that case the call remains `ringing` until another state transition. A server-side scheduled expiry can be added later if needed.
