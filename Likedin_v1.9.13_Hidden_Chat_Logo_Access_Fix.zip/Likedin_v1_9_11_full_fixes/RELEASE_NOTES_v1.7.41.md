# Likedin 1.7.41 — sender-side attachment cache fix

## Fix
- After a successful private Storage upload, copy the exact uploaded file into the app-private `LikedinMediaCache` using the same deterministic cache key used by attachment rendering.
- The sender now renders its own newly sent attachment from this local cache rather than immediately issuing a second Storage download for an object it just uploaded.
- The receiver continues to fetch the attachment from the private `likedin-media` bucket and uses the existing paired-account Storage read policy.
- Applies to queued file/photo/video attachments and direct voice-message uploads because all use `SharedMediaService.upload`.
- Cache writes use a temporary `.part` file and atomic rename. A cache-write failure does not fail an otherwise successful upload/send.

## Scope
- No Supabase SQL, RLS, Edge Function, credential, or backend changes.
- No change to upload format, TUS resumability, compression, message payload schema, or WebRTC.

## Verification
- Version: `1.7.41+71`.
- Source-level checks performed; Flutter SDK is not available in this environment, so `flutter analyze`, automated tests, APK compilation, and two-device regression testing remain to be run.
- Test both sender and receiver views for image, video, document, and voice-message attachments; then close/reopen the app and verify cached sender media remains visible.
