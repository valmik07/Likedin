# Likedin v1.9.11 — Profile Photo Fix v5

## Root cause identified

The runtime screenshot reports a Java `ClassNotFoundException` while the app is saving the edited photo on-device. In the v4 flow, this stage begins immediately before `getApplicationSupportDirectory()`, which is supplied by `path_provider_android`.

`path_provider_android` 2.3.0 introduced a JNI-based implementation and has a documented Android release-mode `ClassNotFoundException` regression in its application-support/documents directory calls. The upstream fix in 2.3.1 removes the dependency on Flutter engine `PathUtils`. See:

- https://pub.dev/packages/path_provider_android/changelog (2.3.1 removes `PathUtils` to avoid release-mode `ClassNotFoundException`)
- https://github.com/flutter/flutter/issues/184750 (reproduction, diagnosis and resolution)

## Change

Added a `dependency_overrides` pin in `pubspec.yaml`:

```yaml
dependency_overrides:
  path_provider_android: 2.3.1
```

This protects all app calls to `getApplicationSupportDirectory()` and `getApplicationDocumentsDirectory()`, not just the profile-photo flow. No Supabase SQL, RLS, bucket configuration, profile-photo RPC, cropper behavior, or app version was changed.

## Validation

- Confirmed the profile-photo save stage calls `getApplicationSupportDirectory()` before writing the output JPEG.
- Confirmed release minification is enabled in `android/app/build.gradle.kts`.
- Confirmed project Flutter workflow uses Flutter 3.47.9.
- YAML parse, dependency override assertion, and ZIP integrity checked locally.
- Flutter dependency resolution, analyzer, tests, release APK build, and on-device photo upload still require GitHub Actions/device verification.

Project version remains `1.9.11+97`.
