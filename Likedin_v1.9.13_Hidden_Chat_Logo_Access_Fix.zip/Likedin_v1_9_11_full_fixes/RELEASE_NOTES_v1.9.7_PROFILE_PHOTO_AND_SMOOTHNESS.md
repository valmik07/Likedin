# Likedin v1.9.7+93 — profile photo viewing, square crop editor and smoothness pass

This release builds on the v1.9.6 Obsidian / Arctic Glass source. Existing chat,
media, calls, notifications, privacy, backup, storage and theme functionality is
retained. No Supabase schema migration, bucket-policy change or new dependency
is introduced.

## Profile-photo viewing
- Tapping the other person's profile image in the chat header opens a full-screen,
  zoomable viewer.
- Tapping the other person's avatar in the Home conversation card opens the same
  viewer.
- The viewer uses the existing signed URL for the private `likedin-media` bucket;
  the bucket is not made public.
- Thumbnail decoding is bounded, and the viewer decodes at a capped width.

## Profile-photo editing before upload
- Selecting Edit profile photo now opens a dedicated editor before any upload.
- The editor supports pan and pinch zoom inside a fixed square crop frame (1:1).
- The crop can be reset before confirmation.
- Image orientation is normalized, and source decoding / resizing / JPEG encoding
  run in worker isolates rather than on the UI isolate.
- The stored avatar is a 1024 x 1024 JPEG at quality 88. This reduces profile-photo
  Storage usage and provides a consistent image format. Source decoding is capped at
  16 megapixels inside the worker isolate to prevent oversized input files from causing
  memory spikes on 3 GB devices; unusually large photos should be resized before selection.
- The upload uses the existing private Storage bucket and existing
  `likedin_set_profile_avatar` RPC. The previous avatar is retained unless the
  replacement upload and profile-path update succeed.
- Supported source formats in this crop flow: JPG/JPEG, PNG and WebP. Source file
  size remains limited to 5 MB. GIF/HEIC/HEIF are not offered by the file picker
  because this built-in editor does not guarantee correct decoding for those formats.

## Smoothness / memory
- Removed synchronous `File.existsSync()` calls from profile-avatar widget builds.
- Profile avatars are decoded at bounded thumbnail dimensions and wrapped in
  `RepaintBoundary` to isolate repaint work.
- The full-screen profile-photo viewer uses a bounded decode width and interactive
  zoom, while retaining the app's existing global 32 MB image-cache budget and
  memory-pressure cleanup behavior.
- No features or app tabs were removed.

## Validation
- Source archive integrity and workflow version checks are verified.
- Flutter analysis, unit/widget tests, Android Gradle build and physical-device
  performance measurements must still be run in GitHub Actions / on devices.
