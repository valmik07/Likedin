# Likedin 1.7.40 — Android R8 notification TypeToken fix

## Fix
- Added explicit R8/ProGuard keep rules for `com.google.gson.reflect.TypeToken` and anonymous subclasses.
- Preserves the generic type signatures used by `flutter_local_notifications 18.0.1` when it loads scheduled-notification data during cancellation.
- Addresses the release APK crash reported during call setup/cleanup: `TypeToken must be created with a type argument`. The stack trace enters `FlutterLocalNotificationsPlugin.cancelNotification`; the failure is in notification persistence/obfuscation, not the WebRTC video stream itself.
- Existing `-keepattributes ... Signature ...` configuration remains in place.

## Scope
- No Dart call-flow changes.
- No Supabase schema, Edge Function, credentials, or backend changes.
- No dependency upgrade; the existing `flutter_local_notifications 18.0.1` dependency is retained.

## Build and verification
- Version: `1.7.40+70`.
- Source/configuration patch only. A release APK and on-device video-call regression test still need to be produced/run in the GitHub Actions build and on both test phones.
