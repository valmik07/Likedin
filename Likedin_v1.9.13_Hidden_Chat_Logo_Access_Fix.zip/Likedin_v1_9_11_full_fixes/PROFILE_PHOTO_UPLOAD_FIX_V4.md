# Likedin v1.9.11+97 — Profile Photo Upload Fix v4

## Why this patch was made

The live Supabase checks supplied for this build confirm:
- `likedin-media` exists, is private, and has a 50 MiB file-size limit.
- `public.profiles.avatar_path` exists.
- `public.likedin_set_profile_avatar(text)` exists.
- Two account slots are occupied, both accounts are confirmed, and both profile rows exist.
- The authenticated Storage policies include own-folder INSERT, pair SELECT, and owner DELETE.

These checks rule out the missing migration, missing bucket, and missing base Storage policies as the obvious cause. They do not prove every live request will pass, so the app must report the exact failing operation.

## Changes in `lib/main.dart::_pickProfilePhoto`

1. The old avatar-path lookup is now best-effort. It is needed only to delete the previous remote photo after a successful replacement. A failed read must not block a new upload.
2. The upload flow tracks the current operation: picker, file read, editor, local write, Storage upload, profile RPC, or local commit.
3. Non-`StateError` failures now show the operation and the original exception text (bounded to 240 characters) instead of replacing every error with a generic connection message.
4. Detailed failure information is written to Android logcat with a `[ProfilePhoto]` prefix.
5. If the profile RPC fails after Storage upload, the newly uploaded object is removed; cleanup failures are logged without hiding the original RPC error.
6. Failure to delete the old remote avatar after a successful update is logged but no longer reports the already-successful profile change as failed.
7. The uploaded object path and local output file are held in non-null local variables through their operations.

## Not changed

- App version remains `1.9.11+97`.
- Bucket remains private (`likedin-media`).
- Storage object naming and existing RLS security model remain unchanged.
- Crop ratio, JPEG output, and profile photo UI remain unchanged.
- No broad Storage UPDATE policy was added.

## Validation status

Source-level checks and ZIP integrity are performed for this package. Flutter analyzer, Flutter tests, and an Android build must be run by GitHub Actions because Flutter/Dart are not installed in this working environment.
