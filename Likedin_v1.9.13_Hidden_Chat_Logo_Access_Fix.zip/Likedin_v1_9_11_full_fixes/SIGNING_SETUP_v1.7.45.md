# Persistent Android release signing for Likedin

The v1.7.45 workflow now requires a stable key and stops before building if any of the four GitHub repository secrets is missing:

- `LIKEDIN_KEYSTORE_B64`
- `LIKEDIN_STORE_PASSWORD`
- `LIKEDIN_KEY_ALIAS`
- `LIKEDIN_KEY_PASSWORD`

Create one keystore locally and back it up somewhere private and durable. Never commit the `.jks` or `key.properties` files.

Example (run locally, and keep the entered passwords private):

```bash
keytool -genkeypair -v -keystore likedin-release.jks -storetype JKS -keyalg RSA -keysize 2048 -validity 10000 -alias likedin_release
```

For the `LIKEDIN_KEYSTORE_B64` secret, encode the binary file as one uninterrupted Base64 string:

- Linux: `base64 -w0 likedin-release.jks`
- macOS: `base64 < likedin-release.jks | tr -d '\n'`
- Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes('likedin-release.jks'))`

Set the remaining GitHub secrets to the exact keystore store password, key alias (`likedin_release` in the example), and key password. Do not paste private-key material into source files, issues, or commit history.

**Upgrade warning:** the existing CI APKs are debug-signed. Switching to this new release key changes the signing certificate, so uninstall the debug-signed app once before installing the first APK signed with the stable key. That removes the app's local data; ensure any important information is backed up first. Every later APK must use the same permanent keystore or Android will reject the upgrade.
