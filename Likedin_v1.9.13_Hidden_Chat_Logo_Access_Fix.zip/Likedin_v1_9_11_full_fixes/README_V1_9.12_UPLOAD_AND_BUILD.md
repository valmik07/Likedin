# Likedin v1.9.12 — Upload and Build

1. Download `Likedin_v1.9.12_Hidden_Chat_Security.zip`.
2. In your existing GitHub repository, replace the previous source ZIP with this ZIP. Keep the existing workflow file unchanged.
3. Run the existing GitHub Actions workflow and download the generated ARM64 APK.
4. Install the APK on both devices. The hidden-chat password and hidden state are device-local, so hide the conversation separately on each device where you want it hidden.

## First use

- On Home, open the conversation card's three-dot menu and choose **Hide chat**.
- Create a separate password of at least 8 characters.
- The conversation is replaced on Home by **Hidden chats**.
- Choose **Unlock**, enter the password, then choose **Open chat** or **Unhide chat**.
- While unlocked, the manager also offers **Change password**. **Forgot password?** verifies the regular Likedin account password before creating a new hidden-chat password.
- The Chat and Files tabs require the hidden-chat password while a conversation is hidden. The Files tab can show shared attachments after authentication. Backup export separately asks for the hidden-chat password.

No Supabase SQL, RLS, Storage policy, Edge Function, or backend deployment is required.
