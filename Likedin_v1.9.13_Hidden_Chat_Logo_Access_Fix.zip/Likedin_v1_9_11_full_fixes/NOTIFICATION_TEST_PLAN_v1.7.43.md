# Likedin v1.7.43 notification test plan

1. Build/install v1.7.43 on both paired Android phones.
2. Open Settings > Notifications on each phone.
3. Confirm Android permission = Allowed, Firebase Messaging = Initialized, and This phone registered = Yes.
4. Tap Send test notification. If this does not appear, inspect Android app notification settings and the `Likedin messages` channel.
5. Deploy current functions:
   - `supabase functions deploy send-message-push --no-verify-jwt`
   - `supabase functions deploy send-missed-call-push --no-verify-jwt`
6. Run `supabase/migrations/202611160002_message_push_trigger.sql` in SQL Editor. Disable any existing Dashboard Database Webhook that also targets `send-message-push` to prevent duplicates.
7. Confirm each user has a row in `public.likedin_push_tokens` using the read-only diagnostic query in `RELEASE_NOTES_v1.7.43.md`.
8. With recipient on Home and app in foreground, send a message. The foreground local notification is suppressed while the chat conversation itself is visible by design.
9. Swipe recipient app away from Recents (do not force-stop), lock the screen, and send a message. Confirm the Android notification appears.
10. Test incoming and missed calls separately, foreground and background.
11. Android force-stop blocks normal FCM delivery until the user manually launches the app again. OEM battery management may delay background delivery.
