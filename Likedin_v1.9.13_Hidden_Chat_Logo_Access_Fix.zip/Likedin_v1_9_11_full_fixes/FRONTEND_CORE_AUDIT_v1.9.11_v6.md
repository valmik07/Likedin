# Likedin v1.9.11 — Frontend Core Functionality Audit (v6)

## Scope

Reviewed the Flutter frontend paths for chat attachments, in-app gallery selection, keyboard image insertion, profile-photo selection, local attachment-vault imports, shared-media upload/queue metadata, and received-media rendering. No SQL schema, RLS policy, Storage bucket policy, credentials, package versions, app ID, app name, or app version were changed.

## Verified frontend defects and fixes

### 1. Photos and GIFs could be mislabeled as generic files

**Cause:** Media type detection relied heavily on the selected filename. Android MediaStore titles and document-provider names can be extensionless or can disagree with the underlying bytes. A photo/GIF could therefore be uploaded with `application/octet-stream` and `kind: file`, making the receiver show a document card instead of an image.

**Fix:** `SharedMediaService` now checks file signatures before trusting the name, normalizes the stored filename extension to match the uploaded bytes, and persists the actual MIME type and media kind in the retry queue. GIF animation state is retained even when a GIF is re-encoded as animated WebP.

### 2. Android content-URI selections could fail before upload

**Cause:** The chat attachment picker and profile-photo picker depended on a normal filesystem path. Some Android providers expose a content URI or no path while still making the selected bytes readable.

**Fix:** Both pickers request `withReadStream` and stage a bounded temporary copy when a normal file path is unavailable. The selected media is then passed through the same detection/preparation path. Each attachment is handled independently so one unreadable item does not abort an entire multi-file selection.

### 3. Local attachment-vault imports had the same path-only assumption

**Cause:** Vault imports silently skipped items without a filesystem path.

**Fix:** Vault imports now consume the file stream when no usable path is returned and clean up partial copies after a failed read.

### 4. BMP/TIFF photos were accepted by keyboard insertion but not allowed by Storage

**Cause:** The frontend accepted BMP/TIFF from compatible keyboards, but the existing private bucket allow-list does not include those MIME types. Such files could be stored as generic binary attachments.

**Fix:** Detect BMP/TIFF signatures and convert those raster photos to JPEG on a worker isolate before enqueueing. The backend allow-list remains unchanged.

### 5. Previously received extensionless/mislabeled media could remain hidden as a file card

**Cause:** Older messages may already contain generic `kind: file` metadata, so the current renderer never tried to display their actual photo/GIF/video bytes.

**Fix:** The renderer now infers common image/video types from MIME or known filename extensions. Ambiguous legacy file cards include a Preview action that downloads to the private cache, inspects the actual bytes, and opens supported photos/GIFs/videos. GIF animation is preserved by the image decoder.

## Tests added

`test/shared_media_mime_test.dart` covers extensionless JPEG/GIF/PNG/WebP signatures, a misleading `.png` filename containing GIF bytes, and raw BMP/TIFF detection versus the current Storage MIME allow-list.

## Validation

- Parsed `pubspec.yaml` and `analysis_options.yaml` successfully.
- Parsed `android/app/src/main/AndroidManifest.xml` successfully.
- Ran a lexical bracket/delimiter scan across all Dart source and test files: no unbalanced delimiters found.
- Compared the working tree against the supplied ZIP: only the intended frontend files, the new MIME test, and this audit note differ.
- Confirmed the supplied ZIP's root project directory is preserved.

**Not run:** Flutter/Dart are not installed in this environment. Therefore `flutter analyze`, `dart format`, `flutter test`, Gradle release compilation, and real Android photo/GIF/call testing have not been executed. Run the project's GitHub Actions build and install the resulting APK on both Android 11 and Android 16 before treating this candidate as device-verified.
