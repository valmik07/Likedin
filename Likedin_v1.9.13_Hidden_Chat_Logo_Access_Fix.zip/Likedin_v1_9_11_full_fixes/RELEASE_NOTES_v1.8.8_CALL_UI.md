# Release Notes — v1.8.8+87

## Futuristic calling UI and call history

- Updated incoming/outgoing call interfaces with glass panels, aurora backgrounds, animated halo avatar, luminous call controls and improved video overlays.
- Updated call history with All, Missed, Video and Audio filters, readable relative timestamps, duration labels and callback action.
- Kept WebRTC signaling, call lifecycle, notifications, proximity handling and existing Supabase history retrieval intact.
- No package additions or database migrations.

This iteration is a Flutter source build. Run analyzer, tests and a release APK build, then complete device-based call regression before deployment.
