# Likedin 1.7.14 — Full-screen incoming calls

## What changed
- Incoming-call FCM is now **data-only**. Android no longer renders the basic FCM notification itself; the Flutter background handler creates the full-screen call notification.
- Incoming-call notifications use maximum importance, call category, public lock-screen visibility, full-screen intent, and an ongoing state while ringing.
- MainActivity opts into showing over the lock screen and turning the display on.
- Android 14+ full-screen-intent access is checked. If Android has not granted it, Likedin opens the system's per-app full-screen notification permission page.
- Incoming call screen redesigned with a dark gradient, clearer call identity, large answer/decline actions, and a larger video stage with a self-preview.
- Incoming notification is cancelled when Likedin takes over the call screen.

## Backend deployment required
There is **no SQL migration** for this update.

Replace the existing Supabase Edge Function source with the updated file in this ZIP:

`supabase/functions/send-incoming-call-push/index.ts`

Then deploy it:

```bash
supabase functions deploy send-incoming-call-push
```

Do not redeploy `send-missed-call-push`; missed-call notifications are unchanged. Existing Supabase/Firebase secrets are reused.

## Android permission
On Android 14 and newer, allow **Full-screen notifications** for Likedin when the app opens the Android permission page. Also keep normal notifications enabled. On Android 11–13, the full-screen intent permission page is not used; notification permission and channel settings still apply.

If the Android call channel was previously muted or changed by the user, restore its sound/importance under Android Settings → Apps → Likedin → Notifications → Likedin calls. Android does not let an app silently override a user's existing channel choice.

## Testing
Test on both phones:
1. Likedin open in foreground.
2. Likedin in background / swiped away from Recents.
3. Phone locked with display off.
4. Answer, decline, caller hang-up, and timeout; confirm ringtone/vibration stop.

A user force-stopping the app from Android App info is different from swiping it away; Android blocks push delivery to force-stopped apps until the user manually opens them again. Full-screen launch can also be restricted by Android/OEM policy or disabled by the user.
