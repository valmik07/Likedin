# Likedin 1.7.12 — Phase 2

- Added a persistent call-history list with incoming/outgoing direction, audio/video type, status, timestamp and connected duration.
- Added realtime call-history refresh and pull-to-refresh.
- Added a 45-second no-answer timeout that records the outgoing call as `missed` and signals the callee to close the ringing screen.
- Added missed-call notification routing to Call history.
- Added an optional Supabase Edge Function and SQL trigger for remote missed-call push notifications.

Backend setup is documented in `PHASE_2_BACKEND_SETUP_v1.7.12.md`.
