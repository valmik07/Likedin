# Likedin v1.7.3.4 — Delete for everyone

## App changes
- Adds a Delete for everyone action to the long-press menu for messages sent by the current user.
- Requires confirmation before deletion.
- Calls `likedin_delete_message_for_everyone` and refreshes the conversation after success.
- Subscribes to message DELETE realtime events so the other active device refreshes promptly.
- Existing Delete for me remains local-only.

## Required Supabase migration
Apply `supabase/migrations/202611120001_delete_message_for_everyone.sql` to the existing Supabase project before testing this feature. The RPC is SECURITY DEFINER but only deletes a row when `sender_id = auth.uid()`. It does not permit deleting another user's message.

## Important behavior
This uses a physical row delete. Both devices will stop displaying the message after the conversation refreshes. A device that is offline will see the message disappear when it next reloads the conversation. This does not retract notifications or media already saved outside the message row.

## Build
- App version: 1.7.3+30
- Flutter compilation and two-device verification are pending.
