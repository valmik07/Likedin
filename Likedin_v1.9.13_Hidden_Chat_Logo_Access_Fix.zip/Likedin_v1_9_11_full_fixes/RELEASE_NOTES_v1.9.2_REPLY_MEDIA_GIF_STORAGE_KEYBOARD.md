# Likedin v1.9.2+91 — Reply media previews, GIF storage and composer reliability

## Changes
- Reply quotes now retain the original `RemoteMessage` and render a thumbnail for photo/GIF replies instead of exposing the attachment filename. Video, audio and document replies use compact media-type previews. The composer reply banner uses the same preview.
- GIF preparation runs off the UI isolate and converts animated GIFs to animated WebP where the result is smaller. The output is resized to at most 480 px, sampled to at most 28 frames, quality-encoded, and limited to 2 MB per animated attachment. Raw keyboard input remains capped at 8 MB.
- No duplicate thumbnail objects are uploaded to Supabase Storage. Reply previews use the existing private media cache; simultaneous requests for the same object share one download future.
- Gboard media is durably queued after preparation, then uploaded in the background so the composer can be used immediately. Queue retries remain supported.
- The chat TextField is no longer switched to `readOnly` while sending. The app explicitly restores focus and shows the keyboard after text/Gboard sends when it was already open.

## Storage impact
Animated GIFs use a strict 2 MB item ceiling after optimization. When optimization cannot achieve that ceiling, the app asks the sender to choose a shorter/smaller GIF rather than uploading a large object. This does not change the Supabase plan's 1 GB quota or delete previous objects.

## Required backend changes
None. Animation metadata (`animated`) is included in the existing media JSON payload stored in the message row; no new table, bucket or Storage policy is required.

## Validation
ZIP integrity, source marker checks, version/Workflow guard match, and YAML syntax are checked in this package-preparation environment. Flutter analysis/tests/Gradle build must still run in GitHub Actions because Flutter/Dart SDKs are not installed in this environment.
