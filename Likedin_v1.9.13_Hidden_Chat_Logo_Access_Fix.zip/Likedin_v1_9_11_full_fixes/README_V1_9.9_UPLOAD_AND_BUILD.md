# Likedin v1.9.9+95 upload and build

1. In the GitHub repository root, remove the previous project ZIP.
2. Upload `Likedin_v1.9.9_chat_camera_info_composer.zip` as the only root-level ZIP.
3. Replace the existing workflow under `.github/workflows` with `likedin_workflow_v1.9.9.yml`.
4. Commit the changes and run **Likedin v1.9.9 Chat Camera, Contact Info and Adaptive Composer ARM64 APK**.

No GitHub signing secrets are required for the current debug-signing fallback. Because GitHub-hosted runners are temporary, debug signing identity may change between runs; do not uninstall the existing app if Android reports a signature conflict before discussing the error.

This release is a frontend update. It preserves the existing Supabase schema, RPCs, storage buckets and backend contract. No SQL migration is required.
