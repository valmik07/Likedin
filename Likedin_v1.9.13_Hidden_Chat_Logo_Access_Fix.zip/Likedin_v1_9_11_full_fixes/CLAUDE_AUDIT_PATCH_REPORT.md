# Likedin v1.9.11 — Claude audit patch report

## Scope and validation status

This patch was applied to the Flutter source archive `Likedin_v1.9.11_source_analyzer_fixes_v4.zip`. The project version remains `1.9.11+97`; no package name, application ID, or existing feature module was intentionally removed.

The environment used for this pass does not have the Flutter or Dart SDK installed. Therefore `flutter pub get`, `flutter analyze`, `flutter test`, and an Android APK build could not be run here. XML/YAML parsing, source delimiter checks, archive checks, and targeted source review were performed. Treat this as a patched source candidate, not a build-certified release.

## Claude's 30 findings

| # | Finding | Patch status | Change made / remaining validation |
|---:|---|---|---|
| 1 | Sign-in rejects short passwords | Fixed in source | The 8-character minimum now applies only to account creation, not sign-in. |
| 2 | Nickname editor overflows on narrow phones | Fixed in source | Header actions are hidden while editing; the name field gets the available row width, with cancel/save controls retained. Verify on 360dp and 411dp devices. |
| 3 | Shared HTTPS links do not launch | Fixed in source | Android package-visibility queries now declare ACTION_VIEW for `https` and `http` schemes. |
| 4 | Sticker sheet inserts instead of sending and bypasses length limit | Fixed in source | Sticker selection sends as its own message through the normal send pipeline; the 10,000-character guard also applies. |
| 5 | Mic does nothing before friend registers | Fixed in source | The user now gets a clear message when the peer account is not registered. |
| 6 | Password recovery event can arrive before AuthGate listens | Hardened in source | An early auth-state subscription captures password-recovery events and AuthGate consumes the pending flag. Confirm with a cold-start recovery link. |
| 7 | Chat may not land on newest message after lazy media sizing | Hardened in source | Scroll-to-latest retries after layout/media updates and cancels retries on dispose. Confirm with large photos and voice notes on a device. |
| 8 | Failed send can lose a message when newer text was typed | Fixed in source | A failed message is restored alongside newer draft text instead of being discarded. |
| 9 | Switching gallery album clears selection | Fixed in source | Selected assets persist while the displayed album changes. |
| 10 | Filtered short video list cannot scroll to trigger pagination | Fixed in source | The filtered viewport is filled by requesting subsequent pages until enough items are present or paging ends. |
| 11 | Gallery permission settings are rechecked too early | Fixed in source | Permission state is refreshed on app resume after returning from Android settings. |
| 12 | Gallery grid tiles lack screen-reader labels | Fixed in source | Each tile exposes media type, title, selection state, and an action hint through Semantics. |
| 13 | Hard-coded white foregrounds have low contrast with bright dark-mode accents | Fixed in source | The affected microphone, in-call join progress indicator, and logo foreground use `colorScheme.onPrimary`. |
| 14 | Incoming-call banner uses fixed light colours in dark mode | Fixed in source | Banner surfaces, outline, and text use theme colour-scheme roles. |
| 15 | Failed Home avatar URL leaves a blank circle | Fixed in source | Network image errors render the contact initial instead. |
| 16 | Home card repeats queries and avatar signing on every message event | Partially fixed | Signed avatar URLs (including null/failed results) are reused for the same path and renewed after 45 minutes, avoiding avatar churn. Conversation/profile/unread data is still refreshed after debounced message events. |
| 17 | Unread badge includes locally hidden/cleared messages and caps at 100 | Fixed in source | Unread rows are paged without the old 100 cap and filtered against hidden, cleared, and post-clear local state, including client message IDs. |
| 18 | “Yesterday” can be wrong around daylight-saving transitions | Fixed in source | Calendar-day boundaries are computed using local date constructors rather than subtracting 24 hours. |
| 19 | Tab says Media while page says Files | Fixed in source | The navigation destination now says Files. |
| 20 | Settings exposes developer-only messaging text and becomes stale after Android settings | Fixed in source | Developer diagnostics text was removed; notification state refreshes when the app resumes. |
| 21 | Contact Info link counting mishandles URLs; documents lack names | Fixed in source | Link extraction strips surrounding punctuation and counts occurrences rather than unique URL strings; document tiles expose and display filenames. |
| 22 | Plain-text messages repeatedly run JSON decoding during rebuilds | Fixed in source | Media-envelope checks reject ordinary text before JSON decoding in the shared-media and Contact Info helpers. The voice-recording timer still causes periodic UI updates, but those updates no longer parse plain text as JSON. |
| 23 | Contact Info and Files load the entire message history repeatedly | Bounded in source | Contact Info now reads at most 500 recent messages and refreshes metrics every 30 minutes; Files scans at most 2,000 recent messages. Older shared items beyond those limits will not appear in these dashboards. |
| 24 | Temporary cleanup can delete camera recovery files; Stickers bucket is empty | Fixed in source | Temporary cleanup only deletes allowlisted disposable Likedin-generated files; camera and active voice files are excluded. The empty Stickers storage category was removed. |
| 25 | Incoming-call dialog may call setState after dispose | Hardened in source | Mounted checks were added after awaited call-status, audio-stop, renderer-initialization, and speaker/proximity operations. Confirm by rapidly closing the call dialog during setup. |
| 26 | Video viewer may play a disposed controller | Fixed in source | Initialization completion now returns when the viewer is no longer mounted before calling play. |
| 27 | Join-call failure misreports an ended call as a connection problem | Fixed in source | A no-longer-ringing call now clears the banner and reports that the call ended; other failures retain the connection guidance. |
| 28 | Backup/recovery text controllers are disposed immediately after dialogs | Hardened in source | Controller disposal is deferred to the next frame after each dialog closes. |
| 29 | Home pull-to-refresh leaks an error while offline | Fixed in source | Refresh errors are caught and the last displayed news Future is restored. |
| 30 | Deleted messages can still be swiped to reply | Fixed in source | Deleted messages no longer attach a reply callback or drag handlers. |

## Android/build configuration

- The app module now applies `org.jetbrains.kotlin.android`; `settings.gradle.kts` already declares Kotlin plugin version `2.4.0`.
- The source still declares `supabase_flutter: ^2.9.1` and uses `Supabase.initialize(publishableKey: ...)`. Dependency resolution and compilation were not run in this environment, so the resolved package/API combination remains to be confirmed by the supplied GitHub workflow.
- Android manifest XML and the workflow YAML passed parser checks.

## Regression tests added

`test/chat_info_metrics_test.dart` now covers link punctuation removal, repeated URL occurrences, and locally hidden messages addressed by a client-message ID. These tests are included in the source archive but were not executable without Flutter/Dart.

## Not included in this bug-fix pass

Claude's minor gaps (a separate display-name editing page and encrypted-backup restore) were not implemented. Backup restore changes how historical messages are reinserted and needs a defined merge/duplicate policy before it is safe to add. The legacy internal payload label `project-whisper-backup` was left unchanged to avoid breaking existing local data or exports.
