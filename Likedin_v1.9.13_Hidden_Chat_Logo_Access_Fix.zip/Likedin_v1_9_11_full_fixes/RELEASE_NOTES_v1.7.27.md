# Likedin 1.7.27

## Changes
- Chat image attachments now render as larger inline previews and open in an interactive full-screen viewer.
- Video attachments render as play tiles and open in an in-app video player.
- Attachment downloads now use Android MediaStore Downloads, placing files in the public Downloads folder.
- Removed the green dot from launcher icon artwork.

## Validation
- Source-level edits and ZIP CRC integrity checked.
- Flutter compilation/device testing was not available in this environment. Verify through the existing GitHub Actions workflow before installing.
