LIKEDIN v1.5 — CHAT + PUSH UPDATE

This ZIP contains:
- Firebase Android config for project likedin-c6682
- Google Services Gradle plugin setup
- Chat state update to avoid FutureBuilder full-page loading refreshes on send
- Read receipts only when the Chat tab is visible and app is resumed
- Delivery acknowledgements after app synchronization
- Foreground push suppression while the conversation is open
- Notification tap routing to the Chat tab
- Supabase Edge Function source for sending generic FCM notifications
- Setup and two-device test instructions in docs/V1_5_PUSH_AND_CHAT_FIXES.md

IMPORTANT:
The Edge Function must be deployed and the Supabase Database Webhook configured before background push can work. Firebase service-account JSON and Supabase service-role keys are intentionally NOT included. Do not put either secret in the APK or repository.

Build status: source-only package; not compiled in this environment. Follow the setup guide, build with GitHub Actions, then test on both Android phones.
