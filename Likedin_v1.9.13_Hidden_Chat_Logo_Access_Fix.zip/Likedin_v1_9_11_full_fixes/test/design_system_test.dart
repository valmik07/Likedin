import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/ui/glassmorphism.dart';

double _contrast(Color a, Color b) {
  final la = a.computeLuminance();
  final lb = b.computeLuminance();
  final hi = la > lb ? la : lb;
  final lo = la > lb ? lb : la;
  return (hi + .05) / (lo + .05);
}

void main() {
  group('Obsidian / Arctic accent contrast', () {
    for (final accent in likedinAccents) {
      test('${accent.name}: accent text is readable on both themes', () {
        expect(
          _contrast(accent.dark, likedinSurface(Brightness.dark)),
          greaterThanOrEqualTo(4.5),
        );
        expect(
          _contrast(accent.light, likedinSurface(Brightness.light)),
          greaterThanOrEqualTo(4.5),
        );
        expect(
          _contrast(accent.light, likedinSurfaceRaised(Brightness.light)),
          greaterThanOrEqualTo(4.5),
        );
      });
    }

    test('primary gradient keeps white labels readable for every accent', () {
      final original = LikedinAppearance.accentIndex.value;
      addTearDown(() => LikedinAppearance.accentIndex.value = original);
      for (var i = 0; i < likedinAccents.length; i++) {
        LikedinAppearance.accentIndex.value = i;
        for (final brightness in Brightness.values) {
          for (final stop in likedinPrimaryGradient(brightness).colors) {
            expect(
              _contrast(Colors.white, stop),
              greaterThanOrEqualTo(4.5),
              reason: '${likedinAccents[i].name} / $brightness',
            );
          }
        }
      }
    });
  });

  test('body text has strong contrast on both theme backgrounds', () {
    for (final brightness in Brightness.values) {
      expect(
        _contrast(likedinOnSurface(brightness), likedinBackground(brightness)),
        greaterThanOrEqualTo(7),
      );
      expect(
        _contrast(likedinMutedText(brightness), likedinSurface(brightness)),
        greaterThanOrEqualTo(4.5),
      );
    }
  });
}
