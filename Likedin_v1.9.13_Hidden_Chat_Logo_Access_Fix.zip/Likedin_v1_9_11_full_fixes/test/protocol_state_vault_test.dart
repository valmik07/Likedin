import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:likedin/security/protocol_state_vault.dart';

class MemorySecureStorage extends FlutterSecureStorage {
  final Map<String, String> values = {};
  @override
  Future<String?> read({required String key, IOSOptions? iOptions, AndroidOptions? aOptions, LinuxOptions? lOptions, WebOptions? webOptions, MacOsOptions? mOptions, WindowsOptions? wOptions}) async => values[key];
  @override
  Future<void> write({required String key, required String? value, IOSOptions? iOptions, AndroidOptions? aOptions, LinuxOptions? lOptions, WebOptions? webOptions, MacOsOptions? mOptions, WindowsOptions? wOptions}) async {
    if (value == null) { values.remove(key); } else { values[key] = value; }
  }
  @override
  Future<void> delete({required String key, IOSOptions? iOptions, AndroidOptions? aOptions, LinuxOptions? lOptions, WebOptions? webOptions, MacOsOptions? mOptions, WindowsOptions? wOptions}) async => values.remove(key);
  @override
  Future<Map<String, String>> readAll({IOSOptions? iOptions, AndroidOptions? aOptions, LinuxOptions? lOptions, WebOptions? webOptions, MacOsOptions? mOptions, WindowsOptions? wOptions}) async => Map.of(values);
}

void main() {
  test('device id is stable', () async {
    final storage = MemorySecureStorage();
    final vault = ProtocolStateVault(storage: storage);
    final first = await vault.getOrCreateDeviceId();
    expect(await vault.getOrCreateDeviceId(), first);
  });

  test('opaque protocol state round-trips', () async {
    final vault = ProtocolStateVault(storage: MemorySecureStorage());
    final bytes = <int>[0, 1, 2, 127, 255];
    await vault.writeState('identity_store', bytes);
    expect(await vault.readState('identity_store'), bytes);
  });

  test('invalid namespace is rejected', () async {
    final vault = ProtocolStateVault(storage: MemorySecureStorage());
    expect(() => vault.readState('../private'), throwsArgumentError);
  });
}
