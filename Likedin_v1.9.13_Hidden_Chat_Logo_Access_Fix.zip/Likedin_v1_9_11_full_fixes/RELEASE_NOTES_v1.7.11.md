# Likedin 1.7.11

## Fix
- Show the **Edited** label on both devices using the server-synchronized `messages.edited_at` timestamp. Previously the label depended on device-local edit metadata, so the receiving phone could show the updated message text without the label.

## Backend
- No new SQL migration required. Uses the existing `edited_at` column populated by `likedin_edit_message`.
- No GitHub Actions workflow changes required.
