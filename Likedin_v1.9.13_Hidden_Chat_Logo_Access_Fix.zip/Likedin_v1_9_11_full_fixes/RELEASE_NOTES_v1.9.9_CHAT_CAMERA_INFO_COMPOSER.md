# Likedin v1.9.9+95 — Chat camera, contact info and adaptive composer

## Frontend changes
- Added a Camera option to the chat attachment sheet. Captured photos can be previewed, retaken or sent through the existing shared-media preparation and retry queue.
- Tapping the chat name opens a dedicated Contact Info screen with the peer avatar, presence, shared media summary, storage access, nickname editing and the existing device-local Clear Chat action.
- Kept the avatar tap dedicated to the existing full-screen profile photo viewer.
- Combined the voice-record and send affordance into one adaptive composer action: hold the microphone when the message field is empty; use Send when text is present.

## Preserved behaviour
- Existing Supabase schema, RPCs, storage buckets, authentication, message delivery, calls, notifications and security configuration are unchanged.
- Existing gallery, file, GIF, sticker, reply, edit and voice-message paths are retained.
- No SQL or backend migration is included.

## Build
- App version: 1.9.9+95
- Android toolchain: AGP 9.1.0 / Gradle 9.3.1 / Kotlin 2.4.0 / compileSdk 36 / minSdk 30
