# Likedin v1.8.3 — Regression test plan

Run after the SQL migration and Edge Function deployments, on both Android devices.

## Chat and presence
- Open chat with both phones online; verify Online updates to Offline within about 90 seconds after force-stopping the peer app.
- Type on one phone, then stop typing without sending; verify Typing… disappears within five seconds on the other phone.
- Start chat before the peer has completed registration/confirmation, then finish registration; verify peer lookup attaches without restarting the app.
- Force-stop/restart after secure-storage state exists; verify a storage-decryption error does not blank the conversation.
- Send 10,000 code points, including supplementary-plane emoji and combining marks; verify it is accepted. Attempt 10,001 and verify it is blocked. Repeat for edit.
- Start a large attachment upload, then send a text message before the upload completes; verify the text goes through independently.

## Signup and account slots
- With one confirmed account and one free slot, start signup on the second device and confirm the email. Verify the pending signup reserves the remaining slot and becomes the second approved member after confirmation.
- Try a third signup while both slots are reserved/confirmed; verify signup preflight reports that both slots are occupied.
- In a non-production test project, create an unconfirmed signup older than 48 hours, call `likedin_can_register_account()`, and verify the expired Auth user is removed and the slot becomes free.
- Verify the `emailRedirectTo` link opens the app through `com.example.likedin://login-callback/`.

## Media and deletion
- Scroll to a video message on a metered connection; verify it does not download until tapped.
- Scroll to a voice note; verify it does not download until Play is tapped.
- Delete an uploaded media message for everyone. Verify the message becomes a tombstone, the sender's Storage object is removed, and both devices remove the cached file. Repeat after force-stopping the recipient before deletion; on next startup/resume, the paginated tombstone sweep must also clear cached files for messages older than the visible 100-message page.
- Repeat delete while offline after the tombstone is committed; reconnect and reload chat to verify remote deletion retries.
- Add profile photos to each account, sign out/in between accounts on the same device, and verify the other account's image is never shown.

## Calls
- Accept an audio and video call normally; verify connected state/timer begins only after WebRTC connection state reports connected.
- Force an ICE/connection failure; verify Supabase stores `failed` (not `ended`) and Call History displays 'Call failed'.
- Force a renderer or permission failure before answer; verify the call becomes rejected, no second Accept action remains, and the caller receives a terminal state rather than an indefinite ring.
- Drop Realtime temporarily during answer/ICE exchange; verify catch-up queries recover signaling.
- While a call dialog is open, start another call from a second tab; verify a second peer connection/dialog is not created.
- Press Android Back while ringing and while connected; verify the call is declined/ended server-side and the other phone exits ringing.

## Push, policies, and release
- Send a message while the receiver app is backgrounded/closed; verify Delivered ticks update without opening the app.
- Verify a bad webhook secret receives HTTP 401 and the configured secret still allows all three push functions.
- Verify only the two approved accounts can read profiles/messages/calls/signals/reactions and only the object owner can delete their own `likedin-media` file.
- Verify Storage upload/read still works for both pair accounts and other storage buckets are not affected.
- Run `flutter analyze --fatal-warnings` and `flutter test`; build the signed ARM64 release APK through CI.

## Known platform limitation

A fully killed Android app may only play the OS-delivered notification sound once. Looping background ringtone and guaranteed lock-screen takeover are not claimed by this release; test OEM-specific notification behavior separately.
