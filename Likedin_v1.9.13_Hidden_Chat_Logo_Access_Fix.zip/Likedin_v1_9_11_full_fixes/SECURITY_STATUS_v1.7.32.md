# Security status — 1.7.32

## Implemented in source
- Local SQLite message bodies are encrypted with AES-256-GCM.
- Local encryption key is stored via flutter_secure_storage (Android Keystore-backed).
- Encrypted backup codec uses PBKDF2-HMAC-SHA256 (310,000 iterations) and AES-256-GCM.
- Storage bucket is private; object access is governed by Supabase Storage RLS.
- Public client config contains a publishable/anon key, not a service-role key.

## Not implemented / must not be represented as complete
- E2EE: explicitly excluded by product decision. Supabase message payloads are plaintext at application layer.
- Full conversation backup export/restore UI and orchestration: not integrated.
- Production release signing: current Gradle config uses debug signing.
- A full backend penetration test and live RLS verification cannot be established from client source alone.

## Required owner-side verification
1. Supabase: inspect RLS on messages, profiles, reactions, account_slots, storage.objects and all exposed RPC functions.
2. Verify only the two intended authenticated accounts can read/write each other's permitted records.
3. Verify no service-role or secret key appears in source, Git history, workflow logs or APK.
4. Test logout/session expiry and account switching on both devices.
5. Test local database contents do not contain readable message bodies.
6. Test backup with a strong passphrase, wrong passphrase, tampered bytes, and restore to a replacement device.
7. Before public distribution, configure a private upload/release keystore and store signing secrets only in GitHub Actions secrets.
