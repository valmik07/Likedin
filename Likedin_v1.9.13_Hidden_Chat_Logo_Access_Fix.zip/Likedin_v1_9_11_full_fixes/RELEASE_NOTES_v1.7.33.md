# Likedin 1.7.33 — notification icon and background push configuration

- Added a dedicated monochrome Android notification status-bar icon (`@drawable/likedin_notification`).
- Configured Firebase Messaging's default notification icon in the Android manifest.
- Updated local-notification initialization to use the same Likedin icon.
- Preserved the existing FCM token registration, message/call handlers, Supabase sender functions, R8/resource shrinking, and ARM64 GitHub Actions build route.
- No end-to-end encryption implementation or roadmap is included.

## Important delivery boundary

This source update fixes the app-side notification icon configuration. It does not by itself deploy Supabase Edge Functions, database webhooks/triggers, Firebase service-account secrets, or guarantee delivery on every device. The included `send-message-push`, `send-incoming-call-push`, and `send-missed-call-push` functions must be deployed to the user's Supabase project and configured with the required secrets/webhooks. Both devices must open Likedin at least once after installing so FCM tokens can register.

High-priority FCM can notify when the app is backgrounded, swiped from recents, or the screen is locked, subject to network, notification permission, battery/OEM restrictions, and FCM delivery. Android force-stop generally blocks delivery until the app is manually opened again.

## Validation status

The archive is structurally checked. Flutter analyze/tests, Android release compilation/R8, and physical-device push delivery have not been run in this environment. Confirm these through the existing GitHub Actions workflow and tests on both phones.
