# Phase 1 status — 1.7.10 client integration

Client integration is now wired for server-backed reply metadata, message edits, reactions, and delete-for-everyone tombstones. Apply the additive migration `202611140001_v1710_client_sync_integration.sql` before testing.

The app's chat refresh reloads message rows and reactions. Realtime listens for message and reaction changes. Replies are linked by message UUID, not copied quote text. Deleted messages remain as rows and render as a deleted-message placeholder.

Not included: offline outbox/retry queue, cross-device media, call history/push missed-call handling, video-call redesign, full security audit, and E2EE.
