# Hidden Chats Frontend Audit — v1.9.13

## Required navigation behaviour

- Home no longer displays a hidden-chat tile, unlock button, or ordinary conversation row while the conversation is hidden.
- The Home-header Likedin logo is the sole entry point. It requests password verification when the in-memory session is locked.
- After verification, a dedicated Private chat list page renders the existing ConversationCard in hidden mode.
- Tapping that card opens the existing full ChatPage. Returning to Home does not relock the session; the logo opens the list again without another password prompt.
- Unlock state is held only in `_AppShellState` memory. No timer, pause timeout, or tab-switch lock remains. A newly created app process starts locked.
- Calls is omitted from the bottom NavigationBar while any hidden-chat ID exists. Incoming-call alerts/acceptance remain separate and are not disabled.
- Normal notification taps cannot enter the hidden conversation directly. Calls/history shortcuts route back to Home while the Calls tab is absent.
- The Home compose shortcut is removed while hidden chats exist.
- Files cannot initiate hidden-area authentication itself; the logo must unlock the session first. Files can then be used during that process session, subject to the existing media filtering.
- The private list supports unhide and password change.

## Files changed

- `pubspec.yaml` — version `1.9.13+99`.
- `lib/main.dart` — process-lifetime session; logo-only entry; dedicated private-page routing; no background or elapsed-time lock; Calls-tab suppression; notification/shortcut route guards; system-back handling.
- `lib/ui/home_page_part.dart` — removes the visible hidden-chat card and adds `HiddenChatsPage`.
- `lib/ui/conversation_card.dart` — hidden-mode Unhide action and updated hide guidance.
- `lib/ui/hidden_chat_pin_dialog.dart` — custom title for password changes.
- Release notes and upload instructions.

## Backend scope

No Supabase SQL, schema, RLS, Storage policy, Edge Function, or remote message-row changes.

## Validation caveat

Flutter analyzer, widget/unit tests, and APK compilation were not run in this environment because the Flutter/Dart SDK is unavailable. GitHub Actions and physical-device validation remain necessary.
