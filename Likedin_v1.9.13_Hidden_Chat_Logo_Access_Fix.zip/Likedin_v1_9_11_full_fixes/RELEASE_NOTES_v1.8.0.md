# Likedin v1.8.0 — Core reliability release

**Version:** `1.8.0+77`  
**Baseline:** `Likedin_v1.7.46_Daily_Briefing_and_Backend_Parity.zip`  
**Release goal:** address the three P1 audit findings and the P2 defects most likely to interrupt sign-up, messaging, media delivery, calling, and push handling.

## Included in this release

### P1 — high priority

- **A01 — Unverified signup slot reservation:** unconfirmed Auth rows no longer consume one of the two permanent pair slots. Slot/profile assignment happens only when a user is confirmed; the migration preserves Auth users and fails visibly if it discovers more than two already-confirmed accounts.
- **A02 — TURN credential exposure:** the TURN endpoint now verifies approved pair membership and rate-limits credential requests. Temporary Coturn REST credentials are supported behind an explicit opt-in. The legacy static credential path remains the default so the currently documented ExpressTURN static-credential setup is not silently changed. This finding is therefore **partially mitigated**, not fully closed, until a TURN provider supporting the shared-secret REST mechanism is configured and tested.
- **A03 — Server-owned no-answer expiry:** a database function marks ringing calls as missed after 60 seconds. The existing missed-call status trigger remains responsible for the missed-call push. Supabase Cron scheduling is attempted by migration when available; Dashboard setup is required if Cron is not enabled or the automatic schedule is rejected.

### P2 — functionality/reliability

- **A04/A05 — Media retry ownership and recovery:** retry jobs are account-bound, legacy ownerless jobs are quarantined rather than guessed, and a single-flight retry processor runs at authenticated startup, app resume, and connectivity restoration. Failed jobs use exponential backoff.
- **A06 — Voice-message durability:** recordings are copied to app-private persistent storage and sent through the same durable, account-bound media outbox with a stable message ID.
- **A07 — ICE candidate deduplication:** answerer snapshot and realtime ICE events are deduplicated by signal row ID.
- **A08 — Call terminal failure consistency:** connection/signaling failures use one idempotent cleanup path that attempts to persist `ended`, then stops call resources and publishes local failure state.
- **A09 — Decline ordering:** the call status is committed before the best-effort reject signal, so a signaling failure cannot skip the backend rejection.
- **A10 — Text-send idempotency:** retrying an ambiguous text send reuses the same pending client message ID and reconciles against the server before sending again.
- **A13 — TUS conflict verification:** HTTP 409 is not accepted by status code alone; the exact Storage object must exist and match the queued file size.
- **A14 — Firebase background-handler recovery:** Firebase bootstrap is centralized and idempotent; a later successful initialization also registers the background handler.
- **A17 — Pair membership enforcement:** profile, peer lookup, message, call, signaling, reaction, presence, receipt, push-token, media Storage, and TURN paths now check approved pair membership. Existing broad direct call/message update policies are not reintroduced.
- **A21 — Composer message limit:** the composer enforces the server's 10,000-character limit, displays a counter near the limit, and the messaging service validates it again before making the RPC.
- **A11 — Reaction query scope:** reactions are now fetched only for IDs in the loaded message page. Conversation history remains capped at 500 until keyset pagination is implemented.

## Deliberately unchanged

- No E2EE was added. The existing product decision to not use E2EE remains in force.
- Android application ID remains `com.example.likedin`; do not change Firebase/package identity as part of this reliability pass.
- Android minimum remains API 30.
- The general chat activity is not allowed to appear over the lock screen. No `showWhenLocked` or `turnScreenOn` restoration was made.
- Existing ExpressTURN-style static credentials remain the default. Do not enable the temporary credential mode unless the configured TURN provider explicitly supports Coturn REST shared-secret authentication.

## Deferred audit items

These are not represented as fixed in v1.8.0: A11 keyset pagination beyond 500 rows; A12 remote Storage object deletion after delete-for-everyone; A15 connecting the dormant encrypted SQLite store to the live chat path (or explicitly removing that claim); A16 call-signaling retention; A18 lockfile/strict CI/test expansion; A19 stale briefing fallback; A20 RSS parser/URL validation; A22 constant-time webhook secret checks; A23 documentation cleanup and project-neutral webhook URLs; A24 final package identity; A25 local release-signing fallback; A26 Play full-screen-intent declaration.

## Verification boundary

The source changes have been inspected, but this environment does not have Flutter, Dart, Deno, a live Supabase connection, Android SDK build tooling, or the user's devices. This package has **not** been compiled, run through `flutter analyze`, tested against a live Supabase project, or physically tested. A successful GitHub Actions build and live regression testing are still required before treating v1.8.0 as validated.
