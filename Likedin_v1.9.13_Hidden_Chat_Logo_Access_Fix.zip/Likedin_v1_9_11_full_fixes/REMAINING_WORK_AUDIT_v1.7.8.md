# Likedin 1.7.8 candidate — audit findings

1. `lib/backend/realtime_messaging_service.dart` reads `encrypted_payload` and sends
   `p_payload`; the initial active schema migration defines `ciphertext` and `nonce`.
   The new compatibility migration restores the older RPC/table contract, but the
   transport remains plaintext.
2. `lib/security/protocol_state_vault.dart` stores opaque serialized state only.
   No Signal Protocol engine or stores are implemented.
3. E2EE acceptance tests are absent: no two-device session test, tamper test,
   replay/duplicate ratchet test, identity-change test, or server ciphertext audit.
4. `docs/REMAINING_WORK_AUDIT_v1.7.7.md` remains applicable for attachments,
   backup/restore, pairing/feed and call hardening.
5. Android APK size and ABI contents require inspection of the produced APK; do
   not infer APK size from compressed artifact ZIP size.

## Release status
This is a compatibility/engineering candidate, NOT an E2EE-complete release.
A reviewed Signal Protocol integration is still required before making any E2EE claim.
