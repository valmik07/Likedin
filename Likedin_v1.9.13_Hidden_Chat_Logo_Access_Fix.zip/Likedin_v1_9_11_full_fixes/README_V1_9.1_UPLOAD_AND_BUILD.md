# Likedin v1.9.1+90 — Upload and Build

1. Keep this ZIP as the only root-level project ZIP in the GitHub repository.
2. Replace the workflow under `.github/workflows` with `likedin_workflow_option_A_v1.9.1.yml`.
3. Run **Likedin Android APK** on `main`.
4. Review the Analyze, Test and Release APK steps before installing.

This release aligns the shared header and bottom navigation with the app-wide background. It retains the v1.9.0 gallery, Gboard media insertion and low-memory changes. Option A signing is used; no GitHub signing secrets are required.
