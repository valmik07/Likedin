# Likedin v1.8.3 — Dart analyzer cleanup

This patch addresses the 42 analyzer findings reported by the v1.8.3 CI analysis run. It changes style/deprecation warnings and one unused import; it does not intentionally change app behavior.

## Changes

- `lib/backend/realtime_messaging_service.dart`: replace three `+`-joined PostgREST filter fragments with adjacent string literals.
- `lib/backend/shared_media_service.dart`: import `package:flutter/foundation.dart` for `debugPrint`; make the immutable `HttpException` const.
- `lib/data/local_message_store.dart`: use const constructors for `FlutterSecureStorage` and `Uuid`.
- `lib/main.dart`:
  - replace deprecated `anonKey` initialization parameter with `publishableKey` (the existing configured legacy anon key remains the value; Supabase documents legacy anon keys as valid with this parameter);
  - replace deprecated `Color.withOpacity` calls with `Color.withValues(alpha: ...)`;
  - use adjacent string literals for the composite PostgREST filter;
  - add braces to single-statement `if` bodies flagged by the analyzer;
  - capture `ScaffoldMessengerState` before awaiting the media download, then use `mounted` guards before showing snackbars.
- `lib/notifications/notification_service.dart`: use `publishableKey` and remove the redundant foundation import, since the used Flutter foundation symbols are already exported by `widgets.dart` in this file.

## Validation note

The reported analyzer output from the user's Windows environment had no compilation errors after the missing `debugPrint` import was added, but it still reported 42 informational/lint issues. This patch targets all 42 findings from that exact output. The packaging environment used to prepare this patch does not have Flutter or Dart installed, so a fresh `flutter analyze`, `flutter test`, and Android build must still be run in the user's Flutter environment / GitHub Actions before release.
