# Likedin 1.7.24 — upload diagnostics, video layout and rotating news

- Increased the client-side shared-media limit to 50 MB to match the verified private Supabase bucket setting.
- Preserved queued files after failed uploads and surfaced the underlying exception in the chat snackbar for diagnosis.
- Improved file-picker failure reporting when Android does not provide a readable local path.
- Updated the outgoing connected video-call layout to use a full-area remote video with a floating local preview, matching the incoming call visual pattern.
- Replaced the home-page placeholder with a live Google News RSS feed, deduplicated and sorted by publication date. The feed shows five stories per day from a 15-story, three-day rotation; refresh retries the feed request.

## Verification

Source-level changes only. Flutter/Dart SDK is not available in this workspace, so `flutter analyze`, unit tests, Android build, and on-device upload/call/news tests have not been run. GitHub Actions remains the build path.
