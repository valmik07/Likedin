# Likedin security audit — source review, v1.7.31

Date: 2026-11-15  
Scope: Flutter client source, checked-in Supabase migrations, Android Gradle configuration and the stated two-account deployment model. This is a static source review, not a penetration test or independent cryptographic audit.

## Executive result

**Do not describe this build as end-to-end encrypted.** The client currently sends the clear message body as `p_payload` to `likedin_send_message_v2`. Supabase stores it in `messages.encrypted_payload`, but that column name does not make its contents ciphertext. TLS protects transport in transit; it does not prevent the backend/database operator or a privileged database role from reading message bodies.

The project has useful groundwork (Android secure-storage wrapper, AES-GCM local SQLite message-body encryption, an encrypted-backup codec, a protocol-state vault and a public device-key registry migration), but the E2EE protocol adapter, real backup/restore workflow and acceptance tests are not integrated.

## Findings

### Critical — remote messages are plaintext at the application layer
- `lib/backend/realtime_messaging_service.dart`: `sendMessage()` passes `clean` directly as `p_payload` to `likedin_send_message_v2`.
- `RemoteMessage.fromMap()` reads `body_payload`, `encrypted_payload` or `ciphertext` as a string without authenticated decryption.
- `docs/E2EE_IMPLEMENTATION_CONTRACT.md` and `docs/SIGNAL_INTEGRATION_PLAN.md` correctly state that this is legacy plaintext transport and require fail-closed encryption before claiming E2EE.
- Impact: backend/database access can expose message contents. TLS is not E2EE.
- Required remediation: integrate a vetted Signal Protocol implementation; encrypt before RPC; decrypt only on recipient device; reject plaintext fallback; persist ratchet state transactionally; verify identity changes and safety numbers.

### High — encrypted backup codec is not a backup product
- `lib/security/encrypted_backup_codec.dart` provides PBKDF2-HMAC-SHA256 (310,000 iterations) + AES-256-GCM envelope encryption/decryption.
- `lib/data/local_message_store.dart` can create a JSON payload from its local SQLite message table.
- Settings explicitly say backup export/restore controls are unavailable. No complete file export/import UI or restore transaction is wired into the app.
- The current local SQLite store is not the same as the authoritative Supabase conversation history shown by the chat UI. A local-store export alone would not constitute full conversation backup.
- Required remediation: define backup scope, export remote history plus required local state and media references, encrypt the complete archive, validate schema and identity on restore, use atomic staging/commit, reject wrong passphrases/tampering, and document what cannot be restored. Never include private E2EE keys in a plaintext archive.

### High — Android release signing uses debug signing configuration
- `android/app/build.gradle.kts` sets the release `signingConfig` to `signingConfigs.getByName("debug")`.
- Impact: unsuitable for a production release, poor key custody and upgrade/release continuity.
- Required remediation: create a private release keystore outside the repository, load credentials from GitHub Actions secrets, and verify signing certificate continuity. Never commit the keystore or passwords.

### Medium — local account password hashing is a bespoke local registry
- `lib/auth/local_account_store.dart` uses PBKDF2-HMAC-SHA256 with 80,000 iterations and stores salt/hash in secure storage.
- This is a local device account registry, not the Supabase authentication authority. Do not treat it as a substitute for server authentication or a modern password-hashing service.
- Before changing the KDF, implement a versioned hash record and successful-login rehash migration; a blind iteration change would lock out existing local accounts.

### Medium — local message encryption key handling
- `lib/data/local_message_store.dart` encrypts local message bodies using AES-GCM and stores the 256-bit key as base64 in `flutter_secure_storage`.
- This is at-rest protection dependent on the Android Keystore-backed plugin implementation and device state. It is not E2EE and does not protect data while plaintext is in app memory.
- Verify the resolved plugin version and Android options in a real release build; test backup/restore, uninstall/reinstall and device migration behavior before relying on it.

### Medium — broad call signaling surface needs adversarial testing
- Call tables have RLS policies limiting reads/updates to participants and inserts to the caller/sender. Validate all transitions, especially whether a participant can mutate fields beyond status/timestamps and whether malformed SDP/ICE payloads can cause resource exhaustion.
- Signaling payloads are not end-to-end encrypted by the chat message protocol. WebRTC media encryption properties and TURN configuration must be checked separately.

### Medium — storage policies depend on deployment state
- Checked-in shared-media migration creates a private bucket, sender-folder INSERT policy, paired-account SELECT policy and owner DELETE policy.
- The user's live project required an additional UPDATE policy and a SECURITY DEFINER membership lookup workaround during troubleshooting; those live changes are not automatically represented in this source tree. The deployment SQL must be reconciled with the live database before release.
- Do not make the bucket public. Confirm `file_size_limit=52428800`, MIME restrictions, INSERT/SELECT/UPDATE/DELETE behavior and cross-account denial in the live project.

### Low — diagnostic logging
- Several catch blocks use `debugPrint` for exception text. Review logs before release to ensure no access tokens, signed URLs, SDP, message bodies or key material are included. Do not log secrets while adding diagnostics.

## Positive controls observed
- Local message bodies are encrypted with AES-GCM before SQLite insertion.
- Secure storage is used for local account material, local message key and protocol-state placeholders.
- Media bucket is configured private in checked-in migration.
- Message and media access policies are present in checked-in migrations; server RPCs validate authentication and the two-account membership for send operations.
- SECURITY DEFINER functions generally set an empty `search_path` and revoke PUBLIC execute before granting authenticated access.
- The E2EE contract explicitly prohibits custom home-grown ratchets and plaintext fallback.

## Release decision

**Not approved as an E2EE-secure or production-signed release.** Functional messaging/calling may be used for acceptance testing with the understanding that remote message content is readable to the backend. Do not send highly sensitive material until E2EE is implemented and independently tested. Complete the release signing, backup/restore and live RLS reconciliation before production use.
