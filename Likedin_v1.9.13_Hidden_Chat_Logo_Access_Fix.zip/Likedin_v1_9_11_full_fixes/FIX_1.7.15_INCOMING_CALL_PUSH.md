# Likedin 1.7.15 — Incoming-call notification fallback

## What changed
- Incoming-call FCM now includes both a visible notification payload and the existing routing data.
- Android is explicitly directed to the existing `likedin_calls_v1` channel, with the `likedin_call` sound and high-priority/public notification settings.
- This restores an OS-rendered incoming-call notification when the app is backgrounded and the Dart background isolate cannot start.
- FCM send results now return attempted/sent counts and non-token failures for diagnosis.
- No database migration or new secrets are required.

## Backend
Replace the existing Supabase Edge Function `send-incoming-call-push` with:
`supabase/functions/send-incoming-call-push/index.ts`

Deploy:
```bash
supabase functions deploy send-incoming-call-push
```
Keep Verify JWT OFF and retain the existing `LIKEDIN_PUSH_WEBHOOK_SECRET` and `FIREBASE_SERVICE_ACCOUNT_JSON` secrets.

## Android test
1. Install the 1.7.15 APK on both phones.
2. Ensure Likedin notifications are allowed and the `Likedin calls` notification channel is enabled with sound.
3. Test app foreground, background, swiped away, and locked.
4. Tap the incoming-call notification and confirm it opens the app/call flow.

## Important platform limitation
This fallback restores OS-rendered incoming-call notifications and ringtone while backgrounded. A true Android full-screen incoming-call activity while locked is a separate native incoming-call UI/Telecom integration and is not guaranteed by an FCM notification payload alone. Android 14+ also controls full-screen intent access per app. Do not treat HTTP 200 from Supabase as proof that the device displayed the notification.
