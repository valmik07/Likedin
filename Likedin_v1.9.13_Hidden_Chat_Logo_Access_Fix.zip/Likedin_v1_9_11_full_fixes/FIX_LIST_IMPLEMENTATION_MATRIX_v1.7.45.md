# v1.7.44 fix-list implementation matrix → v1.7.45

| PDF item | Area | Source action |
|---:|---|---|
| 1 | Android resources | Added `res/raw/keep.xml`; retained the notification icon and both custom sounds; added notification-plugin R8 keep rule. |
| 2 | Missed calls | Changed missed-call FCM to data-only; `missed`/pre-answer `ended` becomes missed alert; `rejected` cancels the ringing alert. |
| 3 | FCM token ownership | Added `likedin_register_push_token(text)`, account migration, unregister on sign-out, and refresh registration in Settings. |
| 4 | Startup | Registered the background handler before `runApp`; permission and token operations are detached; notification listeners are attached once. |
| 5 | Notification IDs | Bounded IDs to positive 31-bit values and made call IDs deterministic across Flutter isolates. |
| 6 | Full-screen intent | Stored a one-time prompt marker in SharedPreferences. |
| 7 | Database triggers | Push calls are wrapped in exception handlers; message/call records sent to webhooks contain IDs/metadata only. |
| 8 | Background Supabase | Background isolate initializes Supabase only when the client is not already initialized. Firebase is initialized if needed. |
| 9 | Push documentation | Corrected the visible-notification payload comment in `send-message-push`. |
| 10 | Chat send | Only the message RPC failure rolls back the optimistic send; later typing/reload errors no longer report a successful send as failed. |
| 11 | Chat realtime | Subscribes before loading messages; optional refresh/presence/call tasks are isolated. |
| 12 | Call cleanup | Failed start/accept setup transitions to a terminal status and disposes resources; accepted-but-unsent answer becomes ended; null call IDs are guarded. |
| 13 | Background calls | Added Android microphone/camera foreground service and start/stop MethodChannel calls. |
| 14 | Media | Handles TUS 409 as already uploaded, drops missing retry files, and streams downloads to disk. |
| 15 | Downloads | Runs MediaStore copy work on a worker thread and reports on the UI thread. |
| 16 | RLS | Drops the broad messages/calls UPDATE policies named in the PDF; uses existing SECURITY DEFINER mutation RPCs. |
| 17 | Realtime | Added idempotent membership for messages, profiles, calls, call signals, and reactions. |
| 18 | Migration order | Adds `read_at` before the unread index needs it. |
| 19 | Signup | Creates the profile and claims one of two existing account slots; backfills existing accounts under the existing advisory lock. |
| 20 | Release signing | CI requires a single persistent keystore via four GitHub secrets; no silent fresh-runner debug-key fallback. |
| 21 | Version/news | Uses one `likedinVersion` constant and daily briefing cache rotation. |
| 22 | Housekeeping | Removed stale generated plugin registrar from the source archive; E2EE remains outside this product plan; push payloads exclude message text. |

## Intentionally not claimed as completed

- No Flutter analyzer, Dart tests, Gradle build, Supabase SQL execution, Edge Function deployment, or two-device runtime tests were available in this environment.
- The user must configure the persistent release keystore secrets. A one-time uninstall/reinstall is required when moving from the prior CI debug signature to the new stable signature; preserve any local-only data first.
- The user must apply `202611170001_hardening_and_bootstrap_fixes.sql` and deploy `send-missed-call-push` separately. APK installation alone does not change Supabase.
