# Likedin 1.7.37 — source fixes

This consolidated source update addresses selected high-priority findings from the 1.7.36 static audit and aligns call status writes with the restricted Supabase RPC created during backend remediation.

## Changes
- Conversation loading now requests the newest 500 messages and reverses them into chronological display order, instead of silently loading only the oldest 500.
- First-use media downloads now write the downloaded byte buffer to a temporary cache file before atomic rename.
- Retry-queue processing continues past an individual failed item so one failure does not block later queued attachments.
- Attachment retry metadata preserves the original picked filename.
- WebRTC connection-state handling checks `disconnected` before `connected`, avoiding the substring false-positive.
- ICE candidate send failures are caught rather than becoming unhandled asynchronous errors.
- Call accepted/rejected/missed/ended status transitions now use `likedin_update_call_status` instead of direct table updates. Answering a call whose row is no longer ringing now cleans up local media and aborts.

## Backend prerequisite
The Supabase function `public.likedin_update_call_status(uuid, text)` must exist and be executable by `authenticated`. This was created during the accompanying backend remediation. Do not remove the existing `participants update call` policy until the updated APK has been installed and call flows have been tested successfully.

## Verification limits
The ZIP archive is integrity-checked. Flutter/Dart are not installed in the authoring environment, so `flutter analyze`, `flutter test`, Android compilation, APK size measurement, and physical-device call/media tests have **not** been run here. Run the preserved GitHub Actions workflow and test both caller/callee flows before removing the legacy call UPDATE policy.
