# Likedin v1.8.1 — Core reliability patch

Build version: `1.8.1+78`

This patch addresses the chat-history, shared-media outbox, call lifecycle, notification, and background delivery failures identified in the v1.8.0 core reliability audit.

## What changed

### Chat history and reactions

- The chat now requests history in 100-message pages and loads older pages with a stable `(created_at, id)` keyset cursor when the user reaches the top of the conversation.
- The Files page uses the same keyset paging pattern to scan the full message history rather than stopping after the first 500 rows.
- Reaction lookups split message IDs into groups of 100, keeping each PostgREST `in` query URL well below common gateway URL limits.
- Reaction refresh errors are isolated from message loading. A reaction endpoint failure no longer clears an otherwise successfully loaded conversation.

### Shared-media outbox

- Concurrent queue writes are serialized so an enqueue, retry update, completion, or quarantine cannot overwrite another newly-added queue entry.
- A retry request received while a run is active marks another pass as required. The shared future now resolves only after the follow-up pass has had a chance to process newly-enqueued work.
- Empty or over-50-MB files are rejected before they enter the outbox. Legacy invalid jobs, missing durable files, unrouteable jobs with no paired recipient, and jobs addressed to the wrong account are quarantined and removed from automatic retry.
- MIME types outside the bucket's allow-list are sent as `application/octet-stream`, which is already allowed by the `likedin-media` bucket. Recognized allow-listed types retain their specific MIME type.

### Calls and Android navigation

- Peer connections are created immediately with public STUN servers. The private TURN configuration is fetched with a three-second timeout and applied asynchronously when it becomes available; a TURN outage or rate limit no longer blocks the answer path.
- Android Back on an incoming-call screen commits a rejection before closing. Back during an active call ends the call before closing the screen.
- Android Back from a non-Home tab returns to Home instead of exiting the app.
- Incoming ringing-call rows are reconciled on cold app entry, app resume, and when Chat becomes active. This covers calls inserted while realtime events were not being observed.
- The Chat banner's Join action opens the call screen in auto-accept mode; it no longer restarts the ringtone and waits for a second Accept tap.
- Incoming-call notifications are dismissible (`ongoing: false`, `autoCancel: true`) and time out after 60 seconds.
- Both the chat-banner and full-screen-dialog decline paths now commit `rejected` to the call row before best-effort signaling and notification cleanup.

### Delivered receipts

- `send-message-push` now sends high-priority Android data-only FCM messages. The Android background handler can therefore receive the message, post the local notification, and acknowledge the exact message ID with `likedin_mark_message_delivered` without waiting for the recipient to open Likedin.

## Deployment

1. Build the Android app as `1.8.1+78` using the repository's GitHub Actions workflow.
2. Deploy the changed message-push function:
   `supabase functions deploy send-message-push --no-verify-jwt`
3. No new SQL migration is introduced by this patch. Keep the existing `likedin_mark_message_delivered(uuid)` RPC and the previously-applied call/media migrations in place.
4. Install the build on both paired devices and complete the regression tests in `REGRESSION_TEST_PLAN_v1.8.1.md`.

The TURN Edge Function remains the relay service. Public STUN fallback improves direct-connect attempts but cannot traverse every NAT; reliable calling across restrictive/symmetric NATs still requires a reachable TURN server and valid credentials.

## Validation status

The source changes are present in this package, but this workspace does not contain Flutter/Dart, Deno, or Gradle executables and has no live Supabase project/device connection. Therefore no Flutter analyzer run, unit/widget test run, APK build, Edge Function deployment, or physical-device test has been completed here. Treat the package as a patched candidate until GitHub Actions succeeds and the device regression tests pass.
