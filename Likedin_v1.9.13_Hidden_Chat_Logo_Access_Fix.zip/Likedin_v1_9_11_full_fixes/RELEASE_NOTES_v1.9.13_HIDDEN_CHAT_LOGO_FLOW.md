# Likedin v1.9.13 — Hidden Chat Logo Entry and Session Behaviour

## Updated hidden-chat experience

- Removed the visible **Hidden chats / Unlock** card from Home. Hidden conversations no longer appear in the normal Home conversation area.
- The Likedin logo in the Home header is now the only entry point to the hidden-chat area.
- Pressing the logo prompts for the hidden-chat password on the first access in a process. After successful unlock, a dedicated **Private chat** page displays the hidden conversation.
- Selecting the conversation opens the existing full ChatPage, not a dialog or a reduced preview.
- Returning from the conversation goes back to Home. Pressing the logo again reopens the private list without asking for the password again during the same app process.
- The unlocked state is memory-only and has no three-minute timeout or background timeout. It resets when the app process is terminated or force-stopped, so the next launch requires the password again.
- The **Calls** bottom-navigation destination is removed while at least one conversation is hidden. Incoming call notifications and incoming-call UI continue to work.
- Notification taps and shortcuts cannot jump directly into the hidden conversation; the user must enter from the Home logo.
- The Home compose shortcut is hidden while the conversation is hidden.
- The private chat list includes an **Unhide chat** action and a password-change action.
- Android screenshot/Recents protection remains active while any conversation is hidden.

## Backend scope

No Supabase SQL, schema, RLS, Storage policy, Edge Function, or remote message changes. Hidden IDs and password verifier remain device-local.

## Validation status

- Source-level delimiter and configuration checks are performed in the packaging environment.
- Flutter analyzer, Flutter tests, and Android APK compilation must be run by GitHub Actions; Flutter/Dart SDK binaries are not available in the packaging environment.
