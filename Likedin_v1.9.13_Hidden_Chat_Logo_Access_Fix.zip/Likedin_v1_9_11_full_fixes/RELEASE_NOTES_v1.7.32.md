# Likedin 1.7.32 — Regular Security & Release Optimisation

## Scope
- E2EE is explicitly out of scope per the owner's decision.
- Preserve existing messaging, media, calling, and Supabase integration.
- Enable Android R8 code shrinking/minification and resource shrinking for release builds.
- Preserve Flutter/Firebase/WebRTC JNI and plugin entry points with conservative ProGuard keep rules.
- Retain the existing ARM64 GitHub Actions build workflow.

## Security status (honest)
- Local message store encrypts message bodies with AES-256-GCM; its key is held using flutter_secure_storage / Android Keystore integration.
- Backup codec provides passphrase-based PBKDF2-HMAC-SHA256 + AES-256-GCM encryption, but a complete user-facing conversation export/restore workflow is not integrated.
- Supabase message transport remains plaintext at the application layer (protected in transit by HTTPS/TLS); Supabase/database operators can access message payloads subject to backend controls. This is NOT E2EE.
- Supabase anon/publishable key is client-side configuration and must be protected by strict RLS; never embed service-role secrets.
- Current Android release build still uses debug signing. Do not distribute publicly until a private release keystore is configured.
- No Flutter SDK is available in the authoring environment; flutter analyze, flutter test, APK build, R8 compatibility and device regression tests remain to be run in GitHub Actions / on devices.

## Optimisation approach
- R8 minification and resource shrinking enabled for release.
- Existing workflow builds ARM64 only, which is already the appropriate smaller APK for the user's ARM64 devices.
- Do not claim a 50 MB result until the generated APK is measured. WebRTC/native libraries may dominate size.
