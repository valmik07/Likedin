# Likedin 1.7.16 — Lock-screen security fix

## Security correction

The previous Android configuration enabled `showWhenLocked` and `turnScreenOn` on the app's **MainActivity**. That made the entire messenger, including chats, available over the device lock screen. This was too broad.

This release removes those flags from MainActivity and removes the code that enabled them at startup or on new intents. The main messenger must now remain behind Android's normal device lock screen.

## Incoming-call behavior trade-off

This is a security-first correction. The existing full-screen notification can no longer make the main messenger visible over the lock screen. A normal incoming-call notification may still appear, and the user may need to unlock the phone before opening/answering in the app. A future implementation should use a dedicated, narrowly scoped native call activity rather than granting lock-screen access to MainActivity.

No SQL migration or Supabase function change is required for this Android security fix. Existing notification permissions and backend configuration remain unchanged.

## Verification

1. Open Likedin and navigate to a chat.
2. Press the power button to lock the phone.
3. Wake the phone without unlocking it.
4. Confirm Android's lock screen is shown and Likedin's chat UI cannot be interacted with.
5. Unlock the phone and confirm Likedin remains usable.
6. Test incoming-call notifications separately; full-screen call presentation over the lock screen is intentionally not enabled in this security patch.
