# Likedin 1.7.22 — In-chat call invitations

## Changes
- Added a live incoming-call invitation card to the active conversation. The recipient can tap **Join call** to retrieve the current offer and enter the existing audio/video call session.
- When the conversation is visible, the app no longer covers it with a second automatic incoming-call dialog; the inline invitation owns the join action. Background/other-screen incoming calls retain the existing incoming-call dialog path.
- The chat call buttons now use the already-resolved conversation peer ID instead of making a second peer-lookup RPC. This removes an unnecessary backend lookup from the chat call-start path.
- Incoming invitation cards clear when the call row transitions out of `ringing`; a recovery query catches calls created immediately before the chat subscription.
- Video call-type checks are normalized to lowercase when opening incoming calls.
- Version bumped to 1.7.22+52.

## Existing functionality retained
- Existing audio/video WebRTC session, signaling, TURN configuration, call history, missed-call notification, and idempotent teardown remain in place.
- Existing deleted-message placeholder, deleted-reply preview, and Edited-label guard remain in place.
- No E2EE has been added.

## Verification limits
- Source archive integrity and required source markers are checked during packaging.
- Flutter/Dart SDKs are not installed in the packaging environment; `flutter analyze`, tests, and Android compilation have NOT been run.
- Test on both phones using the existing GitHub Actions workflow. In particular, verify incoming audio and video invitations while the recipient is already inside the chat, while the app is backgrounded, and after ending one call and starting another.
