# Likedin 1.7.21 — Incoming video-call timing fix

- Prepare microphone/camera capture and create the WebRTC offer before publishing the ringing call row.
- This prevents the callee from receiving an incoming-call event while the caller is still waiting for camera permission or media initialization.
- Extend the callee offer-discovery window from 12 seconds to 30 seconds to tolerate slower device startup and network timing.
- Preserve existing audio-call signalling, call teardown, and notification paths.

Validation: source-level inspection and ZIP integrity only. Flutter analyze, automated tests, and Android build were not run in this environment.
