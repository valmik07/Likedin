# Likedin 1.7.34 — Final feature integration candidate

## Included
- Added a dedicated Documents destination in the bottom navigation.
- Documents lists shared attachments from the existing `messages` table (up to the latest 500 messages) as well as local downloaded files.
- Shared images and videos opened from Documents use Likedin's in-app viewers; shared files can be saved to Android Downloads.
- Added press-and-hold voice recording in chat, AAC-LC audio upload, and in-chat audio playback.
- Existing image/video chat previews and in-app full-screen viewers retained.
- Preserved existing notifications, calling, messaging, security and ARM64 GitHub Actions workflow.
- No end-to-end encryption feature or roadmap is included.

## Important validation status
- Source changes and ZIP integrity are checked.
- Flutter/Dart SDK is not available in the authoring environment; `flutter pub get`, `flutter analyze`, tests, Android release build, and device testing have NOT been run here.
- New dependencies: `record` and `just_audio`. CI must resolve these packages and compile the app before this can be treated as a verified release.
- Voice recording requires microphone permission. The Android manifest already declares `RECORD_AUDIO`.
- Shared Documents listing depends on the existing Supabase `messages` table read policy and current message payload schema.
- FCM background/terminated delivery still requires the separately deployed and configured backend push functions and device verification. Android force-stop restrictions still apply.
- Release signing configuration remains the existing debug signing configuration; do not distribute publicly with it.
- APK size has not been measured; R8/resource shrinking remains enabled from 1.7.32.

## CI build correction
- Added a narrowly scoped R8 `-dontwarn` rule for optional Google Play Core deferred-component classes. Likedin does not use Play Feature Delivery; this addresses the missing-class R8 failure seen in the supplied CI log. A fresh CI build is still required to verify the correction.
