# Likedin 1.7.39 — Home & Visual Refresh

## UI updates
- Reworked the landing screen into a personalized daily-briefing experience with a time-aware greeting, date, refined editorial hierarchy, a featured story card, and compact story rows.
- Removed all direct Chat, Call, and Document/Files shortcuts from the home content. Chat and Calls remain reachable from the existing overflow menu; Files remains available from the profile menu. No communication or file functionality was removed.
- Refined the global light and dark themes with clearer surfaces, softer outlines, rounder cards and controls, refreshed input fields, consistent buttons, and more polished bottom sheets/dialogs.
- Updated the app header with a stronger Likedin identity and a private-space descriptor.
- Preserved the existing RSS sources, three-day story rotation, local news cache, external story opening, authentication, chat, calling, files, and settings flows.

## Build status
- Source update only. Flutter SDK is not installed in the editing environment, so `flutter analyze`, `flutter test`, release APK compilation, and device testing could not be run here.
- No Supabase schema, Edge Function, notification, calling, or message protocol changes are included.
