LIKEDIN v1.7.3.2 — LOCAL CHAT EXPERIENCE UPDATE

Base: v1.7.3 source package exactly. The notification service and existing receipt code are unchanged from v1.7.3.
Android version/build: 1.7.3+28.

Implemented locally on each device:
- Message bubbles remain content-sized up to the chat width limit and wrap long text.
- Swipe a message from left to right to start a reply.
- Reply quote is shown inside the sent message on the originating device.
- Long-press actions: Reply, Edit (own messages), React, Delete for me.
- Edited text and the Edited label persist locally after app restart.
- Emoji reactions persist locally and can be toggled off by selecting the same emoji again.
- Delete for me persists locally and does not affect the other participant's history.
- Clear chat uses a per-account/per-peer local cutoff. It hides the existing conversation on this device; later messages remain visible.
- Local chat metadata is stored through FlutterSecureStorage, not in plaintext SharedPreferences.

Not implemented in this release (requires backend synchronization and a two-device test):
- Delete for everyone.
- Synchronizing edits, replies, reactions, per-message deletion, and clear-chat state to the other phone.

Notifications and delivery receipts:
- This release deliberately starts from the v1.7.3 notification/receipt code.
- No notification fix is included. The notification issue will be handled separately.
- Existing delivery/read receipt rendering and backend calls are left unchanged.

Verification status:
- ZIP archive integrity is checked.
- Flutter SDK is not available in the packaging environment; Flutter analyze/build and device tests have NOT been run here.
- Run the existing GitHub Actions workflow before installing. Then test first on one device for local persistence and UI behaviour.


V1.7.3.3 BUBBLE LAYOUT CORRECTION
- Removed width-expanding Align wrappers around message text, Edited label and reaction row.
- Removed the full-width constraint from quoted-reply preview.
- Outer Align still positions content-sized bubbles on sender/receiver sides.
- Maximum bubble width remains 310 logical pixels; long text wraps within that limit.
- Build version: 1.7.3+29.
- Flutter compilation and real-device layout tests remain pending.
