# Hidden Chats Implementation Audit — v1.9.12

## Delivered

1. Conversation-card menu now offers **Hide chat**.
2. Hiding requires confirmation. On first use, the app creates a separate password (minimum 8 characters, confirmed twice).
3. Passwords are never persisted in plaintext. A random 128-bit salt and PBKDF2-HMAC-SHA256 verifier are held in `flutter_secure_storage` (Android Keystore-backed encryption).
4. Hidden conversation IDs are stored per signed-in account in secure storage. The Home screen does not build the normal conversation card while any chat is hidden; it shows only a generic **Hidden chats** entry.
5. Opening the hidden entry or opening Chat or Files through any existing route requires password verification. This includes the New message FAB, tab/notification routing, direct Chat transitions and the Files tab.
6. After unlock, the user can open the chat, unhide it, or change the hidden-chat password. The Forgot password action requires re-verification of the regular Likedin password through the existing Supabase Auth sign-in endpoint before setting a new hidden-chat password.
7. The unlocked session expires after three minutes, immediately when leaving both protected areas (Chat and Files), and after fifteen seconds continuously in the background. A short return from system activities such as the Android media picker cancels the background lock window.
8. Android `FLAG_SECURE` stays enabled as long as at least one conversation remains hidden, including while the section is locked and while the app is in Recents. It is cleared only after all hidden conversations are restored.
9. Message push text is kept generic while hidden-chat notification redaction is enabled. Incoming and missed call alerts are left intact.
10. The shared-media gallery suppresses attachments from the hidden peer while locked and reveals them only in an authenticated session; encrypted backup export requires the hidden-chat password before it can include conversation history.

## Files changed

- `pubspec.yaml` — version updated to `1.9.12+98`.
- `lib/main.dart` — hidden-chat route gate, unlock/session lifecycle, recovery/change-password manager, Android secure-window channel.
- `lib/security/hidden_chat_vault.dart` — secure local hidden-chat and password-verifier storage.
- `lib/ui/hidden_chat_pin_dialog.dart` — password setup/unlock/recovery action dialog.
- `lib/ui/conversation_card.dart` — Hide chat menu and first-use password setup.
- `lib/ui/home_page_part.dart` — hidden/visible Home state, generic Hidden chats entry, and screenshot-protection activation after hiding.
- `lib/ui/settings_page_part.dart` — Files-tab gate, hidden-peer media suppression while locked, and password gate for encrypted backup export.
- `lib/notifications/notification_service.dart` — hidden-state message notification redaction.
- `android/app/src/main/kotlin/com/example/likedin/MainActivity.kt` — `FLAG_SECURE` method-channel handler.
- `test/hidden_chat_vault_test.dart` — password, persistence, redaction preference and password-length tests.
- Release notes and upload instructions.

## Backend scope

No SQL, migration, RLS, Storage policy, Edge Function or Supabase schema changes. Hide/unhide is device-local. The other participant's app is not changed.

## Security limitations

This is an application-level local access gate, not server-side authorization or end-to-end encryption. Remote message contents still exist in the backend and may be accessible through another authorized client or direct account/database access. This feature does not encrypt all existing cached media files or copies that the user has deliberately exported to public Downloads. A rooted/compromised device or a modified app can bypass client-side UI checks. The Android secure-window flag protects the app window from normal screenshot/screen-recording and Recents snapshot paths; it is not a defense against a fully compromised device.

## Validation performed in this environment

- Dart source delimiter checks passed for all modified Dart files.
- Kotlin source delimiter check passed.
- `pubspec.yaml` and `analysis_options.yaml` parsed successfully.
- Android main manifest parsed successfully.
- Flutter analyzer, unit tests and APK build were not run because no Flutter/Dart SDK is installed in this environment. GitHub Actions/device validation is still required.
