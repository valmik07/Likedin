Likedin v1.6.0 experimental calling preparation

This is a build-validation package based on the tested v1.5.2 source.
It adds flutter_webrtc and Android camera/microphone/audio permissions.
It does NOT yet provide live audio/video calls. Call buttons remain placeholders.
Read docs/V1_6_EXPERIMENTAL_CALLING_PREP.md before testing.
Do not add TURN credentials to the APK or repository.
