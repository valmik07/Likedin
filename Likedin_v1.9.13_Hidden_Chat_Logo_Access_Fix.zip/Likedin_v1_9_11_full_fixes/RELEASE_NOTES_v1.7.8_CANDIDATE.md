# Likedin 1.7.8 — engineering candidate

## Included
- Version advanced to 1.7.8+38.
- Remote message model tolerates the historical `body_payload`, `encrypted_payload`,
  and `ciphertext` column names to avoid a hard crash across known schema variants.
- Added a Supabase compatibility migration restoring the legacy `likedin_send_message`
  RPC contract used by this Flutter client.
- Existing features and dependencies are retained.

## Security status — important
**End-to-end encryption is NOT implemented in this candidate.**
The current `RealtimeMessagingService.sendMessage` path still sends the entered
message text as a plaintext RPC parameter. The historical `encrypted_payload`
column name is misleading and does not make the value encrypted.

The existing `ProtocolStateVault` only persists opaque protocol state. It does not
implement Signal identity keys, signed/one-time/PQ prekeys, session establishment,
Double Ratchet encryption/decryption, identity verification, or atomic ratchet
state/message commits.

Do not deploy this candidate as an E2EE release and do not describe conversations
as end-to-end encrypted. A real Signal Protocol adapter and two-device security
tests remain release blockers.

## Backend action
If your existing database has the older `messages` schema, apply:
`supabase/migrations/202611130001_v178_legacy_messaging_compatibility.sql`

This migration is a legacy compatibility bridge only, not an encryption migration.
Take a database backup first and inspect your currently applied migrations before
running it. Do not blindly rerun older migrations.

## Validation
Run the existing GitHub Actions workflow. Then test sign-in, peer lookup,
send/receive, delivery/read receipts, delete-for-everyone, notifications and calls
on both devices. This source archive has not been compiled in this environment.
