import 'package:flutter/material.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:photo_manager_image_provider/photo_manager_image_provider.dart';

/// A lightweight, WhatsApp-style in-app media picker.
///
/// Loads the device library in small pages and only decodes low-resolution
/// thumbnails. The selected originals are resolved by the caller only after
/// the user presses Send, keeping the grid responsive on low-memory phones.
class InAppGalleryPicker extends StatefulWidget {
  const InAppGalleryPicker({super.key, this.maxSelection = 10});

  final int maxSelection;

  static Future<List<AssetEntity>?> show(BuildContext context, {int maxSelection = 10}) {
    return showModalBottomSheet<List<AssetEntity>>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: Colors.transparent,
      builder: (_) => FractionallySizedBox(
        heightFactor: .92,
        child: InAppGalleryPicker(maxSelection: maxSelection),
      ),
    );
  }

  @override
  State<InAppGalleryPicker> createState() => _InAppGalleryPickerState();
}

class _InAppGalleryPickerState extends State<InAppGalleryPicker> with WidgetsBindingObserver {
  static const _pageSize = 60;
  final ScrollController _scrollController = ScrollController();
  final List<AssetEntity> _assets = <AssetEntity>[];
  final Map<String, AssetEntity> _selected = <String, AssetEntity>{};
  List<AssetPathEntity> _albums = <AssetPathEntity>[];
  AssetPathEntity? _album;
  String _filter = 'All';
  int _page = 0;
  bool _hasMore = true;
  bool _loading = true;
  bool _loadingMore = false;
  String? _error;
  int _albumGeneration = 0;
  bool _awaitingPermissionSettings = false;

  List<AssetEntity> get _visibleAssets => _assets.where((asset) {
        if (_filter == 'Videos') return asset.type == AssetType.video;
        if (_filter == 'Photos') return asset.type == AssetType.image;
        return asset.type == AssetType.image || asset.type == AssetType.video;
      }).toList(growable: false);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _scrollController.addListener(_onScroll);
    _initialize();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && _awaitingPermissionSettings) {
      _awaitingPermissionSettings = false;
      _initialize();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (!_scrollController.hasClients || _loading || _loadingMore || !_hasMore) return;
    if (_scrollController.position.extentAfter < 650) {
      _loadNextPage();
    }
  }

  Future<void> _initialize() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final permission = await PhotoManager.requestPermissionExtend();
      if (!permission.isAuth && !permission.hasAccess) {
        if (!mounted) return;
        setState(() {
          _loading = false;
          _error = 'Allow photo and video access to browse your gallery.';
        });
        return;
      }

      final albums = await PhotoManager.getAssetPathList(
        type: RequestType.common,
        hasAll: true,
        onlyAll: false,
      );
      if (!mounted) return;
      if (albums.isEmpty) {
        setState(() {
          _albums = <AssetPathEntity>[];
          _loading = false;
          _hasMore = false;
        });
        return;
      }
      setState(() {
        _albums = albums;
        _album = albums.first;
        _assets.clear();
        _page = 0;
        _hasMore = true;
      });
      await _loadNextPage(initial: true);
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'Could not open your gallery. Check photo permissions and try again.';
      });
    }
  }

  Future<void> _loadNextPage({bool initial = false}) async {
    final album = _album;
    if (album == null || !_hasMore || _loadingMore) return;
    final generation = _albumGeneration;
    final pageIndex = _page;
    setState(() {
      _loadingMore = true;
      if (initial) _loading = true;
      _error = null;
    });
    try {
      final page = await album.getAssetListPaged(page: pageIndex, size: _pageSize);
      if (!mounted || generation != _albumGeneration || album.id != _album?.id) return;
      setState(() {
        _assets.addAll(page);
        _page = pageIndex + 1;
        _hasMore = page.length == _pageSize;
        _loading = false;
        _loadingMore = false;
      });
    } catch (error) {
      if (!mounted || generation != _albumGeneration) return;
      setState(() {
        _loading = false;
        _loadingMore = false;
        _error = 'Could not load more media. Please try again.';
      });
    } finally {
      if (mounted && generation == _albumGeneration && _loadingMore) {
        setState(() => _loadingMore = false);
      }
    }
  }

  Future<void> _changeAlbum(String id) async {
    final album = _albums.cast<AssetPathEntity?>().firstWhere(
          (item) => item?.id == id,
          orElse: () => null,
        );
    if (album == null || album.id == _album?.id) return;
    setState(() {
      _albumGeneration++;
      _loadingMore = false;
      _album = album;
      _assets.clear();
      // A user's selection spans albums; changing the current view must not
      // silently discard items already chosen from another album.
      _page = 0;
      _hasMore = true;
      _error = null;
      _loading = true;
    });
    if (_scrollController.hasClients) _scrollController.jumpTo(0);
    await _loadNextPage(initial: true);
    await _fillFilteredViewport();
  }

  Future<void> _changeFilter(String filter) async {
    if (_filter == filter) return;
    setState(() => _filter = filter);
    await _fillFilteredViewport();
  }

  Future<void> _fillFilteredViewport() async {
    // A filtered page may contain too few rows to scroll, which would never
    // trigger the normal infinite-scroll threshold. Fill a useful viewport.
    while (mounted && _hasMore && !_loading && !_loadingMore && _visibleAssets.length < 24) {
      final previousPage = _page;
      await _loadNextPage();
      if (!mounted || _page == previousPage || _error != null) break;
    }
  }

  void _toggleAsset(AssetEntity asset) {
    setState(() {
      if (_selected.containsKey(asset.id)) {
        _selected.remove(asset.id);
      } else if (_selected.length < widget.maxSelection) {
        _selected[asset.id] = asset;
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Choose up to ${widget.maxSelection} items at a time.')),
        );
      }
    });
  }

  String _duration(int totalSeconds) {
    final minutes = totalSeconds ~/ 60;
    final seconds = totalSeconds % 60;
    return '$minutes:${seconds.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final dark = theme.brightness == Brightness.dark;
    final surface = dark ? const Color(0xFF121E2B) : const Color(0xFFFCFDFF);
    final assets = _visibleAssets;

    return Material(
      color: surface,
      borderRadius: const BorderRadius.vertical(top: Radius.circular(26)),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          const SizedBox(height: 10),
          Container(
            width: 38,
            height: 4,
            decoration: BoxDecoration(
              color: theme.dividerColor.withValues(alpha: .65),
              borderRadius: BorderRadius.circular(4),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 16, 12, 8),
            child: Row(
              children: [
                const Expanded(
                  child: Text('Gallery', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
                ),
                if (_albums.isNotEmpty)
                  PopupMenuButton<String>(
                    tooltip: 'Choose album',
                    onSelected: _changeAlbum,
                    itemBuilder: (context) => _albums
                        .map((album) => PopupMenuItem<String>(
                              value: album.id,
                              child: Text(album.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                            ))
                        .toList(growable: false),
                    child: Container(
                      constraints: const BoxConstraints(maxWidth: 155),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                      decoration: BoxDecoration(
                        color: dark ? const Color(0xFF1E3042) : const Color(0xFFEAF2FC),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        Flexible(
                          child: Text(
                            _album?.name ?? 'Recent',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
                          ),
                        ),
                        const SizedBox(width: 4),
                        const Icon(Icons.keyboard_arrow_down_rounded, size: 18),
                      ]),
                    ),
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
            child: Row(
              children: [
                for (final filter in const ['All', 'Photos', 'Videos']) ...[
                  if (filter != 'All') const SizedBox(width: 8),
                  ChoiceChip(
                    label: Text(filter),
                    selected: _filter == filter,
                    onSelected: (_) => _changeFilter(filter),
                    selectedColor: theme.colorScheme.primary.withValues(alpha: dark ? .28 : .13),
                    labelStyle: TextStyle(
                      color: _filter == filter ? theme.colorScheme.primary : theme.colorScheme.onSurface.withValues(alpha: .78),
                      fontWeight: FontWeight.w700,
                      fontSize: 12,
                    ),
                    side: BorderSide(color: _filter == filter ? theme.colorScheme.primary.withValues(alpha: .4) : theme.dividerColor),
                    visualDensity: VisualDensity.compact,
                    padding: const EdgeInsets.symmetric(horizontal: 5),
                  ),
                ],
              ],
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(strokeWidth: 2.4))
                : _error != null
                    ? Center(
                        child: Padding(
                          padding: const EdgeInsets.all(24),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.photo_library_outlined, size: 42, color: theme.colorScheme.primary),
                              const SizedBox(height: 12),
                              Text(_error!, textAlign: TextAlign.center),
                              const SizedBox(height: 12),
                              FilledButton.tonal(
                                onPressed: () async {
                                  _awaitingPermissionSettings = true;
                                  await PhotoManager.openSetting();
                                  // The permission state is refreshed by
                                  // didChangeAppLifecycleState(resumed).
                                },
                                child: const Text('Open permission settings'),
                              ),
                              TextButton(onPressed: _initialize, child: const Text('Try again')),
                            ],
                          ),
                        ),
                      )
                    : assets.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  _assets.isEmpty ? 'No photos or videos found on this device.' : 'No items in this page for this filter.',
                                  style: TextStyle(color: theme.hintColor),
                                  textAlign: TextAlign.center,
                                ),
                                if (_hasMore) ...[
                                  const SizedBox(height: 10),
                                  TextButton.icon(
                                    onPressed: _loadingMore ? null : _loadNextPage,
                                    icon: const Icon(Icons.expand_more_rounded),
                                    label: const Text('Load more media'),
                                  ),
                                ],
                              ],
                            ),
                          )
                        : GridView.builder(
                            controller: _scrollController,
                            padding: const EdgeInsets.fromLTRB(2, 0, 2, 10),
                            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 3,
                              crossAxisSpacing: 2,
                              mainAxisSpacing: 2,
                            ),
                            itemCount: assets.length + (_hasMore ? 1 : 0),
                            itemBuilder: (context, index) {
                              if (index >= assets.length) {
                                return const Center(
                                  child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
                                );
                              }
                              final asset = assets[index];
                              final assetTitle = asset.title ?? 'Media';
                              final selectedIndex = _selected.keys.toList(growable: false).indexOf(asset.id);
                              final isSelected = selectedIndex >= 0;
                              final isGif = assetTitle.toLowerCase().endsWith('.gif');
                              return RepaintBoundary(
                                child: Semantics(
                                  button: true,
                                  selected: isSelected,
                                  label: '${asset.type == AssetType.video ? 'Video' : 'Photo'} ${assetTitle.isEmpty ? 'from gallery' : assetTitle}',
                                  hint: isSelected ? 'Double tap to remove from selection' : 'Double tap to add to selection',
                                  child: GestureDetector(
                                  behavior: HitTestBehavior.opaque,
                                  onTap: () => _toggleAsset(asset),
                                  child: Stack(
                                    fit: StackFit.expand,
                                    children: [
                                      Image(
                                        image: AssetEntityImageProvider(
                                          asset,
                                          isOriginal: false,
                                          thumbnailSize: const ThumbnailSize.square(180),
                                          thumbnailFormat: ThumbnailFormat.jpeg,
                                        ),
                                        fit: BoxFit.cover,
                                        filterQuality: FilterQuality.low,
                                        gaplessPlayback: true,
                                        errorBuilder: (_, __, ___) => ColoredBox(
                                          color: dark ? const Color(0xFF263646) : const Color(0xFFE6ECF3),
                                          child: const Center(child: Icon(Icons.broken_image_outlined)),
                                        ),
                                      ),
                                      if (asset.type == AssetType.video)
                                        Positioned(
                                          left: 7,
                                          bottom: 7,
                                          child: DecoratedBox(
                                            decoration: BoxDecoration(
                                              color: Colors.black.withValues(alpha: .62),
                                              borderRadius: BorderRadius.circular(6),
                                            ),
                                            child: Padding(
                                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                                              child: Text(
                                                _duration(asset.duration),
                                                style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700),
                                              ),
                                            ),
                                          ),
                                        ),
                                      if (isGif)
                                        const Positioned(
                                          left: 7,
                                          bottom: 7,
                                          child: _GalleryTag(text: 'GIF'),
                                        ),
                                      Positioned(
                                        top: 7,
                                        right: 7,
                                        child: AnimatedContainer(
                                          duration: const Duration(milliseconds: 100),
                                          width: 25,
                                          height: 25,
                                          alignment: Alignment.center,
                                          decoration: BoxDecoration(
                                            color: isSelected ? Theme.of(context).colorScheme.primary : Colors.black.withValues(alpha: .25),
                                            shape: BoxShape.circle,
                                            border: Border.all(color: Colors.white, width: 1.5),
                                          ),
                                          child: isSelected
                                              ? Text('${selectedIndex + 1}', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w800))
                                              : const SizedBox.shrink(),
                                        ),
                                      ),
                                      if (isSelected)
                                        DecoratedBox(
                                          decoration: BoxDecoration(
                                            border: Border.all(color: Theme.of(context).colorScheme.primary, width: 3),
                                          ),
                                        ),
                                    ],
                                  ),
                                  ),
                                ),
                              );
                            },
                          ),
          ),
          if (_loadingMore && assets.isNotEmpty)
            LinearProgressIndicator(minHeight: 2, color: Theme.of(context).colorScheme.primary),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      _selected.isEmpty
                          ? 'Select up to ${widget.maxSelection} items'
                          : '${_selected.length} selected',
                      style: TextStyle(fontWeight: FontWeight.w700, color: theme.colorScheme.onSurface),
                    ),
                  ),
                  TextButton(
                    onPressed: _selected.isEmpty ? null : () => setState(_selected.clear),
                    child: const Text('Clear'),
                  ),
                  const SizedBox(width: 8),
                  FilledButton.icon(
                    onPressed: _selected.isEmpty
                        ? null
                        : () => Navigator.of(context).pop(_selected.values.toList(growable: false)),
                    icon: const Icon(Icons.send_rounded, size: 17),
                    label: const Text('Send'),
                    style: FilledButton.styleFrom(backgroundColor: Theme.of(context).colorScheme.primary),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _GalleryTag extends StatelessWidget {
  const _GalleryTag({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) => DecoratedBox(
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: .64),
          borderRadius: BorderRadius.circular(6),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
          child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w800)),
        ),
      );
}
