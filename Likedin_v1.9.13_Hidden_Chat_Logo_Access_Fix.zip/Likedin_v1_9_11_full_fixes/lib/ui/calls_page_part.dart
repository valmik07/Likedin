part of '../main.dart';

class CallsPage extends StatefulWidget {
  const CallsPage({super.key});
  @override
  State<CallsPage> createState() => _CallsPageState();
}

class _CallsPageState extends State<CallsPage> {
  Future<List<Map<String, dynamic>>>? _history;
  List<Map<String, dynamic>>? _lastHistory;
  RealtimeChannel? _channel;
  String _filter = 'All';

  @override
  void initState() {
    super.initState();
    _load();
    _subscribe();
  }

  void _load() {
    _history = _fetch();
  }

  Future<List<Map<String, dynamic>>> _fetch() async {
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (uid == null) return _lastHistory ?? const <Map<String, dynamic>>[];
    final rows = await Supabase.instance.client
        .from('likedin_calls')
        .select()
        .or('caller_id.eq.$uid,callee_id.eq.$uid')
        .order('created_at', ascending: false)
        .limit(100);
    final fetched = rows.map((e) => Map<String, dynamic>.from(e)).toList();
    _lastHistory = fetched;
    return fetched;
  }

  void _subscribe() {
    final client = Supabase.instance.client;
    final uid = client.auth.currentUser?.id;
    if (uid == null) return;
    _channel = client
        .channel('likedin-call-history-$uid')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'likedin_calls',
          callback: (_) {
            if (mounted) setState(_load);
          },
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'likedin_calls',
          callback: (_) {
            if (mounted) setState(_load);
          },
        )
      ..subscribe();
  }

  @override
  void dispose() {
    final c = _channel;
    if (c != null) Supabase.instance.client.removeChannel(c);
    super.dispose();
  }

  String _label(Map<String, dynamic> row, String uid) {
    final outgoing = row['caller_id'] == uid;
    final status = row['status']?.toString() ?? 'ended';
    if (status == 'missed') return outgoing ? 'No answer' : 'Missed call';
    if (status == 'rejected') return outgoing ? 'Declined' : 'You declined';
    if (status == 'failed') return 'Call failed';
    if (status == 'ringing') return 'Ringing';
    if (status == 'accepted' || row['answered_at'] != null) return 'Completed';
    return status == 'ended' ? 'Ended' : status;
  }

  IconData _icon(Map<String, dynamic> row, String uid) {
    if (row['status'] == 'missed' && row['callee_id'] == uid) return Icons.call_missed;
    if (row['caller_id'] == uid) return Icons.call_made;
    return Icons.call_received;
  }

  bool _matchesFilter(Map<String, dynamic> row) {
    switch (_filter) {
      case 'Missed':
        return row['status'] == 'missed';
      case 'Video':
        return row['call_type'] == 'video';
      case 'Audio':
        return row['call_type'] != 'video';
      default:
        return true;
    }
  }

  String _dateLabel(Map<String, dynamic> row) {
    final created = DateTime.tryParse(row['created_at']?.toString() ?? '')?.toLocal();
    if (created == null) return 'Date unavailable';
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final day = DateTime(created.year, created.month, created.day);
    final dayText = day == today
        ? 'Today'
        : day == DateTime(today.year, today.month, today.day - 1)
            ? 'Yesterday'
            : MaterialLocalizations.of(context).formatMediumDate(created);
    final timeText = MaterialLocalizations.of(context).formatTimeOfDay(
      TimeOfDay.fromDateTime(created),
    );
    return '$dayText · $timeText';
  }

  Widget _filterPill(String value, {required bool dark, required Color foreground}) {
    final selected = _filter == value;
    final background = selected
        ? (dark ? const Color(0xFF8DB8FF) : const Color(0xFFDCEBFF))
        : (dark ? const Color(0xFF20364E) : const Color(0xFFEAF0FA));
    final label = selected
        ? (dark ? const Color(0xFF061725) : const Color(0xFF174F9A))
        : foreground.withValues(alpha: .88);
    final border = selected
        ? (dark ? const Color(0xFF8DB8FF) : const Color(0xFF9BBCEB))
        : (dark ? const Color(0xFF38506A) : const Color(0xFFD6E0EF));

    return Semantics(
      button: true,
      selected: selected,
      label: '$value calls filter',
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(30),
          onTap: () => setState(() => _filter = value),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 160),
            curve: Curves.easeOut,
            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 9),
            decoration: BoxDecoration(
              color: background,
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: border),
            ),
            child: Text(
              value,
              style: TextStyle(color: label, fontSize: 12, fontWeight: FontWeight.w800),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final uid = Supabase.instance.client.auth.currentUser?.id ?? '';
    final dark = Theme.of(context).brightness == Brightness.dark;
    final foreground = dark ? Colors.white : const Color(0xFF172B4D);
    final secondary = dark ? Colors.white70 : const Color(0xFF61708A);
    final panelTint = dark ? const Color(0xC5162D45) : const Color(0xE8FFFFFF);
    final accent = brandBlue;

    return RefreshIndicator(
        color: accent,
        backgroundColor: dark ? const Color(0xFF18324D) : Colors.white,
        onRefresh: () async {
          if (!mounted) return;
          setState(_load);
          try { await _history; } catch (error) {
            debugPrint('Call history refresh failed: $error');
          }
        },
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(0, 8, 0, 0),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      'Calls',
                      style: TextStyle(
                        color: foreground,
                        fontSize: 34,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -1.1,
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: 'Refresh call history',
                    onPressed: () => setState(_load),
                    icon: Icon(Icons.refresh_rounded, color: secondary),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: _callStartTile(
                    context,
                    icon: Icons.call_rounded,
                    title: 'Voice call',
                    subtitle: 'Audio only',
                    accent: const Color(0xFF32B98D),
                    onTap: () => _showCallSetup(context, video: false),
                  ),
                ),
                const SizedBox(width: 11),
                Expanded(
                  child: _callStartTile(
                    context,
                    icon: Icons.videocam_rounded,
                    title: 'Video call',
                    subtitle: 'Face to face',
                    accent: const Color(0xFF3B9FD0),
                    onTap: () => _showCallSetup(context, video: true),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 26),
            Row(
              children: [
                Expanded(
                  child: Text(
                    'Recent',
                    style: TextStyle(color: foreground, fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: -.4),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: ['All', 'Missed', 'Video', 'Audio']
                  .map((value) => _filterPill(value, dark: dark, foreground: foreground))
                  .toList(),
            ),
            const SizedBox(height: 14),
            FutureBuilder<List<Map<String, dynamic>>>(
              future: _history,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting && _lastHistory == null) {
                  return Padding(
                    padding: const EdgeInsets.all(34),
                    child: Center(child: CircularProgressIndicator(color: accent)),
                  );
                }
                if (snapshot.hasError && _lastHistory == null) {
                  return GlassPanel(
                    tint: panelTint,
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        Icon(Icons.cloud_off_rounded, color: dark ? const Color(0xFFFFB4AB) : const Color(0xFFB5473A), size: 30),
                        const SizedBox(height: 9),
                        Text('Call history unavailable', style: TextStyle(color: foreground, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 4),
                        Text('Pull down to try again.', style: TextStyle(color: secondary, fontSize: 12)),
                      ],
                    ),
                  );
                }
                final allRows = snapshot.data ?? _lastHistory ?? const <Map<String, dynamic>>[];
                final rows = allRows.where(_matchesFilter).toList();
                if (allRows.isEmpty) {
                  return GlassPanel(
                    tint: panelTint,
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                    child: Column(
                      children: [
                        Icon(Icons.history_rounded, color: accent, size: 42),
                        const SizedBox(height: 12),
                        Text('No calls yet', style: TextStyle(color: foreground, fontWeight: FontWeight.w800)),
                        const SizedBox(height: 5),
                        Text(
                          'Your recent audio and video calls will appear here.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: secondary, fontSize: 12),
                        ),
                      ],
                    ),
                  );
                }
                if (rows.isEmpty) {
                  return GlassPanel(
                    tint: panelTint,
                    padding: const EdgeInsets.all(22),
                    child: Column(
                      children: [
                        Icon(Icons.filter_list_off_rounded, color: accent, size: 34),
                        const SizedBox(height: 9),
                        Text('Nothing in this filter', style: TextStyle(color: foreground, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 4),
                        Text('Try another call type.', style: TextStyle(color: secondary, fontSize: 12)),
                      ],
                    ),
                  );
                }
                return Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(bottom: 9, left: 3, right: 3),
                      child: Row(
                        children: [
                          Text(
                            '${rows.length} ${rows.length == 1 ? 'call' : 'calls'}',
                            style: TextStyle(color: secondary, fontSize: 12, fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                    ),
                    ...rows.map((row) {
                      final missed = row['status'] == 'missed';
                      final outgoing = row['caller_id'] == uid;
                      final isVideo = row['call_type'] == 'video';
                      final peerId = outgoing ? row['callee_id']?.toString() : row['caller_id']?.toString();
                      final answered = DateTime.tryParse(row['answered_at']?.toString() ?? '');
                      final ended = DateTime.tryParse(row['ended_at']?.toString() ?? '');
                      final duration = answered == null || ended == null
                          ? null
                          : ended.difference(answered).inSeconds.clamp(0, 86400);
                      final statusColor = missed
                          ? (dark ? const Color(0xFFFF848B) : const Color(0xFFC43D4A))
                          : row['status'] == 'failed'
                              ? (dark ? const Color(0xFFFFB66D) : const Color(0xFFB96B19))
                              : (dark ? const Color(0xFF72DDB7) : const Color(0xFF208B68));
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 9),
                        child: GlassPanel(
                          tint: panelTint,
                          blur: 13,
                          glow: false,
                          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
                          radius: BorderRadius.circular(22),
                          child: Row(
                            children: [
                              Container(
                                width: 46,
                                height: 46,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: statusColor.withValues(alpha: .12),
                                  border: Border.all(color: statusColor.withValues(alpha: .38)),
                                ),
                                child: Icon(
                                  isVideo ? Icons.videocam_rounded : _icon(row, uid),
                                  color: statusColor,
                                  size: 21,
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      '${isVideo ? 'Video' : 'Audio'} · ${_label(row, uid)}',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        color: missed ? statusColor : foreground,
                                        fontWeight: FontWeight.w800,
                                        fontSize: 13,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      '${outgoing ? 'Outgoing' : 'Incoming'}  ·  ${_dateLabel(row)}${duration == null ? '' : '  ·  ${duration ~/ 60}m ${duration % 60}s'}',
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(color: secondary, fontSize: 12),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 5),
                              Container(
                                decoration: BoxDecoration(
                                  color: accent.withValues(alpha: dark ? .13 : .09),
                                  shape: BoxShape.circle,
                                  border: Border.all(color: accent.withValues(alpha: .25)),
                                ),
                                child: IconButton(
                                  tooltip: 'Call back',
                                  visualDensity: VisualDensity.compact,
                                  onPressed: peerId == null || peerId.isEmpty
                                      ? null
                                      : () => _showCallSetup(context, video: isVideo, recipientId: peerId),
                                  icon: Icon(Icons.call_rounded, color: accent, size: 19),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    }),
                  ],
                );
              },
            ),
          ],
        ),
    );
  }

  Widget _callStartTile(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required Color accent,
    required VoidCallback onTap,
  }) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final foreground = dark ? Colors.white : const Color(0xFF172B4D);
    final secondary = dark ? Colors.white70 : const Color(0xFF61708A);
    return Semantics(
      button: true,
      label: '$title, $subtitle',
      child: Material(
        color: accent.withValues(alpha: dark ? .16 : .10),
        borderRadius: BorderRadius.circular(22),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(icon, color: accent, size: 26),
                const SizedBox(height: 18),
                Text(title, style: TextStyle(color: foreground, fontSize: 16, fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text(subtitle, style: TextStyle(color: secondary, fontSize: 13)),
              ],
            ),
          ),
        ),
      ),
    );
  }

}

Future<void> _showCallSetup(BuildContext context, {required bool video, String? recipientId}) async {
  final client = Supabase.instance.client;
  final messenger = ScaffoldMessenger.of(context);
  if (_globalCallDialogActive) {
    messenger.showSnackBar(const SnackBar(content: Text('A call is already active. Finish it before starting another.')));
    return;
  }
  try {
    final peer = recipientId ?? await client.rpc('likedin_get_peer_id') as String?;
    if (peer == null) {
      messenger.showSnackBar(
        const SnackBar(content: Text('Your friend has not registered yet.')),
      );
      return;
    }
    if (!context.mounted) return;
    if (_globalCallDialogActive) return;
    _globalCallDialogActive = true;
    try {
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (_) => _LiveCallDialog(peerId: peer, video: video),
      );
    } finally { _globalCallDialogActive = false; }
  } catch (e) {
    messenger.showSnackBar(SnackBar(content: const Text('Could not start the call. Check your connection and try again.')));
  }
}

class _LiveCallDialog extends StatefulWidget {
  const _LiveCallDialog({required this.peerId, required this.video});
  final String peerId;
  final bool video;
  @override
  State<_LiveCallDialog> createState() => _LiveCallDialogState();
}

class _LiveCallDialogState extends State<_LiveCallDialog> {
  late final LikedinCallService call;
  final ProximityCallController proximity = ProximityCallController();
  StreamSubscription<String>? sub;
  Timer? durationTicker;
  Stopwatch? stopwatch;
  String status = 'Preparing call…';
  bool ready = false, failed = false, connected = false;
  int elapsedSeconds = 0;
  String peerDisplayName = 'Likedin contact';

  @override
  void initState() {
    super.initState();
    _loadPeerDisplayName();
    _start();
  }

  Future<void> _loadPeerDisplayName() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getString('likedIn_nickname_${widget.peerId}');
      if (saved != null && saved.trim().isNotEmpty) {
        if (mounted) setState(() => peerDisplayName = saved.trim());
        return;
      }
      final row = await Supabase.instance.client.from('profiles')
          .select('display_name').eq('user_id', widget.peerId).maybeSingle();
      final name = row?['display_name']?.toString().trim();
      if (mounted && name != null && name.isNotEmpty) setState(() => peerDisplayName = name);
    } catch (error) {
      debugPrint('Call peer-name lookup deferred: $error');
    }
  }

  Future<void> _start() async {
    call = LikedinCallService(Supabase.instance.client);
    try {
      await call.initialize();
      sub = call.changes.listen((v) {
        if (!mounted) return;
        final nowConnected = v == 'connected';
        if (nowConnected && !connected) {
          connected = true;
          stopwatch = Stopwatch()..start();
          durationTicker = Timer.periodic(const Duration(seconds: 1), (_) {
            if (mounted && stopwatch != null) {
              setState(() => elapsedSeconds = stopwatch!.elapsed.inSeconds);
            }
          });
        }
        setState(() {
          status = v;
          if (v.startsWith('failed') || v.startsWith('error:')) failed = true;
        });
        if (v == 'connected') {
          proximity.update(
            active: !widget.video,
            enabled: !widget.video && !call.speaker,
          );
        }
        if (v == 'ended' ||
            v == 'missed' ||
            v == 'rejected' ||
            v.startsWith('failed') ||
            v.startsWith('error:')) {
          Future<void>.delayed(const Duration(milliseconds: 900), () {
            if (mounted && Navigator.of(context).canPop()) Navigator.of(context).pop();
          });
        }
      });
      await call.start(widget.peerId, withVideo: widget.video);
      if (mounted) setState(() => ready = true);
    } catch (e) {
      if (mounted) {
        setState(() {
          status = 'Call connection failed';
          failed = true;
        });
      }
    }
  }

  Future<void> _toggleSpeaker() async {
    await call.toggleSpeaker();
    await proximity.update(
      active: connected && !widget.video,
      enabled: connected && !widget.video && !call.speaker,
    );
    if (mounted) setState(() {});
  }

  String get _durationLabel =>
      '${(elapsedSeconds ~/ 60).toString().padLeft(2, '0')}:${(elapsedSeconds % 60).toString().padLeft(2, '0')}';

  String get _statusLabel {
    final v = status.toLowerCase().trim();
    if (v.startsWith('failed') || v.startsWith('error')) return 'Call connection failed';
    if (v == 'disconnected' || v.contains('disconnected')) return 'Reconnecting…';
    if (v == 'ringing' || v == 'ring') return 'Ringing…';
    if (v == 'ended' || v == 'closed') return 'Call ended';
    if (v == 'missed') return 'Missed call';
    if (v == 'rejected') return 'Call declined';
    if (connected || v == 'connected') return _durationLabel;
    if (v.contains('offer') || v.contains('connecting') || v.contains('preparing') || v.contains('calling')) {
      return 'Calling…';
    }
    return 'Connecting…';
  }

  @override
  void dispose() {
    durationTicker?.cancel();
    stopwatch?.stop();
    proximity.dispose();
    sub?.cancel();
    call.close();
    super.dispose();
  }

  bool _handlingBack = false;

  Future<void> _handleSystemBack() async {
    if (_handlingBack) return;
    _handlingBack = true;
    try {
      try { await call.end(); } catch (error) {
        debugPrint('Call termination failed; closing the call screen anyway: $error');
      }
    } finally {
      if (mounted && Navigator.of(context).canPop()) Navigator.of(context).pop();
      _handlingBack = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final title = connected
        ? 'In ${widget.video ? 'video' : 'audio'} call'
        : (widget.video ? 'Video call' : 'Audio call');
    return PopScope<Object?>(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) unawaited(_handleSystemBack());
      },
      child: Dialog.fullscreen(
        backgroundColor: _callBackground,
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 8, 24, 28),
            child: Column(
              children: [
                Row(
                  children: [
                    IconButton(
                      tooltip: 'End call',
                      onPressed: _handleSystemBack,
                      icon: const Icon(Icons.call_end_rounded, color: _callDanger, size: 25),
                    ),
                    const Spacer(),
                    Icon(
                      widget.video ? Icons.videocam_rounded : Icons.call_rounded,
                      color: _callMuted,
                      size: 22,
                    ),
                    const SizedBox(width: 12),
                  ],
                ),
                const SizedBox(height: 8),
                Expanded(
                  child: widget.video && connected
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(28),
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              RTCVideoView(
                                call.remoteRenderer,
                                objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                              ),
                              Positioned(
                                right: 14,
                                top: 14,
                                width: 108,
                                height: 148,
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(18),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: _callPanel,
                                      border: Border.all(color: Colors.white24),
                                      borderRadius: BorderRadius.circular(18),
                                    ),
                                    child: RTCVideoView(
                                      call.localRenderer,
                                      mirror: call.usingFrontCamera,
                                      objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                left: 14,
                                top: 14,
                                child: _CallPill(
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Container(
                                        width: 7,
                                        height: 7,
                                        decoration: const BoxDecoration(
                                          color: _callPositive,
                                          shape: BoxShape.circle,
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Text(
                                        _statusLabel,
                                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )
                      : Center(
                          child: SingleChildScrollView(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const _CallHaloAvatar(icon: Icons.person_rounded, size: 132),
                                const SizedBox(height: 28),
                                Text(
                                  peerDisplayName,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 30,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: -.8,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  title,
                                  style: const TextStyle(color: _callMuted, fontSize: 16),
                                ),
                                const SizedBox(height: 20),
                                _CallStatusLine(
                                  text: _statusLabel,
                                  color: failed
                                      ? const Color(0xFFFF7C83)
                                      : connected
                                          ? _callPositive
                                          : _callAccent,
                                ),
                                if (failed)
                                  Padding(
                                    padding: const EdgeInsets.only(top: 14),
                                    child: Text(
                                      'Call connection failed. Check your connection and try again.',
                                      textAlign: TextAlign.center,
                                      style: const TextStyle(color: Color(0xFFFFB4AB), fontSize: 13),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ),
                ),
                const SizedBox(height: 24),
                Wrap(
                  alignment: WrapAlignment.center,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  spacing: 8,
                  runSpacing: 18,
                  children: [
                    _callControl(
                      call.muted ? Icons.mic_off_rounded : Icons.mic_rounded,
                      call.muted ? 'Unmute' : 'Mute',
                      ready
                          ? () async {
                              await call.toggleMute();
                              if (mounted) setState(() {});
                            }
                          : null,
                      active: call.muted,
                    ),
                    _callControl(
                      call.speaker ? Icons.volume_up_rounded : Icons.hearing_rounded,
                      call.speaker ? 'Speaker' : 'Earpiece',
                      ready ? _toggleSpeaker : null,
                      active: call.speaker,
                    ),
                    if (widget.video)
                      _callControl(
                        call.camera ? Icons.videocam_rounded : Icons.videocam_off_rounded,
                        'Camera',
                        ready
                            ? () async {
                                await call.toggleCamera();
                                if (mounted) setState(() {});
                              }
                            : null,
                        active: !call.camera,
                      ),
                    if (widget.video)
                      _callControl(Icons.cameraswitch_rounded, 'Flip', ready ? call.switchCamera : null),
                  ],
                ),
                const SizedBox(height: 22),
                _incomingCallAction(
                  icon: Icons.call_end_rounded,
                  label: failed ? 'Close' : 'End call',
                  color: _callDanger,
                  onTap: _handleSystemBack,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _callControl(
    IconData icon,
    String label,
    VoidCallback? action, {
    bool active = false,
  }) =>
      _CallRoundButton(icon: icon, label: label, active: active, onPressed: action);
}

