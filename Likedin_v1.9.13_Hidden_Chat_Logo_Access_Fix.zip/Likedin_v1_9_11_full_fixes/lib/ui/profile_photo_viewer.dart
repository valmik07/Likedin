import 'package:flutter/material.dart';

/// Full-screen, zoomable viewer for the other person's private profile photo.
/// The caller supplies a time-limited Supabase signed URL; no bucket is made public.
class ProfilePhotoViewerPage extends StatelessWidget {
  const ProfilePhotoViewerPage({
    required this.imageUrl,
    required this.displayName,
    super.key,
  });

  final String imageUrl;
  final String displayName;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(
          displayName.trim().isEmpty ? 'Profile photo' : displayName,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
      ),
      body: Center(
        child: InteractiveViewer(
          minScale: 1,
          maxScale: 4,
          boundaryMargin: const EdgeInsets.all(48),
          child: RepaintBoundary(
            child: Image.network(
              imageUrl,
              fit: BoxFit.contain,
              cacheWidth: 1440,
              filterQuality: FilterQuality.medium,
              frameBuilder: (context, child, frame, wasSynchronouslyLoaded) {
                if (wasSynchronouslyLoaded || frame != null) return child;
                return const SizedBox(
                  width: 44,
                  height: 44,
                  child: Center(child: CircularProgressIndicator(color: Colors.white)),
                );
              },
              errorBuilder: (context, error, stackTrace) => const Padding(
                padding: EdgeInsets.all(28),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.broken_image_outlined, color: Colors.white70, size: 48),
                    SizedBox(height: 12),
                    Text(
                      'Profile photo could not be loaded.',
                      style: TextStyle(color: Colors.white70),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
