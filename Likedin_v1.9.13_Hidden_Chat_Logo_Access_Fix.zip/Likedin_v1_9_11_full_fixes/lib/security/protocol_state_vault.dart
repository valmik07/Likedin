import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:uuid/uuid.dart';

/// Secure storage boundary for serialized libsignal state.
///
/// Android storage is backed by flutter_secure_storage's Android Keystore
/// integration. This class stores opaque protocol-state blobs only; it does
/// not generate Signal identity keys, implement a ratchet, or encrypt chat
/// messages. Those operations must be supplied by the libsignal adapter.
class ProtocolStateVault {
  ProtocolStateVault({FlutterSecureStorage? storage})
      : _storage = storage ?? const FlutterSecureStorage();

  static const _deviceIdKey = 'likedin.e2ee.device_id.v1';
  static const _statePrefix = 'likedin.e2ee.protocol_state.v1.';
  final FlutterSecureStorage _storage;
  static const _uuid = Uuid();

  Future<String> getOrCreateDeviceId() async {
    final existing = await _storage.read(key: _deviceIdKey);
    if (existing != null && existing.isNotEmpty) return existing;
    final created = _uuid.v4();
    await _storage.write(key: _deviceIdKey, value: created);
    return created;
  }

  /// Save opaque serialized state from the libsignal store adapter.
  /// [namespace] must be a stable, non-secret store identifier.
  Future<void> writeState(String namespace, List<int> serializedState) async {
    _validateNamespace(namespace);
    await _storage.write(
      key: '$_statePrefix$namespace',
      value: base64Encode(serializedState),
    );
  }

  Future<List<int>?> readState(String namespace) async {
    _validateNamespace(namespace);
    final encoded = await _storage.read(key: '$_statePrefix$namespace');
    if (encoded == null) return null;
    try {
      return base64Decode(encoded);
    } on FormatException {
      throw StateError('Stored E2EE state is corrupted; refusing to reset it.');
    }
  }

  Future<void> deleteState(String namespace) async {
    _validateNamespace(namespace);
    await _storage.delete(key: '$_statePrefix$namespace');
  }

  Future<void> deleteAllProtocolState() async {
    final all = await _storage.readAll();
    for (final key in all.keys.where((key) => key.startsWith(_statePrefix))) {
      await _storage.delete(key: key);
    }
    // Deliberately preserve the device id; account/device reset must be an
    // explicit, separately confirmed operation.
  }

  void _validateNamespace(String namespace) {
    if (namespace.isEmpty ||
        namespace.length > 120 ||
        !RegExp(r'^[a-zA-Z0-9_.-]+$').hasMatch(namespace)) {
      throw ArgumentError.value(namespace, 'namespace', 'Invalid store namespace');
    }
  }
}
