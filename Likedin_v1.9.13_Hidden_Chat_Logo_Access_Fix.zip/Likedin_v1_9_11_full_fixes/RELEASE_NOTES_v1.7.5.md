# Likedin 1.7.5 (build 35)

## Chat experience
- Reworked the message composer into a rounded, adaptive input bar.
- Send control animates into its active state as text is composed; sending gives a light haptic response.
- Newly rendered message bubbles use a short fade-and-rise entrance animation.
- Message bubbles have updated spacing, corner treatment and subtle elevation.
- Swipe either direction on a message to reveal a reply affordance and start a reply; haptic feedback confirms the gesture.
- Long-press message actions remain available.

## Profile photo
- Added local profile-photo selection from the device image picker through the profile menu.
- The selected image is copied into app-private storage and persists across launches.
- The profile avatar in the app header updates immediately.
- This version stores the photo locally on the device; it does not upload or synchronize profile photos to the other account.

## Compatibility / safety
- Existing package ID, Supabase messaging, FCM notification path, calls and message storage are retained.
- Uses dependencies already present in pubspec.yaml (file_picker and path_provider).
- Build and real-device performance still require GitHub Actions and Vivo testing.
