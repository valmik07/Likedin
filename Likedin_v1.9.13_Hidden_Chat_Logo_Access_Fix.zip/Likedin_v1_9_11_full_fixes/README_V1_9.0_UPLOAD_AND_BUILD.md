# Likedin v1.9.0+89 — Upload and Build

## GitHub upload

1. Open the Likedin GitHub repository.
2. In the repository root, remove the previous Likedin source ZIP.
3. Upload `Likedin_v1.9.0_gallery_gboard_low_memory.zip` to the root. Keep this as the only root-level `.zip` file.
4. Replace the existing workflow under `.github/workflows` with `likedin_workflow_option_A_v1.9.0.yml` (or copy its contents into the current workflow file).
5. Commit and run **Likedin Android APK** on `main`.

No GitHub signing secrets are required for Option A. Debug signing can produce a certificate mismatch across clean GitHub runners, so a later permanent signing-key setup is still recommended before relying on in-place APK updates. Do not uninstall an existing installation if Android reports a signature mismatch; send the error first.

## What's new

- WhatsApp-style in-app gallery with albums, filters, paged thumbnails and multi-select.
- Gboard image-keyboard support, including direct GIF insertion and a native content-URI fallback.
- Low-memory improvements targeted at Android 11 / 3 GB RAM.

No backend SQL changes are needed for these features. The existing Supabase media pipeline accepts `image/gif` and handles the upload.

The build workflow performs `flutter pub get`, `flutter analyze`, tests and an ARM64 release APK build. The source has not been compiled in this environment; review the Actions logs before installing.
