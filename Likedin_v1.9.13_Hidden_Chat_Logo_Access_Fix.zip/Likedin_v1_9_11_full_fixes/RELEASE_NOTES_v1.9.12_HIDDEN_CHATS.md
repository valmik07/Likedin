# Likedin v1.9.12 — Password-Protected Hidden Chats

## Frontend changes

- Added a **Hide chat** action to the conversation card menu.
- Added a separate hidden-chat password (minimum 8 characters). The password is not stored in plaintext; a salted PBKDF2-HMAC-SHA256 verifier is stored through `flutter_secure_storage` and Android Keystore-backed storage.
- Added password change while the hidden area is unlocked. Forgot-password recovery verifies the user's existing Supabase account credentials through the app's current sign-in endpoint before allowing a new hidden-chat password to be set.
- Hidden conversation IDs are stored locally in secure storage and removed from the normal Home conversation area.
- Added a **Hidden chats** entry that requires password verification and offers **Open chat** or **Unhide chat**.
- Chat and Files-tab access is guarded for all existing entry points, including notification taps and the New message action; the password session remains available only while moving between those protected areas. The shared-media gallery hides attachments from the hidden conversation while locked and reveals them only after authentication; encrypted backup export asks for the hidden-chat password before including chat history.
- Hidden-chat access automatically locks 3 minutes after unlocking, immediately when leaving both protected areas (Chat and Files), and after the app remains in the background for 15 seconds. Returning from a short-lived system UI (for example, a media picker) cancels the background lock timer.
- Android `FLAG_SECURE` stays enabled for as long as any chat remains hidden, including while locked and in the task switcher, and is cleared only after all hidden chats are restored; screenshots and screen recording are blocked while the feature is active.
- Incoming message-notification previews use generic wording while a chat is hidden. Incoming and missed-call notifications are not suppressed.
- Hiding/unhiding does not delete messages or modify remote delivery/read status, calls, Supabase tables, RLS policies, or Storage policies.

## Local security model and limits

This is a device-local app access gate, not a replacement for account authentication or server-side authorization. A person with access to the signed-in app session, a compromised/rooted device, or direct authorized database access may still access remote data outside this UI. The password verifier and hidden-chat metadata are protected by the platform secure-storage integration; the conversation itself is not re-encrypted by this feature.

Forgot-password recovery requires an internet connection and re-verifies the current Supabase account using its existing Likedin sign-in password. If that account credential is also unavailable, there is no bypass; the hidden-chat password cannot be reset from this app. Unhide also requires successful hidden-chat unlock.

## Validation

Added unit tests for password verification, hidden-ID persistence, notification-redaction preference synchronization, and minimum password length. Flutter analyzer, tests, and Android APK build must still be run in the project's GitHub Actions environment because Flutter/Dart SDK binaries are not available in the packaging environment.
