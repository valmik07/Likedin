# Likedin 1.7.26 — Resumable upload RLS fix

- Removed the unnecessary `x-upsert: true` header from TUS upload creation.
- Media objects already use a fresh UUID-based path for each queued upload, so overwriting is not required.
- This keeps uploads on the INSERT-only path and avoids requiring upsert-specific SELECT/UPDATE permissions for new files.
- Existing private bucket and row-level security policies remain in place.

Validation: source-level check confirms the TUS request no longer sends `x-upsert`; Flutter compilation/device upload testing still required.
