# Likedin UI integration — Stage 1 + Stage 2 + Stage 3

Source iteration: **1.8.9+88**

This source is based on the supplied Stage 3 archive. It integrates the Stage 1 Home/glass surfaces, Stage 2 conversation/search changes, and Stage 3 call UI, then replaces the remaining flat Auth, Files/Downloads, and Preferences layouts so the app has one consistent visual language.

## Visual direction

- Keep the established blue-and-white Likedin identity and **light mode as the default**. Dark mode remains user-selectable.
- Use restrained frosted-glass surfaces: near-opaque theme-aware panels, a very low blur (capped at 4 px), a faint outline, and no neon glow or decorative shadow.
- Keep surfaces readable and inexpensive to render on Android 11 / 3 GB devices; do not blur every message bubble or animate background layers.

## Integrated screen coverage

- **App shell:** glass header and bottom navigation, with the same appearance in either theme.
- **Sign-in / account creation:** ambient page background and one restrained glass form panel; authentication actions and Supabase account limit are unchanged.
- **Home:** refreshed welcome and briefing cards on the shared ambient background.
- **Chat:** frosted header/composer and translucent message surfaces; local text/attachment search, media filters, date range, and result count.
- **Calls:** theme-aware call history, incoming/outgoing/active-call UI, explicit high-contrast filter pills, and callback actions.
- **Files / Downloads:** shared attachments, save-files action, on-device storage summary, downloaded-file list, and empty state all use the shared panel treatment.
- **Preferences & privacy:** account row, dark-mode toggle, notifications, local security status, encrypted backup, transport security, and About surfaces share the same panels.

## Regression corrections

- Call history follows the app's selected light/dark preference.
- Call filter pills use explicit high-contrast colors in both themes.
- Long account email addresses stay on one line and truncate cleanly.
- Reply target resolution maps optimistic client IDs to committed database row IDs for text, voice, and attachment replies; sending a reply to a not-yet-committed item is blocked with a clear prompt.
- Runtime and package version labels are aligned at 1.8.9+88.

## Source organization note

The current project keeps its application routing, state, services, and several screen widgets together in `lib/main.dart`. The older screen layouts were replaced in place; deleting `main.dart` or removing those classes as though they were standalone unused files would remove active app functionality. Shared visual primitives live in `lib/ui/glassmorphism.dart` and search UI helpers in `lib/ui/message_search.dart`.

## Backend and security scope

- No SQL migration, Edge Function, authentication, RLS, storage, notification, WebRTC signalling/service, encryption, or backup implementation was intentionally changed in this visual pass.
- No new Flutter dependency was added.

## Validation limits

- ZIP integrity and Dart delimiter checks are performed when this archive is assembled.
- This environment does not have the Flutter/Dart SDK, so `flutter analyze`, `flutter test`, and APK compilation are not run here. GitHub Actions remains the compile/test gate.

## Device regression checklist

1. Verify Sign-in, Home, Chat, Calls, Files, and Preferences in both light and dark modes.
2. Confirm the glass effect is barely visible: readable white/blue surfaces, a faint edge, no neon glow, and no heavy blur.
3. In Files, test shared attachment open/save, refresh, local import, local open, and delete-copy actions.
4. On Calls, test all filters, empty/error states, refresh, realtime history, and callbacks.
5. On Chat, test text and attachment search, each media filter, date bounds, older-message pagination, and composer behavior.
6. Send replies to existing and just-sent photo/text/voice attachments; verify both devices point to the same original message.
7. Test sign-in and create-account flows, dark-mode persistence, notification settings, and encrypted backup export.
8. Test incoming/outgoing audio and video calls, controls, ending a call, repeated calls, notifications, and call history.
