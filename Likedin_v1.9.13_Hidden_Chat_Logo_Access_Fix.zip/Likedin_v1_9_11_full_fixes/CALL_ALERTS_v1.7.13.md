# Likedin 1.7.13 — Call alerts

## Changes
- Incoming calls play the Android user's selected default ringtone on a loop while the call remains in `ringing` state.
- Incoming-call vibration starts with the ringtone and repeats until answer, decline, remote timeout/end, or dialog disposal.
- Outgoing calls play Android's standard telephone ringback tone while waiting for an answer.
- Ringback/ringtone and vibration are stopped when a call is answered, declined, ended, times out, or the app activity is destroyed.
- Added the Android `VIBRATE` permission.

## Backend
No SQL migration, Edge Function change, or Supabase secret change is required.

## Build
Use the existing GitHub Actions workflow. No workflow changes are required.

## Device notes
Incoming ringtone follows the device's default ringtone selection and ringtone volume. Vibration follows the device's vibration capability/settings. Android Do Not Disturb, silent mode, manufacturer battery policies, and user-disabled vibration may suppress alerts.
