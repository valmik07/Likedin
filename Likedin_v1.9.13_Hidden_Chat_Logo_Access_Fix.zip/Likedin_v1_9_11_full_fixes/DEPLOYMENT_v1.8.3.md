# Likedin v1.8.3+80 — Deployment sequence

Apply backend changes before installing this APK on either phone.

## 1. Apply the database migration

In the Supabase SQL Editor, apply:

`supabase/migrations/202611200001_v183_medium_reliability.sql`

The migration:
- Adds `messages.deleted_media_path`.
- Changes signup reservations so no more than two registrations can be pending/confirmed at a time.
- Makes an unconfirmed user a reserved account, not an approved pair member.
- Cleans unconfirmed registrations older than 48 hours.
- Recreates message limits/RPCs and core RLS policies.
- Replaces Storage policies for the `likedin-media` bucket.
- Schedules cleanup hourly if `pg_cron` is already enabled.

The migration intentionally aborts if it finds more than two confirmed Auth users or cannot safely map them to the two account slots. Do not bypass that error; inspect `auth.users` and `public.account_slots` first.

If `pg_cron` is not enabled, `likedin_can_register_account()` still invokes cleanup before checking signup capacity. Enable the `pg_cron` extension in Supabase to get hourly cleanup even when nobody is attempting signup; a service-role job can also call `public.likedin_cleanup_unconfirmed_signups()`.

The old delete-for-everyone flow did not preserve Storage paths in tombstones. Media deleted before this migration may therefore remain orphaned in the bucket and cannot be mapped automatically by this release; future deletions preserve the path and clean both devices.

## 2. Confirm the email redirect allowlist

In Supabase Dashboard → Authentication → URL Configuration, include this exact redirect URL:

`com.example.likedin://login-callback/`

The Android manifest already declares the matching `com.example.likedin` scheme and `login-callback` host.

## 3. Deploy updated push Edge Functions

The three push functions now import the shared webhook-auth helper. Deploy each one so the helper is included:

```bash
supabase functions deploy send-message-push --no-verify-jwt
supabase functions deploy send-incoming-call-push --no-verify-jwt
supabase functions deploy send-missed-call-push --no-verify-jwt
```

Keep the existing `LIKEDIN_PUSH_WEBHOOK_SECRET`, Firebase service-account secret, Supabase URL, and service-role configuration unchanged. Do not place service-role credentials in the APK.

## 4. Build the Android APK

Run the existing GitHub Actions workflow. It now fails on analyzer warnings/infos and runs the Flutter tests before building.

On the first run without a checked-in `pubspec.lock`, CI resolves dependencies and uploads an artifact named `likedin-pubspec-lock`. Download the `pubspec.lock` file from that artifact, place it at the repository root, and commit it. The workflow then uses `flutter pub get --enforce-lockfile` on later builds.

## 5. Install and verify both phones

Install the same signed ARM64 APK on both Android devices. Use `REGRESSION_TEST_PLAN_v1.8.3.md` to verify chat, uploads, deletion, signup, calls, and app-resume behavior.
