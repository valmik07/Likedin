# Likedin v1.7.2 — UI and chat usability update

- Added a branded start/welcome screen with a Get started action before authentication.
- Redesigned the outgoing call dialog with a dark call surface, clearer call status, video preview area, and labelled call controls.
- Added composer focus and keyboard metric handling to scroll the conversation to the latest message when the keyboard opens, keeping the newest message visible above the composer/keyboard.
- Preserved the animated typing bubble and existing chat/receipt behaviour from v1.7.1.

## Important status
- This release does not claim to fix the currently failing two-phone call flow. Incoming-call detection/acceptance and end-to-end call signalling still require implementation and device testing.
- No new Supabase SQL migration is required for these UI changes.
- Flutter build and physical-device testing have not been run in this environment.
