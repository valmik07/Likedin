# Likedin v1.0 — Real-time messaging source increment
- Replaced local-only chat sending with Supabase RPC-based message submission.
- Added conversation history fetch and Supabase Realtime insert subscription.
- Added secure server-side peer discovery and send validation.
- Added SQL migration `0003_realtime_messaging.sql`.

This is not E2EE. Messages are TLS-protected in transit but readable by the Supabase project. No APK build or two-device test has been completed for this package.
