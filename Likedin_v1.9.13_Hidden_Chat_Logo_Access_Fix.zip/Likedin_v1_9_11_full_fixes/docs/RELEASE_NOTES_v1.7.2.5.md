# Likedin v1.7.2.5 — APK size optimization

- Removed the declared `libsignal` dependency because no Dart source imports it and the project explicitly does not use its protocol adapter. This avoids resolving and packaging an unused native/Rust dependency where applicable. It does not change the app's current messaging encryption model or add end-to-end encryption.
- Kept all dependencies that are imported by the app, including WebRTC, Firebase messaging, secure storage, local database, and attachment picker.
- No features were intentionally removed.

## Recommended Android release build

Use Flutter's ABI-split APK output to avoid shipping one APK containing native libraries for every CPU architecture:

```bash
flutter pub get
flutter build apk --release --split-per-abi
```

Flutter creates separate APKs for supported ABIs (typically `app-armeabi-v7a-release.apk`, `app-arm64-v8a-release.apk`, and `app-x86_64-release.apk`). Install the matching APK on each phone. Most modern Android phones use `arm64-v8a`, while some older phones use `armeabi-v7a`. Do not install an ABI-specific APK on a phone with a different ABI.

For a single APK compatible with both phones, use `flutter build apk --release` instead; it will generally be larger because it bundles multiple ABIs.

## Verification status

Source archive integrity can be checked separately. Flutter dependency resolution, APK size, release compilation, and two-device runtime performance must be verified by the project's GitHub Actions build and physical-device tests. No APK size reduction percentage is claimed without comparing actual release APKs.
