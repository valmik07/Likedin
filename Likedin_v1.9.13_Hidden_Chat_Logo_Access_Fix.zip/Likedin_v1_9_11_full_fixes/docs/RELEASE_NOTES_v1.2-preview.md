# Likedin v1.2 preview — E2EE integration groundwork

This package is a development preview based on v1.1. It adds a Supabase public
**device-key registry schema** and an implementation contract for the next
client increment. It does not yet implement the Signal Protocol in Flutter and
must not be described or used as an end-to-end encrypted release.

## Included

- `0005_e2ee_device_key_registry.sql`: stores only public identity and signed
  prekey material, scoped to the two registered Likedin accounts by RLS.
- Existing v1.1 chat, presence, typing, receipt, and nickname source is retained.
- Explicit protocol and release acceptance requirements are documented.

## Not included / not yet safe to claim

- No Signal Protocol / libsignal client integration.
- No X3DH/PQXDH or Double Ratchet session implementation.
- No private-key generation or Android Keystore-backed identity lifecycle.
- No ciphertext-only message enforcement. Existing `encrypted_payload` currently
  carries readable message text from the Flutter client.
- No encrypted media transfer, backup key recovery, or two-device crypto test.

Do not run this as an E2EE release and do not send sensitive content. The new
migration is groundwork only. A later client release must encrypt before calling
`likedin_send_message`, reject plaintext payloads, verify peer prekey signatures,
keep private keys on-device, persist ratchet state transactionally, and pass
interoperability, replay, tampering, offline-delivery, and identity-change tests.

## Build

The project retains the v1.1 Android/Flutter configuration. Build with the
existing GitHub Actions workflow. A successful APK build verifies compilation
only; it does not verify cryptographic security or two-phone functionality.
