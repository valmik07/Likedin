# Likedin v1.5 — chat stability, receipts and push delivery

## Included in this source package

- Chat messages are held in state instead of replacing the `FutureBuilder` future after every send. The conversation stays mounted while a message is sent.
- New outgoing messages appear optimistically and are reconciled with the server result.
- The chat page reports visibility to the notification service; foreground push alerts are suppressed while the conversation is open.
- Read receipts are only requested while the app is resumed and the Chat tab is selected. The previous unconditional read calls during chat initialization and app resume were removed.
- Delivery receipts are acknowledged after the recipient app synchronizes messages, not merely because the Chat widget was constructed.
- Notification taps route to the Chat tab.
- A Supabase Edge Function is included to send generic FCM notifications after a message insert. It never includes message text in lock-screen notifications.
- Invalid FCM registration tokens are removed after FCM reports them as invalid.

## Important receipt semantics

A grey double tick means the recipient app has synchronized the message and acknowledged it. A blue double tick means the recipient opened the visible Chat tab and the app acknowledged the unread messages as read.

FCM's server acceptance response is not proof that Android displayed a notification or that a device received it. If the recipient force-stops the app, disables notifications, has no network, or Android/OEM battery management blocks delivery, notification and delivery timing can be delayed. The next successful app sync acknowledges pending messages.

## Required one-time setup (cannot be completed from the APK alone)

### 1. Deploy the Edge Function

From the project root, with Supabase CLI linked to your existing Supabase project:

```bash
supabase functions deploy send-message-push --no-verify-jwt
```

### 2. Create a Firebase service account

In Firebase Console, open Project settings → Service accounts → Generate new private key. Keep the downloaded JSON private. Do not put it in the app, GitHub repository, or this ZIP.

Set these Supabase Edge Function secrets:

```bash
supabase secrets set LIKEDIN_PUSH_WEBHOOK_SECRET="a-long-random-secret"
supabase secrets set FIREBASE_SERVICE_ACCOUNT_JSON='{"type":"service_account",...}'
```

The service account must belong to Firebase project `likedin-c6682` and have permission to send Firebase Cloud Messaging messages. `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` are provided automatically to Supabase Edge Functions. Never put the service-role key in the Android app.

Use the same random secret in the Database Webhook header below. Do not use the example text literally.

### 3. Configure the Supabase Database Webhook

In Supabase Dashboard → Database → Webhooks, create a webhook:

- Name: `likedin-message-push`
- Table: `public.messages`
- Events: INSERT only
- Type: Supabase Edge Function
- Function: `send-message-push`
- HTTP header: `x-likedin-webhook-secret: <same random secret>`

The Edge Function validates this secret, looks up the recipient's FCM token using the service role, and sends a generic notification. Do not include message body text in webhook payloads or notification text.

### 4. Confirm token registration

After installing this APK, sign in. The app requests an FCM token and upserts it into `public.likedin_push_tokens`. Confirm the signed-in account has one row. Token refreshes are also saved.

The existing `202611090002_push_tokens.sql` migration must already have been run in Supabase. If it has not, run it once in SQL Editor.

## Test plan

Use two physical Android phones and two registered Likedin accounts:

1. Keep recipient on Home, app open: send a message. A notification should appear; opening it should take the recipient to Chat.
2. Keep recipient on Chat: send a message. No duplicate foreground notification should appear; message should appear without a full-screen loading refresh.
3. Put recipient app in background: send a message. Android should display a generic Likedin notification.
4. Send while recipient is offline: when recipient reconnects and opens Likedin, the message should sync and show grey double tick on sender; open Chat to change it to blue.
5. Confirm that opening Likedin on Home alone does not turn incoming messages blue.

## Not yet verified

The source ZIP has not been compiled or exercised on two devices in this environment. Firebase credentials, Supabase Edge Function deployment, webhook configuration, OEM background restrictions, and end-to-end notification delivery require the setup and test steps above.
