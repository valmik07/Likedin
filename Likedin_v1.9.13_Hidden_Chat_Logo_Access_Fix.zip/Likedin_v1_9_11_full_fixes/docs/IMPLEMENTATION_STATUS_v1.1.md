# Implementation status — v1.1

| Feature | Status |
|---|---|
| Online / last seen | Implemented in source; requires migration and two-device test |
| Typing indicator | Implemented in source; requires migration and two-device test |
| Sent / delivered / read ticks | Implemented in source; requires migration and two-device test |
| Other user's profile name | Implemented in source; profile must exist |
| Per-device nickname | Implemented locally |
| Async setState crash shown in v1.0 screenshot | Fixed in message refresh paths |
| End-to-end encryption | Not implemented |
| Remote media transfer | Not implemented |
| Live audio/video calls | Not implemented |
| Verified Android build | Pending GitHub Actions |
