# Likedin v1.6.0 — Experimental calling preparation

This package is based on the user-tested v1.5.2 source.

## Included in this experimental package
- Flutter WebRTC dependency added (`flutter_webrtc`).
- Android camera, microphone and audio-routing permissions declared.
- Version bumped to 1.6.0+17.
- Existing messaging, push notifications, receipts and chat scrolling source retained.

## Important status: NOT YET LIVE CALLING
This is a dependency/Android-permission integration build for validating the native WebRTC plugin against the existing Android/Flutter toolchain. It does NOT yet implement a working call flow. The existing call buttons remain setup placeholders. No incoming call, outgoing call, media capture, SDP/ICE signalling, call notification, TURN fetch endpoint, or call history is activated by this package.

Do not treat a successful APK build as proof that calls work. After GitHub Actions, verify plugin compilation and installation first. Then the next implementation step is the authenticated Supabase TURN-config endpoint and call-signalling schema/functions, followed by the Flutter call state machine and UI.

## ExpressTURN secrets
The app package does not contain TURN credentials. Keep the existing TURN_SERVER_URL, TURN_USERNAME and TURN_PASSWORD in Supabase Edge Function Secrets. Never put the username/password in Dart source, GitHub, or the APK. A secure authenticated Edge Function must be implemented before clients can retrieve temporary/usable ICE server configuration.

## Test requested
1. Run the existing GitHub Actions workflow.
2. Share the full build log if dependency resolution or Android native compilation fails.
3. If it succeeds, install and verify ordinary messaging, notifications, receipts and chat scrolling remain intact.
4. Do not test calls yet; live calling is not implemented in this package.
