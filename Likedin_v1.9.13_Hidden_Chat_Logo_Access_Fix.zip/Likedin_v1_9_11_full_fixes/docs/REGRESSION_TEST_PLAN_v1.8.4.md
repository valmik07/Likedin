# Likedin v1.8.4 regression plan

Run on both paired Android phones after applying the v1.8.4 migration and installing the v1.8.4+82 build.

## Message idempotency / duplicate bubble
1. Send one text message from phone A to phone B.
2. Confirm exactly one bubble appears on A and exactly one appears on B.
3. Confirm A's bubble receives delivery/read state on the existing message; no second copy should appear.
4. Repeat while briefly switching A's network off immediately after tapping Send, then restore it and retry the same draft. Confirm only one database row for that `client_message_id` and one visible bubble on each phone.
5. Send two intentionally identical texts as separate sends. Confirm both appear, proving the fix doesn't collapse separate messages merely because the text matches.

Read-only database duplicate diagnostic:

```sql
select sender_id, client_message_id, count(*) as copies,
       array_agg(id order by created_at) as row_ids
from public.messages
where client_message_id is not null
group by sender_id, client_message_id
having count(*) > 1;
```

Expected: no rows for sends made by v1.8.4. Existing historical duplicates, if any, are reported but are not automatically deleted.

## Reply-to-media
1. Send a photo from A to B and wait for the image preview to finish loading.
2. Reply to that photo from B with text; verify the quote says `Photo · filename` and the original photo remains visible.
3. Reply to the photo with another attachment; verify the new attachment's reply quote points to the original photo.
4. Repeat with a video and with a media target older than the latest 100 messages.
5. Restart the app and verify reply summaries still identify older media targets.

## Cross-device profile photo
1. Apply the v1.8.4 SQL migration first.
2. On phone A, open the account/profile menu and select/reselect a photo (max 5 MB).
3. Verify the other phone's chat header displays A's photo.
4. Repeat from B to A.
5. Change the photo again and verify the other phone refreshes to the new image.
6. Verify a signed-out or non-pair account cannot read these private files.

## Realtime quota / no history deletion
1. In Supabase Dashboard, record the project's Realtime Messages usage before testing.
2. Type a short message with multiple keystrokes. Confirm typing status sends only an idle-to-typing and typing-to-idle transition per typing burst, rather than one broadcast per character.
3. Leave each app foregrounded for 10 minutes. Presence should write no more often than one online update about every 55 seconds per phone.
4. Send/receive a few messages and verify inserts/receipt updates still work.
5. Recheck Supabase Organization → Usage → Realtime Messages after the test.

The app does not delete old messages to manage the monthly Realtime quota. Realtime message quota and database disk usage are separate limits.
