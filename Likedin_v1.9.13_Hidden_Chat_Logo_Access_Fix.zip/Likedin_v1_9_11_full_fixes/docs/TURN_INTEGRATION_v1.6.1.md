# Likedin v1.6.1 — TURN configuration integration

This update adds the authenticated TURN configuration endpoint and Flutter client service. It does **not** implement the full call state machine or prove two-phone calling. WebRTC peer connections can consume the returned ICE server list once call signalling is implemented.

## Existing Supabase Edge Function secrets
Keep these existing secrets exactly as configured:
- `TURN_SERVER_URL` — e.g. `turn:free.expressturn.com:3478?transport=udp`
- `TURN_USERNAME`
- `TURN_PASSWORD`

Optional:
- `TURN_SERVER_URLS` — comma-separated additional URLs only if the provider dashboard explicitly supplies them (for example a documented TCP/TLS URL). Do not guess ports or transports.

The function also uses Supabase's standard `SUPABASE_URL` and `SUPABASE_ANON_KEY` environment variables. It does not use the service-role key.

## Deploy
1. Supabase Dashboard → Edge Functions → Deploy new function, name `get-turn-config`.
2. Paste `supabase/functions/get-turn-config/index.ts` and deploy.
3. Keep JWT verification **enabled**. The function independently validates the bearer token using `auth.getUser`.
4. Do not add TURN credentials to Flutter, GitHub, or app build variables.

## Flutter use
`TurnConfigService(Supabase.instance.client).createPeerConnectionConfiguration()` returns the `iceServers` configuration for `flutter_webrtc` `createPeerConnection(...)`. Fetch it only after sign-in and cache only in memory for the current call. Never log the response.

## Important limitations
- ExpressTURN's free account uses static username/password credentials; this endpoint protects them from being bundled in the APK, but an authenticated app user can still retrieve them at runtime. This is not equivalent to provider-issued short-lived credentials.
- The endpoint does not create incoming/outgoing calls. Supabase call signalling, SDP/ICE exchange, call UI, push handling and call lifecycle remain separate implementation work.
- The configured URL must exactly match the endpoint and transport shown in the ExpressTURN dashboard. Add TCP/TLS only if the provider explicitly documents those endpoints for this account.
- A successful endpoint response is not proof that TURN relay connectivity works. Test using two phones on different networks and inspect ICE candidate-pair selection.
