# Likedin v1.7.3.7 — UI refresh and call reliability patch

## Changes in this source package
- Bumped Android version to 1.7.3+33; kept application ID `com.example.likedin`.
- Added Android `USE_FULL_SCREEN_INTENT` permission and configured call notifications to use full-screen intent.
- Enabled lock-screen presentation flags for the main activity. Android/Vivo settings and OS policy can still prevent a full-screen alert.
- Reworked proximity handling to listen to the physical proximity sensor and acquire the screen-off wake lock only after a NEAR reading. It releases on FAR, speaker mode, video calls, call end, and Activity teardown/pause.
- Removed Chat, Calls, and Files from the bottom navigation. Chat and Calls are in the compact top overflow menu; tapping the profile avatar opens the complete local Files area.
- Added persistent light/dark appearance setting.
- Removed the prominent home-feed shortcut to the conversation.

## Important limitations
- This is a source-level audit and patch, not a claim that every possible bug has been found. The project has not been compiled or run on physical Vivo devices in this environment.
- Full-screen notification behaviour depends on Android version, notification permission, full-screen-intent special access, and Vivo firmware. The user may need to allow Likedin under Android special app access after installing this build.
- Files are local copies only. This build does not add cloud file transfer.
- Existing app disclosures remain: end-to-end encryption is not implemented; local message-body encryption and TLS/account access controls are separate protections.
- Existing backend functions, message push trigger, Supabase schema, Firebase credentials, and package ID are intentionally unchanged.

## Required validation
1. Run GitHub Actions and inspect the complete Flutter/Gradle log.
2. Install as an update only if the signing certificate matches the installed build.
3. Test calls with app open, minimized, and screen locked on both Vivo devices.
4. Test proximity FAR/NEAR, speaker on/off, video call, and end-call cleanup.
5. Test chat send/receive, typing, receipts, edit/reply/reactions/delete, and message notification sound.
6. Toggle dark mode, restart app, and verify persistence and contrast on both devices.
