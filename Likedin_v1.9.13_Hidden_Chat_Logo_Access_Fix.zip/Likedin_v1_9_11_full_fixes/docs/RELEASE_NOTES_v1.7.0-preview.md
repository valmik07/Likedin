# v1.7.0 preview — WebRTC outgoing call foundation

- Added authenticated TURN/STUN configuration retrieval.
- Added WebRTC peer connection setup for audio and video.
- Added SDP offer/answer and ICE candidate signalling through Supabase Realtime-backed tables.
- Added caller-side audio/video call dialog with mute, speakerphone, camera toggle, camera switch, and hang-up controls.
- Added Supabase SQL migration and setup/test instructions.
- Preview limitations: incoming-call acceptance UI, FCM call wake-up, call history/missed calls, and production lifecycle/reconnection handling are not complete.
