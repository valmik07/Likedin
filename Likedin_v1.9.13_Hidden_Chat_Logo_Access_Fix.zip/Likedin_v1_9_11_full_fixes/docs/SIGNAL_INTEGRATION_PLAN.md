# Signal integration plan

1. Resolve and pin the selected libsignal package version; inspect its exact source, release checksums, licence files, supported Android ABIs, and API docs.
2. Implement durable IdentityKeyStore, PreKeyStore, SignedPreKeyStore, KyberPreKeyStore, SessionStore, SenderKeyStore adapters backed by transactional local persistence. Store encryption keys in Android Keystore-backed secure storage; never store private key material in Supabase.
3. Generate a device identity and protocol-required prekeys on-device; publish only public bundle material. Add signed bundle verification and atomic one-time-prekey consumption.
4. Establish a session on both phones using the library APIs and protocol test vectors.
5. Change message send/receive to fail closed: encrypt before RPC; reject any non-versioned/non-ciphertext payload; decrypt only on recipient device. Keep legacy plaintext messages visibly marked as legacy and never silently reinterpret them.
6. Add identity-change warnings and QR/safety-number verification.
7. Add integration tests with two independent device stores, offline/replay/tamper/duplicate tests, and Supabase inspection proving no plaintext is present.

Do not create a custom X25519/AES ratchet or claim Signal compatibility without libsignal's protocol implementation.
