# Implementation status — v1.2 preview

| Requirement | Status |
|---|---|
| Existing v1.1 features retained in source | Yes; regression testing required |
| Public device-key registry migration | Added |
| Signal Protocol client | Not implemented |
| Android Keystore device identity lifecycle | Not implemented |
| Ciphertext-only message enforcement | Not implemented |
| Persistent encrypted offline outbox | Not implemented |
| Optimistic local message display | Not implemented in this preview |
| Encrypted media | Not implemented |
| Two-phone E2EE verification | Not tested |
| Android build | Not run in this environment; user can run existing CI |

**Security status: NOT E2EE.** Existing v1.1 message payloads are readable by the
Supabase project. The added migration stores public keys only and does not change
message encryption. See `E2EE_IMPLEMENTATION_CONTRACT.md`.
