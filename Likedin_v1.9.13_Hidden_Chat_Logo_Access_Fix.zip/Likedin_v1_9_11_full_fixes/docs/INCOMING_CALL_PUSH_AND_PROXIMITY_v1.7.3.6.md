# Likedin v1.7.3.6 — incoming call alerts and proximity

## App changes

- Adds a separate high-importance Android notification channel, `likedin_calls_v1`, with vibration and the bundled `likedin_call.wav` tone. The existing `likedin_messages_v1` channel and message notification code path remain separate.
- Incoming call FCM payloads contain only the call ID, caller ID, call type, and a generic notification. No message content is sent.
- Tapping an incoming-call push routes to the existing incoming-call dialog, which loads the current ringing call and waits briefly for the WebRTC offer if the call row arrived first.
- Adds Android's native `PROXIMITY_SCREEN_OFF_WAKE_LOCK` for audio calls using the earpiece. It is released for video calls, speakerphone, call end, and Activity teardown. Devices without support continue to allow calls without proximity screen control.
- Android 11+ remains the minimum. The APK remains ARM64-only in the existing workflow.

## Required Supabase setup (one-time)

This is separate from the APK. The app cannot send push notifications to itself when its process is dead; the Supabase database trigger and Edge Function must be deployed.

1. In Supabase Dashboard → Edge Functions, create `send-incoming-call-push` and paste `supabase/functions/send-incoming-call-push/index.ts`. Deploy it with JWT verification disabled. The existing secrets `LIKEDIN_PUSH_WEBHOOK_SECRET`, `FIREBASE_SERVICE_ACCOUNT_JSON`, and the automatically provided `SUPABASE_URL` / `SUPABASE_SERVICE_ROLE_KEY` are reused. Do not expose or rotate them for this change.
2. In Supabase Dashboard → SQL Editor, run `supabase/migrations/202611120002_incoming_call_push.sql` once. It creates a separate `AFTER INSERT` trigger on `likedin_calls`; it does not alter the working message-push trigger or `send-message-push` Edge Function.
3. Confirm the existing push token table has a token for each signed-in device. Open Likedin once after installation so the token can register/refresh.
4. On each phone, allow Likedin notifications and set the new **Likedin calls** notification channel to alerting with sound and vibration. Android notification-channel settings are controlled by the OS and may need manual adjustment on Vivo devices.

## Important Android limits

- High-priority FCM notifications are best-effort. Battery saver, OEM background restrictions, network loss, notification permission/channel settings, and force-stop can delay or prevent delivery. A force-stopped app generally must be opened manually before push resumes.
- This version uses a normal high-priority incoming-call notification, not a guaranteed full-screen/lock-screen takeover. Full-screen intents have additional Android version and user-permission restrictions and are intentionally not claimed here.
- Notification tap opens the existing in-app Accept / Decline UI; Answer/Decline action buttons directly on the notification are not included.
- Proximity screen-off depends on the handset's proximity sensor and Android firmware. Test with the phone at the ear, away from the face, and with speakerphone enabled.

## Two-phone test plan

1. Install build 32 on both phones, sign in, and confirm both push tokens exist.
2. With the callee app open, place an audio call. Existing Realtime incoming-call UI should still appear; proximity should turn the screen off near the ear and restore it when moved away.
3. Repeat with speakerphone on; the proximity screen-off wake lock should be released.
4. Repeat with a video call; proximity screen-off should remain disabled.
5. Put the callee app in background and lock the phone. Place a call. Confirm the Likedin calls notification appears with sound/vibration; tap it and answer.
6. Swipe the callee app away from Recents and repeat. Then repeat after a force-stop from Android Settings to verify/understand the expected force-stop limitation.
7. Send ordinary messages in both directions and confirm the existing message notifications and sound still work.

## Verification status

This source package has been patched and structurally inspected. It has **not** been compiled in this environment or tested on the two Vivo phones. GitHub Actions must confirm the APK build, then real-device tests must confirm FCM delivery and proximity behavior. Supabase Edge Function deployment and SQL migration are also required before background incoming-call pushes can work.
