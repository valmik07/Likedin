# Likedin v1.8.0 — deployment order

This release changes the Auth confirmation/slot flow, RLS and RPC membership checks, TURN credential endpoint, and call expiry. Deploy the backend pieces in this order before building/installing the v1.8.0 APK.

## 0. Preflight — do not skip

1. Take a Supabase database backup.
2. In SQL Editor, inspect how many Auth accounts are already confirmed and the current pair-slot assignment:

```sql
select
  count(*) filter (
    where email_confirmed_at is not null
       or phone_confirmed_at is not null
  ) as confirmed_auth_users,
  count(*) filter (
    where email_confirmed_at is null
      and phone_confirmed_at is null
  ) as unconfirmed_auth_users
from auth.users;

select slot, user_id
from public.account_slots
order by slot;
```

The migration intentionally stops if it finds more than two confirmed Auth users. Do not delete accounts to make the migration pass; review the account list and resolve the pair assignment deliberately first.

## 1. Apply the v1.8.0 SQL migration

Run these four files in Supabase SQL Editor, in numeric order:

1. `supabase/migrations/202611180001_v180_account_slots_and_pair_helpers.sql`
2. `supabase/migrations/202611180002_v180_pair_membership_hardening.sql`
3. `supabase/migrations/202611180003_v180_turn_credential_rate_limit.sql`
4. `supabase/migrations/202611180004_v180_server_call_expiry.sql`

They are split by deployment boundary so an error can be isolated. The changes are additive/replacement DDL and do not delete Auth users. The first migration may free a slot that was incorrectly assigned to an unconfirmed user. If any SQL Editor run reports an error, stop there and share the exact error; do not run later migrations or build against a partly upgraded backend.

## 2. Check Supabase Cron for no-answer expiry

The migration installs `public.likedin_expire_ringing_calls()`. It also attempts to schedule it every minute when the `pg_cron` extension is available and the current SQL role can schedule jobs.

Check whether Cron exists:

```sql
select to_regclass('cron.job') as cron_jobs_table;
```

If this returns `cron.job`, confirm the job:

```sql
select jobid, jobname, schedule, command
from cron.job
where jobname = 'likedin-expire-ringing-calls';
```

If the table is null or the job is absent, enable Supabase Cron from the project's Dashboard (Integrations / Cron), then schedule this SQL command every minute:

```sql
select public.likedin_expire_ringing_calls();
```

Do not treat A03 as live-fixed until the job is visible and a stale ringing call transitions to `missed` in a controlled test. The existing missed-call push trigger should fire from that status transition.

## 3. Deploy `get-turn-config`

In Supabase Dashboard → Edge Functions → `get-turn-config`, replace the function with:

`supabase/functions/get-turn-config/index.ts`

Deploy the function. Keep the existing function secrets:

- `SUPABASE_URL`
- `SUPABASE_ANON_KEY` (the project's anon/publishable JWT key exposed to Edge Functions)
- `SUPABASE_SERVICE_ROLE_KEY`
- `TURN_SERVER_URL` (and optionally `TURN_SERVER_URLS`)
- `TURN_USERNAME`
- `TURN_PASSWORD`

**Do not add `TURN_REST_CREDENTIALS_ENABLED=true` or `TURN_SHARED_SECRET` for the currently documented static-credential provider.** The function keeps the legacy static path by default, with the new membership and rate-limit checks. Temporary credentials are only enabled after the TURN provider is confirmed to support Coturn REST authentication with a configured shared secret. Enabling it on a static-only provider will break call connectivity.

A02 is partially hardened in this build; it is not fully closed until temporary credentials are enabled with a compatible provider and verified on both ends.

## 4. Build the Android ARM64 APK

Upload the contents of the v1.8.0 source ZIP to the repository used by the existing Actions workflow, then run the Android APK workflow. Keep the four existing release signing secrets configured. Do not change the application ID or keystore for this release.

## 5. Regression test before relying on the release

With two approved accounts/devices available:

- Confirm that a pending unverified registration does not consume either pair slot; two confirmed users fill the slots; a third confirmation is rejected without deleting any user.
- Load a call configuration as each pair member; verify a non-member receives 403 and repeated calls are rate-limited. In the current static provider mode, verify existing calls still connect.
- Start a call, force-stop the caller before the client timeout, and confirm the server Cron job marks it missed and the receiver gets the missed-call push.
- Queue a media file offline, close/reopen the app, restore connectivity, and confirm a single message is sent. Repeat with a voice note.
- Retry a text send after an intentionally lost response and confirm one server message exists.
- Exercise incoming decline when signaling insertion is unavailable; the server call row must still become rejected.
- Exercise ICE arriving during the initial candidate snapshot, and force a post-accept transport failure; candidates should be processed once and the call row should become terminal.
- Confirm Android 11 and Android 16 startup, notifications, audio calls, video calls, and attachment viewing.

## Known limitation

The migration and source package cannot prove live production behavior by themselves. SQL must be applied successfully, Cron must be verified, the Edge Function must be deployed with secrets configured, and the APK must build and pass device/network tests.
