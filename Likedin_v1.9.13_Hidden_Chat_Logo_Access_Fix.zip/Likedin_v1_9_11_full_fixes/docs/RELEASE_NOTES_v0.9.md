# Likedin v0.9 — backend expansion

This increment adds the next Supabase SQL migration for message delivery metadata, pair-restricted message insertion, call signalling, and Realtime publication. It is a backend migration package, not a completed remote messaging or calling client. See `IMPLEMENTATION_STATUS_v0.9.md` before applying it.
