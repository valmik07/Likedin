# Likedin 1.7.1 — call signalling and chat regression fixes

- Create the call database row before creating the peer connection, so early ICE candidates have a valid call ID.
- Subscribe to call signals before sending the SDP offer, avoiding the answer-subscription race on the caller.
- Queue remote ICE candidates until the remote SDP description has been applied.
- Restore the animated three-dot typing bubble in the conversation list.
- Remove the obsolete warning that claimed the call migration had not been applied.

## Known limitations

- This build still has no app-wide incoming-call watcher or incoming-call accept/reject screen. A recipient will not yet receive a usable incoming-call prompt while sitting elsewhere in the app.
- Proximity-sensor screen-off behavior is not implemented.
- Background/terminated incoming-call notifications are not implemented.
- Compilation and two-device call tests have not been run in this environment.
