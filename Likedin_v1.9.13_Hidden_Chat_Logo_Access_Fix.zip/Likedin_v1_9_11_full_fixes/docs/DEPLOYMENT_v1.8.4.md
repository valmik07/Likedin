# Likedin v1.8.4 deployment

1. In Supabase SQL Editor, run `supabase/migrations/202611210001_v184_profile_avatar_and_usage_optimization.sql` exactly once.
2. Confirm `public.profiles.avatar_path` exists and `public.likedin_set_profile_avatar(text)` is present.
3. No Edge Function redeployment is required. v1.8.4 does not change push functions or FCM payloads.
4. Upload `Likedin_v1.8.4_source.zip` as the single project ZIP at the root of the `valmik07/Likedin` GitHub repository. Remove the older project ZIP first; the existing GitHub workflow expects exactly one root ZIP.
5. Run the existing `Likedin Android APK` workflow on `main`. The workflow requires the four existing persistent signing secrets (`LIKEDIN_KEYSTORE_B64`, `LIKEDIN_STORE_PASSWORD`, `LIKEDIN_KEY_ALIAS`, `LIKEDIN_KEY_PASSWORD`).
6. Download and test the ARM64 APK on both Android devices.
7. Each account holder must select/reselect their profile photo once so it uploads to private Storage. Existing photos from v1.8.3 were only local files and are not automatically uploaded.
8. Follow `docs/REGRESSION_TEST_PLAN_v1.8.4.md`.

## Supabase Free tier notes

The 2 million Free-plan figure is a monthly Realtime-message quota, not a lifetime cap on rows in `public.messages`. Postgres changes count for each subscribed client receiving them; Broadcast and Presence are also usage. The client now filters subscriptions and throttles chatter while preserving receipts and message history. No automatic message deletion is enabled.

The Free plan also has separate database-size and Storage-size limits. Monitor the project in Supabase Dashboard → Organization → Usage. SQL examples for measuring table and Storage usage are in `docs/SUPABASE_FREE_TIER_CAPACITY_v1.8.4.md`.
