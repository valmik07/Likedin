# Likedin notifications setup

This release includes Firebase Android configuration, client-side FCM initialization/token registration, a generic foreground notification handler, notification tap routing, and a Supabase Edge Function sender.

Background push is not live until the owner completes the one-time Firebase service-account and Supabase webhook setup in `V1_5_PUSH_AND_CHAT_FIXES.md`.

Never embed a Firebase service-account private key or Supabase service-role key in the Android app or source ZIP.
