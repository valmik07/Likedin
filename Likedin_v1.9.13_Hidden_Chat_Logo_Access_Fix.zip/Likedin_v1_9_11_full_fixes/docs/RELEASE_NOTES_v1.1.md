# Likedin v1.1 — Presence, receipts and nicknames

## Included in source
- Supabase-backed online heartbeat and last-seen timestamp (30-second heartbeat; online considered stale after 90 seconds).
- Typing indicator using a shared pair-specific Supabase Realtime Broadcast channel.
- Sent/delivered/read receipt timestamps and UI ticks: one grey check, two grey checks, two blue checks.
- Peer display name loaded from the profile created at registration.
- Per-device nickname override stored locally; it does not alter the other user's profile name.
- Fix for the Flutter `setState() callback argument returned a Future` error in chat message refresh paths.

## Required backend step
Run `docs/migrations/0004_presence_receipts_nicknames.sql` in the Supabase SQL Editor after the existing Likedin migrations. It adds profile presence fields, receipt RPCs, and Realtime publication for profile updates.

## Important limitations
- Online status is heartbeat-based, not guaranteed instant under Android force-stop, network loss, or aggressive battery restrictions. It can take up to about 90 seconds to age out after an abrupt disconnect.
- Typing indicators are ephemeral and require both users to be connected to Realtime.
- Nicknames are stored locally on this device only. They do not sync to another device owned by the same user.
- Message content is still not end-to-end encrypted. TLS protects transport; Supabase can access stored payloads.
- Audio/video calling and remote media transfer are not implemented by this release.

## Build status
Source package prepared. A Flutter build and two-device integration test have not been run in this environment. Use the existing GitHub Actions workflow to validate the APK before installing.
