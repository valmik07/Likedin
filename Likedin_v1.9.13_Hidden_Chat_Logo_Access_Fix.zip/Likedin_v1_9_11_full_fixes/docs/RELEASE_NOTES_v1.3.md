# Likedin v1.3 — Signal integration and secure-state groundwork

## Included in source
- Adds the `libsignal` 9.0.0 Dart/Flutter binding dependency, which wraps Signal's upstream Rust implementation.
- Adds `ProtocolStateVault`, a secure-storage boundary for opaque serialized protocol state and a stable per-install device ID.
- Adds unit tests for device ID stability, opaque-state round trips, and namespace validation.
- Preserves the v1.1 chat and Supabase schema.

## Not yet implemented
- The app does not yet generate/publish Signal identity keys or signed/one-time/PQ prekeys.
- No libsignal identity/session/prekey/sender-key store adapters are wired.
- The current chat send path still submits readable message text in `encrypted_payload`; it is NOT E2EE.
- No encrypted session establishment, Double Ratchet send/receive, key verification, or ciphertext-only server enforcement.

This release is an integration milestone, not an E2EE release. Do not use it for sensitive conversations.

## Dependency and licensing review
The selected pub.dev wrapper is published by an unverified uploader and declares AGPL-3.0 with an app-store exception. Review upstream provenance, dependency source, licence obligations, ABI coverage, and release integrity before distributing an APK. The underlying implementation is Signal's libsignal Rust project.

## Nickname editor stability patch
- Replaced the modal nickname dialog with an inline editor in the chat header.
- Cancel now exits edit mode without pushing/popping a route, avoiding the route-disposal path that triggered the reported Flutter framework assertion on this device.
- Nickname remains local to the current device and is saved only when Save is tapped.
- This is a targeted fix based on the reported reproduction; it still requires a device retest.
