# Likedin v1.4 preview — notification foundation

- Added Android notification permission handling.
- Added a dedicated high-importance message notification channel.
- Added an original Likedin two-note notification sound.
- Added Flutter local notification support.
- Added Firebase Messaging foreground/background integration hooks.
- Added setup documentation for Firebase and a trusted Supabase-to-FCM sender.

This is a notification integration foundation, not a fully deployed push system. Firebase configuration, token registration, server-side push delivery, and physical-device testing remain required.
