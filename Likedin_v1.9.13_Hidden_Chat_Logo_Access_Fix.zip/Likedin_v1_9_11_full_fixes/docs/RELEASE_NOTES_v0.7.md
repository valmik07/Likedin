# v0.7 — backend foundation

- Preserves the v0.6.6 Flutter app and Android build configuration.
- Adds a Supabase SQL migration with an atomic global two-account signup guard.
- Adds a ciphertext-only messages schema and row-level security policies.
- Adds build-time configuration constants for the public Supabase URL/key.

Not included yet: app-side Supabase initialization, online sign-up/sign-in, E2EE key exchange, cross-device message sync, remote attachment storage, push notifications, or WebRTC calls. The existing local UI is unchanged and remains local-only.
