# Likedin Supabase setup

The Supabase project has already been created and the initial SQL schema has been run by the project owner. This version initializes the Flutter Supabase client and uses Supabase Auth for registration and sign-in.

## Client configuration
The project URL and **publishable** key are configured in `lib/backend/backend_config.dart`. Both are public client configuration values. Never place a Supabase secret/service-role key in Flutter, source control, GitHub Actions, or an APK.

The values can also be overridden at build time:

```powershell
flutter build apk --debug --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co --dart-define=SUPABASE_ANON_KEY=YOUR_PUBLISHABLE_KEY
```

## Registration behavior
- Users create accounts with email and password.
- The display name is sent as Auth metadata. The SQL trigger creates the profile and reserves one of the two global account slots.
- If email confirmation is enabled, the user must confirm the email before signing in.
- The project must remain dedicated to Likedin because the database trigger limits the entire Supabase Auth project to two users.

## Important current limitations
The chat screen still uses the local encrypted SQLite store. It does not send messages to Supabase. The current SQL table's `encrypted_payload` column is not yet wired to a reviewed cross-device end-to-end encryption protocol. Do not claim E2EE or remote delivery. Attachments remain local-only and calls remain UI placeholders. These are the next engineering milestones after authentication is tested on both phones.
