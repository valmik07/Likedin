-- Likedin v0.9 backend expansion.
-- Run AFTER the initial v0.8 schema in Supabase SQL Editor.
-- This migration prepares secure transport tables; it does NOT by itself
-- implement the Flutter client, E2EE sessions, push notifications, or WebRTC.

-- Add delivery metadata and client-generated idempotency key.
alter table public.messages
  add column if not exists client_message_id uuid,
  add column if not exists delivered_at timestamptz,
  add column if not exists read_at timestamptz;

create unique index if not exists messages_sender_client_id_uq
  on public.messages(sender_id, client_message_id)
  where client_message_id is not null;

-- Restrict message creation to the two occupied global account slots.
-- A user may only address the other registered account.
drop policy if exists "Users can send messages" on public.messages;
create policy "Pair members can send to the other member"
on public.messages
for insert to authenticated
with check (
  sender_id = (select auth.uid())
  and recipient_id <> (select auth.uid())
  and exists (
    select 1 from public.account_slots s
    where s.user_id = recipient_id
  )
);

-- Receipt updates are intentionally not enabled in this migration. A later
-- narrowly scoped SECURITY DEFINER RPC will update only delivered_at/read_at;
-- a broad UPDATE policy would let recipients alter message ciphertext.

-- Call signalling. SDP and ICE are ephemeral signalling data, not call media.
create table if not exists public.call_signals (
  id uuid primary key default gen_random_uuid(),
  caller_id uuid not null references auth.users(id) on delete cascade,
  callee_id uuid not null references auth.users(id) on delete cascade,
  call_id uuid not null,
  signal_type text not null check (signal_type in ('offer','answer','ice','hangup','reject','busy')),
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '1 day'),
  check (caller_id <> callee_id)
);
create index if not exists call_signals_callee_created_idx
  on public.call_signals(callee_id, created_at desc);
alter table public.call_signals enable row level security;
create policy "Call participants can read signals"
on public.call_signals for select to authenticated
using (caller_id = (select auth.uid()) or callee_id = (select auth.uid()));
create policy "Call participants can create signals"
on public.call_signals for insert to authenticated
with check (
  ((caller_id = (select auth.uid())) or (callee_id = (select auth.uid())))
  and exists (select 1 from public.account_slots s where s.user_id = caller_id)
  and exists (select 1 from public.account_slots s where s.user_id = callee_id)
);

-- Realtime publication is required for low-latency updates. If already present,
-- this DO block safely avoids adding duplicate publication membership.
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public' and tablename = 'messages'
  ) then
    alter publication supabase_realtime add table public.messages;
  end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public' and tablename = 'call_signals'
  ) then
    alter publication supabase_realtime add table public.call_signals;
  end if;
end $$;

-- NOTE: Do not create a public storage bucket for private attachments.
-- The app migration must create a private bucket and per-user object policies
-- only after ciphertext upload/download and client-side encryption are ready.
