-- Likedin E2EE groundwork: public device-key registry only.
-- This does NOT enable encrypted messaging by itself. Private keys must never
-- be uploaded. The Flutter Signal-compatible client must verify signatures,
-- establish sessions, encrypt payloads before RPC submission, and decrypt only
-- on the receiving device before this can be considered E2EE.

begin;

create table if not exists public.device_key_bundles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  protocol_version text not null,
  identity_public_key text not null,
  signed_prekey_id bigint not null,
  signed_prekey_public text not null,
  signed_prekey_signature text not null,
  updated_at timestamptz not null default now(),
  constraint device_key_protocol_nonempty check (length(protocol_version) between 1 and 40),
  constraint identity_key_nonempty check (length(identity_public_key) between 1 and 4096),
  constraint signed_prekey_nonempty check (length(signed_prekey_public) between 1 and 4096),
  constraint signed_prekey_signature_nonempty check (length(signed_prekey_signature) between 1 and 4096)
);

alter table public.device_key_bundles enable row level security;

 drop policy if exists "Users can read registered public device keys"
   on public.device_key_bundles;
create policy "Users can read registered public device keys"
  on public.device_key_bundles
  for select to authenticated
  using (exists (
    select 1 from public.account_slots s
    where s.user_id = device_key_bundles.user_id
  ));

 drop policy if exists "Users can publish only their own public device keys"
   on public.device_key_bundles;
create policy "Users can publish only their own public device keys"
  on public.device_key_bundles
  for insert to authenticated
  with check (user_id = (select auth.uid()) and exists (
    select 1 from public.account_slots s where s.user_id = (select auth.uid())
  ));

 drop policy if exists "Users can rotate only their own public device keys"
   on public.device_key_bundles;
create policy "Users can rotate only their own public device keys"
  on public.device_key_bundles
  for update to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()) and exists (
    select 1 from public.account_slots s where s.user_id = (select auth.uid())
  ));

commit;

notify pgrst, 'reload schema';
