-- Likedin v1.0: safe peer discovery and message submission RPCs.
-- Run after migrations 0001 and 0002 in Supabase SQL Editor.

create or replace function public.likedin_get_peer_id()
returns uuid
language sql
stable
security definer
set search_path = ''
as $$
  select s.user_id
  from public.account_slots s
  where s.user_id is not null
    and s.user_id <> (select auth.uid())
  order by s.slot
  limit 1;
$$;
revoke all on function public.likedin_get_peer_id() from public;
grant execute on function public.likedin_get_peer_id() to authenticated;

create or replace function public.likedin_send_message(
  p_recipient_id uuid,
  p_payload text,
  p_client_message_id uuid
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_sender uuid := auth.uid();
  v_id uuid;
begin
  if v_sender is null then
    raise exception 'Authentication required';
  end if;
  if p_payload is null or length(p_payload) = 0 or length(p_payload) > 10000 then
    raise exception 'Message must contain 1 to 10000 characters';
  end if;
  if p_recipient_id is null or p_recipient_id = v_sender then
    raise exception 'Invalid recipient';
  end if;
  if not exists (select 1 from public.account_slots s where s.user_id = v_sender)
     or not exists (select 1 from public.account_slots s where s.user_id = p_recipient_id) then
    raise exception 'Recipient is not a registered Likedin account';
  end if;
  insert into public.messages(sender_id, recipient_id, encrypted_payload, client_message_id)
  values (v_sender, p_recipient_id, p_payload, p_client_message_id)
  on conflict (sender_id, client_message_id) where client_message_id is not null
  do update set client_message_id = excluded.client_message_id
  returning id into v_id;
  return v_id;
end;
$$;
revoke all on function public.likedin_send_message(uuid, text, uuid) from public;
grant execute on function public.likedin_send_message(uuid, text, uuid) to authenticated;

-- Ensure the authenticated client can read only its own conversation rows.
drop policy if exists "Participants can read messages" on public.messages;
create policy "Participants can read messages"
on public.messages for select to authenticated
using (sender_id = (select auth.uid()) or recipient_id = (select auth.uid()));

-- No direct client inserts: all sends pass through the validated RPC.
drop policy if exists "Pair members can send to the other member" on public.messages;
drop policy if exists "Users can send messages" on public.messages;
