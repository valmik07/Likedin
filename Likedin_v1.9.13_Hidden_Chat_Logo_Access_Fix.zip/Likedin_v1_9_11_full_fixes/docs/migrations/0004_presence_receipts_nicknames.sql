-- Likedin v1.1: online/last-seen, delivery/read receipts and profile data.
-- Run once in Supabase SQL Editor after the previous Likedin migrations.
begin;

alter table public.profiles
  add column if not exists is_online boolean not null default false,
  add column if not exists last_seen_at timestamptz,
  add column if not exists updated_at timestamptz not null default now();

alter table public.messages
  add column if not exists delivered_at timestamptz,
  add column if not exists read_at timestamptz;

-- Keep profiles private to the two authenticated accounts; users can read the pair.
drop policy if exists "Users can view profiles" on public.profiles;
create policy "Users can view profiles"
on public.profiles for select to authenticated using (true);

create or replace function public.likedin_set_presence(p_online boolean)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  update public.profiles
     set is_online = coalesce(p_online, false),
         last_seen_at = now(),
         updated_at = now()
   where user_id = auth.uid();
end; $$;
revoke all on function public.likedin_set_presence(boolean) from public;
grant execute on function public.likedin_set_presence(boolean) to authenticated;

create or replace function public.likedin_mark_delivered()
returns integer language plpgsql security definer set search_path = '' as $$
declare changed integer;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  update public.messages
     set delivered_at = coalesce(delivered_at, now())
   where recipient_id = auth.uid() and delivered_at is null;
  get diagnostics changed = row_count;
  return changed;
end; $$;
revoke all on function public.likedin_mark_delivered() from public;
grant execute on function public.likedin_mark_delivered() to authenticated;

create or replace function public.likedin_mark_read()
returns integer language plpgsql security definer set search_path = '' as $$
declare changed integer;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  update public.messages
     set delivered_at = coalesce(delivered_at, now()),
         read_at = coalesce(read_at, now())
   where recipient_id = auth.uid() and read_at is null;
  get diagnostics changed = row_count;
  return changed;
end; $$;
revoke all on function public.likedin_mark_read() from public;
grant execute on function public.likedin_mark_read() to authenticated;

-- Realtime profile updates are used to refresh online/last-seen labels.
do $$
begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'profiles') then
    alter publication supabase_realtime add table public.profiles;
  end if;
end $$;

commit;
