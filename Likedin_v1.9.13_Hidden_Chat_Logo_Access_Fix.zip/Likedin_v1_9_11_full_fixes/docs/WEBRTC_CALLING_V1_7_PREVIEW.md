# Likedin WebRTC calling preview

This package adds an initial WebRTC outgoing-call implementation (audio/video), TURN configuration retrieval through the authenticated `get-turn-config` Edge Function, SDP offer/answer signalling, ICE candidate exchange, local/remote video renderers, mute, speakerphone, camera enable/disable, camera switching, and end-call signalling.

## Required backend step

Run `supabase/migrations/202611100001_webrtc_call_signalling.sql` in the Supabase SQL Editor. It creates `likedin_calls` and `likedin_call_signals`, participant RLS policies, indexes, and Realtime publication entries. If a table is already in the Realtime publication, remove the duplicate `alter publication` statement before running.

Keep the deployed `get-turn-config` Edge Function and its three TURN secrets. The app calls it with the signed-in user's access token.

## Test flow

1. Apply the migration.
2. Build and install the same APK on both Android phones.
3. Sign in on both phones and ensure the private pair is configured.
4. From phone A, open the chat and tap audio or video call.
5. Inspect Supabase `likedin_calls` and `likedin_call_signals` while testing.

## Current preview limitations

This is an integration preview, not a finished production calling system. Outgoing call creation and WebRTC negotiation are wired. Incoming-call UI/accept flow, push-based wake-up when the app is backgrounded or killed, missed-call history, robust reconnection/timeouts, and comprehensive permission/lifecycle handling remain to be implemented. The current dialog is the caller-side call UI. Do not expect phone B to show a native incoming-call screen yet. Verify on real devices and different networks; TURN fallback depends on the provider credentials and quota.
