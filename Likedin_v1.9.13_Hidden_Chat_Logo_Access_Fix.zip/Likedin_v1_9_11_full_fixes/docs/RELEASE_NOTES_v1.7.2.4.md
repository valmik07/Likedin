# Likedin v1.7.2.4 — Call UI and audio routing

- Route audio to the handset earpiece by default when starting or accepting a call.
- Keep speakerphone as an explicit toggle.
- Give mute and speaker controls distinct active-state styling and state-appropriate icons.
- Expand incoming and outgoing call surfaces to full-screen dialogs.
- Automatically dismiss the call screen when the other participant ends or rejects the call, or when the call reports a terminal failure/disconnection state.

Validation: source changes and ZIP archive integrity checked. Flutter formatting/analyzer/build and two-device behavior were not run in this environment.
