# Likedin v1.0 — real-time messaging increment

## Implemented in this source package
- Flutter chat now resolves the other occupied account slot through a restricted SECURITY DEFINER RPC.
- Flutter sends messages through a second SECURITY DEFINER RPC; direct client inserts are disabled.
- Chat history is fetched from `public.messages` for the signed-in user.
- Supabase Realtime subscribes to new message inserts; each event refreshes the conversation from the database.
- Messages remain in the database while the recipient is offline and are fetched on next app open/connection (store-and-forward history).
- Client-generated message UUIDs make sends idempotent.

## Required Supabase setup
Run, in order, after the initial account/profile/messages schema:
1. `docs/migrations/0002_messaging_media_calls.sql` (v0.9 expansion, if not already run).
2. `docs/migrations/0003_realtime_messaging.sql`.

The SQL editor should report success for both. The migration adds `likedin_get_peer_id()` and `likedin_send_message()` RPCs, restricts direct inserts, and preserves participant-only reads.

## Important security limitation
This increment is **not end-to-end encrypted**. Message text is transported over HTTPS/TLS but is stored readable in the Supabase `encrypted_payload` column. The column name is inherited from the initial schema and does not mean the content is encrypted. Do not use this build for sensitive/private conversations until an audited Signal Protocol implementation is integrated and independently tested. The local SQLite AES-GCM feature protects local-at-rest records only; it is not used as cross-device encryption.

## Not included
- Reliable background push notifications; a recipient receives queued messages when the app reconnects/opens, but no FCM wake-up is implemented.
- Read/delivery receipts.
- End-to-end encryption / key verification.
- Attachment transfer.
- WebRTC calls.

## Verification status
Source changes and SQL migration are packaged. No Flutter SDK is available in this build environment, so `flutter pub get`, `flutter analyze`, Android APK build, and two-device live-message tests have **not** been run here. Verify through the existing GitHub Actions workflow before installing.
