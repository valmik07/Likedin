# Likedin v0.8 — Supabase authentication integration

## Implemented in this increment
- Supabase Flutter client initialization using the project's HTTPS URL and publishable key.
- Email/password sign-up and sign-in.
- Display name passed as Auth user metadata; the database trigger creates the corresponding profile.
- Auth-state-driven app gate and remote sign-out.
- Friendly handling for the database's two-account limit error.

## Not implemented yet
- Remote message send/receive and offline sync. The current chat remains device-local.
- End-to-end encryption or a reviewed key exchange. Do not send sensitive message content through the current local-only chat and assume it is delivered.
- Remote file transfer, audio/video calls, push notifications, and TURN relay.

## Required validation
1. Build with the existing GitHub Actions workflow.
2. Install on the first phone and create an account with its owner's email.
3. Confirm the email if Supabase requests it, then sign in.
4. Repeat on the second phone using a different email and network.
5. Verify a third signup is rejected by the database trigger.

Do not use a third-party or personal account in this dedicated Supabase project: its Auth user limit is global and intentional.
