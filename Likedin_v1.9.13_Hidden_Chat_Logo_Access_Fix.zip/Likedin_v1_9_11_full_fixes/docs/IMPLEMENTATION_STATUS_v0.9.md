# Likedin v0.9 — backend expansion (migration package)

## Included
- Supabase migration adding message idempotency and delivery/read receipt metadata.
- A recipient-constrained message insert policy: a signed-in account may only send to the other globally registered account.
- Call-signalling table with participant-only RLS and short-lived signal records.
- Realtime publication membership for messages and call signals.

## Important: this is not yet a functioning messenger/calling release
The Flutter UI still uses the local SQLite message store. This increment supplies database-side primitives only. The app does not yet subscribe to realtime messages, encrypt/decrypt remote messages using a Signal Protocol session, upload/download attachments, or establish WebRTC calls. No APK build has been run for this increment.

## Security decisions
- Do not upload plaintext message bodies. The existing local AES-GCM key is device-specific and cannot decrypt on the other phone.
- E2EE should use a maintained Signal Protocol implementation with persistent identity/prekey/session stores and safety-number verification. A current Dart wrapper exists, but its exact version, native build hooks, licence obligations, and Android ABI coverage must be validated before adoption.
- Call signalling metadata is not end-to-end encrypted by this migration. SDP/ICE payloads are connection metadata; the WebRTC media channel must use DTLS-SRTP and TURN credentials must not be hard-coded in the APK.
- Attachments must be encrypted client-side before private Storage upload. Do not create a public bucket.
- FCM setup and Android call-notification permissions are separate deployment steps.

## Apply migration
1. Open Supabase SQL Editor.
2. Create a new query.
3. Paste `migrations/0002_messaging_media_calls.sql` and run it.
4. Confirm no SQL error. Do not create any test users until the Flutter client is updated.

## Next engineering work
1. Validate and integrate Signal Protocol with durable encrypted stores and two-device key verification.
2. Implement remote send/fetch/realtime sync using ciphertext only and local outbox retry.
3. Implement private encrypted media storage and verified local/cloud deletion.
4. Implement WebRTC signalling, STUN/TURN configuration, FCM incoming-call wake-up, and test on two physical Android devices.
