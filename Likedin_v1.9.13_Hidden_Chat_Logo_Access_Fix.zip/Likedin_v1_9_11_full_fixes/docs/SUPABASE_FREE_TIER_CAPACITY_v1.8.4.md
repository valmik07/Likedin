# Supabase Free-tier capacity — Likedin v1.8.4

## Important: 2 million is a monthly Realtime-message quota

It is not a lifetime limit on rows in `public.messages`. Supabase counts Realtime events:

- A Postgres change counts once for each subscribed client receiving the event.
- A Broadcast counts one sent event plus one per subscribed receiver.
- Presence events also count.

The current Free plan listing includes 2 million Realtime messages per month, 200 peak connections, 500 MB database size per project, and 1 GB Storage. Confirm current usage on the Supabase organization Usage page because plan limits can change.

## v1.8.4 reductions

- Typing broadcasts are sent only when typing state changes, not on every character.
- Message INSERT events are subscribed only by the recipient device; sender UI reconciles through the RPC result and a REST refresh.
- Profile UPDATE subscription is filtered to the other account's profile only.
- `likedin_set_presence(true)` writes a heartbeat no more often than every 55 seconds. Offline transitions remain immediate.
- Message UPDATE events remain subscribed for both conversation participants because delivery/read receipts and delete-for-everyone need to stay synchronized.

## Monitor database and message rows

Run in Supabase SQL Editor:

```sql
select
  count(*) as message_rows,
  pg_size_pretty(pg_total_relation_size('public.messages')) as messages_table_and_indexes,
  pg_size_pretty(pg_database_size(current_database())) as whole_database_size
from public.messages;
```

Storage object estimate for the private media bucket:

```sql
select
  bucket_id,
  count(*) as object_count,
  pg_size_pretty(coalesce(sum(
    case
      when coalesce(metadata->>'size', '') ~ '^[0-9]+$'
        then (metadata->>'size')::bigint
      else 0
    end
  ), 0)::bigint) as estimated_object_bytes
from storage.objects
where bucket_id = 'likedin-media'
group by bucket_id;
```

Realtime usage is not derived from `public.messages` row count. View it in Supabase Dashboard → Organization → Usage → Realtime Messages, and select the Likedin project/time window.

## Retention policy

No automatic deletion or truncation of chat history is enabled. A monthly Realtime quota and database disk quota are different limits; deleting chat history is not a safe way to reduce Realtime event usage. Keep user conversations unless both account owners explicitly agree to an archive/retention policy.
