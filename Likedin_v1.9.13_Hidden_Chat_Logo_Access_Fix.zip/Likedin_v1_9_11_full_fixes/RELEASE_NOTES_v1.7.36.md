# Likedin 1.7.36 — Messaging and attachment stability

## Changes
- Serialized conversation refreshes. Realtime insert bursts (such as sending several attachments) now coalesce into a follow-up refresh instead of allowing overlapping loads to clear/replace the chat list out of order.
- Bulk attachment sending now uses the same visible busy state as other sends, preventing overlapping text/media send operations while a selected batch is being prepared and uploaded.
- Added a persistent app-private attachment cache keyed by the Supabase Storage object path. Images, videos, and voice messages open from local files after the first successful fetch; reopening the chat no longer downloads those same attachments again. The explicit Save to Downloads action copies from that cache.
- Reply previews are tappable and scroll to the exact original message when it is present in the loaded conversation.
- Updated release version to 1.7.36+66.

## Important verification note
This source package was statically inspected and ZIP integrity-checked. Flutter/Dart tooling and a connected Android device were not available in the packaging environment, so this is not a claim of a successful Flutter build or device-level verification. Existing GitHub Actions workflow and Supabase migrations are retained unchanged.
