# Likedin 1.7.25

## Changes
- Removed the redundant "private space / private feed / private connection status" promotional copy and placeholder social-feed cards from Home. Home now opens with a clean News heading and the existing five-story daily news view.
- Simplified the app header subtitle to "Messages · Calls · Files" and the overflow menu label to "Chat".
- Removed "private" wording from notification channel descriptions; this is copy-only and does not weaken notification or storage security.
- Added a Supabase Storage INSERT policy correction. The previous policy required a matching `account_slots` row during Storage's RLS check, which caused the observed HTTP 403. The replacement permits authenticated uploads only into the signed-in user's own UUID folder. Existing paired-account SELECT restrictions are unchanged.

## Required Supabase step
Run `supabase/migrations/202611150001_fix_media_upload_insert_policy.sql` in the Supabase SQL Editor before testing uploads. Do not make the bucket public and do not disable RLS.

## Verification
Source-level change only. Flutter compilation and device tests must be run through the project's existing GitHub Actions workflow and on both phones.
