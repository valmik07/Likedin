# Likedin v1.9.13 — Upload and Build

1. Download `Likedin_v1.9.13_Hidden_Chat_Logo_Access_Fix.zip`.
2. Replace the previous project ZIP in the root of your existing GitHub repository with this ZIP. Keep exactly one source ZIP in the repository root.
3. Update the version check in your workflow to expect `1.9.13+99`.
4. Run the existing GitHub Actions workflow and download the generated ARM64 APK.
5. Install the APK on the device(s). The hidden state and hidden-chat password are device-local; hide the conversation separately on every device where you need it hidden.

## How the updated flow works

1. On Home, open the regular conversation card's three-dot menu and choose **Hide chat**.
2. Create the separate hidden-chat password (minimum 8 characters).
3. The conversation disappears from Home. The Calls destination also disappears from the bottom navigation.
4. Press the Likedin logo in the Home header and enter the hidden-chat password.
5. The **Private chat** page appears and shows the conversation. Tap it to open the full conversation screen.
6. The unlock remains valid while the app process is alive, including when the app is backgrounded. It resets after the app is closed/terminated or force-stopped.
7. To return the chat to Home, open the private list from the logo and choose **Unhide chat** from the conversation menu.

No Supabase SQL, RLS, Storage-policy, Edge Function, or backend deployment is required.
