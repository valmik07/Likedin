# Likedin 1.7.28

## Media presentation and launcher icon correction
- Reworked chat photo presentation into a larger inline preview with a dedicated full-screen zoomable viewer.
- Reworked video messages to initialise a real remote video frame for the inline thumbnail, with a clear play overlay and dedicated in-app player.
- Signed media URLs are now retained for the lifetime of the message widget rather than recreated on every rebuild; failed URL loads can be retried.
- Repaired the removed status-dot area in adaptive and legacy launcher artwork using the app blue, avoiding a transparent hole through which wallpaper was visible.
- Preserved existing media upload/download and private Storage logic.

Build validation: source-level edits and ZIP integrity only. Flutter compilation/device playback still require the existing GitHub Actions workflow and phone testing.
