# Likedin 1.7.10 — Phase 1 client synchronization integration

## Included in this source package
- Replies now persist `reply_to_message_id` on the server and are restored from the conversation rows on reload.
- Message edits call the authenticated `likedin_edit_message` RPC instead of changing only local preferences.
- Reactions use `message_reactions` through the authenticated reaction RPC and are reloaded for both devices.
- Delete-for-everyone uses the tombstone RPC; the message row remains and the UI displays “This message was deleted”.
- Realtime subscriptions refresh the conversation when reactions are inserted or removed.

## Backend action required
After uploading this source ZIP and before testing, run this one new migration in Supabase SQL Editor:
`supabase/migrations/202611140001_v1710_client_sync_integration.sql`

The 1.7.9 Phase 1 migration is assumed to have already been applied. Do not rerun the old migrations. This migration adds the reply-aware send RPC and adds the reactions table to Supabase Realtime publication when available.

## Build
No GitHub Actions workflow change is required. Keep the existing workflow and replace the project ZIP in the repository with this ZIP.

## Scope notes
This is Phase 1 messaging synchronization only. Call history/notifications, remote media transfer, video-call UI redesign, and the broader security/performance audit are not included in this release. Message payloads are not end-to-end encrypted; this release does not add E2EE.
