# Likedin v1.9.3+92 — reply previews, compact GIFs and faster sends

## Changes

- Reply quote previews now retain the referenced source message. Photo and animated-image replies render a small thumbnail instead of a filename. Video, audio and document replies use a compact media-type preview.
- Concurrent reply/bubble thumbnail requests for the same Storage object share one in-flight cache download.
- New GIFs are decoded and recompressed off the UI isolate to animated WebP, downscaled to a 480 px longest edge and sampled to at most 24 frames, with a bounded decode pixel budget.
- Animated media is capped at 2 MiB after preparation. GIFs that cannot meet the cap are rejected rather than uploaded at full size. Small animated items try a direct single-request Storage upload first (with a resumable TUS fallback); larger media keep the existing TUS path.
- The chat composer restores focus and explicitly reopens the soft keyboard after text sends.
- Gboard and picked media are durably queued locally before network upload; sending continues in the background so the composer is not held waiting for a Storage transfer.

## Storage behavior

The 2 MiB cap applies to newly queued GIF/animated media. Existing objects in Supabase Storage are not automatically rewritten or deleted. Removing an old media message through the app's existing delete-for-everyone flow continues to remove its Storage object when permitted by the existing RLS policy.

## Compatibility / validation

- No database migration or Edge Function change is required; media metadata remains in the existing message payload JSON.
- The project adds the pure-Dart `image` package for animated GIF decoding and WebP encoding.
- The ZIP and workflow version guard are checked. This environment does not have the Flutter SDK, so `flutter analyze`, `flutter test`, Android compilation, actual Gboard insertion and two-device delivery still need GitHub Actions/device verification.
