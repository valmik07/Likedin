# Likedin v1.9.3+92 upload and build

1. Remove the previous source ZIP from the GitHub repository root.
2. Upload `Likedin_v1.9.3_reply_previews_gif_quota_fast_send.zip` to the repository root. Keep exactly one root-level ZIP.
3. Replace the existing workflow under `.github/workflows` with `likedin_workflow_option_A_v1.9.3.yml`.
4. Commit the changes and run **Likedin Android APK** on `main`.

Option A requires no signing secrets. GitHub-hosted runners may generate different debug signing certificates between runs; if Android rejects the APK as an update, do not uninstall the installed app until its local data is safely backed up.

The build should run `flutter pub get`, `flutter analyze`, `flutter test`, build an ARM64 release APK and verify its signature.
