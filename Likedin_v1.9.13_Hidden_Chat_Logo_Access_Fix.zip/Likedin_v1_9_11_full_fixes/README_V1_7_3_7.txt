LIKEDIN v1.7.3.6 — Incoming call notifications + proximity
Build: 32
Baseline: v1.7.3.5 / build 31

This release adds:
- Separate high-priority incoming-call FCM notifications (audio/video).
- Notification-tap routing into the existing Accept / Decline call screen.
- Android native proximity screen-off during audio calls on earpiece.
- Proximity wake lock released for speakerphone, video calls, and call teardown.
- Separate `likedin_calls_v1` channel; existing message channel and message push Edge Function remain unchanged.

IMPORTANT: Background incoming-call notifications require the one-time Supabase setup in:
docs/INCOMING_CALL_PUSH_AND_PROXIMITY_v1.7.3.6.md

Deploy the `send-incoming-call-push` Edge Function in Supabase Dashboard and run the SQL migration before expecting background call alerts. Do not put Firebase service-account JSON or Supabase service-role keys in this ZIP or Android app.

Verification: source structure and AndroidManifest XML were inspected. This package has NOT been compiled in this environment and has NOT been tested on the Vivo phones. GitHub Actions build and two-device tests are still required.
