# Lint fixes for the v1.9.6 Obsidian / Arctic Glass source

This maintenance pass addresses the Flutter analyzer output reported for this source package:

- Added the explicit Flutter foundation import required for `ValueListenable` in `ProfilePage`.
- Removed a non-null assertion after a guard had already promoted the file to non-null.
- Removed the redundant `dart:typed_data` import because the used typed-data symbols are available from `flutter/foundation.dart` in this library.
- Made `PreferredSize` const in the Storage page.
- Removed unnecessary backslash escapes from JSON quotes inside a Dart single-quoted string in the message-search test.

No app version or backend behavior was changed.
