# Likedin v1.9.1 — Shared App Chrome Alignment

## Changes
- Unified the global shell background behind the brand header, active tab content and bottom navigation.
- Replaced the boxed full-width header with a compact transparent/tinted header and a single subtle bottom divider.
- Replaced the raised rounded footer slab with an edge-aligned navigation surface and a single subtle top divider.
- Removed redundant per-tab AuroraBackdrop wrappers from Home, Calls, Downloads and Preferences so those pages share one continuous background.
- Kept the Chat page's own chat-specific background because the global header/footer are intentionally hidden on that route.
- Kept navigation destinations and tab selection behavior unchanged.
- No database, Supabase, storage, call signaling or authentication changes.

## Validation
- Source ZIP integrity and source-version consistency checked.
- Flutter analyze, tests, Gradle build and real-device visual validation must still be run in GitHub Actions/on device; no Flutter SDK is available in this editing environment.
