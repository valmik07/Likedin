# Likedin release shrinker rules.
# Flutter engine/plugin entry points and native/JNI-backed WebRTC types.
-keep class io.flutter.** { *; }
-keep class io.flutter.plugins.** { *; }
-keep class com.google.firebase.** { *; }
-keep class org.webrtc.** { *; }
-keep class com.cloudwebrtc.webrtc.** { *; }
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# flutter_local_notifications 18.x uses Gson TypeToken to restore and cancel
# scheduled notifications. R8 must preserve the TypeToken class and anonymous
# subclasses so their generic Signature metadata remains available at runtime.
-keep class com.google.gson.reflect.TypeToken { *; }
-keep class * extends com.google.gson.reflect.TypeToken
-dontwarn org.webrtc.**

# This app does not use Play Feature Delivery / deferred components.
# Flutter references these optional classes; suppress missing-class checks for that unused path.
-dontwarn com.google.android.play.core.**

# Keep plugin reflection and Gson-backed scheduled-notification metadata.
-keep class com.dexterous.flutterlocalnotifications.** { *; }
