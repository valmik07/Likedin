# Likedin v1.9.7+93 upload and build

1. Keep this source ZIP as the only `.zip` file in the GitHub repository root.
2. Replace the existing workflow file under `.github/workflows` with the supplied
   `likedin_workflow_option_A_v1.9.7.yml` contents.
3. Commit both files to `main`.
4. Run **Likedin v1.9.7 Profile Photo and Smoothness ARM64 APK** from Actions.

No signing secrets are required for temporary Option A testing. The release build
uses the source project's debug-signing fallback when `android/key.properties` is
absent. A persistent signing key is still recommended before this app is treated
as a long-term installation.

The new profile-photo editor returns a 1024 x 1024 JPEG and stores it using the
existing private `likedin-media` bucket and existing profile-avatar RPC. No SQL
migration is required.

The source archive has not been compiled in this environment. Treat the GitHub
Actions result and tests on both target devices as the build verification.
