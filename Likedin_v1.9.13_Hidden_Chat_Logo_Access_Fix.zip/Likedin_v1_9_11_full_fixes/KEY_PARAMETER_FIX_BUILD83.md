# Likedin v1.8.4+83 — analyzer correction

The `_ChatMediaMessage` constructor now declares `Key? key` explicitly and forwards it with `: super(key: key)`. This avoids relying on a super-parameter shorthand for this one constructor and ensures the call at `main.dart:3183` has a declared `key` named parameter.

The archive is a complete project ZIP, with forward-slash entry paths. It is intended to replace the previous project ZIP in the GitHub repository root.

Validation performed in packaging environment: source constructor inspected; exactly one root `pubspec.yaml`; no backslash ZIP entry paths; ZIP integrity tested. Flutter analysis/tests were not run in this packaging environment.
