# v1.9.3 UI polish (chat)

Frontend-only; no backend, migration or version change.

- Empty chat now shows an icon, "No messages with <name> yet" and a hint about typing and holding the mic, replacing a single plain sentence.
- Reply/edit banner above the composer: sentence case ("Replying to Sam", "Editing message") at 12 px instead of 9 px all-caps.
- Mic button: screen-reader label ("Hold to record a voice message" / "Recording voice message"), 44 px target, smooth colour change while recording.
- Send button: tooltip/semantics ("Send message" / "Save edit").

Not compiled here (no Flutter SDK): run `flutter analyze` via GitHub Actions.
