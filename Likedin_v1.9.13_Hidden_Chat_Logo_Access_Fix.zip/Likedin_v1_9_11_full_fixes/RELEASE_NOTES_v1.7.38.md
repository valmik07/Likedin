# Likedin 1.7.38 — Comprehensive Bug & Glitch Remediation

## Fixed in 1.7.38
1. **CI Build Workflow (`.github/workflows/android-apk.yml`)**: Restored the existing ARM64 GitHub Actions workflow from the prior consolidated source ZIP. It retains the project's Flutter `3.47.9` pin and ARM64 release APK artifact upload. The incoming `likedin_fix.zip` did not include this workflow despite the original release-note claim.
2. **Database Schema & RPC Consolidation (`supabase/migrations/202611160001_v1738_complete_schema_and_call_rpc_fixes.sql`)**:
   - Added `public.likedin_update_call_status(uuid, text)` with participant authorization and timestamp updates (`answered_at`, `ended_at`).
   - Added missing `account_slots`, `profiles`, `likedin_get_peer_id`, `likedin_set_presence`, `likedin_mark_delivered`, and `likedin_mark_read` definitions to `supabase/migrations/`.
   - Dropped legacy `NOT NULL` constraints on `messages.ciphertext` and `messages.nonce` so `likedin_send_message_v2` succeeds on fresh deployments.
   - Expanded `likedin-media` bucket allowed MIME types (`audio/x-m4a`, `audio/m4a`, `audio/aac`, `audio/mpeg`, `audio/wav`, `audio/ogg`, `image/heic`, `image/heif`, `video/3gpp`, `video/x-matroska`).
   - Updated `likedin_missed_call_push` trigger to also fire when a ringing call is cancelled or rejected (`ended`/`rejected`) so stuck incoming-call notifications are dismissed.
3. **Supabase Edge Functions & Config (`supabase/config.toml`, `supabase/functions/*`)**:
   - Added `[functions.send-missed-call-push]` and `[functions.get-turn-config]` with `verify_jwt = false`.
   - Switched FCM payloads in `send-message-push`, `send-incoming-call-push`, and `send-missed-call-push` to data-only + high-priority so Android wakes `likedinFirebaseBackgroundHandler` to show full-screen call alerts and record background delivery receipts.
4. **WebRTC Calling & Alerts (`lib/calls/call_service.dart`, `lib/main.dart`)**:
   - Added a 10-second recovery grace window for transient WebRTC `disconnected` states instead of immediately terminating active calls.
   - Defaulted video calls to speakerphone (`Helper.setSpeakerphoneOn(true)`) while keeping audio calls on the handset earpiece.
   - Added Speaker toggle and Camera on/off controls to the callee call screen (`_IncomingCallDialog`).
   - Ringtone and vibration now start when an incoming call banner appears inside an open Chat screen, and a Decline button is available directly on the banner.
   - Wired `LikedinCallService` to use `TurnConfigService`.
5. **Chat, Presence, Replies & Media (`lib/main.dart`, `lib/backend/*`)**:
   - Fixed the 30-second online presence heartbeat so it restarts when resuming the app from the background.
   - Fixed `@override void didChangeMetrics()` keyboard auto-scroll detection.
   - Decoded media/voice payloads into human-readable labels (`Photo · ...`, `Video · ...`, `Voice message`, `File · ...`) in reply quotes and composer banners instead of displaying raw JSON.
   - Disabled text editing (`Edit`) on media and voice message bubbles.
   - Preserved original message text in the editing banner while typing.
   - Used stable `clientMessageId` keys on message bubbles so sent messages do not flash or replay their entrance animation when synced.
   - Normalized `.m4a` MIME types to `audio/mp4`, cleared expired TUS session URLs on `400/403/404/410` so the retry queue never wedges, and preserved original filenames when compressing videos.
6. **Voice Recorder, Audio/Video Players, Navigation & Settings (`lib/main.dart`, `MainActivity.kt`)**:
   - Guarded voice recording against quick-release race conditions, added `onLongPressCancel`, and added a live recording timer.
   - Fixed `_VoiceMessagePlayer` so completed voice notes reset to `0:00` and update the Play/Pause button via `playerStateStream`.
   - Added error handling and playback state listeners to `_LikedinVideoViewer`.
   - Cleaned up orphaned `IS_PENDING` MediaStore entries on failed download writes in `MainActivity.kt`.
   - Added `Calls` to the bottom navigation bar, added quick `Chat` and `Calls` cards on `HomePage`, wired `Sign out` into `SettingsPage` and the profile menu, evicted cached `FileImage` on profile photo updates, and enabled auto-refresh, audio playback, and local file viewing on `FilesPage`.


## Reconciliation notes
- This archive is a source-package merge, not a verified Android build. Flutter analysis, tests, GitHub Actions, and device testing still need to pass.
- The backend SQL migration is included for review only. Do not paste/run it wholesale against the already-configured live Supabase project without reviewing its profile SELECT policy and confirming each function/schema change against the live database.
- Existing live `likedin_update_call_status(uuid, text) RETURNS void` behavior and the current private `likedin-media` bucket settings must be preserved.
