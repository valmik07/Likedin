import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/backend/realtime_messaging_service.dart';
import 'package:likedin/utils/chat_info_metrics.dart';

RemoteMessage _message(String id, String text, DateTime createdAt, {DateTime? deletedAt}) =>
    RemoteMessage(
      id: id,
      senderId: 'sender',
      recipientId: 'recipient',
      text: text,
      createdAt: createdAt,
      deletedForEveryoneAt: deletedAt,
    );

String _media(String kind) => jsonEncode({
      '__likedin_media_v1': true,
      'kind': kind,
      'path': '$kind/path',
      'name': '$kind-file',
    });

void main() {
  group('ChatInfoMetrics', () {
    test('filters hidden, cleared and deleted messages before counting', () {
      final now = DateTime(2026, 11, 18, 12);
      final messages = <RemoteMessage>[
        _message('keep', 'https://example.com', now),
        _message('hidden', 'https://hidden.example', now),
        _message('cleared', 'https://old.example', now.subtract(const Duration(days: 2))),
        _message('deleted', 'https://deleted.example', now, deletedAt: now),
      ];

      final visible = ChatInfoMetrics.visibleMessages(
        messages,
        hiddenMessageIds: {'hidden'},
        clearedBeforeMs: now.subtract(const Duration(days: 1)).millisecondsSinceEpoch,
      );

      expect(visible.map((message) => message.id), ['keep']);
      expect(ChatInfoMetrics.linkCount(visible), 1);
    });

    test('does not count voice notes as shared media or documents', () {
      final now = DateTime(2026, 11, 18);
      final messages = <RemoteMessage>[
        _message('image', _media('image'), now),
        _message('video', _media('video'), now),
        _message('file', _media('file'), now),
        _message('voice', _media('audio'), now),
      ];

      final media = ChatInfoMetrics.mediaItems(messages);
      expect(media.map((item) => item['kind']), ['image', 'video', 'file']);
      expect(ChatInfoMetrics.documentCount(media), 1);
    });

    test('decodes a well-formed media envelope and ignores ordinary text', () {
      expect(ChatInfoMetrics.decodeMediaPayload(_media('image'))?['kind'], 'image');
      expect(ChatInfoMetrics.decodeMediaPayload('hello'), isNull);
    });

    test('preview helper returns the four newest visual items first', () {
      final media = <Map<String, dynamic>>[
        for (var i = 0; i < 6; i++)
          <String, dynamic>{'kind': i == 4 ? 'file' : 'image', 'path': '$i'},
      ];
      final previews = ChatInfoMetrics.latestVisualMedia(media, limit: 4);
      expect(previews.map((item) => item['path']), ['5', '3', '2', '1']);
    });

    test('local visibility helper keeps Clear Chat and hidden rows out of Home previews', () {
      final now = DateTime(2026, 11, 18, 12);
      final recent = _message('recent', 'hello', now);
      final individuallyHidden = _message('hidden', 'secret', now);
      final cleared = _message('cleared', 'old message', now.subtract(const Duration(days: 1)));
      expect(ChatInfoMetrics.isLocallyVisible(recent), isTrue);
      expect(ChatInfoMetrics.isLocallyVisible(individuallyHidden, hiddenMessageIds: {'hidden'}), isFalse);
      expect(ChatInfoMetrics.isLocallyVisible(
        cleared,
        clearedBeforeMs: now.subtract(const Duration(hours: 1)).millisecondsSinceEpoch,
      ), isFalse);
    });
  });
}
