import 'dart:async';
import 'dart:convert';
import 'dart:typed_data' show Int32List;
import 'dart:ui' as ui;
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../backend/backend_config.dart';

const likedinMessageChannelId = 'likedin_messages_v1';
const likedinCallChannelId = 'likedin_calls_v1';
const likedinDiagnosticChannelId = 'likedin_diagnostics_v1';
const _callLaunchChannel = MethodChannel('com.example.likedin/call_alerts');

bool _backgroundHandlerRegistered = false;

/// Centralized, retryable Firebase bootstrap. If the first initialization
/// attempt fails during app startup, a later notification retry also registers
/// the top-level background handler before attaching message streams.
Future<void> ensureLikedinFirebaseReady() async {
  if (Firebase.apps.isEmpty) await Firebase.initializeApp();
  if (!_backgroundHandlerRegistered) {
    FirebaseMessaging.onBackgroundMessage(likedinFirebaseBackgroundHandler);
    _backgroundHandlerRegistered = true;
  }
}

// Deterministic across the main isolate and Firebase's background isolate.
// Dart's Object.hashCode is not a persistence/IPC contract, so call-alert
// cancellation must not depend on the runtime's hash seed.
int _notificationId(Object? seed) {
  final value = seed?.toString() ?? DateTime.now().millisecondsSinceEpoch.toString();
  var hash = 0x811C9DC5;
  for (final unit in value.codeUnits) {
    hash ^= unit;
    hash = (hash * 0x01000193) & 0x7FFFFFFF;
  }
  return hash == 0 ? 1 : hash;
}

@pragma('vm:entry-point')
Future<void> likedinFirebaseBackgroundHandler(RemoteMessage message) async {
  // Register plugins in the Firebase background isolate before invoking
  // flutter_local_notifications or any other platform plugin.
  WidgetsFlutterBinding.ensureInitialized();
  ui.DartPluginRegistrant.ensureInitialized();

  // Display first. A delivery receipt must never be written before the local
  // notification attempt, otherwise a failed display can look delivered.
  try {
    final local = FlutterLocalNotificationsPlugin();
    const android = AndroidInitializationSettings('@drawable/likedin_notification');
    await local.initialize(const InitializationSettings(android: android));
    final route = message.data['route']?.toString();
    final callId = message.data['call_id']?.toString();
    if (route == 'call_ended' || route == 'call_cancelled') {
      if (callId != null && callId.isNotEmpty) {
        await local.cancel(_notificationId(callId));
      }
      return;
    }
    final isCall = route == 'incoming_call' || route == 'missed_call' || route == 'call_history';
    final isMissed = route == 'missed_call' || route == 'call_history';
    final isIncomingCall = route == 'incoming_call';
    final details = NotificationDetails(
      android: AndroidNotificationDetails(
        isCall ? likedinCallChannelId : likedinMessageChannelId,
        isCall ? 'Likedin calls' : 'Likedin messages',
        channelDescription: isCall ? 'Incoming calls' : 'New messages from your Likedin chat',
        importance: isCall ? Importance.max : Importance.high,
        priority: isCall ? Priority.max : Priority.high,
        playSound: true,
        sound: RawResourceAndroidNotificationSound(isCall ? 'likedin_call' : 'likedin_message'),
        audioAttributesUsage: isIncomingCall
            ? AudioAttributesUsage.notificationRingtone
            : AudioAttributesUsage.notification,
        additionalFlags: isIncomingCall ? Int32List.fromList(<int>[4]) : null,
        category: isMissed
            ? AndroidNotificationCategory.missedCall
            : isCall
                ? AndroidNotificationCategory.call
                : AndroidNotificationCategory.message,
        fullScreenIntent: isIncomingCall,
        // Incoming-call notifications loop insistently until answered/declined
        // and self-expire after 60s if the cancellation/missed push is lost.
        ongoing: isIncomingCall,
        autoCancel: !isIncomingCall,
        timeoutAfter: isIncomingCall ? 60000 : null,
        visibility: NotificationVisibility.public,
      ),
    );
    final title = message.data['notification_title']?.toString() ??
        message.notification?.title ??
        'Likedin';
    final body = message.data['notification_body']?.toString() ??
        message.notification?.body ??
        (isMissed ? 'You missed a call.' : isCall ? 'Incoming call' : 'You received a new message.');
    final payloadMap = isMissed
        ? {'route': 'missed_call', 'call_id': callId}
        : isCall
            ? {'route': 'incoming_call', 'call_id': callId}
            : {'route': 'chat'};
    await local.show(
      _notificationId(callId != null && callId.isNotEmpty ? callId : message.messageId),
      title,
      body,
      details,
      payload: jsonEncode(payloadMap),
    );
  } catch (error) {
    debugPrint('Could not display background Likedin notification: $error');
  }

  // Acknowledge after the notification display attempt. If the background
  // isolate cannot restore the Supabase session, foreground sync will retry.
  try {
    if (Firebase.apps.isEmpty) await Firebase.initializeApp();
    try {
      Supabase.instance.client;
    } catch (_) {
      await Supabase.initialize(
        url: BackendConfig.supabaseUrl,
        publishableKey: BackendConfig.supabaseAnonKey,
        authOptions: const FlutterAuthClientOptions(autoRefreshToken: false),
      );
    }
    final messageId = message.data['message_id']?.toString();
    if (messageId != null && messageId.isNotEmpty) {
      await Supabase.instance.client.rpc(
        'likedin_mark_message_delivered',
        params: {'p_message_id': messageId},
      );
    }
  } catch (error) {
    debugPrint('Background delivery acknowledgement deferred: $error');
  }
}

class NotificationTestResult {
  const NotificationTestResult({required this.success, required this.message});
  final bool success;
  final String message;
}

class LikedinNotificationService {
  LikedinNotificationService._();
  static final instance = LikedinNotificationService._();
  final FlutterLocalNotificationsPlugin _local = FlutterLocalNotificationsPlugin();
  bool _localReady = false;
  bool _localInitialized = false;
  bool _channelsCreated = false;
  bool _pushReady = false;
  bool _tokenRegistered = false;
  bool? _notificationsAllowed;
  StreamSubscription<dynamic>? _authStateSubscription;
  StreamSubscription<RemoteMessage>? _foregroundMessageSubscription;
  StreamSubscription<RemoteMessage>? _openedAppSubscription;
  StreamSubscription<String>? _tokenRefreshSubscription;
  bool isConversationVisible = false;
  bool openedFromNotification = false;
  void Function()? onOpenChat;
  void Function(String callId)? onOpenIncomingCall;
  void Function()? onOpenCalls;
  String? _pendingIncomingCallId;

  bool get pushConfigured => _pushReady;
  bool get tokenRegistered => _tokenRegistered;
  bool? get notificationsAllowed => _notificationsAllowed;

  Future<void> refreshNotificationPermissionStatus() async {
    try {
      final androidPlugin = _local.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      _notificationsAllowed = await androidPlugin?.areNotificationsEnabled();
    } catch (error) {
      debugPrint('Could not read Android notification permission: $error');
    }
  }

  Future<NotificationTestResult> showTestNotification() async {
    if (!_localReady) {
      return const NotificationTestResult(
        success: false,
        message: 'The local notification plugin is not initialized. Close and reopen Likedin, then try again.',
      );
    }

    try {
      final androidPlugin = _local.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      var enabled = await androidPlugin?.areNotificationsEnabled();
      _notificationsAllowed = enabled;
      if (enabled == false) {
        final granted = await androidPlugin?.requestNotificationsPermission();
        enabled = granted ?? await androidPlugin?.areNotificationsEnabled();
        _notificationsAllowed = enabled;
      }
      if (enabled == false) {
        return const NotificationTestResult(
          success: false,
          message: 'Android reports that Likedin notifications are blocked. Enable them in Android Settings → Apps → Likedin → Notifications.',
        );
      }

      // Use a brand-new, silent channel for diagnostics. This avoids a muted
      // message/call channel or a custom sound resource hiding the real result.
      const channel = AndroidNotificationChannel(
        likedinDiagnosticChannelId,
        'Likedin notification test',
        description: 'Temporary diagnostic notifications from Likedin',
        importance: Importance.high,
        playSound: false,
        enableVibration: false,
      );
      await androidPlugin?.createNotificationChannel(channel);
      await _local.show(
        DateTime.now().millisecondsSinceEpoch.remainder(100000),
        'Likedin notification test',
        'Android accepted a local notification from this phone.',
        const NotificationDetails(
          android: AndroidNotificationDetails(
            likedinDiagnosticChannelId,
            'Likedin notification test',
            channelDescription: 'Temporary diagnostic notifications from Likedin',
            importance: Importance.high,
            priority: Priority.high,
            icon: 'likedin_notification',
            playSound: false,
            enableVibration: false,
            category: AndroidNotificationCategory.status,
          ),
        ),
      );
      return const NotificationTestResult(
        success: true,
        message: 'Android accepted the test notification. Check the notification shade; this tests local display only, not Firebase push delivery.',
      );
    } on PlatformException catch (error) {
      final detail = (error.message?.isNotEmpty == true) ? error.message : error.details?.toString();
      debugPrint('Local notification test PlatformException ${error.code}: $detail');
      return NotificationTestResult(
        success: false,
        message: 'Android could not display the test notification. Check notification permission and channel settings.',
      );
    } catch (error, stackTrace) {
      debugPrint('Local notification test failed: $error\n$stackTrace');
      return NotificationTestResult(
        success: false,
        message: 'The test notification could not be displayed. Check notification settings and try again.',
      );
    }
  }

  void setConversationVisible(bool visible) {
    isConversationVisible = visible;
  }

  void setOnOpenIncomingCall(void Function(String callId) callback) {
    onOpenIncomingCall = callback;
    final pending = _pendingIncomingCallId;
    if (pending != null) {
      _pendingIncomingCallId = null;
      callback(pending);
    }
  }

  void _dispatchTap({String? payload, Map<String, dynamic>? data}) {
    String? route;
    String? callId;
    if (data != null) {
      route = data['route']?.toString();
      callId = data['call_id']?.toString();
    }
    if (payload != null && payload.isNotEmpty) {
      try {
        final decoded = jsonDecode(payload);
        if (decoded is Map) {
          route ??= decoded['route']?.toString();
          callId ??= decoded['call_id']?.toString();
        }
      } catch (_) {}
    }
    if (route == 'call_history' || route == 'missed_call') {
      final callback = onOpenCalls;
      if (callback != null) callback();
      return;
    }
    if (route == 'incoming_call' && callId != null && callId.isNotEmpty) {
      final callback = onOpenIncomingCall;
      if (callback == null) { _pendingIncomingCallId = callId; } else { callback(callId); }
      return;
    }
    _handleNotificationTap();
  }

  void setOnOpenCalls(void Function() callback) { onOpenCalls = callback; }

  void setOnOpenChat(void Function() callback) {
    onOpenChat = callback;
    if (openedFromNotification) {
      openedFromNotification = false;
      callback();
    }
  }

  void _handleNotificationTap() {
    final callback = onOpenChat;
    if (callback == null) {
      openedFromNotification = true;
    } else {
      callback();
    }
  }

  Future<void> initialize() async {
    if (!_localInitialized) {
      const android = AndroidInitializationSettings('@drawable/likedin_notification');
      const settings = InitializationSettings(android: android);
      await _local.initialize(
        settings,
        onDidReceiveNotificationResponse: (response) => _dispatchTap(payload: response.payload),
      );
      _localInitialized = true;

      final launchDetails = await _local.getNotificationAppLaunchDetails();
      if (launchDetails?.didNotificationLaunchApp == true) {
        final payload = launchDetails?.notificationResponse?.payload;
        if (payload != null && payload.isNotEmpty) {
          _dispatchTap(payload: payload);
        } else {
          openedFromNotification = true;
        }
      }
    }

    final androidPlugin = _local.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    if (!_channelsCreated) {
      const callChannel = AndroidNotificationChannel(
        likedinCallChannelId,
        'Likedin calls',
        description: 'Incoming audio and video calls',
        importance: Importance.max,
        playSound: true,
        sound: RawResourceAndroidNotificationSound('likedin_call'),
        enableVibration: true,
      );
      await androidPlugin?.createNotificationChannel(callChannel);
      const channel = AndroidNotificationChannel(
        likedinMessageChannelId,
        'Likedin messages',
        description: 'New messages from your Likedin chat',
        importance: Importance.high,
        playSound: true,
        sound: RawResourceAndroidNotificationSound('likedin_message'),
        enableVibration: true,
      );
      await androidPlugin?.createNotificationChannel(channel);
      const diagnosticChannel = AndroidNotificationChannel(
        likedinDiagnosticChannelId,
        'Likedin notification test',
        description: 'Silent local notification diagnostics',
        importance: Importance.high,
        playSound: false,
        enableVibration: false,
      );
      await androidPlugin?.createNotificationChannel(diagnosticChannel);
      _channelsCreated = true;
    }

    // Mark the local plugin ready before prompting. A denied or delayed
    // permission dialog must not keep the app splash/startup flow blocked.
    _localReady = true;
    unawaited(_requestNotificationPermission(androidPlugin));

    // Do not repeatedly open the Android full-screen-intent settings screen on
    // every cold start. Users can still manage the permission in system Settings.
    try {
      final prefs = await SharedPreferences.getInstance();
      if (prefs.getBool('fsi_prompted_v1') != true) {
        await prefs.setBool('fsi_prompted_v1', true);
        try {
          await _callLaunchChannel.invokeMethod<bool>('ensureFullScreenCallPermission');
        } catch (error) {
          debugPrint('Full-screen call permission check failed: $error');
        }
      }
    } catch (error) {
      debugPrint('Could not read full-screen-intent prompt state: $error');
    }

    try {
      await ensureLikedinFirebaseReady();

      // Each stream is attached independently and only once, so retrying a
      // partially-completed setup cannot stack duplicate notification handlers.
      _foregroundMessageSubscription ??= FirebaseMessaging.onMessage.listen(_onForegroundMessage);
      _openedAppSubscription ??= FirebaseMessaging.onMessageOpenedApp.listen(
        (message) => _dispatchTap(data: message.data),
      );
      _tokenRefreshSubscription ??= FirebaseMessaging.instance.onTokenRefresh.listen((token) {
        _saveToken(token).catchError((error) => debugPrint('Could not update Likedin push token: $error'));
      });
      _pushReady = true;

      // Auth can be restored or completed after Firebase initialization.
      _authStateSubscription ??= Supabase.instance.client.auth.onAuthStateChange.listen((state) {
        if (state.event == AuthChangeEvent.initialSession ||
            state.event == AuthChangeEvent.signedIn ||
            state.event == AuthChangeEvent.tokenRefreshed) {
          unawaited(registerCurrentToken());
        } else if (state.event == AuthChangeEvent.signedOut) {
          _tokenRegistered = false;
        }
      }, onError: (Object error, StackTrace stackTrace) {
        debugPrint('Likedin auth-state listener notification registration error: $error');
      });

      unawaited(_handleInitialMessageAndToken());
    } catch (error) {
      debugPrint('Likedin Firebase messaging initialization failed: $error');
      _pushReady = false;
    }
  }

  Future<void> _requestNotificationPermission(
    AndroidFlutterLocalNotificationsPlugin? androidPlugin,
  ) async {
    try {
      final permissionResult = await androidPlugin?.requestNotificationsPermission();
      _notificationsAllowed = permissionResult ?? await androidPlugin?.areNotificationsEnabled();
    } catch (error) {
      debugPrint('Notification permission request failed: $error');
      await refreshNotificationPermissionStatus();
    }
  }

  void _onForegroundMessage(RemoteMessage message) {
    final route = message.data['route']?.toString();
    final callId = message.data['call_id']?.toString();
    if (route == 'call_ended' || route == 'call_cancelled') {
      if (callId != null && callId.isNotEmpty) unawaited(cancelIncomingCall(callId));
      return;
    }
    if (route == 'incoming_call') {
      final incomingCallId = callId ?? DateTime.now().millisecondsSinceEpoch.toString();
      unawaited(showIncomingCall(
        callId: incomingCallId,
        video: message.data['call_type'] == 'video',
      ));
      _dispatchTap(data: message.data);
      return;
    }
    if (route == 'missed_call') {
      unawaited(showMissedCall(
        callId: callId ?? DateTime.now().millisecondsSinceEpoch.toString(),
        video: message.data['call_type'] == 'video',
      ));
      return;
    }
    if (!isConversationVisible) unawaited(_showForegroundPush(message));
  }

  Future<void> _handleInitialMessageAndToken() async {
    try {
      final initialMessage = await FirebaseMessaging.instance.getInitialMessage();
      if (initialMessage != null) _dispatchTap(data: initialMessage.data);
    } catch (error) {
      debugPrint('Could not inspect initial FCM message: $error');
    }
    unawaited(registerCurrentToken());
  }
  Future<void> _showForegroundPush(RemoteMessage message) async {
    final title = message.data['notification_title']?.toString() ??
        message.notification?.title ??
        'Likedin';
    final body = message.data['notification_body']?.toString() ??
        message.notification?.body ??
        'You received a new message.';
    await showMessage(title: title, body: body, id: _notificationId(message.messageId));
  }

  Future<void> showMessage({required String title, required String body, int? id}) async {
    if (!_localReady) return;
    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        likedinMessageChannelId,
        'Likedin messages',
        channelDescription: 'New messages from your Likedin chat',
        importance: Importance.high,
        priority: Priority.high,
        playSound: true,
        sound: RawResourceAndroidNotificationSound('likedin_message'),
        category: AndroidNotificationCategory.message,
      ),
    );
    await _local.show(id ?? _notificationId(null), title, body, details, payload: jsonEncode({'route': 'chat'}));
  }

  Future<void> cancelIncomingCall(String callId) async {
    if (!_localReady || callId.isEmpty) return;
    await _local.cancel(_notificationId(callId));
  }

  Future<void> showIncomingCall({required String callId, required bool video}) async {
    if (!_localReady || callId.isEmpty) return;
    final details = NotificationDetails(android: AndroidNotificationDetails(
      likedinCallChannelId, 'Likedin calls',
      channelDescription: 'Incoming audio and video calls',
      importance: Importance.max, priority: Priority.max,
      playSound: true,
      sound: const RawResourceAndroidNotificationSound('likedin_call'),
      audioAttributesUsage: AudioAttributesUsage.notificationRingtone,
      additionalFlags: Int32List.fromList(<int>[4]),
      category: AndroidNotificationCategory.call,
      fullScreenIntent: true,
      ongoing: true,
      autoCancel: false,
      timeoutAfter: 60000,
      visibility: NotificationVisibility.public,
    ));
    await _local.show(_notificationId(callId), 'Incoming ${video ? 'video' : 'audio'} call',
      'Your friend is calling.', details,
      payload: jsonEncode({'route':'incoming_call','call_id':callId}));
  }

  Future<void> showMissedCall({required String callId, required bool video}) async {
    if (!_localReady) return;
    const details = NotificationDetails(android: AndroidNotificationDetails(
      likedinCallChannelId, 'Likedin calls', channelDescription: 'Missed call alerts',
      importance: Importance.max, priority: Priority.high, playSound: true,
      sound: RawResourceAndroidNotificationSound('likedin_call'),
      category: AndroidNotificationCategory.missedCall,
    ));
    await _local.show(_notificationId(callId), 'Missed ${video ? 'video' : 'audio'} call', 'Your friend tried to reach you.', details,
      payload: jsonEncode({'route':'missed_call','call_id':callId}));
  }

  Future<String?> getPushToken() async {
    if (!_pushReady) return null;
    return FirebaseMessaging.instance.getToken();
  }

  Future<void> registerCurrentToken() async {
    if (!_pushReady) return;
    try {
      final token = await FirebaseMessaging.instance.getToken();
      if (token != null) await _saveToken(token);
    } catch (error) {
      _tokenRegistered = false;
      debugPrint('Could not register Likedin push token: $error');
    }
  }

  Future<void> unregisterCurrentToken() async {
    try {
      final client = Supabase.instance.client;
      final user = client.auth.currentUser;
      final token = await FirebaseMessaging.instance.getToken();
      if (user != null && token != null && token.isNotEmpty) {
        await client
            .from('likedin_push_tokens')
            .delete()
            .eq('user_id', user.id)
            .eq('token', token);
      }
    } catch (error) {
      debugPrint('Could not unregister current Likedin push token: $error');
    }
    _tokenRegistered = false;
  }

  Future<void> _saveToken(String token) async {
    final client = Supabase.instance.client;
    final user = client.auth.currentUser;
    if (user == null) {
      _tokenRegistered = false;
      debugPrint('FCM token exists, but no Supabase user is signed in yet.');
      return;
    }
    try {
      await client.rpc('likedin_register_push_token', params: {'p_token': token});
      _tokenRegistered = true;
      debugPrint('Likedin FCM token registered for the signed-in account.');
    } catch (error) {
      _tokenRegistered = false;
      debugPrint('FCM token could not be saved to likedin_push_tokens: $error');
    }
  }
}
