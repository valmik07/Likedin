import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';

import '../backend/realtime_messaging_service.dart';
import '../backend/shared_media_service.dart';
import 'glassmorphism.dart';
import '../utils/chat_info_metrics.dart';

class ChatInfoSnapshot {
  const ChatInfoSnapshot({
    required this.displayName,
    required this.presence,
    required this.avatarUrl,
    this.messages,
  });

  final String displayName;
  final String presence;
  final String? avatarUrl;
  final List<RemoteMessage>? messages;
}

class ChatInfoPage extends StatefulWidget {
  const ChatInfoPage({
    required this.displayName,
    required this.presence,
    required this.avatarUrl,
    required this.messages,
    required this.mediaService,
    required this.loadSnapshot,
    required this.onOpenAvatar,
    required this.onOpenMedia,
    required this.onManageStorage,
    required this.onClearChat,
    required this.onChangeNickname,
    super.key,
  });

  final String displayName;
  final String presence;
  final String? avatarUrl;
  final List<RemoteMessage> messages;
  final SharedMediaService mediaService;
  final Future<ChatInfoSnapshot> Function({bool loadAllMessages}) loadSnapshot;
  final VoidCallback onOpenAvatar;
  final ValueChanged<Map<String, dynamic>> onOpenMedia;
  final VoidCallback onManageStorage;
  final Future<void> Function() onClearChat;
  final VoidCallback onChangeNickname;

  @override
  State<ChatInfoPage> createState() => _ChatInfoPageState();
}

class _ChatInfoPageState extends State<ChatInfoPage> {
  late String _displayName = widget.displayName;
  late String _presence = widget.presence;
  String? _avatarUrl;
  late List<RemoteMessage> _messages;
  late List<Map<String, dynamic>> _mediaItems;
  late int _linkCount;
  Timer? _refreshTimer;
  Timer? _metricsRefreshTimer;
  bool _refreshing = false;
  bool _reloadPending = false;
  bool _pendingLoadAllMessages = false;

  @override
  void initState() {
    super.initState();
    _avatarUrl = widget.avatarUrl;
    _messages = List<RemoteMessage>.unmodifiable(widget.messages);
    _mediaItems = ChatInfoMetrics.mediaItems(_messages);
    _linkCount = ChatInfoMetrics.linkCount(_messages);
    _reload(loadAllMessages: true);
    _refreshTimer = Timer.periodic(const Duration(seconds: 15), (_) => _reload(loadAllMessages: false));
    // Refresh full-history counts less frequently than presence to avoid a
    // large conversation download on every short presence tick.
    _metricsRefreshTimer = Timer.periodic(const Duration(seconds: 60), (_) => _reload(loadAllMessages: true));
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _metricsRefreshTimer?.cancel();
    super.dispose();
  }

  Future<void> _reload({bool loadAllMessages = false}) async {
    if (_refreshing) {
      _reloadPending = true;
      _pendingLoadAllMessages = _pendingLoadAllMessages || loadAllMessages;
      return;
    }
    _refreshing = true;
    try {
      final snapshot = await widget.loadSnapshot(loadAllMessages: loadAllMessages);
      if (!mounted) return;
      setState(() {
        _displayName = snapshot.displayName;
        _presence = snapshot.presence;
        _avatarUrl = snapshot.avatarUrl;
        if (snapshot.messages != null) {
          _messages = List<RemoteMessage>.unmodifiable(snapshot.messages!);
          _mediaItems = ChatInfoMetrics.mediaItems(_messages);
          _linkCount = ChatInfoMetrics.linkCount(_messages);
        }
      });
    } catch (_) {
      // Keep the last complete snapshot visible when presence/network refresh fails.
    } finally {
      _refreshing = false;
      if (mounted && _reloadPending) {
        final reloadAll = _pendingLoadAllMessages;
        _reloadPending = false;
        _pendingLoadAllMessages = false;
        unawaited(_reload(loadAllMessages: reloadAll));
      }
    }
  }

  Future<void> _clearAndRefresh() async {
    await widget.onClearChat();
    if (mounted) await _reload(loadAllMessages: true);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final media = _mediaItems;
    final linkCount = _linkCount;
    final documentCount = ChatInfoMetrics.documentCount(media);
    final sharedCount = media.length + linkCount;
    // The helper is explicit about the oldest-first source order and returns
    // newest-first visual media without touching document/voice-note files.
    final newest = ChatInfoMetrics.visualMediaItems(media).reversed.toList(growable: false);
    final previews = ChatInfoMetrics.latestVisualMedia(media, limit: 4);
    final bottomInset = MediaQuery.paddingOf(context).bottom;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: true,
            backgroundColor: theme.scaffoldBackgroundColor,
            surfaceTintColor: Colors.transparent,
            leading: IconButton(
              tooltip: 'Back to chat',
              onPressed: () => Navigator.of(context).pop(),
              icon: const Icon(Icons.arrow_back_rounded),
            ),
            title: const Text('Contact info', style: TextStyle(fontWeight: FontWeight.w700)),
            actions: [
              PopupMenuButton<String>(
                onSelected: (value) {
                  if (value == 'clear') _clearAndRefresh();
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'clear', child: Text('Clear chat on this device')),
                ],
              ),
            ],
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(22, 18, 22, 12),
              child: Column(
                children: [
                  Semantics(
                    button: true,
                    label: 'View $_displayName profile photo',
                    child: GestureDetector(
                      onTap: _avatarUrl == null ? null : widget.onOpenAvatar,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(colors: [
                            theme.colorScheme.primary.withValues(alpha: .75),
                            theme.colorScheme.secondary.withValues(alpha: .25),
                          ]),
                        ),
                        child: CircleAvatar(
                          radius: 65,
                          backgroundColor: theme.colorScheme.surfaceContainerHighest,
                          backgroundImage: _avatarUrl == null ? null : NetworkImage(_avatarUrl!),
                          child: _avatarUrl == null
                              ? Icon(Icons.person_rounded, size: 58, color: theme.colorScheme.onSurfaceVariant)
                              : null,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 17),
                  Text(_displayName, textAlign: TextAlign.center,
                      style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 5),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(
                          color: _presence.toLowerCase() == 'online'
                              ? const Color(0xFF2FBF86)
                              : theme.colorScheme.outline,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 7),
                      Text(_presence, style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  if (_refreshing)
                    const SizedBox(width: 52, child: LinearProgressIndicator(minHeight: 2)),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 8, 18, 0),
              child: GlassPanel(
                blur: 10,
                glow: false,
                radius: BorderRadius.circular(22),
                padding: const EdgeInsets.fromLTRB(16, 15, 16, 14),
                tint: theme.colorScheme.surface.withValues(alpha: .72),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Semantics(
                      button: newest.isNotEmpty,
                      label: 'Shared media, links, and documents. $sharedCount items. Open all media.',
                      child: InkWell(
                        borderRadius: BorderRadius.circular(10),
                        onTap: newest.isEmpty ? null : () => Navigator.of(context).push<void>(
                          MaterialPageRoute<void>(
                            builder: (_) => _SharedMediaGalleryPage(
                              items: newest,
                              service: widget.mediaService,
                              onOpenMedia: widget.onOpenMedia,
                            ),
                          ),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(children: [
                            Expanded(child: Text('Media, links, and docs', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700))),
                            Text('$sharedCount', style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
                          ]),
                        ),
                      ),
                    ),
                    if (previews.isNotEmpty) ...[
                      const SizedBox(height: 13),
                      SizedBox(
                        height: 76,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: previews.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 9),
                          itemBuilder: (_, index) {
                            final item = previews[index];
                            final kind = item['kind']?.toString() ?? 'image';
                            return _SharedMediaThumbnail(
                              key: ValueKey('contact-media-${item['path'] ?? index}'),
                              payload: item,
                              service: widget.mediaService,
                              isVideo: kind == 'video',
                              onTap: () => widget.onOpenMedia(item),
                            );
                          },
                        ),
                      ),
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton.icon(
                          onPressed: () => Navigator.of(context).push<void>(MaterialPageRoute<void>(
                            builder: (_) => _SharedMediaGalleryPage(
                              items: newest,
                              service: widget.mediaService,
                              onOpenMedia: widget.onOpenMedia,
                            ),
                          )),
                          icon: const Icon(Icons.grid_view_rounded, size: 17),
                          label: const Text('See all media'),
                        ),
                      ),
                    ] else
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 18),
                        child: Text('No shared media yet', style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
                      ),
                  ],
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: EdgeInsets.fromLTRB(18, 14, 18, 28 + bottomInset),
            sliver: SliverList.list(children: [
              _InfoAction(
                icon: Icons.storage_outlined,
                title: 'Manage storage',
                subtitle: 'Review saved media, cache and upload queue',
                onTap: widget.onManageStorage,
              ),
              _InfoAction(
                icon: Icons.edit_outlined,
                title: 'Chat nickname',
                subtitle: 'Change how this contact appears in the chat',
                onTap: widget.onChangeNickname,
              ),
              const SizedBox(height: 8),
              _InfoAction(
                icon: Icons.delete_outline_rounded,
                title: 'Clear chat',
                subtitle: 'Clear this conversation on this device only',
                destructive: true,
                onTap: _clearAndRefresh,
              ),
              const SizedBox(height: 12),
              Text('Shared items: ${media.length - documentCount} media · $linkCount links · $documentCount documents',
                  style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
            ]),
          ),
        ],
      ),
    );
  }
}

class _SharedMediaGalleryPage extends StatelessWidget {
  const _SharedMediaGalleryPage({required this.items, required this.service, required this.onOpenMedia});
  final List<Map<String, dynamic>> items;
  final SharedMediaService service;
  final ValueChanged<Map<String, dynamic>> onOpenMedia;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Shared media')),
        body: GridView.builder(
          padding: const EdgeInsets.all(12),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3, crossAxisSpacing: 8, mainAxisSpacing: 8,
          ),
          itemCount: items.length,
          itemBuilder: (context, index) {
            final item = items[index];
            return _SharedMediaThumbnail(
              payload: item,
              service: service,
              isVideo: item['kind'] == 'video',
              onTap: () => onOpenMedia(item),
            );
          },
        ),
      );
}

class _InfoAction extends StatelessWidget {
  const _InfoAction({required this.icon, required this.title, required this.subtitle, required this.onTap, this.destructive = false});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final bool destructive;
  @override
  Widget build(BuildContext context) {
    final color = destructive ? Theme.of(context).colorScheme.error : Theme.of(context).colorScheme.onSurface;
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      leading: Icon(icon, color: destructive ? color : Theme.of(context).colorScheme.onSurfaceVariant),
      title: Text(title, style: TextStyle(color: color, fontWeight: FontWeight.w600)),
      subtitle: Text(subtitle),
      onTap: onTap,
    );
  }
}

class _SharedMediaThumbnail extends StatefulWidget {
  const _SharedMediaThumbnail({super.key, required this.payload, required this.service, required this.isVideo, required this.onTap});
  final Map<String, dynamic> payload;
  final SharedMediaService service;
  final bool isVideo;
  final VoidCallback onTap;

  @override
  State<_SharedMediaThumbnail> createState() => _SharedMediaThumbnailState();
}

class _SharedMediaThumbnailState extends State<_SharedMediaThumbnail> {
  late Future<File?> _thumbnailFuture = _loadThumbnail();

  @override
  void didUpdateWidget(covariant _SharedMediaThumbnail oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.payload['path'] != widget.payload['path']) {
      _thumbnailFuture = _loadThumbnail();
    }
  }

  Future<File?> _loadThumbnail() async {
    final sidecarPath = widget.payload['thumbnail_path']?.toString();
    if (sidecarPath != null && sidecarPath.isNotEmpty) {
      try {
        return await widget.service.cachedFile(<String, dynamic>{
          '__likedin_media_v1': true,
          'path': sidecarPath,
          'name': 'media-preview.jpg',
          'mime': 'image/jpeg',
          'kind': 'image',
        });
      } catch (_) {
        // Older messages may predate sidecar thumbnails; use the safe fallback.
      }
    }

    if (!widget.isVideo) {
      // Legacy photos remain viewable; cacheWidth below bounds decoded pixels.
      return widget.service.cachedFile(widget.payload);
    }
    // Never download a legacy full video merely to paint a tiny Contact Info
    // tile. New videos receive JPEG sidecars at upload time.
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Semantics(
      button: true,
      label: widget.isVideo ? 'Open shared video' : 'Open shared photo',
      child: InkWell(
        onTap: widget.onTap,
        borderRadius: BorderRadius.circular(14),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: SizedBox(
            width: 76,
            height: 76,
            child: FutureBuilder<File?>(
              future: _thumbnailFuture,
              builder: (context, snapshot) {
                final file = snapshot.data;
                if (file != null) {
                  return Stack(fit: StackFit.expand, children: [
                    Image.file(file, fit: BoxFit.cover, cacheWidth: 192, cacheHeight: 192,
                      errorBuilder: (_, __, ___) => _fallback(theme)),
                    if (widget.isVideo)
                      const Center(child: Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 30)),
                  ]);
                }
                return _fallback(theme, loading: snapshot.connectionState == ConnectionState.waiting);
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _fallback(ThemeData theme, {bool loading = false}) => Container(
        color: theme.colorScheme.surfaceContainerHighest,
        alignment: Alignment.center,
        child: loading
            ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
            : Icon(widget.isVideo ? Icons.video_library_outlined : Icons.image_outlined,
                color: theme.colorScheme.primary, size: 27),
      );
}
