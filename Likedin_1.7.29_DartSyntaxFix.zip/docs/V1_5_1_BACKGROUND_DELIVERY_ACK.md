# Likedin v1.5.1 — background delivery acknowledgement

## Behaviour

- One grey tick: message is sent but the recipient device has not acknowledged its FCM data push or synchronized it in the app.
- Two grey ticks: the recipient device's background handler received the high-priority FCM data message and acknowledged that exact message to Supabase, or the app synchronized it while running.
- Two blue ticks: the recipient opened the visible conversation and the app acknowledged it as read.

## Changes

- The Edge Function now sends high-priority Android data-only FCM messages (28-day FCM TTL).
- The Android background handler initializes Firebase and Supabase, calls `likedin_mark_message_delivered(p_message_id)` for the exact pushed message, then displays the generic local notification.
- Local notification taps route to Chat.
- Existing foreground notifications and normal foreground synchronization remain in place.

## Required Supabase migration

Run `supabase/migrations/202611090004_push_delivery_ack.sql` once in the Supabase SQL Editor. It creates a recipient-scoped RPC that can acknowledge only a message addressed to the signed-in account. Existing `likedin_mark_delivered()` remains unchanged for normal app synchronization.

## Deployment

1. Deploy the updated Edge Function: `supabase functions deploy send-message-push --no-verify-jwt`. Existing Firebase service-account and webhook secrets remain unchanged.
2. Run the SQL migration above.
3. Build and install the updated APK on both phones.
4. Test with the recipient phone online, then offline, send a message, and reconnect the recipient phone without opening Likedin.

## Android limitations

High-priority FCM data messages are designed for prompt background processing, but Android/OEM battery management, force-stop, notification permission, network state, and FCM delivery conditions can delay or prevent immediate processing. A force-stopped app generally will not run its background handler until manually launched again. Therefore two grey ticks mean the device handler acknowledged the push (or the app synchronized the message), not that the server merely accepted the push. If background processing is delayed, the existing app-sync path will acknowledge pending messages when Likedin next runs.

## Validation status

This source change has not yet been compiled or tested on physical devices. Validate with the project's GitHub Actions workflow before installing.
