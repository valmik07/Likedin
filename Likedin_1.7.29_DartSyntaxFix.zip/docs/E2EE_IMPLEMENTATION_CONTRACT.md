# E2EE implementation contract

## Required protocol

Use a maintained, auditable Signal Protocol implementation with compatible
wire formats. Do not implement a home-grown X25519 + AES ratchet and call it
Signal-compatible. Before choosing a Flutter bridge, verify upstream provenance,
maintenance status, supported Android ABIs, licence, test vectors, and whether
it implements current X3DH/PQXDH and Double Ratchet requirements.

## Device model

One Likedin account is registered to one active Android device. Private identity
keys, signed-prekey private material, one-time prekeys, and ratchet state stay on
the device. Store key material with Android Keystore-backed protection; never
place private keys in Supabase, SharedPreferences, logs, crash reports, or
plaintext backups.

## Message flow

1. Generate device identity and prekeys locally.
2. Publish only public identity/prekey material in `device_key_bundles`.
3. Verify peer bundle signatures and establish a protocol session.
4. Encrypt locally; only ciphertext and protocol metadata may leave the device.
5. Server stores/relays ciphertext and delivery metadata, never plaintext.
6. Decrypt only on recipient device; persist ratchet state atomically with message
   processing to prevent state rollback or duplicate message corruption.
7. Fail closed: if encryption/decryption fails, do not send or display a plaintext
   fallback.

## Acceptance tests

- Supabase database inspection cannot recover message plaintext.
- Modified/tampered ciphertext fails authentication.
- Replay and duplicate delivery do not corrupt ratchet state.
- Messages queued offline remain ciphertext and deliver after reconnect.
- Identity-key changes trigger a visible verification warning.
- Safety-number/QR verification matches on both devices.
- Private keys never appear in exported diagnostics or Supabase.
- Two Android devices interoperate using protocol test vectors.
