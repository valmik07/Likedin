import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  const authHeader = req.headers.get("Authorization") ?? "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
  if (!token) return json({ error: "Authentication required" }, 401);

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
  const turnUrl = Deno.env.get("TURN_SERVER_URL");
  const turnUsername = Deno.env.get("TURN_USERNAME");
  const turnPassword = Deno.env.get("TURN_PASSWORD");
  if (!supabaseUrl || !anonKey || !turnUrl || !turnUsername || !turnPassword) {
    console.error("Missing required TURN/Supabase function secret.");
    return json({ error: "Calling service is not configured" }, 503);
  }

  // Validate the caller's Supabase access token; never trust a user id from the body.
  const supabase = createClient(supabaseUrl, anonKey, {
    global: { headers: { Authorization: `Bearer ${token}` } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data, error } = await supabase.auth.getUser(token);
  if (error || !data.user) return json({ error: "Invalid session" }, 401);

  // Optional additional TURN endpoints (e.g. TCP/TLS) can be added as a
  // comma-separated TURN_SERVER_URLS secret later. Keep the current endpoint as fallback.
  const urls = (Deno.env.get("TURN_SERVER_URLS") ?? turnUrl)
    .split(",").map((value) => value.trim()).filter(Boolean);
  return json({ iceServers: [{ urls, username: turnUsername, credential: turnPassword }] }, 200);
});

function json(body: Record<string, unknown>, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json", "Cache-Control": "no-store" },
  });
}
