import 'dart:async';
import 'dart:convert';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import 'call_alert_controller.dart';

class LikedinCallService {
  LikedinCallService(this.client);
  final SupabaseClient client;
  final _uuid = const Uuid();
  RTCPeerConnection? _pc;
  MediaStream? _local;
  final _remote = RTCVideoRenderer();
  final _localRenderer = RTCVideoRenderer();
  final List<RTCIceCandidate> _pendingCandidates = [];
  bool _remoteDescriptionReady = false;
  RealtimeChannel? _channel;
  Timer? _ringTimer;
  String? callId, peerId;
  bool video = false, muted = false, speaker = false, camera = true;
  String status = 'idle';
  final _changes = StreamController<String>.broadcast();
  Future<void>? _disposeFuture;
  Future<void>? _closeFuture;
  Stream<String> get changes => _changes.stream;
  RTCVideoRenderer get remoteRenderer => _remote;
  RTCVideoRenderer get localRenderer => _localRenderer;
  String get uid => client.auth.currentUser!.id;

  Future<void> initialize() async { await _remote.initialize(); await _localRenderer.initialize(); }

  // Start on the handset earpiece. Speakerphone is an explicit user choice.
  Future<void> _routeToEarpiece() async {
    speaker = false;
    await Helper.setSpeakerphoneOn(false);
  }

  Future<List<Map<String,dynamic>>> _iceServers() async {
    final session = client.auth.currentSession;
    if (session == null) throw StateError('Sign in before calling.');
    final response = await client.functions.invoke('get-turn-config', headers: {'Authorization':'Bearer ${session.accessToken}'});
    if (response.status != 200 || response.data is! Map || response.data['iceServers'] is! List) throw StateError('Could not load TURN configuration: ${response.data}');
    return (response.data['iceServers'] as List).cast<Map<String,dynamic>>();
  }

  Future<void> _createPeer() async {
    final servers = await _iceServers();
    _pc = await createPeerConnection({'iceServers': servers, 'sdpSemantics':'unified-plan'});
    _pc!.onIceCandidate = (candidate) { if (candidate.candidate != null && callId != null) _send('ice', {'candidate':candidate.candidate,'sdpMid':candidate.sdpMid,'sdpMLineIndex':candidate.sdpMLineIndex}); };
    _pc!.onTrack = (event) { if (event.streams.isNotEmpty) { _remote.srcObject = event.streams.first; _changes.add('connected'); } };
    _pc!.onConnectionState = (state) {
      final raw = state.toString().toLowerCase();
      if (raw.contains('connected')) {
        status = 'connected';
      } else if (raw.contains('connecting')) {
        status = 'connecting';
      } else if (raw.contains('disconnected')) {
        status = 'disconnected';
      } else if (raw.contains('failed')) {
        status = 'failed';
      } else if (raw.contains('closed')) {
        status = 'ended';
      } else {
        status = 'connecting';
      }
      _changes.add(status);
    };
    _local = await navigator.mediaDevices.getUserMedia({'audio':true,'video':video ? {'facingMode':'user','width':{'ideal':640},'height':{'ideal':480}} : false});
    // getUserMedia may initialize Android's audio route; re-assert earpiece afterwards.
    speaker = false;
    await Helper.setSpeakerphoneOn(false);
    _localRenderer.srcObject = _local;
    for (final track in _local!.getTracks()) { await _pc!.addTrack(track, _local!); }
  }

  Future<void> start(String recipient, {required bool withVideo}) async {
    video = withVideo; peerId = recipient; callId = _uuid.v4(); status = 'calling';
    await _routeToEarpiece();
    // Prepare camera/microphone and the SDP offer BEFORE publishing the ringing
    // row. Video capture can take several seconds (especially on first permission
    // grant); publishing the row first lets the callee receive a push while no
    // offer exists yet, and its short offer wait can expire without showing UI.
    await _createPeer();
    final offer = await _pc!.createOffer();

    // Publish only after media and offer creation have succeeded. ICE gathering
    // starts at setLocalDescription below, so every candidate still has a row.
    await client.from('likedin_calls').insert({'id':callId,'caller_id':uid,'callee_id':recipient,'call_type':video?'video':'audio','status':'ringing'});
    await CallAlertController.startOutgoing();
    _ringTimer?.cancel();
    _ringTimer = Timer(const Duration(seconds: 45), () async {
      if (status == 'calling' && callId != null) {
        try { await client.from('likedin_calls').update({'status':'missed','ended_at':DateTime.now().toUtc().toIso8601String()}).eq('id', callId!); } catch (_) {}
        try { await _send('end', {'reason':'no_answer'}); } catch (_) {}
        status = 'missed';
        _changes.add(status);
        await dispose();
      }
    });
    _listen();
    await _pc!.setLocalDescription(offer);
    await _send('offer', {'sdp':offer.sdp,'type':offer.type}); _changes.add(status);
  }

  Future<void> accept(String id, String caller, Map<String,dynamic> offer, {required bool withVideo}) async {
    callId=id; peerId=caller; video=withVideo; status='connecting';
    await _routeToEarpiece();
    // Subscribe before creating/sending the answer so early ICE candidates are not missed.
    _listen();
    await _createPeer();
    await _pc!.setRemoteDescription(RTCSessionDescription(offer['sdp'] as String, offer['type'] as String));
    _remoteDescriptionReady=true;
    // Reconcile candidates that arrived before the Realtime subscription was ready.
    final existing = await client.from('likedin_call_signals').select('sender_id,kind,payload')
      .eq('call_id', id).eq('kind', 'ice').neq('sender_id', uid).order('created_at');
    for (final row in existing) {
      final data = Map<String,dynamic>.from(row['payload'] as Map);
      if (data['candidate'] != null) {
        await _pc!.addCandidate(RTCIceCandidate(data['candidate'], data['sdpMid'], data['sdpMLineIndex']));
      }
    }
    for(final c in _pendingCandidates) { await _pc!.addCandidate(c); } _pendingCandidates.clear();
    final answer=await _pc!.createAnswer(); await _pc!.setLocalDescription(answer);
    await client.from('likedin_calls').update({'status':'accepted','answered_at':DateTime.now().toUtc().toIso8601String()}).eq('id',id);
    await _send('answer', {'sdp':answer.sdp,'type':answer.type}); _changes.add(status);
  }

  void _listen() {
    _channel=client.channel('call-$callId-${uid.substring(0,6)}')
      .onPostgresChanges(event:PostgresChangeEvent.insert,schema:'public',table:'likedin_call_signals',filter:PostgresChangeFilter(type:PostgresChangeFilterType.eq,column:'call_id',value:callId),callback:(payload) async {
        final row=payload.newRecord; if(row['sender_id']==uid) return; final kind=row['kind']; final data=Map<String,dynamic>.from(row['payload'] as Map);
        try {
          if(kind=='answer' && _pc!=null) { await CallAlertController.stop(); _ringTimer?.cancel(); await _pc!.setRemoteDescription(RTCSessionDescription(data['sdp'],data['type'])); _remoteDescriptionReady=true; for(final c in _pendingCandidates) { await _pc!.addCandidate(c); } _pendingCandidates.clear(); status='connecting'; _changes.add(status); }
          if(kind=='ice' && _pc!=null) { final c=RTCIceCandidate(data['candidate'],data['sdpMid'],data['sdpMLineIndex']); if(_remoteDescriptionReady) { await _pc!.addCandidate(c); } else { _pendingCandidates.add(c); } }
          if (kind == 'end' || kind == 'reject') {
            final terminalStatus = kind == 'reject' ? 'rejected' : 'ended';
            // A remote hang-up must release the peer connection, media tracks,
            // renderers and Realtime channel before another call can start.
            await dispose();
            status = terminalStatus;
            _changes.add(status);
          }
        } catch(e) { status='error: $e'; _changes.add(status); }
      })..subscribe();
  }
  Future<void> _send(String kind, Map<String,dynamic> payload) async { await client.from('likedin_call_signals').insert({'call_id':callId,'sender_id':uid,'kind':kind,'payload':payload}); }
  Future<void> toggleMute() async { muted=!muted; for(final t in _local?.getAudioTracks()??[]) { t.enabled=!muted; } _changes.add(status); }
  Future<void> toggleCamera() async { camera=!camera; for(final t in _local?.getVideoTracks()??[]) { t.enabled=camera; } _changes.add(status); }
  Future<void> switchCamera() async { final tracks=_local?.getVideoTracks()??[]; if(tracks.isNotEmpty) await Helper.switchCamera(tracks.first); }
  Future<void> toggleSpeaker() async { final next = !speaker; await Helper.setSpeakerphoneOn(next); speaker=next; _changes.add(status); }
  Future<void> end({bool rejected=false}) async { await CallAlertController.stop(); _ringTimer?.cancel(); try { await _send(rejected?'reject':'end',{}); } catch(_) {} try { await client.from('likedin_calls').update({'status':rejected?'rejected':'ended','ended_at':DateTime.now().toUtc().toIso8601String()}).eq('id',callId!); } catch(_) {} await dispose(); status=rejected?'rejected':'ended'; _changes.add(status); }
  // Local hang-up and the remote terminal signal can arrive almost together.
  // Share one cleanup future so native WebRTC resources are never closed twice.
  Future<void> dispose() => _disposeFuture ??= _disposeResources();

  Future<void> _disposeResources() async {
    await CallAlertController.stop();
    _ringTimer?.cancel();
    _ringTimer = null;

    final channel = _channel;
    _channel = null;
    if (channel != null) {
      try { await client.removeChannel(channel); } catch (_) {}
    }

    final peer = _pc;
    _pc = null;
    if (peer != null) {
      try { await peer.close(); } catch (_) {}
    }

    final local = _local;
    _local = null;
    if (local != null) {
      try { await local.dispose(); } catch (_) {}
    }

    _remote.srcObject = null;
    _localRenderer.srcObject = null;
    _pendingCandidates.clear();
    _remoteDescriptionReady = false;
  }

  Future<void> close() => _closeFuture ??= _closeResources();

  Future<void> _closeResources() async {
    await dispose();
    try { await _remote.dispose(); } catch (_) {}
    try { await _localRenderer.dispose(); } catch (_) {}
    if (!_changes.isClosed) await _changes.close();
  }
}
