import 'package:flutter/services.dart';

/// Bridges call ringtone/ringback and synchronized vibration to Android.
class CallAlertController {
  static const MethodChannel _channel = MethodChannel('com.example.likedin/call_alerts');

  static Future<void> startIncoming() async {
    try { await _channel.invokeMethod<void>('startIncoming'); } on PlatformException { /* Device may not support call alerts. */ }
  }

  static Future<void> startOutgoing() async {
    try { await _channel.invokeMethod<void>('startOutgoing'); } on PlatformException { /* Device may not support call alerts. */ }
  }

  static Future<void> stop() async {
    try { await _channel.invokeMethod<void>('stop'); } on PlatformException { /* Best-effort cleanup. */ }
  }
}
