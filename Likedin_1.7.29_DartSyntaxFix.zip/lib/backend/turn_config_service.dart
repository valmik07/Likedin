import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Retrieves TURN credentials from the authenticated Supabase Edge Function.
/// TURN credentials are never embedded in the APK or source repository.
class TurnConfigService {
  TurnConfigService(this._client);
  final SupabaseClient _client;

  Future<List<Map<String, dynamic>>> fetchIceServers() async {
    final user = _client.auth.currentUser;
    if (user == null) throw StateError('Sign in before requesting call configuration.');

    final response = await _client.functions.invoke('get-turn-config');
    if (response.status != 200) {
      throw Exception('TURN configuration unavailable (${response.status}).');
    }
    final body = response.data;
    if (body is! Map || body['iceServers'] is! List) {
      throw const FormatException('Invalid TURN configuration response.');
    }
    final servers = (body['iceServers'] as List)
        .whereType<Map>()
        .map((item) => Map<String, dynamic>.from(item))
        .toList(growable: false);
    if (servers.isEmpty) throw StateError('No ICE servers were returned.');
    return servers;
  }

  Future<Map<String, dynamic>> createPeerConnectionConfiguration() async => {
        'iceServers': await fetchIceServers(),
        'sdpSemantics': 'unified-plan',
      };
}
