package com.example.likedin

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.net.Uri
import android.os.PowerManager
import android.os.Handler
import android.os.Looper
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/** Sensor-gated proximity handling. Never acquire the screen-off lock just
 * because a call started: only acquire it after the sensor reports NEAR. */
class MainActivity : FlutterActivity(), SensorEventListener {
    private val channelName = "com.example.likedin/proximity"
    private val callAlertChannelName = "com.example.likedin/call_alerts"
    private val downloadsChannelName = "com.example.likedin/downloads"
    private var incomingRingtone: Ringtone? = null
    private var outgoingTone: ToneGenerator? = null
    private var callVibrator: Vibrator? = null
    private val ringbackHandler = Handler(Looper.getMainLooper())
    private var ringbackRunnable: Runnable? = null
    private lateinit var sensorManager: SensorManager
    private var proximitySensor: Sensor? = null
    private var proximityWakeLock: PowerManager.WakeLock? = null
    private var callActive = false
    private var proximityEnabled = false
    private var sensorRegistered = false
    private var isNear = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        proximitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, downloadsChannelName).setMethodCallHandler { call, result ->
            if (call.method != "saveToDownloads") { result.notImplemented(); return@setMethodCallHandler }
            try {
                val sourcePath = call.argument<String>("sourcePath") ?: throw IllegalArgumentException("Missing source file")
                val displayName = call.argument<String>("displayName") ?: "attachment"
                val mimeType = call.argument<String>("mimeType") ?: "application/octet-stream"
                val source = java.io.File(sourcePath)
                if (!source.exists()) throw IllegalStateException("Downloaded temporary file is missing")
                val values = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                    put(android.provider.MediaStore.MediaColumns.MIME_TYPE, mimeType)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
                        put(android.provider.MediaStore.MediaColumns.IS_PENDING, 1)
                    }
                }
                val resolver = contentResolver
                val uri = resolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Android could not create a Downloads entry")
                resolver.openOutputStream(uri)?.use { output -> source.inputStream().use { input -> input.copyTo(output) } }
                    ?: throw IllegalStateException("Could not write downloaded file")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val done = android.content.ContentValues().apply { put(android.provider.MediaStore.MediaColumns.IS_PENDING, 0) }
                    resolver.update(uri, done, null, null)
                }
                source.delete()
                result.success(displayName)
            } catch (error: Exception) {
                result.error("DOWNLOAD_SAVE_FAILED", error.message, null)
            }
        }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, callAlertChannelName).setMethodCallHandler { call, result ->
            try {
                when (call.method) {
                    "startIncoming" -> { startIncomingCallAlert(); result.success(true) }
                    "startOutgoing" -> { startOutgoingCallAlert(); result.success(true) }
                    "stop" -> { stopCallAlert(); result.success(true) }
                    "ensureFullScreenCallPermission" -> {
                        if (Build.VERSION.SDK_INT >= 34) {
                            val manager = getSystemService(android.app.NotificationManager::class.java)
                            if (!manager.canUseFullScreenIntent()) {
                                val intent = Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT).apply { data = Uri.parse("package:$packageName") }
                                startActivity(intent)
                                result.success(false)
                            } else result.success(true)
                        } else result.success(true)
                    }
                    else -> result.notImplemented()
                }
            } catch (error: Exception) {
                android.util.Log.e("LikedinCallAlert", "Call alert operation failed", error)
                result.error("CALL_ALERT_ERROR", error.message, null)
            }
        }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "setAudioCallActive" -> {
                    callActive = call.argument<Boolean>("active") ?: false
                    proximityEnabled = call.argument<Boolean>("enabled") ?: false
                    updateSensorRegistration()
                    result.success(proximitySensor != null)
                }
                else -> result.notImplemented()
            }
        }
    }


    private fun vibrator(): Vibrator? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }

    private fun startCallVibration() {
        val vib = vibrator() ?: return
        callVibrator = vib
        // Repeating pulse groups run from the same start instant as the ringtone.
        val pattern = longArrayOf(0, 650, 350, 650, 1100)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vib.vibrate(VibrationEffect.createWaveform(pattern, 0))
        } else {
            @Suppress("DEPRECATION")
            vib.vibrate(pattern, 0)
        }
    }

    private fun startIncomingCallAlert() {
        stopCallAlert()
        val uri: Uri? = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_RINGTONE)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        if (uri != null) {
            incomingRingtone = RingtoneManager.getRingtone(this, uri)
            incomingRingtone?.apply {
                audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) isLooping = true
                play()
            }
        }
        startCallVibration()
    }

    private fun startOutgoingCallAlert() {
        stopCallAlert()
        // Android's standard telephone ringback cadence, routed through call audio.
        outgoingTone = ToneGenerator(AudioManager.STREAM_VOICE_CALL, 75)
        val repeat = object : Runnable {
            override fun run() {
                val tone = outgoingTone ?: return
                tone.startTone(ToneGenerator.TONE_SUP_RINGTONE, 1800)
                ringbackHandler.postDelayed(this, 4000)
            }
        }
        ringbackRunnable = repeat
        ringbackHandler.post(repeat)
    }

    private fun stopCallAlert() {
        try { incomingRingtone?.stop() } catch (_: Exception) {}
        incomingRingtone = null
        ringbackRunnable?.let { ringbackHandler.removeCallbacks(it) }
        ringbackRunnable = null
        try { outgoingTone?.stopTone(); outgoingTone?.release() } catch (_: Exception) {}
        outgoingTone = null
        try { callVibrator?.cancel() } catch (_: Exception) {}
        callVibrator = null
    }

    private fun updateSensorRegistration() {
        val shouldListen = callActive && proximityEnabled && proximitySensor != null
        if (shouldListen && !sensorRegistered) {
            isNear = false
            sensorRegistered = sensorManager.registerListener(this, proximitySensor, SensorManager.SENSOR_DELAY_NORMAL)
            // Start in the FAR state. A fresh sensor event must explicitly
            // report NEAR before the display is allowed to switch off.
            setProximityWakeLock(false)
        } else if (!shouldListen) {
            if (sensorRegistered) sensorManager.unregisterListener(this)
            sensorRegistered = false
            isNear = false
            setProximityWakeLock(false)
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type != Sensor.TYPE_PROXIMITY) return
        val sensor = proximitySensor ?: return
        val near = event.values.isNotEmpty() && event.values[0] < sensor.maximumRange
        if (near != isNear) {
            isNear = near
            setProximityWakeLock(callActive && proximityEnabled && isNear)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun setProximityWakeLock(near: Boolean) {
        try {
            if (near) {
                if (proximityWakeLock?.isHeld != true) {
                    val power = getSystemService(POWER_SERVICE) as PowerManager
                    proximityWakeLock = power.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "Likedin:ProximityCall")
                    proximityWakeLock?.setReferenceCounted(false)
                    proximityWakeLock?.acquire()
                }
            } else {
                proximityWakeLock?.let { if (it.isHeld) it.release() }
                proximityWakeLock = null
            }
        } catch (error: Exception) {
            android.util.Log.w("LikedinProximity", "Could not update proximity wake lock", error)
        }
    }

    override fun onDestroy() {
        if (sensorRegistered) sensorManager.unregisterListener(this)
        sensorRegistered = false
        setProximityWakeLock(false)
        stopCallAlert()
        super.onDestroy()
    }
}
