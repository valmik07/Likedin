import 'dart:math' as math;

import 'package:flutter/gestures.dart';
import 'package:flutter/physics.dart';
import 'package:flutter/widgets.dart';


/// Complete kinematic snapshot of a live or just-released touch gesture.
class OriginGestureSnapshot {
  const OriginGestureSnapshot({
    required this.startPosition,
    required this.previousPosition,
    required this.position,
    required this.displacement,
    required this.direction,
    required this.distance,
    required this.velocity,
    required this.isReversing,
    this.releaseVelocity = Offset.zero,
    this.active = false,
  });

  static const OriginGestureSnapshot idle = OriginGestureSnapshot(
    startPosition: Offset.zero,
    previousPosition: Offset.zero,
    position: Offset.zero,
    displacement: Offset.zero,
    direction: Offset.zero,
    distance: 0.0,
    velocity: Offset.zero,
    isReversing: false,
  );

  final Offset startPosition;
  final Offset previousPosition;
  final Offset position;
  final Offset displacement;
  final Offset direction;
  final double distance;
  final Offset velocity;
  final Offset releaseVelocity;
  final bool isReversing;
  final bool active;

  double get speed => velocity.distance;
  double get releaseSpeed => releaseVelocity.distance;
}

class _TimedPoint {
  const _TimedPoint(this.position, this.timeUs);
  final Offset position;
  final int timeUs;
}

/// Sliding-window velocity estimator (90 ms window + sub-pixel jitter filter)
/// providing smooth, noise-free velocity for liquid stretch and spring release.
class OriginVelocityTracker {
  final List<_TimedPoint> _samples = <_TimedPoint>[];
  static const int _windowUs = 90000;

  void reset() => _samples.clear();

  void addPosition(Offset position, {Duration? timestamp}) {
    final nowUs = timestamp?.inMicroseconds ?? DateTime.now().microsecondsSinceEpoch;
    _samples.add(_TimedPoint(position, nowUs));
    final cutoff = nowUs - _windowUs;
    while (_samples.length > 2 && _samples.first.timeUs < cutoff) {
      _samples.removeAt(0);
    }
    if (_samples.length > 20) {
      _samples.removeRange(0, _samples.length - 20);
    }
  }

  Offset estimateVelocity() {
    if (_samples.length < 2) return Offset.zero;
    final first = _samples.first;
    final last = _samples.last;
    final dtSec = (last.timeUs - first.timeUs) / 1000000.0;
    if (dtSec <= 0.001) return Offset.zero;
    final delta = last.position - first.position;
    if (delta.distance < 0.75) return Offset.zero;
    return Offset(
      (delta.dx / dtSec).clamp(-6000.0, 6000.0).toDouble(),
      (delta.dy / dtSec).clamp(-6000.0, 6000.0).toDouble(),
    );
  }
}

/// Active scroll axis for coordinated horizontal/vertical gesture handoff.
enum OriginScrollAxis { none, horizontal, vertical }

/// Velocity-aware gesture coordinator tracking full pointer kinematics,
/// direction reversals, cancellations, interruptions, and smooth
/// horizontal ↔ vertical axis handoffs without competing recognizers.
class OriginGestureCoordinator {
  final OriginVelocityTracker _tracker = OriginVelocityTracker();
  OriginGestureSnapshot _snapshot = OriginGestureSnapshot.idle;
  OriginScrollAxis _lockedAxis = OriginScrollAxis.none;
  Offset _lastDelta = Offset.zero;
  double _crossAxisAccum = 0.0;

  OriginGestureSnapshot get snapshot => _snapshot;
  OriginScrollAxis get lockedAxis => _lockedAxis;

  void start(Offset position, {Duration? timestamp}) {
    _tracker.reset();
    _tracker.addPosition(position, timestamp: timestamp);
    _lockedAxis = OriginScrollAxis.none;
    _lastDelta = Offset.zero;
    _crossAxisAccum = 0.0;
    _snapshot = OriginGestureSnapshot(
      startPosition: position,
      previousPosition: position,
      position: position,
      displacement: Offset.zero,
      direction: Offset.zero,
      distance: 0.0,
      velocity: Offset.zero,
      isReversing: false,
      active: true,
    );
  }

  OriginGestureSnapshot update(Offset position, {Duration? timestamp}) {
    final prev = _snapshot.active ? _snapshot.position : position;
    final startPos = _snapshot.active ? _snapshot.startPosition : position;
    final delta = position - prev;
    _tracker.addPosition(position, timestamp: timestamp);

    final disp = position - startPos;
    final dist = disp.distance;
    final dir = dist > 0.001 ? Offset(disp.dx / dist, disp.dy / dist) : Offset.zero;
    final vel = _tracker.estimateVelocity();

    // Detect gesture reversal when current delta opposes prior movement direction.
    final dot = delta.dx * _lastDelta.dx + delta.dy * _lastDelta.dy;
    final reversing = delta.distance > 1.0 && _lastDelta.distance > 1.0 && dot < -0.5;
    if (delta.distance > 0.5) {
      _lastDelta = delta;
    }

    // Initial axis recognition + smooth mid-gesture cross-axis handoff with hysteresis.
    if (_lockedAxis == OriginScrollAxis.none) {
      if (disp.distance >= 6.0) {
        _lockedAxis = disp.dx.abs() >= disp.dy.abs()
            ? OriginScrollAxis.horizontal
            : OriginScrollAxis.vertical;
      }
    } else if (_lockedAxis == OriginScrollAxis.horizontal) {
      if (delta.dy.abs() > delta.dx.abs() * 1.45) {
        _crossAxisAccum += delta.dy.abs();
        if (_crossAxisAccum >= 26.0) {
          _lockedAxis = OriginScrollAxis.vertical;
          _crossAxisAccum = 0.0;
        }
      } else {
        _crossAxisAccum = math.max(0.0, _crossAxisAccum - delta.dx.abs() * 0.5);
      }
    } else if (_lockedAxis == OriginScrollAxis.vertical) {
      if (delta.dx.abs() > delta.dy.abs() * 1.45) {
        _crossAxisAccum += delta.dx.abs();
        if (_crossAxisAccum >= 26.0) {
          _lockedAxis = OriginScrollAxis.horizontal;
          _crossAxisAccum = 0.0;
        }
      } else {
        _crossAxisAccum = math.max(0.0, _crossAxisAccum - delta.dy.abs() * 0.5);
      }
    }

    _snapshot = OriginGestureSnapshot(
      startPosition: startPos,
      previousPosition: prev,
      position: position,
      displacement: disp,
      direction: dir,
      distance: dist,
      velocity: vel,
      isReversing: reversing,
      active: true,
    );
    return _snapshot;
  }

  OriginGestureSnapshot end({Offset? explicitVelocity}) {
    final releaseVel = explicitVelocity ?? _tracker.estimateVelocity();
    _snapshot = OriginGestureSnapshot(
      startPosition: _snapshot.startPosition,
      previousPosition: _snapshot.previousPosition,
      position: _snapshot.position,
      displacement: _snapshot.displacement,
      direction: _snapshot.direction,
      distance: _snapshot.distance,
      velocity: releaseVel,
      releaseVelocity: releaseVel,
      isReversing: _snapshot.isReversing,
      active: false,
    );
    _lockedAxis = OriginScrollAxis.none;
    _crossAxisAccum = 0.0;
    return _snapshot;
  }

  OriginGestureSnapshot cancel() {
    _lockedAxis = OriginScrollAxis.none;
    _crossAxisAccum = 0.0;
    _snapshot = OriginGestureSnapshot(
      startPosition: _snapshot.startPosition,
      previousPosition: _snapshot.previousPosition,
      position: _snapshot.position,
      displacement: _snapshot.displacement,
      direction: _snapshot.direction,
      distance: _snapshot.distance,
      velocity: Offset.zero,
      releaseVelocity: Offset.zero,
      isReversing: false,
      active: false,
    );
    return _snapshot;
  }
}

/// OriginOS 7 elastic scroll physics: snappy inertial flinging, progressive
/// hyperbolic overscroll resistance (never drags infinitely past boundaries),
/// and velocity-preserving spring recovery at edges.
class OriginElasticScrollPhysics extends BouncingScrollPhysics {
  const OriginElasticScrollPhysics({
    super.parent,
    this.maxOverscrollFraction = 0.38,
  }) : super(decelerationRate: ScrollDecelerationRate.fast);

  final double maxOverscrollFraction;

  static const SpringDescription _edgeSpring = SpringDescription(
    mass: 0.78,
    stiffness: 295.0,
    damping: 25.0,
  );

  @override
  OriginElasticScrollPhysics applyTo(ScrollPhysics? ancestor) =>
      OriginElasticScrollPhysics(
        parent: buildParent(ancestor),
        maxOverscrollFraction: maxOverscrollFraction,
      );

  @override
  SpringDescription get spring => _edgeSpring;

  @override
  double frictionFactor(double overscrollFraction) {
    final clamped = overscrollFraction.clamp(0.0, 1.0).toDouble();
    if (clamped >= maxOverscrollFraction) {
      // Progressive asymptotic wall so content cannot pull infinitely away.
      return 0.04 * math.pow(1.0 - clamped, 2);
    }
    return 0.44 * math.pow(1.0 - clamped, 2);
  }

  @override
  double get minFlingVelocity => 45.0;
}

/// Seamless horizontal ↔ vertical nested scroll coordinator widget.
///
/// Wraps a primary scroll view (e.g., a horizontal [PageView] / [TabBarView])
/// and optional vertical gesture callbacks (e.g., interactive drag-to-dismiss in
/// media viewers) so diagonal drags and mid-gesture direction shifts transfer
/// smoothly with preserved release velocity and zero offset jumps.
class OriginCoordinatedPanSurface extends StatefulWidget {
  const OriginCoordinatedPanSurface({
    required this.child,
    this.onHorizontalDelta,
    this.onVerticalDelta,
    this.onHorizontalEnd,
    this.onVerticalEnd,
    this.onCancel,
    this.onTap,
    this.onDoubleTap,
    this.onDoubleTapDown,
    this.allowVertical = true,
    this.allowHorizontal = true,
    super.key,
  });

  final Widget child;
  final ValueChanged<double>? onHorizontalDelta;
  final ValueChanged<double>? onVerticalDelta;
  final ValueChanged<double>? onHorizontalEnd;
  final ValueChanged<double>? onVerticalEnd;
  final VoidCallback? onCancel;
  final VoidCallback? onTap;
  final VoidCallback? onDoubleTap;
  final GestureTapDownCallback? onDoubleTapDown;
  final bool allowVertical;
  final bool allowHorizontal;

  @override
  State<OriginCoordinatedPanSurface> createState() =>
      _OriginCoordinatedPanSurfaceState();
}

class _OriginCoordinatedPanSurfaceState
    extends State<OriginCoordinatedPanSurface> {
  final OriginGestureCoordinator _coordinator = OriginGestureCoordinator();
  OriginScrollAxis _activeAxis = OriginScrollAxis.none;
  bool _pointerDown = false;

  void _finishCurrentAxis(Offset velocity) {
    if (_activeAxis == OriginScrollAxis.horizontal) {
      widget.onHorizontalEnd?.call(velocity.dx);
    } else if (_activeAxis == OriginScrollAxis.vertical) {
      widget.onVerticalEnd?.call(velocity.dy);
    }
    _activeAxis = OriginScrollAxis.none;
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      behavior: HitTestBehavior.translucent,
      onPointerDown: (event) {
        _pointerDown = true;
        _activeAxis = OriginScrollAxis.none;
        _coordinator.start(event.position, timestamp: event.timeStamp);
      },
      onPointerMove: (event) {
        if (!_pointerDown) return;
        final prevAxis = _activeAxis;
        final snap = _coordinator.update(event.position, timestamp: event.timeStamp);
        var nextAxis = _coordinator.lockedAxis;
        if (nextAxis == OriginScrollAxis.horizontal && !widget.allowHorizontal) {
          nextAxis = OriginScrollAxis.none;
        }
        if (nextAxis == OriginScrollAxis.vertical && !widget.allowVertical) {
          nextAxis = OriginScrollAxis.none;
        }
        if (prevAxis != OriginScrollAxis.none &&
            nextAxis != OriginScrollAxis.none &&
            prevAxis != nextAxis) {
          // Seamless mid-gesture handoff: release old axis with live velocity!
          _finishCurrentAxis(snap.velocity);
        }
        _activeAxis = nextAxis;
        if (_activeAxis == OriginScrollAxis.horizontal) {
          widget.onHorizontalDelta?.call(event.delta.dx);
        } else if (_activeAxis == OriginScrollAxis.vertical) {
          widget.onVerticalDelta?.call(event.delta.dy);
        }
      },
      onPointerUp: (_) {
        if (!_pointerDown) return;
        _pointerDown = false;
        final endSnap = _coordinator.end();
        _finishCurrentAxis(endSnap.releaseVelocity);
      },
      onPointerCancel: (_) {
        if (!_pointerDown) return;
        _pointerDown = false;
        _coordinator.cancel();
        _activeAxis = OriginScrollAxis.none;
        widget.onCancel?.call();
      },
      child: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onTap: widget.onTap,
        onDoubleTapDown: widget.onDoubleTapDown,
        onDoubleTap: widget.onDoubleTap,
        child: widget.child,
      ),
    );
  }
}
