import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/motion/origin_motion.dart';
import 'package:likedin/ui/glassmorphism.dart';

void main() {
  setUp(() {
    OriginMotionEngine.reduceMotion.value = false;
    OriginMotionEngine.isLowRamDevice = false;
    OriginMotionEngine.deformationIntensity.value = 1.0;
    LikedinAppearance.reduceMotion.value = false;
    LikedinAppearance.isLowRamDevice = false;
  });

  group('A. Spring Physics (OriginSpringPhysics & OriginMotionPresets)', () {
    test('fast release produces crisper higher-stiffness spring than slow release', () {
      final slowSpec = OriginMotionPresets.adaptForVelocity(OriginMotionPresets.general, 60.0);
      final fastSpec = OriginMotionPresets.adaptForVelocity(OriginMotionPresets.general, 1800.0);
      expect(fastSpec.stiffness, greaterThan(slowSpec.stiffness));
      expect(fastSpec.damping, greaterThan(slowSpec.damping));
    });

    test('damped spring RK4 integrator preserves initial velocity and settles cleanly', () {
      expect(OriginMotionPresets.elastic.dampingRatio, lessThan(1.0));

      var slow = const OriginSpringState1D(position: 100.0, velocity: 0.0);
      var fast = const OriginSpringState1D(position: 100.0, velocity: -1400.0);
      var minFastPos = fast.position;

      for (var i = 0; i < 120; i++) {
        slow = OriginSpringPhysics.step1D(
          position: slow.position,
          velocity: slow.velocity,
          target: 0.0,
          spec: OriginMotionPresets.elastic,
          dt: 1 / 60,
        );
        fast = OriginSpringPhysics.step1D(
          position: fast.position,
          velocity: fast.velocity,
          target: 0.0,
          spec: OriginMotionPresets.elastic,
          dt: 1 / 60,
        );
        if (fast.position < minFastPos) minFastPos = fast.position;
      }

      expect(minFastPos, lessThan(-10.0));
      expect(slow.position, closeTo(0.0, 0.5));
      expect(fast.position, closeTo(0.0, 0.5));
    });

    test('rubberBand and inverseRubberBand are monotonic, bounded, and invertible', () {
      const limit = 60.0;
      expect(OriginSpringPhysics.rubberBand(0, limit), 0.0);
      expect(OriginSpringPhysics.rubberBand(5000, limit), lessThan(limit));
      expect(OriginSpringPhysics.rubberBand(-5000, limit), greaterThan(-limit));

      final visual = OriginSpringPhysics.rubberBand(85.0, limit);
      final inverted = OriginSpringPhysics.inverseRubberBand(visual, limit);
      expect(inverted, closeTo(85.0, 0.001));
    });

    testWidgets('OriginMotionController supports mid-flight interruption and retargeting without reset', (tester) async {
      late OriginMotionController ctrl;
      await tester.pumpWidget(
        MaterialApp(
          home: StatefulBuilder(
            builder: (context, _) => _ControllerHost(onReady: (c) => ctrl = c),
          ),
        ),
      );

      ctrl.springOffsetTo(
        const Offset(120, 60),
        velocity: const Offset(400, 200),
        spec: OriginMotionPresets.general,
      );
      await tester.pump(const Duration(milliseconds: 50));
      final midPos = ctrl.offset;
      expect(midPos.dx, greaterThan(5.0));

      ctrl.grab();
      expect(ctrl.offset, midPos);
      expect(ctrl.isAnimating, isFalse);

      ctrl.springOffsetTo(const Offset(-40, 10), spec: OriginMotionPresets.soft);
      await tester.pumpAndSettle();
      expect(ctrl.offset.dx, closeTo(-40.0, 0.5));
      expect(ctrl.offset.dy, closeTo(10.0, 0.5));
    });
  });

  group('B. Liquid Deformation & Metaball Separation / Merging', () {
    test('supports horizontal, vertical, and diagonal deformation with readability clamp', () {
      final horiz = OriginFluidPhysics.computeDeformation(
        displacement: const Offset(60, 0),
        velocity: const Offset(500, 0),
      );
      final vert = OriginFluidPhysics.computeDeformation(
        displacement: const Offset(0, -60),
        velocity: const Offset(0, -500),
      );
      final diag = OriginFluidPhysics.computeDeformation(
        displacement: const Offset(45, 45),
        velocity: const Offset(300, 300),
      );

      expect(horiz.direction.dx, closeTo(1.0, 0.01));
      expect(horiz.stretchAlong, greaterThan(1.03));
      expect(horiz.compressAcross, lessThan(1.0));
      expect(horiz.stretchAlong, lessThanOrEqualTo(1.20));

      expect(vert.direction.dy, closeTo(-1.0, 0.01));
      expect(diag.direction.dx, closeTo(0.707, 0.02));
      expect(diag.direction.dy, closeTo(0.707, 0.02));

      final path = OriginFluidPhysics.buildDeformedRRectPath(
        const Size(180, 64),
        BorderRadius.circular(24),
        diag,
      );
      expect(path.getBounds().width, greaterThan(170));
    });

    test('liquid droplet bridge merges when close and ruptures cleanly when separated', () {
      final merged = OriginFluidPhysics.buildLiquidBridgePath(
        centerA: const Offset(20, 20),
        radiusA: 18,
        centerB: const Offset(66, 20),
        radiusB: 18,
        maxBridgeDistance: 60,
      );
      expect(merged, isNotNull);
      expect(merged!.getBounds().width, greaterThan(20));

      final separated = OriginFluidPhysics.buildLiquidBridgePath(
        centerA: const Offset(20, 20),
        radiusA: 18,
        centerB: const Offset(180, 20),
        radiusB: 18,
        maxBridgeDistance: 60,
      );
      expect(separated, isNull);
    });

    test('Reduce Motion disables liquid deformation cleanly', () {
      OriginMotionEngine.reduceMotion.value = true;
      final state = OriginFluidPhysics.computeDeformation(
        displacement: const Offset(80, 40),
        velocity: const Offset(900, 500),
      );
      expect(state.isRest, isTrue);
      expect(state.stretchAlong, 1.0);
    });
  });

  group('C. Gesture Physics & Seamless Horizontal/Vertical Coordination', () {
    test('tracks velocity, diagonal direction, reversal, cancellation, and H<->V axis handoff', () {
      final coord = OriginGestureCoordinator();
      coord.start(const Offset(100, 100), timestamp: const Duration(milliseconds: 0));
      coord.update(const Offset(125, 102), timestamp: const Duration(milliseconds: 16));
      expect(coord.lockedAxis, OriginScrollAxis.horizontal);
      expect(coord.snapshot.isReversing, isFalse);
      expect(coord.snapshot.speed, greaterThan(500.0));

      final rev = coord.update(const Offset(115, 102), timestamp: const Duration(milliseconds: 32));
      expect(rev.isReversing, isTrue);

      coord.update(const Offset(116, 120), timestamp: const Duration(milliseconds: 48));
      coord.update(const Offset(117, 145), timestamp: const Duration(milliseconds: 64));
      expect(coord.lockedAxis, OriginScrollAxis.vertical);

      final end = coord.end();
      expect(end.active, isFalse);
      expect(end.releaseSpeed, greaterThan(100.0));

      coord.start(const Offset(10, 10), timestamp: const Duration(milliseconds: 100));
      final canceled = coord.cancel();
      expect(canceled.active, isFalse);
      expect(canceled.velocity, Offset.zero);
    });
  });

  group('D. Elastic Scrolling & Overscroll', () {
    test('OriginElasticScrollPhysics applies progressive edge resistance', () {
      const physics = OriginElasticScrollPhysics();
      final nearEdge = physics.frictionFactor(0.05);
      final deepEdge = physics.frictionFactor(0.45);
      expect(deepEdge, lessThan(nearEdge));
      expect(deepEdge, greaterThan(0.0));
    });

    testWidgets('Scrollable list flings, overscrolls elastically, and recovers via spring', (tester) async {
      final sc = ScrollController();
      addTearDown(sc.dispose);

      await tester.pumpWidget(
        MaterialApp(
          scrollBehavior: const OriginScrollBehavior(),
          home: Scaffold(
            body: ListView.builder(
              controller: sc,
              itemCount: 40,
              itemBuilder: (_, i) => SizedBox(height: 60, child: Text('Row $i')),
            ),
          ),
        ),
      );

      final gesture = await tester.startGesture(const Offset(180, 200));
      await gesture.moveBy(const Offset(0, 140));
      await tester.pump();
      expect(sc.offset, lessThan(0.0));

      await gesture.up();
      await tester.pumpAndSettle();
      expect(sc.offset, closeTo(0.0, 0.5));
    });
  });

  group('E & F. Reusable Physics Widgets & 3-Tier OriginOS 7 Glass', () {
    testWidgets('OriginSpringToggle supports tap and drag interaction cleanly', (tester) async {
      var state = false;
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: StatefulBuilder(
                builder: (context, setLocal) => OriginSpringToggle(
                  value: state,
                  semanticLabel: 'Test toggle',
                  onChanged: (v) => setLocal(() => state = v),
                ),
              ),
            ),
          ),
        ),
      );

      await tester.tap(find.byType(OriginSpringToggle));
      await tester.pumpAndSettle();
      expect(state, isTrue);

      await tester.drag(find.byType(OriginSpringToggle), const Offset(-45, 0));
      await tester.pumpAndSettle();
      expect(state, isFalse);
    });

    testWidgets('showOriginBottomSheet opens, follows finger drag, and dismisses interactively', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Builder(
            builder: (context) => Scaffold(
              body: ElevatedButton(
                onPressed: () => showOriginBottomSheet<void>(
                  context: context,
                  builder: (_) => const SizedBox(
                    height: 260,
                    child: Center(child: Text('Origin Sheet Content')),
                  ),
                ),
                child: const Text('Open Sheet'),
              ),
            ),
          ),
        ),
      );

      await tester.tap(find.text('Open Sheet'));
      await tester.pumpAndSettle();
      expect(find.text('Origin Sheet Content'), findsOneWidget);

      await tester.fling(find.text('Origin Sheet Content'), const Offset(0, 220), 1200);
      await tester.pumpAndSettle();
      expect(find.text('Origin Sheet Content'), findsNothing);
    });

    testWidgets('3-tier GlassPanel renders Real, Natural, Soft with BackdropFilter on 4+ GB and skips on 3 GB Soft/Natural', (tester) async {
      for (final tier in const [LikedinEffects.real, LikedinEffects.natural, LikedinEffects.soft]) {
        LikedinAppearance.effects.value = tier;
        LikedinAppearance.reduceMotion.value = false;
        LikedinAppearance.isLowRamDevice = false;

        await tester.pumpWidget(
          MaterialApp(
            home: BackdropGroup(
              child: const Scaffold(
                body: Center(
                  child: GlassPanel(
                    frosted: true,
                    child: Text('Glass Test'),
                  ),
                ),
              ),
            ),
          ),
        );
        expect(find.byType(BackdropFilter), findsOneWidget);
      }

      LikedinAppearance.isLowRamDevice = true;
      LikedinAppearance.effects.value = LikedinEffects.soft;
      await tester.pump();
      expect(find.byType(BackdropFilter), findsNothing);
    });
  });
}

class _ControllerHost extends StatefulWidget {
  const _ControllerHost({required this.onReady});
  final ValueChanged<OriginMotionController> onReady;

  @override
  State<_ControllerHost> createState() => _ControllerHostState();
}

class _ControllerHostState extends State<_ControllerHost>
    with TickerProviderStateMixin {
  late final OriginMotionController _ctrl = OriginMotionController(vsync: this);

  @override
  void initState() {
    super.initState();
    widget.onReady(_ctrl);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => const SizedBox.shrink();
}
