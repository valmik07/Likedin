What's New in Likedin v2.9.3+142:

• Instant Files Tab Loading: Added a device-encrypted local Files index (AES-256-GCM) so Media, Audio, and Docs render immediately on open instead of waiting for a full chat-history scan.
• Incremental Background Sync: After the first index build, refreshing the Files tab only fetches and decrypts new messages and deletion tombstones since your last sync, making refreshes near-instant even on long chats.
• Faster Thumbnail Grids & Caching: Cached the media cache directory path and paired peer ID in memory, eliminating repeated lookups across thumbnail tiles and cutting extra network calls.
• Hidden-Chat Sync Fix: Unlocking or locking a hidden chat now immediately updates the Files tab while staying strictly fail-closed when locked.
