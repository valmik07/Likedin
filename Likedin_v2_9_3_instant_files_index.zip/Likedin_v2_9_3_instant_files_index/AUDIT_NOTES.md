# Likedin v2.9.3+142 — Instant Encrypted Files Index & Incremental Sync

## New in v2.9.3+142

| Area | Improvement | Files |
| :--- | :--- | :--- |
| **Encrypted Local Files Index** | Added `FilesIndexStore` & `FilesIndexSnapshot` storing parsed Media/Audio/Docs metadata encrypted at rest with AES-256-GCM (256-bit key in `FlutterSecureStorage`, AAD bound to `uid:peerId`, atomic `.tmp` -> rename) plus a 0 ms in-memory cache. | `lib/data/files_index_store.dart` |
| **Incremental Sync & Deletion Pruning** | Added `loadConversationAfter(...)` (keyset `gt` pagination) and `loadDeletedMessageTombstones(...)` (covering both v2 Double-Ratchet encrypted media and legacy media) in `RealtimeMessagingService` so Files refreshes only fetch new messages and tombstones instead of scanning thousands of historical text messages. | `lib/backend/realtime_messaging_service.dart`, `lib/ui/settings_page_part.dart` |
| **Stale-While-Revalidate Files UI** | `FilesPage` paints local vault files + encrypted Files index immediately (strictly gated behind the fail-closed `HiddenChatVault` check), syncs increments quietly in the background with a subtle spinner on the Refresh icon (long-press Refresh for manual full rebuild), and reacts immediately when `allowHiddenConversationMedia` changes. | `lib/ui/settings_page_part.dart` |
| **Cached Path & Peer Lookups** | Cached `getPeerId()` per `uid` in `RealtimeMessagingService` and `LikedinMediaCache` directory path in `SharedMediaService` (both cleared on sign-out) to speed up thumbnail grid loading on 3 GB phones like the Vivo Y12. | `lib/backend/realtime_messaging_service.dart`, `lib/backend/shared_media_service.dart`, `lib/main.dart` |
| **Unit Tests (23 Suites Total)** | Added `test/files_index_store_test.dart` verifying AES-256-GCM disk encryption (zero plaintext leakage), cold-start reload, corrupted-file fallback, incremental cursor/dedupe/deletion merging, and local hidden/clear-chat display filtering. | `test/files_index_store_test.dart` |
