import 'dart:async';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import '../utils/message_length.dart';

class RemoteMessage {
  const RemoteMessage({
    required this.id,
    required this.senderId,
    required this.recipientId,
    required this.text,
    required this.createdAt,
    this.clientMessageId,
    this.deliveredAt,
    this.readAt,
    this.replyToMessageId,
    this.editedAt,
    this.deletedForEveryoneAt,
    this.deletedMediaPath,
  });
  final String id, senderId, recipientId, text;
  final String? clientMessageId;
  final DateTime createdAt;
  final DateTime? deliveredAt, readAt, editedAt, deletedForEveryoneAt;
  final String? replyToMessageId;
  final String? deletedMediaPath;

  factory RemoteMessage.fromMap(Map<String, dynamic> row) => RemoteMessage(
        id: row['id'] as String,
        clientMessageId: row['client_message_id']?.toString(),
        senderId: row['sender_id'] as String,
        recipientId: row['recipient_id'] as String,
        // Compatibility with the two schemas shipped in prior migrations.
        // IMPORTANT: neither field name proves cryptographic encryption.
        text: (row['body_payload'] ?? row['encrypted_payload'] ?? row['ciphertext'] ?? '').toString(),
        createdAt: DateTime.parse(row['created_at'] as String).toLocal(),
        deliveredAt: row['delivered_at'] == null ? null : DateTime.parse(row['delivered_at'] as String).toLocal(),
        readAt: row['read_at'] == null ? null : DateTime.parse(row['read_at'] as String).toLocal(),
        replyToMessageId: row['reply_to_message_id'] as String?,
        editedAt: row['edited_at'] == null ? null : DateTime.parse(row['edited_at'] as String).toLocal(),
        deletedForEveryoneAt: row['deleted_for_everyone_at'] == null ? null : DateTime.parse(row['deleted_for_everyone_at'] as String).toLocal(),
        deletedMediaPath: row['deleted_media_path']?.toString(),
      );
}

class PeerProfile {
  const PeerProfile({required this.id, required this.name, required this.online, this.lastSeen});
  final String id, name;
  final bool online;
  final DateTime? lastSeen;
}

class RealtimeMessagingService {
  static const int conversationPageSize = 100;
  static const int reactionChunkSize = 100;

  RealtimeMessagingService(this._client);
  final SupabaseClient _client;
  static const _uuid = Uuid();
  RealtimeChannel? _channel;
  RealtimeChannel? _signalChannel;

  String get currentUserId {
    final id = _client.auth.currentUser?.id;
    if (id == null) throw StateError('Please sign in first.');
    return id;
  }

  Future<String?> getPeerId() async {
    final value = await _client.rpc('likedin_get_peer_id');
    return value?.toString();
  }

  Future<PeerProfile?> getPeerProfile() async {
    final peer = await getPeerId();
    if (peer == null) return null;
    final row = await _client
        .from('profiles')
        .select('user_id,display_name,is_online,last_seen_at')
        .eq('user_id', peer)
        .maybeSingle();
    if (row == null) return null;
    return PeerProfile(
      id: peer,
      name: (row['display_name'] as String?)?.trim().isNotEmpty == true
          ? (row['display_name'] as String).trim()
          : 'Likedin friend',
      online: row['is_online'] == true &&
          row['last_seen_at'] != null &&
          DateTime.parse(row['last_seen_at'] as String)
              .isAfter(DateTime.now().toUtc().subtract(const Duration(seconds: 90))),
      lastSeen: row['last_seen_at'] == null ? null : DateTime.parse(row['last_seen_at'] as String).toLocal(),
    );
  }

  /// Loads the newest page by default. Older pages use a composite keyset
  /// cursor so newly-arriving messages do not shift the next page boundary.
  Future<List<RemoteMessage>> loadConversation({
    DateTime? beforeCreatedAt,
    String? beforeId,
    int limit = conversationPageSize,
  }) async {
    final uid = currentUserId;
    var query = _client.from('messages').select();
    if (beforeCreatedAt != null) {
      final stamp = beforeCreatedAt.toUtc().toIso8601String();
      if (beforeId != null && beforeId.isNotEmpty) {
        // Keep the account filter and composite cursor in one PostgREST OR
        // expression. This avoids repeated `or` query parameters while
        // preserving a deterministic (created_at, id) pagination boundary.
        query = query.or(
          'and(sender_id.eq.$uid,created_at.lt.$stamp),' +
              'and(recipient_id.eq.$uid,created_at.lt.$stamp),' +
              'and(sender_id.eq.$uid,created_at.eq.$stamp,id.lt.$beforeId),' +
              'and(recipient_id.eq.$uid,created_at.eq.$stamp,id.lt.$beforeId)',
        );
      } else {
        query = query
            .or('sender_id.eq.$uid,recipient_id.eq.$uid')
            .lt('created_at', stamp);
      }
    } else {
      query = query.or('sender_id.eq.$uid,recipient_id.eq.$uid');
    }
    final rows = await query
        .order('created_at', ascending: false)
        .order('id', ascending: false)
        .limit(limit.clamp(1, 500).toInt());
    return rows.reversed.map((row) => RemoteMessage.fromMap(row)).toList();
  }

  Future<String?> sendMessage(
    String recipientId,
    String text, {
    String? clientMessageId,
    String? replyToMessageId,
  }) async {
    final clean = text.trim();
    if (clean.isEmpty) return null;
    if (likedinMessageCodePointLength(clean) > likedinMaxMessageCodePoints) {
      throw ArgumentError('Message must contain no more than 10000 characters.');
    }
    final stableId = clientMessageId ?? _uuid.v4();
    // Reconcile a prior request that may have committed even though its HTTP
    // response timed out. Reusing the same ID prevents duplicate logical sends.
    final existing = await _client
        .from('messages')
        .select('id')
        .eq('sender_id', currentUserId)
        .eq('client_message_id', stableId)
        .maybeSingle();
    if (existing != null) return existing['id']?.toString();
    final result = await _client.rpc('likedin_send_message_v2', params: {
      'p_recipient_id': recipientId,
      'p_payload': clean,
      'p_client_message_id': stableId,
      'p_reply_to_message_id': replyToMessageId,
    });
    return result?.toString();
  }

  Future<void> deleteMessageForEveryone(String messageId) async {
    await _client.rpc('likedin_delete_message_for_everyone_v2', params: {'p_message_id': messageId});
  }

  /// Returns every deleted media tombstone in the user's conversation.
  /// This is paged because the chat's visible history may only contain the
  /// newest 100 messages; a device that was offline during an old deletion
  /// must still remove that attachment from its private cache on resume.
  Future<List<RemoteMessage>> loadDeletedMediaMessages({int limit = 100}) async {
    final uid = currentUserId;
    final results = <RemoteMessage>[];
    DateTime? beforeCreatedAt;
    String? beforeId;
    while (true) {
      var query = _client
          .from('messages')
          .select()
          .not('deleted_for_everyone_at', 'is', null)
          .not('deleted_media_path', 'is', null);
      if (beforeCreatedAt == null) {
        query = query.or('sender_id.eq.$uid,recipient_id.eq.$uid');
      } else {
        final stamp = beforeCreatedAt.toUtc().toIso8601String();
        query = query.or(
          'and(sender_id.eq.$uid,created_at.lt.$stamp),' +
              'and(recipient_id.eq.$uid,created_at.lt.$stamp),' +
              'and(sender_id.eq.$uid,created_at.eq.$stamp,id.lt.$beforeId),' +
              'and(recipient_id.eq.$uid,created_at.eq.$stamp,id.lt.$beforeId)',
        );
      }
      final rows = await query
          .order('created_at', ascending: false)
          .order('id', ascending: false)
          .limit(limit);
      if (rows.isEmpty) break;
      results.addAll(rows.map((row) => RemoteMessage.fromMap(row)));
      final oldest = rows.last;
      beforeCreatedAt = DateTime.parse(oldest['created_at'].toString());
      beforeId = oldest['id']?.toString();
      if (rows.length < limit || beforeId == null || beforeId.isEmpty) break;
    }
    return results;
  }

  Future<RemoteMessage?> getMessageById(String messageId) async {
    final row = await _client.from('messages').select().eq('id', messageId).maybeSingle();
    return row == null ? null : RemoteMessage.fromMap(row);
  }

  Future<void> editMessage(String messageId, String text) async {
    final clean = text.trim();
    if (clean.isEmpty || likedinMessageCodePointLength(clean) > likedinMaxMessageCodePoints) {
      throw ArgumentError('Message must contain 1 to 10000 characters.');
    }
    await _client.rpc('likedin_edit_message', params: {'p_message_id': messageId, 'p_new_payload': clean});
  }

  Future<Map<String, Set<String>>> loadReactions(List<String> messageIds) async {
    if (messageIds.isEmpty) return <String, Set<String>>{};
    final result = <String, Set<String>>{};
    // PostgREST encodes .in() values into the request URL. Keep each request
    // comfortably below common gateway URL limits (100 UUIDs ~= 3.7 KB).
    for (var start = 0; start < messageIds.length; start += reactionChunkSize) {
      final end = (start + reactionChunkSize).clamp(0, messageIds.length).toInt();
      final chunk = messageIds.sublist(start, end);
      final rows = await _client
          .from('message_reactions')
          .select('message_id,emoji')
          .inFilter('message_id', chunk);
      for (final row in rows) {
        final id = row['message_id'] as String;
        (result[id] ??= <String>{}).add(row['emoji'] as String);
      }
    }
    return result;
  }

  Future<bool> hasMyReaction(String messageId, String emoji) async {
    final row = await _client
        .from('message_reactions')
        .select('message_id')
        .eq('message_id', messageId)
        .eq('user_id', currentUserId)
        .eq('emoji', emoji)
        .maybeSingle();
    return row != null;
  }

  Future<void> setReaction(String messageId, String emoji, {required bool active}) async {
    await _client.rpc('likedin_set_message_reaction', params: {
      'p_message_id': messageId,
      'p_emoji': emoji,
      'p_active': active,
    });
  }

  Future<void> setOnline(bool online) async {
    await _client.rpc('likedin_set_presence', params: {'p_online': online});
  }

  Future<void> markDelivered() async {
    await _client.rpc('likedin_mark_delivered');
  }

  Future<void> markRead() async {
    await _client.rpc('likedin_mark_read');
  }

  void subscribe({
    required String? peerId,
    required void Function() onMessages,
    required void Function() onProfile,
    required void Function(bool) onTyping,
    void Function(Map<String, dynamic>)? onMessageUpdate,
  }) {
    unsubscribe();
    _channel = _client
        .channel('likedin-data-$currentUserId')
        .onPostgresChanges(event: PostgresChangeEvent.insert, schema: 'public', table: 'messages', callback: (_) => onMessages())
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'messages',
          callback: (payload) {
            onMessageUpdate?.call(Map<String, dynamic>.from(payload.newRecord));
            onMessages();
          },
        )
        .onPostgresChanges(event: PostgresChangeEvent.delete, schema: 'public', table: 'messages', callback: (_) => onMessages())
        .onPostgresChanges(event: PostgresChangeEvent.insert, schema: 'public', table: 'message_reactions', callback: (_) => onMessages())
        .onPostgresChanges(event: PostgresChangeEvent.delete, schema: 'public', table: 'message_reactions', callback: (_) => onMessages())
        .onPostgresChanges(event: PostgresChangeEvent.update, schema: 'public', table: 'profiles', callback: (_) => onProfile())
      ..subscribe();
    final ids = <String>[currentUserId, if (peerId != null) peerId]..sort();
    _signalChannel = _client
        .channel('likedin-typing-${ids.join('-')}')
        .onBroadcast(
          event: 'typing',
          callback: (payload) {
            final from = payload['user_id']?.toString();
            if (from != null && from != currentUserId) onTyping(payload['typing'] == true);
          },
        )
      ..subscribe();
  }

  Future<void> sendTyping(bool typing) async {
    final channel = _signalChannel;
    if (channel == null) return;
    await channel.sendBroadcastMessage(
      event: 'typing',
      payload: {'user_id': currentUserId, 'typing': typing},
    );
  }

  void unsubscribe() {
    final a = _channel;
    final b = _signalChannel;
    _channel = null;
    _signalChannel = null;
    if (a != null) _client.removeChannel(a);
    if (b != null) _client.removeChannel(b);
  }
}
