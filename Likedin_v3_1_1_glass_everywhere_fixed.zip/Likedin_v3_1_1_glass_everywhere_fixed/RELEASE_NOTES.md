What's New in Likedin v3.1.1+145:

• Fixed Yellow Underlines & Red Text in Chat Menus: Added a transparent Material text ancestor to all Origin physics bottom sheets so Message Actions and Share-to-Chat sheets always render crisp theme typography with zero yellow double underlines.
• Fixed Glass Showcase Scroll Smearing: Synchronized the GPU optical glass shader's screen bounds with live scroll position so Real, Natural, and Soft glass pills track smoothly during scrolling with zero horizontal streaks.
• Live Optical Glass Across Chat, Menus & Chrome: Enabled frosted GPU glass on the Chat header, message composer, attachment `+` button, floating date pill, jump-to-latest button, pinned/reply bars, Home conversation card, Files tab bar, and upgraded the Chat 3-dot options popup into a frosted OriginOS 7 liquid glass menu.
• Stronger Frost & Readability on Floating Sheets: Upgraded the shader to a 13-tap smooth Vogel-disk frost kernel and boosted modal-sheet diffusion so background chat messages blur cleanly behind Message Actions and Share-to-Chat menus.
