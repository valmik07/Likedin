# Likedin v3.1.1+145 — Chat-Wide Live Optical Glass, Scroll-Synced Shader & Sheet Fixes

See **`RELEASE_NOTES.md`** for release notes (consumed automatically by `android-build-v2.9.0.yml`).
