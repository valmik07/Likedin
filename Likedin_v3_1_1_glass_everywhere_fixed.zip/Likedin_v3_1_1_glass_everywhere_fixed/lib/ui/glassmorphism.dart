import 'dart:async';
import 'dart:math' as math;
import 'dart:ui' show ImageFilter, TileMode;

import 'package:flutter/foundation.dart' show ValueListenable;
import 'package:flutter/material.dart';
import 'package:flutter/physics.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../motion/origin_motion.dart';
import 'origin_optical_glass.dart';

// ---------------------------------------------------------------------------
// Likedin OriginOS 7 Design System
//
// Combines Vivo OriginOS 7's Light & Shadow Aesthetics with ultra-smooth
// low-RAM performance:
//  * 3 Translucent Glass Textures (+ Off):
//      - Real:    Crystal optical translucency, vivid specular rim, live blur
//                 on floating chrome (Origin Island, elastic dock, auth).
//      - Natural: Balanced clear glass sheen & crisp rim (zero blur cost —
//                 automatic default on 3 GB RAM / Android 11 phones).
//      - Soft:    Silky low-glare satin matte glass for calm night reading.
//      - Off:     Solid high-contrast flat surfaces.
//  * Fluid Motion (Spring Physics): True SpringSimulation elastic squish &
//    rebound on cards/buttons plus a stretchy liquid dock pill indicator.
//  * Dynamic Glow: Interactive contact glow & day/night ambient lighting shift.
//  * Glint Light Effect: Angle-responsive iridescent light beam driven by
//    Android's built-in accelerometer (zero third-party packages; auto-off on
//    3 GB RAM devices and when Reduce Motion is enabled).
// ---------------------------------------------------------------------------

/// Accent choices tuned separately for Dark and Light modes so every accent
/// maintains >= 4.5:1 WCAG contrast across all 7 app themes.
class LikedinAccent {
  const LikedinAccent({
    required this.name,
    required this.dark,
    required this.light,
    required this.gradientEnd,
  });

  final String name;
  final Color dark;
  final Color light;
  final Color gradientEnd;

  Color forBrightness(Brightness b) => b == Brightness.dark ? dark : light;
}

const List<LikedinAccent> likedinAccents = [
  LikedinAccent(
    name: 'Electric blue',
    dark: Color(0xFF6FA8FF),
    light: Color(0xFF0A5FD0),
    gradientEnd: Color(0xFF22D3EE),
  ),
  LikedinAccent(
    name: 'Cyan',
    dark: Color(0xFF3DD6F5),
    light: Color(0xFF006A82),
    gradientEnd: Color(0xFF5EEAD4),
  ),
  LikedinAccent(
    name: 'Violet',
    dark: Color(0xFFB39DFF),
    light: Color(0xFF5B3FD6),
    gradientEnd: Color(0xFF7DB8FF),
  ),
  LikedinAccent(
    name: 'Emerald',
    dark: Color(0xFF4FDBA5),
    light: Color(0xFF09704D),
    gradientEnd: Color(0xFF5EE1E8),
  ),
  LikedinAccent(
    name: 'Rose',
    dark: Color(0xFFFF8FB1),
    light: Color(0xFFC2255C),
    gradientEnd: Color(0xFFFFB08A),
  ),
  LikedinAccent(
    name: 'Sunset',
    dark: Color(0xFFFFB36B),
    light: Color(0xFFA84200),
    gradientEnd: Color(0xFFFF7A9E),
  ),
];

/// Unified app-wide OriginOS 7 theme preset adapting cleanly to Dark & Light.
class LikedinThemePreset {
  const LikedinThemePreset({
    required this.name,
    required this.defaultAccentIndex,
    required this.darkBgTop,
    required this.darkBgMid,
    required this.darkBgBottom,
    required this.darkOrb1,
    required this.darkOrb2,
    required this.darkOrb3,
    required this.darkSurface,
    required this.darkSurfaceRaised,
    required this.darkOutline,
    required this.lightBgTop,
    required this.lightBgMid,
    required this.lightBgBottom,
    required this.lightOrb1,
    required this.lightOrb2,
    required this.lightOrb3,
    required this.lightSurface,
    required this.lightSurfaceRaised,
    required this.lightOutline,
  });

  final String name;
  final int defaultAccentIndex;

  final Color darkBgTop;
  final Color darkBgMid;
  final Color darkBgBottom;
  final Color darkOrb1;
  final Color darkOrb2;
  final Color darkOrb3;
  final Color darkSurface;
  final Color darkSurfaceRaised;
  final Color darkOutline;

  final Color lightBgTop;
  final Color lightBgMid;
  final Color lightBgBottom;
  final Color lightOrb1;
  final Color lightOrb2;
  final Color lightOrb3;
  final Color lightSurface;
  final Color lightSurfaceRaised;
  final Color lightOutline;

  List<Color> previewColors(Brightness b) => b == Brightness.dark
      ? [darkBgTop, darkBgMid, darkBgBottom]
      : [lightBgTop, lightBgMid, lightBgBottom];

  Color primaryOrb(Brightness b) => b == Brightness.dark ? darkOrb1 : lightOrb1;
}

const List<LikedinThemePreset> likedinThemePresets = [
  LikedinThemePreset(
    name: 'Default',
    defaultAccentIndex: 0,
    darkBgTop: Color(0xFF0B1530),
    darkBgMid: Color(0xFF091126),
    darkBgBottom: Color(0xFF060B18),
    darkOrb1: Color(0xFF3B82F6),
    darkOrb2: Color(0xFF22D3EE),
    darkOrb3: Color(0xFF6366F1),
    darkSurface: Color(0xFF0E1830),
    darkSurfaceRaised: Color(0xFF16233F),
    darkOutline: Color(0xFF28385A),
    lightBgTop: Color(0xFFF7FAFF),
    lightBgMid: Color(0xFFEFF5FD),
    lightBgBottom: Color(0xFFEAF1FB),
    lightOrb1: Color(0xFF60A5FA),
    lightOrb2: Color(0xFF38BDF8),
    lightOrb3: Color(0xFF93C5FD),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFEBF1FA),
    lightOutline: Color(0xFFD3DEEE),
  ),
  LikedinThemePreset(
    name: 'Ocean',
    defaultAccentIndex: 1,
    darkBgTop: Color(0xFF0C2748),
    darkBgMid: Color(0xFF081B34),
    darkBgBottom: Color(0xFF051122),
    darkOrb1: Color(0xFF0EA5E9),
    darkOrb2: Color(0xFF2DD4BF),
    darkOrb3: Color(0xFF38BDF8),
    darkSurface: Color(0xFF0C1C34),
    darkSurfaceRaised: Color(0xFF132A4A),
    darkOutline: Color(0xFF21426B),
    lightBgTop: Color(0xFFF3F9FF),
    lightBgMid: Color(0xFFE8F4FF),
    lightBgBottom: Color(0xFFE0EFFF),
    lightOrb1: Color(0xFF38BDF8),
    lightOrb2: Color(0xFF5EEAD4),
    lightOrb3: Color(0xFF7DD3FC),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFE7F2FF),
    lightOutline: Color(0xFFC8E0F8),
  ),
  LikedinThemePreset(
    name: 'Rose',
    defaultAccentIndex: 4,
    darkBgTop: Color(0xFF321129),
    darkBgMid: Color(0xFF220C1E),
    darkBgBottom: Color(0xFF130712),
    darkOrb1: Color(0xFFF43F5E),
    darkOrb2: Color(0xFFEC4899),
    darkOrb3: Color(0xFFFB7185),
    darkSurface: Color(0xFF220E1E),
    darkSurfaceRaised: Color(0xFF31162B),
    darkOutline: Color(0xFF4E2445),
    lightBgTop: Color(0xFFFFF7FA),
    lightBgMid: Color(0xFFFEEEF4),
    lightBgBottom: Color(0xFFFCE7EF),
    lightOrb1: Color(0xFFF472B6),
    lightOrb2: Color(0xFFFDA4AF),
    lightOrb3: Color(0xFFF9A8D4),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFFCECF2),
    lightOutline: Color(0xFFF2CEDC),
  ),
  LikedinThemePreset(
    name: 'Emerald',
    defaultAccentIndex: 3,
    darkBgTop: Color(0xFF0B312A),
    darkBgMid: Color(0xFF08221D),
    darkBgBottom: Color(0xFF051412),
    darkOrb1: Color(0xFF10B981),
    darkOrb2: Color(0xFF14B8A6),
    darkOrb3: Color(0xFF34D399),
    darkSurface: Color(0xFF0B211E),
    darkSurfaceRaised: Color(0xFF12312C),
    darkOutline: Color(0xFF1F4C44),
    lightBgTop: Color(0xFFF3FDF9),
    lightBgMid: Color(0xFFE7FAF2),
    lightBgBottom: Color(0xFFDDF6EB),
    lightOrb1: Color(0xFF34D399),
    lightOrb2: Color(0xFF5EEAD4),
    lightOrb3: Color(0xFF6EE7B7),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFE7F7F0),
    lightOutline: Color(0xFFC4E7D8),
  ),
  LikedinThemePreset(
    name: 'Sunset',
    defaultAccentIndex: 5,
    darkBgTop: Color(0xFF351624),
    darkBgMid: Color(0xFF24101E),
    darkBgBottom: Color(0xFF140A16),
    darkOrb1: Color(0xFFFB923C),
    darkOrb2: Color(0xFFF43F5E),
    darkOrb3: Color(0xFFF59E0B),
    darkSurface: Color(0xFF24101C),
    darkSurfaceRaised: Color(0xFF331828),
    darkOutline: Color(0xFF52283E),
    lightBgTop: Color(0xFFFFF8F4),
    lightBgMid: Color(0xFFFEF1EA),
    lightBgBottom: Color(0xFFFDEBE0),
    lightOrb1: Color(0xFFFB923C),
    lightOrb2: Color(0xFFFDA4AF),
    lightOrb3: Color(0xFFFDBA74),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFFDEEE5),
    lightOutline: Color(0xFFF4D4C2),
  ),
  LikedinThemePreset(
    name: 'Lavender',
    defaultAccentIndex: 2,
    darkBgTop: Color(0xFF201846),
    darkBgMid: Color(0xFF151030),
    darkBgBottom: Color(0xFF0B081C),
    darkOrb1: Color(0xFF8B5CF6),
    darkOrb2: Color(0xFF60A5FA),
    darkOrb3: Color(0xFFC084FC),
    darkSurface: Color(0xFF161130),
    darkSurfaceRaised: Color(0xFF211A45),
    darkOutline: Color(0xFF392E6D),
    lightBgTop: Color(0xFFF8F6FF),
    lightBgMid: Color(0xFFF2EEFF),
    lightBgBottom: Color(0xFFECE7FF),
    lightOrb1: Color(0xFFA78BFA),
    lightOrb2: Color(0xFF93C5FD),
    lightOrb3: Color(0xFFC4B5FD),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFEFEBFF),
    lightOutline: Color(0xFFD6CEFA),
  ),
  LikedinThemePreset(
    name: 'Minimal',
    defaultAccentIndex: 0,
    darkBgTop: Color(0xFF141923),
    darkBgMid: Color(0xFF0D1119),
    darkBgBottom: Color(0xFF07090E),
    darkOrb1: Color(0xFF64748B),
    darkOrb2: Color(0xFF94A3B8),
    darkOrb3: Color(0xFF475569),
    darkSurface: Color(0xFF12161F),
    darkSurfaceRaised: Color(0xFF1B212E),
    darkOutline: Color(0xFF2E3749),
    lightBgTop: Color(0xFFFFFFFF),
    lightBgMid: Color(0xFFF7F9FC),
    lightBgBottom: Color(0xFFF0F4F9),
    lightOrb1: Color(0xFFCBD5E1),
    lightOrb2: Color(0xFF94A3B8),
    lightOrb3: Color(0xFFE2E8F0),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFEEF2F7),
    lightOutline: Color(0xFFD8E0EC),
  ),
];

/// OriginOS 7 glass material textures (+ Off for solid maximum contrast).
enum LikedinEffects {
  /// Crisp optical glass with live backdrop blur on floating chrome & specular rim.
  real,

  /// Balanced clear glass sheen & crisp rim with zero live blur GPU cost.
  natural,

  /// Silky matte satin low-glare glass for calm night optics (zero blur cost).
  soft,

  /// Solid flat surfaces for maximum speed and contrast.
  off,
}

/// Drives OriginOS 7's angle-responsive Glint Light sheen from Android's
/// native accelerometer EventChannel (`com.example.likedin/glint_tilt`).
class OriginGlintController {
  OriginGlintController._();

  static const EventChannel _channel =
      EventChannel('com.example.likedin/glint_tilt');

  /// Normalized device tilt offset in `[-1.0, 1.0]`.
  static final ValueNotifier<Offset> tilt = ValueNotifier<Offset>(Offset.zero);
  static StreamSubscription<dynamic>? _sub;

  static void sync() {
    // Soft Glass never renders the Glint tilt beam, so keep the accelerometer
    // completely unregistered in Soft and Off modes to save battery.
    final active = LikedinAppearance.glintEnabled.value &&
        !LikedinAppearance.reduceMotion.value &&
        LikedinAppearance.effects.value != LikedinEffects.off &&
        LikedinAppearance.effects.value != LikedinEffects.soft;
    if (!active) {
      stop();
      return;
    }
    if (_sub != null) return;
    try {
      _sub = _channel.receiveBroadcastStream().listen(
        (dynamic event) {
          if (event is List && event.length >= 2) {
            final dx = ((event[0] as num).toDouble()).clamp(-1.0, 1.0);
            final dy = ((event[1] as num).toDouble()).clamp(-1.0, 1.0);
            tilt.value = Offset(dx, dy);
          }
        },
        onError: (Object _) {
          // Non-Android / emulator / test environments gracefully stay static.
          stop();
        },
        cancelOnError: true,
      );
    } catch (_) {
      stop();
    }
  }

  static void stop() {
    _sub?.cancel();
    _sub = null;
    if (tilt.value != Offset.zero) {
      tilt.value = Offset.zero;
    }
  }
}

/// Persisted OriginOS 7 appearance preferences shared by every screen.
class LikedinAppearance {
  LikedinAppearance._();

  static const _themeKey = 'likedin_theme_preset_v2';
  static const _legacyChatWallpaperKey = 'likedin_chat_wallpaper_preset_v1';
  static const _accentKey = 'likedin_accent_index_v1';
  static const _effectsKeyV2 = 'likedin_origin_texture_v2';
  static const _legacyEffectsKey = 'likedin_effects_level_v1';
  static const _glintKey = 'likedin_origin_glint_v1';
  static const _motionKey = 'likedin_reduce_motion_v1';
  static const _textScaleKey = 'likedin_text_scale_v1';

  static const double minTextScale = 0.85;
  static const double maxTextScale = 1.20;

  static final ValueNotifier<int> themeIndex = ValueNotifier<int>(0);
  static final ValueNotifier<int> accentIndex = ValueNotifier<int>(0);
  // Default all effects to minimum level (Soft glass, Glint off, 30% motion);
  // users can enable Natural/Real glass, Glint, or higher liquid stretch anytime.
  static final ValueNotifier<LikedinEffects> effects =
      ValueNotifier<LikedinEffects>(LikedinEffects.soft);
  static final ValueNotifier<bool> glintEnabled = ValueNotifier<bool>(false);
  static final ValueNotifier<bool> reduceMotion = ValueNotifier<bool>(false);
  /// Independent in-app text scale (default 1.0x) so Likedin never gets
  /// distorted by Android's system font size or display zoom settings.
  static final ValueNotifier<double> textScale = ValueNotifier<double>(1.0);
  static bool isLowRamDevice = false;

  /// Rebuilds the MaterialApp when any appearance value changes.
  static final Listenable listenable = Listenable.merge([
    themeIndex,
    accentIndex,
    effects,
    glintEnabled,
    reduceMotion,
    textScale,
  ]);

  static LikedinThemePreset get theme =>
      likedinThemePresets[themeIndex.value.clamp(0, likedinThemePresets.length - 1).toInt()];

  static LikedinAccent get accent =>
      likedinAccents[accentIndex.value.clamp(0, likedinAccents.length - 1).toInt()];

  static String get textureLabel => switch (effects.value) {
        LikedinEffects.real => 'Real',
        LikedinEffects.natural => 'Natural',
        LikedinEffects.soft => 'Soft',
        LikedinEffects.off => 'Off',
      };

  static String get textScaleLabel {
    final s = textScale.value;
    if (s <= 0.91) return 'Compact (${(s * 100).round()}%)';
    if (s <= 1.04) return 'Standard (${(s * 100).round()}%)';
    if (s <= 1.14) return 'Large (${(s * 100).round()}%)';
    return 'Extra Large (${(s * 100).round()}%)';
  }

  static Future<void> load([
    SharedPreferences? preferences,
    bool lowRamDevice = false,
  ]) async {
    isLowRamDevice = lowRamDevice;
    try {
      final prefs = preferences ?? await SharedPreferences.getInstance();
      final savedTheme = prefs.getInt(_themeKey) ?? prefs.getInt(_legacyChatWallpaperKey) ?? 0;
      themeIndex.value = savedTheme.clamp(0, likedinThemePresets.length - 1).toInt();
      final a = prefs.getInt(_accentKey) ?? 0;
      accentIndex.value = a.clamp(0, likedinAccents.length - 1).toInt();

      final savedV2 = prefs.getInt(_effectsKeyV2);
      if (savedV2 != null) {
        effects.value = LikedinEffects.values[savedV2.clamp(0, LikedinEffects.values.length - 1).toInt()];
      } else {
        final legacy = prefs.getInt(_legacyEffectsKey);
        if (legacy != null) {
          effects.value = switch (legacy) {
            0 => lowRamDevice ? LikedinEffects.natural : LikedinEffects.real,
            1 => LikedinEffects.natural,
            _ => LikedinEffects.off,
          };
        } else {
          // Default to minimum glass level (Soft) across all devices.
          effects.value = LikedinEffects.soft;
        }
      }

      reduceMotion.value = prefs.getBool(_motionKey) ?? false;
      final savedScale = prefs.getDouble(_textScaleKey) ?? 1.0;
      textScale.value = savedScale.clamp(minTextScale, maxTextScale).toDouble();
      final savedGlint = prefs.getBool(_glintKey);
      glintEnabled.value = savedGlint ?? false;
      await OriginMotionEngine.load(
        preferences: prefs,
        lowRamDevice: lowRamDevice,
        reducedMotion: reduceMotion.value,
      );
      OriginGlintController.sync();
    } catch (_) {
      // Defaults are fine if preferences are unavailable.
    }
  }

  /// Sets the app-wide theme preset and optionally syncs its harmonious accent.
  static Future<void> setTheme(int index, {bool syncAccent = true}) async {
    final clamped = index.clamp(0, likedinThemePresets.length - 1).toInt();
    themeIndex.value = clamped;
    if (syncAccent) {
      final recommended = likedinThemePresets[clamped]
          .defaultAccentIndex
          .clamp(0, likedinAccents.length - 1)
          .toInt();
      accentIndex.value = recommended;
    }
    await _save((p) async {
      await p.setInt(_themeKey, clamped);
      if (syncAccent) await p.setInt(_accentKey, accentIndex.value);
    });
  }

  static Future<void> setAccent(int index) async {
    accentIndex.value = index.clamp(0, likedinAccents.length - 1).toInt();
    await _save((p) => p.setInt(_accentKey, accentIndex.value));
  }

  static Future<void> setEffects(LikedinEffects value) async {
    effects.value = value;
    OriginGlintController.sync();
    await _save((p) => p.setInt(_effectsKeyV2, value.index));
  }

  static Future<void> setGlintEnabled(bool value) async {
    glintEnabled.value = value;
    OriginGlintController.sync();
    await _save((p) => p.setBool(_glintKey, value));
  }

  static Future<void> setReduceMotion(bool value) async {
    reduceMotion.value = value;
    OriginMotionEngine.reduceMotion.value = value;
    OriginGlintController.sync();
    await _save((p) => p.setBool(_motionKey, value));
  }

  static Future<void> setTextScale(double value) async {
    final clamped = value.clamp(minTextScale, maxTextScale).toDouble();
    textScale.value = clamped;
    await _save((p) => p.setDouble(_textScaleKey, clamped));
  }

  static Future<void> reset() async {
    themeIndex.value = 0;
    accentIndex.value = 0;
    effects.value = LikedinEffects.soft;
    glintEnabled.value = false;
    reduceMotion.value = false;
    OriginMotionEngine.reduceMotion.value = false;
    textScale.value = 1.0;
    await OriginMotionEngine.reset();
    OriginGlintController.sync();
    await _save((p) async {
      await p.remove(_themeKey);
      await p.remove(_legacyChatWallpaperKey);
      await p.remove(_accentKey);
      await p.remove(_effectsKeyV2);
      await p.remove(_legacyEffectsKey);
      await p.remove(_glintKey);
      await p.remove(_motionKey);
      await p.remove(_textScaleKey);
    });
  }

  static Future<void> _save(Future<void> Function(SharedPreferences) write) async {
    try {
      await write(await SharedPreferences.getInstance());
    } catch (_) {}
  }

  /// True when animations should be skipped or shortened.
  static bool motionReduced(BuildContext context) =>
      reduceMotion.value || MediaQuery.of(context).disableAnimations;
}

// ---- Theme-aware Palette ---------------------------------------------------

Color likedinBackground(Brightness brightness) {
  final t = LikedinAppearance.theme;
  return brightness == Brightness.dark ? t.darkBgBottom : t.lightBgBottom;
}

Color likedinBackgroundTop(Brightness brightness) {
  final t = LikedinAppearance.theme;
  return brightness == Brightness.dark ? t.darkBgTop : t.lightBgTop;
}

Color likedinSurface(Brightness brightness) {
  final t = LikedinAppearance.theme;
  return brightness == Brightness.dark ? t.darkSurface : t.lightSurface;
}

Color likedinSurfaceRaised(Brightness brightness) {
  final t = LikedinAppearance.theme;
  return brightness == Brightness.dark ? t.darkSurfaceRaised : t.lightSurfaceRaised;
}

Color likedinOutline(Brightness brightness) {
  final t = LikedinAppearance.theme;
  return brightness == Brightness.dark ? t.darkOutline : t.lightOutline;
}

Color likedinOnSurface(Brightness brightness) => brightness == Brightness.dark
    ? const Color(0xFFEAF0FF)
    : const Color(0xFF0C1A33);

Color likedinMutedText(Brightness brightness) => brightness == Brightness.dark
    ? const Color(0xFFA8B5CF)
    : const Color(0xFF51617F);

Color likedinPrimary(Brightness brightness) =>
    LikedinAppearance.accent.forBrightness(brightness);

/// Darkens [color] just enough that white text on it reaches [minContrast].
Color likedinEnsureWhiteContrast(Color color, {double minContrast = 4.5}) {
  var result = color;
  for (var i = 0; i < 24; i++) {
    final ratio = 1.05 / (result.computeLuminance() + .05);
    if (ratio >= minContrast) return result;
    result = Color.lerp(result, const Color(0xFF000000), .06)!;
  }
  return result;
}

/// Primary accent gradient for action buttons.
LinearGradient likedinPrimaryGradient(Brightness brightness) {
  final accent = LikedinAppearance.accent;
  final dark = brightness == Brightness.dark;
  final start = likedinEnsureWhiteContrast(
    dark ? Color.lerp(accent.dark, const Color(0xFF1D4ED8), .35)! : accent.light,
  );
  final end = likedinEnsureWhiteContrast(
    dark ? accent.gradientEnd : Color.lerp(accent.light, accent.gradientEnd, .55)!,
  );
  return LinearGradient(
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
    colors: [start, end],
  );
}

/// Outgoing chat-bubble fill harmonized with the active theme and accent.
Color likedinOutgoingBubble(Brightness brightness) {
  final accent = likedinPrimary(brightness);
  return brightness == Brightness.dark
      ? Color.alphaBlend(accent.withValues(alpha: .30), likedinSurface(brightness))
      : Color.alphaBlend(accent.withValues(alpha: .16), Colors.white);
}

/// Incoming chat-bubble fill harmonized with the active theme.
Color likedinIncomingBubble(Brightness brightness) =>
    brightness == Brightness.dark
        ? likedinSurface(brightness).withValues(alpha: .58)
        : Colors.white.withValues(alpha: .78);

// ---- OriginOS 7 Glass Optical Painters (Real / Natural / Soft + Glint) -----

final Map<int, ImageFilter> _blurFilterCache = <int, ImageFilter>{};

ImageFilter _cachedBlurFilter(double sigma) {
  final key = (sigma * 10).round();
  return _blurFilterCache.putIfAbsent(
    key,
    () => ImageFilter.blur(
      sigmaX: key / 10.0,
      sigmaY: key / 10.0,
      tileMode: TileMode.mirror,
    ),
  );
}

/// Unified single-pass OriginOS 7 glass fill & optical reflection painter
/// rendered BEHIND the child widget.
///  - Soft mode is preserved verbatim (calm satin low-glare optics).
///  - Real mode paints the translucent glass body, an elliptical curved top
///    meniscus highlight, and a radial bottom caustic bounce in ONE GPU pass
///    (eliminating double ClipRRect / redundant DecoratedBox layers).
class _LiquidGlassFillPainter extends CustomPainter {
  const _LiquidGlassFillPainter({
    required this.radius,
    required this.baseColor,
    required this.dark,
    required this.accent,
    required this.accentEnd,
    required this.texture,
    required this.isFrosted,
  });

  final BorderRadius radius;
  final Color baseColor;
  final bool dark;
  final Color accent;
  final Color accentEnd;
  final LikedinEffects texture;
  final bool isFrosted;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final rect = Offset.zero & size;
    final rrect = radius.toRRect(rect);

    final isReal = texture == LikedinEffects.real;
    final isSoft = texture == LikedinEffects.soft;

    // 0. Translucent glass body fill
    canvas.drawRRect(rrect, Paint()..color = baseColor);

    canvas.save();
    canvas.clipRRect(rrect);

    final whiteZero = Colors.white.withValues(alpha: 0.0);

    if (isReal) {
      // REAL (真实 — Immersive & Translucent): crystal-clear liquid glass with
      // curved upper specular meniscus, inner edge lens refraction glow, and
      // luminous bottom caustic bounce matching Vivo OriginOS 7 liquid glass.
      final sheenHeight = math.min(size.height * 0.46, 52.0);
      final topSheenRect = Rect.fromLTWH(0, 0, size.width, sheenHeight);
      final double topAlpha = dark
          ? (isFrosted ? .26 : .16)
          : (isFrosted ? .68 : .52);
      final topPaint = Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          stops: const [0.0, 0.34, 1.0],
          colors: [
            Colors.white.withValues(alpha: topAlpha),
            Colors.white.withValues(alpha: topAlpha * 0.28),
            whiteZero,
          ],
        ).createShader(topSheenRect);
      canvas.drawRect(topSheenRect, topPaint);

      // Curved lens catchlight arc along upper-left bevel
      final catchRect = Rect.fromLTWH(
        -size.width * 0.10,
        -sheenHeight * 0.62,
        size.width * 0.88,
        sheenHeight * 1.40,
      );
      final catchPaint = Paint()
        ..shader = RadialGradient(
          center: const Alignment(-0.35, -0.18),
          radius: 0.88,
          colors: [
            Colors.white.withValues(alpha: dark ? .16 : .38),
            whiteZero,
          ],
        ).createShader(catchRect);
      canvas.drawOval(catchRect, catchPaint);

      // Curved inner optical refraction bounce at the lower rim (the signature
      // thick-glass caustic crescent in OriginOS 7 Realistic mode!)
      final bounceH = math.min(size.height * 0.44, 42.0);
      final causticRect = Rect.fromLTWH(
        -size.width * 0.08,
        size.height - bounceH * 0.82,
        size.width * 1.16,
        bounceH * 1.25,
      );
      final causticColor = Color.lerp(Colors.white, Color.lerp(accent, accentEnd, 0.4)!, dark ? 0.45 : 0.25)!;
      final causticPaint = Paint()
        ..shader = RadialGradient(
          center: const Alignment(0.18, 0.95),
          radius: 0.92,
          stops: const [0.0, 0.55, 1.0],
          colors: [
            causticColor.withValues(alpha: dark ? (isFrosted ? .34 : .20) : (isFrosted ? .56 : .34)),
            accent.withValues(alpha: dark ? (isFrosted ? .14 : .08) : .12),
            causticColor.withValues(alpha: 0.0),
          ],
        ).createShader(causticRect);
      canvas.drawOval(causticRect, causticPaint);
    } else if (!isSoft) {
      // NATURAL (自然 — Comfortable & Balanced): smooth medium frosted sheen
      // with gentle top highlight and balanced ambient color diffusion.
      final sheenHeight = math.min(size.height * 0.44, 46.0);
      final topSheenRect = Rect.fromLTWH(0, 0, size.width, sheenHeight);
      final double topAlpha = dark
          ? (isFrosted ? .14 : .10)
          : (isFrosted ? .46 : .36);
      final topSheenPaint = Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          stops: const [0.0, 0.45, 1.0],
          colors: [
            Colors.white.withValues(alpha: topAlpha),
            Colors.white.withValues(alpha: topAlpha * 0.30),
            whiteZero,
          ],
        ).createShader(topSheenRect);
      canvas.drawRect(topSheenRect, topSheenPaint);

      final bounceHeight = math.min(size.height * 0.34, 34.0);
      final bottomBounceRect = Rect.fromLTWH(
        0,
        size.height - bounceHeight,
        size.width,
        bounceHeight,
      );
      final bouncePaint = Paint()
        ..shader = LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [
            Color.lerp(Colors.white, accent, 0.55)!.withValues(alpha: dark ? .11 : .14),
            accent.withValues(alpha: 0.0),
          ],
        ).createShader(bottomBounceRect);
      canvas.drawRect(bottomBounceRect, bouncePaint);
    } else {
      // SOFT (柔和 — Clear & Readable): calm satin frost with diffused glare
      // reduction so white and dark typography stay ultra-legible.
      final sheenHeight = math.min(size.height * 0.38, 34.0);
      final topSheenRect = Rect.fromLTWH(0, 0, size.width, sheenHeight);
      final double topAlpha = dark ? .07 : .28;
      final topSheenPaint = Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          stops: const [0.0, 0.50, 1.0],
          colors: [
            Colors.white.withValues(alpha: topAlpha),
            Colors.white.withValues(alpha: topAlpha * 0.30),
            whiteZero,
          ],
        ).createShader(topSheenRect);
      canvas.drawRect(topSheenRect, topSheenPaint);
    }

    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _LiquidGlassFillPainter old) =>
      old.radius != radius ||
      old.baseColor != baseColor ||
      old.dark != dark ||
      old.accent != accent ||
      old.accentEnd != accentEnd ||
      old.texture != texture ||
      old.isFrosted != isFrosted;
}

/// Paints the directional OriginOS 7 perimeter rim.
///  - Soft mode is preserved verbatim.
///  - Real mode adds prismatic bevel dispersion + a razor-thin inner specular
///    bevel + zero-blur luminous glow contour (fast & richer than BlurStyle.outer!).
class _LiquidGlassRimPainter extends CustomPainter {
  const _LiquidGlassRimPainter({
    required this.radius,
    required this.dark,
    required this.accent,
    required this.accentEnd,
    required this.texture,
    required this.profile,
    required this.lightDir,
    required this.isFrosted,
    required this.glow,
  });

  final BorderRadius radius;
  final bool dark;
  final Color accent;
  final Color accentEnd;
  final LikedinEffects texture;
  final OriginGlassMaterialProfile profile;
  final Offset lightDir;
  final bool isFrosted;
  final bool glow;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final rect = Offset.zero & size;
    final rrect = radius.toRRect(rect);

    final isReal = texture == LikedinEffects.real;
    final isSoft = texture == LikedinEffects.soft;
    final strokeWidth = profile.outerRimWidth;
    final rimRRect = rrect.deflate(strokeWidth * 0.5);

    final lightBegin = Alignment(lightDir.dx, lightDir.dy);
    final lightEnd = Alignment(-lightDir.dx, -lightDir.dy);
    final topAlign = OriginOpticalLightModel.directionalResponse(
      const Offset(0.0, -1.0),
      lightDir,
    );
    final fresnelEdge = OriginOpticalLightModel.fresnelReflection(0.18, profile.fresnelF0);
    final specMult = (0.65 + 0.35 * topAlign) * profile.specularStrength;
    final prismMid = Color.lerp(accent, accentEnd, 0.5)!;
    final bottomCaustic = Color.lerp(Colors.white, accent, dark ? .42 : .24)!;

    final rimPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..shader = LinearGradient(
        begin: lightBegin,
        end: lightEnd,
        stops: const [0.0, 0.20, 0.48, 0.78, 1.0],
        colors: dark
            ? [
                Colors.white.withValues(alpha: (fresnelEdge * (isFrosted ? 1.15 : 0.85) * specMult).clamp(0.08, 0.78)),
                prismMid.withValues(alpha: (profile.edgeIntensity * (isReal ? 0.30 : 0.14)).clamp(0.02, 0.34)),
                Colors.white.withValues(alpha: isSoft ? 0.03 : 0.06),
                accent.withValues(alpha: (profile.causticStrength * 0.28).clamp(0.02, 0.24)),
                bottomCaustic.withValues(alpha: (profile.causticStrength * (isFrosted ? 0.65 : 0.45)).clamp(0.06, 0.52)),
              ]
            : [
                Colors.white.withValues(alpha: (0.62 + 0.36 * specMult).clamp(0.55, 0.98)),
                Colors.white.withValues(alpha: (0.28 + 0.38 * profile.edgeIntensity).clamp(0.20, 0.68)),
                const Color(0xFF0C1A33).withValues(alpha: isSoft ? 0.05 : 0.09),
                prismMid.withValues(alpha: (profile.causticStrength * 0.32).clamp(0.04, 0.28)),
                bottomCaustic.withValues(alpha: (0.34 + 0.48 * profile.causticStrength).clamp(0.30, 0.86)),
              ],
      ).createShader(rect);
    canvas.drawRRect(rimRRect, rimPaint);

    if (profile.innerContourAlpha > 0.08) {
      final innerInset = isReal ? (strokeWidth + 1.1) : (strokeWidth + 0.7);
      final innerBevel = rrect.deflate(innerInset);
      final innerPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = isReal ? 0.85 : 0.6
        ..shader = LinearGradient(
          begin: lightBegin,
          end: lightEnd,
          stops: const [0.0, 0.34, 0.72, 1.0],
          colors: [
            Colors.white.withValues(
              alpha: (profile.innerContourAlpha * (dark ? (isFrosted ? 0.52 : 0.34) : 0.92)).clamp(0.0, 0.75),
            ),
            Colors.white.withValues(alpha: 0.0),
            Colors.white.withValues(alpha: 0.0),
            bottomCaustic.withValues(
              alpha: (profile.causticStrength * (dark ? 0.28 : 0.38)).clamp(0.0, 0.34),
            ),
          ],
        ).createShader(rect);
      canvas.drawRRect(innerBevel, innerPaint);
    }

    if (glow && !isSoft) {
      final auraPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = isReal ? 2.0 : 1.4
        ..shader = LinearGradient(
          begin: lightBegin,
          end: lightEnd,
          colors: [
            accent.withValues(alpha: (dark ? 0.24 : 0.16) * profile.edgeIntensity),
            accentEnd.withValues(alpha: (dark ? 0.18 : 0.12) * profile.edgeIntensity),
          ],
        ).createShader(rect);
      canvas.drawRRect(rrect.deflate(1.0), auraPaint);
    }

    final outerHairlineAlpha = dark
        ? (isReal ? 0.16 : (isSoft ? 0.06 : 0.10))
        : (isReal ? 0.11 : (isSoft ? 0.05 : 0.08));
    final hairline = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.6
      ..color = (dark ? Colors.black : const Color(0xFF0C1A33))
          .withValues(alpha: outerHairlineAlpha);
    canvas.drawRRect(rrect.deflate(0.3), hairline);
  }

  @override
  bool shouldRepaint(covariant _LiquidGlassRimPainter old) =>
      old.radius != radius ||
      old.dark != dark ||
      old.accent != accent ||
      old.accentEnd != accentEnd ||
      old.texture != texture ||
      old.profile != profile ||
      old.lightDir != lightDir ||
      old.isFrosted != isFrosted ||
      old.glow != glow;
}

/// Zero-rebuild angle-responsive OriginOS 7 dual-band prismatic Glint Light
/// painter driven directly via `CustomPainter(repaint: tiltListenable)` inside
/// an isolated RepaintBoundary.
class _OriginGlintPainter extends CustomPainter {
  _OriginGlintPainter({
    required this.radius,
    required this.tiltListenable,
    required this.dark,
    required this.accent,
    required this.accentEnd,
    required this.isReal,
  }) : super(repaint: tiltListenable);

  final BorderRadius radius;
  final ValueListenable<Offset> tiltListenable;
  final bool dark;
  final Color accent;
  final Color accentEnd;
  final bool isReal;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final rect = Offset.zero & size;
    final rrect = radius.toRRect(rect);
    final tilt = tiltListenable.value;

    final shiftX = tilt.dx * 0.95;
    final shiftY = tilt.dy * 0.55;
    final mult = isReal ? 1.18 : 0.85;
    final beam = Paint()
      ..shader = LinearGradient(
        begin: Alignment(-1.15 + shiftX, -1.0 + shiftY),
        end: Alignment(1.15 + shiftX, 1.0 + shiftY),
        stops: const [0.0, 0.30, 0.45, 0.54, 0.70, 1.0],
        colors: dark
            ? [
                accent.withValues(alpha: 0.0),
                accent.withValues(alpha: (.10 * mult).clamp(0.0, 1.0)),
                Colors.white.withValues(alpha: (.18 * mult).clamp(0.0, 1.0)),
                accentEnd.withValues(alpha: (.14 * mult).clamp(0.0, 1.0)),
                accent.withValues(alpha: (.06 * mult).clamp(0.0, 1.0)),
                accentEnd.withValues(alpha: 0.0),
              ]
            : [
                accent.withValues(alpha: 0.0),
                accent.withValues(alpha: (.09 * mult).clamp(0.0, 1.0)),
                Colors.white.withValues(alpha: (.44 * mult).clamp(0.0, 1.0)),
                accentEnd.withValues(alpha: (.13 * mult).clamp(0.0, 1.0)),
                accent.withValues(alpha: (.05 * mult).clamp(0.0, 1.0)),
                accentEnd.withValues(alpha: 0.0),
              ],
      ).createShader(rect);

    canvas.save();
    canvas.clipRRect(rrect);
    canvas.drawRect(rect, beam);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _OriginGlintPainter old) =>
      old.radius != radius ||
      old.tiltListenable != tiltListenable ||
      old.dark != dark ||
      old.accent != accent ||
      old.accentEnd != accentEnd ||
      old.isReal != isReal;
}

// ---- Surfaces --------------------------------------------------------------

/// OriginOS 7 Dynamic Translucent Glass surface supporting Real / Natural /
/// Soft / Off textures, adaptive light-and-shadow contrast, and optional
/// tilt-responsive [glint] iridescence on hero cards.
class GlassPanel extends StatelessWidget {
  const GlassPanel({
    required this.child,
    this.padding = EdgeInsets.zero,
    this.radius = const BorderRadius.all(Radius.circular(24)),
    this.blur = 0,
    this.tint,
    this.glow = false,
    this.frosted = false,
    this.elevatedSheet = false,
    this.glint = false,
    this.effectsOverride,
    this.lowRamOverride,
    this.reduceMotionOverride,
    super.key,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final BorderRadius radius;
  final double blur;
  final Color? tint;
  final bool glow;
  final bool frosted;
  final bool elevatedSheet;
  final bool glint;
  final LikedinEffects? effectsOverride;
  final bool? lowRamOverride;
  final bool? reduceMotionOverride;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    final systemReduceMotion = MediaQuery.disableAnimationsOf(context);
    final dpr = MediaQuery.devicePixelRatioOf(context);

    return ListenableBuilder(
      listenable: Listenable.merge(<Listenable>[
        LikedinAppearance.listenable,
        OriginGlassShaderEngine.readyRevision,
      ]),
      child: Padding(padding: padding, child: child),
      builder: (context, builtChild) {
        final texture = effectsOverride ?? LikedinAppearance.effects.value;
        final base = tint ?? likedinSurface(brightness);
        final fancy = texture != LikedinEffects.off;
        final isReal = texture == LikedinEffects.real;
        final isSoft = texture == LikedinEffects.soft;
        final primary = likedinPrimary(brightness);
        final endAccent = LikedinAppearance.accent.gradientEnd;

        final reduceMotion = reduceMotionOverride ??
            (LikedinAppearance.reduceMotion.value || systemReduceMotion);
        final lowRam = lowRamOverride ?? LikedinAppearance.isLowRamDevice;

        final profile = OriginGlassMaterialProfile.resolve(
          tierName: texture.name,
          lowRamDevice: lowRam,
          reduceMotion: reduceMotion,
          elevatedSheet: elevatedSheet,
        );

        final shaderActive = frosted &&
            fancy &&
            profile.usesShaderRefraction &&
            OriginGlassShaderEngine.isReady;
        final useFallbackBlur = frosted &&
            fancy &&
            !shaderActive &&
            !reduceMotion &&
            profile.fallbackBlurSigma > 0.1;

        final fillAlpha = !fancy
            ? 1.0
            : frosted
                ? (dark ? profile.frostedTintAlphaDark : profile.frostedTintAlphaLight)
                : (dark ? profile.cardTintAlphaDark : profile.cardTintAlphaLight);

        final paintFillAlpha = shaderActive ? (fillAlpha * 0.28) : fillAlpha;
        final baseColor = base.withValues(alpha: paintFillAlpha);
        final shaderTintColor = base.withValues(alpha: fillAlpha);
        final lightDir = OriginOpticalLightModel.defaultLightDir;

        Widget surface;
        if (!fancy) {
          surface = DecoratedBox(
            decoration: BoxDecoration(
              color: base.withValues(alpha: 1.0),
              borderRadius: radius,
              border: Border.all(color: likedinOutline(brightness), width: 1),
            ),
            child: builtChild,
          );
        } else {
          surface = CustomPaint(
            painter: _LiquidGlassFillPainter(
              radius: radius,
              baseColor: baseColor,
              dark: dark,
              accent: primary,
              accentEnd: endAccent,
              texture: texture,
              isFrosted: frosted,
            ),
            foregroundPainter: _LiquidGlassRimPainter(
              radius: radius,
              dark: dark,
              accent: primary,
              accentEnd: endAccent,
              texture: texture,
              profile: profile,
              lightDir: lightDir,
              isFrosted: frosted,
              glow: glow,
            ),
            child: builtChild,
          );
        }

        if (glint &&
            fancy &&
            !isSoft &&
            LikedinAppearance.glintEnabled.value &&
            !reduceMotion) {
          surface = RepaintBoundary(
            child: CustomPaint(
              painter: _OriginGlintPainter(
                radius: radius,
                tiltListenable: OriginGlintController.tilt,
                dark: dark,
                accent: primary,
                accentEnd: endAccent,
                isReal: isReal,
              ),
              child: surface,
            ),
          );
        }

        if (shaderActive) {
          return ClipRRect(
            borderRadius: radius,
            child: OriginRefractiveBackdrop(
              profile: profile,
              radius: radius,
              tintColor: shaderTintColor,
              accentColor: primary,
              dark: dark,
              lightDir: lightDir,
              devicePixelRatio: dpr,
              child: surface,
            ),
          );
        }

        if (useFallbackBlur) {
          final targetSigma = blur > 0 && isReal
              ? blur.clamp(2.5, 5.2).toDouble()
              : profile.fallbackBlurSigma;
          return RepaintBoundary(
            child: ClipRRect(
              borderRadius: radius,
              child: BackdropFilter.grouped(
                filter: _cachedBlurFilter(targetSigma),
                child: surface,
              ),
            ),
          );
        }

        if (radius == BorderRadius.zero) {
          return isReal ? RepaintBoundary(child: surface) : surface;
        }
        final clipped = ClipRRect(borderRadius: radius, child: surface);
        return isReal ? RepaintBoundary(child: clipped) : clipped;
      },
    );
  }
}

/// GPU-native single-draw-call OriginOS 7 chat bubble.
/// Zero ClipRRect, zero CustomPaint shaders — locked at 90/120fps on 3 GB RAM.
class LiquidGlassBubble extends StatelessWidget {
  const LiquidGlassBubble({
    required this.child,
    required this.outgoing,
    required this.borderRadius,
    this.margin = EdgeInsets.zero,
    this.padding = const EdgeInsets.fromLTRB(14, 10, 14, 8),
    this.maxWidth = 310,
    this.highContrast = false,
    super.key,
  });

  final Widget child;
  final bool outgoing;
  final BorderRadius borderRadius;
  final EdgeInsetsGeometry margin;
  final EdgeInsetsGeometry padding;
  final double maxWidth;
  /// Boosts bubble fill opacity & rim separation over bright/busy custom photo wallpapers.
  final bool highContrast;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    final texture = LikedinAppearance.effects.value;
    final fancy = texture != LikedinEffects.off;
    final isSoft = texture == LikedinEffects.soft;
    final primary = likedinPrimary(brightness);

    final baseFill = outgoing
        ? likedinOutgoingBubble(brightness)
        : (fancy ? likedinIncomingBubble(brightness) : likedinSurface(brightness));

    final sheenStrength = isSoft ? 0.45 : 1.0;
    final topTint = dark
        ? Color.alphaBlend(
            Colors.white.withValues(alpha: (outgoing ? .10 : .07) * sheenStrength),
            baseFill,
          )
        : Color.alphaBlend(
            Colors.white.withValues(alpha: (outgoing ? .32 : .52) * sheenStrength),
            baseFill,
          );

    final borderColor = !fancy
        ? (outgoing ? primary.withValues(alpha: .45) : likedinOutline(brightness))
        : outgoing
            ? primary.withValues(alpha: dark ? (isSoft ? .34 : .52) : (isSoft ? .26 : .38))
            : (dark
                ? Colors.white.withValues(alpha: isSoft ? .10 : .16)
                : Colors.white.withValues(alpha: isSoft ? .78 : .94));

    final double topAlpha = highContrast
        ? (dark ? (outgoing ? .93 : .88) : (outgoing ? .96 : .95))
        : isSoft
            ? (dark ? (outgoing ? .90 : .80) : (outgoing ? .94 : .92))
            : (dark ? (outgoing ? .84 : .64) : (outgoing ? .90 : .86));
    final double botAlpha = highContrast
        ? (dark ? (outgoing ? .88 : .82) : (outgoing ? .93 : .92))
        : isSoft
            ? (dark ? (outgoing ? .84 : .74) : (outgoing ? .90 : .88))
            : (dark ? (outgoing ? .76 : .54) : (outgoing ? .84 : .78));

    return Padding(
      padding: margin,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: maxWidth),
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: fancy ? null : baseFill,
            gradient: fancy
                ? LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      topTint.withValues(alpha: topAlpha),
                      baseFill.withValues(alpha: botAlpha),
                    ],
                  )
                : null,
            borderRadius: borderRadius,
            border: Border.all(color: borderColor, width: 1.0),
          ),
          child: Padding(padding: padding, child: child),
        ),
      ),
    );
  }
}

class _OriginAuroraPainter extends CustomPainter {
  const _OriginAuroraPainter({
    required this.bgColors,
    required this.showOrbs,
    required this.dark,
    required this.orb1,
    required this.orb2,
    required this.orb3,
    required this.orbMult,
  });

  final List<Color> bgColors;
  final bool showOrbs;
  final bool dark;
  final Color orb1;
  final Color orb2;
  final Color orb3;
  final double orbMult;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          stops: const [0.0, 0.52, 1.0],
          colors: bgColors,
        ).createShader(rect),
    );
    if (!showOrbs) return;

    final maxDim = math.max(size.width, size.height);
    void drawOrb(Alignment center, double radiusFactor, Color color, double alpha) {
      final c = center.alongSize(size);
      final r = maxDim * radiusFactor;
      canvas.drawCircle(
        c,
        r,
        Paint()
          ..shader = RadialGradient(
            colors: [
              color.withValues(alpha: alpha),
              color.withValues(alpha: 0.0),
            ],
          ).createShader(Rect.fromCircle(center: c, radius: r)),
      );
    }

    drawOrb(const Alignment(-0.82, -0.88), 0.68, orb1, (dark ? .34 : .26) * orbMult);
    drawOrb(const Alignment(0.92, 0.82), 0.64, orb2, (dark ? .26 : .22) * orbMult);
    drawOrb(const Alignment(0.78, -0.16), 0.52, orb3, (dark ? .20 : .16) * orbMult);
  }

  @override
  bool shouldRepaint(covariant _OriginAuroraPainter old) =>
      old.showOrbs != showOrbs ||
      old.dark != dark ||
      old.orb1 != orb1 ||
      old.orb2 != orb2 ||
      old.orb3 != orb3 ||
      old.orbMult != orbMult ||
      old.bgColors[0] != bgColors[0] ||
      old.bgColors[2] != bgColors[2];
}

/// Unified app-wide OriginOS 7 ambient backdrop with single-pass GPU-cached
/// aurora orbs and subtle day/night lighting modulation.
class AuroraBackdrop extends StatelessWidget {
  const AuroraBackdrop({required this.child, super.key});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    final hour = DateTime.now().hour;
    final isNightHour = hour < 6 || hour >= 20;
    final orbIntensity = isNightHour ? 0.84 : 1.0;

    return ListenableBuilder(
      listenable: LikedinAppearance.listenable,
      child: child,
      builder: (context, builtChild) {
        final texture = LikedinAppearance.effects.value;
        final theme = LikedinAppearance.theme;
        final orb1 = dark ? theme.darkOrb1 : theme.lightOrb1;
        final orb2 = dark ? theme.darkOrb2 : theme.lightOrb2;
        final orb3 = dark ? theme.darkOrb3 : theme.lightOrb3;
        final bgColors = dark
            ? [theme.darkBgTop, theme.darkBgMid, theme.darkBgBottom]
            : [theme.lightBgTop, theme.lightBgMid, theme.lightBgBottom];
        final showOrbs = texture == LikedinEffects.real || texture == LikedinEffects.natural;
        final orbMult = (texture == LikedinEffects.natural ? 0.82 : 1.0) * orbIntensity;

        return Stack(
          fit: StackFit.expand,
          children: [
            if (texture == LikedinEffects.off)
              ColoredBox(color: likedinBackground(brightness))
            else
              RepaintBoundary(
                child: CustomPaint(
                  isComplex: true,
                  willChange: false,
                  painter: _OriginAuroraPainter(
                    bgColors: bgColors,
                    showOrbs: showOrbs,
                    dark: dark,
                    orb1: orb1,
                    orb2: orb2,
                    orb3: orb3,
                    orbMult: orbMult,
                  ),
                ),
              ),
            if (builtChild != null) builtChild,
          ],
        );
      },
    );
  }
}

// ---- OriginOS 7 Fluid Motion 3 Physics Engine ------------------------------

/// Unified spring constants & elastic curves shared across the entire app
/// (dock, page transitions, floating PiP, swipe-to-reply, Origin Island).
class OriginPhysics {
  OriginPhysics._();

  static SpringDescription get dockSpring => OriginMotionPresets.dock.description;
  static SpringDescription get pageSpring => OriginMotionPresets.page.description;
  static SpringDescription get swipeReplySpring => OriginMotionPresets.swipeReply.description;
  static SpringDescription get floatingWindowSpring => OriginMotionPresets.floatingWindow.description;
  static SpringDescription get generalSpring => OriginMotionPresets.general.description;
  static SpringDescription get softSpring => OriginMotionPresets.soft.description;
  static SpringDescription get elasticSpring => OriginMotionPresets.elastic.description;

  /// Smooth hyperbolic rubber-band resistance delegated to [OriginSpringPhysics].
  static double rubberBand(double overscroll, double limit) =>
      OriginSpringPhysics.rubberBand(overscroll, limit);
}

/// Custom OriginOS 7 Fluid Motion scroll physics backed by [OriginElasticScrollPhysics].
class OriginSpringScrollPhysics extends OriginElasticScrollPhysics {
  const OriginSpringScrollPhysics({super.parent});

  @override
  OriginSpringScrollPhysics applyTo(ScrollPhysics? ancestor) =>
      OriginSpringScrollPhysics(parent: buildParent(ancestor));
}

/// App-wide ScrollBehavior applying OriginOS 7 Fluid Motion spring physics to
/// every scrollable view (respecting Reduce Motion automatically).
class OriginScrollBehavior extends MaterialScrollBehavior {
  const OriginScrollBehavior();

  @override
  ScrollPhysics getScrollPhysics(BuildContext context) {
    if (OriginMotionEngine.isReducedMotion(context)) {
      return const ClampingScrollPhysics();
    }
    return const OriginSpringScrollPhysics();
  }

  @override
  Widget buildOverscrollIndicator(
    BuildContext context,
    Widget child,
    ScrollableDetails details,
  ) {
    if (OriginMotionEngine.isReducedMotion(context)) {
      return super.buildOverscrollIndicator(context, child, details);
    }
    return child;
  }
}

/// OriginOS 7 Fluid Motion spring press-and-rebound with subtle Dynamic Glow
/// touch highlight. Automatically becomes a no-op when Reduce Motion is active.
class LikedinPressScale extends StatefulWidget {
  const LikedinPressScale({
    required this.child,
    this.enabled = true,
    this.pressedScale = 0.955,
    this.glowRadius = const BorderRadius.all(Radius.circular(24)),
    super.key,
  });

  final Widget child;
  final bool enabled;
  final double pressedScale;
  final BorderRadius glowRadius;

  @override
  State<LikedinPressScale> createState() => _LikedinPressScaleState();
}

class _LikedinPressScaleState extends State<LikedinPressScale>
    with SingleTickerProviderStateMixin {
  late final AnimationController _spring = AnimationController.unbounded(
    vsync: this,
    value: 1.0,
  );
  Offset? _tapOffset;
  bool _pressed = false;

  static const SpringDescription _pressSpring = SpringDescription(
    mass: 1.0,
    stiffness: 520.0,
    damping: 30.0,
  );

  static const SpringDescription _releaseSpring = SpringDescription(
    mass: 1.0,
    stiffness: 380.0,
    damping: 20.0,
  );

  void _animateTo(double target, SpringDescription spring) {
    if (LikedinAppearance.reduceMotion.value) {
      _spring.value = target;
      return;
    }
    _spring
        .animateWith(
          SpringSimulation(
            spring,
            _spring.value,
            target,
            _spring.velocity,
            tolerance: const Tolerance(distance: 0.0005, velocity: 0.002),
          ),
        )
        .whenComplete(() {
      if (mounted && !_spring.isAnimating && (_spring.value - target).abs() < 0.004) {
        _spring.value = target;
      }
    });
  }

  void _onDown(PointerDownEvent e) {
    if (!widget.enabled || OriginMotionEngine.isReducedMotion(context)) return;
    _pressed = true;
    _tapOffset = e.localPosition;
    _animateTo(widget.pressedScale, _pressSpring);
    if (mounted) setState(() {});
  }

  void _onUp() {
    if (!_pressed) return;
    _pressed = false;
    _animateTo(1.0, _releaseSpring);
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _spring.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    final showGlow = _pressed &&
        _tapOffset != null &&
        LikedinAppearance.effects.value != LikedinEffects.off &&
        !OriginMotionEngine.isReducedMotion(context);
    final primary = likedinPrimary(brightness);

    // CRITICAL: Keep the widget tree depth above `child` strictly invariant
    // across pointer down/up! Conditionally wrapping `child` in a Stack during
    // onPointerDown unmounts & remounts descendant InkWell/GestureDetectors
    // mid-gesture, silently cancelling onTap. Using CustomPaint.foregroundPainter
    // updates the glow in-place on the same RenderObject with zero unmounting.
    return Listener(
      behavior: HitTestBehavior.translucent,
      onPointerDown: _onDown,
      onPointerMove: (e) {
        if (_pressed) {
          _tapOffset = e.localPosition;
          if (mounted) setState(() {});
        }
      },
      onPointerUp: (_) => _onUp(),
      onPointerCancel: (_) => _onUp(),
      child: AnimatedBuilder(
        animation: _spring,
        child: widget.child,
        builder: (context, child) {
          final scale = _spring.value.clamp(0.88, 1.05).toDouble();
          return Transform.scale(
            scale: scale,
            child: CustomPaint(
              foregroundPainter: showGlow
                  ? _OriginDynamicGlowPainter(
                      center: _tapOffset!,
                      borderRadius: widget.glowRadius,
                      color: primary,
                      dark: dark,
                    )
                  : null,
              child: child,
            ),
          );
        },
      ),
    );
  }
}

class _OriginDynamicGlowPainter extends CustomPainter {
  const _OriginDynamicGlowPainter({
    required this.center,
    required this.borderRadius,
    required this.color,
    required this.dark,
  });

  final Offset center;
  final BorderRadius borderRadius;
  final Color color;
  final bool dark;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final rect = Offset.zero & size;
    final radius = math.max(size.width, size.height) * 0.72;
    final paint = Paint()
      ..shader = RadialGradient(
        colors: [
          (dark ? Colors.white : color).withValues(alpha: dark ? .16 : .14),
          color.withValues(alpha: dark ? .08 : .06),
          color.withValues(alpha: 0.0),
        ],
        stops: const [0.0, 0.48, 1.0],
      ).createShader(Rect.fromCircle(center: center, radius: radius));
    canvas.save();
    canvas.clipRRect(borderRadius.toRRect(rect));
    canvas.drawCircle(center, radius, paint);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _OriginDynamicGlowPainter old) =>
      old.center != center ||
      old.borderRadius != borderRadius ||
      old.color != color ||
      old.dark != dark;
}

/// OriginOS 7 elastic floating bottom dock with a gliding, spring-stretching
/// Liquid Glass pill indicator and Dynamic Glow halo.
class OriginDockItem {
  const OriginDockItem({
    required this.tab,
    required this.icon,
    required this.activeIcon,
    required this.label,
  });

  final int tab;
  final IconData icon;
  final IconData activeIcon;
  final String label;
}

class OriginFloatingDock extends StatefulWidget {
  const OriginFloatingDock({
    required this.items,
    required this.activeTab,
    required this.onSelect,
    super.key,
  });

  final List<OriginDockItem> items;
  final int activeTab;
  final ValueChanged<int> onSelect;

  @override
  State<OriginFloatingDock> createState() => _OriginFloatingDockState();
}

class _OriginFloatingDockState extends State<OriginFloatingDock>
    with TickerProviderStateMixin {
  late final AnimationController _pillCtrl = AnimationController.unbounded(
    vsync: this,
    value: _indexForTab(widget.activeTab).toDouble(),
  );

  /// Drives liquid pill lift/scale (`0.0` resting -> `1.0` finger gliding).
  late final AnimationController _liftCtrl = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 180),
    reverseDuration: const Duration(milliseconds: 240),
    value: 0.0,
  );

  final OriginVelocityTracker _dragTracker = OriginVelocityTracker();
  bool _isDragging = false;
  int _lastHoveredIdx = -1;
  double _dragVelocitySlots = 0.0;

  int _indexForTab(int tab) {
    final idx = widget.items.indexWhere((e) => e.tab == tab);
    return idx < 0 ? 0 : idx;
  }

  void _springToIndex(int targetIndex, {double velocitySlots = 0.0}) {
    final target = targetIndex.toDouble();
    if (OriginMotionEngine.isReducedMotion(context)) {
      _pillCtrl.value = target;
      return;
    }
    _pillCtrl.animateWith(
      SpringSimulation(
        OriginPhysics.dockSpring,
        _pillCtrl.value,
        target,
        velocitySlots.clamp(-14.0, 14.0).toDouble(),
      ),
    );
  }

  @override
  void didUpdateWidget(covariant OriginFloatingDock oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (_isDragging) return;
    final target = _indexForTab(widget.activeTab);
    final maxIdx = math.max(0, widget.items.length - 1).toDouble();
    if (_pillCtrl.value > maxIdx) {
      _pillCtrl.value = target.toDouble();
      return;
    }
    if ((target.toDouble() - _pillCtrl.value).abs() > 0.001) {
      _springToIndex(target, velocitySlots: _pillCtrl.velocity);
    }
  }

  @override
  void dispose() {
    _pillCtrl.dispose();
    _liftCtrl.dispose();
    super.dispose();
  }

  double _slotPositionFromLocalX(double localX, double slotWidth, int count) {
    if (count <= 1 || slotWidth <= 0) return 0.0;
    final maxIdx = (count - 1).toDouble();
    final raw = (localX / slotWidth) - 0.5;
    if (raw < 0.0) {
      return OriginPhysics.rubberBand(raw, 0.24);
    }
    if (raw > maxIdx) {
      return maxIdx + OriginPhysics.rubberBand(raw - maxIdx, 0.24);
    }
    return raw;
  }

  void _handleDragStart(DragStartDetails details, double slotWidth, int count) {
    if (count <= 1 || slotWidth <= 0) return;
    _isDragging = true;
    _dragVelocitySlots = 0.0;
    _dragTracker.reset();
    _dragTracker.addPosition(details.globalPosition, timestamp: details.sourceTimeStamp);
    _pillCtrl.stop();
    final nextPos = _slotPositionFromLocalX(details.localPosition.dx, slotWidth, count);
    _pillCtrl.value = nextPos;
    _lastHoveredIdx = nextPos.round().clamp(0, count - 1);
    OriginHaptics.dragStart();
    if (!OriginMotionEngine.isReducedMotion(context)) {
      _liftCtrl.forward();
    }
  }

  void _handleDragUpdate(DragUpdateDetails details, double slotWidth, int count) {
    if (!_isDragging || count <= 1 || slotWidth <= 0) return;
    _dragTracker.addPosition(details.globalPosition, timestamp: details.sourceTimeStamp);
    final nextPos = _slotPositionFromLocalX(details.localPosition.dx, slotWidth, count);
    final vxPx = _dragTracker.estimateVelocity().dx;
    final instantVel = slotWidth > 0 ? (vxPx / slotWidth) : 0.0;
    _dragVelocitySlots = _dragVelocitySlots * 0.55 + instantVel * 0.45;
    _pillCtrl.value = nextPos;

    final hovered = nextPos.round().clamp(0, count - 1);
    if (hovered != _lastHoveredIdx) {
      _lastHoveredIdx = hovered;
      OriginHaptics.selection();
    }
  }

  void _handleDragEnd(DragEndDetails details, double slotWidth, int count) {
    if (!_isDragging) return;
    _isDragging = false;
    final maxIdx = math.max(0, count - 1);
    final trackedPxVel = _dragTracker.estimateVelocity().dx;
    final pxVel = (details.primaryVelocity != null && details.primaryVelocity!.abs() > 1.0)
        ? details.primaryVelocity!
        : trackedPxVel;
    final velSlots = slotWidth > 0 ? (pxVel / slotWidth) : 0.0;
    _dragVelocitySlots = 0.0;
    if (!OriginMotionEngine.isReducedMotion(context)) {
      _liftCtrl.reverse();
    } else {
      _liftCtrl.value = 0.0;
    }

    final projected = _pillCtrl.value + (velSlots * 0.11).clamp(-0.65, 0.65);
    final targetIdx = projected.round().clamp(0, maxIdx);
    _springToIndex(targetIdx, velocitySlots: velSlots);

    final targetTab = widget.items[targetIdx].tab;
    if (targetTab != widget.activeTab) {
      OriginHaptics.snapArrival();
      widget.onSelect(targetTab);
    }
  }

  void _handleDragCancel() {
    if (!_isDragging) return;
    _isDragging = false;
    _dragVelocitySlots = 0.0;
    if (!LikedinAppearance.reduceMotion.value) {
      _liftCtrl.reverse();
    } else {
      _liftCtrl.value = 0.0;
    }
    _springToIndex(_indexForTab(widget.activeTab));
  }

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    final primary = likedinPrimary(brightness);
    final endAccent = LikedinAppearance.accent.gradientEnd;
    final mutedColor = dark ? const Color(0xFFD2DDF0) : const Color(0xFF475569);
    final count = widget.items.length;

    final compactDock = MediaQuery.sizeOf(context).width < 345.0;
    return SizedBox(
      height: compactDock ? 60 : 66,
      child: Stack(
        fit: StackFit.expand,
        children: [
          // Static glass backdrop shell in its own RepaintBoundary so gliding &
          // spring physics in the foreground NEVER trigger blur recomputes!
          Positioned.fill(
            child: GlassPanel(
              radius: BorderRadius.circular(34),
              frosted: true,
              blur: 6,
              glow: true,
              child: const SizedBox.expand(),
            ),
          ),
          // Foreground interactive finger-gliding capsule & live-morphing tab row
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 6),
            child: LayoutBuilder(
              builder: (context, constraints) {
                final slotWidth = count > 0 ? constraints.maxWidth / count : constraints.maxWidth;
                return Listener(
                  behavior: HitTestBehavior.translucent,
                  onPointerUp: (_) {
                    // Defer orphaned-drag cleanup to a microtask so GestureDetector's
                    // synchronous onHorizontalDragEnd runs first and commits the tab switch.
                    Future<void>.microtask(() {
                      if (mounted && _isDragging) _handleDragCancel();
                    });
                  },
                  onPointerCancel: (_) {
                    Future<void>.microtask(() {
                      if (mounted && _isDragging) _handleDragCancel();
                    });
                  },
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onHorizontalDragStart: (d) => _handleDragStart(d, slotWidth, count),
                    onHorizontalDragUpdate: (d) => _handleDragUpdate(d, slotWidth, count),
                    onHorizontalDragEnd: (d) => _handleDragEnd(d, slotWidth, count),
                    onHorizontalDragCancel: _handleDragCancel,
                  child: RepaintBoundary(
                    child: AnimatedBuilder(
                      animation: Listenable.merge([_pillCtrl, _liftCtrl]),
                      builder: (context, _) {
                        final maxIdx = math.max(0, count - 1).toDouble();
                        final pos = _pillCtrl.value;
                        final clampedPos = pos.clamp(0.0, maxIdx).toDouble();
                        final overscroll = pos < 0.0
                            ? pos
                            : (pos > maxIdx ? pos - maxIdx : 0.0);
                        final lift = Curves.easeOutCubic.transform(_liftCtrl.value);

                        // Velocity-driven liquid stretch (works during BOTH finger glide & spring fling!)
                        final activeVel = _isDragging
                            ? _dragVelocitySlots.abs()
                            : _pillCtrl.velocity.abs();
                        final velStretch = (activeVel / 16.0).clamp(0.0, 0.24).toDouble();
                        final edgeSquash = (overscroll.abs() * 0.45).clamp(0.0, 0.14).toDouble();
                        final pillW = (slotWidth * (1.0 + velStretch + lift * 0.05 - edgeSquash))
                            .clamp(slotWidth * 0.86, constraints.maxWidth)
                            .toDouble();
                        final centerX = (clampedPos + 0.5 + overscroll * 0.35) * slotWidth;
                        final rawLeft = centerX - pillW * 0.5;
                        final maxLeft = math.max(0.0, constraints.maxWidth - pillW);
                        final left = rawLeft.clamp(0.0, maxLeft).toDouble();
                        final scaleY = (1.0 + lift * 0.06 - velStretch * 0.18).clamp(0.92, 1.08).toDouble();

                        return Stack(
                          children: [
                            // Finger-tracking OriginOS 7 liquid glass pill with genuine Bézier boundary deformation
                            Positioned(
                              left: left,
                              top: 0,
                              bottom: 0,
                              width: pillW,
                              child: IgnorePointer(
                                child: Transform.scale(
                                  scaleY: scaleY,
                                  child: CustomPaint(
                                    painter: OriginLiquidBoundaryPainter(
                                      radius: BorderRadius.circular(27),
                                      state: OriginFluidPhysics.computeDeformation(
                                        displacement: Offset(overscroll * slotWidth * 0.8, 0.0),
                                        velocity: Offset(
                                          (_isDragging ? _dragVelocitySlots : _pillCtrl.velocity) * slotWidth,
                                          0.0,
                                        ),
                                        maxStretch: 0.14,
                                        context: context,
                                      ),
                                      fillColor: Colors.transparent,
                                      gradient: LinearGradient(
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                        colors: dark
                                            ? [
                                                Colors.white.withValues(alpha: .24 + lift * .10),
                                                Color.lerp(primary, endAccent, lift * 0.35)!
                                                    .withValues(alpha: .26 + lift * .10),
                                              ]
                                            : [
                                                Colors.white.withValues(alpha: .97),
                                                Color.lerp(primary, endAccent, lift * 0.35)!
                                                    .withValues(alpha: .16 + lift * .08),
                                              ],
                                      ),
                                      rimColor: dark
                                          ? Color.lerp(Colors.white, endAccent, lift * 0.35)!
                                              .withValues(alpha: .40 + lift * .24)
                                          : Colors.white.withValues(alpha: .98),
                                      strokeWidth: 1.0 + lift * 0.35,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            // Dock tab items with continuous proximity morphing as the pill glides over them
                            Material(
                              type: MaterialType.transparency,
                              child: Row(
                                children: List<Widget>.generate(count, (i) {
                                  final item = widget.items[i];
                                  final proximity = (1.0 - (clampedPos - i).abs()).clamp(0.0, 1.0).toDouble();
                                  final isHighlighted = proximity > 0.52;
                                  final itemColor = Color.lerp(mutedColor, primary, proximity)!;
                                  final iconScale = 1.0 + proximity * (0.10 + lift * 0.06);
                                  return Expanded(
                                    child: Semantics(
                                      button: true,
                                      selected: widget.activeTab == item.tab,
                                      label: item.label,
                                      child: LikedinPressScale(
                                        enabled: !_isDragging,
                                        pressedScale: 0.90,
                                        glowRadius: BorderRadius.circular(26),
                                        child: InkWell(
                                        borderRadius: BorderRadius.circular(26),
                                        onTap: () {
                                          OriginHaptics.selection();
                                          _springToIndex(i);
                                          widget.onSelect(item.tab);
                                        },
                                        child: Center(
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Transform.scale(
                                                scale: iconScale,
                                                child: Icon(
                                                  isHighlighted ? item.activeIcon : item.icon,
                                                  size: 22,
                                                  color: itemColor,
                                                ),
                                              ),
                                              const SizedBox(height: 3),
                                              Text(
                                                item.label,
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                                style: TextStyle(
                                                  fontSize: 11,
                                                  fontWeight: isHighlighted
                                                      ? FontWeight.w800
                                                      : FontWeight.w500,
                                                  color: itemColor,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                    ),
                                  );
                                }, growable: false),
                              ),
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

/// Primary action button: OriginOS 7 gradient pill with specular top rim & spring press.
class GradientButton extends StatelessWidget {
  const GradientButton({
    required this.onPressed,
    required this.child,
    this.height = 52,
    super.key,
  });

  final VoidCallback? onPressed;
  final Widget child;
  final double height;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final enabled = onPressed != null;
    final radius = BorderRadius.circular(height);
    final texture = LikedinAppearance.effects.value;
    final profile = OriginGlassMaterialProfile.resolve(
      tierName: texture.name,
      lowRamDevice: LikedinAppearance.isLowRamDevice,
      reduceMotion: OriginMotionEngine.isReducedMotion(context),
    );
    return LikedinPressScale(
      enabled: enabled,
      glowRadius: radius,
      child: Opacity(
        opacity: enabled ? 1 : .55,
        child: CustomPaint(
          foregroundPainter: _LiquidGlassRimPainter(
            radius: radius,
            dark: true,
            accent: likedinPrimary(brightness),
            accentEnd: LikedinAppearance.accent.gradientEnd,
            texture: texture,
            profile: profile,
            lightDir: OriginOpticalLightModel.defaultLightDir,
            isFrosted: false,
            glow: false,
          ),
          child: Material(
            color: Colors.transparent,
            child: Ink(
              height: height,
              decoration: BoxDecoration(
                gradient: likedinPrimaryGradient(brightness),
                borderRadius: radius,
              ),
              child: InkWell(
                onTap: onPressed,
                borderRadius: radius,
                child: Center(
                  child: DefaultTextStyle.merge(
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                    ),
                    child: IconTheme.merge(
                      data: const IconThemeData(color: Colors.white),
                      child: child,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}


/// Overflow-proof OriginOS 7 floating quick-reaction pill that scales cleanly
/// down to 320dp/360dp widths and 120% in-app text scaling without clipping.
class OriginQuickReactionBar extends StatelessWidget {
  const OriginQuickReactionBar({
    required this.emojis,
    required this.onSelectEmoji,
    this.onMore,
    this.emojiFontFamily,
    super.key,
  });

  final List<String> emojis;
  final ValueChanged<String> onSelectEmoji;
  final VoidCallback? onMore;
  final String? emojiFontFamily;

  @override
  Widget build(BuildContext context) {
    final b = Theme.of(context).brightness;
    final dark = b == Brightness.dark;
    final muted = likedinMutedText(b);

    return GlassPanel(
      radius: BorderRadius.circular(30),
      frosted: true,
      elevatedSheet: true,
      glow: true,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      child: Row(
        children: [
          for (final emoji in emojis)
            Expanded(
              child: LikedinPressScale(
                pressedScale: 0.84,
                glowRadius: BorderRadius.circular(20),
                child: Material(
                  type: MaterialType.transparency,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: () {
                      OriginHaptics.selection();
                      onSelectEmoji(emoji);
                    },
                    child: SizedBox(
                      height: 40,
                      child: Center(
                        child: FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 2),
                            child: Text(
                              emoji,
                              textScaler: TextScaler.noScaling,
                              style: TextStyle(
                                fontSize: 24,
                                fontFamily: emojiFontFamily,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          if (onMore != null)
            Padding(
              padding: const EdgeInsets.only(left: 2),
              child: SizedBox(
                width: 36,
                height: 36,
                child: LikedinPressScale(
                  pressedScale: 0.86,
                  glowRadius: BorderRadius.circular(18),
                  child: Material(
                    type: MaterialType.transparency,
                    child: Semantics(
                      button: true,
                      label: 'More reactions',
                      child: InkWell(
                        borderRadius: BorderRadius.circular(18),
                        onTap: () {
                          OriginHaptics.selection();
                          onMore!();
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            color: (dark ? Colors.white : Colors.black)
                                .withValues(alpha: dark ? .11 : .07),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(Icons.add_rounded, size: 20, color: muted),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
