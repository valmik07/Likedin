import 'package:flutter/material.dart';

/// Shared surface palette. Pages draw on [likedinBackground]; cards, sheets and
/// bars sit on [likedinSurface] with a hairline [likedinOutline].
Color likedinBackground(Brightness brightness) => brightness == Brightness.dark
    ? const Color(0xFF0A101C)
    : const Color(0xFFF4F6FA);

Color likedinSurface(Brightness brightness) => brightness == Brightness.dark
    ? const Color(0xFF121A2A)
    : const Color(0xFFFFFFFF);

Color likedinSurfaceRaised(Brightness brightness) =>
    brightness == Brightness.dark
        ? const Color(0xFF1A2438)
        : const Color(0xFFEDF1F7);

Color likedinOutline(Brightness brightness) => brightness == Brightness.dark
    ? const Color(0xFF223049)
    : const Color(0xFFE2E8F1);

/// A flat, solid content surface used for cards, bars and grouped rows.
///
/// The name is kept for compatibility with existing call sites. The look is now
/// a calm tonal surface with a hairline outline: no blur, gradient or glow, so
/// it is cheaper to paint on entry-level Android GPUs as well. [blur], [tint]
/// and [glow] are accepted but intentionally ignored.
class GlassPanel extends StatelessWidget {
  const GlassPanel({
    required this.child,
    this.padding = EdgeInsets.zero,
    this.radius = const BorderRadius.all(Radius.circular(20)),
    this.blur = 0,
    this.tint,
    this.glow = false,
    super.key,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final BorderRadius radius;
  final double blur;
  final Color? tint;
  final bool glow;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    return ClipRRect(
      borderRadius: radius,
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: likedinSurface(brightness),
          borderRadius: radius,
          border: Border.all(color: likedinOutline(brightness), width: 1),
        ),
        child: Padding(padding: padding, child: child),
      ),
    );
  }
}

/// Flat page background. Kept under its original name so every screen that
/// already wraps itself in it picks up the new look.
class AuroraBackdrop extends StatelessWidget {
  const AuroraBackdrop({required this.child, super.key});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    // Same Stack(expand) layout contract as before, so child sizing is
    // unchanged; only the painted background is now flat.
    return Stack(
      fit: StackFit.expand,
      children: [
        ColoredBox(color: likedinBackground(Theme.of(context).brightness)),
        child,
      ],
    );
  }
}
