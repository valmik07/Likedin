import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../backend/realtime_messaging_service.dart';
import 'glassmorphism.dart';

class _Preview {
  const _Preview({
    this.name,
    this.online = false,
    this.avatarUrl,
    this.lastText,
    this.lastAt,
    this.lastIsMine = false,
    this.unread = 0,
  });
  final String? name;
  final bool online;
  final String? avatarUrl;
  final String? lastText;
  final DateTime? lastAt;
  final bool lastIsMine;
  final int unread;
}

/// Conversation row for the home hub (spec screen 3): avatar with online
/// indicator, name, latest message, timestamp and an unread badge. It only
/// reads data through the existing messaging service and never changes it.
class ConversationCard extends StatefulWidget {
  const ConversationCard({required this.onOpen, super.key});
  final VoidCallback onOpen;

  @override
  State<ConversationCard> createState() => _ConversationCardState();
}

class _ConversationCardState extends State<ConversationCard> {
  late final Future<_Preview> _future = _load();

  Future<_Preview> _load() async {
    final client = Supabase.instance.client;
    final service = RealtimeMessagingService(client);
    final peer = await service.getPeerProfile();
    if (peer == null) return const _Preview();

    String? lastText;
    DateTime? lastAt;
    var lastIsMine = false;
    try {
      final recent = await service.loadConversation(limit: 1);
      if (recent.isNotEmpty) {
        final m = recent.last;
        if (m.deletedForEveryoneAt != null) {
          lastText = 'Message deleted';
        } else {
          lastText = _describe(m.text);
        }
        lastAt = m.createdAt;
        lastIsMine = m.senderId == service.currentUserId;
      }
    } catch (_) {}

    var unread = 0;
    try {
      final uid = client.auth.currentUser?.id;
      if (uid != null) {
        final rows = await client
            .from('messages')
            .select('id')
            .eq('recipient_id', uid)
            .isFilter('read_at', null)
            .isFilter('deleted_for_everyone_at', null)
            .limit(100);
        unread = rows.length;
      }
    } catch (_) {}

    String? avatarUrl;
    final avatarPath = peer.avatarPath;
    if (avatarPath != null && avatarPath.isNotEmpty) {
      try {
        avatarUrl = await service.profileAvatarSignedUrl(avatarPath);
      } catch (_) {}
    }

    return _Preview(
      name: peer.name,
      online: peer.online,
      avatarUrl: avatarUrl,
      lastText: lastText,
      lastAt: lastAt,
      lastIsMine: lastIsMine,
      unread: unread,
    );
  }

  static String _describe(String raw) {
    if (raw.contains('__likedin_media_v1')) {
      try {
        final decoded = jsonDecode(raw);
        if (decoded is Map) {
          switch (decoded['kind']?.toString()) {
            case 'image':
              return 'Photo';
            case 'video':
              return 'Video';
            case 'audio':
              return 'Voice message';
          }
        }
      } catch (_) {}
      return 'Attachment';
    }
    return raw.replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  static String _time(DateTime at) {
    final now = DateTime.now();
    if (at.year == now.year && at.month == now.month && at.day == now.day) {
      return '${at.hour.toString().padLeft(2, '0')}:${at.minute.toString().padLeft(2, '0')}';
    }
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return '${at.day} ${months[at.month - 1]}';
  }

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final primary = likedinPrimary(brightness);
    final muted = likedinMutedText(brightness);
    return FutureBuilder<_Preview>(
      future: _future,
      builder: (context, snapshot) {
        final loading = snapshot.connectionState != ConnectionState.done;
        final data = snapshot.data ?? const _Preview();
        final name = data.name ?? 'Your conversation';
        final hasUnread = data.unread > 0;
        final subtitle = loading
            ? 'Loading…'
            : data.lastText == null
                ? 'Tap to start chatting'
                : '${data.lastIsMine ? 'You: ' : ''}${data.lastText}';
        return GlassPanel(
          radius: BorderRadius.circular(22),
          frosted: false,
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: widget.onOpen,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                child: Row(
                  children: [
                    Stack(
                      clipBehavior: Clip.none,
                      children: [
                        CircleAvatar(
                          radius: 27,
                          backgroundColor: primary.withValues(alpha: .16),
                          backgroundImage: data.avatarUrl == null
                              ? null
                              : ResizeImage(NetworkImage(data.avatarUrl!), width: 144),
                          child: data.avatarUrl != null
                              ? null
                              : Text(
                                  name.isEmpty ? '?' : String.fromCharCode(name.runes.first).toUpperCase(),
                                  style: TextStyle(
                                    color: primary,
                                    fontSize: 21,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                        ),
                        if (data.online)
                          Positioned(
                            right: -1,
                            bottom: -1,
                            child: Semantics(
                              label: 'Online',
                              child: Container(
                                width: 14,
                                height: 14,
                                decoration: BoxDecoration(
                                  color: const Color(0xFF2FBF86),
                                  shape: BoxShape.circle,
                                  border: Border.all(color: likedinSurface(brightness), width: 2.5),
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            subtitle,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 14,
                              color: hasUnread ? likedinOnSurface(brightness) : muted,
                              fontWeight: hasUnread ? FontWeight.w600 : FontWeight.w400,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        if (data.lastAt != null)
                          Text(_time(data.lastAt!), style: TextStyle(fontSize: 12, color: muted)),
                        const SizedBox(height: 6),
                        if (hasUnread)
                          Semantics(
                            label: '${data.unread} unread',
                            child: Container(
                              constraints: const BoxConstraints(minWidth: 22),
                              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                              decoration: BoxDecoration(
                                gradient: likedinPrimaryGradient(brightness),
                                borderRadius: BorderRadius.circular(11),
                              ),
                              child: Text(
                                data.unread > 99 ? '99+' : '${data.unread}',
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                          )
                        else
                          const SizedBox(height: 22),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
