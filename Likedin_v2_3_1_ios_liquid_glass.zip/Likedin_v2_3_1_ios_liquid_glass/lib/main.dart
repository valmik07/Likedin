import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:xml/xml.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import 'backend/backend_config.dart';
import 'backend/realtime_messaging_service.dart';
import 'backend/shared_media_service.dart';
import 'notifications/notification_service.dart';
import 'calls/call_service.dart';
import 'calls/call_alert_controller.dart';
import 'calls/proximity_call_controller.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:video_player/video_player.dart';
import 'package:record/record.dart';
import 'package:just_audio/just_audio.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:photo_manager/photo_manager.dart' show AssetEntity;
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';

import 'data/attachment_vault_store.dart';
import 'auth/local_account_store.dart';
import 'security/e2ee_service.dart';
import 'security/encrypted_backup_codec.dart';
import 'security/hidden_chat_vault.dart';
import 'utils/message_length.dart';
import 'utils/chat_info_metrics.dart';
import 'utils/message_merge.dart';
import 'utils/offline_catch_up.dart';
import 'utils/realtime_message_payload.dart';
import 'utils/receipt_reconciliation.dart';
import 'utils/app_updater.dart';
import 'utils/emoji_text.dart';
import 'utils/voice_gesture_guard.dart';
import 'ui/glassmorphism.dart';
import 'ui/message_search.dart';
import 'ui/in_app_gallery_picker.dart';
import 'ui/conversation_card.dart';
import 'ui/hidden_chat_pin_dialog.dart';
import 'ui/profile_page.dart';
import 'ui/profile_photo_editor.dart';
import 'ui/profile_photo_viewer.dart';
import 'ui/storage_page.dart';
import 'ui/theme_customization_page.dart';
import 'ui/chat_avatar_studio.dart';
import 'ui/chat_info_page.dart';
import 'ui/photo_send_editor.dart';

part 'ui/home_page_part.dart';
part 'ui/chat_page_part.dart';
part 'ui/calls_page_part.dart';
part 'ui/settings_page_part.dart';

/// Call screens always use a dark, flat palette regardless of the app theme.
const Color _callBackground = Color(0xFF0A101C);
const Color _callPanel = Color(0xFF152036);
const Color _callButton = Color(0xFF1E2B45);
const Color _callAccent = Color(0xFF8DB8FF);
const Color _callDanger = Color(0xFFE5484D);
const Color _callPositive = Color(0xFF2FBF86);
const Color _callMuted = Color(0xFFA6B3CC);

/// Small rounded label used for call status and the video overlay chip.
class _CallPill extends StatelessWidget {
  const _CallPill({required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: _callPanel,
          borderRadius: BorderRadius.circular(24),
        ),
        child: child,
      );
}

/// Status line with a coloured dot, e.g. "Ringing…" or "02:14".
class _CallStatusLine extends StatelessWidget {
  const _CallStatusLine({required this.text, required this.color});
  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 8),
          Text(
            text,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 17,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      );
}

/// Round toggle used for mute, speaker, camera and flip.
class _CallRoundButton extends StatelessWidget {
  const _CallRoundButton({
    required this.icon,
    required this.label,
    required this.onPressed,
    this.active = false,
  });
  final IconData icon;
  final String label;
  final VoidCallback? onPressed;
  final bool active;

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null;
    return SizedBox(
      width: 76,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Semantics(
            button: true,
            enabled: enabled,
            selected: active,
            label: label,
            child: Material(
              color: active ? Colors.white : _callButton,
              shape: const CircleBorder(),
              child: InkWell(
                customBorder: const CircleBorder(),
                onTap: onPressed,
                child: SizedBox(
                  width: 60,
                  height: 60,
                  child: Icon(
                    icon,
                    size: 26,
                    color: !enabled
                        ? Colors.white24
                        : active
                            ? _callBackground
                            : Colors.white,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: _callMuted, fontSize: 12),
          ),
        ],
      ),
    );
  }
}

/// A restrained animated focal point for the full-screen calling experience.
/// Animation is local to the active call UI and is disposed with the widget.
class _CallHaloAvatar extends StatefulWidget {
  const _CallHaloAvatar({required this.icon, this.size = 148, this.animate = true});
  final IconData icon;
  final double size;
  final bool animate;

  @override
  State<_CallHaloAvatar> createState() => _CallHaloAvatarState();
}

class _CallHaloAvatarState extends State<_CallHaloAvatar>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulse;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    );
    _syncPulse();
  }

  void _syncPulse() {
    final shouldAnimate = widget.animate &&
        !LikedinAppearance.reduceMotion.value &&
        !(mounted && MediaQuery.maybeOf(context)?.disableAnimations == true);
    if (shouldAnimate) {
      if (!_pulse.isAnimating) _pulse.repeat(reverse: true);
    } else {
      if (_pulse.isAnimating) _pulse.stop();
      _pulse.value = .35;
    }
  }

  @override
  void didUpdateWidget(covariant _CallHaloAvatar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.animate != widget.animate) {
      _syncPulse();
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _syncPulse();
  }

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _pulse,
        builder: (context, _) {
          final t = Curves.easeInOut.transform(_pulse.value);
          return SizedBox(
            width: widget.size * 1.2,
            height: widget.size * 1.2,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: widget.size * (1.04 + .16 * t),
                  height: widget.size * (1.04 + .16 * t),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _callAccent.withValues(alpha: .10 + .24 * (1 - t)),
                      width: 2,
                    ),
                  ),
                ),
                Container(
                  width: widget.size,
                  height: widget.size,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFF1B2A47),
                  ),
                  child: Icon(widget.icon, color: _callAccent, size: widget.size * .44),
                ),
              ],
            ),
          );
        },
      );
}

bool _passwordRecoveryPending = false;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Bound decoded-image memory for 3 GB Android devices. Gallery thumbnails
  // are small, while full-size media is decoded only in the viewer.
  final imageCache = PaintingBinding.instance.imageCache;
  imageCache.maximumSize = 60;
  imageCache.maximumSizeBytes = 24 * 1024 * 1024;
  try {
    await ensureLikedinFirebaseReady();
  } catch (error) {
    debugPrint('Firebase bootstrap initialization failed: $error');
  }
  runApp(const LikedinBootstrap());
}

class LikedinBootstrap extends StatefulWidget {
  const LikedinBootstrap({super.key});
  @override
  State<LikedinBootstrap> createState() => _LikedinBootstrapState();
}

class _LikedinBootstrapState extends State<LikedinBootstrap> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 600),
  )..forward();
  bool _splashDark = false;
  Widget? _readyApp;
  String? _error;
  bool _supabaseInitialized = false;
  StreamSubscription<AuthState>? _earlyAuthSubscription;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _initialize());
  }

  Future<void> _initialize() async {
    try {
      // Read saved theme/appearance first so the splash already matches the
      // user's theme (Obsidian Glass or Arctic Glass). This is a fast local read.
      try {
        final early = await SharedPreferences.getInstance();
        await LikedinAppearance.load(early);
        if (mounted) {
          setState(() => _splashDark = early.getBool(likedinThemePreferenceKey) == true);
        }
        if (LikedinAppearance.reduceMotion.value) _controller.value = 1;
      } catch (_) {}
      if (!_supabaseInitialized) {
        await Supabase.initialize(
          url: BackendConfig.supabaseUrl,
          publishableKey: BackendConfig.supabaseAnonKey,
          // Keep the persisted Supabase session alive by refreshing access
          // tokens automatically when the app resumes or a token nears expiry.
          authOptions: const FlutterAuthClientOptions(autoRefreshToken: true),
        );
        _supabaseInitialized = true;
      }
      // Subscribe immediately after Supabase restores the deep-link session.
      // The notification/bootstrap work below may take long enough for an auth
      // recovery event to otherwise be missed by the later AuthGate listener.
      _earlyAuthSubscription ??= Supabase.instance.client.auth.onAuthStateChange.listen((state) {
        // Diagnostic only: never log access/refresh tokens or user credentials.
        debugPrint('Supabase auth event: ${state.event.name}');
        if (state.event == AuthChangeEvent.passwordRecovery) {
          _passwordRecoveryPending = true;
        }
      }, onError: (Object error, StackTrace stackTrace) {
        debugPrint('Early auth listener failed: $error\n$stackTrace');
      });
      try {
        await LikedinNotificationService.instance.initialize();
      } catch (error) {
        debugPrint('Notification setup failed; continuing app startup: $error');
      }
      final attachmentVault = AttachmentVaultStore();
      final preferences = await SharedPreferences.getInstance();
      likedinThemeMode.value = preferences.getBool(likedinThemePreferenceKey) == true
          ? ThemeMode.dark
          : ThemeMode.light;
      final savedSpeed = preferences.getDouble(likedinVoiceSpeedPrefKey);
      if (savedSpeed == 1.0 || savedSpeed == 1.5 || savedSpeed == 2.0) {
        likedinVoiceSpeed.value = savedSpeed!;
      }
      final uid = Supabase.instance.client.auth.currentUser?.id;
      likedinProfilePhotoPath.value = uid == null ? null : preferences.getString('${likedinProfilePhotoPreferenceKey}_$uid');
      if (!mounted) return;
      setState(() => _readyApp = LikedinApp(attachmentVault: attachmentVault));
    } catch (e) {
      if (mounted) {
        setState(() => _error = 'Could not start Likedin. Check your connection and try again.');
      }
    }
  }

  @override
  void dispose() {
    _earlyAuthSubscription?.cancel();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_readyApp != null) return _readyApp!;
    final b = _splashDark ? Brightness.dark : Brightness.light;
    final primary = likedinPrimary(b);
    final sweep = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.1, 0.85, curve: Curves.easeInOut),
    );
    final nameFade = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.45, 1.0, curve: Curves.easeOut),
    );
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: _likedinTheme(b),
      home: Scaffold(
        backgroundColor: likedinBackground(b),
        body: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [likedinBackgroundTop(b), likedinBackground(b)],
            ),
          ),
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ScaleTransition(
                  scale: Tween<double>(begin: .88, end: 1).animate(
                    CurvedAnimation(parent: _controller, curve: Curves.easeOutBack),
                  ),
                  child: FadeTransition(
                    opacity: CurvedAnimation(parent: _controller, curve: const Interval(0, .5)),
                    child: Container(
                      width: 112,
                      height: 112,
                      decoration: BoxDecoration(
                        color: likedinSurface(b).withValues(alpha: _splashDark ? .75 : .9),
                        borderRadius: BorderRadius.circular(32),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: _splashDark ? .16 : .9),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: primary.withValues(alpha: _splashDark ? .38 : .22),
                            blurRadius: 36,
                            spreadRadius: -2,
                            offset: const Offset(0, 10),
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(32),
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            const LikedinLogo(size: 66),
                            // Soft light sweep across the emblem.
                            Positioned.fill(
                              child: IgnorePointer(
                                child: AnimatedBuilder(
                                  animation: sweep,
                                  builder: (context, _) => DecoratedBox(
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        begin: Alignment(-2.2 + 3.6 * sweep.value, -1),
                                        end: Alignment(-1.0 + 3.6 * sweep.value, 1),
                                        colors: [
                                          Colors.white.withValues(alpha: 0),
                                          Colors.white.withValues(alpha: _splashDark ? .34 : .6),
                                          Colors.white.withValues(alpha: 0),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 22),
                FadeTransition(
                  opacity: nameFade,
                  child: Text(
                    'Likedin',
                    style: TextStyle(
                      color: likedinOnSurface(b),
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -.5,
                    ),
                  ),
                ),
                if (_error != null) ...[
                  const SizedBox(height: 20),
                  Text(_error!, textAlign: TextAlign.center),
                  TextButton(
                    onPressed: () {
                      setState(() => _error = null);
                      _initialize();
                    },
                    child: const Text('Retry'),
                  ),
                ]
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class CodePointLengthLimitingTextInputFormatter extends TextInputFormatter {
  const CodePointLengthLimitingTextInputFormatter(this.maxCodePoints);
  final int maxCodePoints;

  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    final runes = newValue.text.runes;
    if (likedinMessageCodePointLength(newValue.text) <= maxCodePoints) return newValue;
    final limited = String.fromCharCodes(runes.take(maxCodePoints));
    final offset = newValue.selection.extentOffset.clamp(0, limited.length);
    return TextEditingValue(
      text: limited,
      selection: TextSelection.collapsed(offset: offset),
      composing: TextRange.empty,
    );
  }
}

const likedinVersion = '2.3.1+123';
const String likedinVoiceSpeedPrefKey = 'likedin_voice_speed_v1';
final ValueNotifier<double> likedinVoiceSpeed = ValueNotifier<double>(1.0);
const String likedinHiddenBiometricPrefKey = 'likedin_hidden_biometric_v1';
const MethodChannel _callAlertsMethodChannel = MethodChannel('com.example.likedin/call_alerts');
bool _globalCallDialogActive = false;
Color get brandBlue => likedinPrimary(likedinThemeMode.value == ThemeMode.dark ? Brightness.dark : Brightness.light);
const MethodChannel _keyboardMediaChannel = MethodChannel('com.example.likedin/keyboard_media');
const MethodChannel _hiddenChatSecurityChannel = MethodChannel('com.example.likedin/hidden_chat_security');
const ink = Color(0xFF172B4D);
const muted = Color(0xFF667085);
const page = Color(0xFFF3F6F8);
final ValueNotifier<ThemeMode> likedinThemeMode = ValueNotifier<ThemeMode>(ThemeMode.light);
const String likedinThemePreferenceKey = 'likedin_theme_mode_v1';
const String likedinProfilePhotoPreferenceKey = 'likedin_profile_photo_path_v1';
final ValueNotifier<String?> likedinProfilePhotoPath = ValueNotifier<String?>(null);

/// Switches between Arctic Glass (light) and Obsidian Glass (dark) and saves it.
Future<void> setLikedinDarkMode(bool dark) async {
  likedinThemeMode.value = dark ? ThemeMode.dark : ThemeMode.light;
  try {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(likedinThemePreferenceKey, dark);
  } catch (_) {}
}

/// One theme definition for both brightnesses so every page, sheet, dialog and
/// control shares the same shapes, spacing and tonal surfaces.
ThemeData _likedinTheme(Brightness brightness) {
  final dark = brightness == Brightness.dark;
  final background = likedinBackground(brightness);
  final surface = likedinSurface(brightness);
  final outline = likedinOutline(brightness);
  final raised = likedinSurfaceRaised(brightness);
  // Obsidian Glass (dark) / Arctic Glass (light) with the user's accent. The
  // accent is tuned per brightness in glassmorphism.dart so text stays readable.
  final primary = likedinPrimary(brightness);
  final onPrimary = dark ? const Color(0xFF04122B) : Colors.white;
  final onSurface = likedinOnSurface(brightness);
  final scheme = ColorScheme.fromSeed(
    seedColor: primary,
    brightness: brightness,
    surface: surface,
  ).copyWith(
    primary: primary,
    onPrimary: onPrimary,
    onSurface: onSurface,
    onSurfaceVariant: likedinMutedText(brightness),
    outline: outline,
  );
  const pillShape = StadiumBorder();
  return ThemeData(
    useMaterial3: true,
    brightness: brightness,
    scaffoldBackgroundColor: background,
    pageTransitionsTheme: const PageTransitionsTheme(
      builders: {
        TargetPlatform.android: CupertinoPageTransitionsBuilder(),
        TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
      },
    ),
    colorScheme: scheme,
    dividerColor: outline,
    appBarTheme: AppBarTheme(
      backgroundColor: background,
      foregroundColor: onSurface,
      elevation: 0,
      scrolledUnderElevation: 0,
      surfaceTintColor: Colors.transparent,
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: primary,
      foregroundColor: onPrimary,
      elevation: 2,
      highlightElevation: 3,
      shape: const CircleBorder(),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      indicatorColor: primary.withValues(alpha: dark ? .24 : .14),
      indicatorShape: pillShape,
      elevation: 0,
      height: 68,
      labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
      labelTextStyle: WidgetStateProperty.resolveWith(
        (states) => TextStyle(
          fontSize: 12,
          fontWeight: states.contains(WidgetState.selected)
              ? FontWeight.w700
              : FontWeight.w500,
        ),
      ),
    ),
    cardTheme: CardThemeData(
      color: surface,
      elevation: 0,
      margin: EdgeInsets.zero,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: outline),
      ),
    ),
    dividerTheme: DividerThemeData(color: outline, thickness: 1, space: 1),
    listTileTheme: const ListTileThemeData(
      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 2),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(16)),
      ),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: dark ? const Color(0xFFE8EEF9) : const Color(0xFF16233A),
      contentTextStyle: TextStyle(
        color: dark ? const Color(0xFF0F1B2D) : Colors.white,
        fontSize: 14,
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: surface.withValues(alpha: dark ? .94 : .96),
      surfaceTintColor: Colors.transparent,
      showDragHandle: true,
      shape: RoundedRectangleBorder(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        side: BorderSide(
          color: dark
              ? Colors.white.withValues(alpha: .14)
              : Colors.white.withValues(alpha: .90),
        ),
      ),
    ),
    dialogTheme: DialogThemeData(
      backgroundColor: surface.withValues(alpha: dark ? .95 : .97),
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(28),
        side: BorderSide(
          color: dark
              ? Colors.white.withValues(alpha: .14)
              : Colors.white.withValues(alpha: .92),
        ),
      ),
    ),
    popupMenuTheme: PopupMenuThemeData(
      color: surface.withValues(alpha: dark ? .94 : .96),
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: BorderSide(
          color: dark ? Colors.white.withValues(alpha: .14) : outline,
        ),
      ),
    ),
    chipTheme: ChipThemeData(
      shape: pillShape,
      side: BorderSide(color: outline),
      backgroundColor: raised,
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith(
        (states) => states.contains(WidgetState.selected)
            ? (dark ? const Color(0xFF0A101C) : Colors.white)
            : (dark ? const Color(0xFF8795AD) : const Color(0xFF7B8798)),
      ),
      trackColor: WidgetStateProperty.resolveWith(
        (states) => states.contains(WidgetState.selected) ? primary : raised,
      ),
      trackOutlineColor: WidgetStateProperty.resolveWith(
        (states) => states.contains(WidgetState.selected)
            ? Colors.transparent
            : (dark ? const Color(0xFF3A4963) : const Color(0xFFC9D2E0)),
      ),
    ),
    progressIndicatorTheme: ProgressIndicatorThemeData(color: primary),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        shape: pillShape,
        minimumSize: const Size(0, 48),
        padding: const EdgeInsets.symmetric(horizontal: 22),
        textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        shape: pillShape,
        minimumSize: const Size(0, 46),
        side: BorderSide(color: dark ? const Color(0xFF3A4963) : const Color(0xFFC9D2E0)),
        textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        shape: pillShape,
        textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: raised,
      hintStyle: TextStyle(color: dark ? const Color(0xFF8795AD) : const Color(0xFF7B8798)),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: primary, width: 1.6),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
    ),
  );
}

class LikedinApp extends StatelessWidget {
  const LikedinApp({required this.attachmentVault, super.key});
  final AttachmentVaultStore attachmentVault;

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<ThemeMode>(
        valueListenable: likedinThemeMode,
        builder: (context, mode, _) => ListenableBuilder(
          // Accent, effects and motion changes re-theme the whole app live.
          listenable: LikedinAppearance.listenable,
          builder: (context, _) => MaterialApp(
            title: 'Likedin',
            debugShowCheckedModeBanner: false,
            themeMode: mode,
            theme: _likedinTheme(Brightness.light),
            darkTheme: _likedinTheme(Brightness.dark),
            themeAnimationDuration: LikedinAppearance.reduceMotion.value
                ? Duration.zero
                : const Duration(milliseconds: 200),
            home: AuthGate(attachmentVault: attachmentVault),
          ),
        ),
      );
}

class AuthGate extends StatefulWidget {
  const AuthGate({required this.attachmentVault, super.key});
  final AttachmentVaultStore attachmentVault;

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  StreamSubscription<AuthState>? _authSubscription;
  bool _showingRecoveryDialog = false;

  @override
  void initState() {
    super.initState();
    _authSubscription = Supabase.instance.client.auth.onAuthStateChange.listen(
      (state) {
        if (state.event == AuthChangeEvent.passwordRecovery) {
          _passwordRecoveryPending = false;
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) _showPasswordRecoveryDialog();
          });
        }
      },
      onError: (Object error, StackTrace stackTrace) {
        debugPrint('Auth state listener failed: $error\n$stackTrace');
      },
    );
    if (_passwordRecoveryPending) {
      _passwordRecoveryPending = false;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _showPasswordRecoveryDialog();
      });
    }
  }

  @override
  void dispose() {
    _authSubscription?.cancel();
    super.dispose();
  }

  Future<void> _showPasswordRecoveryDialog() async {
    if (!mounted || _showingRecoveryDialog) return;
    _showingRecoveryDialog = true;
    final passwordController = TextEditingController();
    final confirmController = TextEditingController();
    var saving = false;
    String? errorText;
    try {
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => PopScope<Object?>(
          canPop: false,
          child: StatefulBuilder(
          builder: (dialogContext, updateDialog) => AlertDialog(
            title: const Text('Set a new password'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: passwordController,
                  obscureText: true,
                  autofillHints: const [AutofillHints.newPassword],
                  textInputAction: TextInputAction.next,
                  decoration: const InputDecoration(labelText: 'New password (8+ characters)'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: confirmController,
                  obscureText: true,
                  textInputAction: TextInputAction.done,
                  decoration: const InputDecoration(labelText: 'Confirm new password'),
                ),
                if (errorText != null) ...[
                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(errorText!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
                  ),
                ],
              ],
            ),
            actions: [
              TextButton(
                onPressed: saving ? null : () async {
                  await Supabase.instance.client.auth.signOut();
                  if (dialogContext.mounted) Navigator.of(dialogContext).pop();
                },
                child: const Text('Back to sign in'),
              ),
              FilledButton(
                onPressed: saving ? null : () async {
                  final password = passwordController.text;
                  if (password.length < 8) {
                    updateDialog(() => errorText = 'Use at least 8 characters.');
                    return;
                  }
                  if (password != confirmController.text) {
                    updateDialog(() => errorText = 'The passwords do not match.');
                    return;
                  }
                  updateDialog(() { saving = true; errorText = null; });
                  try {
                    await Supabase.instance.client.auth.updateUser(UserAttributes(password: password));
                    if (!dialogContext.mounted) return;
                    Navigator.of(dialogContext).pop();
                    if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Your password has been updated.')),
                      );
                    }
                  } on AuthException {
                    if (dialogContext.mounted) {
                      updateDialog(() {
                        saving = false;
                        errorText = 'The password could not be updated. Check the requirements and try again.';
                      });
                    }
                  } catch (_) {
                    if (dialogContext.mounted) {
                      updateDialog(() {
                        saving = false;
                        errorText = 'Could not update the password. Request a new recovery link and try again.';
                      });
                    }
                  }
                },
                child: saving
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Text('Update password'),
              ),
            ],
          ),
          ),
        ),
      );
    } finally {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        passwordController.dispose();
        confirmController.dispose();
      });
      _showingRecoveryDialog = false;
    }
  }

  @override
  Widget build(BuildContext context) => StreamBuilder<AuthState>(
        stream: Supabase.instance.client.auth.onAuthStateChange,
        builder: (context, snapshot) {
          final user = Supabase.instance.client.auth.currentUser;
          if (user == null) return const SignInPage();
          final account = LikedinAccount(
            displayName: (user.userMetadata?['display_name'] as String?) ??
                user.email?.split('@').first ??
                'Likedin user',
            likedinId: user.email ?? user.id,
            salt: '',
            passwordHash: '',
            createdAt: user.createdAt,
          );
          return AppShell(
            attachmentVault: widget.attachmentVault,
            account: account,
            onSignOut: () async {
              try {
                await LikedinNotificationService.instance.unregisterCurrentToken();
              } catch (error) {
                debugPrint('Push-token cleanup deferred during sign-out: $error');
              }
              likedinProfilePhotoPath.value = null;
              E2eeService.instance.resetMemoryState();
              try {
                final prefs = await SharedPreferences.getInstance();
                await prefs.remove(HiddenChatVault.notificationRedactionPreference);
              } catch (_) {}
              try {
                await Supabase.instance.client.rpc('likedin_set_presence', params: {'p_online': false});
              } catch (_) {}
              await Supabase.instance.client.auth.signOut();
            },
          );
        },
      );
}

class SignInPage extends StatefulWidget {
  const SignInPage({super.key});
  @override
  State<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final nameController = TextEditingController();
  bool creating = false;
  bool busy = false;
  bool obscure = true;
  String? error;
  String? notice;

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    nameController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final email = emailController.text.trim();
    final password = passwordController.text;
    if (email.isEmpty || !email.contains('@')) {
      setState(() => error = 'Enter a valid email address.');
      return;
    }
    if (creating && password.length < 8) {
      setState(() => error = 'Password must contain at least 8 characters.');
      return;
    }
    if (creating && nameController.text.trim().isEmpty) {
      setState(() => error = 'Enter your display name.');
      return;
    }
    setState(() {
      busy = true;
      error = null;
      notice = null;
    });
    try {
      if (creating) {
        final canRegister = await Supabase.instance.client.rpc('likedin_can_register_account');
        if (canRegister != true) {
          if (mounted) setState(() => error = 'Both Likedin account slots are currently occupied.');
          return;
        }
        final response = await Supabase.instance.client.auth.signUp(
          email: email,
          password: password,
          data: {'display_name': nameController.text.trim()},
          emailRedirectTo: 'com.example.likedin://login-callback/',
        );
        if (response.session == null) {
          if (!mounted) return;
          setState(() => notice =
              'Account request accepted. Check your email and confirm it, then return here to sign in.');
        }
      } else {
        await Supabase.instance.client.auth.signInWithPassword(
          email: email,
          password: password,
        );
      }
    } on AuthException catch (e) {
      final message = e.message;
      var pairFull = message.contains('LIKEDIN_PAIR_FULL') ||
          message.toLowerCase().contains('limited to two');
      // GoTrue may wrap a BEFORE INSERT trigger rejection as the generic
      // "Database error saving new user" message. Re-check slot availability
      // before translating that error; do not mislabel unrelated Auth failures.
      if (creating && !pairFull && message.toLowerCase().contains('database error')) {
        try {
          final available = await Supabase.instance.client.rpc('likedin_can_register_account');
          pairFull = available != true;
        } catch (_) {
          // Preserve the original Auth error when the diagnostic RPC is down.
        }
      }
      if (mounted) {
        setState(() => error = pairFull
            ? 'Both Likedin account slots are currently occupied.'
            : message);
      }
    } catch (e) {
      if (mounted) setState(() => error = 'Could not connect. Check your internet and try again.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _sendPasswordReset() async {
    final email = emailController.text.trim();
    if (email.isEmpty || !email.contains('@')) {
      setState(() => error = 'Enter your account email first.');
      return;
    }
    setState(() { busy = true; error = null; notice = null; });
    try {
      await Supabase.instance.client.auth.resetPasswordForEmail(
        email,
        redirectTo: 'com.example.likedin://login-callback/',
      );
      if (!mounted) return;
      setState(() => notice = 'If an account exists for that email, a password-reset link has been sent.');
    } on AuthException catch (e) {
      if (mounted) setState(() => error = e.message);
    } catch (_) {
      if (mounted) setState(() => error = 'Could not send the reset email. Check your connection and try again.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => AuroraBackdrop(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 430),
                  child: GlassPanel(
                    padding: const EdgeInsets.fromLTRB(22, 24, 22, 22),
                    radius: BorderRadius.circular(28),
                    blur: 10,
                    frosted: true,
                    glow: true,
                    child: AutofillGroup(
                      child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Align(alignment: Alignment.centerLeft, child: LikedinLogo(size: 52)),
                    const SizedBox(height: 22),
                    const Text(
                      'Your space.\nYour people.',
                      style: TextStyle(fontSize: 36, height: 1.06, fontWeight: FontWeight.w800, letterSpacing: -1.3),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Private messages, calls and files, just for the two of you.',
                      style: TextStyle(fontSize: 15, height: 1.4, color: Theme.of(context).hintColor),
                    ),
                    const SizedBox(height: 28),
                    Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: likedinSurfaceRaised(Theme.of(context).brightness),
                        borderRadius: BorderRadius.circular(30),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: _AuthTab(
                              label: 'Sign in',
                              selected: !creating,
                              onTap: () => setState(() {
                                creating = false;
                                passwordController.clear();
                                error = null;
                                notice = null;
                              }),
                            ),
                          ),
                          Expanded(
                            child: _AuthTab(
                              label: 'Create account',
                              selected: creating,
                              onTap: () => setState(() {
                                creating = true;
                                passwordController.clear();
                                error = null;
                                notice = null;
                              }),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 22),
                    Text(
                      creating ? 'Create your Likedin account' : 'Welcome back',
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: -.3),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      creating
                          ? 'Use your own email address. The server enforces the two-account limit.'
                          : 'Sign in from any device using your email.',
                      style: TextStyle(height: 1.4, color: Theme.of(context).hintColor),
                    ),
                    const SizedBox(height: 20),
                    if (creating) ...[
                      _AuthField(
                        controller: nameController,
                        label: 'Your name',
                        hint: 'How should we call you?',
                        icon: Icons.person_outline,
                        autofillHints: const [AutofillHints.name],
                        textInputAction: TextInputAction.next,
                      ),
                      const SizedBox(height: 13),
                    ],
                    _AuthField(
                      controller: emailController,
                      label: 'Email address',
                      hint: 'you@example.com',
                      icon: Icons.email_outlined,
                      keyboardType: TextInputType.emailAddress,
                      autofillHints: const [AutofillHints.email],
                      textInputAction: TextInputAction.next,
                    ),
                    const SizedBox(height: 13),
                    _AuthField(
                      controller: passwordController,
                      label: 'Password',
                      hint: 'At least 8 characters',
                      icon: Icons.lock_outline,
                      obscure: obscure,
                      autofillHints: creating ? const [AutofillHints.newPassword] : const [AutofillHints.password],
                      textInputAction: TextInputAction.done,
                      onSubmitted: (_) => _submit(),
                      suffix: IconButton(
                        tooltip: obscure ? 'Show password' : 'Hide password',
                        onPressed: () => setState(() => obscure = !obscure),
                        icon: Icon(obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                      ),
                    ),
                    if (!creating)
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton(
                          onPressed: busy ? null : _sendPasswordReset,
                          child: const Text('Forgot password?'),
                        ),
                      ),
                    const SizedBox(height: 8),
                    if (error != null) _AuthError(message: error!),
                    if (notice != null)
                      Container(
                        padding: const EdgeInsets.all(12),
                        margin: const EdgeInsets.only(bottom: 12),
                        decoration: BoxDecoration(
                          color: const Color(0xFF16865A).withValues(alpha: .14),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Text(
                          notice!,
                          style: TextStyle(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? const Color(0xFF7FDDB5)
                                : const Color(0xFF176B45),
                            fontSize: 13,
                          ),
                        ),
                      ),
                    GradientButton(
                      onPressed: busy ? null : _submit,
                      child: busy
                          ? const SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                            )
                          : Text(creating ? 'Create account' : 'Sign in'),
                    ),
                    ],
                  ),
                      ),
                    ),
                ),
              ),
            ),
          ),
        ),
      );
}

class _AuthTab extends StatelessWidget {
  const _AuthTab({required this.label, required this.selected, required this.onTap});
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: selected ? likedinSurface(Theme.of(context).brightness) : Colors.transparent,
            borderRadius: BorderRadius.circular(26),
            boxShadow: selected
                ? [const BoxShadow(color: Color(0x14000000), blurRadius: 6, offset: Offset(0, 1))]
                : null,
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontWeight: FontWeight.w700,
              color: selected ? Theme.of(context).colorScheme.primary : Theme.of(context).hintColor,
            ),
          ),
        ),
      );
}

class _AuthField extends StatelessWidget {
  const _AuthField({
    required this.controller,
    required this.label,
    required this.hint,
    required this.icon,
    this.obscure = false,
    this.suffix,
    this.keyboardType,
    this.autofillHints,
    this.textInputAction,
    this.onSubmitted,
  });
  final TextEditingController controller;
  final String label;
  final String hint;
  final IconData icon;
  final bool obscure;
  final Widget? suffix;
  final TextInputType? keyboardType;
  final Iterable<String>? autofillHints;
  final TextInputAction? textInputAction;
  final ValueChanged<String>? onSubmitted;

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
          const SizedBox(height: 7),
          TextField(
            controller: controller,
            obscureText: obscure,
            keyboardType: keyboardType,
            autofillHints: autofillHints,
            textInputAction: textInputAction,
            onSubmitted: onSubmitted,
            autocorrect: false,
            enableSuggestions: !obscure,
            decoration: InputDecoration(
              hintText: hint,
              prefixIcon: Icon(icon, size: 19),
              suffixIcon: suffix,
            ),
          ),
        ],
      );
}

Color _errorTone(BuildContext context) =>
    Theme.of(context).brightness == Brightness.dark ? const Color(0xFFFF9AA0) : const Color(0xFFB42318);

class _AuthError extends StatelessWidget {
  const _AuthError({required this.message});
  final String message;
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(11),
        decoration: BoxDecoration(
          color: const Color(0xFFE5484D).withValues(alpha: .13),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            Icon(Icons.error_outline, color: _errorTone(context), size: 18),
            const SizedBox(width: 8),
            Expanded(child: Text(message, style: TextStyle(color: _errorTone(context), fontSize: 13))),
          ],
        ),
      );
}

class LikedinLogo extends StatelessWidget {
  const LikedinLogo({super.key, this.size = 36});
  final double size;
  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        alignment: Alignment.center,
        decoration: BoxDecoration(color: likedinPrimary(Theme.of(context).brightness), borderRadius: BorderRadius.circular(size * .19)),
        child: Text(
          'in',
          style: TextStyle(
            color: Theme.of(context).colorScheme.onPrimary,
            fontSize: size * .61,
            fontWeight: FontWeight.w800,
            letterSpacing: -1.5,
            height: 1,
          ),
        ),
      );
}

class AppShell extends StatefulWidget {
  const AppShell({
    required this.attachmentVault,
    required this.account,
    required this.onSignOut,
    super.key,
  });
  final AttachmentVaultStore attachmentVault;
  final LikedinAccount account;
  final Future<void> Function() onSignOut;
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> with WidgetsBindingObserver {
  int index = 0;
  final Set<int> _visitedTabs = <int>{0};
  final HiddenChatVault _hiddenChatVault = HiddenChatVault();
  RealtimeChannel? _incomingCallsChannel;
  final Set<String> _handledIncomingCallIds = <String>{};
  bool _incomingDialogOpen = false;
  bool _openingProtectedTab = false;
  bool _hiddenChatSessionUnlocked = false;
  bool _hiddenChatsExist = false;
  bool _hiddenChatsStateReady = false;
  bool _showHiddenChatsPage = false;
  int _hiddenPasswordFailures = 0;
  DateTime? _hiddenPasswordBlockedUntil;

  bool _isHiddenDataTab(int tabIndex) => tabIndex == 1 || tabIndex == 3;

  void _switchTab(int nextIndex) {
    if (!mounted) return;

    // The hidden conversation is entered only from the logo-opened private
    // chat list. Notifications, shortcuts and other routes cannot jump into it.
    if (_hiddenChatsExist && nextIndex == 1) {
      _activateTab(0);
      return;
    }
    // Verify secure metadata before opening Calls, including when a
    // notification arrives before the initial startup check has completed.
    if (nextIndex == 2) {
      unawaited(_requestOpenCallsTab());
      return;
    }
    if (_isHiddenDataTab(nextIndex)) {
      unawaited(_requestOpenProtectedTab(nextIndex));
      return;
    }
    _activateTab(nextIndex);
  }

  void _activateTab(int nextIndex) {
    if (!mounted) return;
    final wasChat = index == 1;
    setState(() {
      index = nextIndex;
      _visitedTabs.add(nextIndex);
    });
    if (wasChat && nextIndex != 1) {
      LikedinNotificationService.instance.setConversationVisible(false);
      unawaited(_recoverIncomingCalls());
    }
  }

  Future<void> _requestOpenCallsTab() async {
    try {
      final hidden = await _hasHiddenConversation();
      if (!mounted) return;
      if (hidden) {
        setState(() {
          _hiddenChatsExist = true;
          _hiddenChatsStateReady = true;
        });
        _activateTab(0);
        return;
      }
      setState(() {
        _hiddenChatsExist = false;
        _hiddenChatsStateReady = true;
      });
      _activateTab(2);
    } catch (error) {
      debugPrint('Calls tab access check failed: $error');
      if (!mounted) return;
      // Fail closed: if hidden-chat status is unknown, keep Calls unavailable.
      setState(() {
        _hiddenChatsExist = true;
        _hiddenChatsStateReady = true;
      });
      _activateTab(0);
    }
  }

  Future<void> _refreshHiddenChatsPresence() async {
    try {
      final hidden = await _hasHiddenConversation();
      if (!mounted) return;
      setState(() {
        _hiddenChatsExist = hidden;
        _hiddenChatsStateReady = true;
        if (!hidden) {
          _showHiddenChatsPage = false;
          _hiddenChatSessionUnlocked = false;
        }
        if (hidden && index == 2) index = 0;
      });
      if (!hidden) _setHiddenChatWindowSecure(false);
    } catch (error) {
      debugPrint('Hidden-chat navigation state could not be read: $error');
      if (!mounted) return;
      // Fail closed: hide Calls and keep the hidden-chat entry available.
      setState(() {
        _hiddenChatsExist = true;
        _hiddenChatsStateReady = true;
        if (index == 2) index = 0;
      });
    }
  }

  void _onHiddenChatsChanged() {
    _setHiddenChatWindowSecure(true);
    if (!mounted) return;
    setState(() {
      _hiddenChatsExist = true;
      _hiddenChatsStateReady = true;
      _showHiddenChatsPage = false;
    });
  }

  void _openHiddenConversation() {
    if (!mounted || !_hiddenChatsExist || !_hiddenChatSessionUnlocked) return;
    setState(() {
      _showHiddenChatsPage = false;
      index = 1;
      _visitedTabs.add(1);
    });
  }

  void _closeHiddenChatsPage() {
    if (!mounted) return;
    setState(() => _showHiddenChatsPage = false);
  }

  Future<void> _changeHiddenChatsPassword() async {
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (uid == null || !mounted) return;
    final result = await HiddenChatPinDialog.show(
      context,
      setup: true,
      title: 'Change hidden-chat password',
    );
    final password = result?.password;
    if (!mounted || password == null) return;
    await _hiddenChatVault.configurePassword(uid, password);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Hidden-chat password changed.')),
      );
    }
  }

  Future<bool> _hasHiddenConversation() async {
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (uid == null) return false;
    return _hiddenChatVault.hasHiddenChats(uid);
  }

  Future<bool> _unlockHiddenChatSession() async {
    final blockedUntil = _hiddenPasswordBlockedUntil;
    if (blockedUntil != null && DateTime.now().isBefore(blockedUntil)) {
      final seconds = blockedUntil.difference(DateTime.now()).inSeconds + 1;
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Too many attempts. Try again in $seconds seconds.')),
        );
      }
      return false;
    }
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (uid == null) return false;
    if (!await _hiddenChatVault.hasPassword(uid)) {
      if (!mounted) return false;
      return _recoverHiddenChatPassword(uid);
    }
    if (!mounted) return false;
    try {
      final prefs = await SharedPreferences.getInstance();
      final bioEnabled = prefs.getBool(likedinHiddenBiometricPrefKey) ?? true;
      if (bioEnabled) {
        final canBio = await _hiddenChatSecurityChannel
            .invokeMethod<bool>('canAuthenticateBiometric') ?? false;
        if (canBio && mounted) {
          final outcome = await _hiddenChatSecurityChannel.invokeMethod<String>(
            'authenticateBiometric',
            const <String, Object>{
              'title': 'Unlock private chat',
              'subtitle': 'Scan your fingerprint or tap Use password',
            },
          );
          if (!mounted) return false;
          if (outcome == 'SUCCESS') {
            _hiddenPasswordFailures = 0;
            _hiddenPasswordBlockedUntil = null;
            _startHiddenChatSession();
            return true;
          }
          if (outcome == 'CANCELLED') {
            return false;
          }
          // USE_PASSWORD / UNAVAILABLE falls through to HiddenChatPinDialog.
        }
      }
    } catch (error) {
      debugPrint('Biometric unlock skipped; falling back to password: $error');
    }
    if (!mounted) return false;
    final passwordResult = await HiddenChatPinDialog.show(context, setup: false);
    if (!mounted || passwordResult == null) return false;
    if (passwordResult.requestRecovery) {
      return _recoverHiddenChatPassword(uid);
    }
    final password = passwordResult.password;
    if (password == null) return false;
    final valid = await _hiddenChatVault.verifyPassword(uid, password);
    if (!valid) {
      _hiddenPasswordFailures++;
      if (_hiddenPasswordFailures >= 5) {
        _hiddenPasswordFailures = 0;
        _hiddenPasswordBlockedUntil = DateTime.now().add(const Duration(seconds: 30));
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(_hiddenPasswordBlockedUntil == null
              ? 'Incorrect hidden-chats password.'
              : 'Too many attempts. Hidden chats are locked for 30 seconds.')),
        );
      }
      return false;
    }
    _hiddenPasswordFailures = 0;
    _hiddenPasswordBlockedUntil = null;
    _startHiddenChatSession();
    return true;
  }

  Future<bool> _recoverHiddenChatPassword(String uid) async {
    String enteredAccountPassword = '';
    final accountPassword = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
          title: const Text('Verify your Likedin account'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Enter your regular Likedin sign-in password to reset the hidden-chats password.'),
              const SizedBox(height: 14),
              TextField(
                autofocus: true,
                obscureText: true,
                autocorrect: false,
                enableSuggestions: false,
                textInputAction: TextInputAction.done,
                onChanged: (value) => enteredAccountPassword = value,
                onSubmitted: (_) => Navigator.of(dialogContext).pop(enteredAccountPassword),
                decoration: const InputDecoration(
                  labelText: 'Likedin account password',
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(dialogContext).pop(enteredAccountPassword),
              child: const Text('Verify'),
            ),
          ],
        ),
    );
    if (!mounted || accountPassword == null || accountPassword.isEmpty) return false;

    try {
      final email = Supabase.instance.client.auth.currentUser?.email ??
          widget.account.likedinId;
      final response = await Supabase.instance.client.auth.signInWithPassword(
        email: email,
        password: accountPassword,
      );
      if (response.user?.id != uid) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Your Likedin account password was not accepted.')),
          );
        }
        return false;
      }
      if (!mounted) return false;
      final newPasswordResult = await HiddenChatPinDialog.show(context, setup: true);
      final newPassword = newPasswordResult?.password;
      if (!mounted || newPassword == null) return false;
      await _hiddenChatVault.configurePassword(uid, newPassword);
      _hiddenPasswordFailures = 0;
      _hiddenPasswordBlockedUntil = null;
      _startHiddenChatSession();
      return true;
    } catch (error) {
      debugPrint('Hidden-chat password recovery failed: $error');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not reset the hidden-chats password. Please try again.')),
        );
      }
      return false;
    }
  }

  void _setHiddenChatWindowSecure(bool secure) {
    unawaited(_hiddenChatSecurityChannel
        .invokeMethod<bool>('setSecure', <String, Object>{'secure': secure})
        .then<void>((_) {})
        .catchError((Object _) {}));
  }

  Future<void> _syncNotificationRedaction(bool redact) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(HiddenChatVault.notificationRedactionPreference, redact);
    } catch (_) {}
  }

  Future<void> _syncHiddenChatWindowSecurity() async {
    try {
      final hasHidden = await _hasHiddenConversation();
      await _syncNotificationRedaction(hasHidden);
      if (!mounted) return;
      setState(() {
        _hiddenChatsExist = hasHidden;
        _hiddenChatsStateReady = true;
        if (hasHidden && index == 2) index = 0;
      });
      _setHiddenChatWindowSecure(hasHidden);
    } catch (error) {
      // Fail closed if secure metadata cannot be read at startup.
      debugPrint('Could not sync hidden-chat screenshot protection: $error');
      await _syncNotificationRedaction(true);
      if (mounted) {
        setState(() {
          _hiddenChatsExist = true;
          _hiddenChatsStateReady = true;
          if (index == 2) index = 0;
        });
        _setHiddenChatWindowSecure(true);
      }
    }
  }

  // This flag is intentionally memory-only. It stays unlocked for the life of
  // this app process and resets naturally after app termination/force-stop.
  void _startHiddenChatSession() {
    // Memory-only session: remains unlocked until this process is destroyed.
    _hiddenChatSessionUnlocked = true;
    _setHiddenChatWindowSecure(true);
  }

  Future<void> _requestOpenProtectedTab(int destination) async {
    if (!mounted || _openingProtectedTab) return;
    _openingProtectedTab = true;
    try {
      final hasHidden = await _hasHiddenConversation();
      if (hasHidden && destination == 1) {
        // Never allow notification taps or legacy routes to bypass the logo
        // entry page, even while the startup secure-store check is in flight.
        if (mounted) {
          _activateTab(0);
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Press the Likedin logo on Home to open the private chat.')),
          );
        }
        return;
      }
      if (hasHidden && !_hiddenChatSessionUnlocked) {
        // Authentication always begins from the Home logo. Files may be
        // opened afterwards in the same unlocked process session.
        if (destination == 3) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Press the Likedin logo on Home to unlock private content first.')),
            );
          }
          return;
        }
        if (!await _unlockHiddenChatSession()) return;
      }
      if (mounted) _activateTab(destination);
    } catch (error) {
      debugPrint('Hidden-data access check failed: $error');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not verify chat security. The conversation remains locked.')),
        );
      }
    } finally {
      _openingProtectedTab = false;
    }
  }

  Future<void> _openHiddenChats() async {
    if (!mounted || _openingProtectedTab || !_hiddenChatsExist) return;
    _openingProtectedTab = true;
    try {
      final uid = Supabase.instance.client.auth.currentUser?.id;
      if (uid == null) return;
      final hiddenIds = await _hiddenChatVault.listHiddenChatIds(uid);
      if (hiddenIds.isEmpty) {
        await _refreshHiddenChatsPresence();
        return;
      }
      if (!_hiddenChatSessionUnlocked && !await _unlockHiddenChatSession()) return;
      if (!mounted) return;
      setState(() {
        index = 0;
        _visitedTabs.add(0);
        _showHiddenChatsPage = true;
      });
    } catch (error) {
      debugPrint('Hidden chats could not be opened: $error');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not open hidden chats. Please try again.')),
        );
      }
    } finally {
      _openingProtectedTab = false;
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    unawaited(_syncHiddenChatWindowSecurity());
    LikedinNotificationService.instance.setOnOpenChat(() {
      if (_hiddenChatsExist) {
        _activateTab(0);
        return;
      }
      _switchTab(1);
    });
    LikedinNotificationService.instance.setOnOpenIncomingCall(_openIncomingCallById);
    LikedinNotificationService.instance.setOnOpenCalls(() {
      if (_hiddenChatsExist) {
        _activateTab(0);
        return;
      }
      _switchTab(2);
    });
    LikedinNotificationService.instance.registerCurrentToken();
    _loadAccountProfilePhoto();
    _watchIncomingCalls();
    Future<void>.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        unawaited(AppUpdater.checkAutomatically(context, currentVersion: likedinVersion));
        unawaited(StoragePage.enforceCacheQuota());
      }
    });
  }

  Future<void> _loadAccountProfilePhoto() async {
    try {
      final client = Supabase.instance.client;
      final uid = client.auth.currentUser?.id;
      if (uid == null) {
        likedinProfilePhotoPath.value = null;
        return;
      }
      final prefs = await SharedPreferences.getInstance();
      final prefKey = '${likedinProfilePhotoPreferenceKey}_$uid';
      final remoteMarkerKey = '${likedinProfilePhotoPreferenceKey}_remote_$uid';
      final localPath = prefs.getString(prefKey);
      final hasLocalFile =
          localPath != null && localPath.isNotEmpty && await File(localPath).exists();
      if (hasLocalFile && mounted) {
        likedinProfilePhotoPath.value = localPath;
      }

      // Always validate against the latest remote avatar_path so changes made
      // on another device propagate instead of staying stale indefinitely.
      final remotePath = await RealtimeMessagingService(client).getOwnProfileAvatarPath();
      if (remotePath == null || remotePath.isEmpty) {
        await prefs.remove(remoteMarkerKey);
        if (hasLocalFile) {
          await prefs.remove(prefKey);
          try { await File(localPath).delete(); } catch (_) {}
        }
        if (mounted) {
          likedinProfilePhotoPath.value = null;
        }
        return;
      }

      final cachedRemotePath = prefs.getString(remoteMarkerKey);
      if (hasLocalFile && cachedRemotePath == remotePath) {
        return;
      }

      final cached = await SharedMediaService(client).cachedFile(<String, dynamic>{
        'path': remotePath,
        'name': p.basename(remotePath),
      });
      final support = await getApplicationSupportDirectory();
      final ext = p.extension(remotePath).isNotEmpty ? p.extension(remotePath) : '.jpg';
      final restored = File(
        '${support.path}/likedin_profile_photo_${uid}_${DateTime.now().millisecondsSinceEpoch}$ext',
      );
      await cached.copy(restored.path);
      await prefs.setString(prefKey, restored.path);
      await prefs.setString(remoteMarkerKey, remotePath);
      if (hasLocalFile && localPath != restored.path) {
        try {
          await FileImage(File(localPath)).evict();
          await File(localPath).delete();
        } catch (_) {}
      }
      if (mounted) {
        likedinProfilePhotoPath.value = restored.path;
      }
    } catch (error) {
      debugPrint('Could not load account profile photo: $error');
    }
  }

  @override
  void didHaveMemoryPressure() {
    // Release decoded bitmaps promptly on lower-memory Android devices.
    final cache = PaintingBinding.instance.imageCache;
    cache.clear();
    cache.clearLiveImages();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Deliberately do not lock on pause/background: a successful unlock remains
    // valid until this AppShell process is destroyed (including force-stop).
    // Reconcile incoming calls after the app returns to the foreground.
    if (state == AppLifecycleState.resumed) {
      unawaited(_recoverIncomingCalls());
    }
  }

  Future<void> _openIncomingCallById(String callId) async {
    try {
      final row = await Supabase.instance.client
          .from('likedin_calls')
          .select()
          .eq('id', callId)
          .eq('status', 'ringing')
          .maybeSingle();
      if (row != null && mounted) await _showIncomingCall(Map<String, dynamic>.from(row));
    } catch (e) {
      debugPrint('Could not open call from notification: $e');
    }
  }

  Future<void> _watchIncomingCalls() async {
    final client = Supabase.instance.client;
    final uid = client.auth.currentUser?.id;
    if (uid == null) return;
    _incomingCallsChannel = client
        .channel('likedin-incoming-calls-$uid')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'likedin_calls',
          filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'callee_id', value: uid),
          callback: (payload) {
            final row = payload.newRecord;
            if (row['status'] == 'ringing') _showIncomingCall(Map<String, dynamic>.from(row));
          },
        )
      ..subscribe();
    await _recoverIncomingCalls();
  }

  Future<void> _recoverIncomingCalls() async {
    final client = Supabase.instance.client;
    final uid = client.auth.currentUser?.id;
    if (uid == null) return;
    try {
      final pending = await client
          .from('likedin_calls')
          .select()
          .eq('callee_id', uid)
          .eq('status', 'ringing')
          .order('created_at', ascending: false)
          .limit(3);
      for (final row in pending) {
        await _showIncomingCall(Map<String, dynamic>.from(row));
        if (_incomingDialogOpen) break;
      }
    } catch (e) {
      debugPrint('Incoming-call recovery query failed: $e');
    }
  }

  Future<void> _showIncomingCall(Map<String, dynamic> callRow) async {
    // When the conversation is already visible, its inline invitation owns the
    // accept/decline action and starts the ringtone alert.
    if (LikedinNotificationService.instance.isConversationVisible) return;
    final id = callRow['id']?.toString();
    if (!mounted || id == null || _incomingDialogOpen || !_handledIncomingCallIds.add(id)) return;
    await LikedinNotificationService.instance.cancelIncomingCall(id);
    final client = Supabase.instance.client;
    var ownsIncomingDialog = false;
    var ownsGlobalDialog = false;
    try {
      Map<String, dynamic>? offer;
      for (var attempt = 0; attempt < 60 && offer == null; attempt++) {
        final rows = await client
            .from('likedin_call_signals')
            .select('payload')
            .eq('call_id', id)
            .eq('kind', 'offer')
            .order('created_at', ascending: false)
            .limit(1);
        if (rows.isNotEmpty) offer = Map<String, dynamic>.from(rows.first['payload'] as Map);
        if (offer == null) {
          final latest = await client.from('likedin_calls').select('status').eq('id', id).maybeSingle();
          if (latest == null || latest['status'] != 'ringing') break;
          await Future<void>.delayed(const Duration(milliseconds: 500));
        }
      }
      if (offer == null || !mounted) {
        _handledIncomingCallIds.remove(id);
        return;
      }
      if (_globalCallDialogActive) {
        _handledIncomingCallIds.remove(id);
        return;
      }
      _incomingDialogOpen = true;
      ownsIncomingDialog = true;
      _globalCallDialogActive = true;
      ownsGlobalDialog = true;
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (_) => _IncomingCallDialog(
          callId: id,
          callerId: callRow['caller_id'].toString(),
          offer: offer!,
          withVideo: callRow['call_type']?.toString().toLowerCase() == 'video',
        ),
      );
    } catch (e) {
      debugPrint('Could not present incoming call: $e');
      _handledIncomingCallIds.remove(id);
    } finally {
      if (ownsIncomingDialog) _incomingDialogOpen = false;
      if (ownsGlobalDialog) _globalCallDialogActive = false;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    final channel = _incomingCallsChannel;
    if (channel != null) Supabase.instance.client.removeChannel(channel);
    super.dispose();
  }

  Future<void> _pickProfilePhoto() async {
    File? destination;
    File? stagedSource;
    var stage = 'opening the photo picker';
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: const ['jpg', 'jpeg', 'png', 'webp'],
        allowMultiple: false,
        withData: false,
        withReadStream: true,
      );
      if (result == null) return;

      stage = 'reading the selected photo';
      final selectedFile = result.files.single;
      final selectedPath = selectedFile.path;
      late final File source;
      if (selectedPath != null && selectedPath.isNotEmpty && !selectedPath.startsWith('content://') &&
          await File(selectedPath).exists()) {
        source = File(selectedPath);
      } else {
        final stream = selectedFile.readStream;
        if (stream == null) {
          throw StateError('Android could not read this photo. Please choose it again from Gallery or Files.');
        }
        final staged = await SharedMediaService.copyStreamToTemporaryFile(
          stream,
          selectedFile.name,
          maxSizeBytes: 15 * 1024 * 1024,
        );
        stagedSource = staged;
        source = staged;
      }

      final sourceSize = await source.length();
      if (sourceSize <= 0 || sourceSize > 15 * 1024 * 1024) {
        throw StateError('Choose a profile photo smaller than 15 MB.');
      }

      stage = 'preparing the photo editor';
      final sourceBytes = await source.readAsBytes();
      final sourceMime = await SharedMediaService.detectMimeType(
        source,
        displayName: selectedFile.name,
      );
      final sourceExtension = SharedMediaService.extensionForMime(sourceMime)
              ?.replaceFirst('.', '') ??
          selectedFile.extension?.toLowerCase() ??
          p.extension(selectedPath ?? '').replaceFirst('.', '').toLowerCase();
      if (!const {'image/jpeg', 'image/png', 'image/webp'}.contains(sourceMime)) {
        throw StateError('Choose a JPG, PNG or WebP photo.');
      }
      if (!mounted) return;
      final croppedBytes = await Navigator.of(context).push<Uint8List>(
        MaterialPageRoute<Uint8List>(
          fullscreenDialog: true,
          builder: (_) => ProfilePhotoEditorPage(
            sourceBytes: sourceBytes,
            sourceExtension: sourceExtension,
          ),
        ),
      );
      if (croppedBytes == null || croppedBytes.isEmpty || !mounted) return;
      if (croppedBytes.length > 15 * 1024 * 1024) {
        throw StateError('The edited photo is too large. Please crop it again.');
      }

      stage = 'checking your signed-in account';
      final client = Supabase.instance.client;
      final uid = client.auth.currentUser?.id;
      if (uid == null) {
        throw StateError('Your session has expired. Sign in again before changing your profile photo.');
      }
      final prefs = await SharedPreferences.getInstance();
      final accountPhotoKey = '${likedinProfilePhotoPreferenceKey}_$uid';
      final previousLocalPath = prefs.getString(accountPhotoKey);

      // Reading the old avatar is only needed for post-success cleanup. It must
      // never block a new upload: the RPC below is the authoritative profile
      // update, and an unreadable old path can safely be left for later cleanup.
      String? previousRemotePath;
      try {
        final oldProfile = await client
            .from('profiles')
            .select('avatar_path')
            .eq('user_id', uid)
            .maybeSingle();
        previousRemotePath = oldProfile?['avatar_path']?.toString();
      } catch (error, stackTrace) {
        debugPrint('[ProfilePhoto] Could not read previous avatar path; continuing upload: $error');
        debugPrintStack(stackTrace: stackTrace);
      }

      stage = 'saving the edited photo on this device';
      final support = await getApplicationSupportDirectory();
      final outputFile = File(
        '${support.path}/likedin_profile_photo_${uid}_${DateTime.now().millisecondsSinceEpoch}.jpg',
      );
      destination = outputFile;
      await outputFile.writeAsBytes(croppedBytes, flush: true);
      await FileImage(outputFile).evict();

      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final objectPath = '$uid/avatars/profile_$timestamp.jpg';
      stage = 'uploading the photo to private Storage';
      await client.storage.from('likedin-media').upload(
        objectPath,
        outputFile,
        fileOptions: const FileOptions(
          cacheControl: '86400',
          upsert: false,
          contentType: 'image/jpeg',
        ),
      );

      stage = 'saving the new avatar path to your profile';
      try {
        await RealtimeMessagingService(client).setProfileAvatarPath(objectPath);
      } catch (error, stackTrace) {
        // Do not leave an orphaned object when the profile update is rejected.
        try {
          await client.storage.from('likedin-media').remove([objectPath]);
        } catch (cleanupError) {
          debugPrint('[ProfilePhoto] Failed to remove uncommitted upload: $cleanupError');
        }
        debugPrint('[ProfilePhoto] Profile avatar RPC failed: $error');
        debugPrintStack(stackTrace: stackTrace);
        rethrow;
      }

      // Commit local state only after Storage and the profile row both update.
      stage = 'saving the profile photo on this device';
      await prefs.setString(accountPhotoKey, outputFile.path);
      await prefs.setString('${likedinProfilePhotoPreferenceKey}_remote_$uid', objectPath);
      likedinProfilePhotoPath.value = outputFile.path;
      if (previousLocalPath != null && previousLocalPath != outputFile.path) {
        final previousFile = File(previousLocalPath);
        await FileImage(previousFile).evict();
        if (await previousFile.exists()) {
          try {
            await previousFile.delete();
          } catch (error) {
            debugPrint('[ProfilePhoto] Could not remove previous local avatar: $error');
          }
        }
      }
      if (previousRemotePath != null &&
          previousRemotePath.isNotEmpty &&
          previousRemotePath != objectPath &&
          previousRemotePath.startsWith('$uid/avatars/')) {
        try {
          await client.storage.from('likedin-media').remove([previousRemotePath]);
        } catch (error) {
          // The new avatar is already committed. A stale old object is harmless
          // and must not turn a successful profile update into a reported failure.
          debugPrint('[ProfilePhoto] Could not remove previous remote avatar: $error');
        }
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Profile photo updated and synced to your friend.')),
        );
      }
    } catch (error, stackTrace) {
      debugPrint('[ProfilePhoto] Failed while $stage: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (destination != null &&
          likedinProfilePhotoPath.value != destination.path) {
        try {
          if (await destination.exists()) await destination.delete();
        } catch (cleanupError) {
          debugPrint('[ProfilePhoto] Could not remove temporary edited photo: $cleanupError');
        }
      }
      if (mounted) {
        final rawDetails = error.toString().trim();
        final details = rawDetails.isEmpty
            ? 'The server returned no additional error details.'
            : (rawDetails.length > 240 ? '${rawDetails.substring(0, 240)}…' : rawDetails);
        final message = error is StateError
            ? error.message.toString()
            : 'Profile photo failed while $stage. $details';
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(message),
            duration: const Duration(seconds: 8),
          ),
        );
      }
    } finally {
      if (stagedSource != null) {
        try {
          if (await stagedSource.exists()) await stagedSource.delete();
        } catch (cleanupError) {
          debugPrint('[ProfilePhoto] Could not remove temporary picker source: $cleanupError');
        }
      }
    }
  }

  Future<void> _openBitmojiStudio() async {
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (uid == null || !mounted) return;
    final own = await ChatAvatarConfig.loadOwn(uid);
    if (!mounted) return;
    final updatedOwn = await Navigator.of(context).push<ChatAvatarConfig>(
      MaterialPageRoute(builder: (_) => ChatAvatarStudioPage(initialOwn: own)),
    );
    if (updatedOwn != null) {
      await ChatAvatarConfig.saveOwn(uid, updatedOwn);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Your Bitmoji has been updated!')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final callsTabVisible = _hiddenChatsStateReady && !_hiddenChatsExist;
    final pages = List<Widget>.generate(6, (pageIndex) {
      if (!_visitedTabs.contains(pageIndex)) return const SizedBox.shrink();
      late final Widget page;
      switch (pageIndex) {
        case 0:
          page = _showHiddenChatsPage
              ? HiddenChatsPage(
                  onBack: _closeHiddenChatsPage,
                  onOpenChat: _openHiddenConversation,
                  onUnhidden: _refreshHiddenChatsPresence,
                  onChangePassword: () => unawaited(_changeHiddenChatsPassword()),
                )
              : HomePage(
                  displayName: widget.account.displayName,
                  onOpenChat: () => _switchTab(1),
                  onHiddenChatsChanged: _onHiddenChatsChanged,
                  isActive: index == 0,
                );
          break;
        case 1:
          page = ChatPage(attachmentVault: widget.attachmentVault, isActive: index == 1, onBack: () => _switchTab(0));
          break;
        case 2:
          page = _hiddenChatsExist ? const SizedBox.shrink() : const CallsPage();
          break;
        case 3:
          page = FilesPage(
            store: widget.attachmentVault,
            isActive: index == 3,
            allowHiddenConversationMedia: _hiddenChatSessionUnlocked,
          );
          break;
        case 4:
          page = SettingsPage(
            attachmentVault: widget.attachmentVault,
          );
          break;
        default:
          page = ProfilePage(
            displayName: widget.account.displayName,
            email: widget.account.likedinId,
            photoPath: likedinProfilePhotoPath,
            onEditPhoto: _pickProfilePhoto,
            onOpenBitmoji: _openBitmojiStudio,
            onSignOut: () => widget.onSignOut(),
          );
      }
      final isCurrent = index == pageIndex;
      final tabDur = LikedinAppearance.reduceMotion.value
          ? Duration.zero
          : const Duration(milliseconds: 210);
      return TickerMode(
        enabled: isCurrent,
        child: AnimatedSlide(
          offset: isCurrent ? Offset.zero : const Offset(0, 0.018),
          duration: tabDur,
          curve: Curves.easeOutCubic,
          child: AnimatedOpacity(
            opacity: isCurrent ? 1.0 : 0.0,
            duration: tabDur,
            curve: Curves.easeOut,
            child: page,
          ),
        ),
      );
    }, growable: false);
    return PopScope<Object?>(
      canPop: index == 0 && !_showHiddenChatsPage,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop || !mounted) return;
        if (_showHiddenChatsPage) {
          _closeHiddenChatsPage();
        } else if (index != 0) {
          _switchTab(0);
        }
      },
      child: AuroraBackdrop(
        child: Scaffold(
          extendBody: index != 1,
          backgroundColor: Colors.transparent,
          body: SafeArea(
            bottom: index == 1,
            child: Column(
              children: [
                if (index != 1)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 8, 12, 2),
                    child: Row(
                      children: [
                        Tooltip(
                          message: _hiddenChatsExist && index == 0
                              ? 'Open private chat'
                              : 'Likedin home',
                          child: InkWell(
                            borderRadius: BorderRadius.circular(10),
                            onTap: index == 0 && _hiddenChatsExist
                                ? _openHiddenChats
                                : null,
                            child: const Padding(
                              padding: EdgeInsets.all(2),
                              child: LikedinLogo(size: 34),
                            ),
                          ),
                        ),
                        const SizedBox(width: 11),
                        const Expanded(
                          child: Text(
                            'Likedin',
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w800,
                              letterSpacing: -.6,
                            ),
                          ),
                        ),
                        if (index == 4)
                          IconButton(
                            tooltip: 'Back to home',
                            onPressed: () => _switchTab(0),
                            icon: const Icon(Icons.close_rounded),
                          )
                        else
                          IconButton(
                            tooltip: 'Settings',
                            onPressed: () => _switchTab(4),
                            icon: const Icon(Icons.settings_outlined),
                          ),
                      ],
                    ),
                  ),
                Expanded(child: IndexedStack(index: index, children: pages)),
              ],
            ),
          ),
          bottomNavigationBar: index == 1
              ? null
              : SafeArea(
                  top: false,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 4, 20, 12),
                    child: GlassPanel(
                      radius: BorderRadius.circular(34),
                      frosted: true,
                      blur: 12,
                      glow: true,
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                      child: Builder(
                        builder: (context) {
                          final brightness = Theme.of(context).brightness;
                          final primary = likedinPrimary(brightness);
                          final mutedColor = dark ? const Color(0xFFD2DDF0) : const Color(0xFF475569);
                          final items = <({int tab, IconData icon, IconData activeIcon, String label})>[
                            (
                              tab: 0,
                              icon: Icons.chat_bubble_outline_rounded,
                              activeIcon: Icons.chat_bubble_rounded,
                              label: 'Chats',
                            ),
                            if (callsTabVisible)
                              (
                                tab: 2,
                                icon: Icons.call_outlined,
                                activeIcon: Icons.call_rounded,
                                label: 'Calls',
                              ),
                            (
                              tab: 3,
                              icon: Icons.perm_media_outlined,
                              activeIcon: Icons.perm_media_rounded,
                              label: 'Files',
                            ),
                            (
                              tab: 5,
                              icon: Icons.person_outline_rounded,
                              activeIcon: Icons.person_rounded,
                              label: 'Profile',
                            ),
                          ];
                          final activeTab = index <= 1 ? 0 : index;
                          return Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: items.map((item) {
                              final selected = activeTab == item.tab;
                              return Expanded(
                                child: LikedinPressScale(
                                  pressedScale: 0.92,
                                  child: InkWell(
                                    borderRadius: BorderRadius.circular(24),
                                    onTap: () {
                                      HapticFeedback.selectionClick();
                                      _switchTab(item.tab);
                                    },
                                    child: AnimatedContainer(
                                      duration: LikedinAppearance.reduceMotion.value
                                          ? Duration.zero
                                          : const Duration(milliseconds: 200),
                                      curve: Curves.easeOutCubic,
                                      padding: const EdgeInsets.symmetric(vertical: 8),
                                      decoration: BoxDecoration(
                                        color: selected
                                            ? (dark
                                                ? Colors.white.withValues(alpha: .15)
                                                : Colors.white.withValues(alpha: .72))
                                            : Colors.transparent,
                                        gradient: selected
                                            ? LinearGradient(
                                                begin: Alignment.topLeft,
                                                end: Alignment.bottomRight,
                                                colors: dark
                                                    ? [
                                                        Colors.white.withValues(alpha: .22),
                                                        primary.withValues(alpha: .20),
                                                      ]
                                                    : [
                                                        Colors.white.withValues(alpha: .94),
                                                        primary.withValues(alpha: .14),
                                                      ],
                                              )
                                            : null,
                                        border: selected
                                            ? Border.all(
                                                color: dark
                                                    ? Colors.white.withValues(alpha: .34)
                                                    : Colors.white.withValues(alpha: .96),
                                                width: 1.0,
                                              )
                                            : null,
                                        boxShadow: selected
                                            ? [
                                                BoxShadow(
                                                  color: primary.withValues(alpha: dark ? .24 : .14),
                                                  blurRadius: 12,
                                                  spreadRadius: -3,
                                                ),
                                              ]
                                            : null,
                                        borderRadius: BorderRadius.circular(26),
                                      ),
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Icon(
                                            selected ? item.activeIcon : item.icon,
                                            size: 22,
                                            color: selected ? primary : mutedColor,
                                          ),
                                          const SizedBox(height: 3),
                                          Text(
                                            item.label,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                              fontSize: 11,
                                              fontWeight: selected ? FontWeight.w800 : FontWeight.w500,
                                              color: selected ? primary : mutedColor,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            }).toList(),
                          );
                        },
                      ),
                    ),
                  ),
                ),
        ),
      ),
    );
  }
}

class _VoiceMessagePlayer extends StatefulWidget {
  const _VoiceMessagePlayer({super.key, required this.payload});
  final Map<String, dynamic> payload;
  @override
  State<_VoiceMessagePlayer> createState() => _VoiceMessagePlayerState();
}

class _VoiceMessagePlayerState extends State<_VoiceMessagePlayer>
    with AutomaticKeepAliveClientMixin<_VoiceMessagePlayer> {
  static AudioPlayer? _activePlayer;
  AudioPlayer? _player;
  StreamSubscription<PlayerState>? _stateSubscription;
  final ValueNotifier<double?> _pendingSeekMsNotifier = ValueNotifier<double?>(null);
  bool _loading = false;
  bool _loaded = false;
  double get _speed => likedinVoiceSpeed.value;
  String? _error;

  @override
  void initState() {
    super.initState();
    likedinVoiceSpeed.addListener(_onGlobalSpeedChanged);
  }

  void _onGlobalSpeedChanged() {
    final player = _player;
    if (player != null) {
      unawaited(player.setSpeed(likedinVoiceSpeed.value).catchError((_) {}));
    }
    if (mounted) setState(() {});
  }

  AudioPlayer _ensurePlayer() {
    final existing = _player;
    if (existing != null) return existing;
    final created = AudioPlayer();
    _player = created;
    _stateSubscription = created.playerStateStream.listen((state) {
      if (state.processingState == ProcessingState.completed) {
        created.pause();
        created.seek(Duration.zero);
      }
      // Re-evaluate keep-alive whenever playback starts, pauses or finishes.
      if (mounted) {
        updateKeepAlive();
        setState(() {});
      }
    });
    return created;
  }

  /// Keep the row (and its player) alive while a clip is playing or paused
  /// part-way, so scrolling it out of the lazy list does not stop playback.
  /// Idle rows are released as before.
  @override
  bool get wantKeepAlive {
    final player = _player;
    return _loaded &&
        player != null &&
        (player.playing ||
            (player.position > Duration.zero &&
                player.processingState != ProcessingState.completed));
  }

  Future<void> _load() async {
    if (_loading || _loaded) return;
    setState(() { _loading = true; _error = null; });
    try {
      final file = await SharedMediaService(Supabase.instance.client).cachedFile(widget.payload);
      final player = _ensurePlayer();
      await player.setFilePath(file.path);
      _loaded = true;
    } catch (e) {
      _error = e.toString();
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _cycleSpeed() async {
    final next = _speed == 1.0 ? 1.5 : _speed == 1.5 ? 2.0 : 1.0;
    likedinVoiceSpeed.value = next;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setDouble(likedinVoiceSpeedPrefKey, next);
    } catch (_) {}
    final player = _player;
    if (player == null) return;
    try {
      await player.setSpeed(next);
    } catch (_) {}
  }

  @override
  void dispose() {
    likedinVoiceSpeed.removeListener(_onGlobalSpeedChanged);
    final player = _player;
    if (player != null) {
      if (identical(_activePlayer, player)) {
        _activePlayer = null;
      }
      _stateSubscription?.cancel();
      player.dispose();
    }
    _pendingSeekMsNotifier.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return SizedBox(
        width: (MediaQuery.sizeOf(context).width * .66).clamp(190.0, 320.0).toDouble(),
        child: Row(
          children: [
            IconButton.filled(
              onPressed: _loading
                  ? null
                  : () async {
                      if (!_loaded) {
                        await _load();
                        if (!_loaded) return;
                      }
                      final player = _ensurePlayer();
                      if (player.playing) {
                        await player.pause();
                      } else {
                        final previous = _activePlayer;
                        if (previous != null && !identical(previous, player)) {
                          try {
                            await previous.pause();
                          } catch (_) {}
                        }
                        _activePlayer = player;
                        if (player.processingState == ProcessingState.completed) {
                          await player.seek(Duration.zero);
                        }
                        await player.setSpeed(_speed);
                        await player.play();
                      }
                      if (mounted) setState(() {});
                    },
              icon: Icon((_player?.playing ?? false) ? Icons.pause : Icons.play_arrow),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Expanded(
                        child: Text('Voice message', style: TextStyle(fontWeight: FontWeight.w700)),
                      ),
                      InkWell(
                        onTap: _cycleSpeed,
                        borderRadius: BorderRadius.circular(8),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          child: Text(
                            '${_speed == _speed.roundToDouble() ? _speed.toInt() : _speed}x',
                            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: likedinPrimary(Theme.of(context).brightness)),
                          ),
                        ),
                      ),
                    ],
                  ),
                  if (_loading)
                    const LinearProgressIndicator(minHeight: 2)
                  else if (_error != null)
                    const Text(
                      'Audio unavailable',
                      style: TextStyle(fontSize: 12, color: Colors.red),
                    ),
                  if (_error != null)
                    TextButton(onPressed: _load, child: const Text('Retry download'))
                  else if (_loaded && _player != null)
                    StreamBuilder<Duration>(
                      stream: _player!.positionStream,
                      builder: (_, snap) {
                        final pos = snap.data ?? Duration.zero;
                        final total = _player?.duration ?? Duration.zero;
                        return Column(
                          children: [
                            ValueListenableBuilder<double?>(
                              valueListenable: _pendingSeekMsNotifier,
                              builder: (context, pendingSeekMs, __) {
                                final totalMs = total.inMilliseconds;
                                final currentMs = (pendingSeekMs ?? pos.inMilliseconds.toDouble())
                                    .clamp(0.0, totalMs > 0 ? totalMs.toDouble() : 1.0);
                                final progress = totalMs > 0 ? (currentMs / totalMs).clamp(0.0, 1.0) : 0.0;
                                final primary = likedinPrimary(Theme.of(context).brightness);
                                final inactive = likedinMutedText(Theme.of(context).brightness).withValues(alpha: .32);
                                const bars = <double>[
                                  .35, .65, .45, .85, .60, .95, .50, .75, .40, .90,
                                  .70, .55, .80, .45, .95, .65, .50, .85, .60, .40,
                                  .75, .55, .45, .30,
                                ];
                                return LayoutBuilder(
                                  builder: (context, constraints) {
                                    void seekAt(double dx) {
                                      if (totalMs <= 0 || constraints.maxWidth <= 0) return;
                                      final ratio = (dx / constraints.maxWidth).clamp(0.0, 1.0);
                                      _pendingSeekMsNotifier.value = ratio * totalMs;
                                    }
                                    Future<void> commitSeek() async {
                                      final target = _pendingSeekMsNotifier.value;
                                      if (target != null) {
                                        await _player?.seek(Duration(milliseconds: target.round()));
                                        if (mounted) _pendingSeekMsNotifier.value = null;
                                      }
                                    }
                                    return GestureDetector(
                                      behavior: HitTestBehavior.opaque,
                                      onTapDown: (d) {
                                        seekAt(d.localPosition.dx);
                                        unawaited(commitSeek());
                                      },
                                      onHorizontalDragUpdate: (d) => seekAt(d.localPosition.dx),
                                      onHorizontalDragEnd: (_) => unawaited(commitSeek()),
                                      onHorizontalDragCancel: () => _pendingSeekMsNotifier.value = null,
                                      child: SizedBox(
                                        height: 30,
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: List.generate(bars.length, (i) {
                                            final filled = (i / bars.length) <= progress;
                                            return Container(
                                              width: 3,
                                              height: 6 + 20 * bars[i],
                                              decoration: BoxDecoration(
                                                color: filled ? primary : inactive,
                                                borderRadius: BorderRadius.circular(3),
                                              ),
                                            );
                                          }),
                                        ),
                                      ),
                                    );
                                  },
                                );
                              },
                            ),
                            Text(
                              '${_fmt(pos)} / ${_fmt(total)}',
                              style: TextStyle(fontSize: 12, color: likedinMutedText(Theme.of(context).brightness)),
                            ),
                          ],
                        );
                      },
                    ),
                ],
              ),
            ),
          ],
        ),
      );
  }

  String _fmt(Duration d) => '${d.inMinutes}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';
}

class _ChatMediaMessage extends StatefulWidget {
  const _ChatMediaMessage({
    super.key,
    required this.payload,
    required this.name,
    required this.sizeLabel,
  });
  final Map<String, dynamic> payload;
  final String name;
  final String sizeLabel;
  @override
  State<_ChatMediaMessage> createState() => _ChatMediaMessageState();
}

class _ChatMediaMessageState extends State<_ChatMediaMessage> {
  File? _file;
  File? _thumbFile;
  bool _loading = false;
  String? _error;
  int _loadGeneration = 0;

  bool get _isVideo => widget.payload['kind'] == 'video';
  bool get _isGif => widget.payload['animated'] == true ||
      widget.name.toLowerCase().endsWith('.gif') || widget.payload['mime'] == 'image/gif';

  @override
  void initState() {
    super.initState();
    // Directly download photos, GIFs, and videos automatically.
    _loadFile();
  }

  @override
  void didUpdateWidget(covariant _ChatMediaMessage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.payload['path'] != widget.payload['path'] ||
        oldWidget.payload['kind'] != widget.payload['kind']) {
      _loadGeneration++;
      _file = null;
      _thumbFile = null;
      _error = null;
      _loading = false;
      _loadFile();
    }
  }

  Future<void> _loadThumbnailSidecar(int generation) async {
    final sidecar = widget.payload['thumbnail_path']?.toString();
    if (sidecar == null || sidecar.isEmpty) return;
    try {
      final thumb = await SharedMediaService(Supabase.instance.client).cachedFile(<String, dynamic>{
        '__likedin_media_v1': true,
        'path': sidecar,
        'name': 'video-thumb.jpg',
        'mime': 'image/jpeg',
        'kind': 'image',
      });
      if (mounted && generation == _loadGeneration) {
        setState(() => _thumbFile = thumb);
      }
    } catch (_) {}
  }

  Future<void> _loadFile() async {
    if (_loading || _file != null) return;
    final generation = ++_loadGeneration;
    setState(() { _loading = true; _error = null; });
    if (_isVideo) {
      unawaited(_loadThumbnailSidecar(generation));
    }
    Object? lastError;
    try {
      final media = SharedMediaService(Supabase.instance.client);
      for (var attempt = 0; attempt < 3; attempt++) {
        try {
          final payload = Map<String, dynamic>.from(widget.payload);
          final file = await media.cachedFile(payload);
          if (!mounted || generation != _loadGeneration) return;
          setState(() => _file = file);
          return;
        } catch (error) {
          lastError = error;
          if (generation != _loadGeneration) return;
          if (attempt < 2) {
            await Future<void>.delayed(Duration(milliseconds: 350 * (attempt + 1)));
          }
        }
      }
      if (mounted && generation == _loadGeneration) {
        setState(() => _error = lastError?.toString() ?? 'Media could not be loaded.');
      }
    } finally {
      if (mounted && generation == _loadGeneration) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final file = _file;
    if (file == null) {
      if (_error != null) {
        return _mediaError(
          _isVideo
              ? 'Video unavailable. Tap to retry.'
              : _isGif
                  ? 'GIF unavailable. Tap to retry.'
                  : 'Photo unavailable. Tap to retry.',
          _loadFile,
        );
      }
      return ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: SizedBox(
          width: 270,
          height: 184,
          child: Stack(
            fit: StackFit.expand,
            children: [
              if (_thumbFile != null)
                Image.file(
                  _thumbFile!,
                  fit: BoxFit.cover,
                  cacheWidth: 540,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                )
              else
                DecoratedBox(
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: .65),
                  ),
                ),
              ColoredBox(
                color: Colors.black.withValues(alpha: _thumbFile != null ? 0.34 : 0.04),
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(
                        width: 28,
                        height: 28,
                        child: CircularProgressIndicator(
                          strokeWidth: 2.5,
                          color: _thumbFile != null ? Colors.white : null,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _isVideo
                            ? 'Downloading video…'
                            : _isGif
                                ? 'Downloading GIF…'
                                : 'Loading photo…',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: _thumbFile != null ? Colors.white : null,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    if (_isVideo) {
      return _ChatVideoPreview(
        file: file,
        thumbnailFile: _thumbFile,
        title: widget.name,
        payload: widget.payload,
      );
    }

    return GestureDetector(
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => _LikedinImageViewer(
            file: file,
            title: _isGif ? 'GIF' : 'Photo',
            payload: widget.payload,
          ),
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 300, maxHeight: 360, minWidth: 180),
          child: Stack(
            children: [
              Image.file(
                file,
                fit: _isGif ? BoxFit.contain : BoxFit.cover,
                width: 300,
                cacheWidth: _isGif ? null : 720,
                gaplessPlayback: true,
                frameBuilder: (context, child, frame, sync) => frame != null
                    ? child
                    : const SizedBox(width: 270, height: 190, child: Center(child: CircularProgressIndicator())),
                errorBuilder: (_, __, ___) => const SizedBox(
                  width: 270,
                  height: 150,
                  child: Center(child: Icon(Icons.broken_image_outlined, size: 42)),
                ),
              ),
              if (_isGif)
                Positioned(
                  left: 8,
                  top: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: .58),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      'GIF',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.6,
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _mediaError(String message, VoidCallback retry) => SizedBox(
        width: 270,
        child: TextButton.icon(onPressed: retry, icon: const Icon(Icons.refresh), label: Text(message)),
      );
}

class _ChatVideoPreview extends StatelessWidget {
  const _ChatVideoPreview({
    required this.file,
    required this.title,
    this.thumbnailFile,
    this.payload,
  });
  final File file;
  final String title;
  final File? thumbnailFile;
  final Map<String, dynamic>? payload;

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => _LikedinVideoViewer(
              file: file,
              title: title,
              payload: payload,
            ),
          ),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: SizedBox(
            width: 300,
            height: 184,
            child: Stack(
              fit: StackFit.expand,
              children: [
                if (thumbnailFile != null)
                  Image.file(
                    thumbnailFile!,
                    fit: BoxFit.cover,
                    cacheWidth: 640,
                    errorBuilder: (_, __, ___) => const DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [Color(0xFF172B4D), Color(0xFF0A192F)],
                        ),
                      ),
                    ),
                  )
                else
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [Color(0xFF172B4D), Color(0xFF0A192F)],
                      ),
                    ),
                  ),
                ColoredBox(
                  color: Colors.black.withValues(alpha: thumbnailFile != null ? 0.24 : 0.08),
                ),
                Center(
                  child: Container(
                    width: 58,
                    height: 58,
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: .54),
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white.withValues(alpha: .45), width: 1.5),
                    ),
                    child: const Icon(
                      Icons.play_arrow_rounded,
                      color: Colors.white,
                      size: 38,
                    ),
                  ),
                ),
                Positioned(
                  left: 10,
                  top: 10,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: .56),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.videocam_rounded, color: Colors.white, size: 13),
                        SizedBox(width: 4),
                        Text(
                          'VIDEO',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 0.6,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
}

class _LikedinImageViewer extends StatefulWidget {
  const _LikedinImageViewer({
    required this.file,
    required this.title,
    this.viewOnce = false,
    this.payload,
  });
  final File file;
  final String title;
  final bool viewOnce;
  final Map<String, dynamic>? payload;

  @override
  State<_LikedinImageViewer> createState() => _LikedinImageViewerState();
}

class _LikedinImageViewerState extends State<_LikedinImageViewer>
    with SingleTickerProviderStateMixin {
  final TransformationController _transformController = TransformationController();
  late final AnimationController _zoomAnimController = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 220),
  );
  Animation<Matrix4>? _zoomAnimation;
  TapDownDetails? _doubleTapDetails;
  double _dragY = 0;
  bool _showChrome = true;
  bool _saving = false;

  double get _currentScale => _transformController.value.getMaxScaleOnAxis();

  @override
  void initState() {
    super.initState();
    _zoomAnimController.addListener(() {
      if (_zoomAnimation != null) {
        _transformController.value = _zoomAnimation!.value;
      }
    });
  }

  @override
  void dispose() {
    _zoomAnimController.dispose();
    _transformController.dispose();
    super.dispose();
  }

  void _handleDoubleTap() {
    HapticFeedback.selectionClick();
    final currentScale = _currentScale;
    final Matrix4 targetMatrix;
    if (currentScale > 1.15) {
      targetMatrix = Matrix4.identity();
    } else {
      final pos = _doubleTapDetails?.localPosition ?? Offset.zero;
      const scale = 2.6;
      targetMatrix = Matrix4.identity()
        ..translate(-pos.dx * (scale - 1), -pos.dy * (scale - 1))
        ..scale(scale);
    }
    _zoomAnimation = Matrix4Tween(
      begin: _transformController.value,
      end: targetMatrix,
    ).animate(CurvedAnimation(parent: _zoomAnimController, curve: Curves.easeOutCubic));
    _zoomAnimController.forward(from: 0);
  }

  Future<void> _saveToDownloads() async {
    final payload = widget.payload;
    if (payload == null || _saving) return;
    setState(() => _saving = true);
    final messenger = ScaffoldMessenger.of(context);
    try {
      final saved = await SharedMediaService(Supabase.instance.client)
          .downloadToPublicDownloads(payload);
      if (!mounted) return;
      messenger.showSnackBar(SnackBar(content: Text('Saved $saved to Downloads.')));
    } catch (_) {
      if (!mounted) return;
      messenger.showSnackBar(
        const SnackBar(content: Text('Could not save to Downloads. Please try again.')),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final progress = (_dragY.abs() / 240).clamp(0.0, 1.0);
    return Scaffold(
      backgroundColor: Colors.black.withValues(alpha: 1.0 - progress * 0.72),
      body: Stack(
        fit: StackFit.expand,
        children: [
          GestureDetector(
            onTap: () => setState(() => _showChrome = !_showChrome),
            onDoubleTapDown: (d) => _doubleTapDetails = d,
            onDoubleTap: _handleDoubleTap,
            onVerticalDragUpdate: (details) {
              if (_currentScale > 1.05) return;
              setState(() => _dragY = (_dragY + details.delta.dy).clamp(-260.0, 320.0));
            },
            onVerticalDragEnd: (details) {
              if (_currentScale > 1.05) return;
              if (_dragY.abs() > 105 || (details.primaryVelocity?.abs() ?? 0) > 650) {
                Navigator.of(context).pop();
              } else {
                setState(() => _dragY = 0);
              }
            },
            onVerticalDragCancel: () => setState(() => _dragY = 0),
            child: Center(
              child: AnimatedContainer(
                duration: _dragY == 0 ? const Duration(milliseconds: 180) : Duration.zero,
                curve: Curves.easeOutCubic,
                transform: Matrix4.translationValues(0, _dragY, 0),
                child: Transform.scale(
                  scale: 1.0 - progress * 0.14,
                  child: InteractiveViewer(
                    transformationController: _transformController,
                    minScale: 1.0,
                    maxScale: 5.0,
                    clipBehavior: Clip.none,
                    child: Image.file(
                      widget.file,
                      fit: BoxFit.contain,
                      width: MediaQuery.sizeOf(context).width,
                      height: MediaQuery.sizeOf(context).height,
                      gaplessPlayback: true,
                      errorBuilder: (_, __, ___) => const Icon(
                        Icons.broken_image_outlined,
                        color: Colors.white,
                        size: 56,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          // Top translucent gradient HUD
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: IgnorePointer(
              ignoring: !_showChrome || progress > 0.05,
              child: AnimatedOpacity(
                opacity: (_showChrome && progress <= 0.05) ? 1.0 : 0.0,
                duration: const Duration(milliseconds: 180),
                child: Container(
                  padding: EdgeInsets.fromLTRB(8, MediaQuery.paddingOf(context).top + 6, 12, 18),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.black.withValues(alpha: .72),
                        Colors.transparent,
                      ],
                    ),
                  ),
                  child: Row(
                    children: [
                      IconButton(
                        tooltip: 'Back',
                        onPressed: () => Navigator.of(context).pop(),
                        icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                      ),
                      const SizedBox(width: 4),
                      if (widget.viewOnce)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: .18),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: const Text(
                            '1× View once',
                            style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700),
                          ),
                        )
                      else
                        const Spacer(),
                      if (widget.viewOnce) const Spacer(),
                      if (!widget.viewOnce && widget.payload != null)
                        IconButton(
                          tooltip: 'Save to Downloads',
                          onPressed: _saving ? null : _saveToDownloads,
                          icon: _saving
                              ? const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                                )
                              : const Icon(Icons.download_rounded, color: Colors.white),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _LikedinVideoViewer extends StatefulWidget {
  const _LikedinVideoViewer({
    required this.file,
    required this.title,
    this.payload,
  });
  final File file;
  final String title;
  final Map<String, dynamic>? payload;
  @override
  State<_LikedinVideoViewer> createState() => _LikedinVideoViewerState();
}

class _LikedinVideoViewerState extends State<_LikedinVideoViewer> with WidgetsBindingObserver {
  late final VideoPlayerController _controller = VideoPlayerController.file(widget.file);
  String? _error;
  double _dragY = 0;
  String? _seekBadge;
  Timer? _seekBadgeTimer;
  Timer? _hudHideTimer;
  bool _showHud = true;
  bool _muted = false;
  double _speed = 1.0;
  bool _landscape = false;
  bool _saving = false;
  double? _scrubValueMs;

  void _onControllerUpdated() {
    if (!mounted) return;
    if (_controller.value.isInitialized &&
        _controller.value.duration > Duration.zero &&
        _controller.value.position >= _controller.value.duration &&
        !_showHud) {
      _showHud = true;
    }
    setState(() {});
  }

  void _armHudAutoHide() {
    _hudHideTimer?.cancel();
    if (!_controller.value.isInitialized || !_controller.value.isPlaying) return;
    _hudHideTimer = Timer(const Duration(milliseconds: 3200), () {
      if (mounted && _controller.value.isPlaying && _scrubValueMs == null) {
        setState(() => _showHud = false);
      }
    });
  }

  void _toggleHud() {
    setState(() => _showHud = !_showHud);
    if (_showHud) _armHudAutoHide();
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _controller.addListener(_onControllerUpdated);
    _controller.initialize().then((_) async {
      if (!mounted) return;
      setState(() {});
      await _controller.play();
      _armHudAutoHide();
    }).catchError((Object e) {
      if (mounted) setState(() => _error = e.toString());
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused || state == AppLifecycleState.inactive) {
      if (_controller.value.isInitialized && _controller.value.isPlaying) {
        _controller.pause();
      }
    }
  }

  @override
  void dispose() {
    _seekBadgeTimer?.cancel();
    _hudHideTimer?.cancel();
    if (_landscape) {
      unawaited(SystemChrome.setPreferredOrientations(const <DeviceOrientation>[]));
    }
    WidgetsBinding.instance.removeObserver(this);
    _controller.removeListener(_onControllerUpdated);
    _controller.dispose();
    super.dispose();
  }

  Future<void> _togglePlayPause() async {
    if (!_controller.value.isInitialized) return;
    HapticFeedback.selectionClick();
    if (_controller.value.isPlaying) {
      await _controller.pause();
      _hudHideTimer?.cancel();
      if (mounted) setState(() => _showHud = true);
    } else {
      final dur = _controller.value.duration;
      if (dur > Duration.zero && _controller.value.position >= dur) {
        await _controller.seekTo(Duration.zero);
      }
      await _controller.play();
      if (mounted) setState(() => _showHud = true);
      _armHudAutoHide();
    }
  }

  Future<void> _toggleMute() async {
    if (!_controller.value.isInitialized) return;
    HapticFeedback.selectionClick();
    final nextMuted = !_muted;
    await _controller.setVolume(nextMuted ? 0.0 : 1.0);
    if (mounted) setState(() => _muted = nextMuted);
    _armHudAutoHide();
  }

  Future<void> _cycleSpeed() async {
    if (!_controller.value.isInitialized) return;
    HapticFeedback.selectionClick();
    final next = _speed == 1.0 ? 1.5 : (_speed == 1.5 ? 2.0 : 1.0);
    await _controller.setPlaybackSpeed(next);
    if (mounted) setState(() => _speed = next);
    _armHudAutoHide();
  }

  Future<void> _toggleOrientation() async {
    HapticFeedback.selectionClick();
    final nextLandscape = !_landscape;
    setState(() => _landscape = nextLandscape);
    await SystemChrome.setPreferredOrientations(
      nextLandscape
          ? const <DeviceOrientation>[
              DeviceOrientation.landscapeLeft,
              DeviceOrientation.landscapeRight,
            ]
          : const <DeviceOrientation>[DeviceOrientation.portraitUp],
    );
    _armHudAutoHide();
  }

  Future<void> _saveToDownloads() async {
    final payload = widget.payload;
    if (payload == null || _saving) return;
    setState(() => _saving = true);
    final messenger = ScaffoldMessenger.of(context);
    try {
      final saved = await SharedMediaService(Supabase.instance.client)
          .downloadToPublicDownloads(payload);
      if (!mounted) return;
      messenger.showSnackBar(SnackBar(content: Text('Saved $saved to Downloads.')));
    } catch (_) {
      if (!mounted) return;
      messenger.showSnackBar(
        const SnackBar(content: Text('Could not save video to Downloads.')),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _seekBySeconds(int deltaSeconds) async {
    if (!_controller.value.isInitialized) return;
    final current = _controller.value.position;
    final total = _controller.value.duration;
    final targetMs = (current.inMilliseconds + deltaSeconds * 1000)
        .clamp(0, total.inMilliseconds);
    await _controller.seekTo(Duration(milliseconds: targetMs));
    HapticFeedback.selectionClick();
    if (!mounted) return;
    setState(() => _seekBadge = deltaSeconds < 0 ? '« 10s' : '10s »');
    _seekBadgeTimer?.cancel();
    _seekBadgeTimer = Timer(const Duration(milliseconds: 700), () {
      if (mounted) setState(() => _seekBadge = null);
    });
  }

  String _formatDuration(Duration d) =>
      '${d.inMinutes.toString().padLeft(2, '0')}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final progress = (_dragY.abs() / 240).clamp(0.0, 1.0);
    final initialized = _error == null && _controller.value.isInitialized;
    final isPlaying = initialized && _controller.value.isPlaying;
    final totalMs = initialized ? _controller.value.duration.inMilliseconds.toDouble() : 0.0;
    final currentMs = initialized
        ? (_scrubValueMs ?? _controller.value.position.inMilliseconds.toDouble())
            .clamp(0.0, totalMs > 0 ? totalMs : 1.0)
        : 0.0;
    final isEnded = initialized && totalMs > 0 && currentMs >= totalMs - 120;

    return Scaffold(
      backgroundColor: Colors.black.withValues(alpha: 1.0 - progress * 0.72),
      body: GestureDetector(
        onVerticalDragUpdate: (details) {
          if (_scrubValueMs != null) return;
          setState(() => _dragY = (_dragY + details.delta.dy).clamp(-260.0, 320.0));
        },
        onVerticalDragEnd: (details) {
          if (_scrubValueMs != null) return;
          if (_dragY.abs() > 110 || (details.primaryVelocity?.abs() ?? 0) > 650) {
            Navigator.of(context).pop();
          } else {
            setState(() => _dragY = 0);
          }
        },
        onVerticalDragCancel: () => setState(() => _dragY = 0),
        child: AnimatedContainer(
          duration: _dragY == 0 ? const Duration(milliseconds: 180) : Duration.zero,
          curve: Curves.easeOutCubic,
          transform: Matrix4.translationValues(0, _dragY, 0),
          child: Transform.scale(
            scale: 1.0 - progress * 0.14,
            child: Stack(
              fit: StackFit.expand,
              children: [
                Center(
                  child: _error != null
                      ? const Padding(
                          padding: EdgeInsets.all(24),
                          child: Text(
                            'Could not play this video file.',
                            style: TextStyle(color: Colors.white70),
                          ),
                        )
                      : initialized
                          ? AspectRatio(
                              aspectRatio: _controller.value.aspectRatio,
                              child: VideoPlayer(_controller),
                            )
                          : const CircularProgressIndicator(color: Colors.white),
                ),
                // Tap to toggle HUD + Double-tap left/right halves to seek
                if (initialized)
                  Positioned.fill(
                    child: Row(
                      children: [
                        Expanded(
                          child: GestureDetector(
                            behavior: HitTestBehavior.translucent,
                            onTap: _toggleHud,
                            onDoubleTap: () => unawaited(_seekBySeconds(-10)),
                          ),
                        ),
                        Expanded(
                          child: GestureDetector(
                            behavior: HitTestBehavior.translucent,
                            onTap: _toggleHud,
                            onDoubleTap: () => unawaited(_seekBySeconds(10)),
                          ),
                        ),
                      ],
                    ),
                  ),
                // Seek feedback pill
                if (_seekBadge != null)
                  IgnorePointer(
                    child: Center(
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: .70),
                          borderRadius: BorderRadius.circular(24),
                        ),
                        child: Text(
                          _seekBadge!,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ),
                  ),
                // Center floating Play / Pause / Replay control
                if (initialized && _seekBadge == null)
                  Center(
                    child: IgnorePointer(
                      ignoring: !_showHud || progress > 0.05,
                      child: AnimatedOpacity(
                        opacity: (_showHud && progress <= 0.05) ? 1.0 : 0.0,
                        duration: const Duration(milliseconds: 180),
                        child: GestureDetector(
                          onTap: () => unawaited(_togglePlayPause()),
                          child: Container(
                            width: 68,
                            height: 68,
                            decoration: BoxDecoration(
                              color: Colors.black.withValues(alpha: .56),
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white.withValues(alpha: .42), width: 1.5),
                            ),
                            child: Icon(
                              isEnded
                                  ? Icons.replay_rounded
                                  : isPlaying
                                      ? Icons.pause_rounded
                                      : Icons.play_arrow_rounded,
                              color: Colors.white,
                              size: 40,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                // Top gradient HUD (Back, Mute, Speed, Save)
                Positioned(
                  top: 0,
                  left: 0,
                  right: 0,
                  child: IgnorePointer(
                    ignoring: !_showHud || progress > 0.05,
                    child: AnimatedOpacity(
                      opacity: (_showHud && progress <= 0.05) ? 1.0 : 0.0,
                      duration: const Duration(milliseconds: 180),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(8, MediaQuery.paddingOf(context).top + 6, 12, 18),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.black.withValues(alpha: .74),
                              Colors.transparent,
                            ],
                          ),
                        ),
                        child: Row(
                          children: [
                            IconButton(
                              tooltip: 'Back',
                              onPressed: () => Navigator.of(context).pop(),
                              icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                            ),
                            const Spacer(),
                            if (initialized) ...[
                              IconButton(
                                tooltip: _muted ? 'Unmute' : 'Mute',
                                onPressed: () => unawaited(_toggleMute()),
                                icon: Icon(
                                  _muted ? Icons.volume_off_rounded : Icons.volume_up_rounded,
                                  color: Colors.white,
                                ),
                              ),
                              TextButton(
                                onPressed: () => unawaited(_cycleSpeed()),
                                style: TextButton.styleFrom(
                                  foregroundColor: Colors.white,
                                  backgroundColor: Colors.white.withValues(alpha: .16),
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                  minimumSize: const Size(0, 32),
                                ),
                                child: Text(
                                  '${_speed == _speed.roundToDouble() ? _speed.toInt() : _speed}x',
                                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800),
                                ),
                              ),
                            ],
                            if (widget.payload != null) ...[
                              const SizedBox(width: 4),
                              IconButton(
                                tooltip: 'Save to Downloads',
                                onPressed: _saving ? null : _saveToDownloads,
                                icon: _saving
                                    ? const SizedBox(
                                        width: 18,
                                        height: 18,
                                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                                      )
                                    : const Icon(Icons.download_rounded, color: Colors.white),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                // Bottom glass scrubber HUD
                if (initialized)
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    child: IgnorePointer(
                      ignoring: !_showHud || progress > 0.05,
                      child: AnimatedOpacity(
                        opacity: (_showHud && progress <= 0.05) ? 1.0 : 0.0,
                        duration: const Duration(milliseconds: 180),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(
                            16,
                            18,
                            16,
                            MediaQuery.paddingOf(context).bottom + 14,
                          ),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.bottomCenter,
                              end: Alignment.topCenter,
                              colors: [
                                Colors.black.withValues(alpha: .80),
                                Colors.transparent,
                              ],
                            ),
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SliderTheme(
                                data: SliderTheme.of(context).copyWith(
                                  trackHeight: 3.5,
                                  thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6.5),
                                  overlayShape: const RoundSliderOverlayShape(overlayRadius: 14),
                                  activeTrackColor: likedinPrimary(Theme.of(context).brightness),
                                  inactiveTrackColor: Colors.white24,
                                  thumbColor: Colors.white,
                                ),
                                child: Slider(
                                  value: currentMs,
                                  min: 0.0,
                                  max: totalMs > 0 ? totalMs : 1.0,
                                  onChangeStart: (v) {
                                    _hudHideTimer?.cancel();
                                    setState(() => _scrubValueMs = v);
                                  },
                                  onChanged: (v) => setState(() => _scrubValueMs = v),
                                  onChangeEnd: (v) async {
                                    await _controller.seekTo(Duration(milliseconds: v.round()));
                                    if (mounted) setState(() => _scrubValueMs = null);
                                    _armHudAutoHide();
                                  },
                                ),
                              ),
                              Row(
                                children: [
                                  IconButton(
                                    tooltip: 'Rewind 10 seconds',
                                    visualDensity: VisualDensity.compact,
                                    onPressed: () => unawaited(_seekBySeconds(-10)),
                                    icon: const Icon(Icons.replay_10_rounded, color: Colors.white, size: 22),
                                  ),
                                  IconButton(
                                    visualDensity: VisualDensity.compact,
                                    onPressed: () => unawaited(_togglePlayPause()),
                                    icon: Icon(
                                      isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                                      color: Colors.white,
                                      size: 24,
                                    ),
                                  ),
                                  IconButton(
                                    tooltip: 'Forward 10 seconds',
                                    visualDensity: VisualDensity.compact,
                                    onPressed: () => unawaited(_seekBySeconds(10)),
                                    icon: const Icon(Icons.forward_10_rounded, color: Colors.white, size: 22),
                                  ),
                                  const SizedBox(width: 6),
                                  Text(
                                    '${_formatDuration(Duration(milliseconds: currentMs.round()))} / ${_formatDuration(_controller.value.duration)}',
                                    style: const TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w600),
                                  ),
                                  const Spacer(),
                                  IconButton(
                                    tooltip: _landscape ? 'Portrait' : 'Rotate landscape',
                                    visualDensity: VisualDensity.compact,
                                    onPressed: () => unawaited(_toggleOrientation()),
                                    icon: Icon(
                                      _landscape ? Icons.screen_lock_portrait_rounded : Icons.screen_rotation_rounded,
                                      color: Colors.white70,
                                      size: 20,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _AlbumViewerPage extends StatefulWidget {
  const _AlbumViewerPage({
    required this.items,
    required this.initialIndex,
  });
  final List<({Map<String, dynamic> payload, String name})> items;
  final int initialIndex;

  @override
  State<_AlbumViewerPage> createState() => _AlbumViewerPageState();
}

class _AlbumViewerPageState extends State<_AlbumViewerPage> {
  late final PageController _pageController =
      PageController(initialPage: widget.initialIndex);
  late int _currentIndex = widget.initialIndex;
  double _dragY = 0;
  bool _showChrome = true;
  bool _saving = false;

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _saveCurrent() async {
    if (_saving) return;
    setState(() => _saving = true);
    final messenger = ScaffoldMessenger.of(context);
    try {
      final saved = await SharedMediaService(Supabase.instance.client)
          .downloadToPublicDownloads(widget.items[_currentIndex].payload);
      if (!mounted) return;
      messenger.showSnackBar(SnackBar(content: Text('Saved $saved to Downloads.')));
    } catch (_) {
      if (!mounted) return;
      messenger.showSnackBar(
        const SnackBar(content: Text('Could not save photo to Downloads.')),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final progress = (_dragY.abs() / 240).clamp(0.0, 1.0);
    return Scaffold(
      backgroundColor: Colors.black.withValues(alpha: 1.0 - progress * 0.72),
      body: Stack(
        fit: StackFit.expand,
        children: [
          GestureDetector(
            onTap: () => setState(() => _showChrome = !_showChrome),
            onVerticalDragUpdate: (details) {
              setState(() => _dragY = (_dragY + details.delta.dy).clamp(-260.0, 320.0));
            },
            onVerticalDragEnd: (details) {
              if (_dragY.abs() > 105 || (details.primaryVelocity?.abs() ?? 0) > 650) {
                Navigator.of(context).pop();
              } else {
                setState(() => _dragY = 0);
              }
            },
            onVerticalDragCancel: () => setState(() => _dragY = 0),
            child: AnimatedContainer(
              duration: _dragY == 0 ? const Duration(milliseconds: 180) : Duration.zero,
              curve: Curves.easeOutCubic,
              transform: Matrix4.translationValues(0, _dragY, 0),
              child: Transform.scale(
                scale: 1.0 - progress * 0.14,
                child: PageView.builder(
                  controller: _pageController,
                  itemCount: widget.items.length,
                  onPageChanged: (i) => setState(() => _currentIndex = i),
                  itemBuilder: (context, idx) {
                    final item = widget.items[idx];
                    return FutureBuilder<File>(
                      future: SharedMediaService(Supabase.instance.client)
                          .cachedFile(item.payload),
                      builder: (context, snap) {
                        final file = snap.data;
                        if (file == null) {
                          return const Center(child: CircularProgressIndicator(color: Colors.white));
                        }
                        return Center(
                          child: InteractiveViewer(
                            minScale: 1.0,
                            maxScale: 5.0,
                            child: Image.file(
                              file,
                              fit: BoxFit.contain,
                              width: MediaQuery.sizeOf(context).width,
                              height: MediaQuery.sizeOf(context).height,
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ),
          ),
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: IgnorePointer(
              ignoring: !_showChrome || progress > 0.05,
              child: AnimatedOpacity(
                opacity: (_showChrome && progress <= 0.05) ? 1.0 : 0.0,
                duration: const Duration(milliseconds: 180),
                child: Container(
                  padding: EdgeInsets.fromLTRB(8, MediaQuery.paddingOf(context).top + 6, 12, 18),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.black.withValues(alpha: .72),
                        Colors.transparent,
                      ],
                    ),
                  ),
                  child: Row(
                    children: [
                      IconButton(
                        tooltip: 'Back',
                        onPressed: () => Navigator.of(context).pop(),
                        icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        '${_currentIndex + 1} / ${widget.items.length}',
                        style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700),
                      ),
                      const Spacer(),
                      IconButton(
                        tooltip: 'Save to Downloads',
                        onPressed: _saving ? null : _saveCurrent,
                        icon: _saving
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                              )
                            : const Icon(Icons.download_rounded, color: Colors.white),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Compact quote renderer. Image/GIF replies use the same cached media file as
/// the message bubble; concurrent requests are coalesced by SharedMediaService.
class _ReplyQuotePreview extends StatefulWidget {
  const _ReplyQuotePreview({
    required this.original,
    required this.fallbackText,
    this.compact = false,
  });

  final RemoteMessage? original;
  final String fallbackText;
  final bool compact;

  @override
  State<_ReplyQuotePreview> createState() => _ReplyQuotePreviewState();
}

class _ReplyQuotePreviewState extends State<_ReplyQuotePreview> {
  Future<File>? _imageFuture;
  Map<String, dynamic>? _payload;

  @override
  void initState() {
    super.initState();
    _prepare();
  }

  @override
  void didUpdateWidget(covariant _ReplyQuotePreview oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.original?.id != widget.original?.id ||
        oldWidget.original?.text != widget.original?.text) {
      _prepare();
    }
  }

  void _prepare() {
    _payload = null;
    _imageFuture = null;
    final original = widget.original;
    if (original == null || original.deletedForEveryoneAt != null) return;
    final payload = SharedMediaService(Supabase.instance.client).decode(original.text);
    if (payload == null) return;
    _payload = payload;
    if (payload['kind'] == 'image') {
      _imageFuture = SharedMediaService(Supabase.instance.client).cachedFileIfPresent(payload);
    }
  }

  String _mediaLabel(Map<String, dynamic> payload) {
    final kind = payload['kind']?.toString() ?? 'file';
    if (kind == 'image') {
      final animated = payload['animated'] == true ||
          payload['mime'] == 'image/gif' ||
          (payload['name']?.toString().toLowerCase().endsWith('.gif') ?? false);
      return animated ? 'GIF' : 'Photo';
    }
    if (kind == 'video') return 'Video';
    if (kind == 'audio') return 'Voice message';
    return 'Attachment';
  }

  Widget _iconPreview(IconData icon, {Color? color}) => Container(
        width: widget.compact ? 52 : 60,
        height: widget.compact ? 42 : 48,
        decoration: BoxDecoration(
          color: likedinPrimary(Theme.of(context).brightness).withValues(alpha: .10),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, color: color ?? likedinPrimary(Theme.of(context).brightness), size: 23),
      );

  @override
  Widget build(BuildContext context) {
    final payload = _payload;
    if (payload == null) {
      return Text.rich(
        likedinEmojiSpan(
          widget.fallbackText,
          style: TextStyle(
            fontSize: 12,
            height: 1.2,
            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .78),
          ),
        ),
        maxLines: widget.compact ? 1 : 2,
        overflow: TextOverflow.ellipsis,
      );
    }

    final kind = payload['kind']?.toString() ?? 'file';
    final label = _mediaLabel(payload);
    Widget preview;
    if (kind == 'image' && _imageFuture != null) {
      preview = FutureBuilder<File>(
        future: _imageFuture,
        builder: (context, snapshot) {
          final file = snapshot.data;
          if (snapshot.hasError) {
            return _iconPreview(Icons.image_not_supported_outlined);
          }
          if (file == null || !snapshot.hasData) {
            return SizedBox(
              width: widget.compact ? 52 : 60,
              height: widget.compact ? 42 : 48,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: likedinPrimary(Theme.of(context).brightness).withValues(alpha: .10),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Center(
                  child: SizedBox(width: 15, height: 15, child: CircularProgressIndicator(strokeWidth: 1.7)),
                ),
              ),
            );
          }
          return ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.file(
              file,
              width: widget.compact ? 52 : 60,
              height: widget.compact ? 42 : 48,
              fit: BoxFit.cover,
              cacheWidth: 120,
              filterQuality: FilterQuality.low,
              errorBuilder: (_, __, ___) => _iconPreview(Icons.image_outlined),
            ),
          );
        },
      );
    } else if (kind == 'video') {
      preview = _iconPreview(Icons.play_circle_outline_rounded);
    } else if (kind == 'audio') {
      preview = _iconPreview(Icons.graphic_eq_rounded);
    } else {
      preview = _iconPreview(Icons.insert_drive_file_outlined);
    }

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        preview,
        const SizedBox(width: 8),
        Flexible(
          child: Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .82),
            ),
          ),
        ),
      ],
    );
  }
}
