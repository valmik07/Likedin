# Likedin v2.3.1+123 — True iOS-Style Liquid Glass & Unified App-Wide Themes

## What's new in v2.3.1+123
- **True iOS-style Liquid Glass:** Replaced milky frosted slabs with crystal-clear optical glass (`GlassPanel` & `LiquidGlassBubble`), diagonal directional specular refraction rims, curved liquid top meniscus sheen, bottom chromatic bounce, and `ImageFilter.compose` vibrancy + blur on floating bars.
- **7 Unified App-Wide Themes:** `Default`, `Ocean`, `Rose`, `Emerald`, `Sunset`, `Lavender`, and `Minimal` now apply consistently across the **entire app** (Home, Chat, Calls, Files, Profile, Settings, Contact Info, Shared Media, Storage, Auth) in both **Dark Mode** and **Light Mode** — eliminating the dark-mode visual mismatch when opening Chat.
- **Liquid Glass Floating Dock:** Upgraded the floating bottom navigation bar with a glowing Liquid Glass lens capsule indicator.
- **Retains v2.3.0 APK size & 3 GB RAM optimizations:** ARM64-only ABI filter, compressed `.so` packaging, English-only resource filter, obfuscated symbol splitting, and 24 MB image cache budget.
