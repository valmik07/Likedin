import 'dart:async';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

class RemoteMessage {
  const RemoteMessage({
    required this.id,
    required this.senderId,
    required this.recipientId,
    required this.text,
    required this.createdAt,
    this.clientMessageId,
    this.deliveredAt,
    this.readAt,
    this.replyToMessageId,
    this.editedAt,
    this.deletedForEveryoneAt,
  });
  final String id, senderId, recipientId, text;
  final String? clientMessageId;
  final DateTime createdAt;
  final DateTime? deliveredAt, readAt, editedAt, deletedForEveryoneAt;
  final String? replyToMessageId;

  factory RemoteMessage.fromMap(Map<String, dynamic> row) => RemoteMessage(
        id: row['id'] as String,
        clientMessageId: row['client_message_id']?.toString(),
        senderId: row['sender_id'] as String,
        recipientId: row['recipient_id'] as String,
        // Compatibility with the two schemas shipped in prior migrations.
        // IMPORTANT: neither field name proves cryptographic encryption.
        text: (row['body_payload'] ?? row['encrypted_payload'] ?? row['ciphertext']) as String,
        createdAt: DateTime.parse(row['created_at'] as String).toLocal(),
        deliveredAt: row['delivered_at'] == null ? null : DateTime.parse(row['delivered_at'] as String).toLocal(),
        readAt: row['read_at'] == null ? null : DateTime.parse(row['read_at'] as String).toLocal(),
        replyToMessageId: row['reply_to_message_id'] as String?,
        editedAt: row['edited_at'] == null ? null : DateTime.parse(row['edited_at'] as String).toLocal(),
        deletedForEveryoneAt: row['deleted_for_everyone_at'] == null ? null : DateTime.parse(row['deleted_for_everyone_at'] as String).toLocal(),
      );
}

class PeerProfile {
  const PeerProfile({required this.id, required this.name, required this.online, this.lastSeen});
  final String id, name;
  final bool online;
  final DateTime? lastSeen;
}

class RealtimeMessagingService {
  RealtimeMessagingService(this._client);
  final SupabaseClient _client;
  static const _uuid = Uuid();
  RealtimeChannel? _channel;
  RealtimeChannel? _signalChannel;

  String get currentUserId {
    final id = _client.auth.currentUser?.id;
    if (id == null) throw StateError('Please sign in first.');
    return id;
  }

  Future<String?> getPeerId() async => await _client.rpc('likedin_get_peer_id') as String?;

  Future<PeerProfile?> getPeerProfile() async {
    final peer = await getPeerId();
    if (peer == null) return null;
    final row = await _client
        .from('profiles')
        .select('user_id,display_name,is_online,last_seen_at')
        .eq('user_id', peer)
        .maybeSingle();
    if (row == null) return null;
    return PeerProfile(
      id: peer,
      name: (row['display_name'] as String?)?.trim().isNotEmpty == true
          ? (row['display_name'] as String).trim()
          : 'Likedin friend',
      online: row['is_online'] == true &&
          row['last_seen_at'] != null &&
          DateTime.parse(row['last_seen_at'] as String)
              .isAfter(DateTime.now().toUtc().subtract(const Duration(seconds: 90))),
      lastSeen: row['last_seen_at'] == null ? null : DateTime.parse(row['last_seen_at'] as String).toLocal(),
    );
  }

  Future<List<RemoteMessage>> loadConversation() async {
    final uid = currentUserId;
    final rows = await _client
        .from('messages')
        .select()
        .or('sender_id.eq.$uid,recipient_id.eq.$uid')
        .order('created_at', ascending: false)
        .limit(500);
    return rows.reversed.map((row) => RemoteMessage.fromMap(row)).toList();
  }

  Future<String?> sendMessage(
    String recipientId,
    String text, {
    String? clientMessageId,
    String? replyToMessageId,
  }) async {
    final clean = text.trim();
    if (clean.isEmpty) return null;
    final result = await _client.rpc('likedin_send_message_v2', params: {
      'p_recipient_id': recipientId,
      'p_payload': clean,
      'p_client_message_id': clientMessageId ?? _uuid.v4(),
      'p_reply_to_message_id': replyToMessageId,
    });
    return result?.toString();
  }

  Future<void> deleteMessageForEveryone(String messageId) async {
    await _client.rpc('likedin_delete_message_for_everyone_v2', params: {'p_message_id': messageId});
  }

  Future<void> editMessage(String messageId, String text) async {
    final clean = text.trim();
    if (clean.isEmpty || clean.length > 10000) {
      throw ArgumentError('Message must contain 1 to 10000 characters.');
    }
    await _client.rpc('likedin_edit_message', params: {'p_message_id': messageId, 'p_new_payload': clean});
  }

  Future<Map<String, Set<String>>> loadReactions() async {
    final rows = await _client.from('message_reactions').select('message_id,emoji');
    final result = <String, Set<String>>{};
    for (final row in rows) {
      final id = row['message_id'] as String;
      (result[id] ??= <String>{}).add(row['emoji'] as String);
    }
    return result;
  }

  Future<bool> hasMyReaction(String messageId, String emoji) async {
    final row = await _client
        .from('message_reactions')
        .select('message_id')
        .eq('message_id', messageId)
        .eq('user_id', currentUserId)
        .eq('emoji', emoji)
        .maybeSingle();
    return row != null;
  }

  Future<void> setReaction(String messageId, String emoji, {required bool active}) async {
    await _client.rpc('likedin_set_message_reaction', params: {
      'p_message_id': messageId,
      'p_emoji': emoji,
      'p_active': active,
    });
  }

  Future<void> setOnline(bool online) async {
    await _client.rpc('likedin_set_presence', params: {'p_online': online});
  }

  Future<void> markDelivered() async {
    await _client.rpc('likedin_mark_delivered');
  }

  Future<void> markRead() async {
    await _client.rpc('likedin_mark_read');
  }

  void subscribe({
    required String? peerId,
    required void Function() onMessages,
    required void Function() onProfile,
    required void Function(bool) onTyping,
  }) {
    unsubscribe();
    _channel = _client
        .channel('likedin-data-$currentUserId')
        .onPostgresChanges(event: PostgresChangeEvent.insert, schema: 'public', table: 'messages', callback: (_) => onMessages())
        .onPostgresChanges(event: PostgresChangeEvent.update, schema: 'public', table: 'messages', callback: (_) => onMessages())
        .onPostgresChanges(event: PostgresChangeEvent.delete, schema: 'public', table: 'messages', callback: (_) => onMessages())
        .onPostgresChanges(event: PostgresChangeEvent.insert, schema: 'public', table: 'message_reactions', callback: (_) => onMessages())
        .onPostgresChanges(event: PostgresChangeEvent.delete, schema: 'public', table: 'message_reactions', callback: (_) => onMessages())
        .onPostgresChanges(event: PostgresChangeEvent.update, schema: 'public', table: 'profiles', callback: (_) => onProfile())
      ..subscribe();
    final ids = <String>[currentUserId, if (peerId != null) peerId]..sort();
    _signalChannel = _client
        .channel('likedin-typing-${ids.join('-')}')
        .onBroadcast(
          event: 'typing',
          callback: (payload) {
            final from = payload['user_id']?.toString();
            if (from != null && from != currentUserId) onTyping(payload['typing'] == true);
          },
        )
      ..subscribe();
  }

  Future<void> sendTyping(bool typing) async {
    final channel = _signalChannel;
    if (channel == null) return;
    await channel.sendBroadcastMessage(
      event: 'typing',
      payload: {'user_id': currentUserId, 'typing': typing},
    );
  }

  void unsubscribe() {
    final a = _channel;
    final b = _signalChannel;
    _channel = null;
    _signalChannel = null;
    if (a != null) _client.removeChannel(a);
    if (b != null) _client.removeChannel(b);
  }
}
