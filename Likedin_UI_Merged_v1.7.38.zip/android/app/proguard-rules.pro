# Likedin release shrinker rules.
# Flutter engine/plugin entry points and native/JNI-backed WebRTC types.
-keep class io.flutter.** { *; }
-keep class io.flutter.plugins.** { *; }
-keep class com.google.firebase.** { *; }
-keep class org.webrtc.** { *; }
-keep class com.cloudwebrtc.webrtc.** { *; }
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-dontwarn org.webrtc.**

# This app does not use Play Feature Delivery / deferred components.
# Flutter references these optional classes; suppress missing-class checks for that unused path.
-dontwarn com.google.android.play.core.**
