import 'dart:async';
import 'dart:convert';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import 'call_alert_controller.dart';

class LikedinCallService {
  LikedinCallService(this.client);
  final SupabaseClient client;
  final _uuid = const Uuid();
  RTCPeerConnection? _pc;
  MediaStream? _local;
  final _remote = RTCVideoRenderer();
  final _localRenderer = RTCVideoRenderer();
  final List<RTCIceCandidate> _pendingCandidates = [];
  bool _remoteDescriptionReady = false;
  RealtimeChannel? _channel;
  Timer? _ringTimer;
  String? callId, peerId;
  bool video = false, muted = false, speaker = false, camera = true;
  String status = 'idle';
  final _changes = StreamController<String>.broadcast();
  Stream<String> get changes => _changes.stream;
  RTCVideoRenderer get remoteRenderer => _remote;
  RTCVideoRenderer get localRenderer => _localRenderer;
  String get uid => client.auth.currentUser!.id;

  Future<void> initialize() async { await _remote.initialize(); await _localRenderer.initialize(); }

  // Start on the handset earpiece. Speakerphone is an explicit user choice.
  Future<void> _routeToEarpiece() async {
    speaker = false;
    await Helper.setSpeakerphoneOn(false);
  }

  Future<List<Map<String,dynamic>>> _iceServers() async {
    final session = client.auth.currentSession;
    if (session == null) throw StateError('Sign in before calling.');
    final response = await client.functions.invoke('get-turn-config', headers: {'Authorization':'Bearer ${session.accessToken}'});
    if (response.status != 200 || response.data is! Map || response.data['iceServers'] is! List) throw StateError('Could not load TURN configuration: ${response.data}');
    return (response.data['iceServers'] as List).cast<Map<String,dynamic>>();
  }

  Future<void> _createPeer() async {
    final servers = await _iceServers();
    _pc = await createPeerConnection({'iceServers': servers, 'sdpSemantics':'unified-plan'});
    _pc!.onIceCandidate = (candidate) { if (candidate.candidate != null && callId != null) _send('ice', {'candidate':candidate.candidate,'sdpMid':candidate.sdpMid,'sdpMLineIndex':candidate.sdpMLineIndex}); };
    _pc!.onTrack = (event) { if (event.streams.isNotEmpty) { _remote.srcObject = event.streams.first; _changes.add('connected'); } };
    _pc!.onConnectionState = (state) { status = state.name; _changes.add(status); };
    _local = await navigator.mediaDevices.getUserMedia({'audio':true,'video':video ? {'facingMode':'user','width':{'ideal':640},'height':{'ideal':480}} : false});
    // getUserMedia may initialize Android's audio route; re-assert earpiece afterwards.
    speaker = false;
    await Helper.setSpeakerphoneOn(false);
    _localRenderer.srcObject = _local;
    for (final track in _local!.getTracks()) { await _pc!.addTrack(track, _local!); }
  }

  Future<void> start(String recipient, {required bool withVideo}) async {
    video = withVideo; peerId = recipient; callId = _uuid.v4(); status = 'calling';
    await _routeToEarpiece();
    // Create the row before starting ICE gathering so candidates always have a call_id.
    await client.from('likedin_calls').insert({'id':callId,'caller_id':uid,'callee_id':recipient,'call_type':video?'video':'audio','status':'ringing'});
    await CallAlertController.startOutgoing();
    _ringTimer?.cancel();
    _ringTimer = Timer(const Duration(seconds: 45), () async {
      if (status == 'calling' && callId != null) {
        try { await client.from('likedin_calls').update({'status':'missed','ended_at':DateTime.now().toUtc().toIso8601String()}).eq('id', callId!); } catch (_) {}
        try { await _send('end', {'reason':'no_answer'}); } catch (_) {}
        status = 'missed';
        _changes.add(status);
        await dispose();
      }
    });
    _listen();
    await _createPeer();
    final offer = await _pc!.createOffer(); await _pc!.setLocalDescription(offer);
    await _send('offer', {'sdp':offer.sdp,'type':offer.type}); _changes.add(status);
  }

  Future<void> accept(String id, String caller, Map<String,dynamic> offer, {required bool withVideo}) async {
    callId=id; peerId=caller; video=withVideo; status='connecting';
    await _routeToEarpiece();
    // Subscribe before creating/sending the answer so early ICE candidates are not missed.
    _listen();
    await _createPeer();
    await _pc!.setRemoteDescription(RTCSessionDescription(offer['sdp'] as String, offer['type'] as String));
    _remoteDescriptionReady=true;
    // Reconcile candidates that arrived before the Realtime subscription was ready.
    final existing = await client.from('likedin_call_signals').select('sender_id,kind,payload')
      .eq('call_id', id).eq('kind', 'ice').neq('sender_id', uid).order('created_at');
    for (final row in existing) {
      final data = Map<String,dynamic>.from(row['payload'] as Map);
      if (data['candidate'] != null) {
        await _pc!.addCandidate(RTCIceCandidate(data['candidate'], data['sdpMid'], data['sdpMLineIndex']));
      }
    }
    for(final c in _pendingCandidates) { await _pc!.addCandidate(c); } _pendingCandidates.clear();
    final answer=await _pc!.createAnswer(); await _pc!.setLocalDescription(answer);
    await client.from('likedin_calls').update({'status':'accepted','answered_at':DateTime.now().toUtc().toIso8601String()}).eq('id',id);
    await _send('answer', {'sdp':answer.sdp,'type':answer.type}); _changes.add(status);
  }

  void _listen() {
    _channel=client.channel('call-$callId-${uid.substring(0,6)}')
      .onPostgresChanges(event:PostgresChangeEvent.insert,schema:'public',table:'likedin_call_signals',filter:PostgresChangeFilter(type:PostgresChangeFilterType.eq,column:'call_id',value:callId),callback:(payload) async {
        final row=payload.newRecord; if(row['sender_id']==uid) return; final kind=row['kind']; final data=Map<String,dynamic>.from(row['payload'] as Map);
        try {
          if(kind=='answer' && _pc!=null) { await CallAlertController.stop(); _ringTimer?.cancel(); await _pc!.setRemoteDescription(RTCSessionDescription(data['sdp'],data['type'])); _remoteDescriptionReady=true; for(final c in _pendingCandidates) { await _pc!.addCandidate(c); } _pendingCandidates.clear(); status='connecting'; _changes.add(status); }
          if(kind=='ice' && _pc!=null) { final c=RTCIceCandidate(data['candidate'],data['sdpMid'],data['sdpMLineIndex']); if(_remoteDescriptionReady) { await _pc!.addCandidate(c); } else { _pendingCandidates.add(c); } }
          if(kind=='end') { await CallAlertController.stop(); status='ended'; _ringTimer?.cancel(); _changes.add(status); }
          if(kind=='reject') { await CallAlertController.stop(); status='rejected'; _ringTimer?.cancel(); _changes.add(status); }
        } catch(e) { status='error: $e'; _changes.add(status); }
      })..subscribe();
  }
  Future<void> _send(String kind, Map<String,dynamic> payload) async { await client.from('likedin_call_signals').insert({'call_id':callId,'sender_id':uid,'kind':kind,'payload':payload}); }
  Future<void> toggleMute() async { muted=!muted; for(final t in _local?.getAudioTracks()??[]) { t.enabled=!muted; } _changes.add(status); }
  Future<void> toggleCamera() async { camera=!camera; for(final t in _local?.getVideoTracks()??[]) { t.enabled=camera; } _changes.add(status); }
  Future<void> switchCamera() async { final tracks=_local?.getVideoTracks()??[]; if(tracks.isNotEmpty) await Helper.switchCamera(tracks.first); }
  Future<void> toggleSpeaker() async { final next = !speaker; await Helper.setSpeakerphoneOn(next); speaker=next; _changes.add(status); }
  Future<void> end({bool rejected=false}) async { await CallAlertController.stop(); _ringTimer?.cancel(); try { await _send(rejected?'reject':'end',{}); } catch(_) {} try { await client.from('likedin_calls').update({'status':rejected?'rejected':'ended','ended_at':DateTime.now().toUtc().toIso8601String()}).eq('id',callId!); } catch(_) {} await dispose(); status=rejected?'rejected':'ended'; _changes.add(status); }
  Future<void> dispose() async { await CallAlertController.stop(); _ringTimer?.cancel(); _ringTimer=null; final c=_channel; _channel=null; if(c!=null) await client.removeChannel(c); await _pc?.close(); _pc=null; await _local?.dispose(); _local=null; _remote.srcObject=null; _localRenderer.srcObject=null; _pendingCandidates.clear(); _remoteDescriptionReady=false; }
  Future<void> close() async { await dispose(); await _remote.dispose(); await _localRenderer.dispose(); await _changes.close(); }
}
