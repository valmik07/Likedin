import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:http/http.dart' as http;
import 'package:mime/mime.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import 'package:video_compress/video_compress.dart';
import 'package:flutter/services.dart';

import 'backend_config.dart';

/// Private shared media transport. Uploads use Supabase Storage's TUS endpoint
/// so offsets survive process death. A persisted queue is retried in the foreground when the user initiates another send.
class SharedMediaService {
  SharedMediaService(this.client);
  final SupabaseClient client;
  static const bucket = 'likedin-media';
  static const maxBytes = 50 * 1024 * 1024;
  static String? lastQueueError;
  static const _queueKey = 'likedin_media_retry_queue_v2';
  static const _uuid = Uuid();
  static const _chunkSize = 5 * 1024 * 1024;

  bool isMediaPayload(String value) {
    try {
      final m = jsonDecode(value);
      return m is Map && m['__likedin_media_v1'] == true;
    } catch (_) {
      return false;
    }
  }

  Map<String, dynamic>? decode(String value) {
    try {
      final m = jsonDecode(value);
      if (m is Map && m['__likedin_media_v1'] == true) {
        return Map<String, dynamic>.from(m);
      }
    } catch (_) {}
    return null;
  }

  /// Human-readable summary of a media payload for reply quotes and banners.
  String describePayload(Map<String, dynamic> payload) {
    final kind = payload['kind']?.toString() ?? 'file';
    final name = payload['name']?.toString() ?? 'Attachment';
    switch (kind) {
      case 'image':
        return 'Photo · $name';
      case 'video':
        return 'Video · $name';
      case 'audio':
        return 'Voice message';
      default:
        return 'File · $name';
    }
  }

  static String _normalizeMime(String filename) {
    final ext = p.extension(filename).replaceFirst('.', '').toLowerCase();
    if (ext == 'm4a') return 'audio/mp4';
    final detected = lookupMimeType(filename) ?? 'application/octet-stream';
    if (detected == 'audio/x-m4a' || detected == 'audio/m4a') {
      return 'audio/mp4';
    }
    return detected;
  }

  /// Compresses videos before enqueueing. The original is never modified.
  Future<File> prepare(File source) async {
    final mime = _normalizeMime(source.path);
    if (!mime.startsWith('video/')) return source;
    final result = await VideoCompress.compressVideo(
      source.path,
      quality: VideoQuality.MediumQuality,
      deleteOrigin: false,
      includeAudio: true,
      frameRate: 30,
    );
    final compressed = result?.file;
    if (compressed == null || !await compressed.exists()) return source;
    final originalSize = await source.length();
    final compressedSize = await compressed.length();
    // Keep original when compression does not produce a meaningful reduction.
    if (compressedSize >= originalSize || compressedSize == 0) return source;
    return compressed;
  }

  Future<Map<String, dynamic>> upload(
    File file, {
    String? objectPath,
    String? displayName,
    void Function(double progress)? onProgress,
  }) async {
    final uid = client.auth.currentUser?.id;
    if (uid == null) throw StateError('Sign in before sharing files.');
    final stat = await file.length();
    if (stat <= 0 || stat > maxBytes) {
      throw StateError('Files must be between 1 byte and 50 MB after compression.');
    }
    final name = (displayName?.trim().isNotEmpty == true)
        ? displayName!.trim()
        : p.basename(file.path);
    final mime = _normalizeMime(name);
    final ext = p.extension(name).replaceFirst('.', '').toLowerCase();
    final object = objectPath ?? '$uid/${_uuid.v4()}${ext.isEmpty ? '' : '.$ext'}';
    await _tusUpload(file, object, mime, onProgress: onProgress);
    final kind = mime.startsWith('image/')
        ? 'image'
        : mime.startsWith('video/')
            ? 'video'
            : mime.startsWith('audio/')
                ? 'audio'
                : 'file';
    final metadata = <String, dynamic>{
      '__likedin_media_v1': true,
      'path': object,
      'name': p.basename(name),
      'mime': mime,
      'size': stat,
      'kind': kind,
    };

    // Keep a local copy for the sender before the picker/cache source can be
    // removed. The sender should render the just-uploaded attachment from its
    // own cache instead of immediately downloading the same object through
    // Storage RLS. The receiver continues to download through the private bucket.
    try {
      await _cacheUploadedFile(file, metadata);
    } catch (_) {
      // A cache failure must not turn a successful remote upload into a failed send.
    }
    return metadata;
  }

  Future<File> _cacheUploadedFile(File source, Map<String, dynamic> metadata) async {
    final path = metadata['path']?.toString() ?? '';
    if (path.isEmpty) throw StateError('Uploaded media is missing its storage path.');
    final support = await getApplicationSupportDirectory();
    final cacheDir = Directory(p.join(support.path, 'LikedinMediaCache'));
    await cacheDir.create(recursive: true);
    final key = base64Url.encode(utf8.encode(path)).replaceAll('=', '');
    final ext = p.extension(metadata['name']?.toString() ?? '');
    final cached = File(p.join(cacheDir.path, '$key$ext'));
    final temp = File('${cached.path}.part');
    if (await temp.exists()) await temp.delete();
    await source.copy(temp.path);
    if (await cached.exists()) await cached.delete();
    return temp.rename(cached.path);
  }

  Future<void> _tusUpload(
    File file,
    String object,
    String mime, {
    void Function(double progress)? onProgress,
  }) async {
    final session = client.auth.currentSession;
    if (session == null) {
      throw StateError('Your session expired. Sign in again to resume media upload.');
    }
    final prefs = await SharedPreferences.getInstance();
    final resumeKey = '$_queueKey:tus:$object';
    final total = await file.length();
    final base = BackendConfig.supabaseUrl;
    final headers = <String, String>{
      'apikey': BackendConfig.supabaseAnonKey,
      'Authorization': 'Bearer ${session.accessToken}',
      'Tus-Resumable': '1.0.0',
    };

    Future<String> createTusSession() async {
      final metadata = {
        'bucketName': bucket,
        'objectName': object,
        'contentType': mime,
        'cacheControl': '3600',
      }.entries.map((e) => '${e.key} ${base64.encode(utf8.encode(e.value))}').join(',');
      final response = await http.post(
        Uri.parse('$base/storage/v1/upload/resumable'),
        headers: {
          ...headers,
          'Upload-Length': '$total',
          'Upload-Metadata': metadata,
        },
      );
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw HttpException('Could not start resumable upload (${response.statusCode}): ${response.body}');
      }
      final location = response.headers['location'];
      if (location == null) {
        throw const HttpException('Storage did not return a resumable upload location.');
      }
      final createdUrl = Uri.parse(base).resolve(location).toString();
      await prefs.setString(resumeKey, createdUrl);
      return createdUrl;
    }

    var uploadUrl = prefs.getString(resumeKey) ?? await createTusSession();
    var head = await http.head(Uri.parse(uploadUrl), headers: headers);
    if (head.statusCode == 404 || head.statusCode == 410 || head.statusCode == 400 || head.statusCode == 403) {
      // Stale or expired TUS session URL; discard and create a fresh session.
      await prefs.remove(resumeKey);
      uploadUrl = await createTusSession();
      head = await http.head(Uri.parse(uploadUrl), headers: headers);
    }
    if (head.statusCode < 200 || head.statusCode >= 300) {
      throw HttpException('Could not resume upload (${head.statusCode}).');
    }
    var offset = int.tryParse(head.headers['upload-offset'] ?? '0') ?? 0;
    final raf = await file.open(mode: FileMode.read);
    try {
      while (offset < total) {
        await raf.setPosition(offset);
        final length = min(_chunkSize, total - offset);
        final chunk = await raf.read(length);
        final response = await http.patch(
          Uri.parse(uploadUrl),
          headers: {
            ...headers,
            'Content-Type': 'application/offset+octet-stream',
            'Upload-Offset': '$offset',
          },
          body: chunk,
        );
        if (response.statusCode == 404 || response.statusCode == 410) {
          await prefs.remove(resumeKey);
        }
        if (response.statusCode < 200 || response.statusCode >= 300) {
          throw HttpException('Upload paused at $offset/$total bytes (${response.statusCode}).');
        }
        offset = int.tryParse(response.headers['upload-offset'] ?? '') ?? (offset + chunk.length);
        onProgress?.call(offset / total);
      }
    } finally {
      await raf.close();
    }
    await prefs.remove(resumeKey);
  }

  Future<void> enqueue(File file, String recipientId, {String? originalName}) async {
    final prefs = await SharedPreferences.getInstance();
    final queue = _readQueue(prefs);
    final id = _uuid.v4();
    // Picker/cache files may disappear after the app is closed. Copy each item
    // into app-private persistent storage before registering background work.
    final support = await getApplicationSupportDirectory();
    final pendingDir = Directory(p.join(support.path, 'LikedinPendingMedia'));
    await pendingDir.create(recursive: true);
    final resolvedName = (originalName?.trim().isNotEmpty == true)
        ? originalName!.trim()
        : p.basename(file.path);
    final ext = p.extension(resolvedName).isNotEmpty
        ? p.extension(resolvedName)
        : p.extension(file.path);
    final durableFile = File(p.join(pendingDir.path, '$id$ext'));
    await file.copy(durableFile.path);
    queue.add({
      'id': id,
      'path': durableFile.path,
      'recipient': recipientId,
      'originalName': resolvedName,
      'createdAt': DateTime.now().toUtc().toIso8601String(),
    });
    await prefs.setString(_queueKey, jsonEncode(queue));
  }

  static List<Map<String, dynamic>> _readQueue(SharedPreferences prefs) {
    try {
      final raw = jsonDecode(prefs.getString(_queueKey) ?? '[]') as List;
      return raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } catch (_) {
      return [];
    }
  }

  /// Called in the foreground. Failed items remain persisted for a later manual retry;
  /// TUS offset state lets the next attempt continue, not restart.
  static Future<bool> processRetryQueue(SupabaseClient client) async {
    lastQueueError = null;
    final uid = client.auth.currentUser?.id;
    if (uid == null) {
      lastQueueError = 'Sign in before sending queued attachments.';
      return false;
    }
    final prefs = await SharedPreferences.getInstance();
    final queue = _readQueue(prefs);
    if (queue.isEmpty) return true;
    final service = SharedMediaService(client);
    for (final item in List<Map<String, dynamic>>.from(queue)) {
      try {
        final path = item['path']?.toString() ?? '';
        final recipient = item['recipient']?.toString() ?? '';
        if (path.isEmpty || recipient.isEmpty || !await File(path).exists()) {
          throw StateError('Queued file is unavailable on this device.');
        }
        final file = File(path);
        final name = (item['originalName']?.toString().trim().isNotEmpty == true)
            ? item['originalName'].toString()
            : p.basename(path);
        final ext = p.extension(name).replaceFirst('.', '').toLowerCase();
        final object = '$uid/${item['id']}${ext.isEmpty ? '' : '.$ext'}';
        final metadata = await service.upload(file, objectPath: object, displayName: name);
        metadata['name'] = name;
        await client.rpc('likedin_send_message_v2', params: {
          'p_recipient_id': recipient,
          'p_payload': jsonEncode(metadata),
          'p_client_message_id': item['id'],
          'p_reply_to_message_id': null,
        });
        queue.removeWhere((q) => q['id'] == item['id']);
        await prefs.setString(_queueKey, jsonEncode(queue));
        try {
          await file.delete();
        } catch (_) {}
      } catch (error) {
        lastQueueError ??= error.toString();
        await prefs.setString(_queueKey, jsonEncode(queue));
        continue;
      }
    }
    return queue.isEmpty;
  }

  Future<String> signedUrl(String objectPath) =>
      client.storage.from(bucket).createSignedUrl(objectPath, 900);

  Future<void> _validateMediaPath(String path) async {
    if (path.isEmpty ||
        (!path.startsWith('${client.auth.currentUser?.id ?? ''}/') &&
            !(await _isPeerPath(path)))) {
      throw StateError('This attachment is not accessible to your account.');
    }
  }

  Future<File> cachedFile(Map<String, dynamic> metadata, {void Function(double progress)? onProgress}) async {
    final path = metadata['path']?.toString() ?? '';
    if (path.isEmpty) throw StateError('This attachment is missing its storage path.');

    // Check the device-private cache first. This is essential for the sender:
    // the sender already owns the uploaded bytes and must not need a Storage
    // read permission check just to display its own outgoing attachment.
    final support = await getApplicationSupportDirectory();
    final cacheDir = Directory(p.join(support.path, 'LikedinMediaCache'));
    await cacheDir.create(recursive: true);
    final key = base64Url.encode(utf8.encode(path)).replaceAll('=', '');
    final ext = p.extension(metadata['name']?.toString() ?? '');
    final cached = File(p.join(cacheDir.path, '$key$ext'));
    if (await cached.exists()) {
      if (await cached.length() > 0) {
        onProgress?.call(1);
        return cached;
      }
      await cached.delete();
    }

    // Only a cache miss needs a Storage permission/ownership check and
    // download. Receiver devices normally take this path on first display.
    await _validateMediaPath(path);
    final bytes = await client.storage.from(bucket).download(path);
    onProgress?.call(0.9);
    final temp = File('${cached.path}.part');
    if (await temp.exists()) await temp.delete();
    await temp.writeAsBytes(bytes, flush: true);
    if (await cached.exists()) await cached.delete();
    await temp.rename(cached.path);
    onProgress?.call(1);
    return cached;
  }

  Future<File> download(Map<String, dynamic> metadata, Directory destination, {void Function(double progress)? onProgress}) async {
    final cached = await cachedFile(metadata, onProgress: onProgress);
    await destination.create(recursive: true);
    final safe = (metadata['name']?.toString() ?? 'attachment').replaceAll(RegExp(r'[^A-Za-z0-9._ -]'), '_');
    final out = File(p.join(destination.path, '${_uuid.v4()}--$safe'));
    await cached.copy(out.path);
    return out;
  }

  Future<String> downloadToPublicDownloads(Map<String, dynamic> metadata) async {
    final cached = await cachedFile(metadata);
    final originalName = (metadata['name']?.toString() ?? 'attachment').replaceAll(RegExp(r'[^A-Za-z0-9._ -]'), '_');
    final safeName = originalName.isEmpty ? 'attachment' : originalName;
    final mime = metadata['mime']?.toString() ?? _normalizeMime(safeName);
    final tempDir = await getTemporaryDirectory();
    final temp = File(p.join(tempDir.path, 'likedin_download_${_uuid.v4()}'));
    await cached.copy(temp.path);
    try {
      return await const MethodChannel('com.example.likedin/downloads').invokeMethod<String>('saveToDownloads', {
            'sourcePath': temp.path,
            'displayName': safeName,
            'mimeType': mime,
          }) ??
          safeName;
    } finally {
      if (await temp.exists()) await temp.delete();
    }
  }

  Future<bool> _isPeerPath(String path) async {
    final parts = path.split('/');
    if (parts.length < 2) return false;
    final peer = await client.rpc('likedin_get_peer_id') as String?;
    return peer != null && parts.first == peer;
  }
}
