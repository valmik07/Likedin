import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { cert, getApps, initializeApp } from "npm:firebase-admin@12.7.0/app";
import { getMessaging } from "npm:firebase-admin@12.7.0/messaging";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-likedin-webhook-secret",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  const expected = Deno.env.get("LIKEDIN_PUSH_WEBHOOK_SECRET") ?? "";
  const supplied = req.headers.get("x-likedin-webhook-secret") ?? "";
  if (!expected || supplied.length !== expected.length || supplied !== expected) {
    return new Response("Unauthorized", { status: 401 });
  }

  try {
    const payload = await req.json();
    const row = payload.record ?? payload;
    const recipientId = row.recipient_id;
    const senderId = row.sender_id;
    if (!recipientId || !senderId) return new Response("Missing message participants", { status: 400 });

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRole = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceRole, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    const { data: tokens, error } = await supabase
      .from("likedin_push_tokens")
      .select("token")
      .eq("user_id", recipientId);
    if (error) throw error;
    if (!tokens?.length) return new Response(JSON.stringify({ sent: 0, reason: "no_tokens" }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const serviceAccountRaw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT_JSON");
    if (!serviceAccountRaw) throw new Error("FIREBASE_SERVICE_ACCOUNT_JSON secret is missing");
    const serviceAccount = JSON.parse(serviceAccountRaw);
    const app = getApps().length
      ? getApps()[0]
      : initializeApp({ credential: cert(serviceAccount), projectId: serviceAccount.project_id });

    const messaging = getMessaging(app);
    let sent = 0;
    const invalidTokens: string[] = [];
    for (const item of tokens) {
      try {
        // Send data-only + high priority so Android always wakes
        // likedinFirebaseBackgroundHandler to display the notification and
        // acknowledge message delivery via likedin_mark_message_delivered.
        await messaging.send({
          token: item.token,
          notification: {
            title: "Likedin",
            body: "You received a new message.",
          },
          data: {
            route: "chat",
            message_id: String(row.id ?? ""),
            notification_title: "Likedin",
            notification_body: "You received a new message.",
          },
          android: {
            priority: "high",
            ttl: 60 * 60 * 24 * 28 * 1000,
            notification: {
              channelId: "likedin_messages_v1",
              sound: "likedin_message",
              priority: "high",
            },
          },
        });
        sent++;
      } catch (error) {
        const code = (error as { code?: string }).code ?? "";
        if (code.includes("registration-token-not-registered") || code.includes("invalid-registration-token")) {
          invalidTokens.push(item.token);
        } else {
          console.error("FCM send failed", code, error);
        }
      }
    }
    if (invalidTokens.length) {
      await supabase.from("likedin_push_tokens").delete().eq("user_id", recipientId).in("token", invalidTokens);
    }
    return new Response(JSON.stringify({ sent, invalid_tokens_removed: invalidTokens.length }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error(error);
    return new Response("Push delivery failed", { status: 500 });
  }
});
