import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import 'backend/backend_config.dart';
import 'backend/realtime_messaging_service.dart';
import 'backend/shared_media_service.dart';
import 'notifications/notification_service.dart';
import 'calls/call_service.dart';
import 'calls/call_alert_controller.dart';
import 'calls/proximity_call_controller.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:video_player/video_player.dart';
import 'package:record/record.dart';
import 'package:just_audio/just_audio.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:photo_manager/photo_manager.dart' show AssetEntity;

import 'data/attachment_vault_store.dart';
import 'auth/local_account_store.dart';
import 'security/encrypted_backup_codec.dart';
import 'utils/message_length.dart';
import 'ui/glassmorphism.dart';
import 'ui/message_search.dart';
import 'ui/in_app_gallery_picker.dart';

/// A restrained animated focal point for the full-screen calling experience.
/// Animation is local to the active call UI and is disposed with the widget.
class _CallHaloAvatar extends StatefulWidget {
  const _CallHaloAvatar({required this.icon, this.size = 148});
  final IconData icon;
  final double size;

  @override
  State<_CallHaloAvatar> createState() => _CallHaloAvatarState();
}

class _CallHaloAvatarState extends State<_CallHaloAvatar>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulse;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _pulse,
        builder: (context, _) {
          final t = Curves.easeInOut.transform(_pulse.value);
          return SizedBox(
            width: widget.size * 1.18,
            height: widget.size * 1.18,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: widget.size * (1.02 + .14 * t),
                  height: widget.size * (1.02 + .14 * t),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: const Color(0xFF5DDCFF).withValues(alpha: .16 + .20 * (1 - t)),
                    ),
                  ),
                ),
                Transform.scale(
                  scale: .96 + .04 * t,
                  child: Container(
                    width: widget.size,
                    height: widget.size,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [Color(0xFF244B70), Color(0xFF10243C)],
                      ),
                      border: Border.all(color: const Color(0xFF67DFFF).withValues(alpha: .72), width: 1.4),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFF36CFFF).withValues(alpha: .12 + .13 * t),
                          blurRadius: 30 + 14 * t,
                          spreadRadius: 3 + 4 * t,
                        ),
                      ],
                    ),
                    child: Icon(widget.icon, color: Colors.white, size: widget.size * .46),
                  ),
                ),
              ],
            ),
          );
        },
      );
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Bound decoded-image memory for 3 GB Android devices. Gallery thumbnails
  // are small, while full-size media is decoded only in the viewer.
  final imageCache = PaintingBinding.instance.imageCache;
  imageCache.maximumSize = 80;
  imageCache.maximumSizeBytes = 32 * 1024 * 1024;
  try {
    await ensureLikedinFirebaseReady();
  } catch (error) {
    debugPrint('Firebase bootstrap initialization failed: $error');
  }
  runApp(const LikedinBootstrap());
}

class LikedinBootstrap extends StatefulWidget {
  const LikedinBootstrap({super.key});
  @override
  State<LikedinBootstrap> createState() => _LikedinBootstrapState();
}

class _LikedinBootstrapState extends State<LikedinBootstrap> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 850),
  )..forward();
  Widget? _readyApp;
  String? _error;
  bool _supabaseInitialized = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _initialize());
  }

  Future<void> _initialize() async {
    try {
      if (!_supabaseInitialized) {
        await Supabase.initialize(
          url: BackendConfig.supabaseUrl,
          publishableKey: BackendConfig.supabaseAnonKey,
        );
        _supabaseInitialized = true;
      }
      try {
        await LikedinNotificationService.instance.initialize();
      } catch (error) {
        debugPrint('Notification setup failed; continuing app startup: $error');
      }
      final attachmentVault = AttachmentVaultStore();
      final preferences = await SharedPreferences.getInstance();
      likedinThemeMode.value = preferences.getBool(likedinThemePreferenceKey) == true
          ? ThemeMode.dark
          : ThemeMode.light;
      final uid = Supabase.instance.client.auth.currentUser?.id;
      likedinProfilePhotoPath.value = uid == null ? null : preferences.getString('${likedinProfilePhotoPreferenceKey}_$uid');
      if (!mounted) return;
      setState(() => _readyApp = LikedinApp(attachmentVault: attachmentVault));
    } catch (e) {
      if (mounted) {
        setState(() => _error = 'Could not start Likedin. Check your connection and try again.');
      }
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_readyApp != null) return _readyApp!;
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Colors.white,
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFFEAF4FF), Colors.white, Colors.white],
            ),
          ),
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ScaleTransition(
                  scale: CurvedAnimation(parent: _controller, curve: Curves.easeOutBack),
                  child: FadeTransition(
                    opacity: _controller,
                    child: Container(
                      width: 112,
                      height: 112,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(32),
                        boxShadow: const [
                          BoxShadow(color: Color(0x180A66C2), blurRadius: 28, offset: Offset(0, 12))
                        ],
                      ),
                      child: const Center(child: LikedinLogo(size: 66)),
                    ),
                  ),
                ),
                const SizedBox(height: 22),
                const Text(
                  'Likedin',
                  style: TextStyle(color: ink, fontSize: 22, fontWeight: FontWeight.w800, letterSpacing: -.5),
                ),
                if (_error != null) ...[
                  const SizedBox(height: 20),
                  Text(_error!, textAlign: TextAlign.center),
                  TextButton(
                    onPressed: () {
                      setState(() => _error = null);
                      _initialize();
                    },
                    child: const Text('Retry'),
                  ),
                ]
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class CodePointLengthLimitingTextInputFormatter extends TextInputFormatter {
  const CodePointLengthLimitingTextInputFormatter(this.maxCodePoints);
  final int maxCodePoints;

  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    final runes = newValue.text.runes;
    if (likedinMessageCodePointLength(newValue.text) <= maxCodePoints) return newValue;
    final limited = String.fromCharCodes(runes.take(maxCodePoints));
    final offset = newValue.selection.extentOffset.clamp(0, limited.length);
    return TextEditingValue(
      text: limited,
      selection: TextSelection.collapsed(offset: offset),
      composing: TextRange.empty,
    );
  }
}

const likedinVersion = '1.9.3+92';
bool _globalCallDialogActive = false;
const brandBlue = Color(0xFF0A66C2);
const MethodChannel _keyboardMediaChannel = MethodChannel('com.example.likedin/keyboard_media');
const ink = Color(0xFF172B4D);
const muted = Color(0xFF667085);
const page = Color(0xFFF3F6F8);
final ValueNotifier<ThemeMode> likedinThemeMode = ValueNotifier<ThemeMode>(ThemeMode.light);
const String likedinThemePreferenceKey = 'likedin_theme_mode_v1';
const String likedinProfilePhotoPreferenceKey = 'likedin_profile_photo_path_v1';
final ValueNotifier<String?> likedinProfilePhotoPath = ValueNotifier<String?>(null);

/// One theme definition for both brightnesses so every page, sheet, dialog and
/// control shares the same shapes, spacing and tonal surfaces.
ThemeData _likedinTheme(Brightness brightness) {
  final dark = brightness == Brightness.dark;
  final background = likedinBackground(brightness);
  final surface = likedinSurface(brightness);
  final outline = likedinOutline(brightness);
  final raised = likedinSurfaceRaised(brightness);
  final primary = dark ? const Color(0xFF8DB8FF) : brandBlue;
  final onSurface = dark ? const Color(0xFFE8EEF9) : const Color(0xFF0F1B2D);
  final scheme = ColorScheme.fromSeed(
    seedColor: brandBlue,
    brightness: brightness,
    surface: surface,
  ).copyWith(primary: primary, outline: outline);
  const pillShape = StadiumBorder();
  return ThemeData(
    useMaterial3: true,
    brightness: brightness,
    scaffoldBackgroundColor: background,
    colorScheme: scheme,
    dividerColor: outline,
    appBarTheme: AppBarTheme(
      backgroundColor: background,
      foregroundColor: onSurface,
      elevation: 0,
      scrolledUnderElevation: 0,
      surfaceTintColor: Colors.transparent,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      indicatorColor: primary.withValues(alpha: dark ? .22 : .12),
      indicatorShape: pillShape,
      elevation: 0,
      height: 68,
      labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
      labelTextStyle: WidgetStateProperty.resolveWith(
        (states) => TextStyle(
          fontSize: 12,
          fontWeight: states.contains(WidgetState.selected)
              ? FontWeight.w700
              : FontWeight.w500,
        ),
      ),
    ),
    cardTheme: CardThemeData(
      color: surface,
      elevation: 0,
      margin: EdgeInsets.zero,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: outline),
      ),
    ),
    dividerTheme: DividerThemeData(color: outline, thickness: 1, space: 1),
    listTileTheme: const ListTileThemeData(
      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 2),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(16)),
      ),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: dark ? const Color(0xFFE8EEF9) : const Color(0xFF16233A),
      contentTextStyle: TextStyle(
        color: dark ? const Color(0xFF0F1B2D) : Colors.white,
        fontSize: 14,
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: surface,
      surfaceTintColor: Colors.transparent,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
    ),
    dialogTheme: DialogThemeData(
      backgroundColor: surface,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
    ),
    popupMenuTheme: PopupMenuThemeData(
      color: surface,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: outline),
      ),
    ),
    chipTheme: ChipThemeData(
      shape: pillShape,
      side: BorderSide(color: outline),
      backgroundColor: raised,
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith(
        (states) => states.contains(WidgetState.selected)
            ? (dark ? const Color(0xFF0A101C) : Colors.white)
            : (dark ? const Color(0xFF8795AD) : const Color(0xFF7B8798)),
      ),
      trackColor: WidgetStateProperty.resolveWith(
        (states) => states.contains(WidgetState.selected) ? primary : raised,
      ),
      trackOutlineColor: WidgetStateProperty.resolveWith(
        (states) => states.contains(WidgetState.selected)
            ? Colors.transparent
            : (dark ? const Color(0xFF3A4963) : const Color(0xFFC9D2E0)),
      ),
    ),
    progressIndicatorTheme: ProgressIndicatorThemeData(color: primary),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        shape: pillShape,
        minimumSize: const Size(0, 48),
        padding: const EdgeInsets.symmetric(horizontal: 22),
        textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        shape: pillShape,
        minimumSize: const Size(0, 46),
        side: BorderSide(color: dark ? const Color(0xFF3A4963) : const Color(0xFFC9D2E0)),
        textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        shape: pillShape,
        textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: raised,
      hintStyle: TextStyle(color: dark ? const Color(0xFF8795AD) : const Color(0xFF7B8798)),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: primary, width: 1.6),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
    ),
  );
}

class LikedinApp extends StatelessWidget {
  const LikedinApp({required this.attachmentVault, super.key});
  final AttachmentVaultStore attachmentVault;

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<ThemeMode>(
        valueListenable: likedinThemeMode,
        builder: (context, mode, _) => MaterialApp(
          title: 'Likedin',
          debugShowCheckedModeBanner: false,
          themeMode: mode,
          theme: _likedinTheme(Brightness.light),
          darkTheme: _likedinTheme(Brightness.dark),
          home: AuthGate(attachmentVault: attachmentVault),
        ),
      );
}

class AuthGate extends StatelessWidget {
  const AuthGate({required this.attachmentVault, super.key});
  final AttachmentVaultStore attachmentVault;

  @override
  Widget build(BuildContext context) => StreamBuilder<AuthState>(
        stream: Supabase.instance.client.auth.onAuthStateChange,
        builder: (context, snapshot) {
          final user = Supabase.instance.client.auth.currentUser;
          if (user == null) {
            return const SignInPage();
          }
          final account = LikedinAccount(
            displayName: (user.userMetadata?['display_name'] as String?) ??
                user.email?.split('@').first ??
                'Likedin user',
            likedinId: user.email ?? user.id,
            salt: '',
            passwordHash: '',
            createdAt: user.createdAt,
          );
          return AppShell(
            attachmentVault: attachmentVault,
            account: account,
            onSignOut: () async {
              await LikedinNotificationService.instance.unregisterCurrentToken();
              likedinProfilePhotoPath.value = null;
              try {
                await Supabase.instance.client.rpc('likedin_set_presence', params: {'p_online': false});
              } catch (_) {}
              await Supabase.instance.client.auth.signOut();
            },
          );
        },
      );
}

class SignInPage extends StatefulWidget {
  const SignInPage({super.key});
  @override
  State<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final nameController = TextEditingController();
  bool creating = false;
  bool busy = false;
  bool obscure = true;
  String? error;
  String? notice;

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    nameController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final email = emailController.text.trim();
    final password = passwordController.text;
    if (email.isEmpty || !email.contains('@')) {
      setState(() => error = 'Enter a valid email address.');
      return;
    }
    if (password.length < 8) {
      setState(() => error = 'Password must contain at least 8 characters.');
      return;
    }
    if (creating && nameController.text.trim().isEmpty) {
      setState(() => error = 'Enter your display name.');
      return;
    }
    setState(() {
      busy = true;
      error = null;
      notice = null;
    });
    try {
      if (creating) {
        final canRegister = await Supabase.instance.client.rpc('likedin_can_register_account');
        if (canRegister != true) {
          if (mounted) setState(() => error = 'Both Likedin account slots are currently occupied.');
          return;
        }
        final response = await Supabase.instance.client.auth.signUp(
          email: email,
          password: password,
          data: {'display_name': nameController.text.trim()},
          emailRedirectTo: 'com.example.likedin://login-callback/',
        );
        if (response.session == null) {
          setState(() => notice =
              'Account request accepted. Check your email and confirm it, then return here to sign in.');
        }
      } else {
        await Supabase.instance.client.auth.signInWithPassword(
          email: email,
          password: password,
        );
      }
    } on AuthException catch (e) {
      final message = e.message;
      var pairFull = message.contains('LIKEDIN_PAIR_FULL') ||
          message.toLowerCase().contains('limited to two');
      // GoTrue may wrap a BEFORE INSERT trigger rejection as the generic
      // "Database error saving new user" message. Re-check slot availability
      // before translating that error; do not mislabel unrelated Auth failures.
      if (creating && !pairFull && message.toLowerCase().contains('database error')) {
        try {
          final available = await Supabase.instance.client.rpc('likedin_can_register_account');
          pairFull = available != true;
        } catch (_) {
          // Preserve the original Auth error when the diagnostic RPC is down.
        }
      }
      if (mounted) {
        setState(() => error = pairFull
            ? 'Both Likedin account slots are currently occupied.'
            : message);
      }
    } catch (e) {
      setState(() => error = 'Could not connect. Check your internet and try again.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => AuroraBackdrop(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 430),
                  child: GlassPanel(
                    padding: const EdgeInsets.fromLTRB(22, 24, 22, 22),
                    radius: BorderRadius.circular(28),
                    blur: 5,
                    glow: false,
                    child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Align(alignment: Alignment.centerLeft, child: LikedinLogo(size: 52)),
                    const SizedBox(height: 22),
                    const Text(
                      'Your space.\nYour people.',
                      style: TextStyle(fontSize: 36, height: 1.06, fontWeight: FontWeight.w800, letterSpacing: -1.3),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Private messages, calls and files, just for the two of you.',
                      style: TextStyle(fontSize: 15, height: 1.4, color: Theme.of(context).hintColor),
                    ),
                    const SizedBox(height: 28),
                    Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: likedinSurfaceRaised(Theme.of(context).brightness),
                        borderRadius: BorderRadius.circular(30),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: _AuthTab(
                              label: 'Sign in',
                              selected: !creating,
                              onTap: () => setState(() {
                                creating = false;
                                error = null;
                                notice = null;
                              }),
                            ),
                          ),
                          Expanded(
                            child: _AuthTab(
                              label: 'Create account',
                              selected: creating,
                              onTap: () => setState(() {
                                creating = true;
                                error = null;
                                notice = null;
                              }),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 22),
                    Text(
                      creating ? 'Create your Likedin account' : 'Welcome back',
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: -.3),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      creating
                          ? 'Use your own email address. The server enforces the two-account limit.'
                          : 'Sign in from any device using your email.',
                      style: TextStyle(height: 1.4, color: Theme.of(context).hintColor),
                    ),
                    const SizedBox(height: 20),
                    if (creating) ...[
                      _AuthField(
                        controller: nameController,
                        label: 'Your name',
                        hint: 'How should we call you?',
                        icon: Icons.person_outline,
                      ),
                      const SizedBox(height: 13),
                    ],
                    _AuthField(
                      controller: emailController,
                      label: 'Email address',
                      hint: 'you@example.com',
                      icon: Icons.email_outlined,
                      keyboardType: TextInputType.emailAddress,
                    ),
                    const SizedBox(height: 13),
                    _AuthField(
                      controller: passwordController,
                      label: 'Password',
                      hint: 'At least 8 characters',
                      icon: Icons.lock_outline,
                      obscure: obscure,
                      suffix: IconButton(
                        tooltip: obscure ? 'Show password' : 'Hide password',
                        onPressed: () => setState(() => obscure = !obscure),
                        icon: Icon(obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                      ),
                    ),
                    const SizedBox(height: 16),
                    if (error != null) _AuthError(message: error!),
                    if (notice != null)
                      Container(
                        padding: const EdgeInsets.all(12),
                        margin: const EdgeInsets.only(bottom: 12),
                        decoration: BoxDecoration(
                          color: const Color(0xFF16865A).withValues(alpha: .14),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Text(
                          notice!,
                          style: TextStyle(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? const Color(0xFF7FDDB5)
                                : const Color(0xFF176B45),
                            fontSize: 13,
                          ),
                        ),
                      ),
                    FilledButton(
                      onPressed: busy ? null : _submit,
                      style: _primaryButtonStyle,
                      child: busy
                          ? const SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                            )
                          : Text(creating ? 'Create account' : 'Sign in'),
                    ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
      );
}

class _AuthTab extends StatelessWidget {
  const _AuthTab({required this.label, required this.selected, required this.onTap});
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: selected ? likedinSurface(Theme.of(context).brightness) : Colors.transparent,
            borderRadius: BorderRadius.circular(26),
            boxShadow: selected
                ? [const BoxShadow(color: Color(0x14000000), blurRadius: 6, offset: Offset(0, 1))]
                : null,
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontWeight: FontWeight.w700,
              color: selected ? Theme.of(context).colorScheme.primary : Theme.of(context).hintColor,
            ),
          ),
        ),
      );
}

class _AuthField extends StatelessWidget {
  const _AuthField({
    required this.controller,
    required this.label,
    required this.hint,
    required this.icon,
    this.obscure = false,
    this.suffix,
    this.keyboardType,
  });
  final TextEditingController controller;
  final String label;
  final String hint;
  final IconData icon;
  final bool obscure;
  final Widget? suffix;
  final TextInputType? keyboardType;

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
          const SizedBox(height: 7),
          TextField(
            controller: controller,
            obscureText: obscure,
            keyboardType: keyboardType,
            autocorrect: false,
            enableSuggestions: !obscure,
            decoration: InputDecoration(
              hintText: hint,
              prefixIcon: Icon(icon, size: 19),
              suffixIcon: suffix,
            ),
          ),
        ],
      );
}

Color _errorTone(BuildContext context) =>
    Theme.of(context).brightness == Brightness.dark ? const Color(0xFFFF9AA0) : const Color(0xFFB42318);

class _AuthError extends StatelessWidget {
  const _AuthError({required this.message});
  final String message;
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(11),
        decoration: BoxDecoration(
          color: const Color(0xFFE5484D).withValues(alpha: .13),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            Icon(Icons.error_outline, color: _errorTone(context), size: 18),
            const SizedBox(width: 8),
            Expanded(child: Text(message, style: TextStyle(color: _errorTone(context), fontSize: 13))),
          ],
        ),
      );
}

const ButtonStyle _primaryButtonStyle = ButtonStyle(
  minimumSize: WidgetStatePropertyAll(Size.fromHeight(50)),
  backgroundColor: WidgetStatePropertyAll(brandBlue),
  foregroundColor: WidgetStatePropertyAll(Colors.white),
  textStyle: WidgetStatePropertyAll(TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
  shape: WidgetStatePropertyAll(StadiumBorder()),
);

class LikedinLogo extends StatelessWidget {
  const LikedinLogo({super.key, this.size = 36});
  final double size;
  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        alignment: Alignment.center,
        decoration: BoxDecoration(color: brandBlue, borderRadius: BorderRadius.circular(size * .19)),
        child: Text(
          'in',
          style: TextStyle(
            color: Colors.white,
            fontSize: size * .61,
            fontWeight: FontWeight.w800,
            letterSpacing: -1.5,
            height: 1,
          ),
        ),
      );
}

class AppShell extends StatefulWidget {
  const AppShell({
    required this.attachmentVault,
    required this.account,
    required this.onSignOut,
    super.key,
  });
  final AttachmentVaultStore attachmentVault;
  final LikedinAccount account;
  final Future<void> Function() onSignOut;
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> with WidgetsBindingObserver {
  int index = 0;
  final Set<int> _visitedTabs = <int>{0};
  RealtimeChannel? _incomingCallsChannel;
  final Set<String> _handledIncomingCallIds = <String>{};
  bool _incomingDialogOpen = false;

  void _switchTab(int nextIndex) {
    if (!mounted) return;
    final wasChat = index == 1;
    setState(() {
      index = nextIndex;
      _visitedTabs.add(nextIndex);
    });
    if (wasChat && nextIndex != 1) {
      LikedinNotificationService.instance.setConversationVisible(false);
      unawaited(_recoverIncomingCalls());
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    LikedinNotificationService.instance.setOnOpenChat(() {
      _switchTab(1);
    });
    LikedinNotificationService.instance.setOnOpenIncomingCall(_openIncomingCallById);
    LikedinNotificationService.instance.setOnOpenCalls(() {
      _switchTab(2);
    });
    LikedinNotificationService.instance.registerCurrentToken();
    _loadAccountProfilePhoto();
    _watchIncomingCalls();
  }

  Future<void> _loadAccountProfilePhoto() async {
    try {
      final client = Supabase.instance.client;
      final uid = client.auth.currentUser?.id;
      if (uid == null) {
        likedinProfilePhotoPath.value = null;
        return;
      }
      final prefs = await SharedPreferences.getInstance();
      final prefKey = '${likedinProfilePhotoPreferenceKey}_$uid';
      final localPath = prefs.getString(prefKey);
      if (localPath != null && localPath.isNotEmpty && File(localPath).existsSync()) {
        if (mounted) {
          likedinProfilePhotoPath.value = localPath;
        }
        return;
      }
      final remotePath = await RealtimeMessagingService(client).getOwnProfileAvatarPath();
      if (remotePath == null || remotePath.isEmpty) {
        if (mounted) {
          likedinProfilePhotoPath.value = null;
        }
        return;
      }
      final cached = await SharedMediaService(client).cachedFile(<String, dynamic>{
        'path': remotePath,
        'name': p.basename(remotePath),
      });
      final support = await getApplicationSupportDirectory();
      final ext = p.extension(remotePath).isNotEmpty ? p.extension(remotePath) : '.jpg';
      final restored = File('${support.path}/likedin_profile_photo_${uid}_restored$ext');
      await cached.copy(restored.path);
      await prefs.setString(prefKey, restored.path);
      if (mounted) {
        likedinProfilePhotoPath.value = restored.path;
      }
    } catch (error) {
      debugPrint('Could not load account profile photo: $error');
    }
  }

  @override
  void didHaveMemoryPressure() {
    // Release decoded bitmaps promptly on lower-memory Android devices.
    final cache = PaintingBinding.instance.imageCache;
    cache.clear();
    cache.clearLiveImages();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // Realtime does not replay inserts that happened while this process was
      // backgrounded or disconnected. Reconcile ringing rows on every resume.
      unawaited(_recoverIncomingCalls());
    }
  }

  Future<void> _openIncomingCallById(String callId) async {
    try {
      final row = await Supabase.instance.client
          .from('likedin_calls')
          .select()
          .eq('id', callId)
          .eq('status', 'ringing')
          .maybeSingle();
      if (row != null && mounted) await _showIncomingCall(Map<String, dynamic>.from(row));
    } catch (e) {
      debugPrint('Could not open call from notification: $e');
    }
  }

  Future<void> _watchIncomingCalls() async {
    final client = Supabase.instance.client;
    final uid = client.auth.currentUser?.id;
    if (uid == null) return;
    _incomingCallsChannel = client
        .channel('likedin-incoming-calls-$uid')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'likedin_calls',
          filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'callee_id', value: uid),
          callback: (payload) {
            final row = payload.newRecord;
            if (row['status'] == 'ringing') _showIncomingCall(Map<String, dynamic>.from(row));
          },
        )
      ..subscribe();
    await _recoverIncomingCalls();
  }

  Future<void> _recoverIncomingCalls() async {
    final client = Supabase.instance.client;
    final uid = client.auth.currentUser?.id;
    if (uid == null) return;
    try {
      final pending = await client
          .from('likedin_calls')
          .select()
          .eq('callee_id', uid)
          .eq('status', 'ringing')
          .order('created_at', ascending: false)
          .limit(3);
      for (final row in pending) {
        await _showIncomingCall(Map<String, dynamic>.from(row));
        if (_incomingDialogOpen) break;
      }
    } catch (e) {
      debugPrint('Incoming-call recovery query failed: $e');
    }
  }

  Future<void> _showIncomingCall(Map<String, dynamic> callRow) async {
    // When the conversation is already visible, its inline invitation owns the
    // accept/decline action and starts the ringtone alert.
    if (LikedinNotificationService.instance.isConversationVisible) return;
    final id = callRow['id']?.toString();
    if (!mounted || id == null || _incomingDialogOpen || !_handledIncomingCallIds.add(id)) return;
    await LikedinNotificationService.instance.cancelIncomingCall(id);
    final client = Supabase.instance.client;
    try {
      Map<String, dynamic>? offer;
      for (var attempt = 0; attempt < 60 && offer == null; attempt++) {
        final rows = await client
            .from('likedin_call_signals')
            .select('payload')
            .eq('call_id', id)
            .eq('kind', 'offer')
            .order('created_at', ascending: false)
            .limit(1);
        if (rows.isNotEmpty) offer = Map<String, dynamic>.from(rows.first['payload'] as Map);
        if (offer == null) {
          final latest = await client.from('likedin_calls').select('status').eq('id', id).maybeSingle();
          if (latest == null || latest['status'] != 'ringing') break;
          await Future<void>.delayed(const Duration(milliseconds: 500));
        }
      }
      if (offer == null || !mounted) {
        _handledIncomingCallIds.remove(id);
        return;
      }
      _incomingDialogOpen = true;
      if (_globalCallDialogActive) {
        _incomingDialogOpen = false;
        _handledIncomingCallIds.remove(id);
        return;
      }
      _globalCallDialogActive = true;
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (_) => _IncomingCallDialog(
          callId: id,
          callerId: callRow['caller_id'].toString(),
          offer: offer!,
          withVideo: callRow['call_type']?.toString().toLowerCase() == 'video',
        ),
      );
    } catch (e) {
      debugPrint('Could not present incoming call: $e');
      _handledIncomingCallIds.remove(id);
    } finally {
      _incomingDialogOpen = false;
      _globalCallDialogActive = false;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    final channel = _incomingCallsChannel;
    if (channel != null) Supabase.instance.client.removeChannel(channel);
    super.dispose();
  }

  Future<void> _pickProfilePhoto() async {
    File? destination;
    String? uploadedObjectPath;
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.image,
        allowMultiple: false,
        withData: false,
      );
      if (result == null || result.files.single.path == null) return;
      final source = File(result.files.single.path!);
      final size = await source.length();
      if (size <= 0 || size > 5 * 1024 * 1024) {
        throw StateError('Profile photos must be between 1 byte and 5 MB.');
      }
      final support = await getApplicationSupportDirectory();
      final extension = result.files.single.extension?.toLowerCase();
      final safeExtension = switch (extension) {
        'png' => 'png',
        'webp' => 'webp',
        'gif' => 'gif',
        'heic' => 'heic',
        'heif' => 'heif',
        _ => 'jpg',
      };
      final contentType = switch (safeExtension) {
        'png' => 'image/png',
        'webp' => 'image/webp',
        'gif' => 'image/gif',
        'heic' => 'image/heic',
        'heif' => 'image/heif',
        _ => 'image/jpeg',
      };
      final client = Supabase.instance.client;
      final uid = client.auth.currentUser?.id;
      if (uid == null) throw StateError('Sign in before changing your profile photo.');
      final prefs = await SharedPreferences.getInstance();
      final accountPhotoKey = '${likedinProfilePhotoPreferenceKey}_$uid';
      final previousLocalPath = prefs.getString(accountPhotoKey);
      final oldProfile = await client
          .from('profiles')
          .select('avatar_path')
          .eq('user_id', uid)
          .maybeSingle();
      final previousRemotePath = oldProfile?['avatar_path']?.toString();

      destination = File(
        '${support.path}/likedin_profile_photo_${uid}_${DateTime.now().millisecondsSinceEpoch}.$safeExtension',
      );
      await destination.writeAsBytes(await source.readAsBytes(), flush: true);
      await FileImage(destination).evict();

      final timestamp = DateTime.now().millisecondsSinceEpoch;
      uploadedObjectPath = '$uid/avatars/profile_$timestamp.$safeExtension';
      await client.storage.from('likedin-media').upload(
        uploadedObjectPath,
        destination,
        fileOptions: FileOptions(
          cacheControl: '86400',
          upsert: false,
          contentType: contentType,
        ),
      );
      try {
        await RealtimeMessagingService(client).setProfileAvatarPath(uploadedObjectPath);
      } catch (_) {
        try { await client.storage.from('likedin-media').remove([uploadedObjectPath]); } catch (_) {}
        rethrow;
      }

      // Commit local state only after the private remote object and profile row
      // are both updated. This keeps the previous photo if the upload fails.
      await prefs.setString(accountPhotoKey, destination.path);
      likedinProfilePhotoPath.value = destination.path;
      if (previousLocalPath != null && previousLocalPath != destination.path) {
        final previousFile = File(previousLocalPath);
        await FileImage(previousFile).evict();
        if (await previousFile.exists()) {
          try { await previousFile.delete(); } catch (_) {}
        }
      }
      if (previousRemotePath != null &&
          previousRemotePath.isNotEmpty &&
          previousRemotePath != uploadedObjectPath &&
          previousRemotePath.startsWith('$uid/avatars/')) {
        try { await client.storage.from('likedin-media').remove([previousRemotePath]); } catch (_) {}
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Profile photo updated and synced to your friend.')),
        );
      }
    } catch (e) {
      if (destination != null &&
          likedinProfilePhotoPath.value != destination.path &&
          await destination.exists()) {
        try {
          await destination.delete();
        } catch (_) {}
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not sync profile photo: $e')),
        );
      }
    }
  }

  void _openProfileMenu() {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.person_outline),
              title: Text(widget.account.displayName),
              subtitle: Text(widget.account.likedinId),
            ),
            ListTile(
              leading: const Icon(Icons.photo_camera_outlined),
              title: const Text('Add or change profile photo'),
              onTap: () {
                Navigator.pop(sheetContext);
                _pickProfilePhoto();
              },
            ),
            ListTile(
              leading: const Icon(Icons.folder_outlined),
              title: const Text('Your files'),
              onTap: () {
                Navigator.pop(sheetContext);
                _switchTab(3);
              },
            ),
            ListTile(
              leading: const Icon(Icons.logout_rounded, color: Color(0xFFB42318)),
              title: const Text('Sign out', style: TextStyle(color: Color(0xFFB42318))),
              onTap: () {
                Navigator.pop(sheetContext);
                widget.onSignOut();
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _profileAvatar(bool dark) => ValueListenableBuilder<String?>(
        valueListenable: likedinProfilePhotoPath,
        builder: (context, path, _) {
          final file = path == null ? null : File(path);
          return CircleAvatar(
            radius: 18,
            backgroundColor: dark ? const Color(0xFF29445B) : const Color(0xFFDCEBFA),
            backgroundImage: file != null && file.existsSync() ? FileImage(file) : null,
            child: file != null && file.existsSync()
                ? null
                : const Icon(Icons.person, color: brandBlue, size: 20),
          );
        },
      );

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final pages = List<Widget>.generate(5, (pageIndex) {
      if (!_visitedTabs.contains(pageIndex)) return const SizedBox.shrink();
      late final Widget page;
      switch (pageIndex) {
        case 0:
          page = HomePage(displayName: widget.account.displayName);
          break;
        case 1:
          page = ChatPage(isActive: index == 1, onBack: () => _switchTab(0));
          break;
        case 2:
          page = const CallsPage();
          break;
        case 3:
          page = FilesPage(store: widget.attachmentVault, isActive: index == 3);
          break;
        default:
          page = SettingsPage(account: widget.account, onSignOut: widget.onSignOut);
      }
      return TickerMode(enabled: index == pageIndex, child: page);
    }, growable: false);
    return PopScope<Object?>(
      canPop: index == 0,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop && index != 0 && mounted) {
          _switchTab(0);
        }
      },
      child: AuroraBackdrop(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: SafeArea(
            child: Column(
              children: [
                if (index != 1)
                  Padding(
                      padding: const EdgeInsets.fromLTRB(20, 8, 12, 2),
                      child: Row(
                        children: [
                          const LikedinLogo(size: 34),
                          const SizedBox(width: 11),
                          const Expanded(
                            child: Text(
                              'Likedin',
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w800,
                                letterSpacing: -.6,
                              ),
                            ),
                          ),
                          IconButton(
                            tooltip: 'More',
                            onPressed: () => showModalBottomSheet<void>(
                              context: context,
                              showDragHandle: true,
                              builder: (sheetContext) => SafeArea(
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    ListTile(
                                      leading: const Icon(Icons.chat_bubble_outline),
                                      title: const Text('Chat'),
                                      onTap: () {
                                        Navigator.pop(sheetContext);
                                        _switchTab(1);
                                      },
                                    ),
                                    ListTile(
                                      leading: const Icon(Icons.call_outlined),
                                      title: const Text('Voice and video calls'),
                                      onTap: () {
                                        Navigator.pop(sheetContext);
                                        _switchTab(2);
                                      },
                                    ),
                                    ListTile(
                                      leading: const Icon(Icons.settings_outlined),
                                      title: const Text('Settings & privacy'),
                                      onTap: () {
                                        Navigator.pop(sheetContext);
                                        _switchTab(4);
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            icon: const Icon(Icons.more_horiz),
                          ),
                          IconButton(
                            tooltip: 'Profile menu',
                            onPressed: _openProfileMenu,
                            icon: _profileAvatar(dark),
                          ),
                        ],
                      ),
                    ),
                Expanded(child: IndexedStack(index: index, children: pages)),
              ],
            ),
          ),
          bottomNavigationBar: index == 1
              ? null
              : DecoratedBox(
                  decoration: BoxDecoration(
                    color: likedinSurface(Theme.of(context).brightness),
                    border: Border(
                      top: BorderSide(color: likedinOutline(Theme.of(context).brightness)),
                    ),
                  ),
                  child: SafeArea(
                    top: false,
                    child: NavigationBar(
                      height: 68,
                      elevation: 0,
                      backgroundColor: Colors.transparent,
                      surfaceTintColor: Colors.transparent,
                      selectedIndex: index == 4 ? 1 : 0,
                      onDestinationSelected: (v) => _switchTab(v == 0 ? 0 : 4),
                      destinations: const [
                        NavigationDestination(
                          icon: Icon(Icons.home_outlined),
                          selectedIcon: Icon(Icons.home),
                          label: 'Home',
                        ),
                        NavigationDestination(
                          icon: Icon(Icons.tune_outlined),
                          selectedIcon: Icon(Icons.tune),
                          label: 'Preferences',
                        ),
                      ],
                    ),
                  ),
                ),
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({required this.displayName, super.key});
  final String displayName;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late Future<List<_HomeNews>> _news;

  @override
  void initState() {
    super.initState();
    _news = _loadNews();
  }

  static const _feeds = <String>[
    'https://news.google.com/rss?hl=en-IN&gl=IN&ceid=IN:en',
    'https://news.google.com/rss/headlines/section/topic/WORLD?hl=en-IN&gl=IN&ceid=IN:en',
    'https://news.google.com/rss/headlines/section/topic/BUSINESS?hl=en-IN&gl=IN&ceid=IN:en',
    'https://news.google.com/rss/headlines/section/topic/TECHNOLOGY?hl=en-IN&gl=IN&ceid=IN:en',
    'https://news.google.com/rss/headlines/section/topic/SPORTS?hl=en-IN&gl=IN&ceid=IN:en',
    'https://news.google.com/rss/headlines/section/topic/ENTERTAINMENT?hl=en-IN&gl=IN&ceid=IN:en',
  ];

  Future<List<_HomeNews>> _loadNews({bool forceRefresh = false}) async {
    final prefs = await SharedPreferences.getInstance();
    final cycle = DateTime.now().difference(DateTime(2026, 1, 1)).inDays;
    final cacheKey = 'likedin_home_news_cycle_$cycle';
    final staleCacheKey = 'likedin_home_news_latest';
    for (final key in prefs.getKeys().where((key) => key.startsWith('likedin_home_news_cycle_') && key != cacheKey).toList()) { await prefs.remove(key); }
    if (!forceRefresh) {
      final cached = prefs.getString(cacheKey);
      if (cached != null) {
        try {
          final decoded = (jsonDecode(cached) as List).cast<Map>();
          return decoded
              .map((item) => _HomeNews(
                    title: item['title'].toString(),
                    url: item['url'].toString(),
                    source: item['source'].toString(),
                    published: item['published'] == null
                        ? null
                        : DateTime.tryParse(item['published'].toString()),
                  ))
              .toList();
        } catch (_) {
          await prefs.remove(cacheKey);
        }
      }
    }
    final client = http.Client();
    try {
      final responses = await Future.wait(_feeds.map((feed) async {
        try {
          return await client
              .get(Uri.parse(feed), headers: {'User-Agent': 'Likedin/$likedinVersion'})
              .timeout(const Duration(seconds: 10));
        } catch (_) {
          return null;
        }
      }));
      final all = <_HomeNews>[];
      final completeFeedFetch = responses.every((response) => response != null && response.statusCode == 200);
      for (final response in responses) {
        if (response == null || response.statusCode != 200) continue;
        final items = RegExp(r'<item>([\s\S]*?)</item>', caseSensitive: false).allMatches(response.body);
        for (final match in items) {
          final block = match.group(1) ?? '';
          String tag(String name) {
            final m = RegExp('<$name(?:\\s[^>]*)?>([\\s\\S]*?)</$name>', caseSensitive: false)
                .firstMatch(block);
            return _decodeXml(m?.group(1)?.replaceAll(RegExp(r'<[^>]+>'), '').trim() ?? '');
          }

          final title = tag('title');
          final link = tag('link');
          final pub = tag('pubDate');
          final source = tag('source');
          if (title.isEmpty || link.isEmpty) continue;
          all.add(_HomeNews(
            title: title,
            url: link,
            source: source.isNotEmpty
                ? source
                : (Uri.tryParse(link)?.host.replaceFirst('www.', '') ?? 'News'),
            published: DateTime.tryParse(pub) ?? _parseNewsDate(pub),
          ));
        }
      }
      final seen = <String>{};
      final unique = all.where((n) => seen.add(n.title.toLowerCase())).toList();
      unique.sort((a, b) => (b.published ?? DateTime(2000)).compareTo(a.published ?? DateTime(2000)));
      final selected = unique.take(15).toList();
      if (selected.isEmpty && !completeFeedFetch) {
        final stale = prefs.getString(staleCacheKey);
        if (stale != null) {
          try {
            return (jsonDecode(stale) as List).cast<Map>().map((item) => _HomeNews(
              title: item['title'].toString(), url: item['url'].toString(),
              source: item['source'].toString(),
              published: item['published'] == null ? null : DateTime.tryParse(item['published'].toString()),
            )).toList();
          } catch (_) { await prefs.remove(staleCacheKey); }
        }
      }
      if (selected.isNotEmpty) {
        final encodedNews = jsonEncode(selected
              .map((n) => {
                    'title': n.title,
                    'url': n.url,
                    'source': n.source,
                    'published': n.published?.toIso8601String(),
                  })
              .toList());
        await prefs.setString(staleCacheKey, encodedNews);
        await prefs.setString(
          cacheKey,
          jsonEncode(selected
              .map((n) => {
                    'title': n.title,
                    'url': n.url,
                    'source': n.source,
                    'published': n.published?.toIso8601String(),
                  })
              .toList()),
        );
      }
      return selected;
    } finally {
      client.close();
    }
  }

  static String _decodeXml(String value) => value
      .replaceAll('&amp;', '&')
      .replaceAll('&quot;', '"')
      .replaceAll('&#39;', "'")
      .replaceAll('&apos;', "'")
      .replaceAll('&nbsp;', ' ')
      .replaceAll('&ndash;', '–')
      .replaceAll('&mdash;', '—')
      .replaceAll('&lt;', '<')
      .replaceAll('&gt;', '>')
      .replaceAllMapped(RegExp(r'&#(\d+);'), (match) {
        final code = int.tryParse(match.group(1) ?? '');
        return code == null ? match.group(0)! : String.fromCharCode(code);
      })
      .replaceAllMapped(RegExp(r'&#x([0-9a-fA-F]+);'), (match) {
        final code = int.tryParse(match.group(1) ?? '', radix: 16);
        return code == null ? match.group(0)! : String.fromCharCode(code);
      });

  static DateTime? _parseNewsDate(String value) {
    try {
      return HttpDate.parse(value);
    } catch (_) {
      return null;
    }
  }

  String get _firstName {
    final name = widget.displayName.trim();
    if (name.isEmpty) return 'there';
    return name.split(RegExp(r'\s+')).first;
  }

  String get _greeting {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  }

  String _dateLabel(DateTime date) {
    const weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return '${weekdays[date.weekday - 1]}, ${_monthShort(date.month)} ${date.day}';
  }

  String _storyDate(DateTime? date) {
    if (date == null) return 'Latest update';
    final local = date.toLocal();
    final difference = DateTime.now().difference(local);
    if (difference.inMinutes < 60 && !difference.isNegative) {
      return '${difference.inMinutes.clamp(1, 59)} min ago';
    }
    if (difference.inHours < 24 && !difference.isNegative) {
      return '${difference.inHours.clamp(1, 23)} hr ago';
    }
    return '${local.day.toString().padLeft(2, '0')} ${_monthShort(local.month)}';
  }

  String _monthShort(int month) => const [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
      ][month - 1];

  Future<void> _openStory(_HomeNews story) async {
    final uri = Uri.tryParse(story.url);
    if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('This story has an invalid or unsafe link.')),
        );
      }
      return;
    }
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not open this story.')),
        );
      }
    }
  }

  Widget _buildWelcomeCard(BuildContext context) {
    final now = DateTime.now();
    final dark = Theme.of(context).brightness == Brightness.dark;
    final secondary = dark ? const Color(0xFFA6B3CC) : const Color(0xFF55637C);

    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 14, 4, 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _dateLabel(now),
            style: TextStyle(
              color: secondary,
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            '$_greeting,\n$_firstName',
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 38,
              height: 1.06,
              fontWeight: FontWeight.w800,
              letterSpacing: -1.4,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeaturedStory(BuildContext context, _HomeNews story) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final accent = dark ? const Color(0xFF8DB8FF) : const Color(0xFF426DE0);
    return GlassPanel(
      padding: EdgeInsets.zero,
      radius: BorderRadius.circular(23),
      blur: 9,
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(23),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => _openStory(story),
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _storyDate(story.published),
                  style: TextStyle(
                    color: accent,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  story.title,
                  style: const TextStyle(
                    fontSize: 21,
                    height: 1.26,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -.45,
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        story.source,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: Theme.of(context).hintColor,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Icon(Icons.arrow_outward_rounded, color: accent, size: 18),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStoryRow(BuildContext context, _HomeNews story, int index) {
    return GlassPanel(
      padding: EdgeInsets.zero,
      radius: BorderRadius.circular(19),
      blur: 8,
      glow: false,
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(19),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          borderRadius: BorderRadius.circular(19),
          onTap: () => _openStory(story),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        story.title,
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 15,
                          height: 1.32,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        '${story.source}, ${_storyDate(story.published)}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: Theme.of(context).hintColor,
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Icon(Icons.chevron_right_rounded, color: Theme.of(context).hintColor, size: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNewsContent(BuildContext context) {
    return FutureBuilder<List<_HomeNews>>(
      future: _news,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Container(
            padding: const EdgeInsets.symmetric(vertical: 34),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: Theme.of(context).dividerColor.withValues(alpha: .75)),
            ),
            child: const Center(child: CircularProgressIndicator(strokeWidth: 2.5)),
          );
        }
        if (snapshot.hasError || !snapshot.hasData || snapshot.data!.isEmpty) {
          return Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: Theme.of(context).dividerColor.withValues(alpha: .75)),
            ),
            child: Column(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(color: brandBlue.withValues(alpha: .12), borderRadius: BorderRadius.circular(17)),
                  child: const Icon(Icons.wifi_off_rounded, color: brandBlue, size: 25),
                ),
                const SizedBox(height: 13),
                const Text('Your briefing is taking a break', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
                const SizedBox(height: 5),
                Text('Check your connection and try loading the latest stories again.',
                    textAlign: TextAlign.center, style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12, height: 1.45)),
                const SizedBox(height: 13),
                OutlinedButton.icon(
                  onPressed: () => setState(() => _news = _loadNews(forceRefresh: true)),
                  icon: const Icon(Icons.refresh_rounded, size: 17),
                  label: const Text('Try again'),
                ),
              ],
            ),
          );
        }

        final stories = snapshot.data!;
        // The briefing cache is refreshed daily; show that day's five newest
        // stories instead of keeping the visible selection on a three-day cycle.
        final todays = stories.take(5).toList();
        if (todays.isEmpty) {
          return Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: Theme.of(context).dividerColor.withValues(alpha: .75)),
            ),
            child: const Text('No stories are available in this rotation yet. Refresh to try again.'),
          );
        }

        return Column(
          children: [
            _buildFeaturedStory(context, todays.first),
            if (todays.length > 1) ...[
              const SizedBox(height: 10),
              for (var i = 1; i < todays.length; i++) ...[
                _buildStoryRow(context, todays[i], i),
                if (i != todays.length - 1) const SizedBox(height: 9),
              ],
            ],
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
        onRefresh: () async {
          final next = _loadNews(forceRefresh: true);
          setState(() => _news = next);
          await next;
        },
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
          children: [
            _buildWelcomeCard(context),
            const SizedBox(height: 28),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Today’s briefing',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: -.4),
                      ),
                    ],
                  ),
                ),
                IconButton.filledTonal(
                  tooltip: 'Refresh stories',
                  onPressed: () => setState(() => _news = _loadNews(forceRefresh: true)),
                  icon: const Icon(Icons.refresh_rounded, size: 19),
                ),
              ],
            ),
            const SizedBox(height: 13),
            _buildNewsContent(context),
          ],
        ),
    );
  }
}

class _HomeNews {
  const _HomeNews({required this.title, required this.url, required this.source, this.published});
  final String title, url, source;
  final DateTime? published;
}

class StatusRow extends StatelessWidget {
  const StatusRow({
    required this.icon,
    required this.title,
    required this.subtitle,
    super.key,
  });
  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) => GlassPanel(
        padding: const EdgeInsets.all(14),
        radius: BorderRadius.circular(20),
        blur: 5,
        glow: false,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: brandBlue),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                  const SizedBox(height: 2),
                  Text(subtitle, style: TextStyle(fontSize: 13, height: 1.35, color: Theme.of(context).hintColor)),
                ],
              ),
            ),
          ],
        ),
      );
}

class ChatPage extends StatefulWidget {
  const ChatPage({required this.isActive, required this.onBack, super.key});
  final bool isActive;
  final VoidCallback onBack;
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> with WidgetsBindingObserver {
  final controller = TextEditingController();
  final FocusNode _composerFocus = FocusNode();
  final nicknameController = TextEditingController();
  final ScrollController _chatScrollController = ScrollController();
  bool _showScrollToBottom = false;
  bool _initialChatPositioned = false;
  late final RealtimeMessagingService messaging;
  final List<RemoteMessage> messages = <RemoteMessage>[];
  String? peerId, peerName, nickname, loadError, peerAvatarPath, peerAvatarUrl;
  DateTime? _peerAvatarUrlExpiresAt;
  bool messagesLoading = true;
  bool appResumed = true;
  bool _markingRead = false;
  bool _hasOlderMessages = false;
  bool _loadingOlderMessages = false;
  DateTime? lastSeen;
  bool peerOnline = false, peerTyping = false, saving = false, uploading = false, editingNickname = false;
  final Set<String> _hiddenMessageIds = <String>{};
  final Set<String> _animatedMessageIds = <String>{};
  final Map<String, Set<String>> _messageReactions = <String, Set<String>>{};
  final Map<String, Map<String, Set<String>>> _messageReactionUsers =
      <String, Map<String, Set<String>>>{};
  final Map<String, String> _replyTargets = <String, String>{};
  final Map<String, RemoteMessage> _replySourceMessages = <String, RemoteMessage>{};
  final Map<String, GlobalKey> _messageKeys = <String, GlobalKey>{};
  bool _loadingMessages = false;
  bool _reloadMessagesQueued = false;
  int? _clearedBeforeMs;
  String? _localStateKey;
  final FlutterSecureStorage _localChatSecureStorage = const FlutterSecureStorage();
  RemoteMessage? _replyingTo;
  String? _editingMessageId;
  String? _editingOriginalText;
  Timer? heartbeat, typingTimer, peerLookupTimer, peerTypingExpiryTimer;
  Timer? _typingPublishTimer;
  RealtimeChannel? _chatIncomingCallsChannel;
  Map<String, dynamic>? _chatIncomingCall;
  bool _joiningChatCall = false;
  final AudioRecorder _voiceRecorder = AudioRecorder();
  bool _startingVoiceRecording = false;
  bool _recordingVoice = false;
  bool _voiceReleaseRequested = false;
  DateTime? _voiceRecordStarted;
  Timer? _voiceTimer;
  int _voiceRecordSeconds = 0;
  StreamSubscription<List<ConnectivityResult>>? _connectivitySubscription;
  String? _pendingTextDraftId;
  String? _pendingTextDraftValue;
  bool _clearingComposerForSend = false;
  final TextEditingController _messageSearchController = TextEditingController();
  bool _showMessageSearch = false;
  MessageMediaFilter _messageMediaFilter = MessageMediaFilter.all;
  DateTimeRange? _messageSearchDateRange;

  String get headerName =>
      (nickname?.trim().isNotEmpty == true) ? nickname!.trim() : (peerName ?? 'Your friend');

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _chatScrollController.addListener(_updateScrollButton);
    _composerFocus.addListener(() {
      if (_composerFocus.hasFocus) _scrollToLatest(animated: true);
    });
    messaging = RealtimeMessagingService(Supabase.instance.client);
    LikedinNotificationService.instance.setConversationVisible(widget.isActive);
    _connectivitySubscription = Connectivity().onConnectivityChanged.listen((results) {
      if (!mounted || !appResumed || !results.any((result) => result != ConnectivityResult.none)) return;
      _processQueuedMediaInBackground();
    });
    _initialise();
  }

  void _processQueuedMediaInBackground() {
    unawaited(
      SharedMediaService.processRetryQueue(Supabase.instance.client)
          .then<void>((completed) async {
        if (completed && mounted && peerId != null) {
          try {
            await _loadMessages();
          } catch (error) {
            debugPrint('Sent media refresh is deferred: $error');
          }
        }
      }).catchError((Object error) {
        debugPrint('Queued media retry failed: $error');
      }),
    );
  }

  void _startHeartbeat() {
    heartbeat?.cancel();
    heartbeat = Timer.periodic(const Duration(seconds: 30), (_) async {
      if (!appResumed) return;
      try {
        await messaging.setOnline(true);
      } catch (_) {}
    });
  }

  Future<void> _initialise() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      String? peer;
      try { peer = await messaging.getPeerId(); } catch (error) { debugPrint('Initial peer lookup failed: $error'); }
      if (!mounted) return;
      peerId = peer;
      if (peer != null) {
        _processQueuedMediaInBackground();
      }
      nickname = peer == null ? null : prefs.getString('likedIn_nickname_$peer');
      if (peer != null) await _loadLocalChatState(peer);
      try { await _refreshPeer(); } catch (_) {}
      try { await messaging.setOnline(true); } catch (_) {}
      _startHeartbeat();
      _startPeerLookupRetry();
      if (peer != null) {
        try { await _watchChatIncomingCalls(); } catch (_) {}
        messaging.subscribe(
          peerId: peer,
          onMessages: () => _handleIncomingMessages(),
          onProfile: _refreshPeer,
          onMessageUpdate: _handleRealtimeMessageUpdate,
          onTyping: (value) {
            peerTypingExpiryTimer?.cancel();
            if (mounted) setState(() => peerTyping = value);
            if (value) {
              peerTypingExpiryTimer = Timer(const Duration(seconds: 5), () {
                if (mounted) setState(() => peerTyping = false);
              });
            }
          },
        ); // Subscribe before initial load to avoid missing intervening messages.
        await _loadMessages();
        // Reconcile every historical media tombstone, not just those in the
        // currently loaded pages. This clears local files after an app was
        // killed or offline when a delete-for-everyone event arrived.
        try {
          final deletedMedia = await messaging.loadDeletedMediaMessages();
          await _purgeDeletedMediaCaches(deletedMedia);
        } catch (error) {
          debugPrint('Deleted-media cache reconciliation deferred: $error');
        }
        if (appResumed) {
          try { await messaging.markDelivered(); } catch (_) {}
          if (widget.isActive) {
            try { await _markVisibleMessagesRead(); } catch (_) {}
          }
        }
      } else if (mounted) {
        setState(() => messagesLoading = false);
      }
      if (mounted) {
        setState(() {
          loadError = null;
        });
      }
    } catch (e) {
      if (mounted) setState(() => loadError = e.toString());
    }
  }

  void _setChatIncomingCall(Map<String, dynamic>? row) {
    final hadCall = _chatIncomingCall != null;
    final hasCall = row != null;
    if (mounted) {
      setState(() => _chatIncomingCall = row);
    }
    if (hasCall && widget.isActive && appResumed && !_joiningChatCall) {
      CallAlertController.startIncoming();
    } else if (hadCall && !hasCall && !_joiningChatCall) {
      CallAlertController.stop();
    }
  }

  Future<void> _watchChatIncomingCalls() async {
    final client = Supabase.instance.client;
    final uid = messaging.currentUserId;
    final existing = _chatIncomingCallsChannel;
    if (existing != null) await client.removeChannel(existing);
    _chatIncomingCallsChannel = client
        .channel('likedin-chat-calls-$uid')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'likedin_calls',
          filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'callee_id', value: uid),
          callback: (payload) {
            final row = Map<String, dynamic>.from(payload.newRecord);
            if (row['status'] == 'ringing' && mounted) {
              _setChatIncomingCall(row);
            }
          },
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'likedin_calls',
          filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'callee_id', value: uid),
          callback: (payload) {
            final row = payload.newRecord;
            if (row['status'] != 'ringing' &&
                mounted &&
                _chatIncomingCall?['id']?.toString() == row['id']?.toString()) {
              _setChatIncomingCall(null);
            }
          },
        )
      ..subscribe();
    try {
      final rows = await client
          .from('likedin_calls')
          .select()
          .eq('callee_id', uid)
          .eq('status', 'ringing')
          .order('created_at', ascending: false)
          .limit(1);
      if (mounted) {
        _setChatIncomingCall(rows.isEmpty ? null : Map<String, dynamic>.from(rows.first));
      }
    } catch (e) {
      debugPrint('Chat incoming-call recovery failed: $e');
    }
  }

  Future<void> _declineChatIncomingCall() async {
    final row = _chatIncomingCall;
    if (row == null || _joiningChatCall) return;
    final id = row['id']?.toString();
    if (id == null) return;

    // Commit the authoritative call state first. Signaling is best-effort and
    // must never prevent the caller from learning that the call was rejected.
    try {
      await Supabase.instance.client.rpc('likedin_update_call_status', params: {
        'p_call_id': id,
        'p_new_status': 'rejected',
      });
    } catch (e) {
      debugPrint('Could not commit incoming call rejection: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not decline the call. Please try again.')),
        );
      }
      return;
    }

    try {
      await LikedinNotificationService.instance.cancelIncomingCall(id);
    } catch (e) {
      debugPrint('Decline committed, but local incoming-call notification could not be cancelled: $e');
    }
    _setChatIncomingCall(null);
    try {
      await Supabase.instance.client.from('likedin_call_signals').insert({
        'call_id': id,
        'sender_id': messaging.currentUserId,
        'kind': 'reject',
        'payload': <String, dynamic>{},
      });
    } catch (e) {
      debugPrint('Call was rejected in the database; reject signal could not be sent: $e');
    }
  }

  Future<void> _joinChatIncomingCall() async {
    final row = _chatIncomingCall;
    if (row == null || _joiningChatCall || _globalCallDialogActive) return;
    setState(() => _joiningChatCall = true);
    _globalCallDialogActive = true;
    await CallAlertController.stop();
    try {
      final client = Supabase.instance.client;
      final id = row['id'].toString();
      await LikedinNotificationService.instance.cancelIncomingCall(id);
      Map<String, dynamic>? offer;
      for (var attempt = 0; attempt < 90 && offer == null; attempt++) {
        final latest = await client.from('likedin_calls').select('status').eq('id', id).maybeSingle();
        if (latest == null || latest['status'] != 'ringing') break;
        final signals = await client
            .from('likedin_call_signals')
            .select('payload')
            .eq('call_id', id)
            .eq('kind', 'offer')
            .order('created_at', ascending: false)
            .limit(1);
        if (signals.isNotEmpty) offer = Map<String, dynamic>.from(signals.first['payload'] as Map);
        if (offer == null) await Future<void>.delayed(const Duration(milliseconds: 500));
      }
      if (offer == null) {
        throw StateError('The caller is no longer ringing. Ask them to call again.');
      }
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (_) => _IncomingCallDialog(
          callId: id,
          callerId: row['caller_id'].toString(),
          offer: offer!,
          withVideo: row['call_type']?.toString().toLowerCase() == 'video',
          autoAccept: true,
        ),
      );
      if (mounted) _setChatIncomingCall(null);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not join call: $e')));
      }
    } finally {
      _globalCallDialogActive = false;
      if (mounted) setState(() => _joiningChatCall = false);
    }
  }

  Future<void> _loadLocalChatState(String peer) async {
    final user = messaging.currentUserId;
    _localStateKey = 'likedin_local_chat_v1_${user}_$peer';
    String? raw;
    try { raw = await _localChatSecureStorage.read(key: _localStateKey!); } catch (error) { debugPrint('Local chat state unavailable (secure storage key may have changed): $error'); return; }
    if (raw == null || raw.isEmpty) return;
    try {
      final data = Map<String, dynamic>.from(jsonDecode(raw) as Map);
      _hiddenMessageIds
        ..clear()
        ..addAll((data['hidden'] as List? ?? const []).map((e) => e.toString()));
      _clearedBeforeMs = data['clearedBeforeMs'] as int?;
    } catch (_) {}
  }

  Future<void> _saveLocalChatState() async {
    final key = _localStateKey;
    if (key == null) return;
    try {
      await _localChatSecureStorage.write(key: key, value: jsonEncode({'hidden': _hiddenMessageIds.toList(), 'clearedBeforeMs': _clearedBeforeMs}));
    } catch (error) { debugPrint('Could not persist local chat state: $error'); }
  }

  void _startPeerLookupRetry() {
    peerLookupTimer?.cancel();
    peerLookupTimer = Timer.periodic(const Duration(seconds: 15), (_) async {
      if (!mounted || !appResumed) return;
      if (peerId == null) {
        try {
          final found = await messaging.getPeerId();
          if (found != null && mounted) {
            setState(() => peerId = found);
            await _loadLocalChatState(found);
            messaging.subscribe(peerId: found, onMessages: _handleIncomingMessages,
              onProfile: _refreshPeer, onMessageUpdate: _handleRealtimeMessageUpdate, onTyping: (value) {
                peerTypingExpiryTimer?.cancel();
                if (mounted) setState(() => peerTyping = value);
                if (value) {
                  peerTypingExpiryTimer = Timer(const Duration(seconds: 5), () {
                    if (mounted) setState(() => peerTyping = false);
                  });
                }
              });
            await _refreshPeer();
            await _loadMessages();
            try {
              final deletedMedia = await messaging.loadDeletedMediaMessages();
              await _purgeDeletedMediaCaches(deletedMedia);
            } catch (error) {
              debugPrint('Deleted-media cache reconciliation after peer registration deferred: $error');
            }
            await _watchChatIncomingCalls();
          }
        } catch (error) { debugPrint('Peer lookup retry failed: $error'); }
      } else {
        await _refreshPeer();
      }
    });
  }

  Future<void> _refreshPeer() async {
    try {
      final profile = await messaging.getPeerProfile();
      if (!mounted) return;
      if (profile == null) {
        setState(() {
          peerOnline = false;
          peerAvatarPath = null;
          peerAvatarUrl = null;
          _peerAvatarUrlExpiresAt = null;
        });
        return;
      }

      var nextAvatarUrl = peerAvatarUrl;
      var nextExpiry = _peerAvatarUrlExpiresAt;
      final avatarPathChanged = profile.avatarPath != peerAvatarPath;
      final shouldRefreshUrl = profile.avatarPath != null &&
          (avatarPathChanged ||
              nextAvatarUrl == null ||
              nextExpiry == null ||
              nextExpiry.isBefore(DateTime.now().add(const Duration(minutes: 30))));
      if (profile.avatarPath == null) {
        nextAvatarUrl = null;
        nextExpiry = null;
      } else if (shouldRefreshUrl) {
        try {
          nextAvatarUrl = await messaging.profileAvatarSignedUrl(profile.avatarPath!);
          nextExpiry = DateTime.now().add(const Duration(hours: 24));
        } catch (error) {
          debugPrint('Peer profile photo could not be resolved yet: $error');
          if (avatarPathChanged) nextAvatarUrl = null;
        }
      }
      if (!mounted) return;
      setState(() {
        peerName = profile.name;
        peerOnline = profile.online;
        lastSeen = profile.lastSeen;
        peerAvatarPath = profile.avatarPath;
        peerAvatarUrl = nextAvatarUrl;
        _peerAvatarUrlExpiresAt = nextExpiry;
      });
    } catch (_) {
      if (mounted) setState(() => peerOnline = false);
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    appResumed = state == AppLifecycleState.resumed;
    LikedinNotificationService.instance.setConversationVisible(widget.isActive && appResumed);
    if (appResumed) {
      messaging.setOnline(true).catchError((_) {});
      _processQueuedMediaInBackground();
      _startHeartbeat();
      if (peerId != null) {
        unawaited(_refreshPeer());
        unawaited(_watchChatIncomingCalls());
      }
      if (peerId != null) {
        unawaited(messaging.loadDeletedMediaMessages().then((items) => _purgeDeletedMediaCaches(items)).catchError((Object error) {
          debugPrint('Deleted-media cache reconciliation on resume deferred: $error');
        }));
      }
      if (widget.isActive) {
        _loadMessages().then((_) => _markVisibleMessagesRead()).catchError((_) {});
      }
    } else if (state == AppLifecycleState.paused || state == AppLifecycleState.detached) {
      heartbeat?.cancel();
      CallAlertController.stop();
      messaging.setOnline(false).catchError((_) {});
    }
  }

  @override
  void didUpdateWidget(covariant ChatPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    LikedinNotificationService.instance.setConversationVisible(widget.isActive && appResumed);
    if (widget.isActive && !oldWidget.isActive && appResumed) {
      if (peerId != null) unawaited(_watchChatIncomingCalls());
      _loadMessages().then((_) => _markVisibleMessagesRead()).catchError((_) {});
    } else if (!widget.isActive && oldWidget.isActive) {
      CallAlertController.stop();
    }
  }

  bool get _isNearBottom {
    if (!_chatScrollController.hasClients) return true;
    return _chatScrollController.position.maxScrollExtent - _chatScrollController.position.pixels <= 100;
  }

  void _updateScrollButton() {
    if (!mounted || !_chatScrollController.hasClients) return;
    final shouldShow = !_isNearBottom;
    if (shouldShow != _showScrollToBottom) setState(() => _showScrollToBottom = shouldShow);
    final position = _chatScrollController.position;
    if (_initialChatPositioned &&
        !_loadingMessages &&
        !_loadingOlderMessages &&
        _hasOlderMessages &&
        position.pixels <= 120) {
      unawaited(_loadOlderMessages());
    }
  }

  @override
  void didChangeMetrics() {
    super.didChangeMetrics();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final bottomInset = View.of(context).viewInsets.bottom;
      if (bottomInset > 0 && _isNearBottom) {
        _scrollToLatest(animated: false);
      }
    });
  }

  void _scrollToLatest({bool animated = true}) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || !_chatScrollController.hasClients) return;
      final target = _chatScrollController.position.maxScrollExtent;
      if (animated) {
        _chatScrollController.animateTo(
          target,
          duration: const Duration(milliseconds: 260),
          curve: Curves.easeOut,
        );
      } else {
        _chatScrollController.jumpTo(target);
      }
      if (_showScrollToBottom) setState(() => _showScrollToBottom = false);
    });
  }

  String _summarizeMessage(RemoteMessage message) {
    if (message.deletedForEveryoneAt != null) return 'This message was deleted';
    final mediaService = SharedMediaService(Supabase.instance.client);
    final decoded = mediaService.decode(message.text);
    if (decoded != null) {
      return mediaService.describePayload(decoded);
    }
    return message.text;
  }

  /// Returns the committed database ID for a reply target. Optimistic message
  /// objects temporarily use clientMessageId as their local ID; that value is
  /// not the messages.id foreign key stored in reply_to_message_id.
  Future<String?> _resolveReplyTargetId(RemoteMessage? target) async {
    if (target == null) return null;
    final clientId = target.clientMessageId;
    if (clientId == null || target.id != clientId) return target.id;

    final committed = await Supabase.instance.client
        .from('messages')
        .select('id')
        .eq('sender_id', target.senderId)
        .eq('client_message_id', clientId)
        .maybeSingle();
    final resolved = committed?['id']?.toString();
    if (resolved == null || resolved.isEmpty) {
      throw StateError('Wait until that message finishes sending before replying to it.');
    }
    return resolved;
  }

  /// Merges database rows and optimistic local rows using the stable client
  /// id. A successfully persisted message replaces its local placeholder,
  /// even when its Postgres primary key differs. This prevents a stale grey
  /// optimistic bubble from surviving beside the delivered copy.
  List<RemoteMessage> _mergeMessagesByClientId(Iterable<RemoteMessage> source) {
    final canonical = <String, RemoteMessage>{};
    int quality(RemoteMessage message) {
      var score = message.clientMessageId != null && message.id != message.clientMessageId ? 8 : 0;
      if (message.deliveredAt != null) score += 2;
      if (message.readAt != null) score += 4;
      if (message.editedAt != null) score += 1;
      if (message.deletedForEveryoneAt != null) score += 1;
      return score;
    }

    for (final message in source) {
      final clientId = message.clientMessageId;
      final key = clientId != null && clientId.isNotEmpty
          ? 'client:$clientId'
          : 'row:${message.id}';
      final existing = canonical[key];
      if (existing == null || quality(message) > quality(existing)) {
        canonical[key] = message;
      }
    }
    final merged = canonical.values.toList()
      ..sort((a, b) {
        final byTime = a.createdAt.compareTo(b.createdAt);
        return byTime != 0 ? byTime : a.id.compareTo(b.id);
      });
    return merged;
  }

  Future<void> _purgeDeletedMediaCaches(Iterable<RemoteMessage> items) async {
    final media = SharedMediaService(Supabase.instance.client);
    final ownedPaths = <String>[];
    for (final item in items) {
      final path = item.deletedMediaPath;
      if (item.deletedForEveryoneAt == null || path == null || path.isEmpty) continue;
      try { await media.deleteCachedPath(path); } catch (error) {
        debugPrint('Could not remove cached deleted attachment: $error');
      }
      // Only the sender owns the Storage object. The receiver clears its
      // local cached copy; the sender retries remote deletion on later loads.
      if (item.senderId == messaging.currentUserId) ownedPaths.add(path);
    }
    if (ownedPaths.isNotEmpty) {
      try { await media.deleteRemotePaths(ownedPaths); } catch (error) {
        debugPrint('Remote deleted attachment cleanup will be retried: $error');
      }
    }
  }

  Future<void> _loadMessages() async {
    if (_loadingMessages) {
      _reloadMessagesQueued = true;
      return;
    }
    _loadingMessages = true;
    final hadInitialPosition = _initialChatPositioned;
    final wasAtBottom = !hadInitialPosition || _isNearBottom;
    try {
      final loaded = await messaging.loadConversation(limit: RealtimeMessagingService.conversationPageSize);
      await _purgeDeletedMediaCaches(loaded);
      Map<String, Map<String, Set<String>>> detailedReactions =
          <String, Map<String, Set<String>>>{};
      Map<String, Set<String>> remoteReactions = <String, Set<String>>{};
      var reactionsRefreshed = false;
      try {
        detailedReactions = await messaging.loadDetailedReactions(
          loaded.map((message) => message.id).toList(),
        );
        remoteReactions = <String, Set<String>>{
          for (final entry in detailedReactions.entries)
            entry.key: entry.value.keys.toSet(),
        };
        reactionsRefreshed = true;
      } catch (error) {
        // Reaction availability must never determine whether the chat itself
        // can be displayed. Keep cached reactions and render the messages.
        debugPrint('Reaction refresh failed; displaying messages without new reactions: $error');
      }
      if (!mounted) return;
      final mergedMessages = _mergeMessagesByClientId([...messages, ...loaded]);
      final originalsById = <String, RemoteMessage>{
        for (final item in mergedMessages) item.id: item,
      };
      final replySourceById = Map<String, RemoteMessage>.from(originalsById);
      final missingReplyIds = mergedMessages
          .map((item) => item.replyToMessageId)
          .whereType<String>()
          .where((id) => !replySourceById.containsKey(id))
          .toSet();
      if (missingReplyIds.isNotEmpty) {
        try {
          final references = await messaging.loadMessagesByIds(missingReplyIds);
          replySourceById.addAll({for (final item in references) item.id: item});
        } catch (error) {
          debugPrint('Some reply previews will be generic until their originals load: $error');
        }
      }
      if (messages.isEmpty) {
        _hasOlderMessages = loaded.length >= RealtimeMessagingService.conversationPageSize;
      }
      _messageKeys.removeWhere((id, _) => !originalsById.containsKey(id));
      setState(() {
        messages
          ..clear()
          ..addAll(mergedMessages);
        // Refresh reactions for the page just fetched (including removals),
        // while retaining reactions already loaded for older pages.
        if (reactionsRefreshed) {
          for (final item in loaded) {
            _messageReactions.remove(item.id);
            _messageReactionUsers.remove(item.id);
          }
          _messageReactions.addAll(remoteReactions);
          _messageReactionUsers.addAll(detailedReactions);
        }
        _messageReactions.removeWhere((id, _) => !originalsById.containsKey(id));
        _messageReactionUsers.removeWhere((id, _) => !originalsById.containsKey(id));
        _replyTargets
          ..clear()
          ..addEntries(mergedMessages.where((m) => m.replyToMessageId != null).map((m) {
            final original = replySourceById[m.replyToMessageId];
            return MapEntry(
              m.id,
              original == null ? 'Replying to a message' : _summarizeMessage(original),
            );
          }));
        _replySourceMessages
          ..clear()
          ..addEntries(
            mergedMessages
                .where((m) => m.replyToMessageId != null &&
                    replySourceById.containsKey(m.replyToMessageId))
                .map((m) => MapEntry(m.id, replySourceById[m.replyToMessageId]!)),
          );
        messagesLoading = false;
        loadError = null;
      });
      if (wasAtBottom) {
        _initialChatPositioned = true;
        _scrollToLatest(animated: hadInitialPosition);
      } else {
        WidgetsBinding.instance.addPostFrameCallback((_) => _updateScrollButton());
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          messagesLoading = false;
          loadError = e.toString();
        });
      }
      rethrow;
    } finally {
      _loadingMessages = false;
      if (_reloadMessagesQueued && mounted) {
        _reloadMessagesQueued = false;
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) _loadMessages().catchError((_) {});
        });
      }
    }
  }

  Future<void> _loadOlderMessages() async {
    if (!mounted || _loadingOlderMessages || !_hasOlderMessages || messages.isEmpty) return;
    final oldest = messages.first;
    final oldPixels = _chatScrollController.hasClients ? _chatScrollController.position.pixels : 0.0;
    final oldMaxExtent = _chatScrollController.hasClients
        ? _chatScrollController.position.maxScrollExtent
        : 0.0;
    setState(() => _loadingOlderMessages = true);
    try {
      final older = await messaging.loadConversation(
        beforeCreatedAt: oldest.createdAt,
        beforeId: oldest.id,
        limit: RealtimeMessagingService.conversationPageSize,
      );
      await _purgeDeletedMediaCaches(older);
      if (!mounted) return;

      final existingIds = messages.map((message) => message.id).toSet();
      final additions = older.where((message) => !existingIds.contains(message.id)).toList();
      Map<String, Map<String, Set<String>>> olderDetailedReactions =
          <String, Map<String, Set<String>>>{};
      Map<String, Set<String>> olderReactions = <String, Set<String>>{};
      try {
        olderDetailedReactions = await messaging.loadDetailedReactions(
          additions.map((message) => message.id).toList(),
        );
        olderReactions = <String, Set<String>>{
          for (final entry in olderDetailedReactions.entries)
            entry.key: entry.value.keys.toSet(),
        };
      } catch (error) {
        debugPrint('Older-message reactions could not be loaded: $error');
      }

      final mergedMessages = _mergeMessagesByClientId([...additions, ...messages]);
      final originalsById = <String, RemoteMessage>{for (final item in mergedMessages) item.id: item};
      final replySourceById = Map<String, RemoteMessage>.from(originalsById);
      final missingReplyIds = mergedMessages
          .map((item) => item.replyToMessageId)
          .whereType<String>()
          .where((id) => !replySourceById.containsKey(id))
          .toSet();
      if (missingReplyIds.isNotEmpty) {
        try {
          final references = await messaging.loadMessagesByIds(missingReplyIds);
          replySourceById.addAll({for (final item in references) item.id: item});
        } catch (error) {
          debugPrint('Older-page reply previews remain partial: $error');
        }
      }
      setState(() {
        messages
          ..clear()
          ..addAll(mergedMessages);
        _messageReactions.addAll(olderReactions);
        _messageReactionUsers.addAll(olderDetailedReactions);
        _replyTargets
          ..clear()
          ..addEntries(mergedMessages.where((m) => m.replyToMessageId != null).map((m) {
            final original = replySourceById[m.replyToMessageId];
            return MapEntry(
              m.id,
              original == null ? 'Replying to a message' : _summarizeMessage(original),
            );
          }));
        _replySourceMessages
          ..clear()
          ..addEntries(
            mergedMessages
                .where((m) => m.replyToMessageId != null &&
                    replySourceById.containsKey(m.replyToMessageId))
                .map((m) => MapEntry(m.id, replySourceById[m.replyToMessageId]!)),
          );
        _hasOlderMessages = older.length >= RealtimeMessagingService.conversationPageSize;
        _loadingOlderMessages = false;
      });
      if (_messageKeys.keys.any((id) => !originalsById.containsKey(id))) {
        _messageKeys.removeWhere((id, _) => !originalsById.containsKey(id));
      }

      // Prepending older rows changes the scroll extent. Move the viewport by
      // that same amount so the message the user was reading stays in place.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted || !_chatScrollController.hasClients) return;
        final newMaxExtent = _chatScrollController.position.maxScrollExtent;
        final addedExtent = (newMaxExtent - oldMaxExtent).clamp(0.0, double.infinity).toDouble();
        final target = (oldPixels + addedExtent).clamp(
          _chatScrollController.position.minScrollExtent,
          newMaxExtent,
        ).toDouble();
        _chatScrollController.jumpTo(target);
      });
    } catch (error) {
      debugPrint('Older conversation page could not be loaded: $error');
      if (mounted) setState(() => _loadingOlderMessages = false);
    }
  }

  void _jumpToMessage(String messageId) {
    final key = _messageKeys[messageId];
    final targetContext = key?.currentContext;
    if (targetContext == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('That original message is not in the loaded conversation.')),
      );
      return;
    }
    Scrollable.ensureVisible(
      targetContext,
      duration: const Duration(milliseconds: 380),
      curve: Curves.easeInOut,
      alignment: 0.25,
    );
  }

  void _handleRealtimeMessageUpdate(Map<String, dynamic> row) {
    try {
      final updated = RemoteMessage.fromMap(row);
      var index = messages.indexWhere((message) => message.id == updated.id);
      // A receipt update can arrive while this device still has the optimistic
      // client ID. Match that stable ID and promote the row instead of leaving
      // a grey placeholder next to the persisted server row.
      if (index < 0 && updated.clientMessageId != null) {
        index = messages.indexWhere((message) =>
            message.id == updated.clientMessageId ||
            message.clientMessageId == updated.clientMessageId);
      }
      if (index < 0 || !mounted) return;
      final previousId = messages[index].id;
      setState(() {
        messages[index] = updated;
        if (previousId != updated.id) {
          final quote = _replyTargets.remove(previousId);
          if (quote != null) _replyTargets[updated.id] = quote;
          final quoteSource = _replySourceMessages.remove(previousId);
          if (quoteSource != null) _replySourceMessages[updated.id] = quoteSource;
        }
      });
      if (previousId != updated.id) {
        final messageKey = _messageKeys.remove(previousId);
        if (messageKey != null) _messageKeys[updated.id] = messageKey;
      }
      if (updated.deletedForEveryoneAt != null && updated.deletedMediaPath != null) {
        unawaited(_purgeDeletedMediaCaches([updated]));
      }
    } catch (error) {
      debugPrint('Could not apply realtime message update: $error');
    }
  }

  Future<void> _handleIncomingMessages() async {
    try {
      await _loadMessages();
      if (!appResumed) return;
      await messaging.markDelivered();
      if (widget.isActive) await _markVisibleMessagesRead();
    } catch (_) {}
  }

  Future<void> _markVisibleMessagesRead() async {
    if (!mounted || !widget.isActive || !appResumed || _markingRead) return;
    final hasUnread = messages.any((m) => m.recipientId == messaging.currentUserId && m.readAt == null);
    if (!hasUnread) return;
    _markingRead = true;
    try {
      await messaging.markRead();
      await _loadMessages();
    } catch (_) {
    } finally {
      _markingRead = false;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    LikedinNotificationService.instance.setConversationVisible(false);
    heartbeat?.cancel();
    typingTimer?.cancel();
    _typingPublishTimer?.cancel();
    peerLookupTimer?.cancel();
    peerTypingExpiryTimer?.cancel();
    _connectivitySubscription?.cancel();
    _voiceTimer?.cancel();
    CallAlertController.stop();
    final incomingChannel = _chatIncomingCallsChannel;
    if (incomingChannel != null) Supabase.instance.client.removeChannel(incomingChannel);
    messaging.setOnline(false).catchError((_) {});
    messaging.unsubscribe();
    controller.dispose();
    _messageSearchController.dispose();
    _composerFocus.dispose();
    nicknameController.dispose();
    _voiceRecorder.dispose();
    _chatScrollController.removeListener(_updateScrollButton);
    _chatScrollController.dispose();
    super.dispose();
  }

  Future<void> send() async {
    final text = controller.text.trim();
    // A tap on the send icon can momentarily shift focus before this handler.
    // Non-empty composer text is enough evidence that the user expects it back.
    final keepKeyboardOpen = _composerFocus.hasFocus || text.isNotEmpty;
    final recipient = peerId;
    if (text.isEmpty || saving) return;
    if (_editingMessageId != null) {
      final id = _editingMessageId!;
      setState(() => saving = true);
      try {
        await messaging.editMessage(id, text);
        if (!mounted) return;
        setState(() {
          _editingMessageId = null;
          _editingOriginalText = null;
        });
        controller.clear();
        if (keepKeyboardOpen) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (!mounted) return;
            _composerFocus.requestFocus();
            SystemChannels.textInput.invokeMethod<void>('TextInput.show');
          });
        }
        unawaited(messaging.sendTyping(false).catchError((_) {}));
        await _loadMessages();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Message edited for both phones.')),
          );
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Could not edit message: $e')),
          );
        }
      } finally {
        if (mounted) setState(() => saving = false);
      }
      return;
    }
    if (recipient == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Your friend must register before you can message.')),
      );
      return;
    }
    final clientMessageId = (_pendingTextDraftValue == text && _pendingTextDraftId != null)
        ? _pendingTextDraftId!
        : const Uuid().v4();
    final replyTarget = _replyingTo;
    String? replyId;
    try {
      replyId = await _resolveReplyTargetId(replyTarget);
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(error.toString().replaceFirst('Bad state: ', ''))),
        );
      }
      return;
    }
    if (!mounted) return;
    _pendingTextDraftId = clientMessageId;
    _pendingTextDraftValue = text;
    final replyText = replyTarget == null ? null : _summarizeMessage(replyTarget);
    final optimistic = RemoteMessage(
      id: clientMessageId,
      clientMessageId: clientMessageId,
      senderId: messaging.currentUserId,
      recipientId: recipient,
      text: text,
      createdAt: DateTime.now(),
      replyToMessageId: replyId,
    );
    setState(() {
      saving = true;
      messages.add(optimistic);
      if (replyText != null) _replyTargets[clientMessageId] = replyText;
      if (replyTarget != null) _replySourceMessages[clientMessageId] = replyTarget;
      _replyingTo = null;
    });
    _scrollToLatest();
    // Clearing the controller is not a user edit. Preserve the idempotency key
    // so a retry after a lost response reconciles the same server row instead
    // of creating a second message with a new client ID.
    _clearingComposerForSend = true;
    try {
      controller.clear();
    } finally {
      _clearingComposerForSend = false;
    }
    if (keepKeyboardOpen) _restoreComposerKeyboard();
    String? sentId;
    try {
      sentId = await messaging.sendMessage(
        recipient,
        text,
        clientMessageId: clientMessageId,
        replyToMessageId: replyId,
      );
    } catch (e) {
      if (mounted) {
        setState(() {
          messages.removeWhere((m) => m.id == clientMessageId);
          _replyTargets.remove(clientMessageId);
          _replySourceMessages.remove(clientMessageId);
          _messageReactions.remove(clientMessageId);
        });
        controller.text = text;
        if (keepKeyboardOpen) _restoreComposerKeyboard();
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Message not sent: $e')));
      }
      if (mounted) setState(() => saving = false);
      return;
    }

    final persistedId = sentId;
    if (persistedId != null) {
      if (_pendingTextDraftId == clientMessageId) {
        _pendingTextDraftId = null;
        _pendingTextDraftValue = null;
      }
      if (mounted && persistedId != clientMessageId) {
        setState(() {
          final optimisticIndex = messages.indexWhere((item) => item.id == clientMessageId);
          if (optimisticIndex >= 0) {
            final optimisticMessage = messages[optimisticIndex];
            messages[optimisticIndex] = RemoteMessage(
              id: persistedId,
              clientMessageId: clientMessageId,
              senderId: optimisticMessage.senderId,
              recipientId: optimisticMessage.recipientId,
              text: optimisticMessage.text,
              createdAt: optimisticMessage.createdAt,
              replyToMessageId: optimisticMessage.replyToMessageId,
            );
          }
          final quote = _replyTargets.remove(clientMessageId);
          if (quote != null) _replyTargets[persistedId] = quote;
          final quoteSource = _replySourceMessages.remove(clientMessageId);
          if (quoteSource != null) _replySourceMessages[persistedId] = quoteSource;
        });
        final optimisticKey = _messageKeys.remove(clientMessageId);
        if (optimisticKey != null) _messageKeys[persistedId] = optimisticKey;
      }
    }
    if (replyText != null && sentId != null) _replyTargets[sentId] = replyText;
    try {
      await messaging.sendTyping(false);
    } catch (_) {}
    try {
      await _loadMessages();
    } catch (_) {}
    if (mounted) {
      setState(() => saving = false);
      if (keepKeyboardOpen) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (!mounted) return;
          _composerFocus.requestFocus();
          SystemChannels.textInput.invokeMethod<void>('TextInput.show');
        });
      }
    }
  }

  List<RemoteMessage> get _visibleMessages => messages
      .where((m) =>
          !_hiddenMessageIds.contains(m.id) &&
          (_clearedBeforeMs == null || m.createdAt.millisecondsSinceEpoch > _clearedBeforeMs!))
      .toList();

  MessageSearchFilter get _activeMessageSearchFilter => MessageSearchFilter(
        query: _messageSearchController.text,
        media: _messageMediaFilter,
        fromDate: _messageSearchDateRange?.start,
        toDate: _messageSearchDateRange?.end,
      );

  bool get _hasActiveMessageSearch => _activeMessageSearchFilter.isActive;

  List<RemoteMessage> get _chatDisplayMessages =>
      _visibleMessages.where(_activeMessageSearchFilter.matches).toList();

  Future<void> _chooseMessageSearchDates() async {
    final now = DateTime.now();
    final selected = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2000),
      lastDate: DateTime(now.year, now.month, now.day),
      initialDateRange: _messageSearchDateRange,
      helpText: 'Filter messages by date',
      saveText: 'APPLY',
    );
    if (!mounted || selected == null) return;
    setState(() => _messageSearchDateRange = selected);
  }

  void _clearMessageSearch() {
    setState(() {
      _messageSearchController.clear();
      _messageMediaFilter = MessageMediaFilter.all;
      _messageSearchDateRange = null;
      _showMessageSearch = false;
    });
  }

  Widget _buildMessageSearchPanel(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final resultCount = _chatDisplayMessages.length;
    final loadedCount = _visibleMessages.length;
    final dateRange = _messageSearchDateRange;
    final dateLabel = dateRange == null
        ? 'Any date'
        : '${dateRange.start.day}/${dateRange.start.month}/${dateRange.start.year}'
            ' – ${dateRange.end.day}/${dateRange.end.month}/${dateRange.end.year}';

    Widget filterChip(String label, MessageMediaFilter value) => ChoiceChip(
          label: Text(label),
          selected: _messageMediaFilter == value,
          onSelected: (_) => setState(() => _messageMediaFilter = value),
          visualDensity: VisualDensity.compact,
          labelStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
          padding: const EdgeInsets.symmetric(horizontal: 4),
        );

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 7, 12, 6),
      child: GlassPanel(
        blur: 13,
        radius: BorderRadius.circular(20),
        tint: Theme.of(context).brightness == Brightness.dark
            ? const Color(0xD9142942)
            : const Color(0xEAFBFDFF),
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 9),
        glow: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Icon(Icons.search_rounded, color: colors.primary, size: 19),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _messageSearchController,
                    autofocus: true,
                    textInputAction: TextInputAction.search,
                    onChanged: (_) => setState(() {}),
                    decoration: InputDecoration(
                      hintText: 'Search messages or attachment names',
                      isDense: true,
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(vertical: 9),
                      hintStyle: TextStyle(color: colors.onSurface.withValues(alpha: .55)),
                    ),
                  ),
                ),
                if (_messageSearchController.text.isNotEmpty)
                  IconButton(
                    tooltip: 'Clear search text',
                    visualDensity: VisualDensity.compact,
                    onPressed: () {
                      _messageSearchController.clear();
                      setState(() {});
                    },
                    icon: const Icon(Icons.close_rounded, size: 18),
                  ),
              ],
            ),
            const Divider(height: 9),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  filterChip('All', MessageMediaFilter.all),
                  const SizedBox(width: 6),
                  filterChip('Photos', MessageMediaFilter.photos),
                  const SizedBox(width: 6),
                  filterChip('Videos', MessageMediaFilter.videos),
                  const SizedBox(width: 6),
                  filterChip('Audio', MessageMediaFilter.audio),
                  const SizedBox(width: 6),
                  filterChip('Files', MessageMediaFilter.files),
                ],
              ),
            ),
            const SizedBox(height: 5),
            Row(
              children: [
                Expanded(
                  child: TextButton.icon(
                    onPressed: _chooseMessageSearchDates,
                    icon: const Icon(Icons.calendar_month_rounded, size: 17),
                    label: Text(dateLabel, maxLines: 1, overflow: TextOverflow.ellipsis),
                    style: TextButton.styleFrom(
                      alignment: Alignment.centerLeft,
                      padding: const EdgeInsets.symmetric(horizontal: 7),
                      visualDensity: VisualDensity.compact,
                    ),
                  ),
                ),
                if (dateRange != null)
                  IconButton(
                    tooltip: 'Clear date filter',
                    visualDensity: VisualDensity.compact,
                    onPressed: () => setState(() => _messageSearchDateRange = null),
                    icon: const Icon(Icons.event_busy_rounded, size: 17),
                  ),
                Text(
                  '$resultCount / $loadedCount',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: colors.onSurface.withValues(alpha: .65),
                  ),
                ),
                const SizedBox(width: 7),
                TextButton(
                  onPressed: _clearMessageSearch,
                  style: TextButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 7),
                    visualDensity: VisualDensity.compact,
                  ),
                  child: const Text('Done'),
                ),
              ],
            ),
            Text(
              'Search covers $loadedCount loaded messages. Load older messages in the timeline to expand results.',
              style: TextStyle(
                fontSize: 10,
                height: 1.25,
                color: colors.onSurface.withValues(alpha: .58),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _startReply(RemoteMessage message) {
    setState(() {
      _replyingTo = message;
      _editingMessageId = null;
      _editingOriginalText = null;
    });
    _composerFocus.requestFocus();
  }

  void _startEdit(RemoteMessage message) {
    if (message.senderId != messaging.currentUserId) return;
    if (SharedMediaService(Supabase.instance.client).isMediaPayload(message.text)) return;
    setState(() {
      _editingMessageId = message.id;
      _editingOriginalText = message.text;
      _replyingTo = null;
    });
    controller.text = message.text;
    controller.selection = TextSelection.collapsed(offset: controller.text.length);
    _composerFocus.requestFocus();
  }

  void _cancelComposerMode() {
    setState(() {
      _editingMessageId = null;
      _editingOriginalText = null;
      _replyingTo = null;
    });
    controller.clear();
    unawaited(messaging.sendTyping(false).catchError((_) {}));
  }

  Future<void> _showMessageActions(RemoteMessage message) async {
    final mine = message.senderId == messaging.currentUserId;
    final isMedia = SharedMediaService(Supabase.instance.client).isMediaPayload(message.text);
    final action = await showModalBottomSheet<String>(
      context: context,
      builder: (sheetContext) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.reply),
              title: const Text('Reply'),
              onTap: () => Navigator.pop(sheetContext, 'reply'),
            ),
            if (!isMedia && message.deletedForEveryoneAt == null)
              ListTile(
                leading: const Icon(Icons.copy_rounded),
                title: const Text('Copy text'),
                onTap: () => Navigator.pop(sheetContext, 'copy'),
              ),
            if (mine && !isMedia)
              ListTile(
                leading: const Icon(Icons.edit_outlined),
                title: const Text('Edit'),
                onTap: () => Navigator.pop(sheetContext, 'edit'),
              ),
            ListTile(
              leading: const Icon(Icons.add_reaction_outlined),
              title: const Text('React'),
              onTap: () => Navigator.pop(sheetContext, 'react'),
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline),
              title: const Text('Delete for me'),
              onTap: () => Navigator.pop(sheetContext, 'delete_me'),
            ),
            if (mine)
              ListTile(
                leading: const Icon(Icons.delete_forever_outlined),
                title: const Text('Delete for everyone'),
                onTap: () => Navigator.pop(sheetContext, 'delete_everyone'),
              ),
          ],
        ),
      ),
    );
    if (!mounted || action == null) return;
    switch (action) {
      case 'reply':
        _startReply(message);
        break;
      case 'copy':
        await Clipboard.setData(ClipboardData(text: message.text));
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Message copied to clipboard.')),
          );
        }
        break;
      case 'edit':
        _startEdit(message);
        break;
      case 'react':
        _showReactionPicker(message);
        break;
      case 'delete_me':
        setState(() => _hiddenMessageIds.add(message.id));
        await _saveLocalChatState();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Message deleted from this device.')),
          );
        }
        break;
      case 'delete_everyone':
        final confirmed = await showDialog<bool>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: const Text('Delete for everyone?'),
            content: const Text(
              'Both phones will show a deleted-message placeholder. This action cannot be undone.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, false),
                child: const Text('Cancel'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, true),
                child: const Text('Delete for everyone'),
              ),
            ],
          ),
        );
        if (confirmed != true || !mounted) break;
        try {
          await messaging.deleteMessageForEveryone(message.id);
          // Fetch the tombstone by ID so deletion also updates an older page
          // that is not part of the newest-100 conversation refresh.
          final tombstone = await messaging.getMessageById(message.id);
          if (tombstone != null) {
            final index = messages.indexWhere((item) => item.id == tombstone.id);
            if (index >= 0 && mounted) setState(() => messages[index] = tombstone);
            await _purgeDeletedMediaCaches([tombstone]);
          } else {
            final metadata = SharedMediaService(Supabase.instance.client).decode(message.text);
            final path = metadata?['path']?.toString();
            if (path != null && path.isNotEmpty) {
              final media = SharedMediaService(Supabase.instance.client);
              await media.deleteCachedPath(path);
              await media.deleteRemotePath(path);
            }
          }
          await _loadMessages();
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Message deleted for everyone.')),
            );
          }
        } catch (e) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Could not delete message: $e')),
            );
          }
        }
        break;
    }
  }

  Future<void> _showReactionPicker(RemoteMessage message) async {
    const emojis = ['❤️', '😂', '👍', '😮', '😢', '🔥'];
    final picked = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Wrap(
            alignment: WrapAlignment.spaceEvenly,
            children: emojis
                .map((e) => InkWell(
                      onTap: () => Navigator.pop(ctx, e),
                      child: Padding(
                        padding: const EdgeInsets.all(10),
                        child: Text(e, style: const TextStyle(fontSize: 30)),
                      ),
                    ))
                .toList(),
          ),
        ),
      ),
    );
    if (picked != null && mounted) {
      await _toggleReaction(message.id, picked);
    }
  }

  Future<void> _toggleReaction(String messageId, String emoji) async {
    try {
      final currentlyActive = await messaging.hasMyReaction(messageId, emoji);
      await messaging.setReaction(messageId, emoji, active: !currentlyActive);
      await _loadMessages();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not sync reaction: $e')),
        );
      }
    }
  }

  Future<void> _clearChatForMe() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Clear chat?'),
        content: const Text(
          'This clears the conversation only on this device. The other person’s chat is not affected.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Clear chat')),
        ],
      ),
    );
    if (confirm == true && mounted) {
      try {
        int cutoffMs;
        try {
          final serverNow = await Supabase.instance.client.rpc('likedin_server_now');
          final serverDate = DateTime.tryParse(serverNow.toString());
          cutoffMs = serverDate?.millisecondsSinceEpoch ?? DateTime.now().toUtc().millisecondsSinceEpoch;
        } catch (_) {
          cutoffMs = DateTime.now().toUtc().millisecondsSinceEpoch;
        }
        setState(() => _clearedBeforeMs = cutoffMs);
        await _saveLocalChatState();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Chat cleared on this device. New messages will still appear.')),
          );
        }
      } catch (error) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Could not clear chat: $error')),
          );
        }
      }
    }
  }

  void _beginNicknameEdit() {
    nicknameController.text = nickname ?? '';
    setState(() => editingNickname = true);
  }

  void _cancelNicknameEdit() {
    nicknameController.clear();
    if (mounted) setState(() => editingNickname = false);
  }

  Future<void> _saveNickname() async {
    final peer = peerId;
    if (peer == null) return;
    final clean = nicknameController.text.trim();
    try {
      final prefs = await SharedPreferences.getInstance();
      if (clean.isEmpty) {
        await prefs.remove('likedIn_nickname_$peer');
      } else {
        await prefs.setString('likedIn_nickname_$peer', clean);
      }
      if (!mounted) return;
      setState(() {
        nickname = clean.isEmpty ? null : clean;
        editingNickname = false;
      });
      nicknameController.clear();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not save nickname: $e')),
        );
      }
    }
  }

  Future<void> _startVoiceRecording() async {
    if (saving || peerId == null || _recordingVoice || _startingVoiceRecording) return;
    _startingVoiceRecording = true;
    _voiceReleaseRequested = false;
    try {
      if (!await _voiceRecorder.hasPermission()) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Microphone permission is required to record a voice message.')),
          );
        }
        return;
      }
      final dir = await getTemporaryDirectory();
      final path = '${dir.path}/likedin_voice_${DateTime.now().microsecondsSinceEpoch}.m4a';
      await _voiceRecorder.start(
        const RecordConfig(encoder: AudioEncoder.aacLc, bitRate: 96000, sampleRate: 44100),
        path: path,
      );
      if (_voiceReleaseRequested || !mounted) {
        final stoppedPath = await _voiceRecorder.stop();
        if (stoppedPath != null) {
          final f = File(stoppedPath);
          if (await f.exists()) await f.delete();
        }
        return;
      }
      setState(() {
        _recordingVoice = true;
        _voiceRecordStarted = DateTime.now();
        _voiceRecordSeconds = 0;
      });
      _voiceTimer?.cancel();
      _voiceTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (!mounted || _voiceRecordStarted == null) return;
        setState(() {
          _voiceRecordSeconds = DateTime.now().difference(_voiceRecordStarted!).inSeconds;
        });
      });
      HapticFeedback.mediumImpact();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not start recording: $e')),
        );
      }
    } finally {
      _startingVoiceRecording = false;
    }
  }

  Future<void> _stopAndSendVoice({bool discard = false}) async {
    if (_startingVoiceRecording && !_recordingVoice) {
      _voiceReleaseRequested = true;
      return;
    }
    if (!_recordingVoice) return;
    _voiceTimer?.cancel();
    _voiceTimer = null;
    try {
      final path = await _voiceRecorder.stop();
      if (mounted) {
        setState(() {
          _recordingVoice = false;
          _voiceRecordStarted = null;
          _voiceRecordSeconds = 0;
          uploading = true;
        });
      }
      if (path == null || discard) {
        if (path != null) {
          final f = File(path);
          if (await f.exists()) await f.delete();
        }
        return;
      }
      final file = File(path);
      if (!await file.exists() || await file.length() < 1200) {
        if (await file.exists()) await file.delete();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Recording was too short. Hold the microphone a little longer.')),
          );
        }
        return;
      }
      final recipient = peerId;
      if (recipient == null) return;
      final media = SharedMediaService(Supabase.instance.client);
      // Copy into the account-bound persistent media outbox before removing the
      // recorder temp file. A stable outbox ID is also the message idempotency key.
      final replyId = await _resolveReplyTargetId(_replyingTo);
      if (!mounted) return;
      await media.enqueue(
        file,
        recipient,
        originalName: 'Voice message.m4a',
        replyToMessageId: replyId,
      );
      if (await file.exists()) await file.delete();
      if (mounted && _replyingTo != null) setState(() => _replyingTo = null);
      final completed = await SharedMediaService.processRetryQueue(Supabase.instance.client);
      if (completed) await _loadMessages();
      if (mounted) {
        final quarantined = SharedMediaService.lastQuarantinedCount > 0;
        final detail = SharedMediaService.lastQueueError;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(completed
                ? 'Voice message sent.'
                : quarantined
                    ? 'Voice message was not sent: ${detail ?? 'the file cannot be uploaded'}. It was kept in the local quarantine and removed from automatic retries.'
                    : 'Voice message saved for retry when the connection is available.'),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Voice message failed: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => uploading = false);
    }
  }

  Future<void> _showAttachmentPicker() async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Theme.of(context).colorScheme.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (sheetContext) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const SizedBox(height: 10),
        ListTile(leading: const Icon(Icons.photo_library_outlined, color: brandBlue), title: const Text('Gallery'), subtitle: const Text('Photos, videos and GIFs'), onTap: () => Navigator.pop(sheetContext, 'gallery')),
        ListTile(leading: const Icon(Icons.folder_open_rounded), title: const Text('Browse files'), subtitle: const Text('Documents and other files'), onTap: () => Navigator.pop(sheetContext, 'files')),
        ListTile(leading: const Icon(Icons.gif_box_outlined, color: brandBlue), title: const Text('Choose a GIF'), subtitle: const Text('Pick an animated GIF file'), onTap: () => Navigator.pop(sheetContext, 'gif')),
        const SizedBox(height: 8),
      ])),
    );
    if (!mounted || choice == null) return;
    if (choice == 'gallery') await _openInAppGallery();
    if (choice == 'files') await attach();
    if (choice == 'gif') await attach(gifsOnly: true);
  }

  Future<void> _showStickerPicker() async {
    const stickers = <String>[
      '😂', '🥹', '😍', '😘', '🤗', '🥳', '😎', '🤌',
      '❤️', '💖', '💗', '💯', '🔥', '✨', '🌸', '🫶',
      '😭', '🙄', '😴', '🤔', '😤', '🤝', '👏', '🫡',
      '🐼', '🐻', '🐸', '🦋', '🌈', '☀️', '🎉', '💐',
    ];
    final selected = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Theme.of(context).colorScheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(width: 38, height: 4, decoration: BoxDecoration(
                color: Theme.of(context).dividerColor,
                borderRadius: BorderRadius.circular(4),
              )),
              const SizedBox(height: 16),
              Row(children: [
                const Expanded(child: Text('Stickers', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
                Text('Tap to send', style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor)),
              ]),
              const SizedBox(height: 14),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: stickers.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 4, mainAxisSpacing: 8, crossAxisSpacing: 8,
                ),
                itemBuilder: (_, index) => Material(
                  color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: .55),
                  borderRadius: BorderRadius.circular(16),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () => Navigator.pop(sheetContext, stickers[index]),
                    child: Center(child: Text(stickers[index], style: const TextStyle(fontSize: 34))),
                  ),
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
    if (selected == null || !mounted) return;
    controller.text = selected;
    controller.selection = TextSelection.collapsed(offset: controller.text.length);
    setState(() {});
    await send();
  }

  Future<void> _openInAppGallery() async {
    if (uploading) return;
    final selected = await InAppGalleryPicker.show(context, maxSelection: 10);
    if (!mounted || selected == null || selected.isEmpty) return;
    await _sendGalleryAssets(selected);
  }

  Future<void> _sendGalleryAssets(List<AssetEntity> assets) async {
    final recipient = peerId;
    if (recipient == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Your friend must register before sharing media.')),
      );
      return;
    }
    if (uploading) return;
    setState(() => uploading = true);
    var queued = 0;
    final failures = <String>[];
    try {
      final media = SharedMediaService(Supabase.instance.client);
      final replyId = await _resolveReplyTargetId(_replyingTo);
      for (var index = 0; index < assets.length; index++) {
        final asset = assets[index];
        try {
          final original = await asset.file;
          if (original == null || !await original.exists()) {
            throw StateError('This item is no longer available on the device.');
          }
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Preparing ${index + 1} of ${assets.length}: ${asset.title ?? 'media'}')),
          );
          final prepared = await media.prepare(original);
          try {
            await media.enqueue(
              prepared,
              recipient,
              originalName: asset.title?.trim().isNotEmpty == true
                  ? asset.title!.trim()
                  : p.basename(original.path),
              replyToMessageId: replyId,
            );
            queued++;
          } finally {
            if (prepared.path != original.path && await prepared.exists()) {
              try { await prepared.delete(); } catch (_) {}
            }
          }
        } catch (error) {
          failures.add('${asset.title ?? 'media'}: $error');
        }
      }
      if (replyId != null && queued > 0 && mounted) {
        setState(() => _replyingTo = null);
      }
      if (queued > 0) {
        if (!mounted) return;
        setState(() => uploading = false);
        final summary = '$queued item${queued == 1 ? '' : 's'} queued. Sending in the background…';
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(failures.isEmpty ? summary : '$summary ${failures.length} item(s) could not be queued.')),
        );
        _processQueuedMediaAfterFastSend();
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(failures.isEmpty ? 'No media was selected.' : 'Could not queue media: ${failures.first}')),
        );
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gallery send failed: $error')),
        );
      }
    } finally {
      if (mounted) setState(() => uploading = false);
    }
  }

  void _handleKeyboardContent(KeyboardInsertedContent content) {
    // Android keyboards such as Gboard use the image-keyboard commitContent API.
    // Keep this handler fire-and-forget because TextField's callback is void.
    unawaited(_sendKeyboardContent(content));
  }

  Future<void> _sendKeyboardContent(KeyboardInsertedContent content) async {
    final recipient = peerId;
    if (recipient == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Your friend must register before sharing media.')),
        );
      }
      return;
    }
    if (uploading) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please wait for the current upload to finish.')),
        );
      }
      return;
    }

    final keepKeyboardOpen = _composerFocus.hasFocus;
    final mime = content.mimeType.toLowerCase().trim();
    const supported = <String>{
      'image/gif', 'image/png', 'image/jpeg', 'image/jpg', 'image/webp',
      'image/bmp', 'image/tiff',
    };
    if (!supported.contains(mime)) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gboard inserted an unsupported media type: $mime')),
        );
      }
      return;
    }

    // Keep the raw keyboard payload bounded. GIFs are further optimized to
    // animated WebP and limited to 2 MB before they enter the durable outbox.
    const keyboardMediaLimit = 8 * 1024 * 1024;
    final bytes = content.data;
    if (bytes != null && bytes.length > keyboardMediaLimit) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('That keyboard GIF/image is over 8 MB. Choose a smaller one.')),
        );
      }
      return;
    }

    final extension = switch (mime) {
      'image/gif' => 'gif',
      'image/png' => 'png',
      'image/webp' => 'webp',
      'image/bmp' => 'bmp',
      'image/tiff' => 'tiff',
      _ => 'jpg',
    };
    final fileName = 'Gboard_${DateTime.now().microsecondsSinceEpoch}.$extension';
    File? tempFile;
    File? preparedFile;
    if (!mounted) return;
    setState(() => uploading = true);
    try {
      late final File uploadFile;
      if (bytes != null && bytes.isNotEmpty) {
        final temp = await getTemporaryDirectory();
        uploadFile = File(p.join(temp.path, 'likedin_$fileName'));
        tempFile = uploadFile;
        await uploadFile.writeAsBytes(bytes, flush: true);
      } else {
        final uri = content.uri.trim();
        if (!uri.startsWith('content://')) {
          throw StateError('The keyboard did not provide readable image data.');
        }
        final copiedPath = await _keyboardMediaChannel.invokeMethod<String>(
          'copyContentUriToCache',
          <String, Object>{
            'uri': uri,
            'mimeType': mime,
            'maxBytes': keyboardMediaLimit,
          },
        );
        if (copiedPath == null || copiedPath.isEmpty) {
          throw StateError('The keyboard media could not be read. Try the in-app Gallery.');
        }
        uploadFile = File(copiedPath);
        tempFile = uploadFile;
      }

      final actualSize = await uploadFile.length();
      if (actualSize <= 0 || actualSize > keyboardMediaLimit) {
        throw StateError('Keyboard media must be smaller than 8 MB before optimization.');
      }
      final replyId = await _resolveReplyTargetId(_replyingTo);
      final media = SharedMediaService(Supabase.instance.client);
      preparedFile = await media.prepare(uploadFile);
      await media.enqueue(
        preparedFile,
        recipient,
        originalName: fileName,
        replyToMessageId: replyId,
      );
      if (!mounted) return;
      setState(() {
        if (replyId != null) _replyingTo = null;
        uploading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(mime == 'image/gif'
            ? 'GIF optimized and queued. Sending in the background…'
            : 'Media queued. Sending in the background…')),
      );
      if (keepKeyboardOpen) _restoreComposerKeyboard();
      _processQueuedMediaAfterFastSend();
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not send keyboard media: $error')),
        );
      }
    } finally {
      if (preparedFile != null && tempFile != null && preparedFile.path != tempFile.path) {
        try { if (await preparedFile.exists()) await preparedFile.delete(); } catch (_) {}
      }
      if (tempFile != null) {
        try { if (await tempFile.exists()) await tempFile.delete(); } catch (_) {}
      }
      if (mounted && uploading) setState(() => uploading = false);
      if (keepKeyboardOpen && mounted) _restoreComposerKeyboard();
    }
  }

  void _restoreComposerKeyboard() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _composerFocus.requestFocus();
      SystemChannels.textInput.invokeMethod<void>('TextInput.show');
    });
  }

  void _processQueuedMediaAfterFastSend() {
    unawaited(() async {
      try {
        final completed = await SharedMediaService.processRetryQueue(Supabase.instance.client);
        if (!mounted) return;
        try { await _loadMessages(); } catch (_) {}
        if (!mounted) return;
        if (completed) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('GIF/media sent.')),
          );
        } else {
          final quarantined = SharedMediaService.lastQuarantinedCount > 0;
          final detail = SharedMediaService.lastQueueError;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(quarantined
                ? 'Media could not be sent: ${detail ?? 'the file was rejected'}.'
                : 'Media is saved locally and will retry when the connection is available.')),
          );
        }
      } catch (error) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Media is safely queued. Sending will retry: $error')),
        );
      }
    }());
  }

  Future<void> attach({bool gifsOnly = false}) async {
    if (uploading) return;
    final recipient = peerId;
    if (recipient == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Your friend must register before sharing files.')),
      );
      return;
    }
    setState(() => uploading = true);
    try {
      final picked = await FilePicker.platform.pickFiles(
        allowMultiple: true,
        withData: false,
        type: gifsOnly ? FileType.custom : FileType.any,
        allowedExtensions: gifsOnly ? const ['gif'] : null,
      );
      if (picked == null || picked.files.isEmpty) return;
      final media = SharedMediaService(Supabase.instance.client);
      final replyId = await _resolveReplyTargetId(_replyingTo);
      if (!mounted) return;
      for (final item in picked.files) {
        final path = item.path;
        if (path == null) {
          throw StateError(
            'Android did not provide a readable file path for ${item.name}. Please choose the file from Downloads or Gallery.',
          );
        }
        final original = File(path);
        if (!await original.exists()) continue;
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Preparing ${item.name}…')),
        );
        final prepared = await media.prepare(original);
        try {
          await media.enqueue(
            prepared,
            recipient,
            originalName: item.name,
            replyToMessageId: replyId,
          );
        } finally {
          if (prepared.path != original.path && await prepared.exists()) {
            try {
              await prepared.delete();
            } catch (_) {}
          }
        }
      }
      if (replyId != null && mounted) setState(() => _replyingTo = null);
      if (mounted) {
        setState(() => uploading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Attachments queued. Sending in the background…')),
        );
        _processQueuedMediaAfterFastSend();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Attachment not sent: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => uploading = false);
    }
  }

  Widget _messageContent(RemoteMessage message) {
    if (message.deletedForEveryoneAt != null) {
      return Text(
        'This message was deleted',
        style: TextStyle(fontSize: 15, fontStyle: FontStyle.italic, color: Theme.of(context).hintColor),
      );
    }
    final payload = SharedMediaService(Supabase.instance.client).decode(message.text);
    if (payload == null) {
      final runes = message.text.runes.toList(growable: false);
      final isSticker = runes.isNotEmpty && runes.length <= 8 && runes.every((r) =>
          r >= 0x1F000 || (r >= 0x2600 && r <= 0x27FF) ||
          r == 0xFE0F || r == 0x200D || r == 0x20E3);
      return Text(
        message.text,
        textAlign: isSticker ? TextAlign.center : TextAlign.start,
        softWrap: true,
        style: TextStyle(fontSize: isSticker ? 42 : 15, height: isSticker ? 1.15 : 1.35),
      );
    }
    final name = payload['animated'] == true
        ? 'GIF'
        : (payload['name']?.toString() ?? 'Attachment');
    final kind = payload['kind']?.toString() ?? 'file';
    final size = (payload['size'] as num?)?.toInt() ?? 0;
    final sizeLabel = size >= 1048576
        ? '${(size / 1048576).toStringAsFixed(1)} MB'
        : '${(size / 1024).toStringAsFixed(0)} KB';
    if (kind == 'image' || kind == 'video') {
      return _ChatMediaMessage(
        key: ValueKey('media-${message.id}-${payload['path']}'),
        payload: payload,
        name: name,
        sizeLabel: sizeLabel,
      );
    }
    if (kind == 'audio') {
      return _VoiceMessagePlayer(
        key: ValueKey('audio-${message.id}-${payload['path']}'),
        payload: payload,
      );
    }
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(Icons.insert_drive_file_outlined, size: 28),
        const SizedBox(width: 10),
        Flexible(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                name,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
              Text(sizeLabel, style: const TextStyle(fontSize: 11, color: muted)),
            ],
          ),
        ),
        IconButton(
          tooltip: 'Save to Downloads',
          onPressed: () async {
            try {
              final saved = await SharedMediaService(Supabase.instance.client)
                  .downloadToPublicDownloads(payload);
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Saved $saved to Downloads.')),
                );
              }
            } catch (e) {
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Download failed: $e')),
                );
              }
            }
          },
          icon: const Icon(Icons.download_rounded),
        ),
      ],
    );
  }

  String _time(DateTime value) {
    final local = value.toLocal();
    final hour = local.hour % 12 == 0 ? 12 : local.hour % 12;
    return '$hour:${local.minute.toString().padLeft(2, '0')} ${local.hour >= 12 ? 'PM' : 'AM'}';
  }

  bool _isSameCalendarDay(DateTime a, DateTime b) {
    final la = a.toLocal();
    final lb = b.toLocal();
    return la.year == lb.year && la.month == lb.month && la.day == lb.day;
  }

  String _dayBannerLabel(DateTime value) {
    final local = value.toLocal();
    final now = DateTime.now();
    if (_isSameCalendarDay(local, now)) return 'Today';
    if (_isSameCalendarDay(local, now.subtract(const Duration(days: 1)))) return 'Yesterday';
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return '${local.day} ${months[local.month - 1]} ${local.year}';
  }

  String _presenceText() {
    if (peerOnline) return 'Online';
    if (lastSeen == null) return 'Last seen unavailable';
    final delta = DateTime.now().difference(lastSeen!);
    if (delta.inMinutes < 1) return 'Last seen just now';
    if (delta.inHours < 1) return 'Last seen ${delta.inMinutes}m ago';
    if (delta.inDays < 1) return 'Last seen ${delta.inHours}h ago';
    return 'Last seen ${delta.inDays}d ago';
  }

  Widget _receipt(RemoteMessage message) {
    if (message.readAt != null) {
      return const Icon(Icons.done_all, size: 15, color: Color(0xFF1685E8));
    }
    if (message.deliveredAt != null) return const Icon(Icons.done_all, size: 15);
    return const Icon(Icons.check, size: 15);
  }

  @override
  Widget build(BuildContext context) {
    // Materialize this filtered message view once per build. The old getter
    // allocated a new list each time itemBuilder accessed it, multiplying the
    // work across every visible row on low-end phones.
    final chatDisplayMessages = _chatDisplayMessages;
    final hasActiveMessageSearch = _hasActiveMessageSearch;
    return AuroraBackdrop(
        child: Column(
          children: [
          GlassPanel(
            blur: 14,
            glow: false,
            radius: const BorderRadius.vertical(bottom: Radius.circular(20)),
            tint: Theme.of(context).brightness == Brightness.dark
                ? const Color(0xE0101E31)
                : const Color(0xDDFBFDFF),
            padding: const EdgeInsets.fromLTRB(4, 6, 8, 6),
            child: Row(
              children: [
                IconButton(
                  tooltip: 'Back to home',
                  onPressed: widget.onBack,
                  icon: const Icon(Icons.arrow_back_rounded),
                ),
                CircleAvatar(
                  backgroundColor: brandBlue.withValues(alpha: .14),
                  child: peerAvatarUrl == null
                      ? const Icon(Icons.person, color: brandBlue)
                      : ClipOval(
                          child: Image.network(
                            peerAvatarUrl!,
                            width: 40,
                            height: 40,
                            cacheWidth: 120,
                            cacheHeight: 120,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => const Icon(Icons.person, color: brandBlue),
                          ),
                        ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: editingNickname
                      ? TextField(
                          controller: nicknameController,
                          autofocus: true,
                          maxLength: 30,
                          decoration: const InputDecoration(
                            hintText: 'Nickname for this person',
                            counterText: '',
                            isDense: true,
                          ),
                          onSubmitted: (_) => _saveNickname(),
                        )
                      : GestureDetector(
                          onTap: _beginNicknameEdit,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(headerName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17, letterSpacing: -.2)),
                              Text(
                                _presenceText(),
                                style: TextStyle(
                                  fontSize: 11,
                                  color: peerOnline ? const Color(0xFF16865A) : muted,
                                ),
                              ),
                            ],
                          ),
                        ),
                ),
                if (editingNickname) ...[
                  IconButton(
                    tooltip: 'Cancel nickname',
                    onPressed: _cancelNicknameEdit,
                    icon: const Icon(Icons.close, size: 19),
                  ),
                  IconButton(
                    tooltip: 'Save nickname',
                    onPressed: _saveNickname,
                    icon: const Icon(Icons.check, color: brandBlue, size: 20),
                  ),
                ],
                IconButton(
                  tooltip: _showMessageSearch ? 'Close message search' : 'Search messages',
                  onPressed: () {
                    if (_showMessageSearch) {
                      _clearMessageSearch();
                    } else {
                      setState(() => _showMessageSearch = true);
                    }
                  },
                  visualDensity: VisualDensity.compact,
                  icon: Icon(
                    _showMessageSearch ? Icons.close_rounded : Icons.search_rounded,
                    color: brandBlue,
                  ),
                ),
                IconButton(
                  tooltip: 'Audio call',
                  onPressed: peerId == null
                      ? null
                      : () => _showCallSetup(context, video: false, recipientId: peerId),
                  icon: const Icon(Icons.call_outlined, color: brandBlue),
                ),
                IconButton(
                  tooltip: 'Video call',
                  onPressed: peerId == null
                      ? null
                      : () => _showCallSetup(context, video: true, recipientId: peerId),
                  icon: const Icon(Icons.videocam_outlined, color: brandBlue),
                ),
                PopupMenuButton<String>(
                  tooltip: 'Chat options',
                  onSelected: (v) {
                    if (v == 'nickname') _beginNicknameEdit();
                    if (v == 'clear') _clearChatForMe();
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'nickname', child: Text('Change nickname')),
                    PopupMenuItem(value: 'clear', child: Text('Clear chat on this device')),
                  ],
                ),
              ],
            ),
          ),
          if (_showMessageSearch) _buildMessageSearchPanel(context),
          if (_chatIncomingCall != null)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFEAF3FF),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFFB8D6F5)),
              ),
              child: Row(
                children: [
                  Icon(
                    _chatIncomingCall!['call_type']?.toString().toLowerCase() == 'video'
                        ? Icons.videocam
                        : Icons.call,
                    color: brandBlue,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${_chatIncomingCall!['call_type']?.toString().toLowerCase() == 'video' ? 'Video' : 'Audio'} call incoming',
                          style: const TextStyle(fontWeight: FontWeight.w700, color: ink),
                        ),
                        const Text(
                          'Your friend is waiting for you to join.',
                          style: TextStyle(fontSize: 12, color: ink),
                        ),
                      ],
                    ),
                  ),
                  TextButton(
                    onPressed: _joiningChatCall ? null : _declineChatIncomingCall,
                    child: const Text('Decline', style: TextStyle(color: Color(0xFFB42318))),
                  ),
                  const SizedBox(width: 6),
                  FilledButton(
                    onPressed: _joiningChatCall ? null : _joinChatIncomingCall,
                    child: _joiningChatCall
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                          )
                        : const Text('Join call'),
                  ),
                ],
              ),
            ),
          Expanded(
            child: Stack(
              children: [
                Positioned.fill(
                  child: loadError != null
                      ? Center(
                          child: Padding(
                            padding: const EdgeInsets.all(20),
                            child: Text(
                              'Could not connect to messaging backend.\n$loadError',
                              textAlign: TextAlign.center,
                            ),
                          ),
                        )
                      : messagesLoading
                          ? const Center(child: CircularProgressIndicator())
                          : peerId == null
                              ? const Center(
                                  child: Padding(
                                    padding: EdgeInsets.all(28),
                                    child: Text(
                                      'Waiting for your friend to register.',
                                      textAlign: TextAlign.center,
                                    ),
                                  ),
                                )
                              : ListView.builder(
                                  controller: _chatScrollController,
                                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 18),
                                  itemCount: chatDisplayMessages.length +
                                      ((_hasOlderMessages || _loadingOlderMessages) ? 1 : 0) +
                                      (peerTyping && !hasActiveMessageSearch ? 1 : 0) +
                                      (chatDisplayMessages.isEmpty &&
                                              (!peerTyping || hasActiveMessageSearch)
                                          ? 1
                                          : 0),
                                  itemBuilder: (context, i) {
                                    final hasOlderHeader = _hasOlderMessages || _loadingOlderMessages;
                                    if (hasOlderHeader && i == 0) {
                                      return Center(
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(vertical: 10),
                                          child: _loadingOlderMessages
                                              ? const SizedBox(
                                                  width: 18,
                                                  height: 18,
                                                  child: CircularProgressIndicator(strokeWidth: 2),
                                                )
                                              : TextButton.icon(
                                                  onPressed: _loadOlderMessages,
                                                  icon: const Icon(Icons.history_rounded, size: 17),
                                                  label: const Text('Load older messages'),
                                                ),
                                        ),
                                      );
                                    }
                                    final messageIndex = i - (hasOlderHeader ? 1 : 0);
                                    if (messageIndex >= chatDisplayMessages.length) {
                                      if (hasActiveMessageSearch) {
                                        return Padding(
                                          padding: const EdgeInsets.all(28),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Icon(Icons.search_off_rounded, size: 34,
                                                  color: Theme.of(context).hintColor),
                                              const SizedBox(height: 9),
                                              const Text('No messages match these filters.',
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(fontWeight: FontWeight.w700)),
                                              const SizedBox(height: 4),
                                              Text('Try another phrase, media type or date range.',
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(color: Theme.of(context).hintColor,
                                                      fontSize: 12)),
                                            ],
                                          ),
                                        );
                                      }
                                      if (peerTyping && !hasActiveMessageSearch) {
                                        return const _TypingBubble();
                                      }
                                      return Padding(
                                        padding: const EdgeInsets.fromLTRB(28, 56, 28, 28),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Container(
                                              width: 64,
                                              height: 64,
                                              decoration: BoxDecoration(
                                                color: brandBlue.withValues(alpha: .10),
                                                shape: BoxShape.circle,
                                              ),
                                              child: const Icon(
                                                Icons.chat_bubble_outline_rounded,
                                                size: 28,
                                                color: brandBlue,
                                              ),
                                            ),
                                            const SizedBox(height: 14),
                                            Text(
                                              'No messages with $headerName yet',
                                              textAlign: TextAlign.center,
                                              style: const TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.w700,
                                              ),
                                            ),
                                            const SizedBox(height: 6),
                                            Text(
                                              'Type below to say hello. Hold the mic button to record a voice message.',
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                fontSize: 13,
                                                height: 1.35,
                                                color: Theme.of(context).hintColor,
                                              ),
                                            ),
                                          ],
                                        ),
                                      );
                                    }
                                    final message = chatDisplayMessages[messageIndex];
                                    final showDayHeader = messageIndex == 0 ||
                                        !_isSameCalendarDay(
                                          chatDisplayMessages[messageIndex - 1].createdAt,
                                          message.createdAt,
                                        );
                                    final outgoing = message.senderId == messaging.currentUserId;
                                    final quoted = _replyTargets[message.id] ??
                                        (message.clientMessageId == null
                                            ? null
                                            : _replyTargets[message.clientMessageId!]);
                                    final replySource = _replySourceMessages[message.id] ??
                                        (message.clientMessageId == null
                                            ? null
                                            : _replySourceMessages[message.clientMessageId!]);
                                    final messageKey =
                                        _messageKeys.putIfAbsent(message.id, () => GlobalKey());
                                    final reactions = _messageReactions[message.id] ?? <String>{};
                                    final reactionUsers =
                                        _messageReactionUsers[message.id] ?? const <String, Set<String>>{};
                                    final stableKey = message.clientMessageId ?? message.id;
                                    final shouldAnimate = _animatedMessageIds.add(stableKey);
                                    return RepaintBoundary(
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          if (showDayHeader)
                                            Padding(
                                              padding: const EdgeInsets.symmetric(vertical: 8),
                                              child: Container(
                                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                                                decoration: BoxDecoration(
                                                  color: Theme.of(context).brightness == Brightness.dark
                                                      ? const Color(0xFF1E2D3B)
                                                      : const Color(0xFFE8EEF5),
                                                  borderRadius: BorderRadius.circular(14),
                                                ),
                                                child: Text(
                                                  _dayBannerLabel(message.createdAt),
                                                  style: TextStyle(
                                                    fontSize: 11,
                                                    fontWeight: FontWeight.w700,
                                                    color: Theme.of(context).hintColor,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          _SwipeReplyGesture(
                                            key: messageKey,
                                            onReply: () {
                                              HapticFeedback.selectionClick();
                                              _startReply(message);
                                            },
                                            child: GestureDetector(
                                              onLongPress: message.deletedForEveryoneAt == null
                                                  ? () => _showMessageActions(message)
                                                  : null,
                                              child: TweenAnimationBuilder<double>(
                                                key: ValueKey('message-$stableKey'),
                                                tween: Tween<double>(begin: shouldAnimate ? 0 : 1, end: 1),
                                                duration: Duration(milliseconds: shouldAnimate ? 200 : 0),
                                                curve: Curves.easeOutCubic,
                                                builder: (context, value, child) => Opacity(
                                                  opacity: value,
                                                  child: Transform.translate(
                                                    offset: Offset(0, 8 * (1 - value)),
                                                    child: child,
                                                  ),
                                                ),
                                                child: Align(
                                            alignment: outgoing
                                                ? Alignment.centerRight
                                                : Alignment.centerLeft,
                                            child: Container(
                                              margin: const EdgeInsets.symmetric(vertical: 4),
                                              padding: const EdgeInsets.fromLTRB(14, 10, 14, 8),
                                              constraints: const BoxConstraints(maxWidth: 310),
                                              decoration: BoxDecoration(
                                                color: outgoing
                                                    ? (Theme.of(context).brightness == Brightness.dark
                                                        ? const Color(0xFF1F3B63)
                                                        : const Color(0xFFDCEAFE))
                                                    : likedinSurface(Theme.of(context).brightness),
                                                border: outgoing
                                                    ? null
                                                    : Border.all(color: likedinOutline(Theme.of(context).brightness)),
                                                borderRadius: BorderRadius.only(
                                                  topLeft: const Radius.circular(20),
                                                  topRight: const Radius.circular(20),
                                                  bottomLeft: Radius.circular(outgoing ? 20 : 6),
                                                  bottomRight: Radius.circular(outgoing ? 6 : 20),
                                                ),
                                              ),
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.end,
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  if (quoted != null)
                                                    GestureDetector(
                                                      onTap: message.replyToMessageId == null
                                                          ? null
                                                          : () => _jumpToMessage(message.replyToMessageId!),
                                                      child: Container(
                                                        width: double.infinity,
                                                        margin: const EdgeInsets.only(bottom: 8),
                                                        padding: const EdgeInsets.fromLTRB(9, 7, 9, 7),
                                                        decoration: BoxDecoration(
                                                          color: Theme.of(context).brightness ==
                                                                  Brightness.dark
                                                              ? const Color(0xFF172B3B)
                                                              : const Color(0xFFF0F5FB),
                                                          borderRadius: BorderRadius.circular(10),
                                                          border: Border(
                                                            left: BorderSide(
                                                              color: outgoing
                                                                  ? const Color(0xFF55A7F5)
                                                                  : brandBlue,
                                                              width: 3,
                                                            ),
                                                          ),
                                                        ),
                                                        child: Column(
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          mainAxisSize: MainAxisSize.min,
                                                          children: [
                                                            Text(
                                                              'Replying to',
                                                              style: TextStyle(
                                                                fontSize: 11,
                                                                fontWeight: FontWeight.w700,
                                                                color: Theme.of(context).brightness ==
                                                                        Brightness.dark
                                                                    ? const Color(0xFF80BDF5)
                                                                    : brandBlue,
                                                              ),
                                                            ),
                                                            const SizedBox(height: 4),
                                                            _ReplyQuotePreview(
                                                              original: replySource,
                                                              fallbackText: quoted,
                                                              compact: true,
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  _messageContent(message),
                                                  if (message.deletedForEveryoneAt == null &&
                                                      message.editedAt != null)
                                                    const Padding(
                                                      padding: EdgeInsets.only(top: 2),
                                                      child: Text(
                                                        'Edited',
                                                        style: TextStyle(
                                                          fontSize: 10,
                                                          fontStyle: FontStyle.italic,
                                                        ),
                                                      ),
                                                    ),
                                                  if (reactions.isNotEmpty)
                                                    Padding(
                                                      padding: const EdgeInsets.only(top: 5),
                                                      child: Wrap(
                                                        spacing: 5,
                                                        runSpacing: 4,
                                                        children: reactions.map((emoji) {
                                                          final users = reactionUsers[emoji] ?? const <String>{};
                                                          final count = users.isEmpty ? 1 : users.length;
                                                          final mineReacted = users.contains(messaging.currentUserId);
                                                          return GestureDetector(
                                                            onTap: () => _toggleReaction(message.id, emoji),
                                                            child: Container(
                                                              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                                                              decoration: BoxDecoration(
                                                                color: mineReacted
                                                                    ? brandBlue.withValues(alpha: .16)
                                                                    : Theme.of(context).colorScheme.surface.withValues(alpha: .75),
                                                                borderRadius: BorderRadius.circular(12),
                                                                border: Border.all(
                                                                  color: mineReacted
                                                                      ? brandBlue
                                                                      : Theme.of(context).dividerColor,
                                                                ),
                                                              ),
                                                              child: Text(
                                                                count > 1 ? '$emoji $count' : emoji,
                                                                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                                                              ),
                                                            ),
                                                          );
                                                        }).toList(),
                                                      ),
                                                    ),
                                                  const SizedBox(height: 5),
                                                  Row(
                                                    mainAxisSize: MainAxisSize.min,
                                                    children: [
                                                      Text(
                                                        _time(message.createdAt),
                                                        style: const TextStyle(fontSize: 10),
                                                      ),
                                                      if (outgoing) ...[
                                                        const SizedBox(width: 4),
                                                        _receipt(message),
                                                      ],
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                        ],
                                      ),
                                    );
                                  },
                                ),
                ),
                if (_showScrollToBottom && messages.isNotEmpty)
                  Positioned(
                    right: 18,
                    bottom: 14,
                    child: Material(
                      elevation: 4,
                      color: Theme.of(context).colorScheme.surface,
                      shape: const CircleBorder(),
                      child: IconButton(
                        tooltip: 'Jump to latest message',
                        onPressed: () => _scrollToLatest(),
                        icon: const Icon(
                          Icons.keyboard_arrow_down_rounded,
                          color: brandBlue,
                          size: 30,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          if (_replyingTo != null || _editingMessageId != null)
            Container(
              margin: const EdgeInsets.fromLTRB(12, 8, 12, 2),
              padding: const EdgeInsets.fromLTRB(11, 8, 4, 8),
              decoration: BoxDecoration(
                color: likedinSurfaceRaised(Theme.of(context).brightness),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Row(
                children: [
                  Container(
                    width: 3,
                    height: 34,
                    decoration: BoxDecoration(
                      color: brandBlue,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          _editingMessageId != null
                              ? 'Editing message'
                              : 'Replying to ${_replyingTo!.senderId == messaging.currentUserId ? 'yourself' : headerName}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 12,
                            color: brandBlue,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 2),
                        if (_editingMessageId != null)
                          Text(
                            _editingOriginalText ?? '',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 12,
                              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .78),
                            ),
                          )
                        else
                          _ReplyQuotePreview(
                            original: _replyingTo,
                            fallbackText: _summarizeMessage(_replyingTo!),
                            compact: true,
                          ),
                      ],
                    ),
                  ),
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    tooltip: 'Cancel',
                    onPressed: _cancelComposerMode,
                    icon: const Icon(Icons.close_rounded, size: 19),
                  ),
                ],
              ),
            ),
          if (uploading)
            const LinearProgressIndicator(minHeight: 2.5, color: brandBlue),
          ValueListenableBuilder<TextEditingValue>(
            valueListenable: controller,
            builder: (context, editingValue, child) => SafeArea(
              top: false,
              child: GlassPanel(
                blur: 0,
              glow: false,
              radius: const BorderRadius.vertical(top: Radius.circular(23)),
              tint: Theme.of(context).brightness == Brightness.dark
                  ? const Color(0xE0101E31)
                  : const Color(0xE8FBFDFF),
              padding: const EdgeInsets.fromLTRB(8, 8, 9, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  IconButton(
                    onPressed: uploading ? null : _showAttachmentPicker,
                    tooltip: uploading ? 'Uploading attachment…' : 'Gallery and files',
                    visualDensity: VisualDensity.compact,
                    icon: uploading
                        ? const SizedBox(width: 19, height: 19, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.add_circle_outline_rounded, size: 24),
                  ),
                  IconButton(
                    onPressed: uploading ? null : _showStickerPicker,
                    tooltip: 'Stickers',
                    visualDensity: VisualDensity.compact,
                    icon: const Icon(Icons.sticky_note_2_outlined, size: 22, color: brandBlue),
                  ),
                  if (editingValue.text.trim().isEmpty)
                    Semantics(
                      button: true,
                      label: _recordingVoice
                          ? 'Recording voice message'
                          : 'Hold to record a voice message',
                      child: GestureDetector(
                      onLongPressStart: (_) => _startVoiceRecording(),
                      onLongPressEnd: (_) => _stopAndSendVoice(),
                      onLongPressCancel: () => _stopAndSendVoice(discard: true),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 160),
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: _recordingVoice
                              ? const Color(0xFFE5484D)
                              : brandBlue.withValues(alpha: .10),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          _recordingVoice ? Icons.mic : Icons.mic_none_rounded,
                          color: _recordingVoice ? Colors.white : brandBlue,
                        ),
                      ),
                    ),
                    ),
                  const SizedBox(width: 3),
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: likedinSurfaceRaised(Theme.of(context).brightness),
                        borderRadius: BorderRadius.circular(26),
                      ),
                      child: TextField(
                        focusNode: _composerFocus,
                        controller: controller,
                        minLines: 1,
                        maxLines: 5,
                        textCapitalization: TextCapitalization.sentences,
                        contentInsertionConfiguration: ContentInsertionConfiguration(
                          allowedMimeTypes: const [
                            'image/gif', 'image/png', 'image/jpeg', 'image/jpg', 'image/webp',
                            'image/bmp', 'image/tiff',
                          ],
                          onContentInserted: _handleKeyboardContent,
                        ),
                        inputFormatters: const [CodePointLengthLimitingTextInputFormatter(10000)],
                        buildCounter: (context, {required currentLength, required isFocused, maxLength}) {
                          final count = likedinMessageCodePointLength(controller.text);
                          if (count < 9500) return null;
                          return Text('$count / 10000', style: const TextStyle(fontSize: 11));
                        },
                        onChanged: (value) {
                          if (!_clearingComposerForSend &&
                              _pendingTextDraftValue != null &&
                              value.trim() != _pendingTextDraftValue) {
                            _pendingTextDraftId = null;
                            _pendingTextDraftValue = null;
                          }
                          _typingPublishTimer?.cancel();
                          typingTimer?.cancel();
                          if (value.trim().isNotEmpty) {
                            _typingPublishTimer = Timer(const Duration(milliseconds: 350), () {
                              if (mounted) messaging.sendTyping(true).catchError((_) {});
                            });
                            typingTimer = Timer(
                              const Duration(seconds: 2),
                              () => messaging.sendTyping(false).catchError((_) {}),
                            );
                          } else {
                            unawaited(messaging.sendTyping(false).catchError((_) {}));
                          }
                        },
                        onSubmitted: (_) => send(),
                        decoration: InputDecoration(
                          hintText: _recordingVoice
                              ? 'Recording (${_voiceRecordSeconds}s)… release to send'
                              : _editingMessageId != null
                                  ? 'Edit message…'
                                  : _replyingTo != null
                                      ? 'Write a reply…'
                                      : 'Message…',
                          filled: false,
                          border: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          focusedBorder: InputBorder.none,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    tooltip: _editingMessageId != null ? 'Save edit' : 'Send message',
                    onPressed: saving || peerId == null || editingValue.text.trim().isEmpty
                        ? null
                        : () {
                            HapticFeedback.lightImpact();
                            send();
                          },
                    style: IconButton.styleFrom(
                      backgroundColor: brandBlue,
                      foregroundColor: Colors.white,
                      disabledBackgroundColor: Theme.of(context).disabledColor.withValues(alpha: .25),
                    ),
                    icon: saving
                        ? const SizedBox(
                            width: 19,
                            height: 19,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                          )
                        : const Icon(Icons.arrow_upward_rounded),
                  ),
                ],
              ),
              ),
            ),
          ),
          ],
        ),
      );
  }
}

class _SwipeReplyGesture extends StatefulWidget {
  const _SwipeReplyGesture({super.key, required this.child, required this.onReply});
  final Widget child;
  final VoidCallback onReply;

  @override
  State<_SwipeReplyGesture> createState() => _SwipeReplyGestureState();
}

class _SwipeReplyGestureState extends State<_SwipeReplyGesture> {
  double _drag = 0;

  @override
  Widget build(BuildContext context) {
    final offset = _drag.clamp(-58.0, 58.0);
    return Stack(
      alignment: Alignment.center,
      children: [
        Positioned.fill(
          child: Align(
            alignment: _drag >= 0 ? Alignment.centerLeft : Alignment.centerRight,
            child: Opacity(
              opacity: (offset.abs() / 58).clamp(0.0, 1.0),
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: Icon(Icons.reply_rounded, color: brandBlue, size: 20),
              ),
            ),
          ),
        ),
        GestureDetector(
          behavior: HitTestBehavior.translucent,
          onHorizontalDragUpdate: (details) =>
              setState(() => _drag = (_drag + details.delta.dx).clamp(-58.0, 58.0)),
          onHorizontalDragEnd: (details) {
            final shouldReply = _drag.abs() > 42 || (details.primaryVelocity?.abs() ?? 0) > 260;
            setState(() => _drag = 0);
            if (shouldReply) widget.onReply();
          },
          child: AnimatedContainer(
            duration: _drag == 0 ? const Duration(milliseconds: 180) : Duration.zero,
            curve: Curves.easeOutCubic,
            transform: Matrix4.translationValues(offset, 0, 0),
            child: widget.child,
          ),
        ),
      ],
    );
  }
}

class _TypingBubble extends StatefulWidget {
  const _TypingBubble();
  @override
  State<_TypingBubble> createState() => _TypingBubbleState();
}

class _TypingBubbleState extends State<_TypingBubble> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 850),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Align(
        alignment: Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 5),
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            border: Border.all(color: Theme.of(context).dividerColor),
            borderRadius: BorderRadius.circular(18),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Typing ', style: TextStyle(fontSize: 12)),
              ...List.generate(
                3,
                (i) => AnimatedBuilder(
                  animation: _controller,
                  builder: (_, __) {
                    final v = (_controller.value * 3 - i).clamp(0.0, 1.0);
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 2),
                      child: Transform.translate(
                        offset: Offset(0, -4 * v),
                        child: const CircleAvatar(radius: 3, backgroundColor: brandBlue),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      );
}

class _IncomingCallDialog extends StatefulWidget {
  const _IncomingCallDialog({
    required this.callId,
    required this.callerId,
    required this.offer,
    required this.withVideo,
    this.autoAccept = false,
  });
  final String callId, callerId;
  final Map<String, dynamic> offer;
  final bool withVideo;
  final bool autoAccept;
  @override
  State<_IncomingCallDialog> createState() => _IncomingCallDialogState();
}

class _IncomingCallDialogState extends State<_IncomingCallDialog>
    with SingleTickerProviderStateMixin {
  late final LikedinCallService call;
  final ProximityCallController proximity = ProximityCallController();
  StreamSubscription<String>? subscription;
  bool accepting = false, accepted = false, connected = false, finished = false, _checkingRemoteStatus = false;
  bool _handlingBack = false, _dialogClosing = false;
  String status = 'Incoming call';
  Timer? _incomingStatusTimer;
  Timer? _durationTicker;
  late final AnimationController _ringPulse;
  Stopwatch? _stopwatch;
  int _elapsedSeconds = 0;

  String get _durationLabel =>
      '${(_elapsedSeconds ~/ 60).toString().padLeft(2, '0')}:${(_elapsedSeconds % 60).toString().padLeft(2, '0')}';

  @override
  void initState() {
    super.initState();
    _ringPulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1250),
    )..repeat(reverse: true);
    call = LikedinCallService(Supabase.instance.client);
    if (!widget.autoAccept) CallAlertController.startIncoming();
    _incomingStatusTimer = Timer.periodic(
      const Duration(seconds: 2),
      (_) => _checkIncomingStatus(),
    );
    if (widget.autoAccept) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) unawaited(_accept());
      });
    }
  }

  void _closeDialog() {
    if (!mounted || _dialogClosing) return;
    _dialogClosing = true;
    if (Navigator.of(context).canPop()) Navigator.of(context).pop();
  }

  Future<void> _handleSystemBack() async {
    if (_handlingBack || accepting) return;
    _handlingBack = true;
    try {
      if (!finished) {
        if (accepted) {
          await call.end();
        } else {
          await _reject();
          return;
        }
      }
      _closeDialog();
    } finally {
      _handlingBack = false;
    }
  }

  Future<void> _checkIncomingStatus() async {
    if (!mounted || accepting || accepted || finished || _checkingRemoteStatus) return;
    _checkingRemoteStatus = true;
    try {
      final row = await Supabase.instance.client
          .from('likedin_calls')
          .select('status')
          .eq('id', widget.callId)
          .maybeSingle();
      final remoteStatus = row?['status']?.toString();
      if (remoteStatus != null &&
          remoteStatus != 'ringing' &&
          mounted &&
          !accepting &&
          !accepted) {
        await CallAlertController.stop();
        setState(() {
          status = remoteStatus == 'missed' ? 'Missed call' : remoteStatus == 'failed' ? 'Call failed' : 'Call ended';
          finished = true;
        });
        Future<void>.delayed(const Duration(milliseconds: 900), () {
          _closeDialog();
        });
      }
    } catch (_) {
    } finally {
      _checkingRemoteStatus = false;
    }
  }

  Future<void> _accept() async {
    if (accepting || accepted || finished) return;
    await CallAlertController.stop();
    setState(() {
      accepting = true;
      status = 'Connecting…';
    });
    try {
      await call.initialize();
      subscription = call.changes.listen((value) {
        if (!mounted) return;
        if (value == 'connected' && !connected) {
          connected = true;
          _stopwatch = Stopwatch()..start();
          _durationTicker?.cancel();
          _durationTicker = Timer.periodic(const Duration(seconds: 1), (_) {
            if (mounted && _stopwatch != null) {
              setState(() => _elapsedSeconds = _stopwatch!.elapsed.inSeconds);
            }
          });
        }
        setState(() {
          status = value == 'disconnected'
              ? 'Reconnecting…'
              : value == 'connected'
                  ? _durationLabel
                  : value;
          if (value == 'ended' ||
              value == 'missed' ||
              value == 'rejected' ||
              value.startsWith('failed') ||
              value.startsWith('error:')) {
            finished = true;
          }
        });
        if (finished) {
          Future<void>.delayed(const Duration(milliseconds: 650), () {
            _closeDialog();
          });
        }
      });
      await call.accept(widget.callId, widget.callerId, widget.offer, withVideo: widget.withVideo);
      await proximity.update(
        active: !widget.withVideo,
        enabled: !widget.withVideo && !call.speaker,
      );
      if (mounted) {
        setState(() {
          accepted = true;
          accepting = false;
          status = connected ? _durationLabel : 'Connecting…';
        });
      }
    } catch (e) {
      // Renderer initialization can fail before CallService.accept() runs its
      // own rejection cleanup. Make the server state terminal in either case;
      // a failed answer must never leave the other handset ringing forever.
      try {
        await Supabase.instance.client.rpc('likedin_update_call_status', params: {
          'p_call_id': widget.callId,
          'p_new_status': 'rejected',
        });
      } catch (_) {
        // If accept() already committed and then failed, CallService has
        // already changed the row to ended; rejection is no longer legal.
      }
      try {
        await Supabase.instance.client.from('likedin_call_signals').insert({
          'call_id': widget.callId,
          'sender_id': Supabase.instance.client.auth.currentUser!.id,
          'kind': 'reject',
          'payload': <String, dynamic>{},
        });
      } catch (_) {}
      try { await LikedinNotificationService.instance.cancelIncomingCall(widget.callId); } catch (_) {}
      if (mounted) {
        setState(() {
          accepting = false;
          finished = true;
          status = 'Could not answer: $e';
        });
        Future<void>.delayed(const Duration(milliseconds: 1500), () {
          if (mounted) _closeDialog();
        });
      }
    }
  }

  Future<void> _toggleSpeaker() async {
    await call.toggleSpeaker();
    await proximity.update(
      active: accepted && !widget.withVideo,
      enabled: accepted && !widget.withVideo && !call.speaker,
    );
    if (mounted) setState(() {});
  }

  Future<void> _reject() async {
    await CallAlertController.stop();
    try {
      await Supabase.instance.client.rpc('likedin_update_call_status', params: {
        'p_call_id': widget.callId,
        'p_new_status': 'rejected',
      });
    } catch (e) {
      debugPrint('Could not commit incoming call rejection: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not decline the call. Please try again.')),
        );
      }
      return;
    }
    try {
      await LikedinNotificationService.instance.cancelIncomingCall(widget.callId);
    } catch (e) {
      debugPrint('Call declined, but local incoming-call notification could not be cancelled: $e');
    }
    try {
      await Supabase.instance.client.from('likedin_call_signals').insert({
        'call_id': widget.callId,
        'sender_id': Supabase.instance.client.auth.currentUser!.id,
        'kind': 'reject',
        'payload': <String, dynamic>{},
      });
    } catch (e) {
      // The server-side state is authoritative; missing signaling must not
      // turn a declined call into a missed call.
      debugPrint('Call was declined, but reject signaling failed: $e');
    }
    if (mounted) {
      setState(() {
        finished = true;
        status = 'Call declined';
      });
      _closeDialog();
    }
  }

  @override
  void dispose() {
    _incomingStatusTimer?.cancel();
    _durationTicker?.cancel();
    _ringPulse.dispose();
    _stopwatch?.stop();
    CallAlertController.stop();
    proximity.dispose();
    subscription?.cancel();
    call.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const background = Color(0xFF071426);
    const accent = Color(0xFF58D7F5);
    final isActive = accepted && !finished;
    final headline = widget.withVideo ? 'Video call' : 'Audio call';
    return PopScope<Object?>(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) unawaited(_handleSystemBack());
      },
      child: Dialog.fullscreen(
        backgroundColor: background,
        child: Stack(
          children: [
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF102D4A), Color(0xFF09182B), Color(0xFF040B15)],
                ),
              ),
              child: SizedBox.expand(),
            ),
            Positioned(
              top: -100,
              right: -90,
              child: IgnorePointer(
                child: Container(
                  width: 290,
                  height: 290,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [accent.withValues(alpha: .20), accent.withValues(alpha: 0)],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: -150,
              left: -110,
              child: IgnorePointer(
                child: Container(
                  width: 330,
                  height: 330,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [const Color(0xFF795BFF).withValues(alpha: .17), Colors.transparent],
                    ),
                  ),
                ),
              ),
            ),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 18, 20, 22),
                child: Column(
                  children: [
                    GlassPanel(
                      tint: const Color(0xB9142B43),
                      blur: 16,
                      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
                      radius: BorderRadius.circular(24),
                      child: Row(
                        children: [
                          const Icon(Icons.graphic_eq_rounded, color: accent, size: 19),
                          const SizedBox(width: 10),
                          const Expanded(
                            child: Text(
                              'LIKEDIN CALL',
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 11,
                                letterSpacing: 2.1,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                          Icon(
                            widget.withVideo ? Icons.videocam_rounded : Icons.call_rounded,
                            color: accent,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 18),
                    Expanded(
                      child: isActive && widget.withVideo
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(30),
                              child: Stack(
                                fit: StackFit.expand,
                                children: [
                                  RTCVideoView(
                                    call.remoteRenderer,
                                    objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                                  ),
                                  Positioned(
                                    right: 14,
                                    top: 14,
                                    width: 106,
                                    height: 146,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: const Color(0xCC0A1728),
                                          border: Border.all(color: Colors.white24),
                                          borderRadius: BorderRadius.circular(20),
                                        ),
                                        child: RTCVideoView(
                                          call.localRenderer,
                                          mirror: true,
                                          objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    left: 14,
                                    top: 14,
                                    child: GlassPanel(
                                      tint: const Color(0xC9102033),
                                      blur: 12,
                                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                      child: Text(
                                        connected ? _durationLabel : status,
                                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : Center(
                              child: SingleChildScrollView(
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    _CallHaloAvatar(
                                      icon: widget.withVideo ? Icons.videocam_rounded : Icons.person_rounded,
                                      size: 142,
                                    ),
                                    const SizedBox(height: 24),
                                    Text(
                                      isActive ? 'Connected' : finished ? headline : 'Incoming ${widget.withVideo ? 'video' : 'audio'} call',
                                      textAlign: TextAlign.center,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 27,
                                        fontWeight: FontWeight.w800,
                                        letterSpacing: -.5,
                                      ),
                                    ),
                                    const SizedBox(height: 9),
                                    const Text(
                                      'Likedin contact',
                                      style: TextStyle(color: Color(0xFFB8C9DC), fontSize: 15),
                                    ),
                                    const SizedBox(height: 18),
                                    GlassPanel(
                                      tint: const Color(0xA8172D45),
                                      blur: 14,
                                      padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 10),
                                      radius: BorderRadius.circular(24),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          AnimatedBuilder(
                                            animation: _ringPulse,
                                            builder: (context, child) => Container(
                                              width: 8,
                                              height: 8,
                                              decoration: BoxDecoration(
                                                color: isActive ? const Color(0xFF5DE0A0) : accent,
                                                shape: BoxShape.circle,
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: accent.withValues(alpha: .18 + .28 * _ringPulse.value),
                                                    blurRadius: 8 + 6 * _ringPulse.value,
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 9),
                                          Text(
                                            (accepted || finished)
                                                ? (connected && !finished && status != 'Reconnecting…' ? _durationLabel : status)
                                                : 'Your friend is calling',
                                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                    ),
                    const SizedBox(height: 18),
                    GlassPanel(
                      tint: const Color(0xB9162B42),
                      blur: 18,
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 17),
                      radius: BorderRadius.circular(30),
                      child: !accepted && !finished
                          ? Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                _incomingCallAction(
                                  icon: Icons.call_end_rounded,
                                  label: 'Decline',
                                  color: const Color(0xFFE5485D),
                                  onTap: accepting ? null : _reject,
                                ),
                                _incomingCallAction(
                                  icon: Icons.call_rounded,
                                  label: accepting ? 'Connecting' : 'Answer',
                                  color: const Color(0xFF20B879),
                                  onTap: (accepting || finished) ? null : _accept,
                                ),
                              ],
                            )
                          : isActive
                              ? Wrap(
                                  alignment: WrapAlignment.center,
                                  crossAxisAlignment: WrapCrossAlignment.center,
                                  spacing: 12,
                                  runSpacing: 14,
                                  children: [
                                    _activeCallControl(
                                      call.muted ? Icons.mic_off_rounded : Icons.mic_rounded,
                                      call.muted ? 'Unmute' : 'Mute',
                                      call.muted,
                                      () async {
                                        await call.toggleMute();
                                        if (mounted) setState(() {});
                                      },
                                    ),
                                    _activeCallControl(
                                      call.speaker ? Icons.volume_up_rounded : Icons.hearing_rounded,
                                      'Speaker',
                                      call.speaker,
                                      _toggleSpeaker,
                                    ),
                                    if (widget.withVideo)
                                      _activeCallControl(
                                        call.camera ? Icons.videocam_rounded : Icons.videocam_off_rounded,
                                        'Camera',
                                        !call.camera,
                                        () async {
                                          await call.toggleCamera();
                                          if (mounted) setState(() {});
                                        },
                                      ),
                                    if (widget.withVideo)
                                      _activeCallControl(Icons.cameraswitch_rounded, 'Flip', false, call.switchCamera),
                                    _incomingCallAction(
                                      icon: Icons.call_end_rounded,
                                      label: 'End call',
                                      color: const Color(0xFFE5485D),
                                      onTap: () async {
                                        await call.end();
                                        _closeDialog();
                                      },
                                    ),
                                  ],
                                )
                              : SizedBox(
                                  width: double.infinity,
                                  child: FilledButton.tonal(
                                    onPressed: _closeDialog,
                                    child: const Text('Close'),
                                  ),
                                ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Clear calls. Closer connections.',
                      style: TextStyle(color: Colors.white38, fontSize: 11, letterSpacing: .4),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Widget _incomingCallAction({
  required IconData icon,
  required String label,
  required Color color,
  required VoidCallback? onTap,
}) =>
    Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 76,
          height: 76,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: color.withValues(alpha: .30),
                blurRadius: 23,
                spreadRadius: 1,
              ),
            ],
          ),
          child: FloatingActionButton(
            heroTag: 'call-action-$label',
            elevation: 4,
            highlightElevation: 8,
            backgroundColor: color,
            foregroundColor: Colors.white,
            onPressed: onTap,
            child: Icon(icon, size: 31),
          ),
        ),
        const SizedBox(height: 11),
        Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
      ],
    );

Widget _activeCallControl(
  IconData icon,
  String label,
  bool active,
  VoidCallback onPressed,
) =>
    Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: (active ? const Color(0xFF53D7F4) : const Color(0xFF527FA4))
                    .withValues(alpha: active ? .25 : .10),
                blurRadius: active ? 20 : 12,
              ),
            ],
          ),
          child: IconButton.filled(
            onPressed: onPressed,
            style: IconButton.styleFrom(
              backgroundColor: active ? const Color(0xFF187EA5) : const Color(0xB92A4560),
              foregroundColor: Colors.white,
              fixedSize: const Size(58, 58),
              side: BorderSide(color: Colors.white.withValues(alpha: .16)),
            ),
            icon: Icon(icon),
          ),
        ),
        const SizedBox(height: 5),
        Text(label, style: const TextStyle(color: Color(0xFFB8C9D9), fontSize: 11)),
      ],
    );

class CallsPage extends StatefulWidget {
  const CallsPage({super.key});
  @override
  State<CallsPage> createState() => _CallsPageState();
}

class _CallsPageState extends State<CallsPage> {
  Future<List<Map<String, dynamic>>>? _history;
  RealtimeChannel? _channel;
  String _filter = 'All';

  @override
  void initState() {
    super.initState();
    _load();
    _subscribe();
  }

  void _load() {
    _history = _fetch();
  }

  Future<List<Map<String, dynamic>>> _fetch() async {
    final uid = Supabase.instance.client.auth.currentUser!.id;
    final rows = await Supabase.instance.client
        .from('likedin_calls')
        .select()
        .or('caller_id.eq.$uid,callee_id.eq.$uid')
        .order('created_at', ascending: false)
        .limit(100);
    return rows.map((e) => Map<String, dynamic>.from(e)).toList();
  }

  void _subscribe() {
    final client = Supabase.instance.client;
    final uid = client.auth.currentUser?.id;
    if (uid == null) return;
    _channel = client
        .channel('likedin-call-history-$uid')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'likedin_calls',
          callback: (_) {
            if (mounted) setState(_load);
          },
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'likedin_calls',
          callback: (_) {
            if (mounted) setState(_load);
          },
        )
      ..subscribe();
  }

  @override
  void dispose() {
    final c = _channel;
    if (c != null) Supabase.instance.client.removeChannel(c);
    super.dispose();
  }

  String _label(Map<String, dynamic> row, String uid) {
    final outgoing = row['caller_id'] == uid;
    final status = row['status']?.toString() ?? 'ended';
    if (status == 'missed') return outgoing ? 'No answer' : 'Missed call';
    if (status == 'rejected') return outgoing ? 'Declined' : 'You declined';
    if (status == 'failed') return 'Call failed';
    if (status == 'ringing') return 'Ringing';
    if (status == 'accepted' || row['answered_at'] != null) return 'Completed';
    return status == 'ended' ? 'Ended' : status;
  }

  IconData _icon(Map<String, dynamic> row, String uid) {
    if (row['status'] == 'missed' && row['callee_id'] == uid) return Icons.call_missed;
    if (row['caller_id'] == uid) return Icons.call_made;
    return Icons.call_received;
  }

  bool _matchesFilter(Map<String, dynamic> row) {
    switch (_filter) {
      case 'Missed':
        return row['status'] == 'missed';
      case 'Video':
        return row['call_type'] == 'video';
      case 'Audio':
        return row['call_type'] != 'video';
      default:
        return true;
    }
  }

  String _dateLabel(Map<String, dynamic> row) {
    final created = DateTime.tryParse(row['created_at']?.toString() ?? '')?.toLocal();
    if (created == null) return 'Date unavailable';
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final day = DateTime(created.year, created.month, created.day);
    final dayText = day == today
        ? 'Today'
        : day == today.subtract(const Duration(days: 1))
            ? 'Yesterday'
            : '${created.day.toString().padLeft(2, '0')}/${created.month.toString().padLeft(2, '0')}/${created.year}';
    final timeText = '${created.hour.toString().padLeft(2, '0')}:${created.minute.toString().padLeft(2, '0')}';
    return '$dayText · $timeText';
  }

  Widget _filterPill(String value, {required bool dark, required Color foreground}) {
    final selected = _filter == value;
    final background = selected
        ? (dark ? const Color(0xFF8DB8FF) : const Color(0xFFDCEBFF))
        : (dark ? const Color(0xFF20364E) : const Color(0xFFEAF0FA));
    final label = selected
        ? (dark ? const Color(0xFF061725) : const Color(0xFF174F9A))
        : foreground.withValues(alpha: .88);
    final border = selected
        ? (dark ? const Color(0xFF8DB8FF) : const Color(0xFF9BBCEB))
        : (dark ? const Color(0xFF38506A) : const Color(0xFFD6E0EF));

    return Semantics(
      button: true,
      selected: selected,
      label: '$value calls filter',
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(30),
          onTap: () => setState(() => _filter = value),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 160),
            curve: Curves.easeOut,
            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 9),
            decoration: BoxDecoration(
              color: background,
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: border),
            ),
            child: Text(
              value,
              style: TextStyle(color: label, fontSize: 12, fontWeight: FontWeight.w800),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final uid = Supabase.instance.client.auth.currentUser!.id;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final foreground = dark ? Colors.white : const Color(0xFF172B4D);
    final secondary = dark ? Colors.white70 : const Color(0xFF61708A);
    final panelTint = dark ? const Color(0xC5162D45) : const Color(0xE8FFFFFF);
    final accent = dark ? const Color(0xFF8DB8FF) : brandBlue;

    return RefreshIndicator(
        color: accent,
        backgroundColor: dark ? const Color(0xFF18324D) : Colors.white,
        onRefresh: () async {
          setState(_load);
          await _history;
        },
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(0, 8, 0, 0),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      'Calls',
                      style: TextStyle(
                        color: foreground,
                        fontSize: 34,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -1.1,
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: 'Refresh call history',
                    onPressed: () => setState(_load),
                    icon: Icon(Icons.refresh_rounded, color: secondary),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: _callStartTile(
                    context,
                    icon: Icons.call_rounded,
                    title: 'Voice call',
                    subtitle: 'Audio only',
                    accent: const Color(0xFF32B98D),
                    onTap: () => _showCallSetup(context, video: false),
                  ),
                ),
                const SizedBox(width: 11),
                Expanded(
                  child: _callStartTile(
                    context,
                    icon: Icons.videocam_rounded,
                    title: 'Video call',
                    subtitle: 'Face to face',
                    accent: const Color(0xFF3B9FD0),
                    onTap: () => _showCallSetup(context, video: true),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 26),
            Row(
              children: [
                Expanded(
                  child: Text(
                    'Recent',
                    style: TextStyle(color: foreground, fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: -.4),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: ['All', 'Missed', 'Video', 'Audio']
                  .map((value) => _filterPill(value, dark: dark, foreground: foreground))
                  .toList(),
            ),
            const SizedBox(height: 14),
            FutureBuilder<List<Map<String, dynamic>>>(
              future: _history,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Padding(
                    padding: const EdgeInsets.all(34),
                    child: Center(child: CircularProgressIndicator(color: accent)),
                  );
                }
                if (snapshot.hasError) {
                  return GlassPanel(
                    tint: panelTint,
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        Icon(Icons.cloud_off_rounded, color: dark ? const Color(0xFFFFB4AB) : const Color(0xFFB5473A), size: 30),
                        const SizedBox(height: 9),
                        Text('Call history unavailable', style: TextStyle(color: foreground, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 4),
                        Text('Pull down to try again.', style: TextStyle(color: secondary, fontSize: 12)),
                      ],
                    ),
                  );
                }
                final allRows = snapshot.data ?? const <Map<String, dynamic>>[];
                final rows = allRows.where(_matchesFilter).toList();
                if (allRows.isEmpty) {
                  return GlassPanel(
                    tint: panelTint,
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                    child: Column(
                      children: [
                        Icon(Icons.history_rounded, color: accent, size: 42),
                        const SizedBox(height: 12),
                        Text('No calls yet', style: TextStyle(color: foreground, fontWeight: FontWeight.w800)),
                        const SizedBox(height: 5),
                        Text(
                          'Your recent audio and video calls will appear here.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: secondary, fontSize: 12),
                        ),
                      ],
                    ),
                  );
                }
                if (rows.isEmpty) {
                  return GlassPanel(
                    tint: panelTint,
                    padding: const EdgeInsets.all(22),
                    child: Column(
                      children: [
                        Icon(Icons.filter_list_off_rounded, color: accent, size: 34),
                        const SizedBox(height: 9),
                        Text('Nothing in this filter', style: TextStyle(color: foreground, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 4),
                        Text('Try another call type.', style: TextStyle(color: secondary, fontSize: 12)),
                      ],
                    ),
                  );
                }
                return Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(bottom: 9, left: 3, right: 3),
                      child: Row(
                        children: [
                          Text(
                            '${rows.length} ${rows.length == 1 ? 'call' : 'calls'}',
                            style: TextStyle(color: secondary, fontSize: 12, fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                    ),
                    ...rows.map((row) {
                      final missed = row['status'] == 'missed';
                      final outgoing = row['caller_id'] == uid;
                      final isVideo = row['call_type'] == 'video';
                      final peerId = outgoing ? row['callee_id']?.toString() : row['caller_id']?.toString();
                      final answered = DateTime.tryParse(row['answered_at']?.toString() ?? '');
                      final ended = DateTime.tryParse(row['ended_at']?.toString() ?? '');
                      final duration = answered == null || ended == null
                          ? null
                          : ended.difference(answered).inSeconds.clamp(0, 86400);
                      final statusColor = missed
                          ? (dark ? const Color(0xFFFF848B) : const Color(0xFFC43D4A))
                          : row['status'] == 'failed'
                              ? (dark ? const Color(0xFFFFB66D) : const Color(0xFFB96B19))
                              : (dark ? const Color(0xFF72DDB7) : const Color(0xFF208B68));
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 9),
                        child: GlassPanel(
                          tint: panelTint,
                          blur: 13,
                          glow: false,
                          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
                          radius: BorderRadius.circular(22),
                          child: Row(
                            children: [
                              Container(
                                width: 46,
                                height: 46,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: statusColor.withValues(alpha: .12),
                                  border: Border.all(color: statusColor.withValues(alpha: .38)),
                                ),
                                child: Icon(
                                  isVideo ? Icons.videocam_rounded : _icon(row, uid),
                                  color: statusColor,
                                  size: 21,
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      '${isVideo ? 'Video' : 'Audio'} · ${_label(row, uid)}',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        color: missed ? statusColor : foreground,
                                        fontWeight: FontWeight.w800,
                                        fontSize: 13,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      '${outgoing ? 'Outgoing' : 'Incoming'}  ·  ${_dateLabel(row)}${duration == null ? '' : '  ·  ${duration ~/ 60}m ${duration % 60}s'}',
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(color: secondary, fontSize: 10.5),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 5),
                              Container(
                                decoration: BoxDecoration(
                                  color: accent.withValues(alpha: dark ? .13 : .09),
                                  shape: BoxShape.circle,
                                  border: Border.all(color: accent.withValues(alpha: .25)),
                                ),
                                child: IconButton(
                                  tooltip: 'Call back',
                                  visualDensity: VisualDensity.compact,
                                  onPressed: peerId == null || peerId.isEmpty
                                      ? null
                                      : () => _showCallSetup(context, video: isVideo, recipientId: peerId),
                                  icon: Icon(Icons.call_rounded, color: accent, size: 19),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    }),
                  ],
                );
              },
            ),
          ],
        ),
    );
  }

  Widget _callStartTile(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required Color accent,
    required VoidCallback onTap,
  }) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final foreground = dark ? Colors.white : const Color(0xFF172B4D);
    final secondary = dark ? Colors.white70 : const Color(0xFF61708A);
    return Semantics(
      button: true,
      label: '$title, $subtitle',
      child: Material(
        color: accent.withValues(alpha: dark ? .16 : .10),
        borderRadius: BorderRadius.circular(22),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(icon, color: accent, size: 26),
                const SizedBox(height: 18),
                Text(title, style: TextStyle(color: foreground, fontSize: 16, fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text(subtitle, style: TextStyle(color: secondary, fontSize: 13)),
              ],
            ),
          ),
        ),
      ),
    );
  }

}

Future<void> _showCallSetup(BuildContext context, {required bool video, String? recipientId}) async {
  final client = Supabase.instance.client;
  final messenger = ScaffoldMessenger.of(context);
  if (_globalCallDialogActive) {
    messenger.showSnackBar(const SnackBar(content: Text('A call is already active. Finish it before starting another.')));
    return;
  }
  try {
    final peer = recipientId ?? await client.rpc('likedin_get_peer_id') as String?;
    if (peer == null) {
      messenger.showSnackBar(
        const SnackBar(content: Text('Your friend has not registered yet.')),
      );
      return;
    }
    if (!context.mounted) return;
    if (_globalCallDialogActive) return;
    _globalCallDialogActive = true;
    try {
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (_) => _LiveCallDialog(peerId: peer, video: video),
      );
    } finally { _globalCallDialogActive = false; }
  } catch (e) {
    messenger.showSnackBar(SnackBar(content: Text('Could not start call: $e')));
  }
}

class _LiveCallDialog extends StatefulWidget {
  const _LiveCallDialog({required this.peerId, required this.video});
  final String peerId;
  final bool video;
  @override
  State<_LiveCallDialog> createState() => _LiveCallDialogState();
}

class _LiveCallDialogState extends State<_LiveCallDialog> {
  late final LikedinCallService call;
  final ProximityCallController proximity = ProximityCallController();
  StreamSubscription<String>? sub;
  Timer? durationTicker;
  Stopwatch? stopwatch;
  String status = 'Preparing call…';
  bool ready = false, failed = false, connected = false;
  int elapsedSeconds = 0;

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    call = LikedinCallService(Supabase.instance.client);
    try {
      await call.initialize();
      sub = call.changes.listen((v) {
        if (!mounted) return;
        final nowConnected = v == 'connected';
        if (nowConnected && !connected) {
          connected = true;
          stopwatch = Stopwatch()..start();
          durationTicker = Timer.periodic(const Duration(seconds: 1), (_) {
            if (mounted && stopwatch != null) {
              setState(() => elapsedSeconds = stopwatch!.elapsed.inSeconds);
            }
          });
        }
        setState(() {
          status = v;
          if (v.startsWith('failed') || v.startsWith('error:')) failed = true;
        });
        if (v == 'connected') {
          proximity.update(
            active: !widget.video,
            enabled: !widget.video && !call.speaker,
          );
        }
        if (v == 'ended' ||
            v == 'missed' ||
            v == 'rejected' ||
            v.startsWith('failed') ||
            v.startsWith('error:')) {
          Future<void>.delayed(const Duration(milliseconds: 900), () {
            if (mounted && Navigator.of(context).canPop()) Navigator.of(context).pop();
          });
        }
      });
      await call.start(widget.peerId, withVideo: widget.video);
      if (mounted) setState(() => ready = true);
    } catch (e) {
      if (mounted) {
        setState(() {
          status = e.toString();
          failed = true;
        });
      }
    }
  }

  Future<void> _toggleSpeaker() async {
    await call.toggleSpeaker();
    await proximity.update(
      active: connected && !widget.video,
      enabled: connected && !widget.video && !call.speaker,
    );
    if (mounted) setState(() {});
  }

  String get _durationLabel =>
      '${(elapsedSeconds ~/ 60).toString().padLeft(2, '0')}:${(elapsedSeconds % 60).toString().padLeft(2, '0')}';

  String get _statusLabel {
    final v = status.toLowerCase();
    if (v.contains('disconnected')) return 'Reconnecting…';
    if (connected) return _durationLabel;
    if (v.contains('ring')) return 'Ringing…';
    if (v.contains('offer') || v.contains('connecting') || v.contains('preparing') || v.contains('calling')) {
      return 'Calling…';
    }
    if (v.contains('failed')) return 'Call connection failed';
    if (v.contains('closed') || v.contains('ended')) return 'Call ended';
    return 'Connecting…';
  }

  @override
  void dispose() {
    durationTicker?.cancel();
    stopwatch?.stop();
    proximity.dispose();
    sub?.cancel();
    call.close();
    super.dispose();
  }

  bool _handlingBack = false;

  Future<void> _handleSystemBack() async {
    if (_handlingBack) return;
    _handlingBack = true;
    try {
      await call.end();
      if (mounted && Navigator.of(context).canPop()) {
        Navigator.of(context).pop();
      }
    } finally {
      _handlingBack = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final title = connected
        ? 'In ${widget.video ? 'video' : 'audio'} call'
        : (widget.video ? 'Video call' : 'Audio call');
    return PopScope<Object?>(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) unawaited(_handleSystemBack());
      },
      child: Dialog.fullscreen(
        backgroundColor: const Color(0xFF071426),
        child: Stack(
          children: [
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF102D4A), Color(0xFF09182B), Color(0xFF040B15)],
                ),
              ),
              child: SizedBox.expand(),
            ),
            Positioned(
              top: -110,
              right: -100,
              child: IgnorePointer(
                child: Container(
                  width: 310,
                  height: 310,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [const Color(0xFF4ACCF2).withValues(alpha: .20), Colors.transparent],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: -160,
              left: -120,
              child: IgnorePointer(
                child: Container(
                  width: 350,
                  height: 350,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [const Color(0xFF765BFF).withValues(alpha: .16), Colors.transparent],
                    ),
                  ),
                ),
              ),
            ),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 18, 20, 22),
                child: Column(
                  children: [
                    GlassPanel(
                      tint: const Color(0xB9142B43),
                      blur: 16,
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                      radius: BorderRadius.circular(24),
                      child: Row(
                        children: [
                          IconButton(
                            tooltip: 'End call',
                            onPressed: () async {
                              await call.end();
                              if (context.mounted) Navigator.pop(context);
                            },
                            icon: const Icon(Icons.keyboard_arrow_down_rounded, color: Colors.white, size: 27),
                          ),
                          const Spacer(),
                          Text(
                            widget.video ? 'VIDEO SESSION' : 'AUDIO SESSION',
                            style: const TextStyle(
                              color: Colors.white70,
                              fontSize: 10,
                              letterSpacing: 2,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const Spacer(),
                          Container(
                            width: 38,
                            height: 38,
                            decoration: BoxDecoration(
                              color: const Color(0xFF55D8F4).withValues(alpha: .12),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              widget.video ? Icons.videocam_rounded : Icons.call_rounded,
                              color: const Color(0xFF64DDF5),
                              size: 19,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 18),
                    Expanded(
                      child: widget.video && connected
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(30),
                              child: Stack(
                                fit: StackFit.expand,
                                children: [
                                  RTCVideoView(
                                    call.remoteRenderer,
                                    objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                                  ),
                                  Positioned(
                                    right: 14,
                                    top: 14,
                                    width: 108,
                                    height: 148,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: const Color(0xCC0A1728),
                                          border: Border.all(color: Colors.white24),
                                          borderRadius: BorderRadius.circular(20),
                                        ),
                                        child: RTCVideoView(
                                          call.localRenderer,
                                          mirror: true,
                                          objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    left: 14,
                                    top: 14,
                                    child: GlassPanel(
                                      tint: const Color(0xC9102033),
                                      blur: 12,
                                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Container(
                                            width: 7,
                                            height: 7,
                                            decoration: const BoxDecoration(
                                              color: Color(0xFF67E5A3),
                                              shape: BoxShape.circle,
                                            ),
                                          ),
                                          const SizedBox(width: 8),
                                          Text(
                                            _statusLabel,
                                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : Center(
                              child: SingleChildScrollView(
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const _CallHaloAvatar(icon: Icons.person_rounded, size: 146),
                                    const SizedBox(height: 25),
                                    const Text(
                                      'Likedin contact',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 26,
                                        fontWeight: FontWeight.w800,
                                        letterSpacing: -.6,
                                      ),
                                    ),
                                    const SizedBox(height: 9),
                                    Text(
                                      title,
                                      style: const TextStyle(color: Color(0xFFD6E2EF), fontSize: 15),
                                    ),
                                    const SizedBox(height: 17),
                                    GlassPanel(
                                      tint: const Color(0xA8172D45),
                                      blur: 14,
                                      padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 10),
                                      radius: BorderRadius.circular(24),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Container(
                                            width: 8,
                                            height: 8,
                                            decoration: BoxDecoration(
                                              color: failed
                                                  ? const Color(0xFFFF7C83)
                                                  : connected
                                                      ? const Color(0xFF65E6A3)
                                                      : const Color(0xFF65DFF5),
                                              shape: BoxShape.circle,
                                            ),
                                          ),
                                          const SizedBox(width: 9),
                                          Text(
                                            _statusLabel,
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 13,
                                              fontWeight: FontWeight.w700,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    if (failed)
                                      Padding(
                                        padding: const EdgeInsets.only(top: 14),
                                        child: Text(
                                          status,
                                          textAlign: TextAlign.center,
                                          style: const TextStyle(color: Color(0xFFFFB4AB), fontSize: 12),
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                            ),
                    ),
                    const SizedBox(height: 18),
                    GlassPanel(
                      tint: const Color(0xB9162B42),
                      blur: 18,
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                      radius: BorderRadius.circular(30),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Wrap(
                            alignment: WrapAlignment.center,
                            crossAxisAlignment: WrapCrossAlignment.center,
                            spacing: 13,
                            runSpacing: 12,
                            children: [
                              _callControl(
                                call.muted ? Icons.mic_off_rounded : Icons.mic_rounded,
                                call.muted ? 'Unmute' : 'Mute',
                                ready
                                    ? () async {
                                        await call.toggleMute();
                                        if (mounted) setState(() {});
                                      }
                                    : null,
                                active: call.muted,
                              ),
                              _callControl(
                                call.speaker ? Icons.volume_up_rounded : Icons.hearing_rounded,
                                call.speaker ? 'Speaker' : 'Earpiece',
                                ready ? _toggleSpeaker : null,
                                active: call.speaker,
                              ),
                              if (widget.video)
                                _callControl(
                                  call.camera ? Icons.videocam_rounded : Icons.videocam_off_rounded,
                                  'Camera',
                                  ready
                                      ? () async {
                                          await call.toggleCamera();
                                          if (mounted) setState(() {});
                                        }
                                      : null,
                                  active: !call.camera,
                                ),
                              if (widget.video)
                                _callControl(Icons.cameraswitch_rounded, 'Flip', ready ? call.switchCamera : null),
                            ],
                          ),
                          const SizedBox(height: 17),
                          SizedBox(
                            width: 190,
                            height: 56,
                            child: FilledButton.icon(
                              onPressed: () async {
                                await call.end();
                                if (context.mounted) Navigator.pop(context);
                              },
                              style: FilledButton.styleFrom(
                                backgroundColor: const Color(0xFFE5485D),
                                foregroundColor: Colors.white,
                                elevation: 8,
                                shadowColor: const Color(0xFFE5485D).withValues(alpha: .35),
                                shape: const StadiumBorder(),
                              ),
                              icon: const Icon(Icons.call_end_rounded),
                              label: Text(
                                failed ? 'Close' : 'End call',
                                style: const TextStyle(fontWeight: FontWeight.w800),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Clear calls. Closer connections.',
                      style: TextStyle(color: Colors.white38, fontSize: 11, letterSpacing: .4),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _callControl(
    IconData icon,
    String label,
    VoidCallback? action, {
    bool active = false,
  }) =>
      SizedBox(
        width: 72,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: (active ? const Color(0xFF46D7F2) : const Color(0xFF426C91))
                        .withValues(alpha: active ? .24 : .10),
                    blurRadius: active ? 20 : 12,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: IconButton.filled(
                onPressed: action,
                style: IconButton.styleFrom(
                  backgroundColor: active
                      ? const Color(0xFF187EA5)
                      : const Color(0xB92A4560),
                  foregroundColor: Colors.white,
                  disabledForegroundColor: Colors.white30,
                  fixedSize: const Size(58, 58),
                  side: BorderSide(color: Colors.white.withValues(alpha: .16)),
                ),
                icon: Icon(icon),
              ),
            ),
            const SizedBox(height: 6),
            Text(label, style: const TextStyle(color: Color(0xFFB8C9D9), fontSize: 10)),
          ],
        ),
      );
}

class FilesPage extends StatefulWidget {
  const FilesPage({required this.store, required this.isActive, super.key});
  final AttachmentVaultStore store;
  final bool isActive;
  @override
  State<FilesPage> createState() => _FilesPageState();
}

class _FilesPageState extends State<FilesPage> {
  late Future<List<LocalAttachment>> files;
  late Future<List<Map<String, dynamic>>> sharedFiles;
  bool importing = false;

  @override
  void initState() {
    super.initState();
    refresh();
  }

  @override
  void didUpdateWidget(covariant FilesPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isActive && !oldWidget.isActive) {
      setState(refresh);
    }
  }

  void refresh() {
    files = widget.store.list();
    sharedFiles = _loadSharedFiles();
  }

  Future<List<Map<String, dynamic>>> _loadSharedFiles() async {
    final client = Supabase.instance.client;
    final uid = client.auth.currentUser?.id;
    if (uid == null) return [];
    final hiddenIds = <String>{};
    int? clearedBeforeMs;
    try {
      final peer = await RealtimeMessagingService(client).getPeerId();
      if (peer != null) {
        final rawState = await const FlutterSecureStorage().read(
          key: 'likedin_local_chat_v1_${uid}_$peer',
        );
        if (rawState != null && rawState.isNotEmpty) {
          final data = Map<String, dynamic>.from(jsonDecode(rawState) as Map);
          hiddenIds.addAll((data['hidden'] as List? ?? const []).map((e) => e.toString()));
          clearedBeforeMs = data['clearedBeforeMs'] as int?;
        }
      }
    } catch (_) {}

    final result = <Map<String, dynamic>>[];
    const pageSize = 100;
    const maxPages = 2;
    DateTime? beforeCreatedAt;
    String? beforeId;
    for (var pageIndex = 0; pageIndex < maxPages; pageIndex++) {
      var query = client
          .from('messages')
          .select()
          .isFilter('deleted_for_everyone_at', null)
          .like('encrypted_payload', '%"__likedin_media_v1":true%');
      if (beforeCreatedAt == null) {
        query = query.or('sender_id.eq.$uid,recipient_id.eq.$uid');
      } else {
        final stamp = beforeCreatedAt.toUtc().toIso8601String();
        query = query.or(
          'and(sender_id.eq.$uid,created_at.lt.$stamp),'
          'and(recipient_id.eq.$uid,created_at.lt.$stamp),'
          'and(sender_id.eq.$uid,created_at.eq.$stamp,id.lt.$beforeId),'
          'and(recipient_id.eq.$uid,created_at.eq.$stamp,id.lt.$beforeId)',
        );
      }
      final rows = await query
          .order('created_at', ascending: false)
          .order('id', ascending: false)
          .limit(pageSize);
      if (rows.isEmpty) break;
      for (final row in rows) {
        final rowId = row['id']?.toString() ?? '';
        if (hiddenIds.contains(rowId)) continue;
        final createdAt = DateTime.tryParse(row['created_at']?.toString() ?? '');
        if (clearedBeforeMs != null &&
            createdAt != null &&
            createdAt.millisecondsSinceEpoch <= clearedBeforeMs) {
          continue;
        }
        final raw =
            (row['body_payload'] ?? row['encrypted_payload'] ?? row['ciphertext'])?.toString() ?? '';
        final payload = SharedMediaService(client).decode(raw);
        if (payload != null) {
          result.add({
            ...payload,
            'created_at': row['created_at'],
            'sender_id': row['sender_id'],
          });
        }
      }
      final oldest = rows.last;
      beforeCreatedAt = DateTime.parse(oldest['created_at'].toString());
      beforeId = oldest['id']?.toString();
      if (rows.length < pageSize || beforeId == null || beforeId.isEmpty) break;
    }
    return result;
  }

  Future<void> _openShared(Map<String, dynamic> payload) async {
    final kind = payload['kind']?.toString() ?? 'file';
    final title = payload['name']?.toString() ?? 'Attachment';
    if (kind == 'audio') {
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: Text(title),
          content: _VoiceMessagePlayer(payload: payload),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Close'),
            ),
          ],
        ),
      );
      return;
    }
    if (kind != 'image' && kind != 'video') {
      await _saveShared(payload);
      return;
    }
    try {
      final file = await SharedMediaService(Supabase.instance.client).cachedFile(payload);
      if (!mounted) return;
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => kind == 'image'
              ? _LikedinImageViewer(file: file, title: title)
              : _LikedinVideoViewer(file: file, title: title),
        ),
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not open attachment: $e')),
        );
      }
    }
  }

  Future<void> _openLocal(LocalAttachment attachment) async {
    final file = File(attachment.path);
    if (!await file.exists()) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('This local file is no longer available.')),
        );
      }
      return;
    }
    final ext = p.extension(attachment.name).toLowerCase();
    if (['.jpg', '.jpeg', '.png', '.webp', '.gif'].contains(ext)) {
      if (!mounted) return;
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => _LikedinImageViewer(file: file, title: attachment.name),
        ),
      );
      return;
    }
    if (['.mp4', '.mov', '.webm', '.mkv', '.3gp'].contains(ext)) {
      if (!mounted) return;
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => _LikedinVideoViewer(file: file, title: attachment.name),
        ),
      );
      return;
    }
    try {
      final tempDir = await getTemporaryDirectory();
      final temp = File(p.join(tempDir.path, 'likedin_local_${const Uuid().v4()}'));
      await file.copy(temp.path);
      try {
        final saved = await const MethodChannel('com.example.likedin/downloads')
                .invokeMethod<String>('saveToDownloads', {
              'sourcePath': temp.path,
              'displayName': attachment.name,
              'mimeType': 'application/octet-stream',
            }) ??
            attachment.name;
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Saved $saved to Downloads.')),
          );
        }
      } finally {
        if (await temp.exists()) await temp.delete();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not export file: $e')),
        );
      }
    }
  }

  Future<void> _saveShared(Map<String, dynamic> payload) async {
    try {
      final saved =
          await SharedMediaService(Supabase.instance.client).downloadToPublicDownloads(payload);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Saved $saved to Downloads.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Download failed: $e')),
        );
      }
    }
  }

  Future<void> importFiles() async {
    setState(() => importing = true);
    try {
      final saved = await widget.store.importFiles();
      if (!mounted) return;
      setState(refresh);
      if (saved.isNotEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${saved.length} file(s) copied into Likedin Downloads.')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not import those files.')),
        );
      }
    } finally {
      if (mounted) setState(() => importing = false);
    }
  }

  Future<void> deleteLocal(LocalAttachment file) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete downloaded copy?'),
        content: Text(
          'This deletes ${file.name} from this phone only. It does not delete any copy on another device or in cloud storage.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete from phone'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await widget.store.deleteLocal(file);
    if (mounted) setState(refresh);
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<List<LocalAttachment>>(
        future: files,
        builder: (context, snapshot) {
          final items = snapshot.data ?? const <LocalAttachment>[];
          final totalBytes = items.fold<int>(0, (sum, item) => sum + item.sizeBytes);
          return RefreshIndicator(
            onRefresh: () async {
              setState(refresh);
              await Future.wait([files, sharedFiles]);
            },
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(0, 8, 0, 0),
                  child: Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'Files',
                          style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, letterSpacing: -1.1),
                        ),
                      ),
                      IconButton(
                        tooltip: 'Refresh',
                        onPressed: () => setState(refresh),
                        icon: const Icon(Icons.refresh_rounded),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Keep a copy on this phone before a shared cloud attachment is removed.',
                  style: TextStyle(
                    height: 1.4,
                    fontSize: 14,
                    color: Theme.of(context).hintColor,
                  ),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: importing ? null : importFiles,
                    icon: const Icon(Icons.download_outlined),
                    label: Text(importing ? 'Saving…' : 'Save files to this phone'),
                  ),
                ),
                const SizedBox(height: 26),
                const Text(
                  'Shared in this chat',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: -.4),
                ),
                const SizedBox(height: 10),
                FutureBuilder<List<Map<String, dynamic>>>(
                  future: sharedFiles,
                  builder: (context, sharedSnapshot) {
                    final shared = sharedSnapshot.data ?? const <Map<String, dynamic>>[];
                    if (sharedSnapshot.connectionState == ConnectionState.waiting) {
                      return const Padding(
                        padding: EdgeInsets.all(18),
                        child: Center(child: CircularProgressIndicator()),
                      );
                    }
                    if (sharedSnapshot.hasError) {
                      return const Text('Could not load shared attachments.');
                    }
                    if (shared.isEmpty) {
                      return const Padding(
                        padding: EdgeInsets.symmetric(vertical: 12),
                        child: Text('No shared files yet.'),
                      );
                    }
                    return Column(
                      children: shared.map((item) {
                        final kind = item['kind']?.toString() ?? 'file';
                        final name = item['name']?.toString() ?? 'Attachment';
                        final icon = kind == 'image'
                            ? Icons.image_outlined
                            : kind == 'video'
                                ? Icons.video_file_outlined
                                : kind == 'audio'
                                    ? Icons.mic_none_rounded
                                    : Icons.insert_drive_file_outlined;
                        final when =
                            DateTime.tryParse(item['created_at']?.toString() ?? '')?.toLocal();
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: GlassPanel(
                            padding: EdgeInsets.zero,
                            radius: BorderRadius.circular(20),
                            blur: 5,
                            glow: false,
                            child: ListTile(
                            onTap: () => _openShared(item),
                            leading: CircleAvatar(
                              backgroundColor: brandBlue.withValues(alpha: .12),
                              child: Icon(icon, color: brandBlue),
                            ),
                            title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis),
                            subtitle: Text(
                              '${kind.isEmpty ? 'File' : '${kind[0].toUpperCase()}${kind.substring(1)}'}, ${when == null ? 'shared attachment' : when.toString().substring(0, 16)}',
                            ),
                            trailing: IconButton(
                              tooltip: 'Save to Downloads',
                              onPressed: () => _saveShared(item),
                              icon: const Icon(Icons.download_outlined),
                            ),
                          ),
                          ),
                        );
                      }).toList(),
                    );
                  },
                ),
                const SizedBox(height: 14),
                GlassPanel(
                  padding: const EdgeInsets.all(14),
                  radius: BorderRadius.circular(20),
                  blur: 5,
                  glow: false,
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Row(
                          children: [
                            Icon(Icons.phone_android_rounded, color: brandBlue),
                            SizedBox(width: 10),
                            Text(
                              'On this phone',
                              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          '${items.length} ${items.length == 1 ? 'file' : 'files'} using ${(totalBytes / (1024 * 1024)).toStringAsFixed(1)} MB',
                          style: TextStyle(color: Theme.of(context).hintColor),
                        ),
                      ],
                    ),
                ),
                const SizedBox(height: 12),
                if (snapshot.connectionState == ConnectionState.waiting)
                  const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: CircularProgressIndicator(),
                    ),
                  ),
                if (snapshot.hasError) const Text('Could not load your saved files.'),
                if (snapshot.connectionState != ConnectionState.waiting && items.isEmpty)
                  GlassPanel(
                    padding: const EdgeInsets.all(28),
                    radius: BorderRadius.circular(22),
                    blur: 5,
                    glow: false,
                    child: const Column(
                      children: [
                        Icon(Icons.folder_open_outlined, size: 42),
                        SizedBox(height: 10),
                        Text('No saved files yet', style: TextStyle(fontWeight: FontWeight.w700)),
                        SizedBox(height: 5),
                        Text(
                          'Tap “Save files” to copy photos, videos or documents into Likedin Downloads.',
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                ...items.map(
                  (file) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: GlassPanel(
                      padding: EdgeInsets.zero,
                      radius: BorderRadius.circular(20),
                      blur: 5,
                      glow: false,
                      child: ListTile(
                      onTap: () => _openLocal(file),
                      leading: CircleAvatar(
                        backgroundColor: brandBlue.withValues(alpha: .12),
                        child: const Icon(Icons.insert_drive_file_outlined, color: brandBlue),
                      ),
                      title: Text(file.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text('${file.readableSize}, saved on this phone'),
                      trailing: IconButton(
                        tooltip: 'Delete local copy',
                        onPressed: () => deleteLocal(file),
                        icon: const Icon(Icons.delete_outline, color: Color(0xFFB42318)),
                      ),
                    ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      );
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({required this.account, required this.onSignOut, super.key});
  final LikedinAccount account;
  final Future<void> Function() onSignOut;
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool get dark => likedinThemeMode.value == ThemeMode.dark;
  bool _testingNotification = false;

  @override
  void initState() {
    super.initState();
    _refreshNotificationStatus();
  }

  Future<void> _refreshNotificationStatus() async {
    await LikedinNotificationService.instance.registerCurrentToken();
    await LikedinNotificationService.instance.refreshNotificationPermissionStatus();
    if (mounted) setState(() {});
  }

  Future<void> _sendNotificationTest() async {
    if (_testingNotification) return;
    setState(() => _testingNotification = true);
    final result = await LikedinNotificationService.instance.showTestNotification();
    if (!mounted) return;
    setState(() => _testingNotification = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(result.message), duration: const Duration(seconds: 7)),
    );
    await _refreshNotificationStatus();
  }

  Future<void> _setDark(bool value) async {
    likedinThemeMode.value = value ? ThemeMode.dark : ThemeMode.light;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(likedinThemePreferenceKey, value);
    if (mounted) setState(() {});
  }

  Future<void> _exportEncryptedBackup() async {
    final passController = TextEditingController();
    final passphrase = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Encrypt chat backup'),
        content: TextField(
          controller: passController,
          obscureText: true,
          decoration: const InputDecoration(
            labelText: 'Passphrase (12+ characters)',
            hintText: 'Enter a strong passphrase',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, passController.text),
            child: const Text('Export'),
          ),
        ],
      ),
    );
    passController.dispose();
    if (passphrase == null || passphrase.isEmpty || !mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    try {
      final service = RealtimeMessagingService(Supabase.instance.client);
      final recent = await service.loadConversation(limit: 200);
      final payload = jsonEncode({
        'format': 'project-whisper-backup',
        'version': 1,
        'createdAt': DateTime.now().toUtc().toIso8601String(),
        'messages': recent
            .map((m) => {
                  'id': m.id,
                  'senderId': m.senderId,
                  'recipientId': m.recipientId,
                  'text': m.text,
                  'createdAt': m.createdAt.toUtc().toIso8601String(),
                })
            .toList(),
      });
      final encrypted = await EncryptedBackupCodec().encrypt(payload, passphrase);
      final tempDir = await getTemporaryDirectory();
      final stamp = DateTime.now().millisecondsSinceEpoch;
      final fileName = 'likedin_backup_$stamp.json';
      final tempFile = File(p.join(tempDir.path, fileName));
      await tempFile.writeAsBytes(encrypted, flush: true);
      try {
        final saved = await const MethodChannel('com.example.likedin/downloads')
                .invokeMethod<String>('saveToDownloads', {
              'sourcePath': tempFile.path,
              'displayName': fileName,
              'mimeType': 'application/json',
            }) ??
            fileName;
        if (!mounted) return;
        messenger.showSnackBar(
          SnackBar(content: Text('Encrypted backup saved to Downloads as $saved.')),
        );
      } finally {
        if (await tempFile.exists()) {
          await tempFile.delete();
        }
      }
    } catch (error) {
      if (!mounted) return;
      messenger.showSnackBar(
        SnackBar(content: Text('Could not export backup: $error')),
      );
    }
  }

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
        children: [
          const Text(
            'Settings',
            style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, letterSpacing: -1.1),
          ),
          const SizedBox(height: 16),
          GlassPanel(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            radius: BorderRadius.circular(20),
            blur: 5,
            glow: false,
            child: Row(
                children: [
                  CircleAvatar(
                    radius: 24,
                    backgroundColor: brandBlue.withValues(alpha: .14),
                    child: Text(
                      widget.account.displayName.trim().isEmpty
                          ? '?'
                          : String.fromCharCode(widget.account.displayName.trim().runes.first).toUpperCase(),
                      style: const TextStyle(color: brandBlue, fontSize: 20, fontWeight: FontWeight.w800),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          widget.account.displayName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          widget.account.likedinId,
                          maxLines: 1,
                          softWrap: false,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .68),
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 4),
                  IconButton(
                    tooltip: 'Sign out',
                    onPressed: widget.onSignOut,
                    icon: const Icon(Icons.logout_rounded, color: Color(0xFFB42318)),
                  ),
                ],
              ),
          ),
          const SizedBox(height: 26),
          const _SettingsHeading('Appearance'),
          GlassPanel(
            padding: EdgeInsets.zero,
            radius: BorderRadius.circular(20),
            blur: 5,
            glow: false,
            child: SwitchListTile.adaptive(
              value: dark,
              onChanged: _setDark,
              secondary: Icon(dark ? Icons.dark_mode : Icons.light_mode, color: brandBlue),
              title: const Text('Dark mode'),
              subtitle: const Text('Use a darker appearance across the app.'),
            ),
          ),
          const SizedBox(height: 26),
          const _SettingsHeading('Notifications'),
          GlassPanel(
            padding: const EdgeInsets.all(14),
            radius: BorderRadius.circular(20),
            blur: 5,
            glow: false,
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.notifications_active_outlined, color: brandBlue),
                      SizedBox(width: 8),
                      Text('Notifications', style: TextStyle(fontWeight: FontWeight.w700)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Android app permission: ${LikedinNotificationService.instance.notificationsAllowed == null ? 'Unknown' : LikedinNotificationService.instance.notificationsAllowed! ? 'Allowed' : 'Blocked'}',
                  ),
                  const SizedBox(height: 3),
                  Text(
                    'Firebase messaging: ${LikedinNotificationService.instance.pushConfigured ? 'Initialized' : 'Not initialized'}',
                  ),
                  const SizedBox(height: 3),
                  Text(
                    'This phone registered: ${LikedinNotificationService.instance.tokenRegistered ? 'Yes' : 'Not confirmed'}',
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: _testingNotification ? null : _sendNotificationTest,
                      icon: _testingNotification
                          ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.notifications_outlined),
                      label: Text(_testingNotification ? 'Posting test…' : 'Send test notification'),
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'Uses a separate silent test channel to isolate Android local display. It does not test Firebase or Supabase delivery.',
                    style: TextStyle(fontSize: 11, color: muted),
                  ),
                ],
              ),
          ),
          const SizedBox(height: 26),
          const _SettingsHeading('Privacy and backup'),
          const StatusRow(
            icon: Icons.key_outlined,
            title: 'Local chat state',
            subtitle: 'Protected through Android Keystore secure storage',
          ),
          const SizedBox(height: 8),
          GlassPanel(
            padding: const EdgeInsets.all(14),
            radius: BorderRadius.circular(20),
            blur: 5,
            glow: false,
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.backup_outlined, color: brandBlue),
                      SizedBox(width: 8),
                      Text('Encrypted chat backup', style: TextStyle(fontWeight: FontWeight.w700)),
                    ],
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Export a password-encrypted AES-256-GCM snapshot of your recent conversation to Downloads.',
                    style: TextStyle(fontSize: 12),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: _exportEncryptedBackup,
                      icon: const Icon(Icons.lock_outline, size: 18),
                      label: const Text('Export encrypted backup'),
                    ),
                  ),
                ],
              ),
          ),
          const SizedBox(height: 8),
          const StatusRow(
            icon: Icons.verified_user_outlined,
            title: 'Transport security',
            subtitle: 'TLS and account access controls are enabled; end-to-end encryption is not implemented',
          ),
          const SizedBox(height: 26),
          const _SettingsHeading('About'),
          const StatusRow(
            icon: Icons.info_outline,
            title: 'About Likedin',
            subtitle: 'Messaging app, version $likedinVersion',
          ),
        ],
      );
}

class _SettingsHeading extends StatelessWidget {
  const _SettingsHeading(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 0, 4, 10),
        child: Text(
          text,
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: -.4),
        ),
      );
}

class _VoiceMessagePlayer extends StatefulWidget {
  const _VoiceMessagePlayer({super.key, required this.payload});
  final Map<String, dynamic> payload;
  @override
  State<_VoiceMessagePlayer> createState() => _VoiceMessagePlayerState();
}

class _VoiceMessagePlayerState extends State<_VoiceMessagePlayer> {
  static AudioPlayer? _activePlayer;
  final AudioPlayer _player = AudioPlayer();
  StreamSubscription<PlayerState>? _stateSubscription;
  bool _loading = false;
  bool _loaded = false;
  double _speed = 1.0;
  String? _error;

  @override
  void initState() {
    super.initState();
    _stateSubscription = _player.playerStateStream.listen((state) {
      if (state.processingState == ProcessingState.completed) {
        _player.pause();
        _player.seek(Duration.zero);
      }
      if (mounted) setState(() {});
    });
  }

  Future<void> _load() async {
    if (_loading || _loaded) return;
    setState(() { _loading = true; _error = null; });
    try {
      final file = await SharedMediaService(Supabase.instance.client).cachedFile(widget.payload);
      await _player.setFilePath(file.path);
      _loaded = true;
    } catch (e) {
      _error = e.toString();
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _cycleSpeed() async {
    final next = _speed == 1.0 ? 1.5 : _speed == 1.5 ? 2.0 : 1.0;
    setState(() => _speed = next);
    try {
      await _player.setSpeed(next);
    } catch (_) {}
  }

  @override
  void dispose() {
    if (identical(_activePlayer, _player)) {
      _activePlayer = null;
    }
    _stateSubscription?.cancel();
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => SizedBox(
        width: 245,
        child: Row(
          children: [
            IconButton.filled(
              onPressed: _loading
                  ? null
                  : () async {
                      if (!_loaded) {
                        await _load();
                        if (!_loaded) return;
                      }
                      if (_player.playing) {
                        await _player.pause();
                      } else {
                        final previous = _activePlayer;
                        if (previous != null && !identical(previous, _player)) {
                          try {
                            await previous.pause();
                          } catch (_) {}
                        }
                        _activePlayer = _player;
                        if (_player.processingState == ProcessingState.completed) {
                          await _player.seek(Duration.zero);
                        }
                        await _player.setSpeed(_speed);
                        await _player.play();
                      }
                      if (mounted) setState(() {});
                    },
              icon: Icon(_player.playing ? Icons.pause : Icons.play_arrow),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Expanded(
                        child: Text('Voice message', style: TextStyle(fontWeight: FontWeight.w700)),
                      ),
                      InkWell(
                        onTap: _cycleSpeed,
                        borderRadius: BorderRadius.circular(8),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          child: Text(
                            '${_speed == _speed.roundToDouble() ? _speed.toInt() : _speed}x',
                            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: brandBlue),
                          ),
                        ),
                      ),
                    ],
                  ),
                  if (_loading)
                    const LinearProgressIndicator(minHeight: 2)
                  else if (_error != null)
                    const Text(
                      'Audio unavailable',
                      style: TextStyle(fontSize: 11, color: Colors.red),
                    ),
                  if (_error != null)
                    TextButton(onPressed: _load, child: const Text('Retry download'))
                  else if (_loaded)
                    StreamBuilder<Duration>(
                      stream: _player.positionStream,
                      builder: (_, snap) {
                        final pos = snap.data ?? Duration.zero;
                        final total = _player.duration ?? Duration.zero;
                        return Column(
                          children: [
                            Slider(
                              value: total.inMilliseconds == 0
                                  ? 0
                                  : pos.inMilliseconds.clamp(0, total.inMilliseconds).toDouble(),
                              max: total.inMilliseconds == 0 ? 1 : total.inMilliseconds.toDouble(),
                              onChanged: (v) => _player.seek(Duration(milliseconds: v.round())),
                            ),
                            Text(
                              '${_fmt(pos)} / ${_fmt(total)}',
                              style: const TextStyle(fontSize: 10, color: muted),
                            ),
                          ],
                        );
                      },
                    ),
                ],
              ),
            ),
          ],
        ),
      );

  String _fmt(Duration d) => '${d.inMinutes}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';
}

class _ChatMediaMessage extends StatefulWidget {
  const _ChatMediaMessage({
    super.key,
    required this.payload,
    required this.name,
    required this.sizeLabel,
  });
  final Map<String, dynamic> payload;
  final String name;
  final String sizeLabel;
  @override
  State<_ChatMediaMessage> createState() => _ChatMediaMessageState();
}

class _ChatMediaMessageState extends State<_ChatMediaMessage> {
  File? _file;
  bool _loading = false;
  String? _error;

  bool get _isVideo => widget.payload['kind'] == 'video';
  bool get _isGif => widget.payload['animated'] == true ||
      widget.name.toLowerCase().endsWith('.gif') || widget.payload['mime'] == 'image/gif';

  @override
  void initState() {
    super.initState();
    // Photos retain the compact inline preview. Video is deliberately manual:
    // opening a conversation must not silently download a 50 MB clip over mobile data.
    if (!_isVideo) _loadFile();
  }

  @override
  void didUpdateWidget(covariant _ChatMediaMessage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.payload['path'] != widget.payload['path']) {
      _file = null;
      _error = null;
      _loading = false;
      if (!_isVideo) _loadFile();
    }
  }

  Future<void> _loadFile() async {
    if (_loading || _file != null) return;
    setState(() { _loading = true; _error = null; });
    Object? lastError;
    try {
      final media = SharedMediaService(Supabase.instance.client);
      for (var attempt = 0; attempt < 3; attempt++) {
        try {
          final file = await media.cachedFile(widget.payload);
          if (!mounted) return;
          setState(() => _file = file);
          return;
        } catch (error) {
          lastError = error;
          if (attempt < 2) {
            await Future<void>.delayed(Duration(milliseconds: 350 * (attempt + 1)));
          }
        }
      }
      if (mounted) setState(() => _error = lastError?.toString() ?? 'Media could not be loaded.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final file = _file;
    if (file == null) {
      if (_error != null) {
        return _mediaError('Media unavailable. Tap to retry.', _loadFile);
      }
      return SizedBox(
        width: 270,
        height: 190,
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: .6),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Center(
            child: _loading
                ? const CircularProgressIndicator()
                : Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(_isVideo ? Icons.movie_outlined : Icons.image_outlined, size: 38),
                      const SizedBox(height: 8),
                      Text(_isVideo ? 'Video not downloaded' : 'Loading photo'),
                      const SizedBox(height: 5),
                      Text('${widget.name} · ${widget.sizeLabel}', style: const TextStyle(fontSize: 11)),
                      if (_isVideo) ...[
                        const SizedBox(height: 8),
                        FilledButton.tonalIcon(
                          onPressed: _loadFile,
                          icon: const Icon(Icons.download_rounded),
                          label: const Text('Tap to download'),
                        ),
                      ],
                    ],
                  ),
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        if (_isVideo)
          _ChatVideoPreview(file: file, title: widget.name)
        else
          GestureDetector(
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => _LikedinImageViewer(file: file, title: widget.name)),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 300, maxHeight: 360, minWidth: 210),
                child: Image.file(
                  file,
                  fit: _isGif ? BoxFit.contain : BoxFit.cover,
                  width: 300,
                  cacheWidth: 640,
                  cacheHeight: 640,
                  frameBuilder: (context, child, frame, sync) => frame != null
                      ? child
                      : const SizedBox(width: 270, height: 190, child: Center(child: CircularProgressIndicator())),
                  errorBuilder: (_, __, ___) => const SizedBox(
                    width: 270, height: 150,
                    child: Center(child: Icon(Icons.broken_image_outlined, size: 42)),
                  ),
                ),
              ),
            ),
          ),
        const SizedBox(height: 5),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(_isVideo ? Icons.videocam_outlined : Icons.image_outlined, size: 17),
            const SizedBox(width: 6),
            Flexible(
              child: Text('${widget.name} · ${widget.sizeLabel}', maxLines: 1,
                overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, color: muted)),
            ),
            IconButton(
              visualDensity: VisualDensity.compact,
              tooltip: 'Save to Downloads',
              icon: const Icon(Icons.download_rounded, size: 20),
              onPressed: () async {
                // Capture the messenger before awaiting. After the operation,
                // use the State's mounted guard rather than reading context
                // across the asynchronous gap.
                final messenger = ScaffoldMessenger.of(context);
                try {
                  final saved = await SharedMediaService(Supabase.instance.client)
                      .downloadToPublicDownloads(widget.payload);
                  if (!mounted) return;
                  messenger.showSnackBar(
                    SnackBar(content: Text('Saved $saved to Downloads.')),
                  );
                } catch (e) {
                  if (!mounted) return;
                  messenger.showSnackBar(
                    SnackBar(content: Text('Download failed: $e')),
                  );
                }
              },
            ),
          ],
        ),
      ],
    );
  }

  Widget _mediaError(String message, VoidCallback retry) => SizedBox(
    width: 270,
    child: TextButton.icon(onPressed: retry, icon: const Icon(Icons.refresh), label: Text(message)),
  );
}

class _ChatVideoPreview extends StatelessWidget {
  const _ChatVideoPreview({required this.file, required this.title});
  final File file;
  final String title;

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => _LikedinVideoViewer(file: file, title: title),
          ),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: Container(
            width: 300,
            height: 176,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF172B4D), Color(0xFF0A192F)],
              ),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                const Icon(
                  Icons.play_circle_fill_rounded,
                  color: Colors.white,
                  size: 64,
                ),
                Positioned(
                  left: 12,
                  right: 12,
                  bottom: 10,
                  child: Row(
                    children: [
                      const Icon(Icons.videocam_rounded, color: Colors.white70, size: 16),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
}

class _LikedinImageViewer extends StatelessWidget {
  const _LikedinImageViewer({required this.file, required this.title});
  final File file;
  final String title;

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
          title: Text(title),
        ),
        body: Center(
          child: InteractiveViewer(
            minScale: 0.8,
            maxScale: 5,
            child: Image.file(
              file,
              fit: BoxFit.contain,
              cacheWidth: 1400,
              cacheHeight: 1400,
              errorBuilder: (_, __, ___) => const Icon(
                Icons.broken_image_outlined,
                color: Colors.white,
                size: 56,
              ),
            ),
          ),
        ),
      );
}

class _LikedinVideoViewer extends StatefulWidget {
  const _LikedinVideoViewer({required this.file, required this.title});
  final File file;
  final String title;
  @override
  State<_LikedinVideoViewer> createState() => _LikedinVideoViewerState();
}

class _LikedinVideoViewerState extends State<_LikedinVideoViewer> with WidgetsBindingObserver {
  late final VideoPlayerController _controller = VideoPlayerController.file(widget.file);
  String? _error;

  void _onControllerUpdated() {
    if (mounted) setState(() {});
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _controller.addListener(_onControllerUpdated);
    _controller.initialize().then((_) {
      if (mounted) setState(() {});
      _controller.play();
    }).catchError((Object e) {
      if (mounted) setState(() => _error = e.toString());
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused || state == AppLifecycleState.inactive) {
      if (_controller.value.isInitialized && _controller.value.isPlaying) {
        _controller.pause();
      }
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _controller.removeListener(_onControllerUpdated);
    _controller.dispose();
    super.dispose();
  }

  String _formatDuration(Duration d) =>
      '${d.inMinutes.toString().padLeft(2, '0')}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
          title: Text(widget.title),
        ),
        body: Column(
          children: [
            Expanded(
              child: Center(
                child: _error != null
                    ? const Padding(
                        padding: EdgeInsets.all(24),
                        child: Text(
                          'Could not play this video file.',
                          style: TextStyle(color: Colors.white70),
                        ),
                      )
                    : _controller.value.isInitialized
                        ? AspectRatio(
                            aspectRatio: _controller.value.aspectRatio,
                            child: VideoPlayer(_controller),
                          )
                        : const CircularProgressIndicator(),
              ),
            ),
            if (_error == null && _controller.value.isInitialized)
              SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      VideoProgressIndicator(
                        _controller,
                        allowScrubbing: true,
                        colors: const VideoProgressColors(
                          playedColor: brandBlue,
                          bufferedColor: Colors.white38,
                          backgroundColor: Colors.white12,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          IconButton(
                            onPressed: () {
                              setState(() {
                                _controller.value.isPlaying
                                    ? _controller.pause()
                                    : _controller.play();
                              });
                            },
                            icon: Icon(
                              _controller.value.isPlaying ? Icons.pause : Icons.play_arrow,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            '${_formatDuration(_controller.value.position)} / ${_formatDuration(_controller.value.duration)}',
                            style: const TextStyle(color: Colors.white70, fontSize: 12),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      );
}


/// Compact quote renderer. Image/GIF replies use the same cached media file as
/// the message bubble; concurrent requests are coalesced by SharedMediaService.
class _ReplyQuotePreview extends StatefulWidget {
  const _ReplyQuotePreview({
    required this.original,
    required this.fallbackText,
    this.compact = false,
  });

  final RemoteMessage? original;
  final String fallbackText;
  final bool compact;

  @override
  State<_ReplyQuotePreview> createState() => _ReplyQuotePreviewState();
}

class _ReplyQuotePreviewState extends State<_ReplyQuotePreview> {
  Future<File>? _imageFuture;
  Map<String, dynamic>? _payload;

  @override
  void initState() {
    super.initState();
    _prepare();
  }

  @override
  void didUpdateWidget(covariant _ReplyQuotePreview oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.original?.id != widget.original?.id ||
        oldWidget.original?.text != widget.original?.text) {
      _prepare();
    }
  }

  void _prepare() {
    _payload = null;
    _imageFuture = null;
    final original = widget.original;
    if (original == null || original.deletedForEveryoneAt != null) return;
    final payload = SharedMediaService(Supabase.instance.client).decode(original.text);
    if (payload == null) return;
    _payload = payload;
    if (payload['kind'] == 'image') {
      _imageFuture = SharedMediaService(Supabase.instance.client).cachedFile(payload);
    }
  }

  String _mediaLabel(Map<String, dynamic> payload) {
    final kind = payload['kind']?.toString() ?? 'file';
    if (kind == 'image') {
      final animated = payload['animated'] == true ||
          payload['mime'] == 'image/gif' ||
          (payload['name']?.toString().toLowerCase().endsWith('.gif') ?? false);
      return animated ? 'GIF' : 'Photo';
    }
    if (kind == 'video') return 'Video';
    if (kind == 'audio') return 'Voice message';
    return 'Attachment';
  }

  Widget _iconPreview(IconData icon, {Color? color}) => Container(
        width: widget.compact ? 52 : 60,
        height: widget.compact ? 42 : 48,
        decoration: BoxDecoration(
          color: brandBlue.withValues(alpha: .10),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, color: color ?? brandBlue, size: 23),
      );

  @override
  Widget build(BuildContext context) {
    final payload = _payload;
    if (payload == null) {
      return Text(
        widget.fallbackText,
        maxLines: widget.compact ? 1 : 2,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          fontSize: 12,
          height: 1.2,
          color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .78),
        ),
      );
    }

    final kind = payload['kind']?.toString() ?? 'file';
    final label = _mediaLabel(payload);
    Widget preview;
    if (kind == 'image' && _imageFuture != null) {
      preview = FutureBuilder<File>(
        future: _imageFuture,
        builder: (context, snapshot) {
          final file = snapshot.data;
          if (snapshot.hasError) {
            return _iconPreview(Icons.image_not_supported_outlined);
          }
          if (file == null || !snapshot.hasData) {
            return SizedBox(
              width: widget.compact ? 52 : 60,
              height: widget.compact ? 42 : 48,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: brandBlue.withValues(alpha: .10),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Center(
                  child: SizedBox(width: 15, height: 15, child: CircularProgressIndicator(strokeWidth: 1.7)),
                ),
              ),
            );
          }
          return ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.file(
              file,
              width: widget.compact ? 52 : 60,
              height: widget.compact ? 42 : 48,
              fit: BoxFit.cover,
              cacheWidth: 120,
              cacheHeight: 96,
              filterQuality: FilterQuality.low,
              errorBuilder: (_, __, ___) => _iconPreview(Icons.image_outlined),
            ),
          );
        },
      );
    } else if (kind == 'video') {
      preview = _iconPreview(Icons.play_circle_outline_rounded);
    } else if (kind == 'audio') {
      preview = _iconPreview(Icons.graphic_eq_rounded);
    } else {
      preview = _iconPreview(Icons.insert_drive_file_outlined);
    }

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        preview,
        const SizedBox(width: 8),
        Flexible(
          child: Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .82),
            ),
          ),
        ),
      ],
    );
  }
}
