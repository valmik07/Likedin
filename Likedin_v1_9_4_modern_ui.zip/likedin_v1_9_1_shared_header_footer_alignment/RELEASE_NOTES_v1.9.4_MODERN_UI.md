# v1.9.4 modern UI refresh (front end only)

No backend, migration, dependency or version-string change.

## System-wide
- One shared theme (`_likedinTheme`) for light and dark: tonal flat surfaces, hairline outlines, pill buttons, rounded sheets/dialogs/menus, restyled switches, snackbars, chips and navigation bar.
- `GlassPanel` and `AuroraBackdrop` keep their names/APIs but are now flat solid surfaces: no gradient blobs, blur or glow (cheaper to paint, consistent everywhere).
- Dark-mode accent unified from cyan to a soft blue.
- Removed template chrome: tracked all-caps micro-labels, fake 01/02 numbering, decorative "FILTER"/"LIVE HISTORY"/tagline text.

## Pages
- Sign in: left-aligned large headline, pill tabs, dark-mode-safe error/notice colours, email keyboard, password show/hide tooltip; removed the always-on "Connected" claim.
- Home: greeting is now a large typographic hero (no card); briefing is a clean list without badges or numbering.
- Chat: flatter bubbles (no shadow), tonal composer and reply banner, header decluttered (nickname edit moved into the menu), plus earlier empty-state/labels polish.
- Calls: large title, two tinted start tiles, plain filter pills.
- Files: large title, full-width save button, readable type labels, dark-mode avatars.
- Settings: large title, initial avatar, sections (Appearance, Notifications, Privacy and backup, About).

## Not changed on purpose
Navigation structure (Home + Preferences in the bar; Chat/Calls via More; Files via profile menu) and the full-screen call UIs.

## Verification
Not compiled here (no Flutter SDK). Run `flutter analyze` and a visual pass in light and dark mode via GitHub Actions/device.
