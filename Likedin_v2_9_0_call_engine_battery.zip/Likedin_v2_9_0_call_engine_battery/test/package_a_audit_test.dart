import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/backend/shared_media_service.dart';
import 'package:likedin/main.dart' show isValidLikedinEmail;
import 'package:likedin/ui/glassmorphism.dart';
import 'package:likedin/ui/hidden_chat_pin_dialog.dart';

void main() {
  testWidgets('OriginQuickReactionBar renders without overflow at 360dp and 120% text scale', (tester) async {
    LikedinAppearance.effects.value = LikedinEffects.real;
    LikedinAppearance.reduceMotion.value = false;
    String? picked;
    var moreTapped = false;

    for (final scale in <double>[1.0, 1.2]) {
      picked = null;
      moreTapped = false;
      await tester.binding.setSurfaceSize(const Size(360, 640));
      addTearDown(() => tester.binding.setSurfaceSize(null));

      await tester.pumpWidget(
        MediaQuery(
          data: MediaQueryData(
            size: const Size(360, 640),
            textScaler: TextScaler.linear(scale),
          ),
          child: MaterialApp(
            home: Scaffold(
              body: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 20),
                child: OriginQuickReactionBar(
                  emojis: const ['❤️', '😂', '👍', '😮', '😢', '🔥', '\u{1FAE9}'],
                  onSelectEmoji: (e) => picked = e,
                  onMore: () => moreTapped = true,
                ),
              ),
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();

      expect(tester.takeException(), isNull);

      await tester.tap(find.text('🔥'));
      await tester.pumpAndSettle();
      expect(picked, '🔥');

      await tester.tap(find.byIcon(Icons.add_rounded));
      await tester.pumpAndSettle();
      expect(moreTapped, isTrue);
    }
  });

  testWidgets('GlassPanel skips BackdropFilter blur when Reduce Motion is enabled', (tester) async {
    LikedinAppearance.effects.value = LikedinEffects.real;
    LikedinAppearance.reduceMotion.value = false;

    await tester.pumpWidget(
      const MaterialApp(
        home: BackdropGroup(
          child: Scaffold(
            body: Center(
              child: GlassPanel(
                frosted: true,
                blur: 6,
                child: Text('Frosted glass'),
              ),
            ),
          ),
        ),
      ),
    );
    expect(find.byType(BackdropFilter), findsOneWidget);

    LikedinAppearance.reduceMotion.value = true;
    await tester.pump();
    expect(find.byType(BackdropFilter), findsNothing);

    LikedinAppearance.reduceMotion.value = false;
  });

  testWidgets('LiquidGlassBubble highContrast wallpaper mode renders cleanly in light and dark themes', (tester) async {
    for (final brightness in Brightness.values) {
      await tester.pumpWidget(
        MaterialApp(
          theme: ThemeData(brightness: brightness),
          home: Scaffold(
            body: Column(
              children: [
                LiquidGlassBubble(
                  outgoing: true,
                  highContrast: true,
                  borderRadius: BorderRadius.circular(18),
                  child: const Text('Outgoing over wallpaper'),
                ),
                LiquidGlassBubble(
                  outgoing: false,
                  highContrast: true,
                  borderRadius: BorderRadius.circular(18),
                  child: const Text('Incoming over wallpaper'),
                ),
              ],
            ),
          ),
        ),
      );
      expect(tester.takeException(), isNull);
      expect(find.text('Outgoing over wallpaper'), findsOneWidget);
      expect(find.text('Incoming over wallpaper'), findsOneWidget);
    }
  });

  testWidgets('HiddenChatPinDialog validates length, clears error on edit, and returns password', (tester) async {
    HiddenChatPinDialogResult? result;

    await tester.pumpWidget(
      MaterialApp(
        home: Builder(
          builder: (context) => Scaffold(
            body: ElevatedButton(
              onPressed: () async {
                result = await HiddenChatPinDialog.show(context, setup: true);
              },
              child: const Text('Open'),
            ),
          ),
        ),
      ),
    );

    await tester.tap(find.text('Open'));
    await tester.pumpAndSettle();

    // Too short -> shows length error
    await tester.enterText(find.byType(TextField).first, '1234');
    await tester.tap(find.text('Create password'));
    await tester.pumpAndSettle();
    expect(find.text('Use at least 8 characters.'), findsOneWidget);

    // Typing clears the stale error immediately
    await tester.enterText(find.byType(TextField).first, '12345678');
    await tester.pumpAndSettle();
    expect(find.text('Use at least 8 characters.'), findsNothing);

    // Mismatch -> shows mismatch error
    await tester.enterText(find.byType(TextField).last, '87654321');
    await tester.tap(find.text('Create password'));
    await tester.pumpAndSettle();
    expect(find.text('The passwords do not match.'), findsOneWidget);

    // Fixing confirmation clears mismatch error and submits cleanly
    await tester.enterText(find.byType(TextField).last, '12345678');
    await tester.pumpAndSettle();
    expect(find.text('The passwords do not match.'), findsNothing);

    await tester.tap(find.text('Create password'));
    await tester.pumpAndSettle();
    expect(result?.password, '12345678');
  });

  test('isValidLikedinEmail accepts standard emails and rejects invalid formats', () {
    expect(isValidLikedinEmail('alice@example.com'), isTrue);
    expect(isValidLikedinEmail('  bob.smith+1@sub.domain.co.in  '), isTrue);
    expect(isValidLikedinEmail(''), isFalse);
    expect(isValidLikedinEmail('just-an-@'), isFalse);
    expect(isValidLikedinEmail('missing-dot@domain'), isFalse);
    expect(isValidLikedinEmail('@missing-local.com'), isFalse);
    expect(isValidLikedinEmail('has space@example.com'), isFalse);
  });

  test('SharedMediaService cache directory cleanup leaves unrelated cached files intact', () async {
    final dir = await Directory.systemTemp.createTemp('likedin_pkg_a_cache_');
    addTearDown(() => dir.delete(recursive: true));

    final keep = File('${dir.path}/keep_recent.jpg')..writeAsBytesSync(<int>[1, 2, 3, 4]);
    await SharedMediaService.deleteCachedFilesInDirectory(dir, 'uid/nonexistent.jpg');
    expect(await keep.exists(), isTrue);
  });
}
