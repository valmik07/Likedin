import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

import '../backend/turn_config_service.dart';
import '../ui/glassmorphism.dart';
import 'call_alert_controller.dart';
import 'call_quality_engine.dart';

class LikedinCallService {
  LikedinCallService(this.client);
  final SupabaseClient client;
  final _uuid = const Uuid();
  RTCPeerConnection? _pc;
  MediaStream? _local;
  RTCRtpSender? _videoSender;
  RTCRtpSender? _audioSender;
  final _remote = RTCVideoRenderer();
  final _localRenderer = RTCVideoRenderer();
  bool _renderersInitialized = false;
  final List<RTCIceCandidate> _pendingCandidates = [];
  final Set<String> _seenIceSignalIds = <String>{};
  bool _remoteDescriptionReady = false;
  bool _applyingRemoteAnswer = false;
  bool _makingOffer = false;
  bool _restartingIce = false;
  bool _togglingCamera = false;
  bool _speakerOverriddenByUser = false;
  bool _terminalizing = false;
  RealtimeChannel? _channel;
  StreamSubscription<List<ConnectivityResult>>? _connectivitySub;
  String? _lastTransportKey;
  Timer? _ringTimer;
  Timer? _signalCatchupTimer;
  Timer? _statsTimer;
  Timer? _disconnectGraceTimer;
  static int _channelGeneration = 0;
  bool _catchingUpSignals = false;
  int _prevPacketsLost = 0;
  int _prevPacketsReceived = 0;
  bool _hasPrevStatsSample = false;
  CallQualityProfile? _appliedProfile;
  int _iceRestartCounter = 0;

  String? callId, peerId;
  bool video = false, muted = false, speaker = false, camera = true;
  bool dataSaver = false;
  bool usingFrontCamera = true;
  String status = 'idle';
  final _changes = StreamController<String>.broadcast();
  final ValueNotifier<CallNetworkStats> networkStatsNotifier =
      ValueNotifier<CallNetworkStats>(const CallNetworkStats());
  Future<void>? _disposeFuture;
  Stream<String> get changes => _changes.stream;
  RTCVideoRenderer get remoteRenderer => _remote;
  RTCVideoRenderer get localRenderer => _localRenderer;
  String get uid => client.auth.currentUser?.id ?? '';

  static const Map<String, dynamic> _voiceAudioConstraints = <String, dynamic>{
    'echoCancellation': true,
    'noiseSuppression': true,
    'autoGainControl': true,
    'googEchoCancellation': true,
    'googEchoCancellation2': true,
    'googAutoGainControl': true,
    'googAutoGainControl2': true,
    'googNoiseSuppression': true,
    'googNoiseSuppression2': true,
    'googHighpassFilter': true,
    'googTypingNoiseDetection': true,
  };

  Map<String, dynamic> _videoConstraints() {
    final lowPower = LikedinAppearance.isLowRamDevice || dataSaver;
    return <String, dynamic>{
      'facingMode': usingFrontCamera ? 'user' : 'environment',
      'width': {'ideal': lowPower ? 640 : 960},
      'height': {'ideal': lowPower ? 480 : 540},
      'frameRate': {'ideal': lowPower ? 18 : 24, 'max': lowPower ? 20 : 24},
    };
  }

  Future<void> initialize({bool withVideo = true}) async {
    if (!withVideo || _renderersInitialized) return;
    await _remote.initialize();
    await _localRenderer.initialize();
    _renderersInitialized = true;
  }

  // Audio calls start on the handset earpiece; video calls default to speakerphone.
  Future<void> _applyInitialAudioRoute() async {
    if (!_speakerOverriddenByUser) {
      speaker = video;
    }
    await Helper.setSpeakerphoneOn(speaker);
  }

  Future<List<Map<String, dynamic>>> _iceServers() =>
      TurnConfigService(client).fetchIceServers();

  void _emitStatus(String next) {
    status = next;
    if (!_changes.isClosed) _changes.add(status);
  }

  Future<void> _createPeer() async {
    // Start peer creation with immediately-available STUN servers. Fetching
    // private TURN credentials must not block the answer path or prevent a
    // call during an Edge Function cold start/rate limit/outage.
    final turnServersFuture = _iceServers();
    _pc = await createPeerConnection({
      'iceServers': TurnConfigService.fallbackIceServers,
      'sdpSemantics': 'unified-plan',
    });
    final peerForConfiguration = _pc;
    unawaited(turnServersFuture.then<void>((servers) async {
      final activePeer = _pc;
      if (activePeer == null || !identical(activePeer, peerForConfiguration)) return;
      try {
        await activePeer.setConfiguration({
          'iceServers': servers,
          'sdpSemantics': 'unified-plan',
        });
      } catch (error) {
        debugPrint('Could not apply refreshed TURN configuration; keeping STUN fallback: $error');
      }
    }).catchError((Object error) {
      debugPrint('TURN configuration refresh failed; keeping STUN fallback: $error');
    }));

    _pc!.onIceCandidate = (candidate) {
      if (candidate.candidate != null && callId != null) {
        unawaited(_send('ice', {
          'candidate': candidate.candidate,
          'sdpMid': candidate.sdpMid,
          'sdpMLineIndex': candidate.sdpMLineIndex,
        }).catchError((Object _) {
          // ICE delivery is best-effort; avoid an unhandled async callback error.
        }));
      }
    };

    _pc!.onTrack = (event) {
      if (event.streams.isNotEmpty && _renderersInitialized) {
        _remote.srcObject = event.streams.first;
      }
    };

    _pc!.onConnectionState = (state) {
      // Match RTCPeerConnectionState enum values directly rather than parsing
      // .toString(), which Dart obfuscates in --obfuscate release builds.
      switch (state) {
        case RTCPeerConnectionState.RTCPeerConnectionStateDisconnected:
          _emitStatus('disconnected');
          networkStatsNotifier.value = CallNetworkStats(
            tier: CallQualityTier.reconnecting,
            rttMs: networkStatsNotifier.value.rttMs,
            lossPercent: networkStatsNotifier.value.lossPercent,
            dataSaver: dataSaver,
            reconnecting: true,
          );
          unawaited(_triggerIceRestart(reason: 'ice_disconnected'));
          // Allow a 15-second grace window for full ICE-restart renegotiation
          // (e.g. Wi-Fi -> 4G/5G handoff) before failing the call.
          _disconnectGraceTimer?.cancel();
          _disconnectGraceTimer = Timer(const Duration(seconds: 15), () {
            if (status == 'disconnected' || status == 'reconnecting') {
              unawaited(_failCall('Call disconnected and did not recover.'));
            }
          });
          return;
        case RTCPeerConnectionState.RTCPeerConnectionStateConnected:
          _disconnectGraceTimer?.cancel();
          _restartingIce = false;
          _signalCatchupTimer?.cancel();
          _signalCatchupTimer = null;
          _emitStatus('connected');
          _startStatsMonitor();
          _startConnectivityWatcher();
          unawaited(_applyEncodingProfile(
            CallQualityEngine.profileFor(
              CallQualityTier.good,
              dataSaver: dataSaver,
              lowRamDevice: LikedinAppearance.isLowRamDevice,
            ),
          ));
          return;
        case RTCPeerConnectionState.RTCPeerConnectionStateConnecting:
        case RTCPeerConnectionState.RTCPeerConnectionStateNew:
          _disconnectGraceTimer?.cancel();
          _emitStatus(_restartingIce ? 'reconnecting' : 'connecting');
          return;
        case RTCPeerConnectionState.RTCPeerConnectionStateFailed:
          if (!_restartingIce && _remoteDescriptionReady && !_terminalizing) {
            _emitStatus('reconnecting');
            unawaited(_triggerIceRestart(reason: 'ice_failed'));
            _disconnectGraceTimer?.cancel();
            _disconnectGraceTimer = Timer(const Duration(seconds: 12), () {
              if (status == 'disconnected' || status == 'reconnecting') {
                unawaited(_failCall('WebRTC connection failed.'));
              }
            });
            return;
          }
          _disconnectGraceTimer?.cancel();
          unawaited(_failCall('WebRTC connection failed.'));
          return;
        case RTCPeerConnectionState.RTCPeerConnectionStateClosed:
          _disconnectGraceTimer?.cancel();
          if (!_terminalizing) {
            unawaited(_failCall('Call connection closed unexpectedly.'));
            return;
          }
          _emitStatus('ended');
          return;
      }
    };

    _local = await navigator.mediaDevices.getUserMedia({
      'audio': _voiceAudioConstraints,
      'video': video ? _videoConstraints() : false,
    });
    await CallAlertController.startCallService(video: video);
    // getUserMedia may reset Android's audio route; re-assert initial route afterwards.
    await _applyInitialAudioRoute();
    if (_renderersInitialized) {
      _localRenderer.srcObject = _local;
    }
    _audioSender = null;
    _videoSender = null;
    for (final track in _local!.getTracks()) {
      final sender = await _pc!.addTrack(track, _local!);
      if (track.kind == 'video') {
        _videoSender = sender;
      } else if (track.kind == 'audio') {
        _audioSender = sender;
      }
    }
  }

  /// Watches Android connectivity changes (Wi-Fi <-> 4G/5G) during an active
  /// call and runs a full ICE-restart renegotiation so calls survive handoffs.
  void _startConnectivityWatcher() {
    if (_connectivitySub != null) return;
    _connectivitySub = Connectivity().onConnectivityChanged.listen((results) {
      if (_terminalizing || _pc == null || !_remoteDescriptionReady) return;
      final activeTransports = results
          .where((r) => r != ConnectivityResult.none)
          .map((r) => r.name)
          .toList()
        ..sort();
      final key = activeTransports.join('+');
      if (_lastTransportKey == null) {
        _lastTransportKey = key;
        return;
      }
      if (key == _lastTransportKey) return;
      _lastTransportKey = key;
      if (key.isEmpty) {
        // Momentarily offline — mark reconnecting while waiting for 4G/Wi-Fi.
        networkStatsNotifier.value = CallNetworkStats(
          tier: CallQualityTier.reconnecting,
          rttMs: networkStatsNotifier.value.rttMs,
          lossPercent: networkStatsNotifier.value.lossPercent,
          dataSaver: dataSaver,
          reconnecting: true,
        );
        return;
      }
      // Network interface switched (e.g., Wi-Fi -> Mobile or vice versa).
      unawaited(_triggerIceRestart(reason: 'network_switch:$key'));
    });
  }

  /// Performs a full WebRTC ICE-restart offer/answer renegotiation using
  /// `kind: 'offer'` + `payload.iceRestart = true` (100% compatible with the
  /// existing `likedin_call_signals` DB schema).
  Future<void> _triggerIceRestart({required String reason}) async {
    final peer = _pc;
    final id = callId;
    if (peer == null ||
        id == null ||
        _terminalizing ||
        !_remoteDescriptionReady ||
        _restartingIce ||
        _makingOffer) {
      return;
    }
    _restartingIce = true;
    _makingOffer = true;
    debugPrint('Likedin WebRTC ICE restart triggered ($reason)');
    try {
      // Refresh TURN credentials on network switch so relay candidates stay valid.
      try {
        final refreshedServers = await _iceServers().timeout(const Duration(seconds: 4));
        if (identical(_pc, peer) && !_terminalizing) {
          await peer.setConfiguration({
            'iceServers': refreshedServers,
            'sdpSemantics': 'unified-plan',
          });
        }
      } catch (_) {}

      if (!identical(_pc, peer) || _terminalizing) return;
      final rawOffer = await peer.createOffer({'iceRestart': true});
      final tunedSdp = CallQualityEngine.tuneSdpForVoiceAndHardwareVideo(
        rawOffer.sdp ?? '',
        dataSaver: dataSaver,
      );
      final tunedOffer = RTCSessionDescription(tunedSdp, rawOffer.type);
      await peer.setLocalDescription(tunedOffer);
      _iceRestartCounter++;
      await _send('offer', {
        'sdp': tunedOffer.sdp,
        'type': tunedOffer.type,
        'iceRestart': true,
        'gen': _iceRestartCounter,
      });
      // Re-arm short signal catch-up during handoff in case Realtime socket also rotated.
      _startSignalCatchup();
    } catch (error) {
      debugPrint('ICE restart renegotiation failed ($reason): $error');
    } finally {
      _makingOffer = false;
    }
  }

  /// Polls WebRTC `getStats()` every 2.5s while connected, updates live quality
  /// telemetry, and adapts video bitrate/framerate/resolution smoothly.
  void _startStatsMonitor() {
    _statsTimer?.cancel();
    _hasPrevStatsSample = false;
    _statsTimer = Timer.periodic(const Duration(seconds: 2, milliseconds: 500), (_) {
      unawaited(_pollNetworkStats());
    });
  }

  Future<void> _pollNetworkStats() async {
    final peer = _pc;
    if (peer == null || _terminalizing || status != 'connected') return;
    try {
      final rawReports = await peer.getStats();
      if (!identical(_pc, peer) || _terminalizing) return;
      final sample = CallQualityEngine.extractStatsSample(
        rawReports.map((r) => (type: r.type, values: r.values)),
      );
      var lossPercent = 0.0;
      if (_hasPrevStatsSample) {
        lossPercent = CallQualityEngine.computeLossPercent(
          prevLost: _prevPacketsLost,
          prevReceived: _prevPacketsReceived,
          currLost: sample.packetsLost,
          currReceived: sample.packetsReceived,
        );
      }
      _prevPacketsLost = sample.packetsLost;
      _prevPacketsReceived = sample.packetsReceived;
      _hasPrevStatsSample = true;

      final tier = CallQualityEngine.evaluateTier(
        rttMs: sample.rttMs,
        lossPercent: lossPercent,
        reconnecting: _restartingIce || status == 'disconnected' || status == 'reconnecting',
      );
      networkStatsNotifier.value = CallNetworkStats(
        tier: tier,
        rttMs: sample.rttMs?.round(),
        lossPercent: lossPercent,
        dataSaver: dataSaver,
        reconnecting: tier == CallQualityTier.reconnecting,
      );
      final targetProfile = CallQualityEngine.profileFor(
        tier,
        dataSaver: dataSaver,
        lowRamDevice: LikedinAppearance.isLowRamDevice,
      );
      if (targetProfile != _appliedProfile) {
        await _applyEncodingProfile(targetProfile);
      }
    } catch (error) {
      debugPrint('WebRTC stats poll skipped: $error');
    }
  }

  Future<void> _applyEncodingProfile(CallQualityProfile profile) async {
    _appliedProfile = profile;
    // 1. Protect voice audio bitrate floor.
    final aSender = _audioSender;
    if (aSender != null) {
      try {
        final params = aSender.parameters;
        final encodings = params.encodings;
        if (encodings != null && encodings.isNotEmpty) {
          encodings.first.maxBitrate = profile.maxAudioBitrateBps;
          await aSender.setParameters(params);
        }
      } catch (_) {}
    }
    // 2. Dynamically tune outgoing video bitrate, framerate, and downscale factor.
    final vSender = _videoSender;
    if (video && camera && vSender != null) {
      try {
        final params = vSender.parameters;
        params.degradationPreference = RTCDegradationPreference.BALANCED;
        final encodings = params.encodings;
        if (encodings != null && encodings.isNotEmpty) {
          encodings.first.maxBitrate = profile.maxVideoBitrateBps;
          encodings.first.maxFramerate = profile.maxFramerate;
          encodings.first.scaleResolutionDownBy = profile.scaleResolutionDownBy;
          await vSender.setParameters(params);
        }
      } catch (error) {
        debugPrint('Adaptive video setParameters skipped: $error');
      }
    }
  }

  Future<void> start(String recipient, {required bool withVideo}) async {
    if (uid.isEmpty) throw StateError('Sign in again before starting a call.');
    _disposeFuture = null;
    _terminalizing = false;
    _seenIceSignalIds.clear();
    _pendingCandidates.clear();
    _remoteDescriptionReady = false;
    _applyingRemoteAnswer = false;
    _makingOffer = false;
    _restartingIce = false;
    _appliedProfile = null;
    _lastTransportKey = null;
    _speakerOverriddenByUser = false;
    camera = withVideo;
    video = withVideo;
    peerId = recipient;
    callId = _uuid.v4();
    status = 'calling';
    var callRowInserted = false;
    try {
      await _applyInitialAudioRoute();
      await _createPeer();
      _makingOffer = true;
      RTCSessionDescription tunedOffer;
      try {
        final rawOffer = await _pc!.createOffer();
        final tunedSdp = CallQualityEngine.tuneSdpForVoiceAndHardwareVideo(
          rawOffer.sdp ?? '',
          dataSaver: dataSaver,
        );
        tunedOffer = RTCSessionDescription(tunedSdp, rawOffer.type);
      } finally {
        _makingOffer = false;
      }

      await client.from('likedin_calls').insert({
        'id': callId,
        'caller_id': uid,
        'callee_id': recipient,
        'call_type': video ? 'video' : 'audio',
        'status': 'ringing',
      });
      callRowInserted = true;
      await CallAlertController.startOutgoing();
      _ringTimer?.cancel();
      _ringTimer = Timer(const Duration(seconds: 45), () async {
        if (status == 'calling' && callId != null) {
          _terminalizing = true;
          try {
            await client.rpc('likedin_update_call_status', params: {
              'p_call_id': callId,
              'p_new_status': 'missed',
            });
          } catch (_) {}
          try {
            await _send('end', {'reason': 'no_answer'});
          } catch (_) {}
          _emitStatus('missed');
          await dispose();
        }
      });
      _listen();
      _startSignalCatchup();
      await _pc!.setLocalDescription(tunedOffer);
      await _send('offer', {'sdp': tunedOffer.sdp, 'type': tunedOffer.type});
      if (!_changes.isClosed) _changes.add(status);
    } catch (_) {
      _terminalizing = true;
      final id = callId;
      if (callRowInserted && id != null) {
        try {
          await client.rpc('likedin_update_call_status', params: {
            'p_call_id': id,
            'p_new_status': 'failed',
          });
        } catch (_) {}
        try {
          await _send('end', {'reason': 'setup_failed'});
        } catch (_) {}
      }
      status = 'failed';
      await dispose();
      rethrow;
    }
  }

  Future<void> accept(String id, String caller, Map<String, dynamic> offer, {required bool withVideo}) async {
    if (uid.isEmpty) throw StateError('Sign in again before answering a call.');
    _disposeFuture = null;
    _terminalizing = false;
    _seenIceSignalIds.clear();
    _pendingCandidates.clear();
    _remoteDescriptionReady = false;
    _applyingRemoteAnswer = false;
    _makingOffer = false;
    _restartingIce = false;
    _appliedProfile = null;
    _lastTransportKey = null;
    _speakerOverriddenByUser = false;
    callId = id;
    peerId = caller;
    video = withVideo;
    camera = withVideo;
    status = 'connecting';
    var acceptedStatusCommitted = false;
    try {
      await _applyInitialAudioRoute();
      _listen();
      _startSignalCatchup();
      await _createPeer();
      await _pc!.setRemoteDescription(
        RTCSessionDescription(offer['sdp'] as String, offer['type'] as String),
      );
      _remoteDescriptionReady = true;
      final existing = await client
          .from('likedin_call_signals')
          .select('id,sender_id,kind,payload')
          .eq('call_id', id)
          .eq('kind', 'ice')
          .neq('sender_id', uid)
          .order('created_at');
      for (final row in existing) {
        await _consumeIceSignal(Map<String, dynamic>.from(row));
      }
      for (final c in _pendingCandidates) {
        await _pc!.addCandidate(c);
      }
      _pendingCandidates.clear();
      final rawAnswer = await _pc!.createAnswer();
      final tunedSdp = CallQualityEngine.tuneSdpForVoiceAndHardwareVideo(
        rawAnswer.sdp ?? '',
        dataSaver: dataSaver,
      );
      final tunedAnswer = RTCSessionDescription(tunedSdp, rawAnswer.type);
      await _pc!.setLocalDescription(tunedAnswer);
      await client.rpc('likedin_update_call_status', params: {
        'p_call_id': id,
        'p_new_status': 'accepted',
      });
      acceptedStatusCommitted = true;
      await _send('answer', {'sdp': tunedAnswer.sdp, 'type': tunedAnswer.type});
      if (!_changes.isClosed) _changes.add(status);
    } catch (_) {
      _terminalizing = true;
      try {
        await client.rpc('likedin_update_call_status', params: {
          'p_call_id': id,
          'p_new_status': acceptedStatusCommitted ? 'failed' : 'rejected',
        });
      } catch (_) {}
      await dispose();
      rethrow;
    }
  }

  Future<void> _consumeIceSignal(Map<String, dynamic> row) async {
    final signalId = row['id']?.toString();
    if (signalId != null && signalId.isNotEmpty && !_seenIceSignalIds.add(signalId)) return;
    final data = Map<String, dynamic>.from(row['payload'] as Map);
    if (data['candidate'] == null || _pc == null) return;
    final candidate = RTCIceCandidate(data['candidate'], data['sdpMid'], data['sdpMLineIndex']);
    if (_remoteDescriptionReady) {
      await _pc!.addCandidate(candidate);
    } else {
      _pendingCandidates.add(candidate);
    }
  }

  Future<void> _handleIncomingSignal(Map<String, dynamic> row) async {
    final kind = row['kind']?.toString();
    final data = row['payload'] is Map
        ? Map<String, dynamic>.from(row['payload'] as Map)
        : <String, dynamic>{};
    final isIceRestart = data['iceRestart'] == true;

    if (kind == 'offer' && isIceRestart && _pc != null && _remoteDescriptionReady && data['sdp'] != null) {
      // Glare-safe ICE-restart renegotiation (e.g. peer switched Wi-Fi -> 4G).
      final offerCollision = _makingOffer ||
          _pc!.signalingState != RTCSignalingState.RTCSignalingStateStable;
      final polite = CallQualityEngine.isPoliteIcePeer(
        localUid: uid,
        peerUid: peerId ?? '',
      );
      if (offerCollision && !polite) {
        debugPrint('Ignoring colliding remote ICE-restart offer (impolite peer)');
        return;
      }
      _restartingIce = true;
      await _pc!.setRemoteDescription(
        RTCSessionDescription(data['sdp'].toString(), data['type']?.toString() ?? 'offer'),
      );
      for (final c in _pendingCandidates) {
        await _pc!.addCandidate(c);
      }
      _pendingCandidates.clear();
      final rawAnswer = await _pc!.createAnswer();
      final tunedSdp = CallQualityEngine.tuneSdpForVoiceAndHardwareVideo(
        rawAnswer.sdp ?? '',
        dataSaver: dataSaver,
      );
      final tunedAnswer = RTCSessionDescription(tunedSdp, rawAnswer.type);
      await _pc!.setLocalDescription(tunedAnswer);
      await _send('answer', {
        'sdp': tunedAnswer.sdp,
        'type': tunedAnswer.type,
        'iceRestart': true,
        if (data['gen'] != null) 'gen': data['gen'],
      });
      return;
    }

    if (kind == 'answer' && _pc != null && !_applyingRemoteAnswer && data['sdp'] != null) {
      final acceptInitial = !_remoteDescriptionReady && !isIceRestart;
      final acceptRestart = _remoteDescriptionReady &&
          isIceRestart &&
          _pc!.signalingState == RTCSignalingState.RTCSignalingStateHaveLocalOffer;
      if (acceptInitial || acceptRestart) {
        _applyingRemoteAnswer = true;
        try {
          await CallAlertController.stop();
          _ringTimer?.cancel();
          await _pc!.setRemoteDescription(
            RTCSessionDescription(data['sdp'].toString(), data['type']?.toString() ?? 'answer'),
          );
          _remoteDescriptionReady = true;
          for (final c in _pendingCandidates) {
            await _pc!.addCandidate(c);
          }
          _pendingCandidates.clear();
          _emitStatus(acceptRestart ? 'reconnecting' : 'connecting');
        } finally {
          _applyingRemoteAnswer = false;
        }
      }
      return;
    }

    if (kind == 'ice' && _pc != null) {
      await _consumeIceSignal(row);
      return;
    }

    if (kind == 'end' || kind == 'reject') {
      final terminalStatus = kind == 'reject' ? 'rejected' : 'ended';
      _terminalizing = true;
      await dispose();
      _emitStatus(terminalStatus);
    }
  }

  Future<void> _failCall(String reason) async {
    if (_terminalizing) return;
    _terminalizing = true;
    debugPrint('Likedin call terminating after failure: $reason');
    final id = callId;
    if (id != null) {
      try {
        await client.rpc('likedin_update_call_status', params: {
          'p_call_id': id,
          'p_new_status': 'failed',
        });
      } catch (error) {
        debugPrint('Could not persist failed call status: $error');
      }
      try {
        await _send('end', {'reason': reason});
      } catch (error) {
        debugPrint('Could not signal failed call termination: $error');
      }
    }
    await dispose();
    _emitStatus('failed');
  }

  void _listen() {
    final gen = ++_channelGeneration;
    _channel = client
        .channel('call-$callId-${uid.length >= 6 ? uid.substring(0, 6) : uid}-$gen')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'likedin_call_signals',
          filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'call_id', value: callId),
          callback: (payload) async {
            final row = Map<String, dynamic>.from(payload.newRecord);
            if (row['sender_id'] == uid) return;
            final signalId = row['id']?.toString();
            if (signalId != null && signalId.isNotEmpty && !_seenIceSignalIds.add('signal:$signalId')) return;
            try {
              await _handleIncomingSignal(row);
            } catch (error, stackTrace) {
              debugPrint('Call signaling failed: $error\n$stackTrace');
              await _failCall('Call signaling failed. Please check your connection and try again.');
            }
          },
        )
      ..subscribe();
  }

  void _startSignalCatchup() {
    _signalCatchupTimer?.cancel();
    _signalCatchupTimer = Timer.periodic(const Duration(seconds: 4), (_) {
      unawaited(_catchUpSignals());
    });
    unawaited(_catchUpSignals());
  }

  Future<void> _catchUpSignals() async {
    final id = callId;
    if (id == null || _catchingUpSignals || _terminalizing || _pc == null) return;
    _catchingUpSignals = true;
    try {
      final rows = await client
          .from('likedin_call_signals')
          .select('id,sender_id,kind,payload')
          .eq('call_id', id)
          .neq('sender_id', uid)
          .order('created_at');
      for (final raw in rows) {
        final row = Map<String, dynamic>.from(raw);
        final signalId = row['id']?.toString();
        if (signalId != null && !_seenIceSignalIds.add('signal:$signalId')) continue;
        await _handleIncomingSignal(row);
        if (_terminalizing) break;
      }
    } catch (error) {
      debugPrint('Call signal catch-up failed: $error');
    } finally {
      _catchingUpSignals = false;
    }
  }

  Future<void> _send(String kind, Map<String, dynamic> payload) async {
    await client.from('likedin_call_signals').insert({
      'call_id': callId,
      'sender_id': uid,
      'kind': kind,
      'payload': payload,
    });
  }

  Future<void> toggleMute() async {
    muted = !muted;
    for (final t in _local?.getAudioTracks() ?? []) {
      t.enabled = !muted;
    }
    if (!_changes.isClosed) _changes.add(status);
  }

  /// Battery-saving camera toggle: turning video OFF stops and releases the
  /// Android Camera2 hardware sensor (`replaceTrack(null)` + `track.stop()`)
  /// instead of leaving the sensor powered on sending black frames.
  Future<void> toggleCamera() async {
    if (!video || _togglingCamera || _terminalizing) return;
    _togglingCamera = true;
    try {
      if (camera) {
        camera = false;
        final existingTracks = List<MediaStreamTrack>.of(_local?.getVideoTracks() ?? const []);
        try {
          await _videoSender?.replaceTrack(null);
        } catch (error) {
          debugPrint('replaceTrack(null) fallback to track.enabled=false: $error');
          for (final t in existingTracks) {
            t.enabled = false;
          }
          if (!_changes.isClosed) _changes.add(status);
          return;
        }
        if (_renderersInitialized) {
          _localRenderer.srcObject = null;
        }
        for (final t in existingTracks) {
          try {
            await _local?.removeTrack(t);
          } catch (_) {}
          try {
            await t.stop();
          } catch (_) {}
        }
      } else {
        final freshStream = await navigator.mediaDevices.getUserMedia({
          'audio': false,
          'video': _videoConstraints(),
        });
        final freshTracks = freshStream.getVideoTracks();
        if (freshTracks.isEmpty) {
          await freshStream.dispose();
          return;
        }
        final newTrack = freshTracks.first;
        if (_terminalizing || _pc == null) {
          await newTrack.stop();
          await freshStream.dispose();
          return;
        }
        await _videoSender?.replaceTrack(newTrack);
        if (_local != null) {
          await _local!.addTrack(newTrack);
        } else {
          _local = freshStream;
        }
        if (_renderersInitialized) {
          _localRenderer.srcObject = _local;
        }
        camera = true;
        final currentProfile = _appliedProfile ??
            CallQualityEngine.profileFor(
              networkStatsNotifier.value.tier,
              dataSaver: dataSaver,
              lowRamDevice: LikedinAppearance.isLowRamDevice,
            );
        await _applyEncodingProfile(currentProfile);
      }
      if (!_changes.isClosed) _changes.add(status);
    } catch (error) {
      debugPrint('Camera toggle failed: $error');
    } finally {
      _togglingCamera = false;
    }
  }

  Future<void> switchCamera() async {
    if (!camera) {
      usingFrontCamera = !usingFrontCamera;
      if (!_changes.isClosed) _changes.add(status);
      return;
    }
    final tracks = _local?.getVideoTracks() ?? [];
    if (tracks.isEmpty) return;
    await Helper.switchCamera(tracks.first);
    usingFrontCamera = !usingFrontCamera;
    if (!_changes.isClosed) _changes.add(status);
  }

  Future<void> toggleSpeaker() async {
    final next = !speaker;
    _speakerOverriddenByUser = true;
    await Helper.setSpeakerphoneOn(next);
    speaker = next;
    if (!_changes.isClosed) _changes.add(status);
  }

  /// Toggles Data & Battery Saver mode live during a call, immediately capping
  /// outgoing video bitrate/framerate and Opus audio bandwidth.
  Future<void> toggleDataSaver() async {
    dataSaver = !dataSaver;
    final current = networkStatsNotifier.value;
    networkStatsNotifier.value = CallNetworkStats(
      tier: current.tier,
      rttMs: current.rttMs,
      lossPercent: current.lossPercent,
      dataSaver: dataSaver,
      reconnecting: current.reconnecting,
    );
    await _applyEncodingProfile(
      CallQualityEngine.profileFor(
        current.tier,
        dataSaver: dataSaver,
        lowRamDevice: LikedinAppearance.isLowRamDevice,
      ),
    );
    if (!_changes.isClosed) _changes.add(status);
  }

  Future<void> end({bool rejected = false}) async {
    if (_terminalizing) return;
    _terminalizing = true;
    final id = callId;
    if (id == null) {
      await dispose();
      _emitStatus(rejected ? 'rejected' : 'ended');
      return;
    }
    await CallAlertController.stop();
    _ringTimer?.cancel();
    _signalCatchupTimer?.cancel();
    _statsTimer?.cancel();
    _disconnectGraceTimer?.cancel();
    try {
      await _send(rejected ? 'reject' : 'end', {});
    } catch (_) {}
    try {
      await client.rpc('likedin_update_call_status', params: {
        'p_call_id': id,
        'p_new_status': rejected ? 'rejected' : 'ended',
      });
    } catch (_) {}
    await dispose();
    _emitStatus(rejected ? 'rejected' : 'ended');
  }

  Future<void> dispose() => _disposeFuture ??= _disposeResources();

  Future<void> _disposeResources() async {
    await CallAlertController.stop();
    await CallAlertController.stopCallService();
    _ringTimer?.cancel();
    _signalCatchupTimer?.cancel();
    _statsTimer?.cancel();
    _disconnectGraceTimer?.cancel();
    _signalCatchupTimer = null;
    _ringTimer = null;
    _statsTimer = null;
    _disconnectGraceTimer = null;

    final connSub = _connectivitySub;
    _connectivitySub = null;
    if (connSub != null) {
      try {
        await connSub.cancel();
      } catch (_) {}
    }

    final channel = _channel;
    _channel = null;
    if (channel != null) {
      try {
        await client.removeChannel(channel);
      } catch (_) {}
    }

    _videoSender = null;
    _audioSender = null;
    final peer = _pc;
    _pc = null;
    if (peer != null) {
      try {
        await peer.close();
      } catch (_) {}
    }

    final local = _local;
    _local = null;
    if (local != null) {
      for (final track in local.getTracks()) {
        try {
          await track.stop();
        } catch (_) {}
      }
      try {
        await local.dispose();
      } catch (_) {}
    }

    if (_renderersInitialized) {
      try {
        _localRenderer.srcObject = null;
        _remote.srcObject = null;
        await _localRenderer.dispose();
        await _remote.dispose();
      } catch (_) {}
      _renderersInitialized = false;
    }
    networkStatsNotifier.dispose();
    if (!_changes.isClosed) {
      await _changes.close();
    }
  }
}
