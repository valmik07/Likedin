# Likedin v2.6.1+131 — OriginOS 7 Edition (Critical Tap-Cancellation Fix)

## Fixed in v2.6.1+131
- **Fixed broken taps on Chat card, Bottom Dock tabs, Call buttons, and Gradient buttons (`lib/ui/glassmorphism.dart`):**
  - `LikedinPressScale` previously conditionally wrapped its child in a `Stack` when `onPointerDown` activated the Dynamic Glow effect, causing Flutter to unmount/remount descendant `InkWell` gesture recognizers mid-touch and silently cancel `onTap`.
  - Replaced the conditional `Stack` with an always-present `CustomPaint(foregroundPainter: ...)` so the widget tree never changes shape during a touch, preserving spring squish, Dynamic Glow, and 100% reliable taps.
- **Added automated Flutter widget tap-regression tests** in `test/origin_os_design_test.dart` covering `LikedinPressScale` + `InkWell` and every tab in `OriginFloatingDock`.
