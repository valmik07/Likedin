import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'origin_fluid_physics.dart';
import 'origin_haptics.dart';
import 'origin_motion_presets.dart';
import 'origin_spring_physics.dart';

/// Physics-driven, interruptible, interactive edge-swipe-back navigation route
/// inspired by OriginOS 7.
///
/// Features:
///  * Velocity-preserving spring slide + subtle background depth scale.
///  * Interactive left-edge swipe back that follows the finger 1:1, can be
///    reversed mid-gesture, and commits or rebounds with true spring physics.
class OriginPageRoute<T> extends PageRoute<T> {
  OriginPageRoute({
    required this.builder,
    super.settings,
    super.fullscreenDialog = false,
    this.maintainStateValue = true,
    this.enableInteractiveBack = true,
  });

  final WidgetBuilder builder;
  final bool maintainStateValue;
  final bool enableInteractiveBack;

  @override
  bool get maintainState => maintainStateValue;

  @override
  Duration get transitionDuration => OriginMotionEngine.reduceMotion.value
      ? Duration.zero
      : const Duration(milliseconds: 340);

  @override
  Duration get reverseTransitionDuration => OriginMotionEngine.reduceMotion.value
      ? Duration.zero
      : const Duration(milliseconds: 280);

  @override
  Color? get barrierColor => null;

  @override
  String? get barrierLabel => null;

  @override
  Widget buildPage(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
  ) {
    final page = builder(context);
    if (!enableInteractiveBack || fullscreenDialog) return page;
    return _OriginInteractiveBackWrapper(
      route: this,
      child: page,
    );
  }

  @override
  Widget buildTransitions(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    if (OriginMotionEngine.reduceMotion.value) return child;

    final primaryCurve = CurvedAnimation(
      parent: animation,
      curve: Curves.easeOutCubic,
      reverseCurve: Curves.easeInCubic,
    );
    final secondaryCurve = CurvedAnimation(
      parent: secondaryAnimation,
      curve: Curves.easeOutCubic,
      reverseCurve: Curves.easeInCubic,
    );

    final Offset beginOffset = fullscreenDialog
        ? const Offset(0.0, 0.08)
        : const Offset(1.0, 0.0);

    return AnimatedBuilder(
      animation: Listenable.merge(<Listenable>[primaryCurve, secondaryCurve]),
      child: child,
      builder: (context, builtChild) {
        final t = primaryCurve.value;
        final sec = secondaryCurve.value;
        final slideIn = Offset.lerp(beginOffset, Offset.zero, t)!;
        final slideBack = fullscreenDialog
            ? Offset.zero
            : Offset(-0.22 * sec, 0.0);
        final scale = (1.0 - 0.035 * sec) * (fullscreenDialog ? (0.96 + 0.04 * t) : 1.0);
        final opacity = fullscreenDialog ? t.clamp(0.0, 1.0).toDouble() : 1.0;

        return FractionalTranslation(
          translation: slideIn + slideBack,
          child: Transform.scale(
            scale: scale,
            child: opacity < 0.999
                ? Opacity(opacity: opacity, child: builtChild)
                : builtChild,
          ),
        );
      },
    );
  }

  bool _beginInteractiveBackGesture() {
    if (!isCurrent || isFirst || controller == null) return false;
    navigator?.didStartUserGesture();
    return true;
  }

  void _updateInteractiveBackGesture(double deltaFraction) {
    final ctrl = controller;
    if (ctrl == null) return;
    ctrl.value = (ctrl.value - deltaFraction).clamp(0.0, 1.0).toDouble();
  }

  void _endInteractiveBackGesture({
    required double velocityPx,
    required double width,
  }) {
    final ctrl = controller;
    final nav = navigator;
    if (ctrl == null || nav == null) return;
    final shouldPop = velocityPx > 520.0 || (velocityPx >= -180.0 && ctrl.value < 0.62);
    if (shouldPop) {
      OriginHaptics.gestureComplete();
      nav.pop();
    } else {
      final normVel = (-velocityPx / width).clamp(-6.0, 6.0).toDouble();
      ctrl.animateWith(
        OriginSpringPhysics.createSimulation(
          spec: OriginMotionPresets.page,
          start: ctrl.value,
          end: 1.0,
          velocity: normVel,
          adaptVelocity: false,
        ),
      );
    }
    nav.didStopUserGesture();
  }

  void _cancelInteractiveBackGesture() {
    final ctrl = controller;
    if (ctrl != null) {
      ctrl.animateWith(
        OriginSpringPhysics.createSimulation(
          spec: OriginMotionPresets.page,
          start: ctrl.value,
          end: 1.0,
          velocity: 0.0,
          adaptVelocity: false,
        ),
      );
    }
    navigator?.didStopUserGesture();
  }
}

class _OriginInteractiveBackWrapper extends StatefulWidget {
  const _OriginInteractiveBackWrapper({
    required this.route,
    required this.child,
  });

  final OriginPageRoute<dynamic> route;
  final Widget child;

  @override
  State<_OriginInteractiveBackWrapper> createState() =>
      _OriginInteractiveBackWrapperState();
}

class _OriginInteractiveBackWrapperState
    extends State<_OriginInteractiveBackWrapper> {
  bool _dragging = false;

  void _onDragStart(DragStartDetails details) {
    if (!widget.route._beginInteractiveBackGesture()) return;
    _dragging = true;
    OriginHaptics.dragStart();
  }

  void _onDragUpdate(DragUpdateDetails details) {
    if (!_dragging) return;
    final width = math.max(1.0, MediaQuery.sizeOf(context).width);
    widget.route._updateInteractiveBackGesture((details.primaryDelta ?? 0.0) / width);
  }

  void _onDragEnd(DragEndDetails details) {
    if (!_dragging) return;
    _dragging = false;
    final width = math.max(1.0, MediaQuery.sizeOf(context).width);
    widget.route._endInteractiveBackGesture(
      velocityPx: details.velocity.pixelsPerSecond.dx,
      width: width,
    );
  }

  void _onDragCancel() {
    if (!_dragging) return;
    _dragging = false;
    widget.route._cancelInteractiveBackGesture();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        widget.child,
        Positioned(
          left: 0,
          top: 0,
          bottom: 0,
          width: 24,
          child: GestureDetector(
            behavior: HitTestBehavior.translucent,
            onHorizontalDragStart: _onDragStart,
            onHorizontalDragUpdate: _onDragUpdate,
            onHorizontalDragEnd: _onDragEnd,
            onHorizontalDragCancel: _onDragCancel,
          ),
        ),
      ],
    );
  }
}

/// Physics-driven OriginOS 7 bottom sheet with direct finger following, elastic
/// top boundary resistance, velocity-aware snap/dismissal, and liquid emergence.
Future<T?> showOriginBottomSheet<T>({
  required BuildContext context,
  required WidgetBuilder builder,
  Color barrierColor = const Color(0x75000000),
  bool isDismissible = true,
  List<double> snapFractions = const <double>[1.0],
}) {
  OriginHaptics.menuExpand();
  return Navigator.of(context).push<T>(
    OriginModalSheetRoute<T>(
      builder: builder,
      barrierColorValue: barrierColor,
      isDismissible: isDismissible,
      snapFractions: snapFractions,
    ),
  );
}

class OriginModalSheetRoute<T> extends PopupRoute<T> {
  OriginModalSheetRoute({
    required this.builder,
    required this.barrierColorValue,
    this.isDismissible = true,
    this.snapFractions = const <double>[1.0],
  });

  final WidgetBuilder builder;
  final Color barrierColorValue;
  final bool isDismissible;
  final List<double> snapFractions;

  @override
  Color? get barrierColor => barrierColorValue;

  @override
  bool get barrierDismissible => isDismissible;

  @override
  String? get barrierLabel => 'Dismiss sheet';

  @override
  Duration get transitionDuration => OriginMotionEngine.reduceMotion.value
      ? Duration.zero
      : const Duration(milliseconds: 280);

  @override
  Duration get reverseTransitionDuration => OriginMotionEngine.reduceMotion.value
      ? Duration.zero
      : const Duration(milliseconds: 220);

  @override
  Widget buildPage(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
  ) {
    return _OriginPhysicsSheetHost(
      animation: animation,
      isDismissible: isDismissible,
      snapFractions: snapFractions,
      child: builder(context),
    );
  }
}

class _OriginPhysicsSheetHost extends StatefulWidget {
  const _OriginPhysicsSheetHost({
    required this.animation,
    required this.isDismissible,
    required this.snapFractions,
    required this.child,
  });

  final Animation<double> animation;
  final bool isDismissible;
  final List<double> snapFractions;
  final Widget child;

  @override
  State<_OriginPhysicsSheetHost> createState() => _OriginPhysicsSheetHostState();
}

class _OriginPhysicsSheetHostState extends State<_OriginPhysicsSheetHost>
    with SingleTickerProviderStateMixin {
  late final AnimationController _dragCtrl = AnimationController.unbounded(
    vsync: this,
    value: 0.0,
  );
  double _rawDragY = 0.0;
  double _lastVelocityY = 0.0;
  bool _dismissing = false;

  void _springTo(double target, {double velocity = 0.0}) {
    if (OriginMotionEngine.reduceMotion.value) {
      _dragCtrl.value = target;
      return;
    }
    _dragCtrl.animateWith(
      OriginSpringPhysics.createSimulation(
        spec: OriginMotionPresets.sheet,
        start: _dragCtrl.value,
        end: target,
        velocity: velocity.clamp(-3200.0, 3200.0).toDouble(),
      ),
    );
  }

  void _onDragStart(DragStartDetails details) {
    _dragCtrl.stop(canceled: false);
    _rawDragY = _dragCtrl.value < 0
        ? OriginSpringPhysics.inverseRubberBand(_dragCtrl.value, 54.0)
        : _dragCtrl.value;
    _lastVelocityY = 0.0;
  }

  void _onDragUpdate(DragUpdateDetails details) {
    if (_dismissing) return;
    final dy = details.primaryDelta ?? 0.0;
    _rawDragY += dy;
    _lastVelocityY = dy * 60.0;
    if (_rawDragY < 0.0) {
      // Elastic resistance when pulling upward past the top boundary.
      _dragCtrl.value = OriginSpringPhysics.rubberBand(_rawDragY, 54.0);
    } else {
      _dragCtrl.value = _rawDragY;
    }
  }

  void _onDragEnd(DragEndDetails details) {
    if (_dismissing) return;
    final vy = details.velocity.pixelsPerSecond.dy;
    final current = _dragCtrl.value;
    final screenH = MediaQuery.sizeOf(context).height;
    final dismissThreshold = math.min(130.0, screenH * 0.22);

    if (widget.isDismissible && (current > dismissThreshold || vy > 720.0)) {
      _dismissing = true;
      OriginHaptics.gestureComplete();
      Navigator.of(context).pop();
      return;
    }

    // Multi-snap support if extra snap offsets are configured.
    double targetY = 0.0;
    if (widget.snapFractions.length > 1) {
      final projected = OriginSpringPhysics.projectPosition(
        position: current,
        velocity: vy,
      );
      final sorted = List<double>.of(widget.snapFractions)..sort();
      final maxF = sorted.last;
      final candidates = sorted
          .map((f) => ((maxF - f) * screenH * 0.65).clamp(0.0, screenH * 0.5))
          .toList(growable: false);
      targetY = candidates.reduce(
        (a, b) => (a - projected).abs() <= (b - projected).abs() ? a : b,
      );
    }

    OriginHaptics.snapArrival();
    _rawDragY = targetY;
    _springTo(targetY, velocity: vy);
  }

  void _onDragCancel() {
    if (_dismissing) return;
    _rawDragY = 0.0;
    _springTo(0.0);
  }

  @override
  void dispose() {
    _dragCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final entrance = CurvedAnimation(
      parent: widget.animation,
      curve: Curves.easeOutBack,
      reverseCurve: Curves.easeInCubic,
    );

    return Align(
      alignment: Alignment.bottomCenter,
      child: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onVerticalDragStart: _onDragStart,
        onVerticalDragUpdate: _onDragUpdate,
        onVerticalDragEnd: _onDragEnd,
        onVerticalDragCancel: _onDragCancel,
        child: AnimatedBuilder(
          animation: Listenable.merge(<Listenable>[entrance, _dragCtrl]),
          child: widget.child,
          builder: (context, sheetChild) {
            final enterT = OriginMotionEngine.reduceMotion.value
                ? 1.0
                : entrance.value;
            final dragY = _dragCtrl.value;
            final pullUpStretch = dragY < 0.0
                ? (1.0 + (dragY.abs() / 680.0).clamp(0.0, 0.06))
                : 1.0;
            final pullUpSqueezeX = dragY < 0.0
                ? (1.0 - (dragY.abs() / 1600.0).clamp(0.0, 0.025))
                : 1.0;
            final slideY = (1.0 - enterT) * 72.0 + dragY;
            final scaleY = (0.94 + 0.06 * enterT).clamp(0.92, 1.04) * pullUpStretch;
            final scaleX = (0.96 + 0.04 * enterT).clamp(0.94, 1.03) * pullUpSqueezeX;
            final fluid = OriginFluidPhysics.computeDeformation(
              displacement: Offset(0, dragY < 0 ? dragY : 0),
              velocity: Offset(0, _lastVelocityY * 0.12),
              maxStretch: 0.05,
            );

            return Transform.translate(
              offset: Offset(0, slideY),
              child: Transform(
                alignment: Alignment.bottomCenter,
                transform: Matrix4.diagonal3Values(
                  scaleX * fluid.compressAcross,
                  scaleY * (1.0 + (fluid.stretchAlong - 1.0) * 0.4),
                  1.0,
                ),
                child: Opacity(
                  opacity: widget.animation.value.clamp(0.0, 1.0).toDouble(),
                  child: sheetChild,
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
