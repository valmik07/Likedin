import 'dart:math' as math;

import 'package:flutter/widgets.dart';

import 'origin_motion_presets.dart';

/// Computed directional liquid deformation parameters for an interactive surface.
class OriginFluidState {
  const OriginFluidState({
    required this.direction,
    required this.stretchAlong,
    required this.compressAcross,
    required this.pullVector,
    required this.intensity,
  });

  static const OriginFluidState rest = OriginFluidState(
    direction: Offset.zero,
    stretchAlong: 1.0,
    compressAcross: 1.0,
    pullVector: Offset.zero,
    intensity: 0.0,
  );

  /// Unit vector of active movement/pull (horizontal, vertical, or diagonal).
  final Offset direction;

  /// Extension factor along [direction] (`>= 1.0`, clamped to keep text legible).
  final double stretchAlong;

  /// Area-preserving compression orthogonal to [direction] (`<= 1.0`).
  final double compressAcross;

  /// Local pixel pull offset applied to the leading boundary toward the finger.
  final Offset pullVector;

  /// Normalized deformation intensity in `[0.0, 1.0]`.
  final double intensity;

  bool get isRest => intensity < 0.003;

  /// Builds a gentle, readable 2D stretch/squeeze transform aligned with
  /// [direction] (supports horizontal, vertical, and arbitrary diagonal angles)
  /// without ever distorting text beyond readability limits.
  Matrix4 buildContentTransform(Size size) {
    if (isRest || size.isEmpty) return Matrix4.identity();
    final angle = math.atan2(direction.dy, direction.dx);
    // Keep inner content stretch much gentler than the outer liquid boundary so
    // labels and photos stay crisp and readable!
    final contentAlong = 1.0 + (stretchAlong - 1.0) * 0.35;
    final contentAcross = 1.0 - (1.0 - compressAcross) * 0.35;
    final cx = size.width * 0.5;
    final cy = size.height * 0.5;
    final m = Matrix4.identity()
      ..translate(cx, cy)
      ..rotateZ(angle)
      ..scale(contentAlong, contentAcross, 1.0)
      ..rotateZ(-angle)
      ..translate(-cx, -cy);
    return m;
  }
}

/// Computes physically coherent liquid boundary deformation and metaball-style
/// droplet separation / merging geometry.
class OriginFluidPhysics {
  OriginFluidPhysics._();

  /// Computes directional stretch, orthogonal area-preserving compression, and
  /// boundary pull vector from real displacement and pointer velocity.
  static OriginFluidState computeDeformation({
    required Offset displacement,
    Offset velocity = Offset.zero,
    double maxStretch = 0.14,
    double referenceDistance = 84.0,
    double? intensityOverride,
  }) {
    final scaleFactor =
        intensityOverride ?? OriginMotionEngine.effectiveDeformationIntensity;
    if (scaleFactor <= 0.0) return OriginFluidState.rest;

    // Combine displacement vector + velocity momentum vector for live responsiveness.
    final combined = displacement + velocity * 0.022;
    final mag = combined.distance;
    if (mag < 0.5) return OriginFluidState.rest;

    final dir = Offset(combined.dx / mag, combined.dy / mag);
    final rawNorm = (1.0 - 1.0 / (1.0 + mag / referenceDistance)).clamp(0.0, 1.0).toDouble();
    final intensity = (rawNorm * scaleFactor).clamp(0.0, 1.0).toDouble();

    final stretch = 1.0 + (maxStretch * intensity).clamp(0.0, 0.20).toDouble();
    // Area-preserving Poisson squeeze: compress = 1 / sqrt(stretch)
    final compress = (1.0 / math.sqrt(stretch)).clamp(0.88, 1.0).toDouble();
    final pullMag = (intensity * 10.5).clamp(0.0, 14.0).toDouble();

    return OriginFluidState(
      direction: dir,
      stretchAlong: stretch,
      compressAcross: compress,
      pullVector: Offset(dir.dx * pullMag, dir.dy * pullMag),
      intensity: intensity,
    );
  }

  /// Generates a smooth cubic Bézier path for a rounded rectangle whose leading
  /// edges bulge organically in [state.pullVector] while the trailing edge
  /// remains softly anchored (supporting horizontal, vertical, and diagonal pull).
  static Path buildDeformedRRectPath(
    Size size,
    BorderRadius radius,
    OriginFluidState state,
  ) {
    final rect = Offset.zero & size;
    if (state.isRest || size.isEmpty) {
      return Path()..addRRect(radius.toRRect(rect));
    }

    final w = size.width;
    final h = size.height;
    final px = state.pullVector.dx;
    final py = state.pullVector.dy;
    final squeezeX = (1.0 - state.compressAcross) * w * 0.18 * state.direction.dy.abs();
    final squeezeY = (1.0 - state.compressAcross) * h * 0.18 * state.direction.dx.abs();

    final tl = math.min(radius.topLeft.x, math.min(w, h) * 0.48);
    final tr = math.min(radius.topRight.x, math.min(w, h) * 0.48);
    final br = math.min(radius.bottomRight.x, math.min(w, h) * 0.48);
    final bl = math.min(radius.bottomLeft.x, math.min(w, h) * 0.48);

    // Edge displacements: leading edge pulls with the finger; trailing edge lags slightly.
    final leftX = squeezeX + (px < 0 ? px * 0.55 : px * 0.12);
    final rightX = w - squeezeX + (px > 0 ? px * 0.55 : px * 0.12);
    final topY = squeezeY + (py < 0 ? py * 0.55 : py * 0.12);
    final bottomY = h - squeezeY + (py > 0 ? py * 0.55 : py * 0.12);

    // Mid-edge cubic Bézier control offsets create genuine curved liquid bulging.
    final topMidX = (leftX + rightX) * 0.5 + px * 0.35;
    final topMidY = topY + (py < 0 ? py * 0.42 : py * 0.08);
    final bottomMidX = (leftX + rightX) * 0.5 + px * 0.35;
    final bottomMidY = bottomY + (py > 0 ? py * 0.42 : py * 0.08);
    final rightMidX = rightX + (px > 0 ? px * 0.42 : px * 0.08);
    final rightMidY = (topY + bottomY) * 0.5 + py * 0.35;
    final leftMidX = leftX + (px < 0 ? px * 0.42 : px * 0.08);
    final leftMidY = (topY + bottomY) * 0.5 + py * 0.35;

    final path = Path()
      ..moveTo(leftX + tl, topY)
      ..quadraticBezierTo(topMidX, topMidY, rightX - tr, topY)
      ..quadraticBezierTo(rightX, topY, rightX, topY + tr)
      ..quadraticBezierTo(rightMidX, rightMidY, rightX, bottomY - br)
      ..quadraticBezierTo(rightX, bottomY, rightX - br, bottomY)
      ..quadraticBezierTo(bottomMidX, bottomMidY, leftX + bl, bottomY)
      ..quadraticBezierTo(leftX, bottomY, leftX, bottomY - bl)
      ..quadraticBezierTo(leftMidX, leftMidY, leftX, topY + tl)
      ..quadraticBezierTo(leftX, topY, leftX + tl, topY)
      ..close();
    return path;
  }

  /// Computes a geometrically coherent liquid metaball / water-droplet bridge
  /// connecting two circular/pill anchors ([centerA], [radiusA]) and
  /// ([centerB], [radiusB]) when their separation distance is within
  /// [maxBridgeDistance]. Returns `null` once the neck ruptures cleanly.
  static Path? buildLiquidBridgePath({
    required Offset centerA,
    required double radiusA,
    required Offset centerB,
    required double radiusB,
    double maxBridgeDistance = 72.0,
  }) {
    final delta = centerB - centerA;
    final dist = delta.distance;
    if (dist <= 0.5 || dist >= maxBridgeDistance + radiusA + radiusB) {
      return null;
    }

    final gap = math.max(0.0, dist - (radiusA + radiusB));
    final t = (1.0 - (gap / maxBridgeDistance)).clamp(0.0, 1.0).toDouble();
    if (t <= 0.02) return null;

    final ux = delta.dx / dist;
    final uy = delta.dy / dist;
    // Perpendicular unit normal
    final nx = -uy;
    final ny = ux;

    // Attachment half-widths taper smoothly as the droplets pull apart.
    final attachA = radiusA * (0.52 + 0.34 * t);
    final attachB = radiusB * (0.52 + 0.34 * t);
    final neckHalf = math.min(radiusA, radiusB) * (0.12 + 0.44 * t * t);

    final aOffset = centerA + Offset(ux * radiusA * 0.48, uy * radiusA * 0.48);
    final bOffset = centerB - Offset(ux * radiusB * 0.48, uy * radiusB * 0.48);

    final aTop = aOffset + Offset(nx * attachA, ny * attachA);
    final aBot = aOffset - Offset(nx * attachA, ny * attachA);
    final bTop = bOffset + Offset(nx * attachB, ny * attachB);
    final bBot = bOffset - Offset(nx * attachB, ny * attachB);

    final mid = Offset(
      (aOffset.dx + bOffset.dx) * 0.5,
      (aOffset.dy + bOffset.dy) * 0.5,
    );
    final ctrlTop = mid + Offset(nx * neckHalf, ny * neckHalf);
    final ctrlBot = mid - Offset(nx * neckHalf, ny * neckHalf);

    return Path()
      ..moveTo(aTop.dx, aTop.dy)
      ..quadraticBezierTo(ctrlTop.dx, ctrlTop.dy, bTop.dx, bTop.dy)
      ..lineTo(bBot.dx, bBot.dy)
      ..quadraticBezierTo(ctrlBot.dx, ctrlBot.dy, aBot.dx, aBot.dy)
      ..close();
  }
}

/// Paints a subtle OriginOS 7 liquid deformed surface contour & rim highlight.
class OriginLiquidBoundaryPainter extends CustomPainter {
  const OriginLiquidBoundaryPainter({
    required this.radius,
    required this.state,
    required this.fillColor,
    required this.rimColor,
  });

  final BorderRadius radius;
  final OriginFluidState state;
  final Color fillColor;
  final Color rimColor;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final path = OriginFluidPhysics.buildDeformedRRectPath(size, radius, state);
    canvas.drawPath(path, Paint()..color = fillColor);
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.1
        ..color = rimColor,
    );
  }

  @override
  bool shouldRepaint(covariant OriginLiquidBoundaryPainter old) =>
      old.radius != radius ||
      old.state.pullVector != state.pullVector ||
      old.state.intensity != state.intensity ||
      old.fillColor != fillColor ||
      old.rimColor != rimColor;
}

/// Paints a coherent liquid droplet separation/merging bridge between two
/// neighboring floating controls or surfaces.
class OriginMetaballBridgePainter extends CustomPainter {
  const OriginMetaballBridgePainter({
    required this.centerA,
    required this.radiusA,
    required this.centerB,
    required this.radiusB,
    required this.color,
    this.rimColor,
    this.maxBridgeDistance = 68.0,
  });

  final Offset centerA;
  final double radiusA;
  final Offset centerB;
  final double radiusB;
  final Color color;
  final Color? rimColor;
  final double maxBridgeDistance;

  @override
  void paint(Canvas canvas, Size size) {
    final path = OriginFluidPhysics.buildLiquidBridgePath(
      centerA: centerA,
      radiusA: radiusA,
      centerB: centerB,
      radiusB: radiusB,
      maxBridgeDistance: maxBridgeDistance,
    );
    if (path == null) return;
    canvas.drawPath(path, Paint()..color = color);
    if (rimColor != null) {
      canvas.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 0.9
          ..color = rimColor!,
      );
    }
  }

  @override
  bool shouldRepaint(covariant OriginMetaballBridgePainter old) =>
      old.centerA != centerA ||
      old.centerB != centerB ||
      old.radiusA != radiusA ||
      old.radiusB != radiusB ||
      old.color != color ||
      old.rimColor != rimColor ||
      old.maxBridgeDistance != maxBridgeDistance;
}
