import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/physics.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Immutable damped-spring specification (`m*x'' = -k*(x - target) - c*x'`).
class OriginSpringSpec {
  const OriginSpringSpec({
    required this.mass,
    required this.stiffness,
    required this.damping,
    this.distanceTolerance = 0.001,
    this.velocityTolerance = 0.005,
  });

  final double mass;
  final double stiffness;
  final double damping;
  final double distanceTolerance;
  final double velocityTolerance;

  SpringDescription get description => SpringDescription(
        mass: mass,
        stiffness: stiffness,
        damping: damping,
      );

  Tolerance get tolerance => Tolerance(
        distance: distanceTolerance,
        velocity: velocityTolerance,
      );

  /// Damping ratio zeta = c / (2 * sqrt(m * k)).
  /// `< 1.0` underdamped (natural overshoot), `>= 1.0` critically/overdamped.
  double get dampingRatio => damping / (2.0 * math.sqrt(mass * stiffness));

  OriginSpringSpec copyWith({
    double? mass,
    double? stiffness,
    double? damping,
    double? distanceTolerance,
    double? velocityTolerance,
  }) =>
      OriginSpringSpec(
        mass: mass ?? this.mass,
        stiffness: stiffness ?? this.stiffness,
        damping: damping ?? this.damping,
        distanceTolerance: distanceTolerance ?? this.distanceTolerance,
        velocityTolerance: velocityTolerance ?? this.velocityTolerance,
      );
}

/// Centralized OriginOS 7-inspired spring presets & velocity-adaptive tuning.
class OriginMotionPresets {
  OriginMotionPresets._();

  /// Balanced everyday spring (mass=1.0, stiffness=300, damping=22).
  static const OriginSpringSpec general = OriginSpringSpec(
    mass: 1.0,
    stiffness: 300.0,
    damping: 22.0,
  );

  /// Gentle, low-overshoot spring for subtle settles (mass=1.0, stiffness=220, damping=22).
  static const OriginSpringSpec soft = OriginSpringSpec(
    mass: 1.0,
    stiffness: 220.0,
    damping: 22.0,
  );

  /// Lively underdamped spring for liquid rebound (mass=1.0, stiffness=250, damping=16).
  static const OriginSpringSpec elastic = OriginSpringSpec(
    mass: 1.0,
    stiffness: 250.0,
    damping: 16.0,
  );

  /// Crisp button press/release spring.
  static const OriginSpringSpec crisp = OriginSpringSpec(
    mass: 1.0,
    stiffness: 420.0,
    damping: 25.0,
  );

  /// Liquid bottom dock pill glide spring.
  static const OriginSpringSpec dock = OriginSpringSpec(
    mass: 1.0,
    stiffness: 360.0,
    damping: 23.0,
  );

  /// Bottom sheet snap & interactive dismissal spring.
  static const OriginSpringSpec sheet = OriginSpringSpec(
    mass: 1.0,
    stiffness: 320.0,
    damping: 28.0,
  );

  /// Physical spring toggle switch completion.
  static const OriginSpringSpec toggle = OriginSpringSpec(
    mass: 1.0,
    stiffness: 460.0,
    damping: 23.0,
  );

  /// Interruptible navigation & tab transition spring.
  static const OriginSpringSpec page = OriginSpringSpec(
    mass: 1.0,
    stiffness: 310.0,
    damping: 26.0,
  );

  /// Snappy swipe-to-reply bubble rebound.
  static const OriginSpringSpec swipeReply = OriginSpringSpec(
    mass: 1.0,
    stiffness: 440.0,
    damping: 24.0,
  );

  /// 2D floating window / PiP / Origin Island snap spring.
  static const OriginSpringSpec floatingWindow = OriginSpringSpec(
    mass: 1.0,
    stiffness: 290.0,
    damping: 22.0,
  );

  /// Modulates a base spring dynamically based on input gesture speed (px/s):
  /// fast gestures yield crisper, snappier stiffness; slow gestures stay soft
  /// and unhurried so the same component reacts naturally to gesture intent.
  static OriginSpringSpec adaptForVelocity(
    OriginSpringSpec base,
    double speedPxPerSec,
  ) {
    final normalized = (speedPxPerSec.abs() / 1600.0).clamp(0.0, 1.0).toDouble();
    // 0.88x stiffness on very slow release -> up to 1.32x stiffness on fast flick
    final stiffnessFactor = 0.88 + normalized * 0.44;
    // Scale damping slightly below sqrt(stiffnessFactor) so fast flicks feel energetic
    final dampingFactor = 0.94 + normalized * 0.22;
    return base.copyWith(
      stiffness: base.stiffness * stiffnessFactor,
      damping: base.damping * dampingFactor,
    );
  }
}

/// Global coordinator for Origin Motion Engine configuration, accessibility
/// reduced-motion state, low-RAM device profile, and deformation intensity.
class OriginMotionEngine {
  OriginMotionEngine._();

  static const String _intensityKey = 'likedin_origin_deformation_intensity_v1';

  /// User-configurable liquid deformation intensity multiplier (`0.0`–`1.4`).
  static final ValueNotifier<double> deformationIntensity = ValueNotifier<double>(1.0);

  /// Mirrors `LikedinAppearance.reduceMotion` so `lib/motion/` stays decoupled.
  static final ValueNotifier<bool> reduceMotion = ValueNotifier<bool>(false);

  /// True on <= 3 GB RAM phones (e.g., Vivo Y12) to trim heavy optical effects
  /// while preserving smooth spring kinematics.
  static bool isLowRamDevice = false;

  /// Combined effective deformation intensity factoring in Reduce Motion & RAM tier.
  static double get effectiveDeformationIntensity {
    if (reduceMotion.value) return 0.0;
    final raw = deformationIntensity.value.clamp(0.0, 1.4).toDouble();
    return isLowRamDevice ? (raw * 0.85) : raw;
  }

  static Future<void> load({
    SharedPreferences? preferences,
    bool lowRamDevice = false,
    bool reducedMotion = false,
  }) async {
    isLowRamDevice = lowRamDevice;
    reduceMotion.value = reducedMotion;
    try {
      final prefs = preferences ?? await SharedPreferences.getInstance();
      final saved = prefs.getDouble(_intensityKey);
      if (saved != null) {
        deformationIntensity.value = saved.clamp(0.0, 1.4).toDouble();
      }
    } catch (_) {}
  }

  static Future<void> setDeformationIntensity(double value) async {
    final clamped = value.clamp(0.0, 1.4).toDouble();
    deformationIntensity.value = clamped;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setDouble(_intensityKey, clamped);
    } catch (_) {}
  }

  static Future<void> reset() async {
    deformationIntensity.value = 1.0;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_intensityKey);
    } catch (_) {}
  }
}
