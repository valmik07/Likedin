# Likedin v3.0.0+143 — OriginOS 7 Physics & Motion Engine + 3-Tier Liquid Glass

See **`RELEASE_NOTES.md`** for release notes (consumed automatically by `android-build-v2.9.0.yml`) and **`AUDIT_NOTES.md`** for architecture details.
