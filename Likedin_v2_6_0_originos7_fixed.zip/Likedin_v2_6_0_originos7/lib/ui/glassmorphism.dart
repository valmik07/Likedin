import 'dart:async';
import 'dart:math' as math;
import 'dart:ui' show ImageFilter, TileMode;

import 'package:flutter/material.dart';
import 'package:flutter/physics.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ---------------------------------------------------------------------------
// Likedin OriginOS 7 Design System
//
// Combines Vivo OriginOS 7's Light & Shadow Aesthetics with ultra-smooth
// low-RAM performance:
//  * 3 Translucent Glass Textures (+ Off):
//      - Real:    Crystal optical translucency, vivid specular rim, live blur
//                 on floating chrome (Origin Island, elastic dock, auth).
//      - Natural: Balanced clear glass sheen & crisp rim (zero blur cost —
//                 automatic default on 3 GB RAM / Android 11 phones).
//      - Soft:    Silky low-glare satin matte glass for calm night reading.
//      - Off:     Solid high-contrast flat surfaces.
//  * Fluid Motion (Spring Physics): True SpringSimulation elastic squish &
//    rebound on cards/buttons plus a stretchy liquid dock pill indicator.
//  * Dynamic Glow: Interactive contact glow & day/night ambient lighting shift.
//  * Glint Light Effect: Angle-responsive iridescent light beam driven by
//    Android's built-in accelerometer (zero third-party packages; auto-off on
//    3 GB RAM devices and when Reduce Motion is enabled).
// ---------------------------------------------------------------------------

/// Accent choices tuned separately for Dark and Light modes so every accent
/// maintains >= 4.5:1 WCAG contrast across all 7 app themes.
class LikedinAccent {
  const LikedinAccent({
    required this.name,
    required this.dark,
    required this.light,
    required this.gradientEnd,
  });

  final String name;
  final Color dark;
  final Color light;
  final Color gradientEnd;

  Color forBrightness(Brightness b) => b == Brightness.dark ? dark : light;
}

const List<LikedinAccent> likedinAccents = [
  LikedinAccent(
    name: 'Electric blue',
    dark: Color(0xFF6FA8FF),
    light: Color(0xFF0A5FD0),
    gradientEnd: Color(0xFF22D3EE),
  ),
  LikedinAccent(
    name: 'Cyan',
    dark: Color(0xFF3DD6F5),
    light: Color(0xFF006A82),
    gradientEnd: Color(0xFF5EEAD4),
  ),
  LikedinAccent(
    name: 'Violet',
    dark: Color(0xFFB39DFF),
    light: Color(0xFF5B3FD6),
    gradientEnd: Color(0xFF7DB8FF),
  ),
  LikedinAccent(
    name: 'Emerald',
    dark: Color(0xFF4FDBA5),
    light: Color(0xFF09704D),
    gradientEnd: Color(0xFF5EE1E8),
  ),
  LikedinAccent(
    name: 'Rose',
    dark: Color(0xFFFF8FB1),
    light: Color(0xFFC2255C),
    gradientEnd: Color(0xFFFFB08A),
  ),
  LikedinAccent(
    name: 'Sunset',
    dark: Color(0xFFFFB36B),
    light: Color(0xFFA84200),
    gradientEnd: Color(0xFFFF7A9E),
  ),
];

/// Unified app-wide OriginOS 7 theme preset adapting cleanly to Dark & Light.
class LikedinThemePreset {
  const LikedinThemePreset({
    required this.name,
    required this.defaultAccentIndex,
    required this.darkBgTop,
    required this.darkBgMid,
    required this.darkBgBottom,
    required this.darkOrb1,
    required this.darkOrb2,
    required this.darkOrb3,
    required this.darkSurface,
    required this.darkSurfaceRaised,
    required this.darkOutline,
    required this.lightBgTop,
    required this.lightBgMid,
    required this.lightBgBottom,
    required this.lightOrb1,
    required this.lightOrb2,
    required this.lightOrb3,
    required this.lightSurface,
    required this.lightSurfaceRaised,
    required this.lightOutline,
  });

  final String name;
  final int defaultAccentIndex;

  final Color darkBgTop;
  final Color darkBgMid;
  final Color darkBgBottom;
  final Color darkOrb1;
  final Color darkOrb2;
  final Color darkOrb3;
  final Color darkSurface;
  final Color darkSurfaceRaised;
  final Color darkOutline;

  final Color lightBgTop;
  final Color lightBgMid;
  final Color lightBgBottom;
  final Color lightOrb1;
  final Color lightOrb2;
  final Color lightOrb3;
  final Color lightSurface;
  final Color lightSurfaceRaised;
  final Color lightOutline;

  List<Color> previewColors(Brightness b) => b == Brightness.dark
      ? [darkBgTop, darkBgMid, darkBgBottom]
      : [lightBgTop, lightBgMid, lightBgBottom];

  Color primaryOrb(Brightness b) => b == Brightness.dark ? darkOrb1 : lightOrb1;
}

const List<LikedinThemePreset> likedinThemePresets = [
  LikedinThemePreset(
    name: 'Default',
    defaultAccentIndex: 0,
    darkBgTop: Color(0xFF0B1530),
    darkBgMid: Color(0xFF091126),
    darkBgBottom: Color(0xFF060B18),
    darkOrb1: Color(0xFF3B82F6),
    darkOrb2: Color(0xFF22D3EE),
    darkOrb3: Color(0xFF6366F1),
    darkSurface: Color(0xFF0E1830),
    darkSurfaceRaised: Color(0xFF16233F),
    darkOutline: Color(0xFF28385A),
    lightBgTop: Color(0xFFF7FAFF),
    lightBgMid: Color(0xFFEFF5FD),
    lightBgBottom: Color(0xFFEAF1FB),
    lightOrb1: Color(0xFF60A5FA),
    lightOrb2: Color(0xFF38BDF8),
    lightOrb3: Color(0xFF93C5FD),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFEBF1FA),
    lightOutline: Color(0xFFD3DEEE),
  ),
  LikedinThemePreset(
    name: 'Ocean',
    defaultAccentIndex: 1,
    darkBgTop: Color(0xFF0C2748),
    darkBgMid: Color(0xFF081B34),
    darkBgBottom: Color(0xFF051122),
    darkOrb1: Color(0xFF0EA5E9),
    darkOrb2: Color(0xFF2DD4BF),
    darkOrb3: Color(0xFF38BDF8),
    darkSurface: Color(0xFF0C1C34),
    darkSurfaceRaised: Color(0xFF132A4A),
    darkOutline: Color(0xFF21426B),
    lightBgTop: Color(0xFFF3F9FF),
    lightBgMid: Color(0xFFE8F4FF),
    lightBgBottom: Color(0xFFE0EFFF),
    lightOrb1: Color(0xFF38BDF8),
    lightOrb2: Color(0xFF5EEAD4),
    lightOrb3: Color(0xFF7DD3FC),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFE7F2FF),
    lightOutline: Color(0xFFC8E0F8),
  ),
  LikedinThemePreset(
    name: 'Rose',
    defaultAccentIndex: 4,
    darkBgTop: Color(0xFF321129),
    darkBgMid: Color(0xFF220C1E),
    darkBgBottom: Color(0xFF130712),
    darkOrb1: Color(0xFFF43F5E),
    darkOrb2: Color(0xFFEC4899),
    darkOrb3: Color(0xFFFB7185),
    darkSurface: Color(0xFF220E1E),
    darkSurfaceRaised: Color(0xFF31162B),
    darkOutline: Color(0xFF4E2445),
    lightBgTop: Color(0xFFFFF7FA),
    lightBgMid: Color(0xFFFEEEF4),
    lightBgBottom: Color(0xFFFCE7EF),
    lightOrb1: Color(0xFFF472B6),
    lightOrb2: Color(0xFFFDA4AF),
    lightOrb3: Color(0xFFF9A8D4),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFFCECF2),
    lightOutline: Color(0xFFF2CEDC),
  ),
  LikedinThemePreset(
    name: 'Emerald',
    defaultAccentIndex: 3,
    darkBgTop: Color(0xFF0B312A),
    darkBgMid: Color(0xFF08221D),
    darkBgBottom: Color(0xFF051412),
    darkOrb1: Color(0xFF10B981),
    darkOrb2: Color(0xFF14B8A6),
    darkOrb3: Color(0xFF34D399),
    darkSurface: Color(0xFF0B211E),
    darkSurfaceRaised: Color(0xFF12312C),
    darkOutline: Color(0xFF1F4C44),
    lightBgTop: Color(0xFFF3FDF9),
    lightBgMid: Color(0xFFE7FAF2),
    lightBgBottom: Color(0xFFDDF6EB),
    lightOrb1: Color(0xFF34D399),
    lightOrb2: Color(0xFF5EEAD4),
    lightOrb3: Color(0xFF6EE7B7),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFE7F7F0),
    lightOutline: Color(0xFFC4E7D8),
  ),
  LikedinThemePreset(
    name: 'Sunset',
    defaultAccentIndex: 5,
    darkBgTop: Color(0xFF351624),
    darkBgMid: Color(0xFF24101E),
    darkBgBottom: Color(0xFF140A16),
    darkOrb1: Color(0xFFFB923C),
    darkOrb2: Color(0xFFF43F5E),
    darkOrb3: Color(0xFFF59E0B),
    darkSurface: Color(0xFF24101C),
    darkSurfaceRaised: Color(0xFF331828),
    darkOutline: Color(0xFF52283E),
    lightBgTop: Color(0xFFFFF8F4),
    lightBgMid: Color(0xFFFEF1EA),
    lightBgBottom: Color(0xFFFDEBE0),
    lightOrb1: Color(0xFFFB923C),
    lightOrb2: Color(0xFFFDA4AF),
    lightOrb3: Color(0xFFFDBA74),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFFDEEE5),
    lightOutline: Color(0xFFF4D4C2),
  ),
  LikedinThemePreset(
    name: 'Lavender',
    defaultAccentIndex: 2,
    darkBgTop: Color(0xFF201846),
    darkBgMid: Color(0xFF151030),
    darkBgBottom: Color(0xFF0B081C),
    darkOrb1: Color(0xFF8B5CF6),
    darkOrb2: Color(0xFF60A5FA),
    darkOrb3: Color(0xFFC084FC),
    darkSurface: Color(0xFF161130),
    darkSurfaceRaised: Color(0xFF211A45),
    darkOutline: Color(0xFF392E6D),
    lightBgTop: Color(0xFFF8F6FF),
    lightBgMid: Color(0xFFF2EEFF),
    lightBgBottom: Color(0xFFECE7FF),
    lightOrb1: Color(0xFFA78BFA),
    lightOrb2: Color(0xFF93C5FD),
    lightOrb3: Color(0xFFC4B5FD),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFEFEBFF),
    lightOutline: Color(0xFFD6CEFA),
  ),
  LikedinThemePreset(
    name: 'Minimal',
    defaultAccentIndex: 0,
    darkBgTop: Color(0xFF141923),
    darkBgMid: Color(0xFF0D1119),
    darkBgBottom: Color(0xFF07090E),
    darkOrb1: Color(0xFF64748B),
    darkOrb2: Color(0xFF94A3B8),
    darkOrb3: Color(0xFF475569),
    darkSurface: Color(0xFF12161F),
    darkSurfaceRaised: Color(0xFF1B212E),
    darkOutline: Color(0xFF2E3749),
    lightBgTop: Color(0xFFFFFFFF),
    lightBgMid: Color(0xFFF7F9FC),
    lightBgBottom: Color(0xFFF0F4F9),
    lightOrb1: Color(0xFFCBD5E1),
    lightOrb2: Color(0xFF94A3B8),
    lightOrb3: Color(0xFFE2E8F0),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFEEF2F7),
    lightOutline: Color(0xFFD8E0EC),
  ),
];

/// OriginOS 7 glass material textures (+ Off for solid maximum contrast).
enum LikedinEffects {
  /// Crisp optical glass with live backdrop blur on floating chrome & specular rim.
  real,

  /// Balanced clear glass sheen & crisp rim with zero live blur GPU cost.
  natural,

  /// Silky matte satin low-glare glass for calm night optics (zero blur cost).
  soft,

  /// Solid flat surfaces for maximum speed and contrast.
  off,
}

/// Drives OriginOS 7's angle-responsive Glint Light sheen from Android's
/// native accelerometer EventChannel (`com.example.likedin/glint_tilt`).
class OriginGlintController {
  OriginGlintController._();

  static const EventChannel _channel =
      EventChannel('com.example.likedin/glint_tilt');

  /// Normalized device tilt offset in `[-1.0, 1.0]`.
  static final ValueNotifier<Offset> tilt = ValueNotifier<Offset>(Offset.zero);
  static StreamSubscription<dynamic>? _sub;

  static void sync() {
    final active = LikedinAppearance.glintEnabled.value &&
        !LikedinAppearance.reduceMotion.value &&
        LikedinAppearance.effects.value != LikedinEffects.off;
    if (!active) {
      stop();
      return;
    }
    if (_sub != null) return;
    try {
      _sub = _channel.receiveBroadcastStream().listen(
        (dynamic event) {
          if (event is List && event.length >= 2) {
            final dx = ((event[0] as num).toDouble()).clamp(-1.0, 1.0);
            final dy = ((event[1] as num).toDouble()).clamp(-1.0, 1.0);
            tilt.value = Offset(dx, dy);
          }
        },
        onError: (Object _) {
          // Non-Android / emulator / test environments gracefully stay static.
          stop();
        },
        cancelOnError: true,
      );
    } catch (_) {
      stop();
    }
  }

  static void stop() {
    _sub?.cancel();
    _sub = null;
    if (tilt.value != Offset.zero) {
      tilt.value = Offset.zero;
    }
  }
}

/// Persisted OriginOS 7 appearance preferences shared by every screen.
class LikedinAppearance {
  LikedinAppearance._();

  static const _themeKey = 'likedin_theme_preset_v2';
  static const _legacyChatWallpaperKey = 'likedin_chat_wallpaper_preset_v1';
  static const _accentKey = 'likedin_accent_index_v1';
  static const _effectsKeyV2 = 'likedin_origin_texture_v2';
  static const _legacyEffectsKey = 'likedin_effects_level_v1';
  static const _glintKey = 'likedin_origin_glint_v1';
  static const _motionKey = 'likedin_reduce_motion_v1';

  static final ValueNotifier<int> themeIndex = ValueNotifier<int>(0);
  static final ValueNotifier<int> accentIndex = ValueNotifier<int>(0);
  static final ValueNotifier<LikedinEffects> effects =
      ValueNotifier<LikedinEffects>(LikedinEffects.real);
  static final ValueNotifier<bool> glintEnabled = ValueNotifier<bool>(true);
  static final ValueNotifier<bool> reduceMotion = ValueNotifier<bool>(false);
  static bool isLowRamDevice = false;

  /// Rebuilds the MaterialApp when any appearance value changes.
  static final Listenable listenable = Listenable.merge([
    themeIndex,
    accentIndex,
    effects,
    glintEnabled,
    reduceMotion,
  ]);

  static LikedinThemePreset get theme =>
      likedinThemePresets[themeIndex.value.clamp(0, likedinThemePresets.length - 1).toInt()];

  static LikedinAccent get accent =>
      likedinAccents[accentIndex.value.clamp(0, likedinAccents.length - 1).toInt()];

  static String get textureLabel => switch (effects.value) {
        LikedinEffects.real => 'Real',
        LikedinEffects.natural => 'Natural',
        LikedinEffects.soft => 'Soft',
        LikedinEffects.off => 'Off',
      };

  static Future<void> load([
    SharedPreferences? preferences,
    bool lowRamDevice = false,
  ]) async {
    isLowRamDevice = lowRamDevice;
    try {
      final prefs = preferences ?? await SharedPreferences.getInstance();
      final savedTheme = prefs.getInt(_themeKey) ?? prefs.getInt(_legacyChatWallpaperKey) ?? 0;
      themeIndex.value = savedTheme.clamp(0, likedinThemePresets.length - 1).toInt();
      final a = prefs.getInt(_accentKey) ?? 0;
      accentIndex.value = a.clamp(0, likedinAccents.length - 1).toInt();

      final savedV2 = prefs.getInt(_effectsKeyV2);
      if (savedV2 != null) {
        effects.value = LikedinEffects.values[savedV2.clamp(0, LikedinEffects.values.length - 1).toInt()];
      } else {
        final legacy = prefs.getInt(_legacyEffectsKey);
        if (legacy != null) {
          effects.value = switch (legacy) {
            0 => lowRamDevice ? LikedinEffects.natural : LikedinEffects.real,
            1 => LikedinEffects.natural,
            _ => LikedinEffects.off,
          };
        } else {
          // Auto-select Real on 4+ GB devices and zero-blur Natural on 3 GB RAM phones.
          effects.value = lowRamDevice ? LikedinEffects.natural : LikedinEffects.real;
        }
      }

      reduceMotion.value = prefs.getBool(_motionKey) ?? false;
      final savedGlint = prefs.getBool(_glintKey);
      glintEnabled.value = savedGlint ?? !lowRamDevice;
      OriginGlintController.sync();
    } catch (_) {
      // Defaults are fine if preferences are unavailable.
    }
  }

  /// Sets the app-wide theme preset and optionally syncs its harmonious accent.
  static Future<void> setTheme(int index, {bool syncAccent = true}) async {
    final clamped = index.clamp(0, likedinThemePresets.length - 1).toInt();
    themeIndex.value = clamped;
    if (syncAccent) {
      final recommended = likedinThemePresets[clamped]
          .defaultAccentIndex
          .clamp(0, likedinAccents.length - 1)
          .toInt();
      accentIndex.value = recommended;
    }
    await _save((p) async {
      await p.setInt(_themeKey, clamped);
      if (syncAccent) await p.setInt(_accentKey, accentIndex.value);
    });
  }

  static Future<void> setAccent(int index) async {
    accentIndex.value = index.clamp(0, likedinAccents.length - 1).toInt();
    await _save((p) => p.setInt(_accentKey, accentIndex.value));
  }

  static Future<void> setEffects(LikedinEffects value) async {
    effects.value = value;
    OriginGlintController.sync();
    await _save((p) => p.setInt(_effectsKeyV2, value.index));
  }

  static Future<void> setGlintEnabled(bool value) async {
    glintEnabled.value = value;
    OriginGlintController.sync();
    await _save((p) => p.setBool(_glintKey, value));
  }

  static Future<void> setReduceMotion(bool value) async {
    reduceMotion.value = value;
    OriginGlintController.sync();
    await _save((p) => p.setBool(_motionKey, value));
  }

  static Future<void> reset() async {
    themeIndex.value = 0;
    accentIndex.value = 0;
    effects.value = isLowRamDevice ? LikedinEffects.natural : LikedinEffects.real;
    glintEnabled.value = !isLowRamDevice;
    reduceMotion.value = false;
    OriginGlintController.sync();
    await _save((p) async {
      await p.remove(_themeKey);
      await p.remove(_legacyChatWallpaperKey);
      await p.remove(_accentKey);
      await p.remove(_effectsKeyV2);
      await p.remove(_legacyEffectsKey);
      await p.remove(_glintKey);
      await p.remove(_motionKey);
    });
  }

  static Future<void> _save(Future<void> Function(SharedPreferences) write) async {
    try {
      await write(await SharedPreferences.getInstance());
    } catch (_) {}
  }

  /// True when animations should be skipped or shortened.
  static bool motionReduced(BuildContext context) =>
      reduceMotion.value || MediaQuery.of(context).disableAnimations;
}

// ---- Theme-aware Palette ---------------------------------------------------

Color likedinBackground(Brightness brightness) {
  final t = LikedinAppearance.theme;
  return brightness == Brightness.dark ? t.darkBgBottom : t.lightBgBottom;
}

Color likedinBackgroundTop(Brightness brightness) {
  final t = LikedinAppearance.theme;
  return brightness == Brightness.dark ? t.darkBgTop : t.lightBgTop;
}

Color likedinSurface(Brightness brightness) {
  final t = LikedinAppearance.theme;
  return brightness == Brightness.dark ? t.darkSurface : t.lightSurface;
}

Color likedinSurfaceRaised(Brightness brightness) {
  final t = LikedinAppearance.theme;
  return brightness == Brightness.dark ? t.darkSurfaceRaised : t.lightSurfaceRaised;
}

Color likedinOutline(Brightness brightness) {
  final t = LikedinAppearance.theme;
  return brightness == Brightness.dark ? t.darkOutline : t.lightOutline;
}

Color likedinOnSurface(Brightness brightness) => brightness == Brightness.dark
    ? const Color(0xFFEAF0FF)
    : const Color(0xFF0C1A33);

Color likedinMutedText(Brightness brightness) => brightness == Brightness.dark
    ? const Color(0xFFA8B5CF)
    : const Color(0xFF51617F);

Color likedinPrimary(Brightness brightness) =>
    LikedinAppearance.accent.forBrightness(brightness);

/// Darkens [color] just enough that white text on it reaches [minContrast].
Color likedinEnsureWhiteContrast(Color color, {double minContrast = 4.5}) {
  var result = color;
  for (var i = 0; i < 24; i++) {
    final ratio = 1.05 / (result.computeLuminance() + .05);
    if (ratio >= minContrast) return result;
    result = Color.lerp(result, const Color(0xFF000000), .06)!;
  }
  return result;
}

/// Primary accent gradient for action buttons.
LinearGradient likedinPrimaryGradient(Brightness brightness) {
  final accent = LikedinAppearance.accent;
  final dark = brightness == Brightness.dark;
  final start = likedinEnsureWhiteContrast(
    dark ? Color.lerp(accent.dark, const Color(0xFF1D4ED8), .35)! : accent.light,
  );
  final end = likedinEnsureWhiteContrast(
    dark ? accent.gradientEnd : Color.lerp(accent.light, accent.gradientEnd, .55)!,
  );
  return LinearGradient(
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
    colors: [start, end],
  );
}

/// Outgoing chat-bubble fill harmonized with the active theme and accent.
Color likedinOutgoingBubble(Brightness brightness) {
  final accent = likedinPrimary(brightness);
  return brightness == Brightness.dark
      ? Color.alphaBlend(accent.withValues(alpha: .30), likedinSurface(brightness))
      : Color.alphaBlend(accent.withValues(alpha: .16), Colors.white);
}

/// Incoming chat-bubble fill harmonized with the active theme.
Color likedinIncomingBubble(Brightness brightness) =>
    brightness == Brightness.dark
        ? likedinSurface(brightness).withValues(alpha: .58)
        : Colors.white.withValues(alpha: .78);

// ---- OriginOS 7 Glass Optical Painters (Real / Natural / Soft + Glint) -----

/// Paints the OriginOS 7 glass interior sheen BEHIND child widgets.
/// Uses same-hue zero-alpha stops (never `Colors.transparent` black) so cards
/// stay crystal-clear with zero dark-grey banding in both Light and Dark mode.
class _LiquidGlassFillPainter extends CustomPainter {
  const _LiquidGlassFillPainter({
    required this.radius,
    required this.dark,
    required this.accent,
    required this.texture,
    required this.isFrosted,
  });

  final BorderRadius radius;
  final bool dark;
  final Color accent;
  final LikedinEffects texture;
  final bool isFrosted;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final rect = Offset.zero & size;
    final rrect = radius.toRRect(rect);

    canvas.save();
    canvas.clipRRect(rrect);

    final isReal = texture == LikedinEffects.real;
    final isSoft = texture == LikedinEffects.soft;

    // 1. Curved top liquid meniscus highlight capped in physical pixels.
    final sheenHeight = math.min(size.height * 0.42, isSoft ? 32.0 : 44.0);
    final topSheenRect = Rect.fromLTWH(0, 0, size.width, sheenHeight);
    final whiteZero = Colors.white.withValues(alpha: 0.0);
    final double topAlpha = dark
        ? (isReal ? (isFrosted ? .17 : .11) : (isSoft ? .05 : .08))
        : (isReal ? (isFrosted ? .58 : .44) : (isSoft ? .24 : .34));
    final double midAlpha = topAlpha * 0.34;

    final topSheenPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        stops: const [0.0, 0.45, 1.0],
        colors: [
          Colors.white.withValues(alpha: topAlpha),
          Colors.white.withValues(alpha: midAlpha),
          whiteZero,
        ],
      ).createShader(topSheenRect);
    canvas.drawRect(topSheenRect, topSheenPaint);

    // 2. Subtle OriginOS 7 bottom Dynamic Glow bounce (toned down in Soft mode).
    if (!isSoft) {
      final bounceHeight = math.min(size.height * 0.28, 28.0);
      final bottomBounceRect = Rect.fromLTWH(
        0,
        size.height - bounceHeight,
        size.width,
        bounceHeight,
      );
      final bounceAlpha = dark
          ? (isReal ? (isFrosted ? .15 : .09) : .06)
          : (isReal ? .08 : .05);
      final bouncePaint = Paint()
        ..shader = LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [
            accent.withValues(alpha: bounceAlpha),
            accent.withValues(alpha: 0.0),
          ],
        ).createShader(bottomBounceRect);
      canvas.drawRect(bottomBounceRect, bouncePaint);
    }

    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _LiquidGlassFillPainter old) =>
      old.radius != radius ||
      old.dark != dark ||
      old.accent != accent ||
      old.texture != texture ||
      old.isFrosted != isFrosted;
}

/// Paints ONLY the crisp directional specular OriginOS 7 perimeter rim.
class _LiquidGlassRimPainter extends CustomPainter {
  const _LiquidGlassRimPainter({
    required this.radius,
    required this.dark,
    required this.accent,
    required this.texture,
    required this.isFrosted,
  });

  final BorderRadius radius;
  final bool dark;
  final Color accent;
  final LikedinEffects texture;
  final bool isFrosted;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final rect = Offset.zero & size;
    final rrect = radius.toRRect(rect);

    final isReal = texture == LikedinEffects.real;
    final isSoft = texture == LikedinEffects.soft;
    final strokeWidth = isReal ? 1.25 : (isSoft ? 0.9 : 1.05);
    final rimRRect = rrect.deflate(strokeWidth * 0.5);
    const topHighlight = Colors.white;
    final bottomRefraction = Color.lerp(Colors.white, accent, dark ? .45 : .28)!;

    final rimPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        stops: const [0.0, 0.24, 0.50, 0.76, 1.0],
        colors: dark
            ? [
                topHighlight.withValues(
                  alpha: isReal ? (isFrosted ? .58 : .38) : (isSoft ? .14 : .26),
                ),
                Colors.white.withValues(alpha: isReal ? .16 : (isSoft ? .06 : .10)),
                Colors.white.withValues(alpha: isReal ? .06 : .04),
                bottomRefraction.withValues(alpha: isReal ? .14 : (isSoft ? .05 : .09)),
                bottomRefraction.withValues(
                  alpha: isReal ? (isFrosted ? .38 : .26) : (isSoft ? .11 : .18),
                ),
              ]
            : [
                topHighlight.withValues(alpha: isReal ? .96 : (isSoft ? .65 : .84)),
                Colors.white.withValues(alpha: isReal ? .55 : (isSoft ? .26 : .40)),
                Color(0xFF0C1A33).withValues(alpha: isReal ? .08 : .06),
                Colors.white.withValues(alpha: isReal ? .50 : (isSoft ? .24 : .36)),
                bottomRefraction.withValues(alpha: isReal ? .78 : (isSoft ? .42 : .62)),
              ],
      ).createShader(rect);
    canvas.drawRRect(rimRRect, rimPaint);

    if (!dark) {
      final hairline = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.6
        ..color = Color(0xFF0C1A33).withValues(alpha: isReal ? .08 : .06);
      canvas.drawRRect(rrect.deflate(0.3), hairline);
    }
  }

  @override
  bool shouldRepaint(covariant _LiquidGlassRimPainter old) =>
      old.radius != radius ||
      old.dark != dark ||
      old.accent != accent ||
      old.texture != texture ||
      old.isFrosted != isFrosted;
}

/// Paints OriginOS 7's angle-responsive iridescent Glint Light beam across hero
/// cards as the user tilts their phone (uses same-hue zero-alpha stops!).
class _OriginGlintPainter extends CustomPainter {
  const _OriginGlintPainter({
    required this.radius,
    required this.tilt,
    required this.dark,
    required this.accent,
    required this.accentEnd,
  });

  final BorderRadius radius;
  final Offset tilt;
  final bool dark;
  final Color accent;
  final Color accentEnd;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final rect = Offset.zero & size;
    final rrect = radius.toRRect(rect);

    final shiftX = tilt.dx * 0.95;
    final shiftY = tilt.dy * 0.55;
    final beam = Paint()
      ..shader = LinearGradient(
        begin: Alignment(-1.15 + shiftX, -1.0 + shiftY),
        end: Alignment(1.15 + shiftX, 1.0 + shiftY),
        stops: const [0.0, 0.36, 0.50, 0.64, 1.0],
        colors: dark
            ? [
                accent.withValues(alpha: 0.0),
                accent.withValues(alpha: .11),
                Colors.white.withValues(alpha: .16),
                accentEnd.withValues(alpha: .11),
                accentEnd.withValues(alpha: 0.0),
              ]
            : [
                accent.withValues(alpha: 0.0),
                accent.withValues(alpha: .10),
                Colors.white.withValues(alpha: .42),
                accentEnd.withValues(alpha: .12),
                accentEnd.withValues(alpha: 0.0),
              ],
      ).createShader(rect);

    canvas.save();
    canvas.clipRRect(rrect);
    canvas.drawRect(rect, beam);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _OriginGlintPainter old) =>
      old.radius != radius ||
      old.tilt != tilt ||
      old.dark != dark ||
      old.accent != accent ||
      old.accentEnd != accentEnd;
}

// ---- Surfaces --------------------------------------------------------------

/// OriginOS 7 Dynamic Translucent Glass surface supporting Real / Natural /
/// Soft / Off textures, adaptive light-and-shadow contrast, and optional
/// tilt-responsive [glint] iridescence on hero cards.
class GlassPanel extends StatelessWidget {
  const GlassPanel({
    required this.child,
    this.padding = EdgeInsets.zero,
    this.radius = const BorderRadius.all(Radius.circular(24)),
    this.blur = 0,
    this.tint,
    this.glow = false,
    this.frosted = false,
    this.glint = false,
    super.key,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final BorderRadius radius;
  final double blur;
  final Color? tint;
  final bool glow;
  final bool frosted;
  final bool glint;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    return ListenableBuilder(
      listenable: LikedinAppearance.listenable,
      child: Padding(padding: padding, child: child),
      builder: (context, builtChild) {
        final texture = LikedinAppearance.effects.value;
        final base = tint ?? likedinSurface(brightness);
        final fancy = texture != LikedinEffects.off;
        final isReal = texture == LikedinEffects.real;
        final isSoft = texture == LikedinEffects.soft;
        final primary = likedinPrimary(brightness);
        final endAccent = LikedinAppearance.accent.gradientEnd;

        final fillAlpha = switch (texture) {
          LikedinEffects.off => 1.0,
          LikedinEffects.real => frosted ? (dark ? .34 : .56) : (dark ? .52 : .76),
          LikedinEffects.natural => frosted ? (dark ? .62 : .78) : (dark ? .64 : .82),
          LikedinEffects.soft => frosted ? (dark ? .78 : .88) : (dark ? .76 : .88),
        };

        final Widget core = DecoratedBox(
          decoration: BoxDecoration(
            color: base.withValues(alpha: fillAlpha),
            borderRadius: radius,
            border: !fancy
                ? Border.all(color: likedinOutline(brightness), width: 1)
                : null,
          ),
          child: builtChild,
        );

        Widget layered = fancy
            ? CustomPaint(
                painter: _LiquidGlassFillPainter(
                  radius: radius,
                  dark: dark,
                  accent: primary,
                  texture: texture,
                  isFrosted: frosted,
                ),
                foregroundPainter: _LiquidGlassRimPainter(
                  radius: radius,
                  dark: dark,
                  accent: primary,
                  texture: texture,
                  isFrosted: frosted,
                ),
                child: core,
              )
            : core;

        // Angle-responsive OriginOS 7 Glint Light sheen on hero cards.
        if (glint &&
            fancy &&
            !isSoft &&
            LikedinAppearance.glintEnabled.value &&
            !LikedinAppearance.reduceMotion.value) {
          layered = ValueListenableBuilder<Offset>(
            valueListenable: OriginGlintController.tilt,
            child: layered,
            builder: (_, tilt, childWidget) => CustomPaint(
              painter: _OriginGlintPainter(
                radius: radius,
                tilt: tilt,
                dark: dark,
                accent: primary,
                accentEnd: endAccent,
              ),
              child: childWidget,
            ),
          );
        }

        Widget result;
        if (frosted && isReal) {
          final maxSigma = LikedinAppearance.isLowRamDevice ? 5.5 : 7.5;
          final sigma = (blur <= 0 ? 7.0 : blur).clamp(0.0, maxSigma).toDouble();
          result = RepaintBoundary(
            child: ClipRRect(
              borderRadius: radius,
              child: BackdropFilter(
                filter: ImageFilter.blur(
                  sigmaX: sigma,
                  sigmaY: sigma,
                  tileMode: TileMode.mirror,
                ),
                child: layered,
              ),
            ),
          );
        } else if (radius == BorderRadius.zero) {
          result = layered;
        } else {
          result = ClipRRect(borderRadius: radius, child: layered);
        }

        // Outer ambient Dynamic Glow strictly outside glass perimeter.
        if (fancy && !isSoft && (frosted || glow)) {
          final glowScale = isReal ? 1.0 : 0.72;
          result = DecoratedBox(
            decoration: BoxDecoration(
              borderRadius: radius,
              boxShadow: [
                if (glow)
                  BoxShadow(
                    color: primary.withValues(alpha: (dark ? .22 : .13) * glowScale),
                    blurRadius: 18,
                    blurStyle: BlurStyle.outer,
                  ),
                if (frosted)
                  BoxShadow(
                    color: dark
                        ? Colors.black.withValues(alpha: .32 * glowScale)
                        : Color(0xFF0C1A33).withValues(alpha: .10 * glowScale),
                    blurRadius: 14,
                    blurStyle: BlurStyle.outer,
                  ),
              ],
            ),
            child: result,
          );
        }
        return result;
      },
    );
  }
}

/// GPU-native single-draw-call OriginOS 7 chat bubble.
/// Zero ClipRRect, zero CustomPaint shaders — locked at 90/120fps on 3 GB RAM.
class LiquidGlassBubble extends StatelessWidget {
  const LiquidGlassBubble({
    required this.child,
    required this.outgoing,
    required this.borderRadius,
    this.margin = EdgeInsets.zero,
    this.padding = const EdgeInsets.fromLTRB(14, 10, 14, 8),
    this.maxWidth = 310,
    super.key,
  });

  final Widget child;
  final bool outgoing;
  final BorderRadius borderRadius;
  final EdgeInsetsGeometry margin;
  final EdgeInsetsGeometry padding;
  final double maxWidth;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    final texture = LikedinAppearance.effects.value;
    final fancy = texture != LikedinEffects.off;
    final isSoft = texture == LikedinEffects.soft;
    final primary = likedinPrimary(brightness);

    final baseFill = outgoing
        ? likedinOutgoingBubble(brightness)
        : (fancy ? likedinIncomingBubble(brightness) : likedinSurface(brightness));

    final sheenStrength = isSoft ? 0.45 : 1.0;
    final topTint = dark
        ? Color.alphaBlend(
            Colors.white.withValues(alpha: (outgoing ? .10 : .07) * sheenStrength),
            baseFill,
          )
        : Color.alphaBlend(
            Colors.white.withValues(alpha: (outgoing ? .32 : .52) * sheenStrength),
            baseFill,
          );

    final borderColor = !fancy
        ? (outgoing ? primary.withValues(alpha: .45) : likedinOutline(brightness))
        : outgoing
            ? primary.withValues(alpha: dark ? (isSoft ? .34 : .52) : (isSoft ? .26 : .38))
            : (dark
                ? Colors.white.withValues(alpha: isSoft ? .10 : .16)
                : Colors.white.withValues(alpha: isSoft ? .78 : .94));

    final double topAlpha = isSoft
        ? (dark ? (outgoing ? .90 : .80) : (outgoing ? .94 : .92))
        : (dark ? (outgoing ? .84 : .64) : (outgoing ? .90 : .86));
    final double botAlpha = isSoft
        ? (dark ? (outgoing ? .84 : .74) : (outgoing ? .90 : .88))
        : (dark ? (outgoing ? .76 : .54) : (outgoing ? .84 : .78));

    return Padding(
      padding: margin,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: maxWidth),
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: fancy ? null : baseFill,
            gradient: fancy
                ? LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      topTint.withValues(alpha: topAlpha),
                      baseFill.withValues(alpha: botAlpha),
                    ],
                  )
                : null,
            borderRadius: borderRadius,
            border: Border.all(color: borderColor, width: 1.0),
          ),
          child: Padding(padding: padding, child: child),
        ),
      ),
    );
  }
}

/// Unified app-wide OriginOS 7 ambient backdrop with subtle day/night lighting
/// modulation and three static soft light orbs (zero per-frame blur cost).
class AuroraBackdrop extends StatelessWidget {
  const AuroraBackdrop({required this.child, super.key});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    final hour = DateTime.now().hour;
    final isNightHour = hour < 6 || hour >= 20;
    // OriginOS 7 Immersive Day/Night lighting: bright & poppy in daytime,
    // deeper and calmer at night.
    final orbIntensity = isNightHour ? 0.84 : 1.0;

    return ListenableBuilder(
      listenable: LikedinAppearance.listenable,
      child: child,
      builder: (context, builtChild) {
        final texture = LikedinAppearance.effects.value;
        final theme = LikedinAppearance.theme;
        final orb1 = dark ? theme.darkOrb1 : theme.lightOrb1;
        final orb2 = dark ? theme.darkOrb2 : theme.lightOrb2;
        final orb3 = dark ? theme.darkOrb3 : theme.lightOrb3;
        final bgColors = dark
            ? [theme.darkBgTop, theme.darkBgMid, theme.darkBgBottom]
            : [theme.lightBgTop, theme.lightBgMid, theme.lightBgBottom];
        final showOrbs = texture == LikedinEffects.real || texture == LikedinEffects.natural;
        final orbMult = (texture == LikedinEffects.natural ? 0.82 : 1.0) * orbIntensity;

        final children = <Widget>[
          if (texture == LikedinEffects.off)
            ColoredBox(color: likedinBackground(brightness))
          else
            RepaintBoundary(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    stops: const [0.0, 0.52, 1.0],
                    colors: bgColors,
                  ),
                ),
                child: showOrbs
                    ? Stack(
                        fit: StackFit.expand,
                        children: [
                          DecoratedBox(
                            decoration: BoxDecoration(
                              gradient: RadialGradient(
                                center: const Alignment(-.82, -.88),
                                radius: 1.05,
                                colors: [
                                  orb1.withValues(alpha: (dark ? .34 : .26) * orbMult),
                                  orb1.withValues(alpha: 0),
                                ],
                              ),
                            ),
                          ),
                          DecoratedBox(
                            decoration: BoxDecoration(
                              gradient: RadialGradient(
                                center: const Alignment(.92, .82),
                                radius: .98,
                                colors: [
                                  orb2.withValues(alpha: (dark ? .26 : .22) * orbMult),
                                  orb2.withValues(alpha: 0),
                                ],
                              ),
                            ),
                          ),
                          DecoratedBox(
                            decoration: BoxDecoration(
                              gradient: RadialGradient(
                                center: const Alignment(.78, -.16),
                                radius: .82,
                                colors: [
                                  orb3.withValues(alpha: (dark ? .20 : .16) * orbMult),
                                  orb3.withValues(alpha: 0),
                                ],
                              ),
                            ),
                          ),
                        ],
                      )
                    : null,
              ),
            ),
          if (builtChild != null) builtChild,
        ];
        return Stack(fit: StackFit.expand, children: children);
      },
    );
  }
}

/// OriginOS 7 Fluid Motion spring press-and-rebound with subtle Dynamic Glow
/// touch highlight. Automatically becomes a no-op when Reduce Motion is active.
class LikedinPressScale extends StatefulWidget {
  const LikedinPressScale({
    required this.child,
    this.enabled = true,
    this.pressedScale = 0.955,
    this.glowRadius = const BorderRadius.all(Radius.circular(24)),
    super.key,
  });

  final Widget child;
  final bool enabled;
  final double pressedScale;
  final BorderRadius glowRadius;

  @override
  State<LikedinPressScale> createState() => _LikedinPressScaleState();
}

class _LikedinPressScaleState extends State<LikedinPressScale>
    with SingleTickerProviderStateMixin {
  late final AnimationController _spring = AnimationController.unbounded(
    vsync: this,
    value: 1.0,
  );
  Offset? _tapOffset;
  bool _pressed = false;

  static const SpringDescription _pressSpring = SpringDescription(
    mass: 1.0,
    stiffness: 520.0,
    damping: 30.0,
  );

  static const SpringDescription _releaseSpring = SpringDescription(
    mass: 1.0,
    stiffness: 380.0,
    damping: 20.0,
  );

  void _animateTo(double target, SpringDescription spring) {
    if (LikedinAppearance.reduceMotion.value) {
      _spring.value = target;
      return;
    }
    _spring.animateWith(
      SpringSimulation(spring, _spring.value, target, _spring.velocity),
    );
  }

  void _onDown(PointerDownEvent e) {
    if (!widget.enabled || LikedinAppearance.reduceMotion.value) return;
    _pressed = true;
    _tapOffset = e.localPosition;
    _animateTo(widget.pressedScale, _pressSpring);
    if (mounted) setState(() {});
  }

  void _onUp() {
    if (!_pressed) return;
    _pressed = false;
    _animateTo(1.0, _releaseSpring);
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _spring.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    final showGlow = _pressed &&
        _tapOffset != null &&
        LikedinAppearance.effects.value != LikedinEffects.off &&
        !LikedinAppearance.reduceMotion.value;
    final primary = likedinPrimary(brightness);

    return Listener(
      behavior: HitTestBehavior.translucent,
      onPointerDown: _onDown,
      onPointerUp: (_) => _onUp(),
      onPointerCancel: (_) => _onUp(),
      child: AnimatedBuilder(
        animation: _spring,
        child: widget.child,
        builder: (context, child) {
          final scale = _spring.value.clamp(0.88, 1.05);
          Widget out = Transform.scale(scale: scale, child: child);
          if (showGlow) {
            out = Stack(
              fit: StackFit.passthrough,
              children: [
                out,
                Positioned.fill(
                  child: IgnorePointer(
                    child: ClipRRect(
                      borderRadius: widget.glowRadius,
                      child: CustomPaint(
                        painter: _OriginDynamicGlowPainter(
                          center: _tapOffset!,
                          color: primary,
                          dark: dark,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          }
          return out;
        },
      ),
    );
  }
}

class _OriginDynamicGlowPainter extends CustomPainter {
  const _OriginDynamicGlowPainter({
    required this.center,
    required this.color,
    required this.dark,
  });

  final Offset center;
  final Color color;
  final bool dark;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final radius = math.max(size.width, size.height) * 0.72;
    final paint = Paint()
      ..shader = RadialGradient(
        colors: [
          (dark ? Colors.white : color).withValues(alpha: dark ? .16 : .14),
          color.withValues(alpha: dark ? .08 : .06),
          color.withValues(alpha: 0.0),
        ],
        stops: const [0.0, 0.48, 1.0],
      ).createShader(Rect.fromCircle(center: center, radius: radius));
    canvas.drawCircle(center, radius, paint);
  }

  @override
  bool shouldRepaint(covariant _OriginDynamicGlowPainter old) =>
      old.center != center || old.color != color || old.dark != dark;
}

/// OriginOS 7 elastic floating bottom dock with a gliding, spring-stretching
/// Liquid Glass pill indicator and Dynamic Glow halo.
class OriginDockItem {
  const OriginDockItem({
    required this.tab,
    required this.icon,
    required this.activeIcon,
    required this.label,
  });

  final int tab;
  final IconData icon;
  final IconData activeIcon;
  final String label;
}

class OriginFloatingDock extends StatefulWidget {
  const OriginFloatingDock({
    required this.items,
    required this.activeTab,
    required this.onSelect,
    super.key,
  });

  final List<OriginDockItem> items;
  final int activeTab;
  final ValueChanged<int> onSelect;

  @override
  State<OriginFloatingDock> createState() => _OriginFloatingDockState();
}

class _OriginFloatingDockState extends State<OriginFloatingDock>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pillCtrl = AnimationController.unbounded(
    vsync: this,
    value: _indexForTab(widget.activeTab).toDouble(),
  );

  static const SpringDescription _dockSpring = SpringDescription(
    mass: 1.0,
    stiffness: 340.0,
    damping: 24.0,
  );

  int _indexForTab(int tab) {
    final idx = widget.items.indexWhere((e) => e.tab == tab);
    return idx < 0 ? 0 : idx;
  }

  @override
  void didUpdateWidget(covariant OriginFloatingDock oldWidget) {
    super.didUpdateWidget(oldWidget);
    final target = _indexForTab(widget.activeTab).toDouble();
    final maxIdx = math.max(0, widget.items.length - 1).toDouble();
    if (_pillCtrl.value > maxIdx) {
      _pillCtrl.value = target;
      return;
    }
    if ((target - _pillCtrl.value).abs() > 0.001) {
      if (LikedinAppearance.reduceMotion.value) {
        _pillCtrl.value = target;
      } else {
        _pillCtrl.animateWith(
          SpringSimulation(_dockSpring, _pillCtrl.value, target, _pillCtrl.velocity),
        );
      }
    }
  }

  @override
  void dispose() {
    _pillCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    final primary = likedinPrimary(brightness);
    final mutedColor = dark ? const Color(0xFFD2DDF0) : const Color(0xFF475569);
    final count = widget.items.length;

    return GlassPanel(
      radius: BorderRadius.circular(34),
      frosted: true,
      blur: 7,
      glow: true,
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 6),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final slotWidth = count > 0 ? constraints.maxWidth / count : constraints.maxWidth;
          return SizedBox(
            height: 54,
            child: Stack(
              children: [
                // Elastic gliding OriginOS 7 liquid capsule indicator
                AnimatedBuilder(
                  animation: _pillCtrl,
                  builder: (context, _) {
                    final maxIdx = math.max(0, count - 1).toDouble();
                    final pos = _pillCtrl.value.clamp(0.0, maxIdx).toDouble();
                    // Subtle liquid stretch proportional to travel velocity
                    final vel = (_pillCtrl.velocity.abs() / 18.0).clamp(0.0, 0.22).toDouble();
                    final pillW = (slotWidth * (1.0 + vel))
                        .clamp(slotWidth, constraints.maxWidth)
                        .toDouble();
                    final rawLeft = pos * slotWidth - (pillW - slotWidth) * 0.5;
                    final maxLeft = math.max(0.0, constraints.maxWidth - pillW);
                    final left = rawLeft.clamp(0.0, maxLeft).toDouble();
                    return Positioned(
                      left: left,
                      top: 0,
                      bottom: 0,
                      width: pillW,
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(27),
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: dark
                                ? [
                                    Colors.white.withValues(alpha: .22),
                                    primary.withValues(alpha: .22),
                                  ]
                                : [
                                    Colors.white.withValues(alpha: .96),
                                    primary.withValues(alpha: .15),
                                  ],
                          ),
                          border: Border.all(
                            color: dark
                                ? Colors.white.withValues(alpha: .36)
                                : Colors.white.withValues(alpha: .98),
                            width: 1.0,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: primary.withValues(alpha: dark ? .26 : .14),
                              blurRadius: 12,
                              blurStyle: BlurStyle.outer,
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
                // Dock tab buttons
                Row(
                  children: widget.items.map((item) {
                    final selected = widget.activeTab == item.tab;
                    return Expanded(
                      child: LikedinPressScale(
                        pressedScale: 0.90,
                        glowRadius: BorderRadius.circular(26),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(26),
                          onTap: () {
                            HapticFeedback.selectionClick();
                            widget.onSelect(item.tab);
                          },
                          child: Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  selected ? item.activeIcon : item.icon,
                                  size: 22,
                                  color: selected ? primary : mutedColor,
                                ),
                                const SizedBox(height: 3),
                                Text(
                                  item.label,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: selected ? FontWeight.w800 : FontWeight.w500,
                                    color: selected ? primary : mutedColor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  }).toList(growable: false),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

/// Primary action button: OriginOS 7 gradient pill with specular top rim & spring press.
class GradientButton extends StatelessWidget {
  const GradientButton({
    required this.onPressed,
    required this.child,
    this.height = 52,
    super.key,
  });

  final VoidCallback? onPressed;
  final Widget child;
  final double height;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final enabled = onPressed != null;
    final radius = BorderRadius.circular(height);
    return LikedinPressScale(
      enabled: enabled,
      glowRadius: radius,
      child: Opacity(
        opacity: enabled ? 1 : .55,
        child: CustomPaint(
          foregroundPainter: _LiquidGlassRimPainter(
            radius: radius,
            dark: true,
            accent: likedinPrimary(brightness),
            texture: LikedinAppearance.effects.value,
            isFrosted: false,
          ),
          child: Material(
            color: Colors.transparent,
            child: Ink(
              height: height,
              decoration: BoxDecoration(
                gradient: likedinPrimaryGradient(brightness),
                borderRadius: radius,
              ),
              child: InkWell(
                onTap: onPressed,
                borderRadius: radius,
                child: Center(
                  child: DefaultTextStyle.merge(
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                    ),
                    child: IconTheme.merge(
                      data: const IconThemeData(color: Colors.white),
                      child: child,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
