import 'dart:ui' show ImageFilter, TileMode;

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ---------------------------------------------------------------------------
// Likedin Design System: iOS-inspired Liquid Glass (Dark & Light) with 7
// unified app-wide themes.
//
// Core optical properties:
//  * Crystal-clear translucency (not milky frosted slabs): low-opacity optical
//    lens fill paired with backdrop blur + saturation/vibrancy boost on
//    floating chrome (nav pill, chat header, composer, banners, auth card).
//  * Directional specular rim refraction (`_LiquidGlassPainter`): diagonal
//    bright-to-clear-to-tinted glass perimeter stroke + curved top liquid
//    meniscus highlight + subtle bottom chromatic bounce (zero GPU blur cost).
//  * Unified app-wide themes: Default, Ocean, Rose, Emerald, Sunset, Lavender,
//    and Minimal — all 7 adapt seamlessly between Dark & Light modes across
//    Home, Chat, Calls, Files, Profile, Settings, Contact Info, and Storage.
//  * Performance aware: Full / Lighter / Off effects + Reduce Motion.
// ---------------------------------------------------------------------------

/// Accent choices tuned separately for Dark and Light modes so every accent
/// maintains >= 4.5:1 WCAG contrast across all 7 app themes.
class LikedinAccent {
  const LikedinAccent({
    required this.name,
    required this.dark,
    required this.light,
    required this.gradientEnd,
  });

  final String name;
  final Color dark;
  final Color light;
  final Color gradientEnd;

  Color forBrightness(Brightness b) => b == Brightness.dark ? dark : light;
}

const List<LikedinAccent> likedinAccents = [
  LikedinAccent(
    name: 'Electric blue',
    dark: Color(0xFF6FA8FF),
    light: Color(0xFF0A5FD0),
    gradientEnd: Color(0xFF22D3EE),
  ),
  LikedinAccent(
    name: 'Cyan',
    dark: Color(0xFF3DD6F5),
    light: Color(0xFF006A82),
    gradientEnd: Color(0xFF5EEAD4),
  ),
  LikedinAccent(
    name: 'Violet',
    dark: Color(0xFFB39DFF),
    light: Color(0xFF5B3FD6),
    gradientEnd: Color(0xFF7DB8FF),
  ),
  LikedinAccent(
    name: 'Emerald',
    dark: Color(0xFF4FDBA5),
    light: Color(0xFF09704D),
    gradientEnd: Color(0xFF5EE1E8),
  ),
  LikedinAccent(
    name: 'Rose',
    dark: Color(0xFFFF8FB1),
    light: Color(0xFFC2255C),
    gradientEnd: Color(0xFFFFB08A),
  ),
  LikedinAccent(
    name: 'Sunset',
    dark: Color(0xFFFFB36B),
    light: Color(0xFFA84200),
    gradientEnd: Color(0xFFFF7A9E),
  ),
];

/// Unified app-wide Liquid Glass theme preset that adapts cleanly to both Dark
/// and Light modes across every screen (including Chat).
class LikedinThemePreset {
  const LikedinThemePreset({
    required this.name,
    required this.defaultAccentIndex,
    required this.darkBgTop,
    required this.darkBgMid,
    required this.darkBgBottom,
    required this.darkOrb1,
    required this.darkOrb2,
    required this.darkOrb3,
    required this.darkSurface,
    required this.darkSurfaceRaised,
    required this.darkOutline,
    required this.lightBgTop,
    required this.lightBgMid,
    required this.lightBgBottom,
    required this.lightOrb1,
    required this.lightOrb2,
    required this.lightOrb3,
    required this.lightSurface,
    required this.lightSurfaceRaised,
    required this.lightOutline,
  });

  final String name;
  final int defaultAccentIndex;

  final Color darkBgTop;
  final Color darkBgMid;
  final Color darkBgBottom;
  final Color darkOrb1;
  final Color darkOrb2;
  final Color darkOrb3;
  final Color darkSurface;
  final Color darkSurfaceRaised;
  final Color darkOutline;

  final Color lightBgTop;
  final Color lightBgMid;
  final Color lightBgBottom;
  final Color lightOrb1;
  final Color lightOrb2;
  final Color lightOrb3;
  final Color lightSurface;
  final Color lightSurfaceRaised;
  final Color lightOutline;

  List<Color> previewColors(Brightness b) => b == Brightness.dark
      ? [darkBgTop, darkBgMid, darkBgBottom]
      : [lightBgTop, lightBgMid, lightBgBottom];

  Color primaryOrb(Brightness b) => b == Brightness.dark ? darkOrb1 : lightOrb1;
}

const List<LikedinThemePreset> likedinThemePresets = [
  LikedinThemePreset(
    name: 'Default',
    defaultAccentIndex: 0,
    darkBgTop: Color(0xFF0B1530),
    darkBgMid: Color(0xFF091126),
    darkBgBottom: Color(0xFF060B18),
    darkOrb1: Color(0xFF3B82F6),
    darkOrb2: Color(0xFF22D3EE),
    darkOrb3: Color(0xFF6366F1),
    darkSurface: Color(0xFF0E1830),
    darkSurfaceRaised: Color(0xFF16233F),
    darkOutline: Color(0xFF28385A),
    lightBgTop: Color(0xFFF7FAFF),
    lightBgMid: Color(0xFFEFF5FD),
    lightBgBottom: Color(0xFFEAF1FB),
    lightOrb1: Color(0xFF60A5FA),
    lightOrb2: Color(0xFF38BDF8),
    lightOrb3: Color(0xFF93C5FD),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFEBF1FA),
    lightOutline: Color(0xFFD3DEEE),
  ),
  LikedinThemePreset(
    name: 'Ocean',
    defaultAccentIndex: 1,
    darkBgTop: Color(0xFF0C2748),
    darkBgMid: Color(0xFF081B34),
    darkBgBottom: Color(0xFF051122),
    darkOrb1: Color(0xFF0EA5E9),
    darkOrb2: Color(0xFF2DD4BF),
    darkOrb3: Color(0xFF38BDF8),
    darkSurface: Color(0xFF0C1C34),
    darkSurfaceRaised: Color(0xFF132A4A),
    darkOutline: Color(0xFF21426B),
    lightBgTop: Color(0xFFF3F9FF),
    lightBgMid: Color(0xFFE8F4FF),
    lightBgBottom: Color(0xFFE0EFFF),
    lightOrb1: Color(0xFF38BDF8),
    lightOrb2: Color(0xFF5EEAD4),
    lightOrb3: Color(0xFF7DD3FC),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFE7F2FF),
    lightOutline: Color(0xFFC8E0F8),
  ),
  LikedinThemePreset(
    name: 'Rose',
    defaultAccentIndex: 4,
    darkBgTop: Color(0xFF321129),
    darkBgMid: Color(0xFF220C1E),
    darkBgBottom: Color(0xFF130712),
    darkOrb1: Color(0xFFF43F5E),
    darkOrb2: Color(0xFFEC4899),
    darkOrb3: Color(0xFFFB7185),
    darkSurface: Color(0xFF220E1E),
    darkSurfaceRaised: Color(0xFF31162B),
    darkOutline: Color(0xFF4E2445),
    lightBgTop: Color(0xFFFFF7FA),
    lightBgMid: Color(0xFFFEEEF4),
    lightBgBottom: Color(0xFFFCE7EF),
    lightOrb1: Color(0xFFF472B6),
    lightOrb2: Color(0xFFFDA4AF),
    lightOrb3: Color(0xFFF9A8D4),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFFCECF2),
    lightOutline: Color(0xFFF2CEDC),
  ),
  LikedinThemePreset(
    name: 'Emerald',
    defaultAccentIndex: 3,
    darkBgTop: Color(0xFF0B312A),
    darkBgMid: Color(0xFF08221D),
    darkBgBottom: Color(0xFF051412),
    darkOrb1: Color(0xFF10B981),
    darkOrb2: Color(0xFF14B8A6),
    darkOrb3: Color(0xFF34D399),
    darkSurface: Color(0xFF0B211E),
    darkSurfaceRaised: Color(0xFF12312C),
    darkOutline: Color(0xFF1F4C44),
    lightBgTop: Color(0xFFF3FDF9),
    lightBgMid: Color(0xFFE7FAF2),
    lightBgBottom: Color(0xFFDDF6EB),
    lightOrb1: Color(0xFF34D399),
    lightOrb2: Color(0xFF5EEAD4),
    lightOrb3: Color(0xFF6EE7B7),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFE7F7F0),
    lightOutline: Color(0xFFC4E7D8),
  ),
  LikedinThemePreset(
    name: 'Sunset',
    defaultAccentIndex: 5,
    darkBgTop: Color(0xFF351624),
    darkBgMid: Color(0xFF24101E),
    darkBgBottom: Color(0xFF140A16),
    darkOrb1: Color(0xFFFB923C),
    darkOrb2: Color(0xFFF43F5E),
    darkOrb3: Color(0xFFF59E0B),
    darkSurface: Color(0xFF24101C),
    darkSurfaceRaised: Color(0xFF331828),
    darkOutline: Color(0xFF52283E),
    lightBgTop: Color(0xFFFFF8F4),
    lightBgMid: Color(0xFFFEF1EA),
    lightBgBottom: Color(0xFFFDEBE0),
    lightOrb1: Color(0xFFFB923C),
    lightOrb2: Color(0xFFFDA4AF),
    lightOrb3: Color(0xFFFDBA74),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFFDEEE5),
    lightOutline: Color(0xFFF4D4C2),
  ),
  LikedinThemePreset(
    name: 'Lavender',
    defaultAccentIndex: 2,
    darkBgTop: Color(0xFF201846),
    darkBgMid: Color(0xFF151030),
    darkBgBottom: Color(0xFF0B081C),
    darkOrb1: Color(0xFF8B5CF6),
    darkOrb2: Color(0xFF60A5FA),
    darkOrb3: Color(0xFFC084FC),
    darkSurface: Color(0xFF161130),
    darkSurfaceRaised: Color(0xFF211A45),
    darkOutline: Color(0xFF392E6D),
    lightBgTop: Color(0xFFF8F6FF),
    lightBgMid: Color(0xFFF2EEFF),
    lightBgBottom: Color(0xFFECE7FF),
    lightOrb1: Color(0xFFA78BFA),
    lightOrb2: Color(0xFF93C5FD),
    lightOrb3: Color(0xFFC4B5FD),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFEFEBFF),
    lightOutline: Color(0xFFD6CEFA),
  ),
  LikedinThemePreset(
    name: 'Minimal',
    defaultAccentIndex: 0,
    darkBgTop: Color(0xFF141923),
    darkBgMid: Color(0xFF0D1119),
    darkBgBottom: Color(0xFF07090E),
    darkOrb1: Color(0xFF64748B),
    darkOrb2: Color(0xFF94A3B8),
    darkOrb3: Color(0xFF475569),
    darkSurface: Color(0xFF12161F),
    darkSurfaceRaised: Color(0xFF1B212E),
    darkOutline: Color(0xFF2E3749),
    lightBgTop: Color(0xFFFFFFFF),
    lightBgMid: Color(0xFFF7F9FC),
    lightBgBottom: Color(0xFFF0F4F9),
    lightOrb1: Color(0xFFCBD5E1),
    lightOrb2: Color(0xFF94A3B8),
    lightOrb3: Color(0xFFE2E8F0),
    lightSurface: Color(0xFFFFFFFF),
    lightSurfaceRaised: Color(0xFFEEF2F7),
    lightOutline: Color(0xFFD8E0EC),
  ),
];

enum LikedinEffects { full, lighter, off }

/// Persisted appearance preferences shared by every screen.
class LikedinAppearance {
  LikedinAppearance._();

  static const _themeKey = 'likedin_theme_preset_v2';
  static const _legacyChatWallpaperKey = 'likedin_chat_wallpaper_preset_v1';
  static const _accentKey = 'likedin_accent_index_v1';
  static const _effectsKey = 'likedin_effects_level_v1';
  static const _motionKey = 'likedin_reduce_motion_v1';

  static final ValueNotifier<int> themeIndex = ValueNotifier<int>(0);
  static final ValueNotifier<int> accentIndex = ValueNotifier<int>(0);
  static final ValueNotifier<LikedinEffects> effects =
      ValueNotifier<LikedinEffects>(LikedinEffects.full);
  static final ValueNotifier<bool> reduceMotion = ValueNotifier<bool>(false);

  /// Rebuilds the MaterialApp when any appearance value changes.
  static final Listenable listenable =
      Listenable.merge([themeIndex, accentIndex, effects, reduceMotion]);

  static LikedinThemePreset get theme =>
      likedinThemePresets[themeIndex.value.clamp(0, likedinThemePresets.length - 1).toInt()];

  static LikedinAccent get accent =>
      likedinAccents[accentIndex.value.clamp(0, likedinAccents.length - 1).toInt()];

  static Future<void> load([SharedPreferences? preferences]) async {
    try {
      final prefs = preferences ?? await SharedPreferences.getInstance();
      final savedTheme = prefs.getInt(_themeKey) ?? prefs.getInt(_legacyChatWallpaperKey) ?? 0;
      themeIndex.value = savedTheme.clamp(0, likedinThemePresets.length - 1).toInt();
      final a = prefs.getInt(_accentKey) ?? 0;
      accentIndex.value = a.clamp(0, likedinAccents.length - 1).toInt();
      final e = prefs.getInt(_effectsKey) ?? 0;
      effects.value = LikedinEffects.values[e.clamp(0, 2).toInt()];
      reduceMotion.value = prefs.getBool(_motionKey) ?? false;
    } catch (_) {
      // Defaults are fine if preferences are unavailable.
    }
  }

  /// Sets the app-wide theme preset. When [syncAccent] is true (default), also
  /// switches to the theme's harmonious accent colour so every button, bubble
  /// and glow matches immediately across Home, Chat, Calls, Files & Settings.
  static Future<void> setTheme(int index, {bool syncAccent = true}) async {
    final clamped = index.clamp(0, likedinThemePresets.length - 1).toInt();
    themeIndex.value = clamped;
    if (syncAccent) {
      final recommended = likedinThemePresets[clamped]
          .defaultAccentIndex
          .clamp(0, likedinAccents.length - 1)
          .toInt();
      accentIndex.value = recommended;
    }
    await _save((p) async {
      await p.setInt(_themeKey, clamped);
      if (syncAccent) await p.setInt(_accentKey, accentIndex.value);
    });
  }

  static Future<void> setAccent(int index) async {
    accentIndex.value = index.clamp(0, likedinAccents.length - 1).toInt();
    await _save((p) => p.setInt(_accentKey, accentIndex.value));
  }

  static Future<void> setEffects(LikedinEffects value) async {
    effects.value = value;
    await _save((p) => p.setInt(_effectsKey, value.index));
  }

  static Future<void> setReduceMotion(bool value) async {
    reduceMotion.value = value;
    await _save((p) => p.setBool(_motionKey, value));
  }

  static Future<void> reset() async {
    themeIndex.value = 0;
    accentIndex.value = 0;
    effects.value = LikedinEffects.full;
    reduceMotion.value = false;
    await _save((p) async {
      await p.remove(_themeKey);
      await p.remove(_legacyChatWallpaperKey);
      await p.remove(_accentKey);
      await p.remove(_effectsKey);
      await p.remove(_motionKey);
    });
  }

  static Future<void> _save(Future<void> Function(SharedPreferences) write) async {
    try {
      await write(await SharedPreferences.getInstance());
    } catch (_) {}
  }

  /// True when animations should be skipped or shortened: either the user
  /// chose reduced motion in Likedin or the OS asks for it.
  static bool motionReduced(BuildContext context) =>
      reduceMotion.value || MediaQuery.of(context).disableAnimations;
}

// ---- Theme-aware Palette ---------------------------------------------------

Color likedinBackground(Brightness brightness) {
  final t = LikedinAppearance.theme;
  return brightness == Brightness.dark ? t.darkBgBottom : t.lightBgBottom;
}

Color likedinBackgroundTop(Brightness brightness) {
  final t = LikedinAppearance.theme;
  return brightness == Brightness.dark ? t.darkBgTop : t.lightBgTop;
}

Color likedinSurface(Brightness brightness) {
  final t = LikedinAppearance.theme;
  return brightness == Brightness.dark ? t.darkSurface : t.lightSurface;
}

Color likedinSurfaceRaised(Brightness brightness) {
  final t = LikedinAppearance.theme;
  return brightness == Brightness.dark ? t.darkSurfaceRaised : t.lightSurfaceRaised;
}

Color likedinOutline(Brightness brightness) {
  final t = LikedinAppearance.theme;
  return brightness == Brightness.dark ? t.darkOutline : t.lightOutline;
}

Color likedinOnSurface(Brightness brightness) => brightness == Brightness.dark
    ? const Color(0xFFEAF0FF)
    : const Color(0xFF0C1A33);

Color likedinMutedText(Brightness brightness) => brightness == Brightness.dark
    ? const Color(0xFFA8B5CF)
    : const Color(0xFF51617F);

Color likedinPrimary(Brightness brightness) =>
    LikedinAppearance.accent.forBrightness(brightness);

/// Darkens [color] just enough that white text on it reaches [minContrast]
/// (WCAG ratio). This is what keeps every accent choice readable.
Color likedinEnsureWhiteContrast(Color color, {double minContrast = 4.5}) {
  var result = color;
  for (var i = 0; i < 24; i++) {
    final ratio = 1.05 / (result.computeLuminance() + .05);
    if (ratio >= minContrast) return result;
    result = Color.lerp(result, const Color(0xFF000000), .06)!;
  }
  return result;
}

/// Primary accent gradient for action buttons. Both stops are contrast-checked
/// for white labels, so it is safe with any theme/accent combination.
LinearGradient likedinPrimaryGradient(Brightness brightness) {
  final accent = LikedinAppearance.accent;
  final dark = brightness == Brightness.dark;
  final start = likedinEnsureWhiteContrast(
    dark ? Color.lerp(accent.dark, const Color(0xFF1D4ED8), .35)! : accent.light,
  );
  final end = likedinEnsureWhiteContrast(
    dark ? accent.gradientEnd : Color.lerp(accent.light, accent.gradientEnd, .55)!,
  );
  return LinearGradient(
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
    colors: [start, end],
  );
}

/// Outgoing chat-bubble fill harmonized with the active theme and accent.
Color likedinOutgoingBubble(Brightness brightness) {
  final accent = likedinPrimary(brightness);
  return brightness == Brightness.dark
      ? Color.alphaBlend(accent.withValues(alpha: .30), likedinSurface(brightness))
      : Color.alphaBlend(accent.withValues(alpha: .16), Colors.white);
}

/// Incoming chat-bubble fill harmonized with the active theme.
Color likedinIncomingBubble(Brightness brightness) =>
    brightness == Brightness.dark
        ? likedinSurface(brightness).withValues(alpha: .54)
        : Colors.white.withValues(alpha: .72);

// ---- iOS-Style Liquid Glass Specular & Refraction Painter ------------------

/// Paints authentic iOS-style Liquid Glass optical reflections:
///  1. Curved top liquid meniscus gloss highlight (upper lens contour)
///  2. Subtle bottom chromatic bounce tinted with the active accent
///  3. Directional diagonal specular refraction rim (bright top-left catchlight
///     -> crystal-clear mid-edges -> luminous bottom-right counter-refraction)
class _LiquidGlassPainter extends CustomPainter {
  const _LiquidGlassPainter({
    required this.radius,
    required this.dark,
    required this.accent,
    required this.isFull,
    required this.isFrosted,
    this.accentBorderBoost = false,
  });

  final BorderRadius radius;
  final bool dark;
  final Color accent;
  final bool isFull;
  final bool isFrosted;
  final bool accentBorderBoost;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final rect = Offset.zero & size;
    final rrect = radius.toRRect(rect);

    // 1. Curved top liquid meniscus sheen + subtle bottom chromatic bounce
    canvas.save();
    canvas.clipRRect(rrect);

    final topSheenRect = Rect.fromLTWH(0, 0, size.width, size.height * 0.48);
    final topSheenPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        stops: const [0.0, 0.32, 1.0],
        colors: dark
            ? [
                Colors.white.withValues(alpha: isFull ? (isFrosted ? .20 : .13) : .08),
                Colors.white.withValues(alpha: isFull ? .05 : .02),
                Colors.transparent,
              ]
            : [
                Colors.white.withValues(alpha: isFull ? (isFrosted ? .76 : .62) : .45),
                Colors.white.withValues(alpha: isFull ? .24 : .12),
                Colors.transparent,
              ],
      ).createShader(topSheenRect);
    canvas.drawRect(topSheenRect, topSheenPaint);

    if (isFull) {
      final bottomBounceRect = Rect.fromLTWH(
        0,
        size.height * 0.72,
        size.width,
        size.height * 0.28,
      );
      final bouncePaint = Paint()
        ..shader = LinearGradient(
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
          colors: [
            accent.withValues(alpha: dark ? (isFrosted ? .14 : .09) : .08),
            Colors.transparent,
          ],
        ).createShader(bottomBounceRect);
      canvas.drawRect(bottomBounceRect, bouncePaint);
    }
    canvas.restore();

    // 2. Directional diagonal specular rim (the signature iOS Liquid Glass edge)
    final strokeWidth = isFull ? 1.3 : 1.0;
    final rimRRect = rrect.deflate(strokeWidth * 0.5);
    final topHighlight = accentBorderBoost
        ? Color.lerp(Colors.white, accent, dark ? .35 : .25)!
        : Colors.white;
    final bottomRefraction = accentBorderBoost
        ? accent
        : Color.lerp(Colors.white, accent, dark ? .45 : .25)!;

    final rimPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        stops: const [0.0, 0.22, 0.50, 0.78, 1.0],
        colors: dark
            ? [
                topHighlight.withValues(alpha: isFull ? (isFrosted ? .62 : .42) : .22),
                Colors.white.withValues(alpha: isFull ? .16 : .09),
                Colors.white.withValues(alpha: isFull ? .05 : .04),
                bottomRefraction.withValues(alpha: isFull ? .14 : .07),
                bottomRefraction.withValues(alpha: isFull ? (isFrosted ? .40 : .28) : .16),
              ]
            : [
                topHighlight.withValues(alpha: isFull ? .98 : .85),
                Colors.white.withValues(alpha: isFull ? .55 : .40),
                Color(0xFF0C1A33).withValues(alpha: isFull ? .08 : .06),
                Colors.white.withValues(alpha: isFull ? .52 : .35),
                bottomRefraction.withValues(alpha: isFull ? .86 : .68),
              ],
      ).createShader(rect);
    canvas.drawRRect(rimRRect, rimPaint);

    // Subtle crisp outer contour in light mode so clear glass stays defined on bright Frost themes
    if (!dark) {
      final hairline = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.6
        ..color = Color(0xFF0C1A33).withValues(alpha: isFull ? .09 : .07);
      canvas.drawRRect(rrect.deflate(0.3), hairline);
    }
  }

  @override
  bool shouldRepaint(covariant _LiquidGlassPainter old) =>
      old.radius != radius ||
      old.dark != dark ||
      old.accent != accent ||
      old.isFull != isFull ||
      old.isFrosted != isFrosted ||
      old.accentBorderBoost != accentBorderBoost;
}

// ---- Surfaces --------------------------------------------------------------

/// iOS-inspired Liquid Glass surface for floating bars, cards, and grouped rows.
///
/// Set [frosted] for optical backdrop refraction (blur + vibrancy matrix) on
/// floating chrome (nav capsule, chat header, composer, banners, auth card).
/// Everyday scrolling rows use crystal-clear translucency + directional
/// specular rim refraction with zero blur overhead.
class GlassPanel extends StatelessWidget {
  const GlassPanel({
    required this.child,
    this.padding = EdgeInsets.zero,
    this.radius = const BorderRadius.all(Radius.circular(22)),
    this.blur = 0,
    this.tint,
    this.glow = false,
    this.frosted = false,
    super.key,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final BorderRadius radius;
  final double blur;
  final Color? tint;
  final bool glow;
  final bool frosted;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    return ListenableBuilder(
      listenable: LikedinAppearance.listenable,
      child: Padding(padding: padding, child: child),
      builder: (context, builtChild) {
        final effects = LikedinAppearance.effects.value;
        final base = tint ?? likedinSurface(brightness);
        final fancy = effects != LikedinEffects.off;
        final isFull = effects == LikedinEffects.full;
        final primary = likedinPrimary(brightness);

        // Crystal-clear Liquid Glass opacity: low milkiness on frosted floating
        // chrome, balanced clear translucency on non-blurred cards.
        final fillAlpha = !fancy
            ? 1.0
            : frosted
                ? (dark ? .26 : .42)
                : (dark ? .46 : .62);

        final Widget core = DecoratedBox(
          decoration: BoxDecoration(
            color: base.withValues(alpha: fillAlpha),
            borderRadius: radius,
            border: !fancy
                ? Border.all(color: likedinOutline(brightness), width: 1)
                : null,
          ),
          child: builtChild,
        );

        final Widget body = fancy
            ? CustomPaint(
                foregroundPainter: _LiquidGlassPainter(
                  radius: radius,
                  dark: dark,
                  accent: primary,
                  isFull: isFull,
                  isFrosted: frosted,
                ),
                child: core,
              )
            : core;

        Widget result;
        if (frosted && isFull) {
          // Use pure TileMode.mirror blur without ImageFilter.compose(ColorFilter, blur)
          // to avoid Flutter 3.47-3.50 Impeller nearest-neighbor banding (#196725),
          // edge smearing (#196727), and unbounded full-screen snapshots (#196728).
          final sigma = (blur <= 0 ? 11.0 : blur).clamp(0.0, 14.0).toDouble();
          result = RepaintBoundary(
            child: ClipRRect(
              borderRadius: radius,
              child: BackdropFilter(
                filter: ImageFilter.blur(
                  sigmaX: sigma,
                  sigmaY: sigma,
                  tileMode: TileMode.mirror,
                ),
                child: body,
              ),
            ),
          );
        } else if (radius == BorderRadius.zero) {
          result = body;
        } else {
          result = ClipRRect(borderRadius: radius, child: body);
        }

        if (fancy && isFull) {
          result = DecoratedBox(
            decoration: BoxDecoration(
              borderRadius: radius,
              boxShadow: [
                if (glow)
                  BoxShadow(
                    color: primary.withValues(alpha: dark ? .26 : .15),
                    blurRadius: 26,
                    spreadRadius: -5,
                  ),
                BoxShadow(
                  color: dark
                      ? Colors.black.withValues(alpha: frosted ? .38 : .28)
                      : Color(0xFF0C1A33).withValues(alpha: frosted ? .11 : .07),
                  blurRadius: frosted ? 22 : 16,
                  offset: Offset(0, frosted ? 8 : 5),
                  spreadRadius: -4,
                ),
              ],
            ),
            child: result,
          );
        }
        return result;
      },
    );
  }
}

/// Zero-blur Liquid Glass chat bubble container with curved top meniscus gloss
/// and directional specular rim refraction — smooth at 60/120fps on 3 GB RAM.
class LiquidGlassBubble extends StatelessWidget {
  const LiquidGlassBubble({
    required this.child,
    required this.outgoing,
    required this.borderRadius,
    this.margin = EdgeInsets.zero,
    this.padding = const EdgeInsets.fromLTRB(14, 10, 14, 8),
    this.maxWidth = 310,
    super.key,
  });

  final Widget child;
  final bool outgoing;
  final BorderRadius borderRadius;
  final EdgeInsetsGeometry margin;
  final EdgeInsetsGeometry padding;
  final double maxWidth;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    final effects = LikedinAppearance.effects.value;
    final fancy = effects != LikedinEffects.off;
    final isFull = effects == LikedinEffects.full;
    final primary = likedinPrimary(brightness);

    final fillColor = !fancy
        ? (outgoing ? likedinOutgoingBubble(brightness) : likedinSurface(brightness))
        : outgoing
            ? likedinOutgoingBubble(brightness).withValues(alpha: dark ? .68 : .74)
            : likedinIncomingBubble(brightness);

    final inner = Container(
      constraints: BoxConstraints(maxWidth: maxWidth),
      padding: padding,
      decoration: BoxDecoration(
        color: fillColor,
        borderRadius: borderRadius,
        border: !fancy
            ? Border.all(
                color: outgoing
                    ? primary.withValues(alpha: .45)
                    : likedinOutline(brightness),
              )
            : null,
      ),
      child: child,
    );

    final Widget bubble = fancy
        ? DecoratedBox(
            decoration: BoxDecoration(
              borderRadius: borderRadius,
              boxShadow: isFull
                  ? [
                      BoxShadow(
                        color: dark
                            ? Colors.black.withValues(alpha: .24)
                            : Color(0xFF0C1A33).withValues(alpha: .06),
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                        spreadRadius: -2,
                      ),
                    ]
                  : null,
            ),
            child: ClipRRect(
              borderRadius: borderRadius,
              child: CustomPaint(
                foregroundPainter: _LiquidGlassPainter(
                  radius: borderRadius,
                  dark: dark,
                  accent: primary,
                  isFull: isFull,
                  isFrosted: false,
                  accentBorderBoost: outgoing,
                ),
                child: inner,
              ),
            ),
          )
        : inner;

    return Padding(padding: margin, child: bubble);
  }
}

/// Unified app-wide Liquid Glass ambient backdrop driven by the active
/// [LikedinThemePreset]. Uses a rich 3-stop gradient plus three luminous static
/// light orbs so clear Liquid Glass panels catch real depth and refraction in
/// both Dark and Light modes with zero per-frame blur cost.
class AuroraBackdrop extends StatelessWidget {
  const AuroraBackdrop({required this.child, super.key});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    return ListenableBuilder(
      listenable: LikedinAppearance.listenable,
      child: child,
      builder: (context, builtChild) {
        final effects = LikedinAppearance.effects.value;
        final theme = LikedinAppearance.theme;
        final orb1 = dark ? theme.darkOrb1 : theme.lightOrb1;
        final orb2 = dark ? theme.darkOrb2 : theme.lightOrb2;
        final orb3 = dark ? theme.darkOrb3 : theme.lightOrb3;
        final bgColors = dark
            ? [theme.darkBgTop, theme.darkBgMid, theme.darkBgBottom]
            : [theme.lightBgTop, theme.lightBgMid, theme.lightBgBottom];

        final children = <Widget>[
          if (effects == LikedinEffects.off)
            ColoredBox(color: likedinBackground(brightness))
          else
            RepaintBoundary(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    stops: const [0.0, 0.52, 1.0],
                    colors: bgColors,
                  ),
                ),
                child: effects == LikedinEffects.full
                    ? Stack(
                        fit: StackFit.expand,
                        children: [
                          DecoratedBox(
                            decoration: BoxDecoration(
                              gradient: RadialGradient(
                                center: const Alignment(-.82, -.88),
                                radius: 1.05,
                                colors: [
                                  orb1.withValues(alpha: dark ? .34 : .26),
                                  orb1.withValues(alpha: 0),
                                ],
                              ),
                            ),
                          ),
                          DecoratedBox(
                            decoration: BoxDecoration(
                              gradient: RadialGradient(
                                center: const Alignment(.92, .82),
                                radius: .98,
                                colors: [
                                  orb2.withValues(alpha: dark ? .26 : .22),
                                  orb2.withValues(alpha: 0),
                                ],
                              ),
                            ),
                          ),
                          DecoratedBox(
                            decoration: BoxDecoration(
                              gradient: RadialGradient(
                                center: const Alignment(.78, -.16),
                                radius: .82,
                                colors: [
                                  orb3.withValues(alpha: dark ? .20 : .16),
                                  orb3.withValues(alpha: 0),
                                ],
                              ),
                            ),
                          ),
                        ],
                      )
                    : null,
              ),
            ),
          if (builtChild != null) builtChild,
        ];
        return Stack(fit: StackFit.expand, children: children);
      },
    );
  }
}

/// Lightweight tactile press-down scale for interactive glass buttons/cards.
class LikedinPressScale extends StatefulWidget {
  const LikedinPressScale({
    required this.child,
    this.enabled = true,
    this.pressedScale = 0.95,
    super.key,
  });

  final Widget child;
  final bool enabled;
  final double pressedScale;

  @override
  State<LikedinPressScale> createState() => _LikedinPressScaleState();
}

class _LikedinPressScaleState extends State<LikedinPressScale> {
  bool _pressed = false;

  void _setPressed(bool value) {
    if (!widget.enabled || LikedinAppearance.reduceMotion.value) return;
    if (_pressed != value && mounted) setState(() => _pressed = value);
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      behavior: HitTestBehavior.translucent,
      onPointerDown: (_) => _setPressed(true),
      onPointerUp: (_) => _setPressed(false),
      onPointerCancel: (_) => _setPressed(false),
      child: AnimatedScale(
        scale: _pressed ? widget.pressedScale : 1.0,
        duration: LikedinAppearance.reduceMotion.value
            ? Duration.zero
            : const Duration(milliseconds: 130),
        curve: Curves.easeOutCubic,
        child: widget.child,
      ),
    );
  }
}

/// Primary action button: Liquid Glass gradient pill with specular top rim.
class GradientButton extends StatelessWidget {
  const GradientButton({
    required this.onPressed,
    required this.child,
    this.height = 52,
    super.key,
  });

  final VoidCallback? onPressed;
  final Widget child;
  final double height;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final enabled = onPressed != null;
    final radius = BorderRadius.circular(height);
    return LikedinPressScale(
      enabled: enabled,
      child: Opacity(
        opacity: enabled ? 1 : .55,
        child: CustomPaint(
          foregroundPainter: _LiquidGlassPainter(
            radius: radius,
            dark: true,
            accent: likedinPrimary(brightness),
            isFull: LikedinAppearance.effects.value == LikedinEffects.full,
            isFrosted: false,
          ),
          child: Material(
            color: Colors.transparent,
            child: Ink(
              height: height,
              decoration: BoxDecoration(
                gradient: likedinPrimaryGradient(brightness),
                borderRadius: radius,
              ),
              child: InkWell(
                onTap: onPressed,
                borderRadius: radius,
                child: Center(
                  child: DefaultTextStyle.merge(
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                    ),
                    child: IconTheme.merge(
                      data: const IconThemeData(color: Colors.white),
                      child: child,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
