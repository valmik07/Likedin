import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'glassmorphism.dart';

/// Live chat activity states shown by the Snapchat-style peeking avatar.
enum ChatAvatarActivity { hidden, present, typing, recording }

/// Compact (~110-byte JSON) customizable 3D-shaded Bitmoji configuration synced
/// over Realtime Presence & Broadcast with zero database writes or uploads.
class ChatAvatarConfig {
  const ChatAvatarConfig({
    this.gender = 'male',
    this.skinIndex = 2,
    this.eyeColor = 0,
    this.hairStyle = 1,
    this.hairColor = 0,
    this.outfitStyle = 0,
    this.outfitColor = 0,
    this.accessory = 0,
    this.facialHair = 0,
  });

  final String gender; // 'male' | 'female'
  final int skinIndex; // 0..5
  final int eyeColor; // 0..5
  final int hairStyle; // 0..7
  final int hairColor; // 0..6
  final int outfitStyle; // 0..5
  final int outfitColor; // 0..9
  final int accessory; // 0..5
  final int facialHair; // 0..3

  static const ChatAvatarConfig maleDefault = ChatAvatarConfig(
    gender: 'male',
    skinIndex: 2,
    eyeColor: 0,
    hairStyle: 1,
    hairColor: 0,
    outfitStyle: 0,
    outfitColor: 0,
    accessory: 0,
    facialHair: 1,
  );

  static const ChatAvatarConfig femaleDefault = ChatAvatarConfig(
    gender: 'female',
    skinIndex: 1,
    eyeColor: 1,
    hairStyle: 4,
    hairColor: 1,
    outfitStyle: 0,
    outfitColor: 9,
    accessory: 0,
    facialHair: 0,
  );

  static const List<Color> skinTones = <Color>[
    Color(0xFFFFDFC8),
    Color(0xFFF6C6A0),
    Color(0xFFE2A779),
    Color(0xFFC58252),
    Color(0xFF9B5D36),
    Color(0xFF693B22),
  ];

  static const List<Color> eyeColors = <Color>[
    Color(0xFF3B2418), // Espresso
    Color(0xFF6B4423), // Warm Hazel
    Color(0xFF8C5E2A), // Honey Amber
    Color(0xFF2B6CB0), // Ocean Blue
    Color(0xFF2F855A), // Emerald
    Color(0xFF475569), // Slate Gray
  ];

  static const List<Color> hairColors = <Color>[
    Color(0xFF181920), // Jet Black
    Color(0xFF3A231E), // Deep Espresso
    Color(0xFF6B4433), // Warm Chestnut
    Color(0xFF9B3A26), // Copper Auburn
    Color(0xFFD6A354), // Honey Blonde
    Color(0xFF94A3B8), // Ash Silver
    Color(0xFFD85E8F), // Dusty Rose
  ];

  static const List<String> hairStyleNames = <String>[
    'Textured Fringe',
    'Curtain Flow',
    'Curly Fade',
    'Sleek Taper',
    'Layered Waves',
    'High Ponytail',
    'Soft Bob',
    'Messy Bun',
  ];

  static const List<String> outfitNames = <String>[
    'Oversized Hoodie',
    'Layered Tee',
    'Varsity Bomber',
    'Turtleneck',
    'Denim Jacket',
    'Festive Kurta',
  ];

  static const List<Color> outfitColors = <Color>[
    Color(0xFF2563EB), // Cobalt
    Color(0xFF10B981), // Mint
    Color(0xFFEF4444), // Crimson
    Color(0xFF8B5CF6), // Violet
    Color(0xFF1E293B), // Obsidian
    Color(0xFF9F1239), // Wine
    Color(0xFFD97706), // Amber
    Color(0xFF0EA5E9), // Sky
    Color(0xFF15803D), // Forest
    Color(0xFFEC4899), // Rose
  ];

  static const List<String> accessoryNames = <String>[
    'None',
    'Wire Glasses',
    'Shades',
    'Knit Beanie',
    'Cap',
    'Headphones',
  ];

  static const List<String> facialHairNames = <String>[
    'None',
    'Light Stubble',
    'Trimmed Beard',
    'Goatee',
  ];

  ChatAvatarConfig copyWith({
    String? gender,
    int? skinIndex,
    int? eyeColor,
    int? hairStyle,
    int? hairColor,
    int? outfitStyle,
    int? outfitColor,
    int? accessory,
    int? facialHair,
  }) =>
      ChatAvatarConfig(
        gender: gender ?? this.gender,
        skinIndex: (skinIndex ?? this.skinIndex).clamp(0, skinTones.length - 1),
        eyeColor: (eyeColor ?? this.eyeColor).clamp(0, eyeColors.length - 1),
        hairStyle: (hairStyle ?? this.hairStyle).clamp(0, hairStyleNames.length - 1),
        hairColor: (hairColor ?? this.hairColor).clamp(0, hairColors.length - 1),
        outfitStyle: (outfitStyle ?? this.outfitStyle).clamp(0, outfitNames.length - 1),
        outfitColor: (outfitColor ?? this.outfitColor).clamp(0, outfitColors.length - 1),
        accessory: (accessory ?? this.accessory).clamp(0, accessoryNames.length - 1),
        facialHair: (facialHair ?? this.facialHair).clamp(0, facialHairNames.length - 1),
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'g': gender == 'female' ? 'f' : 'm',
        's': skinIndex,
        'e': eyeColor,
        'hs': hairStyle,
        'hc': hairColor,
        'os': outfitStyle,
        'oc': outfitColor,
        'a': accessory,
        'f': facialHair,
      };

  static ChatAvatarConfig fromJson(Map<dynamic, dynamic> map) {
    int readInt(String key, int fallback, int max) {
      final raw = map[key];
      final v = raw is num ? raw.toInt() : int.tryParse(raw?.toString() ?? '');
      return (v ?? fallback).clamp(0, max);
    }

    final g = map['g']?.toString().toLowerCase() == 'f' ? 'female' : 'male';
    return ChatAvatarConfig(
      gender: g,
      skinIndex: readInt('s', 2, skinTones.length - 1),
      eyeColor: readInt('e', 0, eyeColors.length - 1),
      hairStyle: readInt('hs', g == 'female' ? 4 : 1, hairStyleNames.length - 1),
      hairColor: readInt('hc', 0, hairColors.length - 1),
      outfitStyle: readInt('os', 0, outfitNames.length - 1),
      outfitColor: readInt('oc', g == 'female' ? 9 : 0, outfitColors.length - 1),
      accessory: readInt('a', 0, accessoryNames.length - 1),
      facialHair: readInt('f', 0, facialHairNames.length - 1),
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ChatAvatarConfig &&
          other.gender == gender &&
          other.skinIndex == skinIndex &&
          other.eyeColor == eyeColor &&
          other.hairStyle == hairStyle &&
          other.hairColor == hairColor &&
          other.outfitStyle == outfitStyle &&
          other.outfitColor == outfitColor &&
          other.accessory == accessory &&
          other.facialHair == facialHair;

  @override
  int get hashCode => Object.hash(
        gender,
        skinIndex,
        eyeColor,
        hairStyle,
        hairColor,
        outfitStyle,
        outfitColor,
        accessory,
        facialHair,
      );

  static String _ownKey(String uid) => 'likedin_my_avatar_v1_$uid';
  static String _peerKey(String uid, String peerId) => 'likedin_peer_avatar_v1_${uid}_$peerId';

  static Future<ChatAvatarConfig> loadOwn(String uid) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_ownKey(uid));
      if (raw != null && raw.isNotEmpty) {
        final decoded = jsonDecode(raw);
        if (decoded is Map) return fromJson(decoded);
      }
    } catch (_) {}
    return maleDefault;
  }

  static Future<void> saveOwn(String uid, ChatAvatarConfig config) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_ownKey(uid), jsonEncode(config.toJson()));
    } catch (_) {}
  }

  static Future<ChatAvatarConfig> loadPeer(String uid, String peerId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_peerKey(uid, peerId));
      if (raw != null && raw.isNotEmpty) {
        final decoded = jsonDecode(raw);
        if (decoded is Map) return fromJson(decoded);
      }
    } catch (_) {}
    return femaleDefault;
  }

  static Future<void> savePeer(String uid, String peerId, ChatAvatarConfig config) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_peerKey(uid, peerId), jsonEncode(config.toJson()));
    } catch (_) {}
  }
}

/// Renders a modern 3D-shaded Memoji / Bitmoji-style character with soft radial
/// lighting, sculpted jawline, multi-layered volumetric hair, expressive irises,
/// modern streetwear, and 3D peeking hands gripping the composer bar.
class ChatBitmojiAvatar extends StatelessWidget {
  const ChatBitmojiAvatar({
    required this.config,
    this.size = 78,
    this.activity = ChatAvatarActivity.present,
    this.blinking = false,
    this.showPeekingHands = true,
    super.key,
  });

  final ChatAvatarConfig config;
  final double size;
  final ChatAvatarActivity activity;
  final bool blinking;
  final bool showPeekingHands;

  @override
  Widget build(BuildContext context) => SizedBox(
        width: size,
        height: size,
        child: CustomPaint(
          painter: _ModernBitmojiPainter(
            config: config,
            activity: activity,
            blinking: blinking,
            showPeekingHands: showPeekingHands,
          ),
        ),
      );
}

class _ModernBitmojiPainter extends CustomPainter {
  _ModernBitmojiPainter({
    required this.config,
    required this.activity,
    required this.blinking,
    required this.showPeekingHands,
  });

  final ChatAvatarConfig config;
  final ChatAvatarActivity activity;
  final bool blinking;
  final bool showPeekingHands;

  Color _shiftLightness(Color c, double delta) {
    final hsl = HSLColor.fromColor(c);
    return hsl.withLightness((hsl.lightness + delta).clamp(0.0, 1.0)).toColor();
  }

  Color _warmShadow(Color c, double delta) {
    final hsl = HSLColor.fromColor(c);
    return hsl
        .withLightness((hsl.lightness - delta).clamp(0.0, 1.0))
        .withSaturation((hsl.saturation + 0.08).clamp(0.0, 1.0))
        .toColor();
  }

  Path _sculptedHeadPath(double cx, double cy, double rx, double ry, bool isFemale) {
    final jawW = isFemale ? 0.72 : 0.84;
    final chinDrop = isFemale ? 1.01 : 1.03;
    return Path()
      ..moveTo(cx, cy - ry)
      ..cubicTo(cx + rx * 0.68, cy - ry, cx + rx * 1.02, cy - ry * 0.54, cx + rx * 0.99, cy + ry * 0.04)
      ..cubicTo(cx + rx * 0.96, cy + ry * 0.56, cx + rx * jawW, cy + ry * 0.94, cx, cy + ry * chinDrop)
      ..cubicTo(cx - rx * jawW, cy + ry * 0.94, cx - rx * 0.96, cy + ry * 0.56, cx - rx * 0.99, cy + ry * 0.04)
      ..cubicTo(cx - rx * 1.02, cy - ry * 0.54, cx - rx * 0.68, cy - ry, cx, cy - ry)
      ..close();
  }

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final cx = w * 0.50;
    final headCy = h * 0.445;
    final headRx = w * 0.245;
    final headRy = h * 0.270;

    final skin = ChatAvatarConfig.skinTones[config.skinIndex];
    final skinHighlight = _shiftLightness(skin, 0.09);
    final skinMidShadow = _warmShadow(skin, 0.11);
    final skinDeepShadow = _warmShadow(skin, 0.20);

    final hair = ChatAvatarConfig.hairColors[config.hairColor];
    final hairHighlight = _shiftLightness(hair, 0.17);
    final hairDeep = _shiftLightness(hair, -0.10);

    final outfit = ChatAvatarConfig.outfitColors[config.outfitColor];
    final outfitLight = _shiftLightness(outfit, 0.13);
    final outfitDark = _shiftLightness(outfit, -0.16);
    final eyeIris = ChatAvatarConfig.eyeColors[config.eyeColor];
    final isFemale = config.gender == 'female';

    // 1. Back hair mass (with subtle depth gradient)
    _paintBackHair(canvas, w, h, cx, headCy, headRx, headRy, hair, hairDeep, outfit);

    // 2. Sculpted shoulders & modern outfit
    _paintOutfit(canvas, w, h, cx, headCy, headRx, headRy, outfit, outfitLight, outfitDark);

    // 3. Neck with soft ambient occlusion under the chin
    final neckRect = Rect.fromCenter(
      center: Offset(cx, headCy + headRy * 1.02),
      width: headRx * (isFemale ? 0.52 : 0.62),
      height: headRy * 0.62,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(neckRect, Radius.circular(headRx * 0.26)),
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [skinDeepShadow, skinMidShadow, skin],
          stops: const [0.0, 0.48, 1.0],
        ).createShader(neckRect),
    );

    // 4. Ears with 3D inner concha depth
    for (final side in const [-1.0, 1.0]) {
      final ex = cx + side * headRx * 0.96;
      final ey = headCy + headRy * 0.07;
      final earRect = Rect.fromCenter(center: Offset(ex, ey), width: headRx * 0.28, height: headRy * 0.37);
      canvas.drawOval(
        earRect,
        Paint()
          ..shader = RadialGradient(
            center: Alignment(-side * 0.25, -0.25),
            radius: 0.95,
            colors: [skinHighlight, skin, skinMidShadow],
          ).createShader(earRect),
      );
      canvas.drawOval(
        Rect.fromCenter(center: Offset(ex - side * headRx * 0.03, ey + headRy * 0.02), width: headRx * 0.13, height: headRy * 0.19),
        Paint()..color = skinDeepShadow.withValues(alpha: .38),
      );
      if (isFemale) {
        // Subtle metallic stud earring
        canvas.drawCircle(
          Offset(ex + side * headRx * 0.02, ey + headRy * 0.16),
          w * 0.015,
          Paint()..color = const Color(0xFFFDE68A),
        );
      }
    }

    // 5. Headphones top arch (behind head crown if accessory == 5)
    if (config.accessory == 5) {
      final archRect = Rect.fromCenter(center: Offset(cx, headCy - headRy * 0.04), width: headRx * 2.28, height: headRy * 2.18);
      canvas.drawArc(
        archRect,
        pi,
        pi,
        false,
        Paint()
          ..color = const Color(0xFF1E293B)
          ..style = PaintingStyle.stroke
          ..strokeWidth = w * 0.062
          ..strokeCap = StrokeCap.round,
      );
      canvas.drawArc(
        archRect,
        pi + 0.35,
        pi - 0.70,
        false,
        Paint()
          ..color = Colors.white.withValues(alpha: .28)
          ..style = PaintingStyle.stroke
          ..strokeWidth = w * 0.016
          ..strokeCap = StrokeCap.round,
      );
    }

    // 6. Sculpted 3D-lit head
    final headPath = _sculptedHeadPath(cx, headCy, headRx, headRy, isFemale);
    final headBounds = Rect.fromCenter(center: Offset(cx, headCy), width: headRx * 2.1, height: headRy * 2.2);

    // Subtle soft drop shadow from head onto neck/shoulders
    canvas.drawPath(
      headPath.shift(Offset(0, h * 0.025)),
      Paint()
        ..color = Colors.black.withValues(alpha: .16)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, w * 0.028),
    );

    canvas.drawPath(
      headPath,
      Paint()
        ..shader = RadialGradient(
          center: const Alignment(-0.22, -0.35),
          radius: 1.05,
          colors: [skinHighlight, skin, skinMidShadow],
          stops: const [0.0, 0.56, 1.0],
        ).createShader(headBounds),
    );

    // Subtle rim light along left cheek/jaw
    canvas.drawPath(
      headPath,
      Paint()
        ..color = skinMidShadow.withValues(alpha: .35)
        ..style = PaintingStyle.stroke
        ..strokeWidth = w * 0.011,
    );

    // Warm airbrushed blush cheeks
    final blushPaint = Paint()
      ..color = const Color(0xFFFB7185).withValues(alpha: isFemale ? .24 : .11)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, w * 0.030);
    for (final side in const [-1.0, 1.0]) {
      canvas.drawOval(
        Rect.fromCenter(
          center: Offset(cx + side * headRx * 0.52, headCy + headRy * 0.22),
          width: headRx * 0.42,
          height: headRy * 0.22,
        ),
        blushPaint,
      );
    }

    // 7. Facial hair (clipped softly to lower jawline)
    if (config.facialHair > 0) {
      canvas.save();
      canvas.clipPath(headPath);
      _paintFacialHair(canvas, cx, headCy, headRx, headRy, hair, hairDeep, config.facialHair);
      canvas.restore();
    }

    // 8. Expressive modern Memoji face (eyes, sculpted nose, contoured lips)
    _paintFace(canvas, w, cx, headCy, headRx, headRy, hair, eyeIris, skinHighlight, skinMidShadow, skinDeepShadow, isFemale);

    // 9. Soft forehead ambient-occlusion shadow cast by bangs
    canvas.save();
    canvas.clipPath(headPath);
    canvas.drawOval(
      Rect.fromCenter(center: Offset(cx, headCy - headRy * 0.68), width: headRx * 2.1, height: headRy * 0.55),
      Paint()
        ..color = skinDeepShadow.withValues(alpha: .20)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, w * 0.025),
    );
    canvas.restore();

    // 10. Multi-layered volumetric front hair + glossy crown sheen
    _paintFrontHair(canvas, w, h, cx, headCy, headRx, headRy, hair, hairHighlight, hairDeep);

    // 11. Modern accessories (glasses, shades, beanie, cap, headphone ear cups)
    _paintAccessories(canvas, w, cx, headCy, headRx, headRy, outfit, outfitLight, outfitDark);

    // 12. 3D-shaded peeking hands gripping the composer bar
    if (showPeekingHands) {
      _paintPeekingHands(canvas, w, h, cx, skinHighlight, skin, skinMidShadow);
    }
  }

  void _paintBackHair(
    Canvas canvas,
    double w,
    double h,
    double cx,
    double headCy,
    double headRx,
    double headRy,
    Color hair,
    Color hairDeep,
    Color accent,
  ) {
    final bounds = Rect.fromLTWH(0, 0, w, h);
    final hairPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [hair, hairDeep],
      ).createShader(bounds);

    switch (config.hairStyle) {
      case 4: // Layered Waves (long flowing volume)
        final hairEndY = showPeekingHands ? h * 0.90 : h * 0.98;
        final path = Path()
          ..moveTo(cx - headRx * 1.16, headCy - headRy * 0.30)
          ..cubicTo(cx - headRx * 1.42, headCy + headRy * 0.50, cx - headRx * 1.32, headCy + headRy * 1.38, cx - headRx * 0.96, hairEndY)
          ..lineTo(cx + headRx * 0.96, hairEndY)
          ..cubicTo(cx + headRx * 1.32, headCy + headRy * 1.38, cx + headRx * 1.42, headCy + headRy * 0.50, cx + headRx * 1.16, headCy - headRy * 0.30)
          ..close();
        canvas.drawPath(path, hairPaint);
        break;
      case 5: // High Ponytail
        final tail = Path()
          ..moveTo(cx + headRx * 0.45, headCy - headRy * 0.85)
          ..cubicTo(cx + headRx * 1.42, headCy - headRy * 0.82, cx + headRx * 1.52, headCy + headRy * 0.32, cx + headRx * 1.05, headCy + headRy * 0.98)
          ..cubicTo(cx + headRx * 0.82, headCy + headRy * 0.45, cx + headRx * 0.95, headCy - headRy * 0.25, cx + headRx * 0.40, headCy - headRy * 0.55)
          ..close();
        canvas.drawPath(tail, hairPaint);
        canvas.drawOval(
          Rect.fromCenter(center: Offset(cx + headRx * 0.56, headCy - headRy * 0.72), width: headRx * 0.30, height: headRy * 0.22),
          Paint()..color = accent,
        );
        break;
      case 6: // Soft Bob
        final bob = Path()
          ..moveTo(cx - headRx * 1.12, headCy - headRy * 0.32)
          ..cubicTo(cx - headRx * 1.36, headCy + headRy * 0.45, cx - headRx * 1.24, headCy + headRy * 1.12, cx - headRx * 0.62, headCy + headRy * 1.14)
          ..lineTo(cx + headRx * 0.62, headCy + headRy * 1.14)
          ..cubicTo(cx + headRx * 1.24, headCy + headRy * 1.12, cx + headRx * 1.36, headCy + headRy * 0.45, cx + headRx * 1.12, headCy - headRy * 0.32)
          ..close();
        canvas.drawPath(bob, hairPaint);
        break;
      case 7: // Messy Top Bun
        final bunCenter = Offset(cx, headCy - headRy * 1.18);
        canvas.drawOval(
          Rect.fromCenter(center: bunCenter, width: headRx * 1.08, height: headRy * 0.74),
          hairPaint,
        );
        canvas.drawArc(
          Rect.fromCenter(center: Offset(cx, headCy - headRy * 0.95), width: headRx * 0.76, height: headRy * 0.26),
          0,
          pi,
          false,
          Paint()
            ..color = accent
            ..style = PaintingStyle.stroke
            ..strokeWidth = w * 0.028,
        );
        break;
      default:
        break;
    }
  }

  void _paintOutfit(
    Canvas canvas,
    double w,
    double h,
    double cx,
    double headCy,
    double headRx,
    double headRy,
    Color outfit,
    Color outfitLight,
    Color outfitDark,
  ) {
    final shoulderTop = headCy + headRy * 1.02;
    final bodyBottom = showPeekingHands ? h * 0.90 : h * 1.02;
    final bodyRect = Rect.fromLTRB(cx - w * 0.38, shoulderTop, cx + w * 0.38, bodyBottom);
    final bodyRRect = RRect.fromRectAndCorners(
      bodyRect,
      topLeft: Radius.circular(w * 0.26),
      topRight: Radius.circular(w * 0.26),
    );
    canvas.drawRRect(
      bodyRRect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [outfitLight, outfit, outfitDark],
          stops: const [0.0, 0.48, 1.0],
        ).createShader(bodyRect),
    );

    canvas.save();
    canvas.clipRRect(bodyRRect);

    switch (config.outfitStyle) {
      case 0: // Oversized Hoodie: plush collar rim + shaded interior + aglet drawstrings
        final hoodRim = Rect.fromCenter(center: Offset(cx, shoulderTop + h * 0.03), width: w * 0.40, height: h * 0.17);
        canvas.drawOval(hoodRim, Paint()..color = outfitDark.withValues(alpha: .72));
        canvas.drawArc(
          hoodRim,
          0.12,
          pi - 0.24,
          false,
          Paint()
            ..color = outfitLight.withValues(alpha: .55)
            ..style = PaintingStyle.stroke
            ..strokeWidth = w * 0.042
            ..strokeCap = StrokeCap.round,
        );
        final stringPaint = Paint()
          ..color = Colors.white.withValues(alpha: .92)
          ..strokeWidth = w * 0.019
          ..strokeCap = StrokeCap.round;
        canvas.drawLine(Offset(cx - w * 0.062, shoulderTop + h * 0.09), Offset(cx - w * 0.068, shoulderTop + h * 0.24), stringPaint);
        canvas.drawLine(Offset(cx + w * 0.062, shoulderTop + h * 0.09), Offset(cx + w * 0.068, shoulderTop + h * 0.22), stringPaint);
        final aglet = Paint()..color = const Color(0xFF94A3B8);
        canvas.drawCircle(Offset(cx - w * 0.068, shoulderTop + h * 0.24), w * 0.012, aglet);
        canvas.drawCircle(Offset(cx + w * 0.068, shoulderTop + h * 0.22), w * 0.012, aglet);
        break;
      case 1: // Layered Streetwear Tee
        canvas.drawArc(
          Rect.fromCenter(center: Offset(cx, shoulderTop), width: w * 0.28, height: h * 0.14),
          0,
          pi,
          false,
          Paint()
            ..color = outfitDark
            ..style = PaintingStyle.stroke
            ..strokeWidth = w * 0.034,
        );
        canvas.drawRect(
          Rect.fromLTRB(cx - w * 0.40, shoulderTop + h * 0.15, cx + w * 0.40, shoulderTop + h * 0.20),
          Paint()..color = Colors.white.withValues(alpha: .20),
        );
        break;
      case 2: // Varsity Bomber (contrast sleeves + striped collar + center snaps)
        final sleevePaint = Paint()..color = Colors.white.withValues(alpha: .90);
        canvas.drawRect(Rect.fromLTRB(cx - w * 0.40, shoulderTop, cx - w * 0.22, h), sleevePaint);
        canvas.drawRect(Rect.fromLTRB(cx + w * 0.22, shoulderTop, cx + w * 0.40, h), sleevePaint);
        canvas.drawArc(
          Rect.fromCenter(center: Offset(cx, shoulderTop), width: w * 0.30, height: h * 0.15),
          0,
          pi,
          false,
          Paint()
            ..color = Colors.white.withValues(alpha: .88)
            ..style = PaintingStyle.stroke
            ..strokeWidth = w * 0.030,
        );
        canvas.drawLine(
          Offset(cx, shoulderTop + h * 0.07),
          Offset(cx, h),
          Paint()
            ..color = outfitDark.withValues(alpha: .55)
            ..strokeWidth = w * 0.015,
        );
        for (final dy in const [0.12, 0.20]) {
          canvas.drawCircle(Offset(cx, shoulderTop + h * dy), w * 0.014, Paint()..color = Colors.white);
        }
        break;
      case 3: // Cozy Ribbed Turtleneck
        final neckFold = RRect.fromRectAndRadius(
          Rect.fromCenter(center: Offset(cx, shoulderTop + h * 0.02), width: w * 0.28, height: h * 0.11),
          Radius.circular(w * 0.05),
        );
        canvas.drawRRect(neckFold, Paint()..color = outfitLight);
        final rib = Paint()
          ..color = outfitDark.withValues(alpha: .32)
          ..strokeWidth = w * 0.012;
        for (var x = -0.10; x <= 0.10; x += 0.04) {
          canvas.drawLine(Offset(cx + w * x, shoulderTop - h * 0.02), Offset(cx + w * x, shoulderTop + h * 0.07), rib);
        }
        break;
      case 4: // Denim / Moto Jacket with crisp inner tee & lapels
        canvas.drawRect(
          Rect.fromCenter(center: Offset(cx, shoulderTop + h * 0.16), width: w * 0.19, height: h * 0.34),
          Paint()..color = Colors.white.withValues(alpha: .94),
        );
        for (final side in const [-1.0, 1.0]) {
          final lapel = Path()
            ..moveTo(cx + side * w * 0.10, shoulderTop + h * 0.01)
            ..lineTo(cx + side * w * 0.21, shoulderTop + h * 0.08)
            ..lineTo(cx + side * w * 0.12, shoulderTop + h * 0.20)
            ..lineTo(cx + side * w * 0.09, shoulderTop + h * 0.02)
            ..close();
          canvas.drawPath(lapel, Paint()..color = outfitLight);
          canvas.drawCircle(Offset(cx + side * w * 0.14, shoulderTop + h * 0.16), w * 0.013, Paint()..color = const Color(0xFFE2E8F0));
        }
        break;
      case 5: // Festive Kurta with gold-trimmed placket
        final placket = RRect.fromRectAndRadius(
          Rect.fromCenter(center: Offset(cx, shoulderTop + h * 0.12), width: w * 0.078, height: h * 0.21),
          Radius.circular(w * 0.02),
        );
        canvas.drawRRect(placket, Paint()..color = outfitDark);
        canvas.drawRRect(
          placket,
          Paint()
            ..color = const Color(0xFFFBBF24).withValues(alpha: .72)
            ..style = PaintingStyle.stroke
            ..strokeWidth = w * 0.010,
        );
        final gold = Paint()..color = const Color(0xFFFDE047);
        for (final dy in const [0.07, 0.125, 0.18]) {
          canvas.drawCircle(Offset(cx, shoulderTop + h * dy), w * 0.012, gold);
        }
        break;
    }

    canvas.restore();
  }

  void _paintFacialHair(
    Canvas canvas,
    double cx,
    double headCy,
    double headRx,
    double headRy,
    Color hair,
    Color hairDeep,
    int style,
  ) {
    if (style == 1) {
      // Soft airbrushed stubble
      canvas.drawOval(
        Rect.fromCenter(center: Offset(cx, headCy + headRy * 0.62), width: headRx * 1.98, height: headRy * 1.25),
        Paint()
          ..color = hairDeep.withValues(alpha: .19)
          ..maskFilter = MaskFilter.blur(BlurStyle.normal, headRx * 0.10),
      );
    } else if (style == 2) {
      // Sculpted trimmed beard + mustache
      final beard = Path()
        ..moveTo(cx - headRx * 0.98, headCy + headRy * 0.12)
        ..cubicTo(cx - headRx * 0.95, headCy + headRy * 1.08, cx - headRx * 0.45, headCy + headRy * 1.15, cx, headCy + headRy * 1.14)
        ..cubicTo(cx + headRx * 0.45, headCy + headRy * 1.15, cx + headRx * 0.95, headCy + headRy * 1.08, cx + headRx * 0.98, headCy + headRy * 0.12)
        ..quadraticBezierTo(cx + headRx * 0.62, headCy + headRy * 0.46, cx + headRx * 0.34, headCy + headRy * 0.36)
        ..quadraticBezierTo(cx, headCy + headRy * 0.25, cx - headRx * 0.34, headCy + headRy * 0.36)
        ..quadraticBezierTo(cx - headRx * 0.62, headCy + headRy * 0.46, cx - headRx * 0.98, headCy + headRy * 0.12)
        ..close();
      canvas.drawPath(
        beard,
        Paint()
          ..shader = LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [hair.withValues(alpha: .82), hairDeep.withValues(alpha: .94)],
          ).createShader(Rect.fromCenter(center: Offset(cx, headCy + headRy * 0.65), width: headRx * 2, height: headRy * 1.1)),
      );
    } else if (style == 3) {
      // Modern sculpted goatee
      canvas.drawOval(
        Rect.fromCenter(center: Offset(cx, headCy + headRy * 0.68), width: headRx * 0.72, height: headRy * 0.64),
        Paint()..color = hair.withValues(alpha: .84),
      );
    }
  }

  void _paintFace(
    Canvas canvas,
    double w,
    double cx,
    double headCy,
    double headRx,
    double headRy,
    Color hair,
    Color eyeIris,
    Color skinHighlight,
    Color skinMidShadow,
    Color skinDeepShadow,
    bool isFemale,
  ) {
    final gazeShiftY = activity == ChatAvatarActivity.typing ? headRy * 0.055 : 0.0;
    final eyeY = headCy - headRy * 0.01 + gazeShiftY * 0.6;
    final eyeOffsetX = headRx * 0.39;
    final eyeW = headRx * 0.39;
    final eyeH = headRy * (isFemale ? 0.31 : 0.28);

    // Sculpted tapered eyebrows (filled curved polygons, not flat lines)
    final browLift = activity == ChatAvatarActivity.recording ? -headRy * 0.075 : 0.0;
    final browThick = headRy * (isFemale ? 0.055 : 0.075);
    for (final side in const [-1.0, 1.0]) {
      final bx = cx + side * eyeOffsetX;
      final by = eyeY - headRy * 0.26 + browLift;
      final browPath = Path()
        ..moveTo(bx - side * eyeW * 0.60, by + browThick * 0.25)
        ..quadraticBezierTo(bx, by - browThick * 1.15, bx + side * eyeW * 0.62, by + browThick * 0.35)
        ..quadraticBezierTo(bx, by - browThick * 0.15, bx - side * eyeW * 0.60, by + browThick * 0.65)
        ..close();
      canvas.drawPath(browPath, Paint()..color = hair);
    }

    // Detailed Memoji eyes
    if (blinking) {
      final lidPaint = Paint()
        ..color = const Color(0xFF1E1B18)
        ..style = PaintingStyle.stroke
        ..strokeWidth = w * 0.025
        ..strokeCap = StrokeCap.round;
      for (final side in const [-1.0, 1.0]) {
        final ex = cx + side * eyeOffsetX;
        canvas.drawArc(
          Rect.fromCenter(center: Offset(ex, eyeY + eyeH * 0.1), width: eyeW * 1.05, height: eyeH * 0.85),
          0.18,
          pi - 0.36,
          false,
          lidPaint,
        );
      }
    } else {
      final irisRadius = min(eyeW, eyeH) * 0.44;
      final pupilShiftY = activity == ChatAvatarActivity.typing ? irisRadius * 0.30 : 0.0;
      for (final side in const [-1.0, 1.0]) {
        final ex = cx + side * eyeOffsetX;
        final eyeRect = Rect.fromCenter(center: Offset(ex, eyeY), width: eyeW, height: eyeH);

        // Subtle upper eyelid crease
        canvas.drawArc(
          Rect.fromCenter(center: Offset(ex, eyeY - eyeH * 0.22), width: eyeW * 1.08, height: eyeH * 0.90),
          pi + 0.38,
          pi - 0.76,
          false,
          Paint()
            ..color = skinDeepShadow.withValues(alpha: .35)
            ..style = PaintingStyle.stroke
            ..strokeWidth = w * 0.011
            ..strokeCap = StrokeCap.round,
        );

        // Almond sclera clipped for iris + top shadow
        final eyePath = Path()..addOval(eyeRect);
        canvas.save();
        canvas.clipPath(eyePath);
        canvas.drawRect(
          eyeRect,
          Paint()
            ..shader = LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: const [Color(0xFFDDE3EE), Color(0xFFFFFFFF), Color(0xFFF8FAFC)],
              stops: const [0.0, 0.32, 1.0],
            ).createShader(eyeRect),
        );

        final irisCenter = Offset(ex, eyeY + pupilShiftY);
        final irisRect = Rect.fromCircle(center: irisCenter, radius: irisRadius);
        // Colored 3D iris + limbal ring
        canvas.drawCircle(
          irisCenter,
          irisRadius,
          Paint()
            ..shader = RadialGradient(
              center: const Alignment(0, 0.35),
              radius: 0.95,
              colors: [_shiftLightness(eyeIris, 0.18), eyeIris, _shiftLightness(eyeIris, -0.18)],
            ).createShader(irisRect),
        );
        // Deep pupil
        canvas.drawCircle(irisCenter, irisRadius * 0.54, Paint()..color = const Color(0xFF0F1014));
        // Double specular catchlights (signature modern Memoji sparkle)
        canvas.drawCircle(
          Offset(irisCenter.dx - irisRadius * 0.34, irisCenter.dy - irisRadius * 0.32),
          irisRadius * 0.27,
          Paint()..color = Colors.white,
        );
        canvas.drawCircle(
          Offset(irisCenter.dx + irisRadius * 0.28, irisCenter.dy + irisRadius * 0.28),
          irisRadius * 0.12,
          Paint()..color = Colors.white.withValues(alpha: .82),
        );
        canvas.restore();

        // Crisp upper lash line
        canvas.drawArc(
          eyeRect,
          pi + 0.18,
          pi - 0.36,
          false,
          Paint()
            ..color = const Color(0xFF18181B)
            ..style = PaintingStyle.stroke
            ..strokeWidth = w * (isFemale ? 0.025 : 0.018)
            ..strokeCap = StrokeCap.round,
        );
        if (isFemale) {
          // Winged outer eyelashes
          final lashPaint = Paint()
            ..color = const Color(0xFF18181B)
            ..strokeWidth = w * 0.017
            ..strokeCap = StrokeCap.round;
          canvas.drawLine(
            Offset(ex + side * eyeW * 0.45, eyeY - eyeH * 0.16),
            Offset(ex + side * eyeW * 0.64, eyeY - eyeH * 0.42),
            lashPaint,
          );
        }
      }
    }

    // Sculpted 3D nose (soft under-shadow + glossy tip highlight)
    final noseY = headCy + headRy * 0.19;
    canvas.drawOval(
      Rect.fromCenter(center: Offset(cx, noseY + headRy * 0.05), width: headRx * 0.24, height: headRy * 0.10),
      Paint()
        ..color = skinDeepShadow.withValues(alpha: .32)
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, w * 0.012),
    );
    canvas.drawOval(
      Rect.fromCenter(center: Offset(cx - headRx * 0.02, noseY - headRy * 0.02), width: headRx * 0.12, height: headRy * 0.07),
      Paint()..color = skinHighlight.withValues(alpha: .65),
    );
    canvas.drawArc(
      Rect.fromCenter(center: Offset(cx, noseY + headRy * 0.02), width: headRx * 0.20, height: headRy * 0.11),
      0.22,
      pi - 0.44,
      false,
      Paint()
        ..color = skinMidShadow
        ..style = PaintingStyle.stroke
        ..strokeWidth = w * 0.015
        ..strokeCap = StrokeCap.round,
    );

    // Expressive contoured mouth
    final mouthY = headCy + headRy * 0.47;
    final lipTone = isFemale ? const Color(0xFFD9647A) : _warmShadow(skinMidShadow, 0.06);
    if (activity == ChatAvatarActivity.recording) {
      // Animated speaking mouth
      final openRect = Rect.fromCenter(center: Offset(cx, mouthY + headRy * 0.02), width: headRx * 0.36, height: headRy * 0.28);
      canvas.drawOval(openRect, Paint()..color = const Color(0xFF7F1D1D));
      canvas.drawOval(
        openRect,
        Paint()
          ..color = lipTone
          ..style = PaintingStyle.stroke
          ..strokeWidth = w * 0.018,
      );
      canvas.drawArc(
        Rect.fromCenter(center: Offset(cx, mouthY + headRy * 0.09), width: headRx * 0.24, height: headRy * 0.14),
        0,
        pi,
        true,
        Paint()..color = const Color(0xFFF472B6),
      );
    } else if (activity == ChatAvatarActivity.typing) {
      // Big cheerful grin with bright teeth + tongue
      final grinRect = Rect.fromCenter(center: Offset(cx, mouthY - headRy * 0.02), width: headRx * 0.62, height: headRy * 0.36);
      final grinPath = Path()..addArc(grinRect, 0, pi)..close();
      canvas.save();
      canvas.clipPath(grinPath);
      canvas.drawRect(grinRect, Paint()..color = const Color(0xFF881337));
      // Upper teeth bar
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTRB(cx - headRx * 0.30, mouthY - headRy * 0.04, cx + headRx * 0.30, mouthY + headRy * 0.055),
          Radius.circular(w * 0.02),
        ),
        Paint()..color = Colors.white,
      );
      // Soft tongue
      canvas.drawOval(
        Rect.fromCenter(center: Offset(cx, mouthY + headRy * 0.16), width: headRx * 0.32, height: headRy * 0.14),
        Paint()..color = const Color(0xFFFB7185),
      );
      canvas.restore();
      canvas.drawPath(
        grinPath,
        Paint()
          ..color = lipTone.withValues(alpha: .85)
          ..style = PaintingStyle.stroke
          ..strokeWidth = w * 0.014,
      );
    } else {
      // Soft natural contoured smile + subtle lower-lip gloss
      final smileRect = Rect.fromCenter(center: Offset(cx, mouthY - headRy * 0.06), width: headRx * 0.54, height: headRy * 0.28);
      if (isFemale) {
        // Fuller soft tinted lips
        final upperLip = Path()
          ..moveTo(cx - headRx * 0.27, mouthY + headRy * 0.01)
          ..quadraticBezierTo(cx - headRx * 0.10, mouthY - headRy * 0.08, cx, mouthY - headRy * 0.02)
          ..quadraticBezierTo(cx + headRx * 0.10, mouthY - headRy * 0.08, cx + headRx * 0.27, mouthY + headRy * 0.01)
          ..quadraticBezierTo(cx, mouthY + headRy * 0.06, cx - headRx * 0.27, mouthY + headRy * 0.01)
          ..close();
        canvas.drawPath(upperLip, Paint()..color = lipTone.withValues(alpha: .86));
        canvas.drawArc(
          Rect.fromCenter(center: Offset(cx, mouthY + headRy * 0.01), width: headRx * 0.46, height: headRy * 0.20),
          0,
          pi,
          true,
          Paint()..color = _shiftLightness(lipTone, 0.07),
        );
        canvas.drawOval(
          Rect.fromCenter(center: Offset(cx, mouthY + headRy * 0.075), width: headRx * 0.18, height: headRy * 0.045),
          Paint()..color = Colors.white.withValues(alpha: .40),
        );
      } else {
        canvas.drawArc(
          smileRect,
          0.16,
          pi - 0.32,
          false,
          Paint()
            ..color = const Color(0xFF6B2D22)
            ..style = PaintingStyle.stroke
            ..strokeWidth = w * 0.024
            ..strokeCap = StrokeCap.round,
        );
        // Subtle lower-lip shadow
        canvas.drawArc(
          Rect.fromCenter(center: Offset(cx, mouthY + headRy * 0.08), width: headRx * 0.26, height: headRy * 0.08),
          0.2,
          pi - 0.4,
          false,
          Paint()
            ..color = skinDeepShadow.withValues(alpha: .35)
            ..style = PaintingStyle.stroke
            ..strokeWidth = w * 0.014
            ..strokeCap = StrokeCap.round,
        );
      }
    }
  }

  void _paintFrontHair(
    Canvas canvas,
    double w,
    double h,
    double cx,
    double headCy,
    double headRx,
    double headRy,
    Color hair,
    Color hairHighlight,
    Color hairDeep,
  ) {
    final hairBounds = Rect.fromCenter(center: Offset(cx, headCy - headRy * 0.45), width: headRx * 2.5, height: headRy * 1.9);
    final hairPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [hairHighlight, hair, hairDeep],
        stops: const [0.0, 0.42, 1.0],
      ).createShader(hairBounds);

    switch (config.hairStyle) {
      case 0: // Textured Fringe (modern messy crop)
        final path = Path()
          ..moveTo(cx - headRx * 1.02, headCy - headRy * 0.18)
          ..cubicTo(cx - headRx * 1.12, headCy - headRy * 1.15, cx - headRx * 0.30, headCy - headRy * 1.28, cx + headRx * 0.10, headCy - headRy * 1.22)
          ..cubicTo(cx + headRx * 0.72, headCy - headRy * 1.24, cx + headRx * 1.12, headCy - headRy * 0.82, cx + headRx * 1.02, headCy - headRy * 0.16)
          ..quadraticBezierTo(cx + headRx * 0.72, headCy - headRy * 0.42, cx + headRx * 0.42, headCy - headRy * 0.34)
          ..quadraticBezierTo(cx + headRx * 0.25, headCy - headRy * 0.56, cx + headRx * 0.02, headCy - headRy * 0.32)
          ..quadraticBezierTo(cx - headRx * 0.25, headCy - headRy * 0.58, cx - headRx * 0.52, headCy - headRy * 0.34)
          ..quadraticBezierTo(cx - headRx * 0.80, headCy - headRy * 0.48, cx - headRx * 1.02, headCy - headRy * 0.18)
          ..close();
        canvas.drawPath(path, hairPaint);
        break;
      case 1: // Curtain Flow / Modern Wolf Cut
        final left = Path()
          ..moveTo(cx, headCy - headRy * 1.24)
          ..cubicTo(cx - headRx * 0.92, headCy - headRy * 1.26, cx - headRx * 1.22, headCy - headRy * 0.52, cx - headRx * 1.04, headCy + headRy * 0.06)
          ..quadraticBezierTo(cx - headRx * 0.62, headCy - headRy * 0.28, cx - headRx * 0.06, headCy - headRy * 0.70)
          ..close();
        final right = Path()
          ..moveTo(cx, headCy - headRy * 1.24)
          ..cubicTo(cx + headRx * 0.92, headCy - headRy * 1.26, cx + headRx * 1.22, headCy - headRy * 0.52, cx + headRx * 1.04, headCy + headRy * 0.06)
          ..quadraticBezierTo(cx + headRx * 0.62, headCy - headRy * 0.28, cx + headRx * 0.06, headCy - headRy * 0.70)
          ..close();
        canvas.drawPath(left, hairPaint);
        canvas.drawPath(right, hairPaint);
        break;
      case 2: // Curly Fade (layered cloud curls)
        final curls = <({Offset c, double r})>[
          (c: Offset(cx - headRx * 0.76, headCy - headRy * 0.66), r: headRx * 0.38),
          (c: Offset(cx - headRx * 0.42, headCy - headRy * 0.96), r: headRx * 0.42),
          (c: Offset(cx, headCy - headRy * 1.06), r: headRx * 0.46),
          (c: Offset(cx + headRx * 0.42, headCy - headRy * 0.96), r: headRx * 0.42),
          (c: Offset(cx + headRx * 0.76, headCy - headRy * 0.66), r: headRx * 0.38),
          (c: Offset(cx - headRx * 0.88, headCy - headRy * 0.34), r: headRx * 0.28),
          (c: Offset(cx + headRx * 0.88, headCy - headRy * 0.34), r: headRx * 0.28),
          (c: Offset(cx - headRx * 0.24, headCy - headRy * 0.66), r: headRx * 0.34),
          (c: Offset(cx + headRx * 0.26, headCy - headRy * 0.66), r: headRx * 0.34),
        ];
        for (final curl in curls) {
          canvas.drawCircle(curl.c, curl.r, hairPaint);
        }
        break;
      case 3: // Sleek Side Taper
        final path = Path()
          ..moveTo(cx - headRx * 1.00, headCy - headRy * 0.14)
          ..cubicTo(cx - headRx * 1.06, headCy - headRy * 1.18, cx - headRx * 0.15, headCy - headRy * 1.26, cx + headRx * 0.38, headCy - headRy * 1.18)
          ..cubicTo(cx + headRx * 1.08, headCy - headRy * 1.05, cx + headRx * 1.08, headCy - headRy * 0.48, cx + headRx * 0.98, headCy - headRy * 0.14)
          ..quadraticBezierTo(cx + headRx * 0.56, headCy - headRy * 0.58, cx - headRx * 0.38, headCy - headRy * 0.78)
          ..quadraticBezierTo(cx - headRx * 0.76, headCy - headRy * 0.52, cx - headRx * 1.00, headCy - headRy * 0.14)
          ..close();
        canvas.drawPath(path, hairPaint);
        break;
      default: // 4..7 (Layered Waves, High Ponytail, Soft Bob, Messy Bun) — sculpted curtain bangs + face-framing wisps
        final path = Path()
          ..moveTo(cx - headRx * 1.08, headCy + headRy * 0.08)
          ..cubicTo(cx - headRx * 1.16, headCy - headRy * 1.16, cx - headRx * 0.35, headCy - headRy * 1.24, cx, headCy - headRy * 1.22)
          ..cubicTo(cx + headRx * 0.35, headCy - headRy * 1.24, cx + headRx * 1.16, headCy - headRy * 1.16, cx + headRx * 1.08, headCy + headRy * 0.08)
          ..quadraticBezierTo(cx + headRx * 0.76, headCy - headRy * 0.34, cx + headRx * 0.10, headCy - headRy * 0.74)
          ..quadraticBezierTo(cx - headRx * 0.68, headCy - headRy * 0.34, cx - headRx * 1.08, headCy + headRy * 0.08)
          ..close();
        canvas.drawPath(path, hairPaint);
        break;
    }

    // Glossy 3D hair sheen arc
    canvas.drawArc(
      Rect.fromCenter(center: Offset(cx - headRx * 0.04, headCy - headRy * 0.34), width: headRx * 1.48, height: headRy * 1.26),
      -2.38,
      1.18,
      false,
      Paint()
        ..color = Colors.white.withValues(alpha: .20)
        ..style = PaintingStyle.stroke
        ..strokeWidth = w * 0.024
        ..strokeCap = StrokeCap.round
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, w * 0.008),
    );
  }

  void _paintAccessories(
    Canvas canvas,
    double w,
    double cx,
    double headCy,
    double headRx,
    double headRy,
    Color outfit,
    Color outfitLight,
    Color outfitDark,
  ) {
    final eyeY = headCy - headRy * 0.01 + (activity == ChatAvatarActivity.typing ? headRy * 0.033 : 0);
    final eyeOffsetX = headRx * 0.39;

    if (config.accessory == 1 || config.accessory == 2) {
      // Modern Wire Glasses (1) or Glossy Wayfarer Shades (2)
      final isShades = config.accessory == 2;
      final lensW = headRx * (isShades ? 0.74 : 0.68);
      final lensH = headRy * (isShades ? 0.50 : 0.48);
      final framePaint = Paint()
        ..color = isShades ? const Color(0xFF0F172A) : const Color(0xFF334155)
        ..style = PaintingStyle.stroke
        ..strokeWidth = w * (isShades ? 0.028 : 0.020);

      for (final side in const [-1.0, 1.0]) {
        final rect = Rect.fromCenter(center: Offset(cx + side * eyeOffsetX, eyeY), width: lensW, height: lensH);
        final rrect = RRect.fromRectAndRadius(rect, Radius.circular(isShades ? lensH * 0.34 : lensH * 0.48));
        // Subtle drop shadow under frames
        canvas.drawRRect(
          rrect.shift(Offset(0, w * 0.012)),
          Paint()
            ..color = Colors.black.withValues(alpha: .16)
            ..maskFilter = MaskFilter.blur(BlurStyle.normal, w * 0.014),
        );
        canvas.drawRRect(
          rrect,
          Paint()
            ..shader = LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: isShades
                  ? const [Color(0xEE1E293B), Color(0xF5020617)]
                  : [Colors.white.withValues(alpha: .22), Colors.white.withValues(alpha: .06)],
            ).createShader(rect),
        );
        // Glossy diagonal lens reflection
        canvas.drawLine(
          Offset(rect.left + lensW * 0.22, rect.top + lensH * 0.20),
          Offset(rect.left + lensW * 0.46, rect.bottom - lensH * 0.22),
          Paint()
            ..color = Colors.white.withValues(alpha: isShades ? .22 : .34)
            ..strokeWidth = w * 0.018
            ..strokeCap = StrokeCap.round,
        );
        canvas.drawRRect(rrect, framePaint);
      }
      // Nose bridge
      canvas.drawArc(
        Rect.fromCenter(center: Offset(cx, eyeY - lensH * 0.05), width: eyeOffsetX * 2 - lensW, height: lensH * 0.30),
        pi,
        pi,
        false,
        framePaint,
      );
    } else if (config.accessory == 3) {
      // Knit Beanie with ribbed folded cuff
      final domeRect = Rect.fromCenter(center: Offset(cx, headCy - headRy * 0.56), width: headRx * 2.18, height: headRy * 1.56);
      canvas.drawArc(
        domeRect,
        pi,
        pi,
        true,
        Paint()
          ..shader = LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [outfitLight, outfit, outfitDark],
          ).createShader(domeRect),
      );
      final cuff = RRect.fromRectAndRadius(
        Rect.fromLTRB(cx - headRx * 1.12, headCy - headRy * 0.78, cx + headRx * 1.12, headCy - headRy * 0.46),
        Radius.circular(headRx * 0.22),
      );
      canvas.drawRRect(cuff, Paint()..color = outfit);
      final ribPaint = Paint()
        ..color = outfitDark.withValues(alpha: .42)
        ..strokeWidth = w * 0.012;
      for (var t = -0.85; t <= 0.85; t += 0.24) {
        canvas.drawLine(
          Offset(cx + headRx * t, headCy - headRy * 0.76),
          Offset(cx + headRx * t, headCy - headRy * 0.48),
          ribPaint,
        );
      }
    } else if (config.accessory == 4) {
      // Curved Baseball Cap
      final capRect = Rect.fromCenter(center: Offset(cx, headCy - headRy * 0.54), width: headRx * 2.16, height: headRy * 1.50);
      canvas.drawArc(
        capRect,
        pi,
        pi,
        true,
        Paint()
          ..shader = LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [outfitLight, outfit, outfitDark],
          ).createShader(capRect),
      );
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTRB(cx - headRx * 1.06, headCy - headRy * 0.64, cx + headRx * 1.34, headCy - headRy * 0.44),
          Radius.circular(headRx * 0.20),
        ),
        Paint()..color = outfitDark,
      );
    } else if (config.accessory == 5) {
      // Studio Over-Ear Headphone Cups
      for (final side in const [-1.0, 1.0]) {
        final cupRect = Rect.fromCenter(
          center: Offset(cx + side * headRx * 1.10, headCy + headRy * 0.04),
          width: headRx * 0.36,
          height: headRy * 0.70,
        );
        canvas.drawRRect(
          RRect.fromRectAndRadius(cupRect, Radius.circular(headRx * 0.18)),
          Paint()
            ..shader = LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [outfitLight, outfit, outfitDark],
            ).createShader(cupRect),
        );
        canvas.drawRRect(
          RRect.fromRectAndRadius(
            Rect.fromCenter(
              center: Offset(cx + side * headRx * 0.96, headCy + headRy * 0.04),
              width: headRx * 0.13,
              height: headRy * 0.56,
            ),
            Radius.circular(headRx * 0.08),
          ),
          Paint()..color = const Color(0xFF1E293B),
        );
      }
    }
  }

  void _paintPeekingHands(
    Canvas canvas,
    double w,
    double h,
    double cx,
    Color skinHighlight,
    Color skin,
    Color skinMidShadow,
  ) {
    final handY = h * 0.91;
    for (final side in const [-1.0, 1.0]) {
      final hx = cx + side * w * 0.28;
      final rect = Rect.fromCenter(center: Offset(hx, handY), width: w * 0.175, height: h * 0.13);
      final rrect = RRect.fromRectAndRadius(rect, Radius.circular(w * 0.075));
      // Soft drop shadow on the glass composer bar below the fingers
      canvas.drawRRect(
        rrect.shift(Offset(0, h * 0.025)),
        Paint()
          ..color = Colors.black.withValues(alpha: .28)
          ..maskFilter = MaskFilter.blur(BlurStyle.normal, w * 0.024),
      );
      canvas.drawRRect(
        rrect,
        Paint()
          ..shader = RadialGradient(
            center: const Alignment(0, -0.45),
            radius: 0.95,
            colors: [skinHighlight, skin, skinMidShadow],
          ).createShader(rect),
      );
      final crease = Paint()
        ..color = skinMidShadow.withValues(alpha: .72)
        ..style = PaintingStyle.stroke
        ..strokeWidth = w * 0.014
        ..strokeCap = StrokeCap.round;
      canvas.drawRRect(rrect, crease);
      for (final fx in const [-0.032, 0.0, 0.032]) {
        canvas.drawLine(
          Offset(hx + w * fx, handY - h * 0.038),
          Offset(hx + w * fx, handY + h * 0.030),
          crease,
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant _ModernBitmojiPainter oldDelegate) =>
      oldDelegate.config != config ||
      oldDelegate.activity != activity ||
      oldDelegate.blinking != blinking ||
      oldDelegate.showPeekingHands != showPeekingHands;
}

/// Animated Snapchat-style peeking Bitmoji that rests directly on the top-left
/// edge of the chat composer bar.
class PeekingBitmojiBar extends StatefulWidget {
  const PeekingBitmojiBar({
    required this.config,
    required this.activity,
    required this.peerName,
    this.nudgeEmoji,
    this.onTapWave,
    super.key,
  });

  final ChatAvatarConfig config;
  final ChatAvatarActivity activity;
  final String peerName;
  final String? nudgeEmoji;
  final VoidCallback? onTapWave;

  @override
  State<PeekingBitmojiBar> createState() => _PeekingBitmojiBarState();
}

class _PeekingBitmojiBarState extends State<PeekingBitmojiBar>
    with SingleTickerProviderStateMixin {
  late final AnimationController _anim = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  );
  Timer? _blinkTimer;
  bool _blinking = false;

  @override
  void initState() {
    super.initState();
    LikedinAppearance.reduceMotion.addListener(_syncAnimation);
    _syncAnimation();
    _scheduleBlink();
  }

  void _syncAnimation() {
    if (!mounted) return;
    final active = widget.activity != ChatAvatarActivity.hidden && !LikedinAppearance.reduceMotion.value;
    if (active) {
      _anim.duration = widget.activity == ChatAvatarActivity.present
          ? const Duration(milliseconds: 1850)
          : const Duration(milliseconds: 680);
      if (!_anim.isAnimating) _anim.repeat(reverse: true);
    } else {
      if (_anim.isAnimating) _anim.stop();
      _anim.value = 0;
    }
  }

  void _scheduleBlink() {
    _blinkTimer?.cancel();
    _blinkTimer = Timer.periodic(const Duration(milliseconds: 3400), (_) {
      if (!mounted || widget.activity == ChatAvatarActivity.hidden) return;
      setState(() => _blinking = true);
      Future<void>.delayed(const Duration(milliseconds: 135), () {
        if (mounted) setState(() => _blinking = false);
      });
    });
  }

  @override
  void didUpdateWidget(covariant PeekingBitmojiBar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.activity != widget.activity) {
      _syncAnimation();
    }
  }

  @override
  void dispose() {
    _blinkTimer?.cancel();
    LikedinAppearance.reduceMotion.removeListener(_syncAnimation);
    _anim.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final visible = widget.activity != ChatAvatarActivity.hidden;
    final reduced = LikedinAppearance.reduceMotion.value;
    final dur = reduced ? Duration.zero : const Duration(milliseconds: 290);
    final primary = likedinPrimary(Theme.of(context).brightness);

    return IgnorePointer(
      ignoring: !visible,
      child: AnimatedOpacity(
        opacity: visible ? 1.0 : 0.0,
        duration: dur,
        child: AnimatedSlide(
          offset: visible
              ? (widget.activity == ChatAvatarActivity.present ? const Offset(0, 0.04) : Offset.zero)
              : const Offset(0, 0.90),
          duration: dur,
          curve: Curves.easeOutBack,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              GestureDetector(
                onTap: widget.onTapWave,
                child: Tooltip(
                  message: 'Tap to wave at ${widget.peerName}',
                  child: AnimatedBuilder(
                    animation: _anim,
                    builder: (context, child) {
                      final t = Curves.easeInOut.transform(_anim.value);
                      final bounce = widget.activity == ChatAvatarActivity.present
                          ? -2.0 * t
                          : -5.0 * t;
                      final tilt = widget.activity == ChatAvatarActivity.present
                          ? (t - 0.5) * 0.04
                          : (t - 0.5) * 0.065;
                      return Transform.translate(
                        offset: Offset(0, bounce),
                        child: Transform.rotate(
                          angle: tilt,
                          alignment: Alignment.bottomCenter,
                          child: child,
                        ),
                      );
                    },
                    child: ChatBitmojiAvatar(
                      config: widget.config,
                      size: 62,
                      activity: widget.activity,
                      blinking: _blinking,
                      showPeekingHands: true,
                    ),
                  ),
                ),
              ),
              if (widget.nudgeEmoji != null)
                Padding(
                  padding: const EdgeInsets.only(left: 2, bottom: 28),
                  child: TweenAnimationBuilder<double>(
                    key: ValueKey('nudge-${widget.nudgeEmoji}'),
                    tween: Tween<double>(begin: 0.5, end: 1.0),
                    duration: reduced ? Duration.zero : const Duration(milliseconds: 240),
                    curve: Curves.easeOutBack,
                    builder: (_, s, child) => Transform.scale(scale: s, child: child),
                    child: GlassPanel(
                      blur: 8,
                      radius: BorderRadius.circular(16),
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      child: Text(widget.nudgeEmoji!, style: const TextStyle(fontSize: 18)),
                    ),
                  ),
                )
              else if (widget.activity == ChatAvatarActivity.typing)
                Padding(
                  padding: const EdgeInsets.only(left: 2, bottom: 26),
                  child: GlassPanel(
                    blur: 8,
                    radius: BorderRadius.circular(16),
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: List.generate(3, (i) {
                        return AnimatedBuilder(
                          animation: _anim,
                          builder: (_, __) {
                            final phase = ((_anim.value * 3 - i) % 1.0).abs();
                            final dy = -3.6 * (1.0 - (phase - 0.5).abs() * 2.0);
                            return Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 2),
                              child: Transform.translate(
                                offset: Offset(0, dy),
                                child: CircleAvatar(radius: 3.2, backgroundColor: primary),
                              ),
                            );
                          },
                        );
                      }),
                    ),
                  ),
                )
              else if (widget.activity == ChatAvatarActivity.recording)
                Padding(
                  padding: const EdgeInsets.only(left: 2, bottom: 26),
                  child: GlassPanel(
                    blur: 8,
                    radius: BorderRadius.circular(16),
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.mic_rounded, size: 15, color: Color(0xFFE5484D)),
                        const SizedBox(width: 5),
                        ...List.generate(4, (i) {
                          return AnimatedBuilder(
                            animation: _anim,
                            builder: (_, __) {
                              final phase = ((_anim.value * 4 - i) % 1.0).abs();
                              final barH = 5.0 + 9.0 * (1.0 - (phase - 0.5).abs() * 2.0);
                              return Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 1.5),
                                child: Container(
                                  width: 2.8,
                                  height: barH,
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFE5484D),
                                    borderRadius: BorderRadius.circular(2),
                                  ),
                                ),
                              );
                            },
                          );
                        }),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Interactive Avatar Studio strictly for customizing YOUR OWN Bitmoji.
/// Features a pinned 3D-shaded spotlight preview and tabbed customization panels.
class ChatAvatarStudioPage extends StatefulWidget {
  const ChatAvatarStudioPage({
    required this.initialOwn,
    super.key,
  });

  final ChatAvatarConfig initialOwn;

  @override
  State<ChatAvatarStudioPage> createState() => _ChatAvatarStudioPageState();
}

class _ChatAvatarStudioPageState extends State<ChatAvatarStudioPage> {
  late ChatAvatarConfig _own = widget.initialOwn;
  ChatAvatarActivity _previewActivity = ChatAvatarActivity.present;

  void _update(ChatAvatarConfig next) {
    HapticFeedback.selectionClick();
    setState(() => _own = next);
  }

  void _randomize() {
    final rng = Random();
    final isFemale = rng.nextBool();
    _update(ChatAvatarConfig(
      gender: isFemale ? 'female' : 'male',
      skinIndex: rng.nextInt(ChatAvatarConfig.skinTones.length),
      eyeColor: rng.nextInt(ChatAvatarConfig.eyeColors.length),
      hairStyle: isFemale ? 4 + rng.nextInt(4) : rng.nextInt(4),
      hairColor: rng.nextInt(ChatAvatarConfig.hairColors.length),
      outfitStyle: rng.nextInt(ChatAvatarConfig.outfitNames.length),
      outfitColor: rng.nextInt(ChatAvatarConfig.outfitColors.length),
      accessory: rng.nextInt(ChatAvatarConfig.accessoryNames.length),
      facialHair: isFemale ? 0 : rng.nextInt(ChatAvatarConfig.facialHairNames.length),
    ));
  }

  Widget _swatchRow({
    required String label,
    required List<Color> colors,
    required int selectedIndex,
    required ValueChanged<int> onSelect,
  }) =>
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Wrap(
            spacing: 11,
            runSpacing: 11,
            children: List.generate(colors.length, (i) {
              final selected = i == selectedIndex;
              return GestureDetector(
                onTap: () => onSelect(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 160),
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: colors[i],
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: selected ? likedinPrimary(Theme.of(context).brightness) : Colors.white24,
                      width: selected ? 3 : 1.5,
                    ),
                    boxShadow: selected
                        ? [
                            BoxShadow(
                              color: likedinPrimary(Theme.of(context).brightness).withValues(alpha: .35),
                              blurRadius: 10,
                            ),
                          ]
                        : null,
                  ),
                  child: selected
                      ? Icon(
                          Icons.check_rounded,
                          size: 18,
                          color: colors[i].computeLuminance() > 0.55 ? Colors.black87 : Colors.white,
                        )
                      : null,
                ),
              );
            }),
          ),
        ],
      );

  Widget _choiceRow({
    required String label,
    required List<String> options,
    required int selectedIndex,
    required ValueChanged<int> onSelect,
  }) =>
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 6,
            children: List.generate(options.length, (i) {
              return ChoiceChip(
                label: Text(options[i]),
                selected: i == selectedIndex,
                visualDensity: VisualDensity.compact,
                onSelected: (_) => onSelect(i),
              );
            }),
          ),
        ],
      );

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final primary = likedinPrimary(brightness);

    return DefaultTabController(
      length: 4,
      child: AuroraBackdrop(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            title: const Text('My Bitmoji', style: TextStyle(fontWeight: FontWeight.w800)),
            actions: [
              IconButton(
                tooltip: 'Randomize',
                onPressed: _randomize,
                icon: const Icon(Icons.casino_outlined),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 10),
                child: FilledButton(
                  onPressed: () => Navigator.of(context).pop(_own),
                  child: const Text('Save'),
                ),
              ),
            ],
          ),
          body: Column(
            children: [
              // Pinned live spotlight preview stage
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 12),
                child: GlassPanel(
                  radius: BorderRadius.circular(28),
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
                  glow: true,
                  child: Column(
                    children: [
                      SizedBox(
                        height: 146,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Container(
                              width: 124,
                              height: 124,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: RadialGradient(
                                  colors: [
                                    primary.withValues(alpha: .28),
                                    primary.withValues(alpha: .0),
                                  ],
                                ),
                              ),
                            ),
                            ChatBitmojiAvatar(
                              config: _own,
                              size: 138,
                              activity: _previewActivity,
                              showPeekingHands: false,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        children: [
                          ChoiceChip(
                            label: const Text('In chat'),
                            selected: _previewActivity == ChatAvatarActivity.present,
                            visualDensity: VisualDensity.compact,
                            onSelected: (_) => setState(() => _previewActivity = ChatAvatarActivity.present),
                          ),
                          ChoiceChip(
                            label: const Text('Typing'),
                            selected: _previewActivity == ChatAvatarActivity.typing,
                            visualDensity: VisualDensity.compact,
                            onSelected: (_) => setState(() => _previewActivity = ChatAvatarActivity.typing),
                          ),
                          ChoiceChip(
                            label: const Text('Recording'),
                            selected: _previewActivity == ChatAvatarActivity.recording,
                            visualDensity: VisualDensity.compact,
                            onSelected: (_) => setState(() => _previewActivity = ChatAvatarActivity.recording),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              // Category tabs
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: GlassPanel(
                  radius: BorderRadius.circular(20),
                  padding: const EdgeInsets.all(4),
                  blur: 6,
                  glow: false,
                  child: const TabBar(
                    dividerColor: Colors.transparent,
                    indicatorSize: TabBarIndicatorSize.tab,
                    tabs: [
                      Tab(text: 'Face'),
                      Tab(text: 'Hair'),
                      Tab(text: 'Outfit'),
                      Tab(text: 'Extras'),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              // Customization panels
              Expanded(
                child: TabBarView(
                  children: [
                    // 1. Face tab (Male/Female preset, Skin tone, Eye color)
                    ListView(
                      padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
                      children: [
                        GlassPanel(
                          radius: BorderRadius.circular(22),
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Starter style', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
                              const SizedBox(height: 10),
                              Row(
                                children: [
                                  Expanded(
                                    child: OutlinedButton.icon(
                                      onPressed: () => _update(ChatAvatarConfig.maleDefault.copyWith(
                                        skinIndex: _own.skinIndex,
                                        eyeColor: _own.eyeColor,
                                      )),
                                      icon: const Icon(Icons.male_rounded, size: 19),
                                      label: const Text('Male'),
                                      style: OutlinedButton.styleFrom(
                                        backgroundColor: _own.gender == 'male'
                                            ? primary.withValues(alpha: .15)
                                            : null,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: OutlinedButton.icon(
                                      onPressed: () => _update(ChatAvatarConfig.femaleDefault.copyWith(
                                        skinIndex: _own.skinIndex,
                                        eyeColor: _own.eyeColor,
                                      )),
                                      icon: const Icon(Icons.female_rounded, size: 19),
                                      label: const Text('Female'),
                                      style: OutlinedButton.styleFrom(
                                        backgroundColor: _own.gender == 'female'
                                            ? primary.withValues(alpha: .15)
                                            : null,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 18),
                              _swatchRow(
                                label: 'Skin tone',
                                colors: ChatAvatarConfig.skinTones,
                                selectedIndex: _own.skinIndex,
                                onSelect: (i) => _update(_own.copyWith(skinIndex: i)),
                              ),
                              const SizedBox(height: 18),
                              _swatchRow(
                                label: 'Eye color',
                                colors: ChatAvatarConfig.eyeColors,
                                selectedIndex: _own.eyeColor,
                                onSelect: (i) => _update(_own.copyWith(eyeColor: i)),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    // 2. Hair tab
                    ListView(
                      padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
                      children: [
                        GlassPanel(
                          radius: BorderRadius.circular(22),
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _choiceRow(
                                label: 'Hairstyle',
                                options: ChatAvatarConfig.hairStyleNames,
                                selectedIndex: _own.hairStyle,
                                onSelect: (i) => _update(_own.copyWith(hairStyle: i)),
                              ),
                              const SizedBox(height: 18),
                              _swatchRow(
                                label: 'Hair color',
                                colors: ChatAvatarConfig.hairColors,
                                selectedIndex: _own.hairColor,
                                onSelect: (i) => _update(_own.copyWith(hairColor: i)),
                              ),
                              if (_own.gender == 'male' || _own.facialHair > 0) ...[
                                const SizedBox(height: 18),
                                _choiceRow(
                                  label: 'Facial hair',
                                  options: ChatAvatarConfig.facialHairNames,
                                  selectedIndex: _own.facialHair,
                                  onSelect: (i) => _update(_own.copyWith(facialHair: i)),
                                ),
                              ],
                            ],
                          ),
                        ),
                      ],
                    ),
                    // 3. Outfit tab
                    ListView(
                      padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
                      children: [
                        GlassPanel(
                          radius: BorderRadius.circular(22),
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              _choiceRow(
                                label: 'Clothing',
                                options: ChatAvatarConfig.outfitNames,
                                selectedIndex: _own.outfitStyle,
                                onSelect: (i) => _update(_own.copyWith(outfitStyle: i)),
                              ),
                              const SizedBox(height: 18),
                              _swatchRow(
                                label: 'Outfit color',
                                colors: ChatAvatarConfig.outfitColors,
                                selectedIndex: _own.outfitColor,
                                onSelect: (i) => _update(_own.copyWith(outfitColor: i)),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    // 4. Extras tab
                    ListView(
                      padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
                      children: [
                        GlassPanel(
                          radius: BorderRadius.circular(22),
                          padding: const EdgeInsets.all(16),
                          child: _choiceRow(
                            label: 'Accessories',
                            options: ChatAvatarConfig.accessoryNames,
                            selectedIndex: _own.accessory,
                            onSelect: (i) => _update(_own.copyWith(accessory: i)),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
