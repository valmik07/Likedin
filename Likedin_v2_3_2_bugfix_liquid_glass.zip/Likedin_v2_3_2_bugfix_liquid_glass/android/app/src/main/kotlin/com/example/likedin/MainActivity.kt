package com.example.likedin

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import android.os.PowerManager
import android.os.Handler
import android.os.Looper
import android.app.PictureInPictureParams
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.CancellationSignal
import android.util.Rational
import android.view.WindowManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/** Sensor-gated proximity handling. Never acquire the screen-off lock just
 * because a call started: only acquire it after the sensor reports NEAR. */
class MainActivity : FlutterActivity(), SensorEventListener {
    private val channelName = "com.example.likedin/proximity"
    private val callAlertChannelName = "com.example.likedin/call_alerts"
    private val downloadsChannelName = "com.example.likedin/downloads"
    private var incomingRingtone: Ringtone? = null
    private var outgoingTone: ToneGenerator? = null
    private var callVibrator: Vibrator? = null
    private val ringbackHandler = Handler(Looper.getMainLooper())
    private var ringbackRunnable: Runnable? = null
    private lateinit var sensorManager: SensorManager
    private var proximitySensor: Sensor? = null
    private var proximityWakeLock: PowerManager.WakeLock? = null
    private var callActive = false
    private var activeVideoCall = false
    private var proximityEnabled = false
    private var sensorRegistered = false
    private var isNear = false

    private fun requestHighestRefreshRate() {
        try {
            val activeDisplay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                display
            } else {
                @Suppress("DEPRECATION")
                windowManager.defaultDisplay
            } ?: return
            val highestMode = activeDisplay.supportedModes
                .maxByOrNull { it.refreshRate } ?: return
            val params = window.attributes
            if (params.preferredDisplayModeId != highestMode.modeId) {
                params.preferredDisplayModeId = highestMode.modeId
                params.preferredRefreshRate = highestMode.refreshRate
                window.attributes = params
            }
        } catch (_: Exception) {
            // Fall back silently to the system default refresh rate.
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestHighestRefreshRate()
        // SECURITY: the app must NOT draw over the lock screen in normal use,
        // otherwise turning the screen off and on again skips the device
        // PIN/pattern/password. Only an incoming-call full-screen intent may
        // show the call UI above the keyguard.
        applyLockScreenPolicy(intent)
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        proximitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY)
    }

    override fun onNewIntent(intent: Intent) {
        applyLockScreenPolicy(intent)
        super.onNewIntent(intent)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (activeVideoCall && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            enterVideoPip()
        }
    }

    private fun enterVideoPip(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false
        if (isFinishing || isDestroyed) return false
        if (!packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            return false
        }
        return try {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(9, 16))
                .build()
            enterPictureInPictureMode(params)
        } catch (_: Exception) {
            false
        }
    }

    override fun onStop() {
        // Screen off / app backgrounded: always go back to the secure default
        // so the keyguard (PIN/password) is required when the screen wakes.
        setLockScreenVisibility(false)
        super.onStop()
    }

    /** True only when this launch came from the incoming-call full-screen notification. */
    private fun isIncomingCallLaunch(launchIntent: Intent?): Boolean {
        if (launchIntent == null) return false
        // A task restored from Recents re-delivers the old intent; never trust that.
        if (launchIntent.flags and Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY != 0) return false
        val payload = launchIntent.getStringExtra("payload") ?: return false
        return payload.contains("incoming_call")
    }

    private fun applyLockScreenPolicy(launchIntent: Intent?) {
        setLockScreenVisibility(isIncomingCallLaunch(launchIntent))
    }

    private fun setLockScreenVisibility(allow: Boolean) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(allow)
            setTurnScreenOn(allow)
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.example.likedin/hidden_chat_security").setMethodCallHandler { call, result ->
            when (call.method) {
                "setSecure" -> {
                    val secure = call.argument<Boolean>("secure") ?: false
                    runOnUiThread {
                        if (secure) {
                            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                        } else {
                            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                        }
                        result.success(true)
                    }
                }
                "canAuthenticateBiometric" -> {
                    val available = try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            val manager = getSystemService(BiometricManager::class.java)
                            val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
                                BiometricManager.Authenticators.BIOMETRIC_WEAK
                            manager?.canAuthenticate(authenticators) == BiometricManager.BIOMETRIC_SUCCESS
                        } else {
                            false
                        }
                    } catch (_: Exception) {
                        false
                    }
                    result.success(available)
                }
                "authenticateBiometric" -> {
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
                        result.success("UNAVAILABLE")
                        return@setMethodCallHandler
                    }
                    val title = call.argument<String>("title") ?: "Unlock private chat"
                    val subtitle = call.argument<String>("subtitle") ?: "Verify your fingerprint to open hidden chats"
                    runOnUiThread {
                        var replied = false
                        fun sendOnce(status: String) {
                            if (!replied) {
                                replied = true
                                result.success(status)
                            }
                        }
                        try {
                            val prompt = BiometricPrompt.Builder(this)
                                .setTitle(title)
                                .setSubtitle(subtitle)
                                .setAllowedAuthenticators(
                                    BiometricManager.Authenticators.BIOMETRIC_STRONG or
                                        BiometricManager.Authenticators.BIOMETRIC_WEAK
                                )
                                .setNegativeButton("Use password", mainExecutor) { _, _ ->
                                    sendOnce("USE_PASSWORD")
                                }
                                .build()
                            prompt.authenticate(
                                CancellationSignal(),
                                mainExecutor,
                                object : BiometricPrompt.AuthenticationCallback() {
                                    override fun onAuthenticationSucceeded(authResult: BiometricPrompt.AuthenticationResult?) {
                                        sendOnce("SUCCESS")
                                    }
                                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                                        sendOnce(
                                            if (errorCode == BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED ||
                                                errorCode == BiometricPrompt.BIOMETRIC_ERROR_CANCELED) "CANCELLED"
                                            else "USE_PASSWORD"
                                        )
                                    }
                                }
                            )
                        } catch (_: Exception) {
                            sendOnce("USE_PASSWORD")
                        }
                    }
                }
                else -> result.notImplemented()
            }
        }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.example.likedin/keyboard_media").setMethodCallHandler { call, result ->
            if (call.method != "copyContentUriToCache") {
                result.notImplemented()
                return@setMethodCallHandler
            }
            val rawUri = call.argument<String>("uri")?.takeIf { it.isNotBlank() }
            val requestedMime = call.argument<String>("mimeType")?.lowercase()?.trim()
            val maxBytes = (call.argument<Number>("maxBytes")?.toLong() ?: 8L * 1024L * 1024L)
                .coerceIn(1L, 8L * 1024L * 1024L)
            val allowedMimeTypes = setOf(
                "image/gif", "image/png", "image/jpeg", "image/jpg",
                "image/webp", "image/bmp", "image/tiff",
            )
            if (rawUri == null || requestedMime == null || requestedMime !in allowedMimeTypes) {
                result.error("INVALID_KEYBOARD_MEDIA", "Unsupported keyboard media.", null)
                return@setMethodCallHandler
            }
            val contentUri = try {
                Uri.parse(rawUri).also {
                    if (it.scheme != "content") throw IllegalArgumentException("Only content URIs are accepted")
                }
            } catch (error: Exception) {
                result.error("INVALID_KEYBOARD_URI", error.message, null)
                return@setMethodCallHandler
            }

            Thread {
                var destination: java.io.File? = null
                try {
                    val directory = java.io.File(cacheDir, "keyboard_media")
                    if (!directory.exists() && !directory.mkdirs()) {
                        throw IllegalStateException("Could not create a temporary media folder")
                    }
                    // Keep this directory bounded: keyboard shares are short-lived.
                    directory.listFiles()?.forEach { file ->
                        if (System.currentTimeMillis() - file.lastModified() > 24L * 60L * 60L * 1000L) {
                            try { file.delete() } catch (_: Exception) {}
                        }
                    }
                    val extension = when (requestedMime) {
                        "image/gif" -> "gif"
                        "image/png" -> "png"
                        "image/webp" -> "webp"
                        "image/bmp" -> "bmp"
                        "image/tiff" -> "tiff"
                        else -> "jpg"
                    }
                    destination = java.io.File.createTempFile("gboard_", ".$extension", directory)
                    val input = contentResolver.openInputStream(contentUri)
                        ?: throw IllegalStateException("The keyboard media provider is unavailable")
                    input.use { source ->
                        java.io.FileOutputStream(destination!!).use { output ->
                            val buffer = ByteArray(16 * 1024)
                            var total = 0L
                            while (true) {
                                val read = source.read(buffer)
                                if (read < 0) break
                                total += read
                                if (total > maxBytes) {
                                    throw IllegalArgumentException("Keyboard media exceeds the 8 MB limit")
                                }
                                output.write(buffer, 0, read)
                            }
                            output.flush()
                            if (total <= 0L) throw IllegalStateException("The keyboard sent an empty file")
                        }
                    }
                    val path = destination!!.absolutePath
                    runOnUiThread { result.success(path) }
                } catch (error: Exception) {
                    destination?.let { try { it.delete() } catch (_: Exception) {} }
                    runOnUiThread {
                        result.error("KEYBOARD_MEDIA_COPY_FAILED", error.message ?: "Could not read keyboard media", null)
                    }
                }
            }.start()
        }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, downloadsChannelName).setMethodCallHandler { call, result ->
            if (call.method == "installApk") {
                try {
                    val sourcePath = call.argument<String>("sourcePath")
                        ?: throw IllegalArgumentException("Missing APK file path")
                    val file = java.io.File(sourcePath)
                    if (!file.exists()) throw IllegalStateException("Update APK is missing")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
                        val settingsIntent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                            data = Uri.parse("package:$packageName")
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        startActivity(settingsIntent)
                        result.success("PERMISSION_REQUIRED")
                        return@setMethodCallHandler
                    }
                    val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
                    val intent = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, "application/vnd.android.package-archive")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intent)
                    result.success("STARTED")
                } catch (error: Exception) {
                    result.error("INSTALL_APK_FAILED", error.message ?: "Could not start APK installer", null)
                }
                return@setMethodCallHandler
            }
            if (call.method == "openLocalFile") {
                try {
                    val sourcePath = call.argument<String>("sourcePath")
                        ?: throw IllegalArgumentException("Missing source file")
                    val file = java.io.File(sourcePath)
                    if (!file.exists()) throw IllegalStateException("File is no longer available")
                    val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
                    val extension = file.extension.lowercase()
                    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
                        ?: "application/octet-stream"
                    val intent = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, mime)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(intent, "Open with"))
                    result.success(true)
                } catch (error: android.content.ActivityNotFoundException) {
                    result.error("NO_FILE_HANDLER", "No app can open this file type", null)
                } catch (error: Exception) {
                    result.error("OPEN_FILE_FAILED", error.message ?: "Could not open file", null)
                }
                return@setMethodCallHandler
            }
            if (call.method != "saveToDownloads") { result.notImplemented(); return@setMethodCallHandler }
            val sourcePath = call.argument<String>("sourcePath")
            val displayName = call.argument<String>("displayName") ?: "attachment"
            val mimeType = call.argument<String>("mimeType") ?: "application/octet-stream"
            val resolver = contentResolver
            Thread {
                var createdUri: Uri? = null
                try {
                    val resolvedPath = sourcePath ?: throw IllegalArgumentException("Missing source file")
                    val source = java.io.File(resolvedPath)
                    if (!source.exists()) throw IllegalStateException("Downloaded temporary file is missing")
                    val values = android.content.ContentValues().apply {
                        put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                        put(android.provider.MediaStore.MediaColumns.MIME_TYPE, mimeType)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
                            put(android.provider.MediaStore.MediaColumns.IS_PENDING, 1)
                        }
                    }
                    val uri = resolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("Android could not create a Downloads entry")
                    createdUri = uri
                    resolver.openOutputStream(uri)?.use { output ->
                        source.inputStream().use { input -> input.copyTo(output) }
                    } ?: throw IllegalStateException("Could not write downloaded file")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val done = android.content.ContentValues().apply {
                            put(android.provider.MediaStore.MediaColumns.IS_PENDING, 0)
                        }
                        resolver.update(uri, done, null, null)
                    }
                    source.delete()
                    runOnUiThread { result.success(displayName) }
                } catch (error: Exception) {
                    createdUri?.let { uri ->
                        try { resolver.delete(uri, null, null) } catch (_: Exception) {}
                    }
                    runOnUiThread { result.error("DOWNLOAD_SAVE_FAILED", error.message, null) }
                }
            }.start()
        }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, callAlertChannelName).setMethodCallHandler { call, result ->
            try {
                when (call.method) {
                    "startIncoming" -> { startIncomingCallAlert(); result.success(true) }
                    "startOutgoing" -> { startOutgoingCallAlert(); result.success(true) }
                    "stop" -> { stopCallAlert(); result.success(true) }
                    "startCallService" -> {
                        val svc = Intent(this, CallForegroundService::class.java)
                            .putExtra("video", call.argument<Boolean>("video") ?: false)
                        androidx.core.content.ContextCompat.startForegroundService(this, svc)
                        result.success(true)
                    }
                    "stopCallService" -> {
                        activeVideoCall = false
                        stopService(Intent(this, CallForegroundService::class.java))
                        result.success(true)
                    }
                    "setVideoCallActive" -> {
                        activeVideoCall = call.argument<Boolean>("active") ?: false
                        result.success(true)
                    }
                    "enterPipMode" -> {
                        result.success(enterVideoPip())
                    }
                    "ensureFullScreenCallPermission" -> {
                        if (Build.VERSION.SDK_INT >= 34) {
                            val manager = getSystemService(android.app.NotificationManager::class.java)
                            if (!manager.canUseFullScreenIntent()) {
                                val intent = Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT).apply { data = Uri.parse("package:$packageName") }
                                startActivity(intent)
                                result.success(false)
                            } else result.success(true)
                        } else result.success(true)
                    }
                    else -> result.notImplemented()
                }
            } catch (error: Exception) {
                android.util.Log.e("LikedinCallAlert", "Call alert operation failed", error)
                result.error("CALL_ALERT_ERROR", error.message, null)
            }
        }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "setAudioCallActive" -> {
                    callActive = call.argument<Boolean>("active") ?: false
                    proximityEnabled = call.argument<Boolean>("enabled") ?: false
                    updateSensorRegistration()
                    result.success(proximitySensor != null)
                }
                else -> result.notImplemented()
            }
        }
    }


    private fun vibrator(): Vibrator? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }

    private fun startCallVibration() {
        val vib = vibrator() ?: return
        callVibrator = vib
        // Repeating pulse groups run from the same start instant as the ringtone.
        val pattern = longArrayOf(0, 650, 350, 650, 1100)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vib.vibrate(VibrationEffect.createWaveform(pattern, 0))
        } else {
            @Suppress("DEPRECATION")
            vib.vibrate(pattern, 0)
        }
    }

    private fun startIncomingCallAlert() {
        stopCallAlert()
        val uri: Uri? = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_RINGTONE)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        if (uri != null) {
            incomingRingtone = RingtoneManager.getRingtone(this, uri)
            incomingRingtone?.apply {
                audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) isLooping = true
                play()
            }
        }
        startCallVibration()
    }

    private fun startOutgoingCallAlert() {
        stopCallAlert()
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
        } catch (_: Exception) {}
        // Android's standard telephone ringback cadence, routed through call audio.
        outgoingTone = ToneGenerator(AudioManager.STREAM_VOICE_CALL, 75)
        val repeat = object : Runnable {
            override fun run() {
                val tone = outgoingTone ?: return
                tone.startTone(ToneGenerator.TONE_SUP_RINGTONE, 1800)
                ringbackHandler.postDelayed(this, 4000)
            }
        }
        ringbackRunnable = repeat
        ringbackHandler.post(repeat)
    }

    private fun stopCallAlert() {
        try { incomingRingtone?.stop() } catch (_: Exception) {}
        incomingRingtone = null
        ringbackRunnable?.let { ringbackHandler.removeCallbacks(it) }
        ringbackRunnable = null
        try { outgoingTone?.stopTone(); outgoingTone?.release() } catch (_: Exception) {}
        outgoingTone = null
        try { callVibrator?.cancel() } catch (_: Exception) {}
        callVibrator = null
    }

    private fun updateSensorRegistration() {
        val shouldListen = callActive && proximityEnabled && proximitySensor != null
        if (shouldListen && !sensorRegistered) {
            isNear = false
            sensorRegistered = sensorManager.registerListener(this, proximitySensor, SensorManager.SENSOR_DELAY_NORMAL)
            // Start in the FAR state. A fresh sensor event must explicitly
            // report NEAR before the display is allowed to switch off.
            setProximityWakeLock(false)
        } else if (!shouldListen) {
            if (sensorRegistered) sensorManager.unregisterListener(this)
            sensorRegistered = false
            isNear = false
            setProximityWakeLock(false)
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type != Sensor.TYPE_PROXIMITY) return
        val sensor = proximitySensor ?: return
        val near = event.values.isNotEmpty() && event.values[0] < sensor.maximumRange
        if (near != isNear) {
            isNear = near
            setProximityWakeLock(callActive && proximityEnabled && isNear)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun setProximityWakeLock(near: Boolean) {
        try {
            if (near) {
                if (proximityWakeLock?.isHeld != true) {
                    val power = getSystemService(POWER_SERVICE) as PowerManager
                    proximityWakeLock = power.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "Likedin:ProximityCall")
                    proximityWakeLock?.setReferenceCounted(false)
                    proximityWakeLock?.acquire()
                }
            } else {
                proximityWakeLock?.let { if (it.isHeld) it.release() }
                proximityWakeLock = null
            }
        } catch (error: Exception) {
            android.util.Log.w("LikedinProximity", "Could not update proximity wake lock", error)
        }
    }

    override fun onResume() {
        super.onResume()
        requestHighestRefreshRate()
    }

    override fun onDestroy() {
        if (sensorRegistered) sensorManager.unregisterListener(this)
        sensorRegistered = false
        setProximityWakeLock(false)
        stopCallAlert()
        super.onDestroy()
    }
}
