import 'package:flutter/widgets.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:workmanager/workmanager.dart';

import 'backend_config.dart';
import 'shared_media_service.dart';

const mediaRetryTask = 'likedin.media.upload.retry';

@pragma('vm:entry-point')
void likedinMediaCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    WidgetsFlutterBinding.ensureInitialized();
    try {
      await Supabase.initialize(url: BackendConfig.supabaseUrl, anonKey: BackendConfig.supabaseAnonKey);
      final client = Supabase.instance.client;
      if (client.auth.currentSession == null) return false;
      return await SharedMediaService.processRetryQueue(client);
    } catch (_) {
      return false;
    }
  });
}
