import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'origin_fluid_physics.dart';
import 'origin_gesture_coordinator.dart';
import 'origin_haptics.dart';
import 'origin_motion_presets.dart';
import 'origin_spring_physics.dart';

/// Physics-driven, spring-curved, interruptible edge-swipe-back navigation
/// route inspired by OriginOS 7.
class OriginPageRoute<T> extends PageRoute<T> {
  OriginPageRoute({
    required this.builder,
    super.settings,
    super.fullscreenDialog = false,
    this.maintainStateValue = true,
    this.enableInteractiveBack = true,
  });

  final WidgetBuilder builder;
  final bool maintainStateValue;
  final bool enableInteractiveBack;

  @override
  bool get maintainState => maintainStateValue;

  @override
  Duration get transitionDuration => OriginMotionEngine.reduceMotion.value
      ? Duration.zero
      : const Duration(milliseconds: 360);

  @override
  Duration get reverseTransitionDuration => OriginMotionEngine.reduceMotion.value
      ? Duration.zero
      : const Duration(milliseconds: 300);

  @override
  Color? get barrierColor => null;

  @override
  String? get barrierLabel => null;

  @override
  Widget buildPage(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
  ) {
    final page = builder(context);
    if (!enableInteractiveBack || fullscreenDialog) return page;
    return _OriginInteractiveBackWrapper(
      route: this,
      child: page,
    );
  }

  @override
  Widget buildTransitions(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    if (OriginMotionEngine.isReducedMotion(context)) return child;

    final userDragging = navigator?.userGestureInProgress ?? false;
    final springCurve = const OriginSpringCurve(
      OriginMotionPresets.page,
      durationSeconds: 0.36,
    );
    final reverseSpringCurve = const OriginSpringCurve(
      OriginMotionPresets.soft,
      durationSeconds: 0.30,
    ).flipped;

    final Animation<double> primary = userDragging
        ? animation
        : CurvedAnimation(
            parent: animation,
            curve: springCurve,
            reverseCurve: reverseSpringCurve,
          );
    final Animation<double> secondary = userDragging
        ? secondaryAnimation
        : CurvedAnimation(
            parent: secondaryAnimation,
            curve: springCurve,
            reverseCurve: reverseSpringCurve,
          );

    final Offset beginOffset = fullscreenDialog
        ? const Offset(0.0, 0.08)
        : const Offset(1.0, 0.0);

    return AnimatedBuilder(
      animation: Listenable.merge(<Listenable>[primary, secondary]),
      child: child,
      builder: (context, builtChild) {
        final t = primary.value;
        final sec = secondary.value.clamp(0.0, 1.0).toDouble();
        final slideIn = Offset.lerp(beginOffset, Offset.zero, t)!;
        final slideBack = fullscreenDialog
            ? Offset.zero
            : Offset(-0.22 * sec, 0.0);
        final scale = (1.0 - 0.035 * sec) *
            (fullscreenDialog ? (0.96 + 0.04 * t.clamp(0.0, 1.05)) : 1.0);
        final opacity = fullscreenDialog ? t.clamp(0.0, 1.0).toDouble() : 1.0;

        return FractionalTranslation(
          translation: slideIn + slideBack,
          child: Transform.scale(
            scale: scale,
            child: opacity < 0.999
                ? Opacity(opacity: opacity, child: builtChild)
                : builtChild,
          ),
        );
      },
    );
  }

  bool _beginInteractiveBackGesture() {
    if (!isCurrent || isFirst || controller == null) return false;
    controller!.stop(canceled: false);
    navigator?.didStartUserGesture();
    return true;
  }

  void _updateInteractiveBackGesture(double deltaFraction) {
    final ctrl = controller;
    if (ctrl == null) return;
    ctrl.value = (ctrl.value - deltaFraction).clamp(0.0, 1.0).toDouble();
  }

  void _endInteractiveBackGesture({
    required double velocityPx,
    required double width,
  }) {
    final ctrl = controller;
    final nav = navigator;
    if (ctrl == null || nav == null) return;
    final shouldPop = velocityPx > 520.0 || (velocityPx >= -180.0 && ctrl.value < 0.62);
    if (shouldPop) {
      OriginHaptics.gestureComplete();
      nav.pop();
    } else {
      final normVel = (-velocityPx / width).clamp(-6.0, 6.0).toDouble();
      ctrl.animateWith(
        OriginSpringPhysics.createSimulation(
          spec: OriginMotionPresets.page,
          start: ctrl.value,
          end: 1.0,
          velocity: normVel,
          adaptVelocity: false,
        ),
      );
    }
    nav.didStopUserGesture();
  }

  void _cancelInteractiveBackGesture() {
    final ctrl = controller;
    if (ctrl != null) {
      ctrl.animateWith(
        OriginSpringPhysics.createSimulation(
          spec: OriginMotionPresets.page,
          start: ctrl.value,
          end: 1.0,
          velocity: 0.0,
          adaptVelocity: false,
        ),
      );
    }
    navigator?.didStopUserGesture();
  }
}

class _OriginInteractiveBackWrapper extends StatefulWidget {
  const _OriginInteractiveBackWrapper({
    required this.route,
    required this.child,
  });

  final OriginPageRoute<dynamic> route;
  final Widget child;

  @override
  State<_OriginInteractiveBackWrapper> createState() =>
      _OriginInteractiveBackWrapperState();
}

class _OriginInteractiveBackWrapperState
    extends State<_OriginInteractiveBackWrapper> {
  bool _dragging = false;

  void _onDragStart(DragStartDetails details) {
    if (!widget.route._beginInteractiveBackGesture()) return;
    _dragging = true;
    OriginHaptics.dragStart();
  }

  void _onDragUpdate(DragUpdateDetails details) {
    if (!_dragging) return;
    final width = math.max(1.0, MediaQuery.sizeOf(context).width);
    widget.route._updateInteractiveBackGesture((details.primaryDelta ?? 0.0) / width);
  }

  void _onDragEnd(DragEndDetails details) {
    if (!_dragging) return;
    _dragging = false;
    final width = math.max(1.0, MediaQuery.sizeOf(context).width);
    widget.route._endInteractiveBackGesture(
      velocityPx: details.velocity.pixelsPerSecond.dx,
      width: width,
    );
  }

  void _onDragCancel() {
    if (!_dragging) return;
    _dragging = false;
    widget.route._cancelInteractiveBackGesture();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        widget.child,
        Positioned(
          left: 0,
          top: 0,
          bottom: 0,
          width: 24,
          child: GestureDetector(
            behavior: HitTestBehavior.translucent,
            onHorizontalDragStart: _onDragStart,
            onHorizontalDragUpdate: _onDragUpdate,
            onHorizontalDragEnd: _onDragEnd,
            onHorizontalDragCancel: _onDragCancel,
          ),
        ),
      ],
    );
  }
}

Future<T?> showOriginBottomSheet<T>({
  required BuildContext context,
  required WidgetBuilder builder,
  Color barrierColor = const Color(0x75000000),
  bool isDismissible = true,
  bool wrapInMaterialSurface = false,
  List<double> snapFractions = const <double>[1.0],
}) {
  OriginHaptics.menuExpand();
  return Navigator.of(context).push<T>(
    OriginModalSheetRoute<T>(
      builder: builder,
      barrierColorValue: barrierColor,
      isDismissible: isDismissible,
      wrapInMaterialSurface: wrapInMaterialSurface,
      snapFractions: snapFractions,
    ),
  );
}

class OriginModalSheetRoute<T> extends PopupRoute<T> {
  OriginModalSheetRoute({
    required this.builder,
    required this.barrierColorValue,
    this.isDismissible = true,
    this.wrapInMaterialSurface = false,
    this.snapFractions = const <double>[1.0],
  });

  final WidgetBuilder builder;
  final Color barrierColorValue;
  final bool isDismissible;
  final bool wrapInMaterialSurface;
  final List<double> snapFractions;

  @override
  Color? get barrierColor => barrierColorValue;

  @override
  bool get barrierDismissible => isDismissible;

  @override
  String? get barrierLabel => 'Dismiss sheet';

  @override
  Duration get transitionDuration => OriginMotionEngine.reduceMotion.value
      ? Duration.zero
      : const Duration(milliseconds: 280);

  @override
  Duration get reverseTransitionDuration => OriginMotionEngine.reduceMotion.value
      ? Duration.zero
      : const Duration(milliseconds: 220);

  @override
  Widget buildPage(
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
  ) {
    return _OriginPhysicsSheetHost(
      animation: animation,
      isDismissible: isDismissible,
      wrapInMaterialSurface: wrapInMaterialSurface,
      snapFractions: snapFractions,
      child: builder(context),
    );
  }
}

class _OriginPhysicsSheetHost extends StatefulWidget {
  const _OriginPhysicsSheetHost({
    required this.animation,
    required this.isDismissible,
    required this.wrapInMaterialSurface,
    required this.snapFractions,
    required this.child,
  });

  final Animation<double> animation;
  final bool isDismissible;
  final bool wrapInMaterialSurface;
  final List<double> snapFractions;
  final Widget child;

  @override
  State<_OriginPhysicsSheetHost> createState() => _OriginPhysicsSheetHostState();
}

class _OriginPhysicsSheetHostState extends State<_OriginPhysicsSheetHost>
    with SingleTickerProviderStateMixin {
  late final AnimationController _dragCtrl = AnimationController.unbounded(
    vsync: this,
    value: 0.0,
  );
  final OriginVelocityTracker _velocityTracker = OriginVelocityTracker();
  double _rawDragY = 0.0;
  bool _dismissing = false;
  bool _innerScrolledPastTop = false;
  bool _draggingFromHandle = false;

  void _springTo(double target, {double velocity = 0.0}) {
    if (OriginMotionEngine.isReducedMotion(context)) {
      _dragCtrl.value = target;
      return;
    }
    _dragCtrl.animateWith(
      OriginSpringPhysics.createSimulation(
        spec: OriginMotionPresets.sheet,
        start: _dragCtrl.value,
        end: target,
        velocity: velocity.clamp(-3200.0, 3200.0).toDouble(),
      ),
    );
  }

  void _onDragStart(DragStartDetails details, {bool fromHandle = false}) {
    _draggingFromHandle = fromHandle;
    _dragCtrl.stop(canceled: false);
    _velocityTracker.reset();
    _velocityTracker.addPosition(
      details.globalPosition,
      timestamp: details.sourceTimeStamp,
    );
    _rawDragY = _dragCtrl.value < 0
        ? OriginSpringPhysics.inverseRubberBand(_dragCtrl.value, 54.0)
        : _dragCtrl.value;
  }

  void _onDragUpdate(DragUpdateDetails details) {
    if (_dismissing) return;
    if (!_draggingFromHandle && _innerScrolledPastTop && _dragCtrl.value <= 0.5) return;
    final dy = details.primaryDelta ?? 0.0;
    _velocityTracker.addPosition(
      details.globalPosition,
      timestamp: details.sourceTimeStamp,
    );
    _rawDragY += dy;
    if (_rawDragY < 0.0) {
      _dragCtrl.value = OriginSpringPhysics.rubberBand(_rawDragY, 54.0);
    } else {
      _dragCtrl.value = _rawDragY;
    }
  }

  void _onDragEnd(DragEndDetails details) {
    if (_dismissing) return;
    _draggingFromHandle = false;
    final trackedVy = _velocityTracker.estimateVelocity().dy;
    final vy = details.velocity.pixelsPerSecond.dy != 0.0
        ? details.velocity.pixelsPerSecond.dy
        : trackedVy;
    final current = _dragCtrl.value;
    final screenH = MediaQuery.sizeOf(context).height;
    final dismissThreshold = math.min(130.0, screenH * 0.22);

    if (widget.isDismissible && (current > dismissThreshold || vy > 720.0)) {
      _dismissing = true;
      OriginHaptics.gestureComplete();
      Navigator.of(context).pop();
      return;
    }

    double targetY = 0.0;
    if (widget.snapFractions.length > 1) {
      final projected = OriginSpringPhysics.projectPosition(
        position: current,
        velocity: vy,
      );
      final sorted = List<double>.of(widget.snapFractions)..sort();
      final maxF = sorted.last;
      final candidates = sorted
          .map((f) => ((maxF - f) * screenH * 0.65).clamp(0.0, screenH * 0.5))
          .toList(growable: false);
      targetY = candidates.reduce(
        (a, b) => (a - projected).abs() <= (b - projected).abs() ? a : b,
      );
    }

    OriginHaptics.snapArrival();
    _rawDragY = targetY;
    _springTo(targetY, velocity: vy);
  }

  void _onDragCancel() {
    if (_dismissing) return;
    _draggingFromHandle = false;
    _rawDragY = 0.0;
    _springTo(0.0);
  }

  @override
  void dispose() {
    _dragCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final reduced = OriginMotionEngine.isReducedMotion(context);
    final entrance = CurvedAnimation(
      parent: widget.animation,
      curve: const OriginSpringCurve(OriginMotionPresets.sheet, durationSeconds: 0.28),
      reverseCurve: Curves.easeInCubic,
    );

    Widget sheetBody = widget.child;
    if (widget.wrapInMaterialSurface) {
      final theme = Theme.of(context);
      sheetBody = Material(
        color: theme.bottomSheetTheme.backgroundColor ?? theme.colorScheme.surface,
        elevation: 8,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        clipBehavior: Clip.antiAlias,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            GestureDetector(
              key: const Key('origin-sheet-handle'),
              behavior: HitTestBehavior.opaque,
              onVerticalDragStart: (d) => _onDragStart(d, fromHandle: true),
              onVerticalDragUpdate: _onDragUpdate,
              onVerticalDragEnd: _onDragEnd,
              onVerticalDragCancel: _onDragCancel,
              child: SizedBox(
                width: double.infinity,
                height: 28,
                child: Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: theme.colorScheme.onSurface.withValues(alpha: .24),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
              ),
            ),
            Flexible(child: widget.child),
          ],
        ),
      );
    }

    return Align(
      alignment: Alignment.bottomCenter,
      child: NotificationListener<ScrollNotification>(
        onNotification: (notification) {
          if (notification.metrics.axis == Axis.vertical) {
            _innerScrolledPastTop = notification.metrics.pixels > 2.0;
          }
          return false;
        },
        child: GestureDetector(
          behavior: HitTestBehavior.translucent,
          onVerticalDragStart: (d) => _onDragStart(d, fromHandle: false),
          onVerticalDragUpdate: _onDragUpdate,
          onVerticalDragEnd: _onDragEnd,
          onVerticalDragCancel: _onDragCancel,
          child: AnimatedBuilder(
            animation: Listenable.merge(<Listenable>[entrance, _dragCtrl]),
            child: sheetBody,
            builder: (context, builtChild) {
              final enterT = reduced ? 1.0 : entrance.value;
              final dragY = _dragCtrl.value;
              final slideY = (1.0 - enterT) * 72.0 + dragY;
              final fluid = OriginFluidPhysics.computeDeformation(
                displacement: Offset(0, dragY < 0 ? dragY : 0),
                velocity: Offset(0, _velocityTracker.estimateVelocity().dy * 0.15),
                maxStretch: 0.06,
                context: context,
              );
              final scaleY = reduced ? 1.0 : (0.95 + 0.05 * enterT).clamp(0.92, 1.03);
              final scaleX = reduced ? 1.0 : (0.97 + 0.03 * enterT).clamp(0.94, 1.02);

              return Transform.translate(
                offset: Offset(0, slideY),
                child: Transform(
                  alignment: Alignment.bottomCenter,
                  transform: Matrix4.diagonal3Values(scaleX, scaleY, 1.0),
                  child: Opacity(
                    opacity: widget.animation.value.clamp(0.0, 1.0).toDouble(),
                    child: OriginLiquidSurface(
                      radius: const BorderRadius.vertical(top: Radius.circular(28)),
                      state: fluid,
                      child: builtChild!,
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
