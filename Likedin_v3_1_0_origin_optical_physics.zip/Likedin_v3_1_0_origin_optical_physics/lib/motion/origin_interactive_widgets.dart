import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'origin_fluid_physics.dart';
import 'origin_gesture_coordinator.dart';
import 'origin_haptics.dart';
import 'origin_motion_presets.dart';
import 'origin_spring_physics.dart';

class OriginLiquidButton extends StatefulWidget {
  const OriginLiquidButton({
    required this.child,
    this.onTap,
    this.enabled = true,
    this.pressedScale = 0.94,
    this.radius = const BorderRadius.all(Radius.circular(24)),
    this.glowColor,
    this.haptic = true,
    super.key,
  });

  final Widget child;
  final VoidCallback? onTap;
  final bool enabled;
  final double pressedScale;
  final BorderRadius radius;
  final Color? glowColor;
  final bool haptic;

  @override
  State<OriginLiquidButton> createState() => _OriginLiquidButtonState();
}

class _OriginLiquidButtonState extends State<OriginLiquidButton>
    with TickerProviderStateMixin {
  late final OriginMotionController _motion = OriginMotionController(vsync: this);
  Offset? _localTouch;
  Size _lastSize = Size.zero;
  bool _pressed = false;

  void _onDown(PointerDownEvent e) {
    if (!widget.enabled) return;
    _pressed = true;
    _localTouch = e.localPosition;
    if (widget.haptic) OriginHaptics.buttonTap();
    if (!OriginMotionEngine.isReducedMotion(context)) {
      _motion.springScaleTo(widget.pressedScale, spec: OriginMotionPresets.crisp);
      if (!_lastSize.isEmpty) {
        final normX = ((e.localPosition.dx / _lastSize.width) - 0.5) * 2.0;
        final normY = ((e.localPosition.dy / _lastSize.height) - 0.5) * 2.0;
        _motion.springOffsetTo(
          Offset(normX * 2.5, normY * 2.5),
          spec: OriginMotionPresets.crisp,
          adaptVelocity: false,
        );
      }
    }
    if (mounted) setState(() {});
  }

  void _onMove(PointerMoveEvent e) {
    if (!_pressed) return;
    _localTouch = e.localPosition;
    if (mounted) setState(() {});
  }

  void _onUp() {
    if (!_pressed) return;
    _pressed = false;
    if (OriginMotionEngine.isReducedMotion(context)) {
      _motion.jumpToScale(1.0);
      _motion.jumpToOffset(Offset.zero);
    } else {
      _motion.springScaleTo(1.0, spec: OriginMotionPresets.elastic);
      _motion.springOffsetTo(Offset.zero, spec: OriginMotionPresets.elastic);
    }
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _motion.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final accent = widget.glowColor ?? Theme.of(context).colorScheme.primary;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final reduced = OriginMotionEngine.isReducedMotion(context);
    final showGlow = _pressed && _localTouch != null && !reduced;

    return Listener(
      behavior: HitTestBehavior.translucent,
      onPointerDown: _onDown,
      onPointerMove: _onMove,
      onPointerUp: (_) => _onUp(),
      onPointerCancel: (_) => _onUp(),
      child: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onTap: widget.enabled ? widget.onTap : null,
        child: AnimatedBuilder(
          animation: _motion,
          child: widget.child,
          builder: (context, child) {
            return LayoutBuilder(
              builder: (context, constraints) {
                if (constraints.hasBoundedWidth && constraints.hasBoundedHeight) {
                  _lastSize = Size(constraints.maxWidth, constraints.maxHeight);
                }
                final s = reduced ? 1.0 : _motion.scale.clamp(0.86, 1.06).toDouble();
                final off = reduced ? Offset.zero : _motion.offset;
                final transform = Matrix4.translationValues(off.dx, off.dy, 0.0) *
                    Matrix4.diagonal3Values(s, s, 1.0);
                return Transform(
                  alignment: Alignment.center,
                  transform: transform,
                  child: CustomPaint(
                    foregroundPainter: showGlow
                        ? _TouchGlowPainter(
                            center: _localTouch!,
                            radius: widget.radius,
                            color: accent,
                            dark: dark,
                          )
                        : null,
                    child: child,
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

class _TouchGlowPainter extends CustomPainter {
  const _TouchGlowPainter({
    required this.center,
    required this.radius,
    required this.color,
    required this.dark,
  });

  final Offset center;
  final BorderRadius radius;
  final Color color;
  final bool dark;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final rect = Offset.zero & size;
    final r = math.max(size.width, size.height) * 0.72;
    final paint = Paint()
      ..shader = RadialGradient(
        colors: [
          (dark ? Colors.white : color).withValues(alpha: dark ? .18 : .14),
          color.withValues(alpha: dark ? .07 : .05),
          color.withValues(alpha: 0.0),
        ],
        stops: const [0.0, 0.48, 1.0],
      ).createShader(Rect.fromCircle(center: center, radius: r));
    canvas.save();
    canvas.clipRRect(radius.toRRect(rect));
    canvas.drawCircle(center, r, paint);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _TouchGlowPainter old) =>
      old.center != center ||
      old.radius != radius ||
      old.color != color ||
      old.dark != dark;
}

class OriginElasticCard extends StatefulWidget {
  const OriginElasticCard({
    required this.child,
    this.maxElasticOffset = 24.0,
    this.radius = const BorderRadius.all(Radius.circular(26)),
    this.enableHorizontalDrag = true,
    super.key,
  });

  final Widget child;
  final double maxElasticOffset;
  final BorderRadius radius;
  final bool enableHorizontalDrag;

  @override
  State<OriginElasticCard> createState() => _OriginElasticCardState();
}

class _OriginElasticCardState extends State<OriginElasticCard>
    with TickerProviderStateMixin {
  late final OriginMotionController _motion = OriginMotionController(vsync: this);
  final OriginGestureCoordinator _gesture = OriginGestureCoordinator();
  double _rawDx = 0.0;

  void _onDragStart(DragStartDetails details) {
    _motion.grab();
    _gesture.start(details.globalPosition, timestamp: details.sourceTimeStamp);
    _rawDx = OriginSpringPhysics.inverseRubberBand(
      _motion.offset.dx,
      widget.maxElasticOffset,
    );
    OriginHaptics.dragStart();
  }

  void _onDragUpdate(DragUpdateDetails details) {
    if (OriginMotionEngine.isReducedMotion(context)) return;
    _gesture.update(details.globalPosition, timestamp: details.sourceTimeStamp);
    _rawDx += details.delta.dx;
    final visualX = OriginSpringPhysics.rubberBand(_rawDx, widget.maxElasticOffset);
    _motion.jumpToOffset(Offset(visualX, 0.0));
  }

  void _onDragEnd(DragEndDetails details) {
    final endSnap = _gesture.end(explicitVelocity: details.velocity.pixelsPerSecond);
    _rawDx = 0.0;
    if (OriginMotionEngine.isReducedMotion(context)) {
      _motion.jumpToOffset(Offset.zero);
      return;
    }
    _motion.springOffsetTo(
      Offset.zero,
      velocity: Offset(endSnap.releaseVelocity.dx * 0.28, 0.0),
      spec: OriginMotionPresets.elastic,
    );
  }

  void _onDragCancel() {
    _gesture.cancel();
    _rawDx = 0.0;
    _motion.springOffsetTo(Offset.zero, spec: OriginMotionPresets.elastic);
  }

  @override
  void dispose() {
    _motion.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final primary = Theme.of(context).colorScheme.primary;
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onHorizontalDragStart: widget.enableHorizontalDrag ? _onDragStart : null,
      onHorizontalDragUpdate: widget.enableHorizontalDrag ? _onDragUpdate : null,
      onHorizontalDragEnd: widget.enableHorizontalDrag ? _onDragEnd : null,
      onHorizontalDragCancel: widget.enableHorizontalDrag ? _onDragCancel : null,
      child: AnimatedBuilder(
        animation: _motion,
        child: widget.child,
        builder: (context, child) {
          final off = _motion.offset;
          if (off.distance < 0.2 && !_motion.isAnimating) {
            return child!;
          }
          final fluid = OriginFluidPhysics.computeDeformation(
            displacement: off,
            velocity: _motion.velocity,
            maxStretch: 0.12,
            referenceDistance: widget.maxElasticOffset * 1.2,
            context: context,
          );
          return Transform.translate(
            offset: off,
            child: OriginLiquidSurface(
              radius: widget.radius,
              state: fluid,
              rimColor: (dark ? Colors.white : primary).withValues(alpha: dark ? 0.34 : 0.26),
              strokeWidth: 1.2,
              child: child!,
            ),
          );
        },
      ),
    );
  }
}

class OriginSpringToggle extends StatefulWidget {
  const OriginSpringToggle({
    required this.value,
    required this.onChanged,
    this.activeColor,
    this.semanticLabel,
    super.key,
  });

  final bool value;
  final ValueChanged<bool>? onChanged;
  final Color? activeColor;
  final String? semanticLabel;

  @override
  State<OriginSpringToggle> createState() => OriginSpringToggleState();
}

@visibleForTesting
class OriginSpringToggleState extends State<OriginSpringToggle>
    with SingleTickerProviderStateMixin {
  late final AnimationController _posCtrl = AnimationController.unbounded(
    vsync: this,
    value: widget.value ? 1.0 : 0.0,
  );
  bool _dragging = false;
  bool _pressed = false;
  bool _crossedMidpoint = false;
  bool? _pendingCommittedValue;
  double _lastSpringLaunchVelocity = 0.0;
  int _springStartCount = 0;

  @visibleForTesting
  double get lastSpringLaunchVelocity => _lastSpringLaunchVelocity;

  @visibleForTesting
  int get springStartCount => _springStartCount;

  static const double _trackW = 54.0;
  static const double _trackH = 31.0;
  static const double _thumbBase = 25.0;
  static const double _pad = 3.0;
  static const double _travel = _trackW - _thumbBase - _pad * 2;

  @override
  void didUpdateWidget(covariant OriginSpringToggle oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.value != widget.value) {
      if (_pendingCommittedValue == widget.value) {
        _pendingCommittedValue = null;
        return;
      }
      _pendingCommittedValue = null;
      if (!_dragging) {
        _springTo(widget.value ? 1.0 : 0.0);
      }
    }
  }

  void _springTo(double target, {double velocity = 0.0}) {
    if (OriginMotionEngine.isReducedMotion(context)) {
      _posCtrl.value = target;
      return;
    }
    _lastSpringLaunchVelocity = velocity;
    _springStartCount++;
    _posCtrl
        .animateWith(
          OriginSpringPhysics.createSimulation(
            spec: OriginMotionPresets.toggle,
            start: _posCtrl.value,
            end: target,
            velocity: velocity,
            adaptVelocity: false,
          ),
        )
        .whenComplete(() {
      if (mounted && !_posCtrl.isAnimating && (_posCtrl.value - target).abs() < 0.01) {
        _posCtrl.value = target;
      }
    });
  }

  void _commitValue(bool next, {double velocity = 0.0}) {
    _springTo(next ? 1.0 : 0.0, velocity: velocity);
    if (next != widget.value) {
      _pendingCommittedValue = next;
      OriginHaptics.toggle();
      widget.onChanged?.call(next);
    }
  }

  @override
  void dispose() {
    _posCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final enabled = widget.onChanged != null;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final accent = widget.activeColor ?? Theme.of(context).colorScheme.primary;
    final offTrack = dark
        ? Colors.white.withValues(alpha: .18)
        : Colors.black.withValues(alpha: .14);
    final deform = OriginMotionEngine.effectiveIntensityFor(context);

    return Semantics(
      toggled: widget.value,
      enabled: enabled,
      label: widget.semanticLabel,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: enabled ? (_) => setState(() => _pressed = true) : null,
        onTapUp: enabled
            ? (_) {
                setState(() => _pressed = false);
                _commitValue(!widget.value);
              }
            : null,
        onTapCancel: enabled ? () => setState(() => _pressed = false) : null,
        onHorizontalDragStart: enabled
            ? (_) {
                _posCtrl.stop(canceled: false);
                _pendingCommittedValue = null;
                _dragging = true;
                _pressed = true;
                _crossedMidpoint = _posCtrl.value >= 0.5;
                if (mounted) setState(() {});
              }
            : null,
        onHorizontalDragUpdate: enabled
            ? (details) {
                final next = (_posCtrl.value + details.delta.dx / _travel)
                    .clamp(-0.08, 1.08)
                    .toDouble();
                _posCtrl.value = next;
                final nowHigh = next >= 0.5;
                if (nowHigh != _crossedMidpoint) {
                  _crossedMidpoint = nowHigh;
                  OriginHaptics.selection();
                }
              }
            : null,
        onHorizontalDragEnd: enabled
            ? (details) {
                _dragging = false;
                _pressed = false;
                final vx = details.velocity.pixelsPerSecond.dx / _travel;
                final next = vx.abs() > 2.2 ? vx > 0 : _posCtrl.value >= 0.5;
                _commitValue(next, velocity: vx.clamp(-18.0, 18.0).toDouble());
                if (mounted) setState(() {});
              }
            : null,
        onHorizontalDragCancel: enabled
            ? () {
                _dragging = false;
                _pressed = false;
                _springTo(widget.value ? 1.0 : 0.0);
                if (mounted) setState(() {});
              }
            : null,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 2),
          child: AnimatedBuilder(
            animation: _posCtrl,
            builder: (context, _) {
              final p = _posCtrl.value.clamp(0.0, 1.0).toDouble();
              final speedStretch = (_posCtrl.velocity.abs() / 16.0).clamp(0.0, 0.24).toDouble();
              final pressStretch = _pressed ? 0.16 : 0.0;
              final thumbW = _thumbBase * (1.0 + (speedStretch + pressStretch) * deform);
              final trackColor = Color.lerp(offTrack, accent, p)!;
              final maxLeft = _trackW - _pad * 2 - thumbW;
              final left = _pad + (p * maxLeft).clamp(0.0, maxLeft);

              return Opacity(
                opacity: enabled ? 1.0 : 0.45,
                child: Container(
                  width: _trackW,
                  height: _trackH,
                  decoration: BoxDecoration(
                    color: trackColor,
                    borderRadius: BorderRadius.circular(_trackH / 2),
                    border: Border.all(
                      color: Colors.white.withValues(alpha: dark ? .18 : .45),
                      width: 0.8,
                    ),
                  ),
                  child: Stack(
                    children: [
                      Positioned(
                        left: left,
                        top: _pad,
                        width: thumbW,
                        height: _thumbBase,
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(_thumbBase / 2),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: .22),
                                blurRadius: 5,
                                offset: const Offset(0, 1.5),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

class OriginLiquidMergePair extends StatelessWidget {
  const OriginLiquidMergePair({
    required this.primary,
    required this.secondary,
    required this.separation,
    required this.bridgeColor,
    this.rimColor,
    this.maxBridgeDistance = 56.0,
    this.nodeRadius = 21.0,
    super.key,
  });

  final Widget primary;
  final Widget secondary;
  final double separation;
  final Color bridgeColor;
  final Color? rimColor;
  final double maxBridgeDistance;
  final double nodeRadius;

  @override
  Widget build(BuildContext context) {
    final safeSep = separation.clamp(0.0, 140.0).toDouble();
    final totalW = nodeRadius * 4 + safeSep;
    final totalH = nodeRadius * 2;
    return SizedBox(
      width: totalW,
      height: totalH,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Positioned.fill(
            child: IgnorePointer(
              child: CustomPaint(
                painter: OriginMetaballBridgePainter(
                  centerA: Offset(nodeRadius, nodeRadius),
                  radiusA: nodeRadius,
                  centerB: Offset(nodeRadius * 3 + safeSep, nodeRadius),
                  radiusB: nodeRadius,
                  color: bridgeColor,
                  rimColor: rimColor,
                  maxBridgeDistance: maxBridgeDistance,
                ),
              ),
            ),
          ),
          Positioned(left: 0, top: 0, child: primary),
          Positioned(left: nodeRadius * 2 + safeSep, top: 0, child: secondary),
        ],
      ),
    );
  }
}

class OriginDraggableSurface extends StatefulWidget {
  const OriginDraggableSurface({
    required this.child,
    this.snapTargets = const <Offset>[],
    this.snapRadius = 72.0,
    this.radius = const BorderRadius.all(Radius.circular(26)),
    this.resetToOriginOnSnap = false,
    this.onSnapped,
    this.onRejected,
    super.key,
  });

  final Widget child;
  final List<Offset> snapTargets;
  final double snapRadius;
  final BorderRadius radius;
  final bool resetToOriginOnSnap;
  final ValueChanged<Offset>? onSnapped;
  final VoidCallback? onRejected;

  @override
  State<OriginDraggableSurface> createState() => _OriginDraggableSurfaceState();
}

class _OriginDraggableSurfaceState extends State<OriginDraggableSurface>
    with TickerProviderStateMixin {
  late final OriginMotionController _motion = OriginMotionController(vsync: this);
  final OriginGestureCoordinator _gesture = OriginGestureCoordinator();
  Offset? _magneticTarget;

  @override
  void dispose() {
    _motion.dispose();
    super.dispose();
  }

  Offset? _nearestTarget(Offset pos) {
    Offset? best;
    var bestDist = widget.snapRadius;
    for (final t in widget.snapTargets) {
      final d = (t - pos).distance;
      if (d < bestDist) {
        bestDist = d;
        best = t;
      }
    }
    return best;
  }

  @override
  Widget build(BuildContext context) {
    final reduced = OriginMotionEngine.isReducedMotion(context);
    return GestureDetector(
      onPanStart: (d) {
        _motion.grab();
        _gesture.start(d.globalPosition, timestamp: d.sourceTimeStamp);
        if (!reduced) {
          _motion.springScaleTo(1.03, spec: OriginMotionPresets.crisp);
        }
        OriginHaptics.dragStart();
      },
      onPanUpdate: (d) {
        _gesture.update(d.globalPosition, timestamp: d.sourceTimeStamp);
        final next = _motion.offset + d.delta;
        final near = _nearestTarget(next);
        if (near != null && _magneticTarget != near) {
          OriginHaptics.snapArrival();
        }
        _magneticTarget = near;
        final pulled = near == null ? next : Offset.lerp(next, near, 0.22)!;
        _motion.jumpToOffset(pulled);
      },
      onPanEnd: (d) {
        final snap = _gesture.end(explicitVelocity: d.velocity.pixelsPerSecond);
        if (reduced) {
          _motion.jumpToScale(1.0);
        } else {
          _motion.springScaleTo(1.0, spec: OriginMotionPresets.general);
        }
        final projected = Offset(
          OriginSpringPhysics.projectPosition(
            position: _motion.offset.dx,
            velocity: snap.releaseVelocity.dx * 0.25,
          ),
          OriginSpringPhysics.projectPosition(
            position: _motion.offset.dy,
            velocity: snap.releaseVelocity.dy * 0.25,
          ),
        );
        final target = _nearestTarget(projected) ?? _magneticTarget;
        _magneticTarget = null;
        if (target != null) {
          OriginHaptics.dropSuccess();
          if (widget.resetToOriginOnSnap) {
            _motion.jumpToOffset(Offset.zero);
          } else if (reduced) {
            _motion.jumpToOffset(target);
          } else {
            _motion.springOffsetTo(
              target,
              velocity: snap.releaseVelocity,
              spec: OriginMotionPresets.general,
            );
          }
          widget.onSnapped?.call(target);
        } else {
          if (reduced) {
            _motion.jumpToOffset(Offset.zero);
          } else {
            _motion.springOffsetTo(
              Offset.zero,
              velocity: snap.releaseVelocity,
              spec: OriginMotionPresets.elastic,
            );
          }
          widget.onRejected?.call();
        }
      },
      onPanCancel: () {
        _gesture.cancel();
        _magneticTarget = null;
        _motion.springScaleTo(1.0, spec: OriginMotionPresets.general);
        _motion.springOffsetTo(Offset.zero, spec: OriginMotionPresets.elastic);
        widget.onRejected?.call();
      },
      child: AnimatedBuilder(
        animation: _motion,
        child: widget.child,
        builder: (context, child) {
          final fluid = OriginFluidPhysics.computeDeformation(
            displacement: _motion.offset,
            velocity: _motion.velocity,
            maxStretch: 0.12,
            context: context,
          );
          return Transform.translate(
            offset: _motion.offset,
            child: Transform.scale(
              scale: reduced ? 1.0 : _motion.scale,
              child: OriginLiquidSurface(
                radius: widget.radius,
                state: fluid,
                child: child!,
              ),
            ),
          );
        },
      ),
    );
  }
}
