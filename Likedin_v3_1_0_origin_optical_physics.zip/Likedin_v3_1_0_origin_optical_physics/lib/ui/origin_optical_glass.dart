import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

class OriginGlassMaterialProfile {
  const OriginGlassMaterialProfile({
    required this.refractionPx,
    required this.dispersion,
    required this.frostRadiusPx,
    required this.fallbackBlurSigma,
    required this.edgeIntensity,
    required this.fresnelF0,
    required this.specularStrength,
    required this.innerContourAlpha,
    required this.outerRimWidth,
    required this.causticStrength,
    required this.frostedTintAlphaDark,
    required this.frostedTintAlphaLight,
    required this.cardTintAlphaDark,
    required this.cardTintAlphaLight,
    required this.usesShaderRefraction,
  });

  final double refractionPx;
  final double dispersion;
  final double frostRadiusPx;
  final double fallbackBlurSigma;
  final double edgeIntensity;
  final double fresnelF0;
  final double specularStrength;
  final double innerContourAlpha;
  final double outerRimWidth;
  final double causticStrength;
  final double frostedTintAlphaDark;
  final double frostedTintAlphaLight;
  final double cardTintAlphaDark;
  final double cardTintAlphaLight;
  final bool usesShaderRefraction;

  static OriginGlassMaterialProfile resolve({
    required String tierName,
    required bool lowRamDevice,
    required bool reduceMotion,
  }) {
    if (tierName == 'off') {
      return const OriginGlassMaterialProfile(
        refractionPx: 0.0,
        dispersion: 0.0,
        frostRadiusPx: 0.0,
        fallbackBlurSigma: 0.0,
        edgeIntensity: 0.0,
        fresnelF0: 0.0,
        specularStrength: 0.0,
        innerContourAlpha: 0.0,
        outerRimWidth: 1.0,
        causticStrength: 0.0,
        frostedTintAlphaDark: 1.0,
        frostedTintAlphaLight: 1.0,
        cardTintAlphaDark: 1.0,
        cardTintAlphaLight: 1.0,
        usesShaderRefraction: false,
      );
    }

    if (tierName == 'real') {
      return OriginGlassMaterialProfile(
        refractionPx: reduceMotion ? 0.0 : (lowRamDevice ? 7.5 : 13.5),
        dispersion: reduceMotion ? 0.0 : (lowRamDevice ? 0.0 : 0.16),
        frostRadiusPx: reduceMotion ? 0.0 : (lowRamDevice ? 1.8 : 2.6),
        fallbackBlurSigma: reduceMotion ? 0.0 : (lowRamDevice ? 3.2 : 4.2),
        edgeIntensity: lowRamDevice ? 0.82 : 1.0,
        fresnelF0: 0.14,
        specularStrength: lowRamDevice ? 0.78 : 1.0,
        innerContourAlpha: 0.56,
        outerRimWidth: 1.35,
        causticStrength: lowRamDevice ? 0.48 : 0.78,
        frostedTintAlphaDark: reduceMotion ? 0.70 : 0.14,
        frostedTintAlphaLight: reduceMotion ? 0.86 : 0.22,
        cardTintAlphaDark: 0.42,
        cardTintAlphaLight: 0.62,
        usesShaderRefraction: !reduceMotion,
      );
    }

    if (tierName == 'natural') {
      return OriginGlassMaterialProfile(
        refractionPx: (reduceMotion || lowRamDevice) ? 0.0 : 5.8,
        dispersion: (reduceMotion || lowRamDevice) ? 0.0 : 0.04,
        frostRadiusPx: (reduceMotion || lowRamDevice) ? 0.0 : 6.8,
        fallbackBlurSigma: (reduceMotion || lowRamDevice) ? 0.0 : 10.5,
        edgeIntensity: 0.56,
        fresnelF0: 0.08,
        specularStrength: 0.54,
        innerContourAlpha: 0.30,
        outerRimWidth: 1.1,
        causticStrength: 0.34,
        frostedTintAlphaDark: (reduceMotion || lowRamDevice) ? 0.56 : 0.26,
        frostedTintAlphaLight: (reduceMotion || lowRamDevice) ? 0.72 : 0.36,
        cardTintAlphaDark: 0.60,
        cardTintAlphaLight: 0.78,
        usesShaderRefraction: !reduceMotion && !lowRamDevice,
      );
    }

    return OriginGlassMaterialProfile(
      refractionPx: (reduceMotion || lowRamDevice) ? 0.0 : 1.2,
      dispersion: 0.0,
      frostRadiusPx: (reduceMotion || lowRamDevice) ? 0.0 : 11.5,
      fallbackBlurSigma: (reduceMotion || lowRamDevice) ? 0.0 : 17.5,
      edgeIntensity: 0.26,
      fresnelF0: 0.04,
      specularStrength: 0.22,
      innerContourAlpha: 0.14,
      outerRimWidth: 0.9,
      causticStrength: 0.10,
      frostedTintAlphaDark: (reduceMotion || lowRamDevice) ? 0.76 : 0.42,
      frostedTintAlphaLight: (reduceMotion || lowRamDevice) ? 0.86 : 0.54,
      cardTintAlphaDark: 0.75,
      cardTintAlphaLight: 0.86,
      usesShaderRefraction: !reduceMotion && !lowRamDevice,
    );
  }
}

class OriginOpticalLightModel {
  OriginOpticalLightModel._();

  static const Offset defaultLightDir = Offset(-0.46, -0.89);

  static Offset lightDirectionForTilt(Offset tilt, {bool interactive = false}) {
    if (!interactive || tilt == Offset.zero) return defaultLightDir;
    final raw = Offset(
      defaultLightDir.dx + tilt.dx * 0.32,
      defaultLightDir.dy + tilt.dy * 0.24,
    );
    final len = raw.distance;
    return len > 0.001 ? Offset(raw.dx / len, raw.dy / len) : defaultLightDir;
  }

  static double sdRoundedBox(Offset localP, Size halfSize, double radius) {
    final r = radius.clamp(0.0, math.min(halfSize.width, halfSize.height)).toDouble();
    final qx = localP.dx.abs() - halfSize.width + r;
    final qy = localP.dy.abs() - halfSize.height + r;
    final outX = math.max(qx, 0.0);
    final outY = math.max(qy, 0.0);
    return math.min(math.max(qx, qy), 0.0) + math.sqrt(outX * outX + outY * outY) - r;
  }

  static double bezelRefractionFactor({
    required double dist,
    required Size halfSize,
  }) {
    if (dist > 0.0) return 0.0;
    final bezelWidth =
        (math.min(halfSize.width, halfSize.height) * 0.42).clamp(8.0, 44.0).toDouble();
    final depthIn = -dist;
    final edgeT = (1.0 - (depthIn / bezelWidth)).clamp(0.0, 1.0).toDouble();
    final smoothBezel = edgeT * edgeT * (3.0 - 2.0 * edgeT);
    final boundaryTaper = (depthIn / 1.5).clamp(0.0, 1.0).toDouble();
    return smoothBezel * smoothBezel * boundaryTaper;
  }

  static double fresnelReflection(double cosTheta, double f0) {
    final c = (1.0 - cosTheta.clamp(0.0, 1.0)).toDouble();
    return f0 + (1.0 - f0) * c * c * c;
  }

  static double directionalResponse(Offset edgeNormal, Offset lightDir) {
    final nLen = edgeNormal.distance;
    final lLen = lightDir.distance;
    if (nLen <= 0.0001 || lLen <= 0.0001) return 0.0;
    final dot = (edgeNormal.dx * lightDir.dx + edgeNormal.dy * lightDir.dy) / (nLen * lLen);
    return dot.clamp(0.0, 1.0).toDouble();
  }
}

class OriginGlassShaderEngine {
  OriginGlassShaderEngine._();

  static const String shaderAssetPath = 'shaders/origin_liquid_glass.frag';
  static ui.FragmentProgram? _program;
  static Future<void>? _loadFuture;
  static bool _failed = false;

  static final ValueNotifier<int> readyRevision = ValueNotifier<int>(0);

  static bool get isSupported => ui.ImageFilter.isShaderFilterSupported;
  static bool get isReady => _program != null && !_failed && isSupported;
  static ui.FragmentProgram? get program => _program;

  static Future<void> preload() {
    if (_program != null || _failed || !isSupported) {
      return Future<void>.value();
    }
    return _loadFuture ??= _loadInternal();
  }

  static Future<void> _loadInternal() async {
    try {
      _program = await ui.FragmentProgram.fromAsset(shaderAssetPath);
      readyRevision.value++;
    } catch (error) {
      _failed = true;
      debugPrint('OriginGlassShaderEngine fallback active (shader unavailable): $error');
    }
  }
}

class OriginRefractiveBackdrop extends SingleChildRenderObjectWidget {
  const OriginRefractiveBackdrop({
    required this.profile,
    required this.radius,
    required this.tintColor,
    required this.accentColor,
    required this.dark,
    required this.lightDir,
    required this.devicePixelRatio,
    required super.child,
    super.key,
  });

  final OriginGlassMaterialProfile profile;
  final BorderRadius radius;
  final Color tintColor;
  final Color accentColor;
  final bool dark;
  final Offset lightDir;
  final double devicePixelRatio;

  @override
  RenderObject createRenderObject(BuildContext context) =>
      _RenderOriginRefractiveBackdrop(
        profile: profile,
        radius: radius,
        tintColor: tintColor,
        accentColor: accentColor,
        dark: dark,
        lightDir: lightDir,
        devicePixelRatio: devicePixelRatio,
      );

  @override
  void updateRenderObject(
    BuildContext context,
    covariant _RenderOriginRefractiveBackdrop renderObject,
  ) {
    renderObject
      ..profile = profile
      ..radius = radius
      ..tintColor = tintColor
      ..accentColor = accentColor
      ..dark = dark
      ..lightDir = lightDir
      ..devicePixelRatio = devicePixelRatio;
  }
}

class _RenderOriginRefractiveBackdrop extends RenderProxyBox {
  _RenderOriginRefractiveBackdrop({
    required OriginGlassMaterialProfile profile,
    required BorderRadius radius,
    required Color tintColor,
    required Color accentColor,
    required bool dark,
    required Offset lightDir,
    required double devicePixelRatio,
  })  : _profile = profile,
        _radius = radius,
        _tintColor = tintColor,
        _accentColor = accentColor,
        _dark = dark,
        _lightDir = lightDir,
        _devicePixelRatio = devicePixelRatio;

  OriginGlassMaterialProfile _profile;
  BorderRadius _radius;
  Color _tintColor;
  Color _accentColor;
  bool _dark;
  Offset _lightDir;
  double _devicePixelRatio;
  ui.FragmentShader? _shader;

  set profile(OriginGlassMaterialProfile value) {
    if (_profile == value) return;
    _profile = value;
    markNeedsPaint();
  }

  set radius(BorderRadius value) {
    if (_radius == value) return;
    _radius = value;
    markNeedsPaint();
  }

  set tintColor(Color value) {
    if (_tintColor == value) return;
    _tintColor = value;
    markNeedsPaint();
  }

  set accentColor(Color value) {
    if (_accentColor == value) return;
    _accentColor = value;
    markNeedsPaint();
  }

  set dark(bool value) {
    if (_dark == value) return;
    _dark = value;
    markNeedsPaint();
  }

  set lightDir(Offset value) {
    if (_lightDir == value) return;
    _lightDir = value;
    markNeedsPaint();
  }

  set devicePixelRatio(double value) {
    if (_devicePixelRatio == value) return;
    _devicePixelRatio = value;
    markNeedsPaint();
  }

  @override
  bool get alwaysNeedsCompositing => true;

  @override
  void dispose() {
    _shader?.dispose();
    _shader = null;
    super.dispose();
  }

  @override
  void paint(PaintingContext context, Offset offset) {
    final program = OriginGlassShaderEngine.program;
    if (!OriginGlassShaderEngine.isReady ||
        program == null ||
        !_profile.usesShaderRefraction ||
        size.isEmpty) {
      super.paint(context, offset);
      return;
    }

    final shader = _shader ??= program.fragmentShader();
    final dpr = _devicePixelRatio.clamp(1.0, 4.0).toDouble();
    final globalTopLeft = MatrixUtils.transformPoint(getTransformTo(null), Offset.zero);
    final physX = globalTopLeft.dx * dpr;
    final physY = globalTopLeft.dy * dpr;
    final physW = size.width * dpr;
    final physH = size.height * dpr;
    final avgRadius = (_radius.topLeft.x +
            _radius.topRight.x +
            _radius.bottomLeft.x +
            _radius.bottomRight.x) *
        0.25;
    final physR = (avgRadius * dpr).clamp(1.0, math.min(physW, physH) * 0.5).toDouble();

    shader
      ..setFloat(2, physX)
      ..setFloat(3, physY)
      ..setFloat(4, physW)
      ..setFloat(5, physH)
      ..setFloat(6, physR)
      ..setFloat(7, _profile.refractionPx * dpr * 0.5)
      ..setFloat(8, _profile.dispersion)
      ..setFloat(9, _profile.frostRadiusPx * dpr * 0.5)
      ..setFloat(10, _lightDir.dx)
      ..setFloat(11, _lightDir.dy)
      ..setFloat(12, _profile.edgeIntensity)
      ..setFloat(13, _dark ? 1.0 : 0.0)
      ..setFloat(14, _tintColor.r)
      ..setFloat(15, _tintColor.g)
      ..setFloat(16, _tintColor.b)
      ..setFloat(17, _tintColor.a)
      ..setFloat(18, _accentColor.r)
      ..setFloat(19, _accentColor.g)
      ..setFloat(20, _accentColor.b)
      ..setFloat(21, _profile.causticStrength);

    final filter = ui.ImageFilter.shader(
      shader,
      filterQuality: FilterQuality.low,
    );
    layer = context.pushLayer(
      BackdropFilterLayer(filter: filter),
      super.paint,
      offset,
      oldLayer: layer as BackdropFilterLayer?,
    );
  }
}
