import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/ui/glass_showcase_page.dart';
import 'package:likedin/ui/glassmorphism.dart';
import 'package:likedin/ui/origin_optical_glass.dart';

void main() {
  setUp(() {
    LikedinAppearance.reduceMotion.value = false;
    LikedinAppearance.isLowRamDevice = false;
    LikedinAppearance.effects.value = LikedinEffects.real;
  });

  group('OriginGlassMaterialProfile material differentiation', () {
    test('Real, Natural, Soft, and Off differ in refraction, dispersion, frost, and edge optics', () {
      final real = OriginGlassMaterialProfile.resolve(
        tierName: 'real',
        lowRamDevice: false,
        reduceMotion: false,
      );
      final natural = OriginGlassMaterialProfile.resolve(
        tierName: 'natural',
        lowRamDevice: false,
        reduceMotion: false,
      );
      final soft = OriginGlassMaterialProfile.resolve(
        tierName: 'soft',
        lowRamDevice: false,
        reduceMotion: false,
      );
      final off = OriginGlassMaterialProfile.resolve(
        tierName: 'off',
        lowRamDevice: false,
        reduceMotion: false,
      );

      expect(real.refractionPx, greaterThan(natural.refractionPx));
      expect(natural.refractionPx, greaterThan(soft.refractionPx));
      expect(soft.refractionPx, greaterThan(off.refractionPx));

      expect(soft.frostRadiusPx, greaterThan(natural.frostRadiusPx));
      expect(natural.frostRadiusPx, greaterThan(real.frostRadiusPx));

      expect(real.edgeIntensity, greaterThan(natural.edgeIntensity));
      expect(natural.edgeIntensity, greaterThan(soft.edgeIntensity));
      expect(real.dispersion, greaterThan(natural.dispersion));
      expect(soft.dispersion, 0.0);
    });

    test('Low-RAM and Reduce Motion fallbacks reduce refraction and disable heavy blur safely', () {
      final realLowRam = OriginGlassMaterialProfile.resolve(
        tierName: 'real',
        lowRamDevice: true,
        reduceMotion: false,
      );
      final realHighRam = OriginGlassMaterialProfile.resolve(
        tierName: 'real',
        lowRamDevice: false,
        reduceMotion: false,
      );
      expect(realLowRam.refractionPx, lessThan(realHighRam.refractionPx));
      expect(realLowRam.dispersion, 0.0);

      final softLowRam = OriginGlassMaterialProfile.resolve(
        tierName: 'soft',
        lowRamDevice: true,
        reduceMotion: false,
      );
      expect(softLowRam.usesShaderRefraction, isFalse);
      expect(softLowRam.fallbackBlurSigma, 0.0);

      final reduced = OriginGlassMaterialProfile.resolve(
        tierName: 'real',
        lowRamDevice: false,
        reduceMotion: true,
      );
      expect(reduced.usesShaderRefraction, isFalse);
      expect(reduced.refractionPx, 0.0);
      expect(reduced.fallbackBlurSigma, 0.0);
    });
  });

  group('OriginOpticalLightModel SDF & Fresnel math', () {
    test('preserves central clarity (zero displacement at center) and tapers smoothly at boundary', () {
      const half = Size(120, 40);
      final centerDist = OriginOpticalLightModel.sdRoundedBox(Offset.zero, half, 24);
      expect(centerDist, lessThan(-25));
      expect(
        OriginOpticalLightModel.bezelRefractionFactor(dist: centerDist, halfSize: half),
        0.0,
      );

      final bezelFactor = OriginOpticalLightModel.bezelRefractionFactor(dist: -4.0, halfSize: half);
      expect(bezelFactor, greaterThan(0.25));
      expect(bezelFactor, lessThanOrEqualTo(1.0));

      expect(OriginOpticalLightModel.bezelRefractionFactor(dist: 1.0, halfSize: half), 0.0);
    });

    test('Fresnel increases at grazing angles and directional light favors light-facing edge', () {
      final centerF = OriginOpticalLightModel.fresnelReflection(1.0, 0.14);
      final edgeF = OriginOpticalLightModel.fresnelReflection(0.1, 0.14);
      expect(edgeF, greaterThan(centerF));

      final topLit = OriginOpticalLightModel.directionalResponse(
        const Offset(0, -1),
        OriginOpticalLightModel.defaultLightDir,
      );
      final bottomLit = OriginOpticalLightModel.directionalResponse(
        const Offset(0, 1),
        OriginOpticalLightModel.defaultLightDir,
      );
      expect(topLit, greaterThan(0.7));
      expect(bottomLit, 0.0);
    });
  });

  group('Accessibility & GlassShowcasePage', () {
    testWidgets('GlassPanel respects Android system disableAnimations setting', (tester) async {
      LikedinAppearance.effects.value = LikedinEffects.real;
      LikedinAppearance.reduceMotion.value = false;

      await tester.pumpWidget(
        const MediaQuery(
          data: MediaQueryData(disableAnimations: true),
          child: MaterialApp(
            home: Scaffold(
              body: Center(
                child: GlassPanel(
                  frosted: true,
                  child: Text('Accessible Glass'),
                ),
              ),
            ),
          ),
        ),
      );
      expect(find.byType(BackdropFilter), findsNothing);
      expect(find.text('Accessible Glass'), findsOneWidget);
    });

    testWidgets('GlassShowcasePage compares Real, Natural, Soft, Off across backgrounds', (tester) async {
      await tester.pumpWidget(const MaterialApp(home: GlassShowcasePage()));
      await tester.pumpAndSettle();

      expect(find.text('Real · 真实'), findsOneWidget);
      expect(find.text('Natural · 自然'), findsOneWidget);
      expect(find.text('Soft · 柔和'), findsOneWidget);
      expect(find.text('Off · Solid'), findsOneWidget);

      await tester.tap(find.text('Overlapping'));
      await tester.pumpAndSettle();
      expect(find.text('Real (真实) Top'), findsOneWidget);
      expect(find.text('Natural (自然) Mid'), findsOneWidget);
      expect(find.text('Soft (柔和) Base'), findsOneWidget);
      expect(tester.takeException(), isNull);
    });
  });
}
