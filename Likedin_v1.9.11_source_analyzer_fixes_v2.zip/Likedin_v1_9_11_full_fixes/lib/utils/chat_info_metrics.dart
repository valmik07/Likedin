import 'dart:convert';

import '../backend/realtime_messaging_service.dart';

/// Pure Contact Info filtering and counting helpers. Keeping these rules out
/// of widget build methods makes hidden/cleared-message behaviour testable.
class ChatInfoMetrics {
  static final RegExp _linkPattern = RegExp(r'https?://\S+', caseSensitive: false);

  static bool isLocallyVisible(
    RemoteMessage message, {
    Set<String> hiddenMessageIds = const <String>{},
    int? clearedBeforeMs,
    Set<String> postClearVisibleMessageIds = const <String>{},
  }) {
    if (hiddenMessageIds.contains(message.id)) return false;
    if (postClearVisibleMessageIds.contains(message.id) ||
        (message.clientMessageId != null &&
            postClearVisibleMessageIds.contains(message.clientMessageId))) return true;
    return clearedBeforeMs == null ||
        message.createdAt.millisecondsSinceEpoch > clearedBeforeMs;
  }

  static List<RemoteMessage> visibleMessages(
    Iterable<RemoteMessage> messages, {
    Set<String> hiddenMessageIds = const <String>{},
    int? clearedBeforeMs,
    Set<String> postClearVisibleMessageIds = const <String>{},
  }) => messages.where((message) =>
        message.deletedForEveryoneAt == null &&
        isLocallyVisible(
          message,
          hiddenMessageIds: hiddenMessageIds,
          clearedBeforeMs: clearedBeforeMs,
          postClearVisibleMessageIds: postClearVisibleMessageIds,
        )).toList(growable: false);

  static Map<String, dynamic>? decodeMediaPayload(String value) {
    try {
      final decoded = jsonDecode(value);
      if (decoded is Map && decoded['__likedin_media_v1'] == true) {
        return Map<String, dynamic>.from(decoded);
      }
    } catch (_) {
      // Plain text messages are not media payloads.
    }
    return null;
  }

  static List<Map<String, dynamic>> mediaItems(Iterable<RemoteMessage> messages) =>
      messages
          .where((message) => message.deletedForEveryoneAt == null)
          .map((message) => decodeMediaPayload(message.text))
          .whereType<Map<String, dynamic>>()
          .where((item) => item['kind']?.toString() != 'audio')
          .toList(growable: false);

  /// Return only image/video items, preserving their original oldest-first order.
  static List<Map<String, dynamic>> visualMediaItems(Iterable<Map<String, dynamic>> media) =>
      media.where((item) {
        final kind = item['kind']?.toString();
        return kind == 'image' || kind == 'video';
      }).toList(growable: false);

  /// Contact Info receives messages oldest-first. This returns the newest N
  /// visual media items first, which is also the desired preview-strip order.
  static List<Map<String, dynamic>> latestVisualMedia(
    Iterable<Map<String, dynamic>> media, {
    int limit = 4,
  }) => visualMediaItems(media).reversed.take(limit < 0 ? 0 : limit).toList(growable: false);

  /// Counts messages containing a link (not every URL token in one message).
  static List<String> links(Iterable<RemoteMessage> messages) {
    final found = <String>{};
    for (final message in messages) {
      if (message.deletedForEveryoneAt != null) continue;
      for (final match in _linkPattern.allMatches(message.text)) {
        final value = match.group(0)?.trim();
        if (value != null && value.isNotEmpty) found.add(value);
      }
    }
    return found.toList(growable: false);
  }

  static int linkCount(Iterable<RemoteMessage> messages) => links(messages).length;

  static int documentCount(Iterable<Map<String, dynamic>> media) => media.where((item) {
        final kind = item['kind']?.toString() ?? 'file';
        return kind != 'image' && kind != 'video';
      }).length;
}
