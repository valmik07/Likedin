import 'dart:convert';
import 'dart:ui' as ui;
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../backend/backend_config.dart';

const likedinMessageChannelId = 'likedin_messages_v1';
const likedinCallChannelId = 'likedin_calls_v1';
const _callLaunchChannel = MethodChannel('com.example.likedin/call_alerts');

@pragma('vm:entry-point')
Future<void> likedinFirebaseBackgroundHandler(RemoteMessage message) async {
  // Register plugins in the Firebase background isolate before invoking
  // flutter_local_notifications or any other platform plugin.
  WidgetsFlutterBinding.ensureInitialized();
  ui.DartPluginRegistrant.ensureInitialized();

  // Display first. A delivery receipt must never be written before the local
  // notification attempt, otherwise a failed display can look delivered.
  try {
    final local = FlutterLocalNotificationsPlugin();
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await local.initialize(const InitializationSettings(android: android));
    final route = message.data['route']?.toString();
    final isCall = route == 'incoming_call' || route == 'missed_call';
    final isMissed = route == 'missed_call';
    final details = NotificationDetails(
      android: AndroidNotificationDetails(
        isCall ? likedinCallChannelId : likedinMessageChannelId,
        isCall ? 'Likedin calls' : 'Likedin messages',
        channelDescription: isCall ? 'Incoming private calls' : 'New messages from your private Likedin conversation',
        importance: isCall ? Importance.max : Importance.high,
        priority: isCall ? Priority.max : Priority.high,
        playSound: !isCall,
        sound: RawResourceAndroidNotificationSound(isCall ? 'likedin_call' : 'likedin_message'),
        category: isCall ? AndroidNotificationCategory.call : AndroidNotificationCategory.message,
        fullScreenIntent: route == 'incoming_call',
        ongoing: route == 'incoming_call',
        autoCancel: route != 'incoming_call',
        visibility: NotificationVisibility.public,
      ),
    );
    final title = message.data['notification_title']?.toString() ?? 'Likedin';
    final body = message.data['notification_body']?.toString() ?? (isMissed ? 'You missed a call.' : isCall ? 'Incoming call' : 'You received a new message.');
    await local.show(
      (message.data['call_id']?.toString().hashCode) ?? message.messageId?.hashCode ?? DateTime.now().millisecondsSinceEpoch.remainder(100000),
      title,
      body,
      details,
      payload: jsonEncode(route == 'missed_call' ? {'route':'missed_call','call_id':message.data['call_id']} : isCall ? {'route': 'incoming_call', 'call_id': message.data['call_id']} : {'route': 'chat'}),
    );
  } catch (error) {
    debugPrint('Could not display background Likedin notification: $error');
  }

  // Acknowledge after the notification display attempt. If the background
  // isolate cannot restore the Supabase session, foreground sync will retry.
  try {
    if (Firebase.apps.isEmpty) await Firebase.initializeApp();
    await Supabase.initialize(
      url: BackendConfig.supabaseUrl,
      anonKey: BackendConfig.supabaseAnonKey,
    );
    final messageId = message.data['message_id']?.toString();
    if (messageId != null && messageId.isNotEmpty) {
      await Supabase.instance.client.rpc(
        'likedin_mark_message_delivered',
        params: {'p_message_id': messageId},
      );
    }
  } catch (error) {
    debugPrint('Background delivery acknowledgement deferred: $error');
  }
}

class LikedinNotificationService {
  LikedinNotificationService._();
  static final instance = LikedinNotificationService._();
  final FlutterLocalNotificationsPlugin _local = FlutterLocalNotificationsPlugin();
  bool _localReady = false;
  bool _pushReady = false;
  bool isConversationVisible = false;
  bool openedFromNotification = false;
  void Function()? onOpenChat;
  void Function(String callId)? onOpenIncomingCall;
  void Function()? onOpenCalls;
  String? _pendingIncomingCallId;

  bool get pushConfigured => _pushReady;

  void setConversationVisible(bool visible) {
    isConversationVisible = visible;
  }

  void setOnOpenIncomingCall(void Function(String callId) callback) {
    onOpenIncomingCall = callback;
    final pending = _pendingIncomingCallId;
    if (pending != null) {
      _pendingIncomingCallId = null;
      callback(pending);
    }
  }

  void _dispatchTap({String? payload, Map<String, dynamic>? data}) {
    String? route;
    String? callId;
    if (data != null) {
      route = data['route']?.toString();
      callId = data['call_id']?.toString();
    }
    if (payload != null && payload.isNotEmpty) {
      try {
        final decoded = jsonDecode(payload);
        if (decoded is Map) {
          route ??= decoded['route']?.toString();
          callId ??= decoded['call_id']?.toString();
        }
      } catch (_) {}
    }
    if (route == 'call_history' || route == 'missed_call') {
      final callback = onOpenCalls;
      if (callback != null) callback();
      return;
    }
    if (route == 'incoming_call' && callId != null && callId.isNotEmpty) {
      final callback = onOpenIncomingCall;
      if (callback == null) { _pendingIncomingCallId = callId; } else { callback(callId); }
      return;
    }
    _handleNotificationTap();
  }

  void setOnOpenCalls(void Function() callback) { onOpenCalls = callback; }

  void setOnOpenChat(void Function() callback) {
    onOpenChat = callback;
    if (openedFromNotification) {
      openedFromNotification = false;
      callback();
    }
  }

  void _handleNotificationTap() {
    final callback = onOpenChat;
    if (callback == null) {
      openedFromNotification = true;
    } else {
      callback();
    }
  }

  Future<void> initialize() async {
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    await _local.initialize(settings, onDidReceiveNotificationResponse: (response) => _dispatchTap(payload: response.payload));
    final launchDetails = await _local.getNotificationAppLaunchDetails();
    if (launchDetails?.didNotificationLaunchApp == true) {
      final payload = launchDetails?.notificationResponse?.payload;
      if (payload != null && payload.isNotEmpty) { _dispatchTap(payload: payload); } else { openedFromNotification = true; }
    }
    const callChannel = AndroidNotificationChannel(
      likedinCallChannelId,
      'Likedin calls',
      description: 'Incoming private audio and video calls',
      importance: Importance.max,
      playSound: true,
      sound: RawResourceAndroidNotificationSound('likedin_call'),
      enableVibration: true,
    );
    await _local.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.createNotificationChannel(callChannel);
    const channel = AndroidNotificationChannel(
      likedinMessageChannelId,
      'Likedin messages',
      description: 'New messages from your private Likedin conversation',
      importance: Importance.high,
      playSound: true,
      sound: RawResourceAndroidNotificationSound('likedin_message'),
      enableVibration: true,
    );
    await _local.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.createNotificationChannel(channel);
    final androidPlugin = _local.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.requestNotificationsPermission();
    // Android 14+ can restrict full-screen intents. The native bridge opens
    // the dedicated system permission screen only when access is not granted.
    try { await _callLaunchChannel.invokeMethod<bool>('ensureFullScreenCallPermission'); } catch (error) { debugPrint('Full-screen call permission check failed: $error'); }
    _localReady = true;

    // Firebase credentials are intentionally not bundled in source control.
    // Until google-services.json / Firebase options are supplied, local
    // notifications still work and the app remains buildable.
    try {
      if (Firebase.apps.isEmpty) await Firebase.initializeApp();
      FirebaseMessaging.onBackgroundMessage(likedinFirebaseBackgroundHandler);
      await FirebaseMessaging.instance.requestPermission(alert: true, badge: true, sound: true);
      FirebaseMessaging.onMessage.listen((message) {
        final route = message.data['route']?.toString();
        if (route == 'incoming_call') {
          // FCM is a second foreground delivery path. Do not rely exclusively
          // on the Postgres Changes subscription to open the incoming-call UI.
          _dispatchTap(data: message.data);
          return;
        }
        if (route == 'missed_call') {
          showMissedCall(
            callId: message.data['call_id']?.toString() ??
                DateTime.now().millisecondsSinceEpoch.toString(),
            video: message.data['call_type'] == 'video',
          );
          return;
        }
        if (!isConversationVisible) _showForegroundPush(message);
      });
      FirebaseMessaging.onMessageOpenedApp.listen((message) => _dispatchTap(data: message.data));
      FirebaseMessaging.instance.onTokenRefresh.listen((token) {
        _saveToken(token).catchError((error) => debugPrint('Could not update Likedin push token: $error'));
      });
      _pushReady = true;
      final initialMessage = await FirebaseMessaging.instance.getInitialMessage();
      if (initialMessage != null) _dispatchTap(data: initialMessage.data);
      final token = await FirebaseMessaging.instance.getToken();
      if (token != null) await _saveToken(token);
    } catch (error) {
      debugPrint('Likedin push is not configured yet: $error');
      _pushReady = false;
    }
  }

  Future<void> _showForegroundPush(RemoteMessage message) async {
    final title = message.notification?.title ?? 'Likedin';
    final body = message.notification?.body ?? 'You received a new message.';
    await showMessage(title: title, body: body, id: message.messageId?.hashCode ?? DateTime.now().millisecondsSinceEpoch);
  }

  Future<void> showMessage({required String title, required String body, int? id}) async {
    if (!_localReady) return;
    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        likedinMessageChannelId,
        'Likedin messages',
        channelDescription: 'New messages from your private Likedin conversation',
        importance: Importance.high,
        priority: Priority.high,
        playSound: true,
        sound: RawResourceAndroidNotificationSound('likedin_message'),
        category: AndroidNotificationCategory.message,
      ),
    );
    await _local.show(id ?? DateTime.now().millisecondsSinceEpoch.remainder(100000), title, body, details, payload: jsonEncode({'route': 'chat'}));
  }

  Future<void> cancelIncomingCall(String callId) async {
    if (!_localReady || callId.isEmpty) return;
    await _local.cancel(callId.hashCode);
  }

  Future<void> showMissedCall({required String callId, required bool video}) async {
    if (!_localReady) return;
    const details = NotificationDetails(android: AndroidNotificationDetails(
      likedinCallChannelId, 'Likedin calls', channelDescription: 'Missed call alerts',
      importance: Importance.max, priority: Priority.high, playSound: true,
      sound: RawResourceAndroidNotificationSound('likedin_call'),
      category: AndroidNotificationCategory.missedCall,
    ));
    await _local.show(callId.hashCode, 'Missed ${video ? 'video' : 'audio'} call', 'Your friend tried to reach you.', details,
      payload: jsonEncode({'route':'missed_call','call_id':callId}));
  }

  Future<String?> getPushToken() async {
    if (!_pushReady) return null;
    return FirebaseMessaging.instance.getToken();
  }

  Future<void> registerCurrentToken() async {
    if (!_pushReady) return;
    try {
      final token = await FirebaseMessaging.instance.getToken();
      if (token != null) await _saveToken(token);
    } catch (error) {
      debugPrint('Could not register Likedin push token: $error');
    }
  }

  Future<void> _saveToken(String token) async {
    final client = Supabase.instance.client;
    final user = client.auth.currentUser;
    if (user == null) return;
    await client.from('likedin_push_tokens').upsert({
      'user_id': user.id,
      'token': token,
      'platform': 'android',
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    });
  }
}
