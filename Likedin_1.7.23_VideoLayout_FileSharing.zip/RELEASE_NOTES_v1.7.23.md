# Likedin 1.7.23 — Video layout and file sharing

## Changes
- Updated the connected outgoing video-call screen to use a full-available-area remote video surface with a floating local camera preview and an overlaid contact/status strip.
- Kept the incoming connected video-call screen's full remote-video surface and floating local preview.
- Improved attachment cards in chat with media previews, clearer file-type icons, filename, file size, extension, and download action.
- Raised the per-file upload limit from 25 MB to 50 MB. The limit is enforced by the shared-media upload service after video compression.
- Bumped Android app version to 1.7.23+53.

## Verification
- Source edits and ZIP integrity checked.
- Flutter/Dart SDK is not available in this environment; `flutter analyze`, tests, and Android compilation have not been run.
- Device layout, 50 MB transfer, and Supabase Storage policy limits still require two-device testing.
