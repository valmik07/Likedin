import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { cert, getApps, initializeApp } from "npm:firebase-admin@12.7.0/app";
import { getMessaging } from "npm:firebase-admin@12.7.0/messaging";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-likedin-webhook-secret",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const expected = Deno.env.get("LIKEDIN_PUSH_WEBHOOK_SECRET") ?? "";
  const supplied = req.headers.get("x-likedin-webhook-secret") ?? "";
  if (!expected || supplied.length !== expected.length || supplied !== expected) return new Response("Unauthorized", { status: 401 });

  try {
    const payload = await req.json();
    const row = payload.record ?? payload;
    const callId = String(row.id ?? "");
    const calleeId = String(row.callee_id ?? "");
    const callerId = String(row.caller_id ?? "");
    const callType = row.call_type === "video" ? "video" : "audio";
    const status = String(row.status ?? "");
    if (!callId || !calleeId || !callerId || !["missed", "ended", "rejected"].includes(status)) {
      return new Response("Invalid call terminal record", { status: 400 });
    }

    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false, autoRefreshToken: false } });
    const { data: tokens, error } = await supabase.from("likedin_push_tokens").select("token").eq("user_id", calleeId);
    if (error) throw error;
    if (!tokens?.length) return new Response(JSON.stringify({ sent: 0, reason: "no_tokens" }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const raw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT_JSON");
    if (!raw) throw new Error("FIREBASE_SERVICE_ACCOUNT_JSON secret is missing");
    const account = JSON.parse(raw);
    const app = getApps().length ? getApps()[0] : initializeApp({ credential: cert(account), projectId: account.project_id });
    let sent = 0;
    const invalid: string[] = [];
    const showMissed = status === "missed" || status === "ended";
    const route = showMissed ? "missed_call" : "call_ended";
    const bodyText = `You missed ${callType === "video" ? "a video" : "an audio"} call`;
    for (const item of tokens) {
      try {
        await getMessaging(app).send({
          token: item.token,
          // Data-only is intentional: the background handler must cancel or
          // replace the ongoing incoming-call notification using the same ID.
          data: {
            route,
            call_id: callId,
            caller_id: callerId,
            call_type: callType,
            notification_title: "Likedin",
            notification_body: bodyText,
          },
          android: {
            priority: "high",
            collapseKey: `likedin-call-${callId}`,
          },
        });
        sent++;
      } catch (error) {
        const code = (error as { code?: string }).code ?? "";
        if (code.includes("registration-token-not-registered") || code.includes("invalid-registration-token")) invalid.push(item.token);
        else console.error("Missed-call push failed", code, error);
      }
    }
    if (invalid.length) await supabase.from("likedin_push_tokens").delete().eq("user_id", calleeId).in("token", invalid);
    return new Response(JSON.stringify({ sent, invalid_tokens_removed: invalid.length }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (error) {
    console.error("Missed-call push failed", error);
    return new Response("Missed-call push failed", { status: 500 });
  }
});
