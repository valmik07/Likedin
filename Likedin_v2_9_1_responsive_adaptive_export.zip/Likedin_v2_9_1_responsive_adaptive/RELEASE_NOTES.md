What's New in Likedin v2.9.1+140:

• Full Adaptive Screen Sizing (Tuned for 720p & Modern Displays): Added LikedinResponsive so 720x1544 phones like the Vivo Y12 (360dp native and 320dp zoomed) automatically scale text, chat bubbles, photos, videos, albums, and composer buttons proportionally without looking oversized or cramped.
• Roomier Chat Header on Compact Screens: Automatically tightens header icon spacing and avatar sizing below 380dp so contact names and encryption badges stay readable without cutting off early.
• Non-Overlapping Video Call Top Bar: Scales the floating self-preview to screen width and bounds the top-left timer and network quality pill so they never collide on narrower screens.
• Adaptive Media & Emoji Grids: Switched Files, Contact Info, In-App Gallery, and Emoji/Sticker pickers from fixed column counts to adaptive tile widths that adjust smoothly across portrait and landscape screens.
