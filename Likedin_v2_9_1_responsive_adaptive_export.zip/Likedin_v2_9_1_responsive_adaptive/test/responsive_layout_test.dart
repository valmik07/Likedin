import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/ui/glassmorphism.dart';
import 'package:likedin/utils/responsive_layout.dart';

void main() {
  group('LikedinResponsive screen metrics', () {
    test('scales cleanly across Vivo Y12 zoomed (320dp), Vivo Y12 native (360dp), 1080p (412dp) and landscape', () {
      final y12Zoomed = LikedinResponsive.fromSize(const Size(320, 686));
      final y12Native = LikedinResponsive.fromSize(const Size(360, 772));
      final modern1080p = LikedinResponsive.fromSize(const Size(412, 915));
      final landscape = LikedinResponsive.fromSize(const Size(772, 360));

      expect(y12Zoomed.isUltraCompact, isTrue);
      expect(y12Zoomed.isCompact, isTrue);
      expect(y12Native.isUltraCompact, isFalse);
      expect(y12Native.isCompact, isTrue);
      expect(modern1080p.isCompact, isFalse);
      expect(landscape.isWide, isTrue);
      expect(landscape.isLandscape, isTrue);

      // Automatic text scale trims oversized appearance on 720p phones.
      expect(y12Zoomed.effectiveTextScale(1.0), closeTo(0.88, 0.001));
      expect(y12Native.effectiveTextScale(1.0), closeTo(0.93, 0.001));
      expect(modern1080p.effectiveTextScale(1.0), closeTo(1.00, 0.001));

      // Bubbles and media never overflow narrow Vivo Y12 screens and stay bounded in landscape.
      expect(y12Zoomed.bubbleMaxWidth, lessThan(260));
      expect(y12Native.bubbleMaxWidth, lessThan(290));
      expect(y12Native.mediaWidth, lessThan(y12Native.bubbleMaxWidth));
      expect(landscape.bubbleMaxWidth, 420.0);

      // Video call self-preview leaves generous room for the top-left timer & quality pill.
      expect(y12Zoomed.callSelfPreviewWidth, lessThanOrEqualTo(80));
      expect(y12Native.callSelfPreviewWidth, lessThanOrEqualTo(92));
      expect(y12Zoomed.originIslandMaxWidth, lessThan(300));
    });

    testWidgets('OriginFloatingDock and OriginQuickReactionBar render with zero overflow on 320dp & 360dp Vivo Y12', (tester) async {
      LikedinAppearance.effects.value = LikedinEffects.natural;
      LikedinAppearance.reduceMotion.value = false;

      for (final size in const <Size>[Size(320, 686), Size(360, 772)]) {
        await tester.binding.setSurfaceSize(size);
        addTearDown(() => tester.binding.setSurfaceSize(null));

        await tester.pumpWidget(
          MediaQuery(
            data: MediaQueryData(
              size: size,
              textScaler: TextScaler.linear(
                LikedinResponsive.fromSize(size).effectiveTextScale(1.0),
              ),
            ),
            child: MaterialApp(
              home: Scaffold(
                body: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(12),
                      child: OriginQuickReactionBar(
                        emojis: const ['❤️', '😂', '👍', '😮', '😢', '🔥', '\u{1FAE9}'],
                        onSelectEmoji: (_) {},
                        onMore: () {},
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                      child: OriginFloatingDock(
                        activeTab: 0,
                        onSelect: (_) {},
                        items: const [
                          (tab: 0, icon: Icons.chat_bubble_outline_rounded, activeIcon: Icons.chat_bubble_rounded, label: 'Chats'),
                          (tab: 1, icon: Icons.call_outlined, activeIcon: Icons.call_rounded, label: 'Calls'),
                          (tab: 2, icon: Icons.folder_outlined, activeIcon: Icons.folder_rounded, label: 'Files'),
                          (tab: 3, icon: Icons.person_outline_rounded, activeIcon: Icons.person_rounded, label: 'Profile'),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
        await tester.pumpAndSettle();
        expect(tester.takeException(), isNull);
      }
    });
  });
}
