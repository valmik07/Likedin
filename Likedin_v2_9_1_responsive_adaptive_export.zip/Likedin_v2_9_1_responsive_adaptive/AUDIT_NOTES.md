# Likedin v2.9.1+140 — Responsive Layout & Vivo Y12 Adaptation Log

## New in v2.9.1+140

| Area | Improvement | Files |
| :--- | :--- | :--- |
| **Centralized Responsive Engine** | Added `LikedinResponsive` using `MediaQuery.sizeOf` (zero keyboard-inset rebuilds) with width-aware `autoTextScale` (`0.88x` at `<=340dp`, `0.93x` at `<=375dp`, `1.00x` at `376-430dp`, `1.04x` at `>430dp`) multiplied with the user's in-app Text Size setting. | `lib/utils/responsive_layout.dart`, `lib/main.dart` |
| **Chat Bubbles, Media & Albums** | Replaced hardcoded `310dp` bubble width, `270/300dp` photo/video sizes, and `268dp` album grids with proportional `bubbleMaxWidth`, `mediaWidth`/`mediaHeight`, and `albumWidth`. | `lib/ui/chat_page_part.dart`, `lib/main.dart`, `lib/ui/chat_message_widgets_part.dart` |
| **Chat Header & Composer Density** | Applied compact `VisualDensity`, scaled icons, trimmed avatar radius, and responsive composer buttons on `<380dp` phones (freeing ~48–60dp for contact names on Vivo Y12). | `lib/ui/chat_page_part.dart` |
| **Video Call Overlay Safety** | Scaled self-preview (`callSelfPreviewWidth` x `callSelfPreviewHeight`) and bounded the top-left `_CallPill` against the right preview so timer + quality badge never overlap on 320–360dp screens; scaled audio call halo avatar. | `lib/ui/calls_page_part.dart` |
| **Adaptive Grids & Chrome** | Switched Files, Contact Info, In-App Gallery, and Emoji/Sticker pickers from fixed `crossAxisCount` to `SliverGridDelegateWithMaxCrossAxisExtent`; bounded `OriginIsland` width and adapted `OriginFloatingDock` height on ultra-compact screens. | `lib/ui/settings_page_part.dart`, `lib/ui/chat_info_page.dart`, `lib/ui/in_app_gallery_picker.dart`, `lib/ui/chat_page_part.dart`, `lib/ui/origin_island.dart`, `lib/ui/glassmorphism.dart` |
| **Responsive Tests (22 Suites Total)** | Added `test/responsive_layout_test.dart` exercising Vivo Y12 zoomed (`320x686`), Vivo Y12 native (`360x772`), 1080p (`412x915`), and landscape (`772x360`). | `test/responsive_layout_test.dart` |
