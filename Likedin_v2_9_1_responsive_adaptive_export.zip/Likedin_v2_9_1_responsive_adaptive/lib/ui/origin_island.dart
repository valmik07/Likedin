import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../utils/responsive_layout.dart';
import 'glassmorphism.dart';

/// Transient event displayed inside the OriginOS 7 Origin Island top pill.
class OriginIslandEvent {
  const OriginIslandEvent({
    required this.id,
    required this.title,
    required this.icon,
    required this.accent,
    this.subtitle,
    this.loading = false,
  });

  final String id;
  final String title;
  final String? subtitle;
  final IconData icon;
  final Color accent;
  final bool loading;
}

/// Global controller for transient Origin Island morphing pills (uploads,
/// shares, E2EE status, peer presence pulses). Automatically yields to an
/// active minimized audio call pill whenever a call is running.
class OriginIslandHost {
  OriginIslandHost._();

  static final ValueNotifier<OriginIslandEvent?> current =
      ValueNotifier<OriginIslandEvent?>(null);
  static Timer? _autoClearTimer;

  static void show({
    required String title,
    String? subtitle,
    IconData icon = Icons.auto_awesome_rounded,
    Color accent = const Color(0xFF4FDBA5),
    bool loading = false,
    Duration duration = const Duration(seconds: 3),
  }) {
    _autoClearTimer?.cancel();
    final event = OriginIslandEvent(
      id: 'island-${DateTime.now().microsecondsSinceEpoch}',
      title: title,
      subtitle: subtitle,
      icon: icon,
      accent: accent,
      loading: loading,
    );
    current.value = event;
    if (!loading) {
      _autoClearTimer = Timer(duration, () {
        if (current.value?.id == event.id) {
          current.value = null;
        }
      });
    }
  }

  static void clear() {
    _autoClearTimer?.cancel();
    _autoClearTimer = null;
    current.value = null;
  }
}

/// Animated 4-bar OriginOS audio waveform inside the Origin Island call pill.
class _OriginAudioWaveform extends StatefulWidget {
  const _OriginAudioWaveform({required this.color, required this.active});

  final Color color;
  final bool active;

  @override
  State<_OriginAudioWaveform> createState() => _OriginAudioWaveformState();
}

class _OriginAudioWaveformState extends State<_OriginAudioWaveform>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  );

  @override
  void initState() {
    super.initState();
    _sync();
  }

  void _sync() {
    if (widget.active && !LikedinAppearance.reduceMotion.value) {
      if (!_ctrl.isAnimating) _ctrl.repeat();
    } else {
      if (_ctrl.isAnimating) _ctrl.stop();
      _ctrl.value = 0.25;
    }
  }

  @override
  void didUpdateWidget(covariant _OriginAudioWaveform oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.active != widget.active) _sync();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const phases = <double>[0.0, 0.35, 0.70, 0.20];
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) => Row(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: List.generate(phases.length, (i) {
          final wave = 0.5 + 0.5 * math.sin((_ctrl.value + phases[i]) * 2 * math.pi);
          final h = widget.active ? (5.0 + 11.0 * wave) : 5.0;
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 1.3),
            child: Container(
              width: 2.6,
              height: h,
              decoration: BoxDecoration(
                color: widget.color,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          );
        }),
      ),
    );
  }
}

/// OriginOS 7 Origin Island pill for a minimized audio call.
/// Morphs smoothly into a sleek obsidian-glass capsule at the top center with
/// live waveform bars, timer, and Overlay-safe Mute / Speaker / End controls.
class OriginIslandAudioCall extends StatefulWidget {
  const OriginIslandAudioCall({
    required this.name,
    required this.statusNotifier,
    required this.statusBuilder,
    required this.muted,
    required this.speaker,
    required this.onExpand,
    required this.onToggleMute,
    required this.onToggleSpeaker,
    required this.onEnd,
    super.key,
  });

  final String name;
  final ValueNotifier<int> statusNotifier;
  final String Function(int seconds) statusBuilder;
  final bool muted;
  final bool speaker;
  final VoidCallback onExpand;
  final VoidCallback onToggleMute;
  final VoidCallback onToggleSpeaker;
  final VoidCallback onEnd;

  @override
  State<OriginIslandAudioCall> createState() => _OriginIslandAudioCallState();
}

class _OriginIslandAudioCallState extends State<OriginIslandAudioCall> {
  static const Color _positive = Color(0xFF2FBF86);
  static const Color _danger = Color(0xFFE5484D);
  static const Color _accent = Color(0xFF8DB8FF);

  @override
  Widget build(BuildContext context) {
    final topPad = MediaQuery.paddingOf(context).top;
    final reduced = LikedinAppearance.reduceMotion.value;
    return Positioned(
      left: 14,
      right: 14,
      top: topPad + 6,
      child: Material(
        color: Colors.transparent,
        child: TweenAnimationBuilder<double>(
          tween: Tween<double>(begin: 0.88, end: 1.0),
          duration: reduced ? Duration.zero : const Duration(milliseconds: 260),
          curve: Curves.easeOutBack,
          builder: (_, scale, child) => Transform.scale(scale: scale, child: child),
          child: GestureDetector(
            onTap: widget.onExpand,
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xF0070D14),
                borderRadius: BorderRadius.circular(28),
                border: Border.all(
                  color: _positive.withValues(alpha: .42),
                  width: 1.15,
                ),
                boxShadow: [
                  BoxShadow(
                    color: _positive.withValues(alpha: .22),
                    blurRadius: 18,
                    blurStyle: BlurStyle.outer,
                  ),
                ],
              ),
              padding: const EdgeInsets.fromLTRB(12, 8, 8, 8),
              child: Row(
                children: [
                  Container(
                    width: 34,
                    height: 34,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: _positive.withValues(alpha: .18),
                      shape: BoxShape.circle,
                    ),
                    child: _OriginAudioWaveform(
                      color: _positive,
                      active: !widget.muted,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          widget.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 13.5,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        ValueListenableBuilder<int>(
                          valueListenable: widget.statusNotifier,
                          builder: (_, sec, __) => Text(
                            '${widget.statusBuilder(sec)} · Tap to expand',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: _positive,
                              fontSize: 11.5,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Semantics(
                    button: true,
                    label: widget.muted ? 'Unmute' : 'Mute',
                    child: IconButton(
                      visualDensity: VisualDensity.compact,
                      onPressed: widget.onToggleMute,
                      icon: Icon(
                        widget.muted ? Icons.mic_off_rounded : Icons.mic_rounded,
                        color: widget.muted ? _danger : Colors.white,
                        size: 20,
                      ),
                    ),
                  ),
                  Semantics(
                    button: true,
                    label: widget.speaker ? 'Earpiece' : 'Speaker',
                    child: IconButton(
                      visualDensity: VisualDensity.compact,
                      onPressed: widget.onToggleSpeaker,
                      icon: Icon(
                        widget.speaker ? Icons.volume_up_rounded : Icons.hearing_rounded,
                        color: widget.speaker ? _accent : Colors.white70,
                        size: 20,
                      ),
                    ),
                  ),
                  const SizedBox(width: 2),
                  Material(
                    color: _danger,
                    shape: const CircleBorder(),
                    child: InkWell(
                      customBorder: const CircleBorder(),
                      onTap: widget.onEnd,
                      child: const SizedBox(
                        width: 34,
                        height: 34,
                        child: Icon(Icons.call_end_rounded, color: Colors.white, size: 18),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Morphing top-center Origin Island capsule for transient live app events
/// (uploading media, direct share queued, E2EE verified/changed pulse).
class OriginIslandStatusOverlay extends StatefulWidget {
  const OriginIslandStatusOverlay({
    required this.suppressed,
    super.key,
  });

  final bool suppressed;

  @override
  State<OriginIslandStatusOverlay> createState() => _OriginIslandStatusOverlayState();
}

class _OriginIslandStatusOverlayState extends State<OriginIslandStatusOverlay> {
  double _dragOffsetY = 0.0;

  @override
  Widget build(BuildContext context) {
    if (widget.suppressed) return const SizedBox.shrink();
    return ValueListenableBuilder<OriginIslandEvent?>(
      valueListenable: OriginIslandHost.current,
      builder: (context, event, _) {
        final topPad = MediaQuery.paddingOf(context).top;
        final visible = event != null;
        if (!visible && _dragOffsetY != 0.0) _dragOffsetY = 0.0;
        final reduced = LikedinAppearance.reduceMotion.value;
        final dur = reduced ? Duration.zero : const Duration(milliseconds: 260);
        return Positioned(
          top: topPad + 6,
          left: 24,
          right: 24,
          child: IgnorePointer(
            ignoring: !visible,
            child: Center(
              child: GestureDetector(
                onVerticalDragUpdate: (d) {
                  if (d.delta.dy < 0 || _dragOffsetY < 0) {
                    setState(
                      () => _dragOffsetY = (_dragOffsetY + d.delta.dy).clamp(-48.0, 10.0).toDouble(),
                    );
                  }
                },
                onVerticalDragEnd: (d) {
                  final vel = d.primaryVelocity ?? 0.0;
                  if (_dragOffsetY < -18.0 || vel < -240.0) {
                    setState(() => _dragOffsetY = 0.0);
                    OriginIslandHost.clear();
                  } else {
                    setState(() => _dragOffsetY = 0.0);
                  }
                },
                child: Transform.translate(
                  offset: Offset(0, _dragOffsetY),
                  child: AnimatedSlide(
                    offset: visible ? Offset.zero : const Offset(0, -0.85),
                    duration: dur,
                    curve: Curves.easeOutBack,
                    child: AnimatedOpacity(
                      opacity: visible ? 1.0 : 0.0,
                      duration: dur,
                      child: event == null
                          ? const SizedBox.shrink()
                          : Material(
                              color: Colors.transparent,
                              child: Container(
                                constraints: BoxConstraints(maxWidth: LikedinResponsive.of(context).originIslandMaxWidth),
                                padding: const EdgeInsets.fromLTRB(12, 8, 14, 8),
                                decoration: BoxDecoration(
                                  color: const Color(0xF00A101B),
                                  borderRadius: BorderRadius.circular(26),
                                  border: Border.all(
                                    color: event.accent.withValues(alpha: .46),
                                    width: 1.1,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: event.accent.withValues(alpha: .20),
                                      blurRadius: 16,
                                      blurStyle: BlurStyle.outer,
                                    ),
                                  ],
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    if (event.loading)
                                      SizedBox(
                                        width: 16,
                                        height: 16,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2,
                                          color: event.accent,
                                        ),
                                      )
                                    else
                                      Icon(event.icon, color: event.accent, size: 17),
                                    const SizedBox(width: 9),
                                    Flexible(
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            event.title,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 12.5,
                                              fontWeight: FontWeight.w700,
                                            ),
                                          ),
                                          if (event.subtitle != null && event.subtitle!.isNotEmpty)
                                            Text(
                                              event.subtitle!,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style: TextStyle(
                                                color: Colors.white.withValues(alpha: .72),
                                                fontSize: 11,
                                              ),
                                            ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
