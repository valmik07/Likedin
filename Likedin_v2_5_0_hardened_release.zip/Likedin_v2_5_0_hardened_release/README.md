# Likedin v2.5.0+129 — Audit Hardening, E2EE Identity Verification & Release Safety

## Audit Findings Fixed in v2.5.0+129
1. **E2EE Identity Verification & Key-Change Warnings (100% backward-compatible):**
   - Added explicit `E2eeStatus` states (`pending`, `active`, `verified`, `keyChanged`, `error`), persisted manual fingerprint verification (`Mark as verified`), and persisted peer public-key change detection with a visible warning banner in Chat and Settings.
   - Prevents silent downgrade to plaintext if an already-established E2EE session encounters an error, while preserving planned compatibility mode for peers that have not yet published a key.
2. **E2EE Cloud Backup Migration Included (`supabase/migrations/202611270001_v250_e2ee_keys_table.sql`):**
   - Added idempotent SQL migration creating `public.likedin_e2ee_keys` with pair-member RLS policies.
3. **Propagated Local Media Cache Deletion Failures (`shared_media_service.dart`):**
   - `deleteCachedPath` now throws a `FileSystemException` if any matching cached file fails to delete, so tombstone checkpoint reconciliation retains failed items for retry.
4. **Fail-Closed Android Release Signing (`android/app/build.gradle.kts`):**
   - Release builds no longer silently fall back to debug signing when `android/key.properties` is missing (explicit opt-in `-PallowDebugReleaseSigning=true` is required for non-production local tests).
5. **Updater Reliability & Strict ARM64 Selection (`app_updater.dart`):**
   - Automatic update checks now record the 6-hour cooldown only after a successful check and retry after 15 minutes on network failure.
   - APK selection strictly requires an HTTPS `arm64` / `arm64-v8a` asset and never falls back to an incompatible ABI.
6. **Expanded Test Suite:** Added `test/e2ee_service_test.dart`, `test/app_updater_test.dart`, and `test/shared_media_cleanup_test.dart` (16 test files total).
