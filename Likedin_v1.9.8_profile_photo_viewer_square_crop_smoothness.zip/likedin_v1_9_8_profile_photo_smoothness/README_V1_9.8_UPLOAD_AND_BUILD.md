# Likedin v1.9.8+94 upload and build

1. In the GitHub repository root, remove the previous project ZIP.
2. Upload `Likedin_v1.9.8_profile_photo_viewer_square_crop_smoothness.zip` as the
   only root-level ZIP.
3. Replace the existing workflow under `.github/workflows` with the contents of
   `likedin_workflow_option_A_v1.9.8.yml`.
4. Commit the changes and run **Likedin v1.9.8 Profile Photo and Crop ARM64 APK**.

No GitHub signing secrets are required for the current Option A debug-signing
fallback. Because GitHub-hosted runners are temporary, debug signing identity may
change between runs; do not uninstall the existing app if Android reports a
signature conflict before discussing the error.

This source package preserves the existing features and Supabase backend
contract. No SQL migration is required.
