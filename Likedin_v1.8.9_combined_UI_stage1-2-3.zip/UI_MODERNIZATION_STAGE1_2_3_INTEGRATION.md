# Likedin UI integration — Stage 1 + Stage 2 + Stage 3

Source iteration: **1.8.9+88**

This combined source is based on the supplied Stage 3 source archive and retains the prior Stage 1 and Stage 2 implementation. It does not replace the backend or Supabase migrations.

## Integrated UI

- Stage 1: reusable glass surfaces and aurora backdrop; refreshed Home cards; frosted app header and bottom navigation.
- Stage 2: aurora conversation background, translucent message surfaces, frosted chat header/composer, local text/attachment search, media filters, date range and result count.
- Stage 3: incoming/outgoing/active call presentation and call-history filters/callbacks.

## Regression corrections in this integration

- Call history now follows the app's light/dark preference instead of forcing a dark page while Dark mode is off.
- Call-history filter pills use explicit foreground/background colors, avoiding near-white text on pale pills.
- Call-start cards inherit readable theme-aware text and glass surfaces.
- Chat header and composer now use actual frosted-glass surfaces rather than mostly opaque conventional containers.
- Message bubbles use more translucent tints without adding a blur effect to every message (keeps scrolling cost lower on entry-level phones).
- The account email is single-line with ellipsis; the sign-out control no longer forces the email to wrap awkwardly.
- Reply sending resolves an optimistic message's client ID to the committed database row ID before using it as `reply_to_message_id`; replying to a message that has not committed yet is blocked with a clear prompt.
- The runtime version label and `pubspec.yaml` version are aligned at 1.8.9+88.

## Backend and security scope

- No SQL migration, Edge Function, authentication, RLS, storage, notification, WebRTC signalling/service, encryption, or backup code was intentionally changed.
- No new Flutter dependency was added.
- The reply target resolution uses the existing `messages` table and `client_message_id` field. It does not require a database migration.

## Validation limits

- ZIP integrity and lexical Dart delimiter checks are performed when this archive is assembled.
- This environment does not have the Flutter/Dart SDK, so `flutter analyze`, `flutter test`, and APK compilation are not run here. The GitHub Actions build remains the compile/test gate.

## Device regression checklist

1. Verify Home, chat, Calls, Preferences and Files in both light and dark mode.
2. On Calls, check every filter's contrast, all four filters, empty/error states, refresh, realtime updates and callbacks.
3. On Chat, open search, search text and an attachment filename, test each media filter and inclusive date bounds, and load older messages while filtering.
4. Send a reply to an existing photo and verify both devices show the exact same filename. Also try replying immediately to a just-sent optimistic message; the app should wait for its committed row ID.
5. Confirm the keyboard stays usable, the composer and header remain translucent, and long chat histories scroll smoothly on both Android 11 and Android 16.
6. Confirm the account email truncates cleanly without hiding the sign-out action.
7. Test incoming/outgoing audio and video call flows, call controls, ending a call, repeated calls, notifications and call history.
