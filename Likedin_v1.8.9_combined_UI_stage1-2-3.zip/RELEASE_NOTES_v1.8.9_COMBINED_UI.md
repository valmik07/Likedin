# Likedin 1.8.9+88 — Combined UI and regression fixes

- Integrates Stage 1 Home/glassmorphism, Stage 2 conversation/search and Stage 3 call experience in one source archive.
- Makes call history responsive to the app light/dark preference.
- Replaces low-contrast call filter chips with explicit theme-aware filter pills.
- Applies frosted-glass styling to the chat header and composer while avoiding per-message blur work.
- Prevents account email wrapping into an isolated final character.
- Resolves optimistic message client IDs before storing reply references for text, voice and attachment sends.
- Updates the app version label and package version to 1.8.9+88.

No database migration or third-party dependency was added. Flutter compilation and runtime testing remain pending in GitHub Actions and on both devices.
