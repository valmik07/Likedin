-- Likedin v2.5.0: public X25519 E2EE key exchange & passphrase-encrypted key backup table.
-- Safe and idempotent to run on existing projects. Private keys are NEVER stored in plaintext;
-- `encrypted_key_backup` holds a client-side PBKDF2-HMAC-SHA256 + AES-256-GCM envelope.
begin;

create table if not exists public.likedin_e2ee_keys (
  user_id uuid primary key references auth.users(id) on delete cascade,
  public_key text not null check (length(public_key) between 32 and 128),
  encrypted_key_backup text null check (
    encrypted_key_backup is null or length(encrypted_key_backup) between 32 and 8192
  ),
  updated_at timestamptz not null default now()
);

alter table public.likedin_e2ee_keys enable row level security;
revoke all on table public.likedin_e2ee_keys from public, anon;
grant select, insert, update on table public.likedin_e2ee_keys to authenticated;

drop policy if exists "v250 pair members can read e2ee keys" on public.likedin_e2ee_keys;
create policy "v250 pair members can read e2ee keys"
on public.likedin_e2ee_keys for select to authenticated
using (
  public.likedin_is_pair_member(auth.uid())
  and public.likedin_is_pair_member(user_id)
);

drop policy if exists "v250 pair members can insert own e2ee key" on public.likedin_e2ee_keys;
create policy "v250 pair members can insert own e2ee key"
on public.likedin_e2ee_keys for insert to authenticated
with check (
  auth.uid() = user_id
  and public.likedin_is_pair_member(auth.uid())
);

drop policy if exists "v250 pair members can update own e2ee key" on public.likedin_e2ee_keys;
create policy "v250 pair members can update own e2ee key"
on public.likedin_e2ee_keys for update to authenticated
using (
  auth.uid() = user_id
  and public.likedin_is_pair_member(auth.uid())
)
with check (
  auth.uid() = user_id
  and public.likedin_is_pair_member(auth.uid())
);

commit;
notify pgrst, 'reload schema';
