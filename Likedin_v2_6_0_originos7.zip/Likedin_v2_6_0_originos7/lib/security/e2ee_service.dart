import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../backend/realtime_messaging_service.dart';

/// Explicit E2EE lifecycle state surfaced to the UI so compatibility mode,
/// active encryption, verified identity, key changes, and errors are distinct.
enum E2eeStatus {
  /// Waiting for the paired peer to publish an X25519 public key (compatibility mode).
  pending,

  /// Shared X25519 + AES-256-GCM session active, safety fingerprint not yet verified.
  active,

  /// Shared session active and the current safety fingerprint was manually verified.
  verified,

  /// Peer's public key changed since the last trusted session; review fingerprint.
  keyChanged,

  /// Initialization or cryptographic failure after an established key state.
  error,
}

/// Client-side End-to-End Encryption (X25519 + HKDF-SHA256 + AES-256-GCM)
/// with intentional compatibility-mode plaintext when the peer has not yet
/// updated to a v2.2.0+ build that publishes an X25519 public key.
///
/// Includes identity fingerprint verification, persisted peer key-change
/// detection, fail-closed protection on active-session errors, and a
/// PBKDF2-HMAC-SHA256 + AES-256-GCM recovery passphrase backup.
class E2eeService {
  E2eeService._([FlutterSecureStorage? storage])
      : _storage = storage ?? const FlutterSecureStorage();

  /// Creates an isolated instance backed by [storage] for unit tests.
  @visibleForTesting
  factory E2eeService.forTesting(FlutterSecureStorage storage) =>
      E2eeService._(storage);

  static final E2eeService instance = E2eeService._();

  static const String envelopeMarker = '__likedin_e2ee_v1';
  static const String _backupFormat = 'likedin-e2ee-key-backup-v1';
  static const String _storagePrefix = 'likedin_e2ee_v1';
  // 8-byte magic headers for encrypted media blobs:
  // v1 ("LKE2EE1\0"): single-shot AES-256-GCM
  // v2 ("LKE2EE2\0"): streaming 512 KB chunked AES-256-GCM with chunk-index & finality AAD
  static const List<int> _mediaMagic = <int>[0x4C, 0x4B, 0x45, 0x32, 0x45, 0x45, 0x31, 0x00];
  static const List<int> _mediaMagicV2 = <int>[0x4C, 0x4B, 0x45, 0x32, 0x45, 0x45, 0x32, 0x00];
  static const int _mediaChunkBytes = 512 * 1024;

  final FlutterSecureStorage _storage;
  final X25519 _x25519 = X25519();
  final AesGcm _aesGcm = AesGcm.with256bits();
  final Hkdf _hkdf = Hkdf(hmac: Hmac.sha256(), outputLength: 32);

  final ValueNotifier<bool> activeNotifier = ValueNotifier<bool>(false);
  final ValueNotifier<E2eeStatus> statusNotifier =
      ValueNotifier<E2eeStatus>(E2eeStatus.pending);

  String? _userId;
  String? _peerId;
  List<int>? _privateKeyBytes;
  List<int>? _publicKeyBytes;
  List<int>? _peerPublicKeyBytes;
  SecretKey? _sessionKey;
  String? _safetyFingerprint;
  String? _verifiedFingerprint;
  bool _peerKeyChanged = false;
  bool _hadKnownPeerKey = false;
  String? _lastError;
  bool _cloudTableAvailable = true;

  bool get isActive => _sessionKey != null;
  E2eeStatus get status => statusNotifier.value;
  bool get isVerified =>
      _sessionKey != null &&
      !_peerKeyChanged &&
      _safetyFingerprint != null &&
      _verifiedFingerprint == _safetyFingerprint;
  bool get hasPeerKeyChanged => _peerKeyChanged;
  String? get lastError => _lastError;
  String? get ownPublicKeyBase64 =>
      _publicKeyBytes == null ? null : base64Encode(_publicKeyBytes!);
  String? get safetyFingerprint => _safetyFingerprint;
  bool get cloudBackupSupported => _cloudTableAvailable;

  String _privStorageKey(String uid) => '${_storagePrefix}_priv_$uid';
  String _pubStorageKey(String uid) => '${_storagePrefix}_pub_$uid';
  String _peerPubStorageKey(String uid, String peer) =>
      '${_storagePrefix}_peer_${uid}_$peer';
  String _verifiedFingerprintKey(String uid, String peer) =>
      '${_storagePrefix}_verified_${uid}_$peer';
  String _keyChangedFlagKey(String uid, String peer) =>
      '${_storagePrefix}_key_changed_${uid}_$peer';

  void _syncNotifiers() {
    final active = _sessionKey != null;
    activeNotifier.value = active;
    if (_lastError != null && !active) {
      statusNotifier.value = E2eeStatus.error;
    } else if (!active) {
      statusNotifier.value = E2eeStatus.pending;
    } else if (_peerKeyChanged) {
      statusNotifier.value = E2eeStatus.keyChanged;
    } else if (_safetyFingerprint != null &&
        _verifiedFingerprint == _safetyFingerprint) {
      statusNotifier.value = E2eeStatus.verified;
    } else {
      statusNotifier.value = E2eeStatus.active;
    }
  }

  static bool isEncryptedEnvelope(String text) =>
      text.startsWith('{"$envelopeMarker":');

  /// Loads or generates this user's X25519 key pair, publishes the public key,
  /// and attempts to fetch the peer's public key to derive the shared secret.
  Future<bool> initialize(
    SupabaseClient client, {
    required String userId,
    required String peerId,
  }) async {
    try {
      await _prepareLocalPairContext(userId: userId, peerId: peerId);
      await _publishOwnPublicKey(client, userId);

      // Fetch latest peer public key from Supabase (if table exists and peer published one).
      final remotePeerB64 = await _fetchPeerPublicKey(client, peerId);
      if (remotePeerB64 != null && remotePeerB64.isNotEmpty) {
        await acceptPeerPublicKey(
          remotePeerB64,
          userId: userId,
          peerId: peerId,
        );
      } else if (_peerPublicKeyBytes != null) {
        await _deriveSessionKey();
      } else {
        _lastError = null;
        _syncNotifiers();
      }
      return isActive;
    } catch (error) {
      _lastError = 'Encryption initialization failed. Restart or restore your key in Settings.';
      _sessionKey = null;
      _syncNotifiers();
      debugPrint('E2EE initialize failed: $error');
      rethrow;
    }
  }

  /// Local-only initialization used by unit tests (skips Supabase network calls).
  @visibleForTesting
  Future<bool> initializeLocalForTesting({
    required String userId,
    required String peerId,
  }) async {
    await _prepareLocalPairContext(userId: userId, peerId: peerId);
    if (_peerPublicKeyBytes != null) {
      await _deriveSessionKey();
    } else {
      _lastError = null;
      _syncNotifiers();
    }
    return isActive;
  }

  Future<void> _prepareLocalPairContext({
    required String userId,
    required String peerId,
  }) async {
    if (_userId != userId || _peerId != peerId) {
      _userId = userId;
      _peerId = peerId;
      _privateKeyBytes = null;
      _publicKeyBytes = null;
      _peerPublicKeyBytes = null;
      _sessionKey = null;
      _safetyFingerprint = null;
      _verifiedFingerprint = null;
      _peerKeyChanged = false;
      _hadKnownPeerKey = false;
      _lastError = null;
      _syncNotifiers();
    }

    await _ensureOwnKeyPair(userId);

    // Load persisted verification & key-change state for this pair.
    _verifiedFingerprint =
        await _readSecure(_verifiedFingerprintKey(userId, peerId));
    _peerKeyChanged =
        (await _readSecure(_keyChangedFlagKey(userId, peerId))) == '1';

    // Load any cached peer public key first for instant offline/startup decryption
    // and to detect subsequent key substitution/reinstalls.
    final cachedPeerB64 = await _readSecure(_peerPubStorageKey(userId, peerId));
    if (cachedPeerB64 != null && cachedPeerB64.isNotEmpty) {
      try {
        final bytes = base64Decode(cachedPeerB64);
        if (bytes.length == 32) {
          _peerPublicKeyBytes = bytes;
          _hadKnownPeerKey = true;
        }
      } catch (_) {}
    }
  }

  /// Accepts a peer's 32-byte X25519 public key (from Supabase table or Realtime
  /// broadcast), detects unexpected identity key changes against the previously
  /// stored key, caches the key in secure storage, and derives the shared key.
  Future<bool> acceptPeerPublicKey(
    String publicKeyB64, {
    String? userId,
    String? peerId,
  }) async {
    final uid = userId ?? _userId;
    final pid = peerId ?? _peerId;
    if (uid == null || pid == null) return false;
    final List<int> bytes;
    try {
      bytes = base64Decode(publicKeyB64.trim());
    } on FormatException catch (error) {
      debugPrint('Ignoring malformed peer E2EE public key: $error');
      return false;
    }
    if (bytes.length != 32) return false;

    // Load persisted peer key if memory has not hydrated it yet so we still
    // catch key substitution across cold starts.
    List<int>? previousPeerBytes = _peerPublicKeyBytes;
    if (previousPeerBytes == null) {
      final stored = await _readSecure(_peerPubStorageKey(uid, pid));
      if (stored != null && stored.isNotEmpty) {
        try {
          final decoded = base64Decode(stored);
          if (decoded.length == 32) {
            previousPeerBytes = decoded;
            _hadKnownPeerKey = true;
          }
        } catch (_) {}
      }
    }

    final unchanged = previousPeerBytes != null &&
        _bytesEqual(previousPeerBytes, bytes) &&
        _sessionKey != null;
    if (unchanged) {
      _syncNotifiers();
      return true;
    }

    final keyChanged =
        previousPeerBytes != null && !_bytesEqual(previousPeerBytes, bytes);

    // Persist before updating in-memory state so a storage write failure
    // fails closed rather than activating an unpersisted session key.
    await _writeSecure(_peerPubStorageKey(uid, pid), base64Encode(bytes));
    if (keyChanged) {
      _peerKeyChanged = true;
      _verifiedFingerprint = null;
      await _deleteSecure(_verifiedFingerprintKey(uid, pid));
      await _writeSecure(_keyChangedFlagKey(uid, pid), '1');
    }
    _userId = uid;
    _peerId = pid;
    _peerPublicKeyBytes = bytes;
    _hadKnownPeerKey = true;
    await _ensureOwnKeyPair(uid);
    await _deriveSessionKey();
    return isActive;
  }

  /// Marks the active peer safety fingerprint as manually verified on this
  /// device and clears any pending key-change warning.
  Future<void> markCurrentFingerprintVerified() async {
    final uid = _userId;
    final pid = _peerId;
    final fp = _safetyFingerprint;
    if (uid == null || pid == null || fp == null || !isActive) return;
    await _writeSecure(_verifiedFingerprintKey(uid, pid), fp);
    await _deleteSecure(_keyChangedFlagKey(uid, pid));
    _verifiedFingerprint = fp;
    _peerKeyChanged = false;
    _syncNotifiers();
  }

  /// Clears a verified badge (e.g., if the user wants to re-check in person).
  Future<void> clearFingerprintVerification() async {
    final uid = _userId;
    final pid = _peerId;
    if (uid == null || pid == null) return;
    await _deleteSecure(_verifiedFingerprintKey(uid, pid));
    _verifiedFingerprint = null;
    _syncNotifiers();
  }

  /// Acknowledges a peer key-change warning without marking it verified yet.
  Future<void> acknowledgePeerKeyChange() async {
    final uid = _userId;
    final pid = _peerId;
    if (uid == null || pid == null) return;
    await _deleteSecure(_keyChangedFlagKey(uid, pid));
    _peerKeyChanged = false;
    _syncNotifiers();
  }

  /// Encrypts [plaintext] into an authenticated AES-256-GCM envelope when E2EE
  /// is active with the peer. Falls back to [plaintext] unchanged ONLY in
  /// genuine compatibility mode (peer has never published a key). Refuses to
  /// silently downgrade to plaintext if an established session is in error.
  Future<String> encryptIfReady(String plaintext) async {
    if (plaintext.isEmpty) return plaintext;
    final key = _sessionKey;
    if (key == null) {
      if (_hadKnownPeerKey || statusNotifier.value == E2eeStatus.error) {
        throw StateError(
          'End-to-end encryption session is unavailable. Refusing to send plaintext; open Settings → E2EE to recover.',
        );
      }
      return plaintext;
    }
    // Never double-encrypt an existing envelope.
    if (isEncryptedEnvelope(plaintext)) return plaintext;
    try {
      final nonce = _randomBytes(12);
      final box = await _aesGcm.encrypt(
        utf8.encode(plaintext),
        secretKey: key,
        nonce: nonce,
      );
      return jsonEncode(<String, Object>{
        envelopeMarker: 1,
        'n': base64Encode(box.nonce),
        'c': base64Encode(box.cipherText),
        'm': base64Encode(box.mac.bytes),
      });
    } catch (error) {
      debugPrint('E2EE encryption failed while session is active: $error');
      rethrow;
    }
  }

  /// Decrypts an E2EE envelope back into plaintext. Older unencrypted messages
  /// and media JSON payloads pass through untouched.
  Future<String> decryptIfNeeded(String payload) async {
    if (!isEncryptedEnvelope(payload)) return payload;
    final key = _sessionKey;
    if (key == null) {
      return '🔒 Encrypted message (open Settings → E2EE to sync or restore your key)';
    }
    try {
      final decoded = jsonDecode(payload);
      if (decoded is! Map || decoded[envelopeMarker] != 1) return payload;
      final nonce = base64Decode(decoded['n'].toString());
      final cipherText = base64Decode(decoded['c'].toString());
      final macBytes = base64Decode(decoded['m'].toString());
      final clearBytes = await _aesGcm.decrypt(
        SecretBox(cipherText, nonce: nonce, mac: Mac(macBytes)),
        secretKey: key,
      );
      return utf8.decode(clearBytes);
    } catch (error) {
      debugPrint('E2EE message decryption failed: $error');
      return '🔒 Encrypted message (restore your E2EE recovery key in Settings to read)';
    }
  }

  static bool isEncryptedMediaBytes(Uint8List data) {
    if (data.length < _mediaMagic.length + 12 + 16) return false;
    for (var i = 0; i < _mediaMagic.length; i++) {
      if (data[i] != _mediaMagic[i]) return false;
    }
    return true;
  }

  /// Encrypts raw media bytes with AES-256-GCM when an E2EE session is active
  /// with the peer. Leaves bytes unchanged when the peer has not updated yet
  /// so older app versions remain compatible.
  Future<Uint8List> encryptBytesIfReady(Uint8List plainBytes) async {
    final key = _sessionKey;
    if (key == null || plainBytes.isEmpty || isEncryptedMediaBytes(plainBytes)) {
      return plainBytes;
    }
    final nonce = _randomBytes(12);
    final box = await _aesGcm.encrypt(
      plainBytes,
      secretKey: key,
      nonce: nonce,
    );
    final out = BytesBuilder(copy: false)
      ..add(_mediaMagic)
      ..add(box.nonce)
      ..add(box.cipherText)
      ..add(box.mac.bytes);
    return out.takeBytes();
  }

  /// Decrypts an E2EE media blob back to raw bytes. Legacy unencrypted media
  /// files pass through untouched.
  Future<Uint8List> decryptBytesIfNeeded(Uint8List data) async {
    if (!isEncryptedMediaBytes(data)) return data;
    final key = _sessionKey;
    if (key == null) {
      throw StateError('E2EE session key is unavailable to decrypt this media file.');
    }
    final magicLen = _mediaMagic.length;
    final nonce = data.sublist(magicLen, magicLen + 12);
    final macStart = data.length - 16;
    final cipherText = data.sublist(magicLen + 12, macStart);
    final macBytes = data.sublist(macStart);
    final clear = await _aesGcm.decrypt(
      SecretBox(cipherText, nonce: nonce, mac: Mac(macBytes)),
      secretKey: key,
    );
    return Uint8List.fromList(clear);
  }

  /// Inspects only the first 8 bytes of [file] to determine whether it is an
  /// E2EE media blob (returns 1 for LKE2EE1, 2 for LKE2EE2, or 0 for plain).
  static Future<int> detectEncryptedMediaVersion(File file) async {
    if (!await file.exists()) return 0;
    RandomAccessFile? raf;
    try {
      raf = await file.open(mode: FileMode.read);
      final header = await raf.read(8);
      if (header.length < 8) return 0;
      if (_bytesEqual(header, _mediaMagicV2)) return 2;
      if (_bytesEqual(header, _mediaMagic)) return 1;
      return 0;
    } catch (_) {
      return 0;
    } finally {
      await raf?.close();
    }
  }

  /// Streams [source] into [destination] using 512 KB AES-256-GCM chunks
  /// (LKE2EE2 format) when an E2EE session is active. Returns `false` when the
  /// peer has not published a key yet so older APKs keep receiving plain media.
  /// Peak RAM usage stays ~1 MB even for 50 MB videos.
  Future<bool> encryptFileToDestination(File source, File destination) async {
    final key = _sessionKey;
    if (key == null) {
      if (_hadKnownPeerKey || statusNotifier.value == E2eeStatus.error) {
        throw StateError(
          'End-to-end encryption session is unavailable. Refusing to upload unencrypted media.',
        );
      }
      return false;
    }
    final totalLength = await source.length();
    if (totalLength <= 0) return false;
    if (await detectEncryptedMediaVersion(source) != 0) {
      await source.copy(destination.path);
      return true;
    }

    final part = File('${destination.path}.part');
    RandomAccessFile? reader;
    IOSink? writer;
    try {
      if (await part.exists()) await part.delete();
      reader = await source.open(mode: FileMode.read);
      writer = part.openWrite();
      writer.add(_mediaMagicV2);

      var bytesRead = 0;
      var chunkIndex = 0;
      final lenBuf = ByteData(4);
      while (bytesRead < totalLength) {
        final chunk = await reader.read(_mediaChunkBytes);
        if (chunk.isEmpty) break;
        bytesRead += chunk.length;
        final isFinal = bytesRead >= totalLength;
        final nonce = _randomBytes(12);
        final aad = utf8.encode('likedin-media-v2:$chunkIndex:${isFinal ? 1 : 0}');
        final box = await _aesGcm.encrypt(
          chunk,
          secretKey: key,
          nonce: nonce,
          aad: aad,
        );
        lenBuf.setUint32(0, box.cipherText.length, Endian.big);
        writer.add(lenBuf.buffer.asUint8List());
        writer.add(box.nonce);
        writer.add(box.cipherText);
        writer.add(box.mac.bytes);
        chunkIndex++;
      }
      await writer.flush();
      await writer.close();
      writer = null;
      await reader.close();
      reader = null;
      if (await destination.exists()) await destination.delete();
      await part.rename(destination.path);
      return true;
    } catch (_) {
      try { await writer?.close(); } catch (_) {}
      try { await reader?.close(); } catch (_) {}
      try { if (await part.exists()) await part.delete(); } catch (_) {}
      rethrow;
    }
  }

  /// Decrypts [file] in place if it carries an LKE2EE1 or LKE2EE2 header.
  /// Legacy unencrypted files pass through untouched.
  /// If [requireEncrypted] is true, unencrypted files fail closed.
  Future<void> decryptFileInPlaceIfNeeded(
    File file, {
    bool requireEncrypted = false,
  }) async {
    final version = await detectEncryptedMediaVersion(file);
    if (version == 0) {
      if (requireEncrypted) {
        throw StateError('Expected encrypted media bytes, but received an unencrypted file.');
      }
      return;
    }
    final key = _sessionKey;
    if (key == null) {
      throw StateError('E2EE session key is unavailable to decrypt this media file.');
    }

    final decodedTemp = File('${file.path}.dec');
    RandomAccessFile? reader;
    IOSink? writer;
    try {
      if (await decodedTemp.exists()) await decodedTemp.delete();
      if (version == 1) {
        final encrypted = await file.readAsBytes();
        final plain = await decryptBytesIfNeeded(encrypted);
        await decodedTemp.writeAsBytes(plain, flush: true);
      } else {
        final fileLength = await file.length();
        reader = await file.open(mode: FileMode.read);
        final header = await reader.read(8);
        if (header.length != 8 || !_bytesEqual(header, _mediaMagicV2)) {
          throw StateError('Invalid encrypted media header.');
        }
        writer = decodedTemp.openWrite();
        var readPos = 8;
        var chunkIndex = 0;
        while (readPos < fileLength) {
          final lenBytes = await reader.read(4);
          if (lenBytes.length != 4) {
            throw StateError('Truncated encrypted media chunk length.');
          }
          final cipherLen = ByteData.sublistView(lenBytes).getUint32(0, Endian.big);
          if (cipherLen <= 0 || cipherLen > _mediaChunkBytes + 64) {
            throw StateError('Invalid encrypted media chunk size ($cipherLen).');
          }
          final nonce = await reader.read(12);
          final cipherText = await reader.read(cipherLen);
          final macBytes = await reader.read(16);
          if (nonce.length != 12 || cipherText.length != cipherLen || macBytes.length != 16) {
            throw StateError('Truncated encrypted media chunk body.');
          }
          readPos += 4 + 12 + cipherLen + 16;
          final isFinal = readPos >= fileLength;
          final aad = utf8.encode('likedin-media-v2:$chunkIndex:${isFinal ? 1 : 0}');
          final clear = await _aesGcm.decrypt(
            SecretBox(cipherText, nonce: nonce, mac: Mac(macBytes)),
            secretKey: key,
            aad: aad,
          );
          writer.add(clear);
          chunkIndex++;
        }
        if (chunkIndex == 0) {
          throw StateError('Encrypted media file contains no chunks.');
        }
        await writer.flush();
        await writer.close();
        writer = null;
        await reader.close();
        reader = null;
      }
      await file.delete();
      await decodedTemp.rename(file.path);
    } catch (_) {
      try { await writer?.close(); } catch (_) {}
      try { await reader?.close(); } catch (_) {}
      try { if (await decodedTemp.exists()) await decodedTemp.delete(); } catch (_) {}
      rethrow;
    }
  }

  Future<RemoteMessage> decryptMessage(RemoteMessage message) async {
    if (message.deletedForEveryoneAt != null || !isEncryptedEnvelope(message.text)) {
      return message;
    }
    final clear = await decryptIfNeeded(message.text);
    return RemoteMessage(
      id: message.id,
      clientMessageId: message.clientMessageId,
      senderId: message.senderId,
      recipientId: message.recipientId,
      text: clear,
      createdAt: message.createdAt,
      deliveredAt: message.deliveredAt,
      readAt: message.readAt,
      replyToMessageId: message.replyToMessageId,
      editedAt: message.editedAt,
      deletedForEveryoneAt: message.deletedForEveryoneAt,
      deletedMediaPath: message.deletedMediaPath,
    );
  }

  Future<List<RemoteMessage>> decryptMessages(List<RemoteMessage> list) async {
    if (list.isEmpty) return list;
    final hasEncrypted = list.any((m) => m.deletedForEveryoneAt == null && isEncryptedEnvelope(m.text));
    if (!hasEncrypted) return list;
    return Future.wait(list.map(decryptMessage));
  }

  /// Encrypts this device's X25519 private key with [passphrase] (PBKDF2 100k
  /// + AES-256-GCM) and uploads the encrypted blob to `likedin_e2ee_keys`.
  Future<void> backupKeyWithPassphrase(
    SupabaseClient client,
    String passphrase,
  ) async {
    final uid = client.auth.currentUser?.id ?? _userId;
    if (uid == null) throw StateError('Sign in before backing up your E2EE key.');
    if (passphrase.length < 12) {
      throw StateError('Use a recovery passphrase of at least 12 characters.');
    }
    await _ensureOwnKeyPair(uid);
    final priv = _privateKeyBytes;
    final pub = _publicKeyBytes;
    if (priv == null || pub == null) {
      throw StateError('E2EE key pair is not ready yet.');
    }

    final salt = _randomBytes(16);
    final nonce = _randomBytes(12);
    final wrappingKey = await Pbkdf2(
      macAlgorithm: Hmac.sha256(),
      iterations: 100000,
      bits: 256,
    ).deriveKeyFromPassword(password: passphrase, nonce: salt);

    final box = await _aesGcm.encrypt(
      priv,
      secretKey: wrappingKey,
      nonce: nonce,
    );
    final backupEnvelope = jsonEncode(<String, Object>{
      'format': _backupFormat,
      'iterations': 100000,
      'salt': base64Encode(salt),
      'nonce': base64Encode(box.nonce),
      'cipher': base64Encode(box.cipherText),
      'mac': base64Encode(box.mac.bytes),
    });

    await client.from('likedin_e2ee_keys').upsert(
      <String, Object>{
        'user_id': uid,
        'public_key': base64Encode(pub),
        'encrypted_key_backup': backupEnvelope,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      },
      onConflict: 'user_id',
    );
    _cloudTableAvailable = true;
  }

  /// Downloads and decrypts the user's X25519 private key from Supabase using
  /// [passphrase], saves it in secure storage, and re-derives the session key.
  Future<void> restoreKeyWithPassphrase(
    SupabaseClient client,
    String passphrase,
  ) async {
    final uid = client.auth.currentUser?.id ?? _userId;
    if (uid == null) throw StateError('Sign in before restoring your E2EE key.');
    final row = await client
        .from('likedin_e2ee_keys')
        .select('encrypted_key_backup')
        .eq('user_id', uid)
        .maybeSingle();
    final rawBackup = row?['encrypted_key_backup']?.toString();
    if (rawBackup == null || rawBackup.isEmpty) {
      throw StateError('No E2EE key backup was found for this account.');
    }
    final decoded = jsonDecode(rawBackup);
    if (decoded is! Map || decoded['format'] != _backupFormat) {
      throw StateError('The stored E2EE key backup format is unrecognized.');
    }
    final iterations = (decoded['iterations'] as num?)?.toInt() ?? 100000;
    final salt = base64Decode(decoded['salt'].toString());
    final nonce = base64Decode(decoded['nonce'].toString());
    final cipher = base64Decode(decoded['cipher'].toString());
    final mac = base64Decode(decoded['mac'].toString());

    final wrappingKey = await Pbkdf2(
      macAlgorithm: Hmac.sha256(),
      iterations: iterations,
      bits: 256,
    ).deriveKeyFromPassword(password: passphrase, nonce: salt);

    List<int> privBytes;
    try {
      privBytes = await _aesGcm.decrypt(
        SecretBox(cipher, nonce: nonce, mac: Mac(mac)),
        secretKey: wrappingKey,
      );
    } catch (_) {
      throw StateError('Incorrect recovery passphrase. Your E2EE key was not changed.');
    }
    if (privBytes.length != 32) {
      throw StateError('The restored key data is invalid.');
    }

    final restoredPair = await _x25519.newKeyPairFromSeed(privBytes);
    final restoredPub = await restoredPair.extractPublicKey();
    await _writeSecure(_privStorageKey(uid), base64Encode(privBytes));
    await _writeSecure(_pubStorageKey(uid), base64Encode(restoredPub.bytes));
    _privateKeyBytes = privBytes;
    _publicKeyBytes = restoredPub.bytes;
    await _publishOwnPublicKey(client, uid);
    if (_peerPublicKeyBytes != null) {
      await _deriveSessionKey();
    }
  }

  /// Clears in-memory session state on sign-out without destroying stored keys
  /// (which are scoped by user ID in secure storage).
  void resetMemoryState() {
    _userId = null;
    _peerId = null;
    _privateKeyBytes = null;
    _publicKeyBytes = null;
    _peerPublicKeyBytes = null;
    _sessionKey = null;
    _safetyFingerprint = null;
    _verifiedFingerprint = null;
    _peerKeyChanged = false;
    _hadKnownPeerKey = false;
    _lastError = null;
    _syncNotifiers();
  }

  Future<void> _ensureOwnKeyPair(String uid) async {
    if (_privateKeyBytes != null && _publicKeyBytes != null) return;
    final savedPriv = await _readSecure(_privStorageKey(uid));
    final savedPub = await _readSecure(_pubStorageKey(uid));
    if (savedPriv != null && savedPriv.isNotEmpty && savedPub != null && savedPub.isNotEmpty) {
      try {
        final priv = base64Decode(savedPriv);
        final pub = base64Decode(savedPub);
        if (priv.length == 32 && pub.length == 32) {
          _privateKeyBytes = priv;
          _publicKeyBytes = pub;
          return;
        }
      } catch (_) {}
    }

    final generated = await _x25519.newKeyPair();
    final extractedPriv = await generated.extractPrivateKeyBytes();
    final extractedPub = await generated.extractPublicKey();
    await _writeSecure(_privStorageKey(uid), base64Encode(extractedPriv));
    await _writeSecure(_pubStorageKey(uid), base64Encode(extractedPub.bytes));
    _privateKeyBytes = extractedPriv;
    _publicKeyBytes = extractedPub.bytes;
  }

  Future<void> _publishOwnPublicKey(SupabaseClient client, String uid) async {
    final pub = _publicKeyBytes;
    if (pub == null) return;
    try {
      await client.from('likedin_e2ee_keys').upsert(
        <String, Object>{
          'user_id': uid,
          'public_key': base64Encode(pub),
          'updated_at': DateTime.now().toUtc().toIso8601String(),
        },
        onConflict: 'user_id',
      );
      _cloudTableAvailable = true;
    } catch (error) {
      // If likedin_e2ee_keys has not been created in Supabase yet, fail softly;
      // live Realtime key exchange still works seamlessly between active devices.
      _cloudTableAvailable = false;
      debugPrint('E2EE cloud key publish skipped (table optional): $error');
    }
  }

  Future<String?> _fetchPeerPublicKey(SupabaseClient client, String peerId) async {
    try {
      final row = await client
          .from('likedin_e2ee_keys')
          .select('public_key')
          .eq('user_id', peerId)
          .maybeSingle();
      _cloudTableAvailable = true;
      return row?['public_key']?.toString();
    } catch (error) {
      debugPrint('E2EE peer key lookup skipped (table optional): $error');
      return null;
    }
  }

  Future<void> _deriveSessionKey() async {
    final priv = _privateKeyBytes;
    final pub = _publicKeyBytes;
    final peerPub = _peerPublicKeyBytes;
    if (priv == null || pub == null || peerPub == null) return;

    final localPair = SimpleKeyPairData(
      priv,
      publicKey: SimplePublicKey(pub, type: KeyPairType.x25519),
      type: KeyPairType.x25519,
    );
    final remotePub = SimplePublicKey(peerPub, type: KeyPairType.x25519);
    final sharedSecret = await _x25519.sharedSecretKey(
      keyPair: localPair,
      remotePublicKey: remotePub,
    );

    // Non-empty salt avoids the empty-HMAC-key bug in cryptography 2.7.0.
    final derived = await _hkdf.deriveKey(
      secretKey: sharedSecret,
      nonce: utf8.encode('likedin-e2ee-v1-salt'),
      info: utf8.encode('likedin-e2ee-v1-aes256gcm'),
    );

    // Build a deterministic 6-group safety fingerprint from sorted public keys.
    final keysSorted = <String>[base64Encode(pub), base64Encode(peerPub)]..sort();
    final digest = await Sha256().hash(utf8.encode(keysSorted.join(':')));
    final hex = digest.bytes
        .take(12)
        .map((b) => b.toRadixString(16).padLeft(2, '0').toUpperCase())
        .join();
    final groups = <String>[
      for (var i = 0; i < hex.length; i += 4) hex.substring(i, i + 4),
    ];

    _sessionKey = derived;
    _safetyFingerprint = groups.join(' ');
    _lastError = null;
    _syncNotifiers();
  }

  Future<String?> _readSecure(String key) async {
    try {
      return await _storage.read(key: key);
    } catch (_) {
      return null;
    }
  }

  Future<void> _writeSecure(String key, String value) async {
    await _storage.write(key: key, value: value);
  }

  Future<void> _deleteSecure(String key) async {
    await _storage.delete(key: key);
  }

  static List<int> _randomBytes(int length) {
    final rng = Random.secure();
    return List<int>.generate(length, (_) => rng.nextInt(256), growable: false);
  }

  static bool _bytesEqual(List<int> a, List<int> b) {
    if (a.length != b.length) return false;
    var diff = 0;
    for (var i = 0; i < a.length; i++) {
      diff |= a[i] ^ b[i];
    }
    return diff == 0;
  }
}
