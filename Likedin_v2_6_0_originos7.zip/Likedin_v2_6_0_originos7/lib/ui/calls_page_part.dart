part of '../main.dart';

class CallsPage extends StatefulWidget {
  const CallsPage({super.key});
  @override
  State<CallsPage> createState() => _CallsPageState();
}

class _CallsPageState extends State<CallsPage> {
  Future<List<Map<String, dynamic>>>? _history;
  List<Map<String, dynamic>>? _lastHistory;
  static int _historyChannelGen = 0;
  RealtimeChannel? _channel;
  String _filter = 'All';

  @override
  void initState() {
    super.initState();
    _load();
    _subscribe();
  }

  void _load() {
    _history = _fetch();
  }

  Future<List<Map<String, dynamic>>> _fetch() async {
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (uid == null) return _lastHistory ?? const <Map<String, dynamic>>[];
    final rows = await Supabase.instance.client
        .from('likedin_calls')
        .select()
        .or('caller_id.eq.$uid,callee_id.eq.$uid')
        .order('created_at', ascending: false)
        .limit(100);
    final fetched = rows.map((e) => Map<String, dynamic>.from(e)).toList();
    _lastHistory = fetched;
    return fetched;
  }

  void _subscribe() {
    final client = Supabase.instance.client;
    final uid = client.auth.currentUser?.id;
    if (uid == null) return;
    final gen = ++_historyChannelGen;
    _channel = client
        .channel('likedin-call-history-$uid-$gen')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'likedin_calls',
          callback: (_) {
            if (mounted) setState(_load);
          },
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'likedin_calls',
          callback: (_) {
            if (mounted) setState(_load);
          },
        )
      ..subscribe();
  }

  @override
  void dispose() {
    final c = _channel;
    if (c != null) Supabase.instance.client.removeChannel(c);
    super.dispose();
  }

  String _label(Map<String, dynamic> row, String uid) {
    final outgoing = row['caller_id'] == uid;
    final status = row['status']?.toString() ?? 'ended';
    if (status == 'missed') return outgoing ? 'No answer' : 'Missed call';
    if (status == 'rejected') return outgoing ? 'Declined' : 'You declined';
    if (status == 'failed') return 'Call failed';
    if (status == 'ringing') return 'Ringing';
    if (status == 'accepted' || row['answered_at'] != null) return 'Completed';
    return status == 'ended' ? 'Ended' : status;
  }

  IconData _icon(Map<String, dynamic> row, String uid) {
    if (row['status'] == 'missed' && row['callee_id'] == uid) return Icons.call_missed;
    if (row['caller_id'] == uid) return Icons.call_made;
    return Icons.call_received;
  }

  bool _matchesFilter(Map<String, dynamic> row) {
    switch (_filter) {
      case 'Missed':
        return row['status'] == 'missed';
      case 'Video':
        return row['call_type'] == 'video';
      case 'Audio':
        return row['call_type'] != 'video';
      default:
        return true;
    }
  }

  String _dateLabel(Map<String, dynamic> row) {
    final created = DateTime.tryParse(row['created_at']?.toString() ?? '')?.toLocal();
    if (created == null) return 'Date unavailable';
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final day = DateTime(created.year, created.month, created.day);
    final dayText = day == today
        ? 'Today'
        : day == DateTime(today.year, today.month, today.day - 1)
            ? 'Yesterday'
            : MaterialLocalizations.of(context).formatMediumDate(created);
    final timeText = MaterialLocalizations.of(context).formatTimeOfDay(
      TimeOfDay.fromDateTime(created),
    );
    return '$dayText · $timeText';
  }

  Widget _filterPill(String value, {required Brightness brightness, required Color foreground}) {
    final dark = brightness == Brightness.dark;
    final primary = likedinPrimary(brightness);
    final selected = _filter == value;
    final background = selected
        ? primary.withValues(alpha: dark ? .28 : .16)
        : likedinSurface(brightness).withValues(alpha: dark ? .72 : .80);
    final label = selected ? primary : foreground.withValues(alpha: .86);
    final border = selected
        ? primary.withValues(alpha: dark ? .65 : .48)
        : (dark ? Colors.white.withValues(alpha: .14) : Colors.white.withValues(alpha: .92));

    return Semantics(
      button: true,
      selected: selected,
      label: '$value calls filter',
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(30),
          onTap: () => setState(() => _filter = value),
          child: AnimatedContainer(
            duration: LikedinAppearance.reduceMotion.value
                ? Duration.zero
                : const Duration(milliseconds: 160),
            curve: Curves.easeOut,
            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 9),
            decoration: BoxDecoration(
              color: background,
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: border),
            ),
            child: Text(
              value,
              style: TextStyle(color: label, fontSize: 12, fontWeight: FontWeight.w800),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final uid = Supabase.instance.client.auth.currentUser?.id ?? '';
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    final foreground = likedinOnSurface(brightness);
    final secondary = likedinMutedText(brightness);
    final accent = likedinPrimary(brightness);

    return RefreshIndicator(
      color: accent,
      backgroundColor: likedinSurface(brightness),
      onRefresh: () async {
        if (!mounted) return;
        setState(_load);
        try {
          await _history;
        } catch (error) {
          debugPrint('Call history refresh failed: $error');
        }
      },
      child: FutureBuilder<List<Map<String, dynamic>>>(
        future: _history,
        builder: (context, snapshot) {
          final isLoadingInitial =
              snapshot.connectionState == ConnectionState.waiting && _lastHistory == null;
          final hasInitialError = snapshot.hasError && _lastHistory == null;
          final allRows = snapshot.data ?? _lastHistory ?? const <Map<String, dynamic>>[];
          final rows = allRows.where(_matchesFilter).toList(growable: false);
          final outlineColor = likedinOutline(brightness);
          final rowBg = likedinSurface(brightness).withValues(alpha: dark ? .54 : .82);
          final rimColor = dark
              ? Colors.white.withValues(alpha: .16)
              : Colors.white.withValues(alpha: .95);

          return CustomScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            cacheExtent: LikedinAppearance.isLowRamDevice ? 320 : 560,
            slivers: [
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                sliver: SliverToBoxAdapter(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              'Calls',
                              style: TextStyle(
                                color: foreground,
                                fontSize: 34,
                                fontWeight: FontWeight.w800,
                                letterSpacing: -1.1,
                              ),
                            ),
                          ),
                          IconButton(
                            tooltip: 'Refresh call history',
                            onPressed: () => setState(_load),
                            icon: Icon(Icons.refresh_rounded, color: secondary),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      Row(
                        children: [
                          Expanded(
                            child: _callStartTile(
                              context,
                              icon: Icons.call_rounded,
                              title: 'Voice call',
                              subtitle: 'Audio only',
                              accent: const Color(0xFF32B98D),
                              onTap: () => _showCallSetup(context, video: false),
                            ),
                          ),
                          const SizedBox(width: 11),
                          Expanded(
                            child: _callStartTile(
                              context,
                              icon: Icons.videocam_rounded,
                              title: 'Video call',
                              subtitle: 'Face to face',
                              accent: const Color(0xFF3B9FD0),
                              onTap: () => _showCallSetup(context, video: true),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 26),
                      Text(
                        'Recent',
                        style: TextStyle(
                          color: foreground,
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                          letterSpacing: -.4,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: ['All', 'Missed', 'Video', 'Audio']
                            .map((value) => _filterPill(value, brightness: brightness, foreground: foreground))
                            .toList(),
                      ),
                      const SizedBox(height: 14),
                    ],
                  ),
                ),
              ),
              if (isLoadingInitial)
                SliverPadding(
                  padding: const EdgeInsets.all(34),
                  sliver: SliverToBoxAdapter(
                    child: Center(child: CircularProgressIndicator(color: accent)),
                  ),
                )
              else if (hasInitialError)
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 118),
                  sliver: SliverToBoxAdapter(
                    child: GlassPanel(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        children: [
                          Icon(
                            Icons.cloud_off_rounded,
                            color: dark ? const Color(0xFFFFB4AB) : const Color(0xFFB5473A),
                            size: 30,
                          ),
                          const SizedBox(height: 9),
                          Text('Call history unavailable', style: TextStyle(color: foreground, fontWeight: FontWeight.w700)),
                          const SizedBox(height: 4),
                          Text('Pull down to try again.', style: TextStyle(color: secondary, fontSize: 12)),
                        ],
                      ),
                    ),
                  ),
                )
              else if (allRows.isEmpty)
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 118),
                  sliver: SliverToBoxAdapter(
                    child: GlassPanel(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                      child: Column(
                        children: [
                          Icon(Icons.history_rounded, color: accent, size: 42),
                          const SizedBox(height: 12),
                          Text('No calls yet', style: TextStyle(color: foreground, fontWeight: FontWeight.w800)),
                          const SizedBox(height: 5),
                          Text(
                            'Your recent audio and video calls will appear here.',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: secondary, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              else if (rows.isEmpty)
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 118),
                  sliver: SliverToBoxAdapter(
                    child: GlassPanel(
                      padding: const EdgeInsets.all(22),
                      child: Column(
                        children: [
                          Icon(Icons.filter_list_off_rounded, color: accent, size: 34),
                          const SizedBox(height: 9),
                          Text('Nothing in this filter', style: TextStyle(color: foreground, fontWeight: FontWeight.w700)),
                          const SizedBox(height: 4),
                          Text('Try another call type.', style: TextStyle(color: secondary, fontSize: 12)),
                        ],
                      ),
                    ),
                  ),
                )
              else ...[
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(23, 0, 23, 9),
                  sliver: SliverToBoxAdapter(
                    child: Text(
                      '${rows.length} ${rows.length == 1 ? 'call' : 'calls'}',
                      style: TextStyle(color: secondary, fontSize: 12, fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 118),
                  sliver: SliverList.builder(
                    itemCount: rows.length,
                    itemBuilder: (context, i) {
                      final row = rows[i];
                      final isFirst = i == 0;
                      final isLast = i == rows.length - 1;
                      final missed = row['status'] == 'missed';
                      final outgoing = row['caller_id'] == uid;
                      final isVideo = row['call_type'] == 'video';
                      final peerId = outgoing ? row['callee_id']?.toString() : row['caller_id']?.toString();
                      final answered = DateTime.tryParse(row['answered_at']?.toString() ?? '');
                      final ended = DateTime.tryParse(row['ended_at']?.toString() ?? '');
                      final duration = answered == null || ended == null
                          ? null
                          : ended.difference(answered).inSeconds.clamp(0, 86400);
                      final statusColor = missed
                          ? (dark ? const Color(0xFFFF848B) : const Color(0xFFC43D4A))
                          : row['status'] == 'failed'
                              ? (dark ? const Color(0xFFFFB66D) : const Color(0xFFB96B19))
                              : (dark ? const Color(0xFF72DDB7) : const Color(0xFF208B68));
                      final rowRadius = BorderRadius.vertical(
                        top: Radius.circular(isFirst ? 22 : 0),
                        bottom: Radius.circular(isLast ? 22 : 0),
                      );
                      return RepaintBoundary(
                        child: Container(
                          decoration: BoxDecoration(
                            color: rowBg,
                            borderRadius: rowRadius,
                            border: Border(
                              left: BorderSide(color: rimColor, width: 1),
                              right: BorderSide(color: rimColor, width: 1),
                              top: isFirst ? BorderSide(color: rimColor, width: 1) : BorderSide.none,
                              bottom: isLast ? BorderSide(color: rimColor, width: 1) : BorderSide.none,
                            ),
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                                child: Row(
                                  children: [
                                    Container(
                                      width: 40,
                                      height: 40,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(13),
                                        color: statusColor.withValues(alpha: .16),
                                      ),
                                      child: Icon(
                                        isVideo ? Icons.videocam_rounded : _icon(row, uid),
                                        color: statusColor,
                                        size: 20,
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            '${isVideo ? 'Video' : 'Audio'} · ${_label(row, uid)}',
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                              color: missed ? statusColor : foreground,
                                              fontWeight: FontWeight.w700,
                                              fontSize: 14,
                                            ),
                                          ),
                                          const SizedBox(height: 3),
                                          Text(
                                            '${outgoing ? 'Outgoing' : 'Incoming'} · ${_dateLabel(row)}${duration == null ? '' : ' · ${duration ~/ 60}m ${duration % 60}s'}',
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(color: secondary, fontSize: 12),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: 6),
                                    IconButton(
                                      tooltip: 'Call back',
                                      visualDensity: VisualDensity.compact,
                                      onPressed: peerId == null || peerId.isEmpty
                                          ? null
                                          : () => _showCallSetup(context, video: isVideo, recipientId: peerId),
                                      icon: Icon(Icons.call_rounded, color: accent, size: 20),
                                    ),
                                  ],
                                ),
                              ),
                              if (!isLast)
                                Divider(
                                  height: 1,
                                  indent: 66,
                                  endIndent: 14,
                                  color: outlineColor.withValues(alpha: .65),
                                ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ],
          );
        },
      ),
    );
  }

  Widget _callStartTile(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required Color accent,
    required VoidCallback onTap,
  }) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    final foreground = likedinOnSurface(brightness);
    final secondary = likedinMutedText(brightness);
    return LikedinPressScale(
      child: Semantics(
        button: true,
        label: '$title, $subtitle',
        child: GlassPanel(
          radius: BorderRadius.circular(26),
          glow: true,
          glint: true,
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(22),
              onTap: onTap,
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      accent.withValues(alpha: dark ? .18 : .11),
                      accent.withValues(alpha: 0.0),
                    ],
                  ),
                ),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        color: accent.withValues(alpha: dark ? .22 : .15),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Icon(icon, color: accent, size: 23),
                    ),
                    const SizedBox(height: 16),
                    Text(title, style: TextStyle(color: foreground, fontSize: 16, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 2),
                    Text(subtitle, style: TextStyle(color: secondary, fontSize: 13)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

}

Future<void> _showCallSetup(BuildContext context, {required bool video, String? recipientId}) async {
  final client = Supabase.instance.client;
  final messenger = ScaffoldMessenger.of(context);
  if (LikedinActiveCallHost.isActive) {
    LikedinActiveCallHost.setMinimized(false);
    return;
  }
  if (_globalCallDialogActive) {
    messenger.showSnackBar(const SnackBar(content: Text('A call is already active. Finish it before starting another.')));
    return;
  }
  try {
    final peer = recipientId ?? await client.rpc('likedin_get_peer_id') as String?;
    if (peer == null) {
      messenger.showSnackBar(
        const SnackBar(content: Text('Your friend has not registered yet.')),
      );
      return;
    }
    if (!context.mounted) return;
    if (LikedinActiveCallHost.isActive || _globalCallDialogActive) {
      LikedinActiveCallHost.setMinimized(false);
      return;
    }
    await LikedinActiveCallHost.startOutgoing(peerId: peer, video: video);
  } catch (e) {
    messenger.showSnackBar(const SnackBar(content: Text('Could not start the call. Check your connection and try again.')));
  }
}

class _LiveCallDialog extends StatefulWidget {
  const _LiveCallDialog({
    super.key,
    required this.peerId,
    required this.video,
    this.minimized = false,
    this.onMinimize,
    this.onExpand,
    this.onClose,
  });
  final String peerId;
  final bool video;
  final bool minimized;
  final VoidCallback? onMinimize;
  final VoidCallback? onExpand;
  final VoidCallback? onClose;
  @override
  State<_LiveCallDialog> createState() => _LiveCallDialogState();
}

class _LiveCallDialogState extends State<_LiveCallDialog> {
  late final LikedinCallService call;
  final ProximityCallController proximity = ProximityCallController();
  StreamSubscription<String>? sub;
  Timer? durationTicker;
  Stopwatch? stopwatch;
  String status = 'Preparing call…';
  bool ready = false, failed = false, connected = false;
  final ValueNotifier<int> _elapsedSecondsNotifier = ValueNotifier<int>(0);
  String peerDisplayName = 'Likedin contact';

  void _closeOverlay() {
    if (!mounted) return;
    final close = widget.onClose;
    if (close != null) {
      close();
    } else if (Navigator.of(context).canPop()) {
      Navigator.of(context).pop();
    }
  }

  @override
  void initState() {
    super.initState();
    LikedinActiveCallHost._onBackPressed = _handleBackOrMinimize;
    LikedinActiveCallHost._onEndCall = _handleEndCall;
    _loadPeerDisplayName();
    _start();
  }

  @override
  void didUpdateWidget(covariant _LiveCallDialog oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.minimized != widget.minimized && !widget.video && connected) {
      unawaited(proximity.update(
        active: !widget.minimized,
        enabled: !widget.minimized && !call.speaker,
      ));
    }
  }

  Future<void> _loadPeerDisplayName() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getString('likedIn_nickname_${widget.peerId}');
      if (saved != null && saved.trim().isNotEmpty) {
        if (mounted) setState(() => peerDisplayName = saved.trim());
        return;
      }
      final row = await Supabase.instance.client.from('profiles')
          .select('display_name').eq('user_id', widget.peerId).maybeSingle();
      final name = row?['display_name']?.toString().trim();
      if (mounted && name != null && name.isNotEmpty) setState(() => peerDisplayName = name);
    } catch (error) {
      debugPrint('Call peer-name lookup deferred: $error');
    }
  }

  Future<void> _start() async {
    call = LikedinCallService(Supabase.instance.client);
    try {
      await call.initialize(withVideo: widget.video);
      sub = call.changes.listen((v) {
        if (!mounted) return;
        final nowConnected = v == 'connected';
        if (nowConnected && !connected) {
          connected = true;
          if (widget.video) {
            unawaited(_callAlertsMethodChannel
                .invokeMethod<bool>('setVideoCallActive', const {'active': true})
                .catchError((Object _) => false));
          }
          stopwatch = Stopwatch()..start();
          durationTicker?.cancel();
          durationTicker = Timer.periodic(const Duration(seconds: 1), (_) {
            if (mounted && stopwatch != null) {
              _elapsedSecondsNotifier.value = stopwatch!.elapsed.inSeconds;
            }
          });
        }
        setState(() {
          status = v;
          if (v.startsWith('failed') || v.startsWith('error:')) failed = true;
        });
        if (v == 'connected') {
          proximity.update(
            active: !widget.video && !widget.minimized,
            enabled: !widget.video && !widget.minimized && !call.speaker,
          );
        }
        if (v == 'ended' ||
            v == 'missed' ||
            v == 'rejected' ||
            v.startsWith('failed') ||
            v.startsWith('error:')) {
          Future<void>.delayed(const Duration(milliseconds: 900), () {
            _closeOverlay();
          });
        }
      });
      await call.start(widget.peerId, withVideo: widget.video);
      if (mounted) setState(() => ready = true);
    } catch (e) {
      if (mounted) {
        setState(() {
          status = 'Call connection failed';
          failed = true;
        });
      }
    }
  }

  Future<void> _toggleSpeaker() async {
    await call.toggleSpeaker();
    await proximity.update(
      active: connected && !widget.video && !widget.minimized,
      enabled: connected && !widget.video && !widget.minimized && !call.speaker,
    );
    if (mounted) setState(() {});
  }

  String _formatDuration(int seconds) =>
      '${(seconds ~/ 60).toString().padLeft(2, '0')}:${(seconds % 60).toString().padLeft(2, '0')}';

  String _statusLabelFor(int seconds) {
    final v = status.toLowerCase().trim();
    if (v.startsWith('failed') || v.startsWith('error')) return 'Call connection failed';
    if (v == 'disconnected' || v.contains('disconnected')) return 'Reconnecting…';
    if (v == 'ringing' || v == 'ring') return 'Ringing…';
    if (v == 'ended' || v == 'closed') return 'Call ended';
    if (v == 'missed') return 'Missed call';
    if (v == 'rejected') return 'Call declined';
    if (connected || v == 'connected') return _formatDuration(seconds);
    if (v.contains('offer') || v.contains('connecting') || v.contains('preparing') || v.contains('calling')) {
      return 'Calling…';
    }
    return 'Connecting…';
  }

  @override
  void dispose() {
    if (identical(LikedinActiveCallHost._onBackPressed, _handleBackOrMinimize)) {
      LikedinActiveCallHost._onBackPressed = null;
    }
    if (identical(LikedinActiveCallHost._onEndCall, _handleEndCall)) {
      LikedinActiveCallHost._onEndCall = null;
    }
    if (widget.video) {
      unawaited(_callAlertsMethodChannel
          .invokeMethod<bool>('setVideoCallActive', const {'active': false})
          .catchError((Object _) => false));
    }
    durationTicker?.cancel();
    stopwatch?.stop();
    _elapsedSecondsNotifier.dispose();
    proximity.dispose();
    sub?.cancel();
    call.close();
    super.dispose();
  }

  bool _handlingBack = false;

  void _handleBackOrMinimize() {
    if (!failed && widget.onMinimize != null) {
      widget.onMinimize!();
      return;
    }
    unawaited(_handleEndCall());
  }

  Future<void> _handleEndCall() async {
    if (_handlingBack) return;
    _handlingBack = true;
    try {
      try { await call.end(); } catch (error) {
        debugPrint('Call termination failed; closing the call screen anyway: $error');
      }
    } finally {
      _closeOverlay();
      _handlingBack = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final inPip = MediaQuery.sizeOf(context).width < 260;
    if (inPip && widget.video && connected) {
      return Positioned.fill(
        child: Material(
          color: _callBackground,
          child: RTCVideoView(
            call.remoteRenderer,
            objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
          ),
        ),
      );
    }
    if (widget.minimized) {
      if (widget.video) {
        return _MinimizedVideoCallBubble(
          remoteRenderer: call.remoteRenderer,
          localRenderer: call.localRenderer,
          mirrorLocal: call.usingFrontCamera,
          cameraOn: call.camera,
          muted: call.muted,
          connected: connected,
          statusNotifier: _elapsedSecondsNotifier,
          statusBuilder: _statusLabelFor,
          onExpand: () => widget.onExpand?.call(),
          onToggleMute: () async {
            if (!ready) return;
            await call.toggleMute();
            if (mounted) setState(() {});
          },
          onEnd: () => unawaited(_handleEndCall()),
        );
      }
      return _MinimizedAudioCallBar(
        name: peerDisplayName,
        statusNotifier: _elapsedSecondsNotifier,
        statusBuilder: _statusLabelFor,
        muted: call.muted,
        speaker: call.speaker,
        onExpand: () => widget.onExpand?.call(),
        onToggleMute: () async {
          if (!ready) return;
          await call.toggleMute();
          if (mounted) setState(() {});
        },
        onToggleSpeaker: () {
          if (ready) unawaited(_toggleSpeaker());
        },
        onEnd: () => unawaited(_handleEndCall()),
      );
    }

    final title = connected
        ? 'In ${widget.video ? 'video' : 'audio'} call'
        : (widget.video ? 'Video call' : 'Audio call');
    final controlsWrap = Wrap(
      alignment: WrapAlignment.center,
      crossAxisAlignment: WrapCrossAlignment.center,
      spacing: 8,
      runSpacing: 18,
      children: [
        _callControl(
          call.muted ? Icons.mic_off_rounded : Icons.mic_rounded,
          call.muted ? 'Unmute' : 'Mute',
          ready
              ? () async {
                  await call.toggleMute();
                  if (mounted) setState(() {});
                }
              : null,
          active: call.muted,
        ),
        _callControl(
          call.speaker ? Icons.volume_up_rounded : Icons.hearing_rounded,
          call.speaker ? 'Speaker' : 'Earpiece',
          ready ? _toggleSpeaker : null,
          active: call.speaker,
        ),
        if (widget.video)
          _callControl(
            call.camera ? Icons.videocam_rounded : Icons.videocam_off_rounded,
            'Camera',
            ready
                ? () async {
                    await call.toggleCamera();
                    if (mounted) setState(() {});
                  }
                : null,
            active: !call.camera,
          ),
        if (widget.video)
          _callControl(Icons.cameraswitch_rounded, 'Flip', ready ? call.switchCamera : null),
      ],
    );

    return Positioned.fill(
      child: Material(
        color: _callBackground,
        child: widget.video && connected
            ? Builder(builder: (context) {
                final inPip = MediaQuery.sizeOf(context).width < 260;
                return Stack(
                fit: StackFit.expand,
                children: [
                  RTCVideoView(
                    call.remoteRenderer,
                    objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                  ),
                  if (!inPip) ...[
                  // Subtle top scrim for status pill legibility.
                  Positioned(
                    left: 0,
                    right: 0,
                    top: 0,
                    height: 110,
                    child: IgnorePointer(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.black.withValues(alpha: .55),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  // Subtle bottom scrim for floating call controls.
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    height: 220,
                    child: IgnorePointer(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            colors: [
                              Colors.black.withValues(alpha: .72),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  // Floating top-left status & timer pill.
                  Positioned(
                    left: 16,
                    top: MediaQuery.paddingOf(context).top + 12,
                    child: _CallPill(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 7,
                            height: 7,
                            decoration: const BoxDecoration(
                              color: _callPositive,
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 8),
                          ValueListenableBuilder<int>(
                            valueListenable: _elapsedSecondsNotifier,
                            builder: (_, seconds, __) => Text(
                              _statusLabelFor(seconds),
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                            ),
                          ),
                          const SizedBox(width: 8),
                          if (widget.onMinimize != null)
                            Semantics(
                              button: true,
                              label: 'Minimize call',
                              child: InkWell(
                                borderRadius: BorderRadius.circular(14),
                                onTap: widget.onMinimize,
                                child: const Padding(
                                  padding: EdgeInsets.all(3),
                                  child: Icon(
                                    Icons.keyboard_arrow_down_rounded,
                                    color: Colors.white,
                                    size: 20,
                                  ),
                                ),
                              ),
                            ),
                          const SizedBox(width: 2),
                          Semantics(
                            button: true,
                            label: 'Picture in picture',
                            child: InkWell(
                              borderRadius: BorderRadius.circular(14),
                              onTap: () => unawaited(_callAlertsMethodChannel
                                  .invokeMethod<bool>('enterPipMode')
                                  .catchError((Object _) => false)),
                              child: const Padding(
                                padding: EdgeInsets.all(2),
                                child: Icon(
                                  Icons.picture_in_picture_alt_rounded,
                                  color: Colors.white70,
                                  size: 17,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  // Floating top-right self preview.
                  Positioned(
                    right: 16,
                    top: MediaQuery.paddingOf(context).top + 12,
                    width: 108,
                    height: 148,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(18),
                      child: Container(
                        decoration: BoxDecoration(
                          color: _callPanel,
                          border: Border.all(color: Colors.white24),
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: RTCVideoView(
                          call.localRenderer,
                          mirror: call.usingFrontCamera,
                          objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                        ),
                      ),
                    ),
                  ),
                  // Floating bottom controls over full-screen video.
                  Positioned(
                    left: 16,
                    right: 16,
                    bottom: MediaQuery.paddingOf(context).bottom + 20,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        controlsWrap,
                        const SizedBox(height: 18),
                        _incomingCallAction(
                          icon: Icons.call_end_rounded,
                          label: failed ? 'Close' : 'End call',
                          color: _callDanger,
                          onTap: _handleEndCall,
                        ),
                      ],
                    ),
                  ),
                  ],
                ],
              );
              })
            : SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(24, 8, 24, 28),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          if (widget.onMinimize != null && !failed)
                            TextButton.icon(
                              onPressed: widget.onMinimize,
                              style: TextButton.styleFrom(
                                foregroundColor: Colors.white,
                                backgroundColor: Colors.white.withValues(alpha: .10),
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              ),
                              icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 20),
                              label: const Text('Minimize', style: TextStyle(fontSize: 13)),
                            )
                          else
                            Semantics(
                              button: true,
                              label: 'Close',
                              child: IconButton(
                                onPressed: _handleEndCall,
                                icon: const Icon(Icons.close_rounded, color: Colors.white70, size: 24),
                              ),
                            ),
                          const Spacer(),
                          Icon(
                            widget.video ? Icons.videocam_rounded : Icons.call_rounded,
                            color: _callMuted,
                            size: 22,
                          ),
                          const SizedBox(width: 12),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Expanded(
                        child: Center(
                          child: SingleChildScrollView(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                _CallHaloAvatar(
                                  icon: Icons.person_rounded,
                                  size: 132,
                                  animate: !connected && !failed,
                                ),
                                const SizedBox(height: 28),
                                Text(
                                  peerDisplayName,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 30,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: -.8,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  title,
                                  style: const TextStyle(color: _callMuted, fontSize: 16),
                                ),
                                const SizedBox(height: 20),
                                ValueListenableBuilder<int>(
                                  valueListenable: _elapsedSecondsNotifier,
                                  builder: (_, seconds, __) => _CallStatusLine(
                                    text: _statusLabelFor(seconds),
                                    color: failed
                                        ? const Color(0xFFFF7C83)
                                        : connected
                                            ? _callPositive
                                            : _callAccent,
                                  ),
                                ),
                                if (failed)
                                  const Padding(
                                    padding: EdgeInsets.only(top: 14),
                                    child: Text(
                                      'Call connection failed. Check your connection and try again.',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(color: Color(0xFFFFB4AB), fontSize: 13),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),
                      controlsWrap,
                      const SizedBox(height: 22),
                      _incomingCallAction(
                        icon: Icons.call_end_rounded,
                        label: failed ? 'Close' : 'End call',
                        color: _callDanger,
                        onTap: _handleEndCall,
                      ),
                    ],
                  ),
                ),
              ),
      ),
    );
  }

  Widget _callControl(
    IconData icon,
    String label,
    VoidCallback? action, {
    bool active = false,
  }) =>
      _CallRoundButton(icon: icon, label: label, active: active, onPressed: action);
}

