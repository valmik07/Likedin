# Likedin v2.6.0+130 — OriginOS 7 Edition

## What's New in v2.6.0+130
1. **OriginOS 7 Glass Material System (`Real` / `Natural` / `Soft` / `Off`):**
   - **Real:** Crisp translucent glass with live backdrop blur on floating bars, bright specular rims, and vivid ambient orbs (automatic default on 4+ GB RAM phones).
   - **Natural:** Clear translucent glass sheen & crisp rims with zero live blur cost (automatic default on 3 GB RAM / Android 11 phones).
   - **Soft:** Low-glare matte satin finish tuned for calm night optics.
   - **Off:** Solid high-contrast surfaces.
2. **Origin Island (`lib/ui/origin_island.dart`):**
   - Morphing top-center obsidian glass capsule for minimized audio calls (with animated 4-bar live waveform, timer, Mute / Speaker / End controls, tap-to-expand) and live transient events (background media upload/sent, E2EE identity verified).
3. **OriginOS 7 Glint Light Effect (`MainActivity.kt` + `OriginGlintController`):**
   - Angle-responsive iridescent light beam driven by Android's native accelerometer (low-pass smoothed, 25 Hz throttled, auto-paused in background, zero new packages, auto-off on 3 GB RAM phones, toggleable in Appearance).
4. **Fluid Motion Spring Physics & Elastic Dock (`OriginFloatingDock` + `LikedinPressScale`):**
   - Real `SpringSimulation` squish-and-rebound physics with subtle Dynamic Glow touch highlights on press, plus a gliding, velocity-stretching Liquid Glass pill in the floating bottom dock.
5. **Immersive Day/Night Lighting & Bento Squircles:**
   - Subtle daytime/nighttime luminosity adaptation across all 7 themes + Glint hero cards on Home, Calls, Profile, Sign-In, and Appearance.
6. **Hardened SQL Migration:**
   - Added explicit `REVOKE` / `GRANT` statements to `supabase/migrations/202611270001_v250_e2ee_keys_table.sql`.
