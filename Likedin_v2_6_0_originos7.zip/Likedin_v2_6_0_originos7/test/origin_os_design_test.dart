import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:likedin/ui/glassmorphism.dart';
import 'package:likedin/ui/origin_island.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('OriginOS 7 defaults to Real + Glint on 4+ GB devices and Natural + no Glint on 3 GB phones', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await LikedinAppearance.load(null, false);
    expect(LikedinAppearance.effects.value, LikedinEffects.real);
    expect(LikedinAppearance.glintEnabled.value, isTrue);

    SharedPreferences.setMockInitialValues(<String, Object>{});
    await LikedinAppearance.load(null, true);
    expect(LikedinAppearance.effects.value, LikedinEffects.natural);
    expect(LikedinAppearance.glintEnabled.value, isFalse);
  });

  test('All 4 OriginOS 7 glass textures persist and expose readable labels', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    for (final texture in LikedinEffects.values) {
      await LikedinAppearance.setEffects(texture);
      expect(LikedinAppearance.effects.value, texture);
      expect(LikedinAppearance.textureLabel.isNotEmpty, isTrue);
    }
    await LikedinAppearance.reset();
  });

  test('OriginIslandHost shows and clears live events cleanly', () {
    OriginIslandHost.clear();
    expect(OriginIslandHost.current.value, isNull);

    OriginIslandHost.show(
      title: 'Sending media…',
      loading: true,
      icon: Icons.cloud_upload_rounded,
      accent: const Color(0xFF4FDBA5),
    );
    expect(OriginIslandHost.current.value?.title, 'Sending media…');
    expect(OriginIslandHost.current.value?.loading, isTrue);

    OriginIslandHost.clear();
    expect(OriginIslandHost.current.value, isNull);
  });
}
