import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/utils/app_updater.dart';

void main() {
  group('AppUpdater.selectArm64ApkUrl', () {
    test('selects strict HTTPS arm64 APK and ignores non-ARM64 assets', () {
      final url = AppUpdater.selectArm64ApkUrl([
        {
          'name': 'likedin-armeabi-v7a-v2.5.0.apk',
          'browser_download_url': 'https://example.com/v7a.apk',
        },
        {
          'name': 'likedin-x86_64-v2.5.0.apk',
          'browser_download_url': 'https://example.com/x86.apk',
        },
        {
          'name': 'likedin-arm64-v2.5.0+129.apk',
          'browser_download_url': 'https://example.com/arm64.apk',
        },
      ]);
      expect(url, 'https://example.com/arm64.apk');
    });

    test('returns null instead of falling back to incompatible or non-HTTPS APK', () {
      expect(
        AppUpdater.selectArm64ApkUrl([
          {
            'name': 'likedin-universal-debug.apk',
            'browser_download_url': 'https://example.com/universal.apk',
          },
          {
            'name': 'likedin-arm64-v2.5.0.apk',
            'browser_download_url': 'http://insecure.example.com/arm64.apk',
          },
        ]),
        isNull,
      );
    });
  });

  group('AppUpdater.shouldRunAutomaticCheck', () {
    test('throttles successful checks for 6 hours but retries failed checks after 15 minutes', () {
      const now = 1000 * 60 * 60 * 24;
      // 1 hour after success -> skip
      expect(
        AppUpdater.shouldRunAutomaticCheck(
          nowMs: now,
          lastSuccessMs: now - const Duration(hours: 1).inMilliseconds,
          lastFailureMs: 0,
        ),
        isFalse,
      );
      // 7 hours after success -> run
      expect(
        AppUpdater.shouldRunAutomaticCheck(
          nowMs: now,
          lastSuccessMs: now - const Duration(hours: 7).inMilliseconds,
          lastFailureMs: 0,
        ),
        isTrue,
      );
      // 5 minutes after failure -> wait
      expect(
        AppUpdater.shouldRunAutomaticCheck(
          nowMs: now,
          lastSuccessMs: 0,
          lastFailureMs: now - const Duration(minutes: 5).inMilliseconds,
        ),
        isFalse,
      );
      // 16 minutes after failure -> retry
      expect(
        AppUpdater.shouldRunAutomaticCheck(
          nowMs: now,
          lastSuccessMs: 0,
          lastFailureMs: now - const Duration(minutes: 16).inMilliseconds,
        ),
        isTrue,
      );
    });
  });

  test('isNewerVersion compares semver and build numbers accurately', () {
    expect(AppUpdater.isNewerVersion('2.5.0+129', '2.4.3+128'), isTrue);
    expect(AppUpdater.isNewerVersion('v2.5.0+130', '2.5.0+129'), isTrue);
    expect(AppUpdater.isNewerVersion('2.5.0+129', '2.5.0+129'), isFalse);
    expect(AppUpdater.isNewerVersion('2.4.3+128', '2.5.0+129'), isFalse);
  });
}
