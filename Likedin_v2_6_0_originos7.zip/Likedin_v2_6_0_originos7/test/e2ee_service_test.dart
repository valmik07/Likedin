import 'dart:io';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/security/e2ee_service.dart';

class _MemorySecureStorage extends FlutterSecureStorage {
  final Map<String, String> values = <String, String>{};

  @override
  Future<String?> read({
    required String key,
    IOSOptions? iOptions,
    AndroidOptions? aOptions,
    LinuxOptions? lOptions,
    WebOptions? webOptions,
    MacOsOptions? mOptions,
    WindowsOptions? wOptions,
  }) async =>
      values[key];

  @override
  Future<void> write({
    required String key,
    required String? value,
    IOSOptions? iOptions,
    AndroidOptions? aOptions,
    LinuxOptions? lOptions,
    WebOptions? webOptions,
    MacOsOptions? mOptions,
    WindowsOptions? wOptions,
  }) async {
    if (value == null) {
      values.remove(key);
    } else {
      values[key] = value;
    }
  }

  @override
  Future<void> delete({
    required String key,
    IOSOptions? iOptions,
    AndroidOptions? aOptions,
    LinuxOptions? lOptions,
    WebOptions? webOptions,
    MacOsOptions? mOptions,
    WindowsOptions? wOptions,
  }) async {
    values.remove(key);
  }

  @override
  Future<Map<String, String>> readAll({
    IOSOptions? iOptions,
    AndroidOptions? aOptions,
    LinuxOptions? lOptions,
    WebOptions? webOptions,
    MacOsOptions? mOptions,
    WindowsOptions? wOptions,
  }) async =>
      Map<String, String>.of(values);
}

void main() {
  test('stays in pending compatibility mode until peer publishes key, then encrypts & decrypts', () async {
    final aliceStorage = _MemorySecureStorage();
    final bobStorage = _MemorySecureStorage();
    final alice = E2eeService.forTesting(aliceStorage);
    final bob = E2eeService.forTesting(bobStorage);

    expect(await alice.initializeLocalForTesting(userId: 'alice', peerId: 'bob'), isFalse);
    expect(alice.status, E2eeStatus.pending);
    expect(await alice.encryptIfReady('hello legacy'), 'hello legacy');

    await bob.initializeLocalForTesting(userId: 'bob', peerId: 'alice');
    expect(await alice.acceptPeerPublicKey(bob.ownPublicKeyBase64!), isTrue);
    expect(await bob.acceptPeerPublicKey(alice.ownPublicKeyBase64!), isTrue);

    expect(alice.status, E2eeStatus.active);
    expect(bob.status, E2eeStatus.active);
    expect(alice.safetyFingerprint, isNotNull);
    expect(alice.safetyFingerprint, bob.safetyFingerprint);

    final cipher = await alice.encryptIfReady('secret message');
    expect(E2eeService.isEncryptedEnvelope(cipher), isTrue);
    expect(await bob.decryptIfNeeded(cipher), 'secret message');
  });

  test('verifying fingerprint persists and peer key rotation triggers persisted keyChanged warning', () async {
    final aliceStorage = _MemorySecureStorage();
    final bobStorage1 = _MemorySecureStorage();
    final bobStorage2 = _MemorySecureStorage();

    final alice = E2eeService.forTesting(aliceStorage);
    final bobOld = E2eeService.forTesting(bobStorage1);
    final bobNew = E2eeService.forTesting(bobStorage2);

    await alice.initializeLocalForTesting(userId: 'alice', peerId: 'bob');
    await bobOld.initializeLocalForTesting(userId: 'bob', peerId: 'alice');
    await bobNew.initializeLocalForTesting(userId: 'bob', peerId: 'alice');

    await alice.acceptPeerPublicKey(bobOld.ownPublicKeyBase64!);
    await alice.markCurrentFingerprintVerified();
    expect(alice.status, E2eeStatus.verified);
    expect(alice.isVerified, isTrue);

    // Simulate cold restart: verified state is preserved.
    final aliceRestarted = E2eeService.forTesting(aliceStorage);
    await aliceRestarted.initializeLocalForTesting(userId: 'alice', peerId: 'bob');
    expect(aliceRestarted.status, E2eeStatus.verified);

    // Peer reinstalls with a new key: verification clears and keyChanged fires.
    await aliceRestarted.acceptPeerPublicKey(bobNew.ownPublicKeyBase64!);
    expect(aliceRestarted.status, E2eeStatus.keyChanged);
    expect(aliceRestarted.hasPeerKeyChanged, isTrue);
    expect(aliceRestarted.isVerified, isFalse);

    // Warning persists across restarts until acknowledged or re-verified.
    final aliceAfterRestart2 = E2eeService.forTesting(aliceStorage);
    await aliceAfterRestart2.initializeLocalForTesting(userId: 'alice', peerId: 'bob');
    expect(aliceAfterRestart2.status, E2eeStatus.keyChanged);

    await aliceAfterRestart2.acknowledgePeerKeyChange();
    expect(aliceAfterRestart2.status, E2eeStatus.active);
    await aliceAfterRestart2.markCurrentFingerprintVerified();
    expect(aliceAfterRestart2.status, E2eeStatus.verified);
  });

  test('chunked file encryption round-trips cleanly when E2EE is active', () async {
    final alice = E2eeService.forTesting(_MemorySecureStorage());
    final bob = E2eeService.forTesting(_MemorySecureStorage());
    await alice.initializeLocalForTesting(userId: 'alice', peerId: 'bob');
    await bob.initializeLocalForTesting(userId: 'bob', peerId: 'alice');
    await alice.acceptPeerPublicKey(bob.ownPublicKeyBase64!);
    await bob.acceptPeerPublicKey(alice.ownPublicKeyBase64!);

    final tmp = await Directory.systemTemp.createTemp('likedin_e2ee_file_');
    addTearDown(() => tmp.delete(recursive: true));
    final plain = File('${tmp.path}/plain.bin');
    final enc = File('${tmp.path}/enc.bin');
    final originalBytes = List<int>.generate(12000, (i) => i % 251);
    await plain.writeAsBytes(originalBytes, flush: true);

    expect(await alice.encryptFileToDestination(plain, enc), isTrue);
    expect(await E2eeService.detectEncryptedMediaVersion(enc), 2);
    await bob.decryptFileInPlaceIfNeeded(enc, requireEncrypted: true);
    expect(await enc.readAsBytes(), originalBytes);
  });
}
