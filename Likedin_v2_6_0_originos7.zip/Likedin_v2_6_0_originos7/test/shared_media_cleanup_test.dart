import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/backend/shared_media_service.dart';

String _keyFor(String objectPath) =>
    base64Url.encode(utf8.encode(objectPath)).replaceAll('=', '');

void main() {
  test('deleteCachedFilesInDirectory removes main, thumbnail and partial cache files', () async {
    final dir = await Directory.systemTemp.createTemp('likedin_cache_clean_');
    addTearDown(() => dir.delete(recursive: true));

    const objPath = 'user-1/photo-123.jpg';
    final mainKey = _keyFor(objPath);
    final thumbKey = _keyFor('$objPath.thumb.jpg');
    final f1 = File('${dir.path}/$mainKey.jpg')..writeAsBytesSync([1, 2, 3]);
    final f2 = File('${dir.path}/$mainKey.part')..writeAsBytesSync([4, 5]);
    final f3 = File('${dir.path}/$thumbKey.jpg')..writeAsBytesSync([6, 7]);
    final unrelated = File('${dir.path}/keep_me.jpg')..writeAsBytesSync([9]);

    await SharedMediaService.deleteCachedFilesInDirectory(dir, objPath);

    expect(await f1.exists(), isFalse);
    expect(await f2.exists(), isFalse);
    expect(await f3.exists(), isFalse);
    expect(await unrelated.exists(), isTrue);
  });

  test('deleteCachedFilesInDirectory throws FileSystemException when deletion fails', () async {
    final dir = await Directory.systemTemp.createTemp('likedin_cache_fail_');
    addTearDown(() => dir.delete(recursive: true));

    const objPath = 'user-1/locked-file.jpg';
    final mainKey = _keyFor(objPath);
    // A non-empty directory with the matching cache key name causes
    // non-recursive delete() to fail with FileSystemException.
    final blockingDir = Directory('${dir.path}/$mainKey.jpg');
    await blockingDir.create(recursive: true);
    await File('${blockingDir.path}/nested').writeAsString('stay');

    await expectLater(
      SharedMediaService.deleteCachedFilesInDirectory(dir, objPath),
      throwsA(isA<FileSystemException>()),
    );
  });
}
