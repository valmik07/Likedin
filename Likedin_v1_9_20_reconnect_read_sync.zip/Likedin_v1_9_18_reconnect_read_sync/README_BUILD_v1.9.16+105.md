# Likedin 1.9.16+105 — Reliability build

This is a source-code build package for the next Android CI build. It is not a precompiled APK.

## Build

1. Upload/replace the project files in the existing GitHub repository, preserving the project root and `android/` directory.
2. Run the existing Android GitHub Actions workflow.
3. In CI, run `flutter pub get`, `dart format --output=none --set-exit-if-changed lib test`, `flutter analyze`, `flutter test`, and the existing release APK/AAB build command.
4. Do not distribute the APK unless the workflow completes successfully.

## Important reliability changes

- Receipt-only message updates are applied to loaded bubbles; they no longer cause full conversation reloads.
- Reaction Realtime bursts are coalesced per message and refresh only that message.
- Offline catch-up follows the composite `(created_at, id)` cursor until it reconnects with the existing in-memory history or detects lack of cursor progress; the former 2,000-message cutoff is removed.
- Overlapping chat reload requests are individually awaited; errors from the corresponding refresh are propagated to the waiting caller.
- Deleted media paths successfully removed from Supabase Storage are persisted in Android secure storage, and concurrent tombstone cleanup is deduplicated.
- Failed/quarantined attachment uploads are surfaced in the chat, with an example filename and failure reason; pending uploads display their filenames.
- Cleared-chat Home previews avoid paging through pre-clear history. Receipt-only UPDATE events do not refresh the preview.
- Explicit audio metadata takes precedence over generic video MIME/extension guesses. Audio-only picker selections carry audio kind through retries.
- Download timeout, partial Realtime-row merging, jump-to-reply cancellation, and the related earlier v1.9.15 fixes are retained.

## Supabase migration

This reliability pass fixes a duplicate migration version in the supplied source. Audio allow-list SQL is now `202611230003_audio_file_sharing_allowlist_reapply.sql`; the additive profile-avatar/presence migration is reissued idempotently as `202611230002_v1916_reapply_profile_avatar_and_presence.sql`. The edit no-op migration remains `202611230001_v1914_edit_message_noop_guard.sql`. Apply pending migrations with `supabase db push` from the correctly linked Supabase project. The two reissued migrations are additive/idempotent, so they also repair a database where the old shared version had caused one of them to be skipped.

## Verification status

- ZIP/archive integrity: checked when packaged.
- Source-level review: performed for the changed code paths.
- Flutter formatting, analyzer, tests and Android compilation: **not run in this environment** because the Flutter/Dart SDK is unavailable. GitHub Actions must confirm these before release.
- Real-device testing is still required for offline catch-up, Realtime event bursts, audio-only MP4/3GP/WebM containers, queued upload quarantine, and persisted deleted-media cleanup.
