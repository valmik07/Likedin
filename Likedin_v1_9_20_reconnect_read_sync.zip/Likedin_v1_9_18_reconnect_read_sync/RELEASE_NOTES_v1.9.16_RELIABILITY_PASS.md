# Likedin v1.9.16 — Reliability pass

## Changes

- Receipt-only message updates are applied to existing bubbles without triggering a full conversation reload. Successful bulk delivered/read RPCs update local receipt state immediately.
- Reaction insert/delete Realtime events refresh only the affected message's reactions. Initial reaction hydration is now limited to messages not already hydrated, including empty reaction results.
- Offline catch-up no longer stops at an arbitrary 20-page/2,000-message ceiling. It continues until it overlaps the previously loaded timeline, reaches the known boundary, or detects that pagination is no longer progressing.
- Successfully deleted remote media paths are persisted in device secure storage so historical tombstones do not repeatedly issue Storage deletes after every app restart. Cached local copies are still removed on both devices.
- Explicit audio message metadata now takes precedence over generic MP4/3GP/WebM/MKV video MIME/extension detection in the chat renderer.
- Home preview ignores receipt-only message updates, avoiding preview reloads when only delivered/read timestamps change.

## Checks and limitations

- Source changes and ZIP archive structure were checked.
- Flutter/Dart SDK was not available in the editing environment, so `flutter analyze`, unit tests, and Android compilation must be run in GitHub Actions.
- Audio-only container identification at upload time still depends on picker-provided MIME/metadata; the renderer now respects an explicit `kind: audio` or `mime: audio/*` value.
- Real-device verification is still required for background delivery, high-volume offline catch-up, and repeated reaction events.

- Added a visible Cancel control while jumping to an old reply; the operation checks cancellation between page loads and list-scroll retries.
- Realtime message UPDATE handling now merges available fields with the currently loaded message, so a partial row cannot blank out message content or receipts.
- Audio-only picker selections carry an explicit `kind: audio` through the local retry queue and uploaded metadata. Ambiguous audio containers are not sent through video compression, and the chat renderer gives explicit audio metadata precedence.
- The empty-edit action can now be pressed to show the explanatory message instead of appearing silently disabled.
- The pending attachment banner now accurately describes retry conditions.
- Audio-only file picking now accepts MP4/3GP/3G2/WebM/MKV containers from Android audio providers even when generic MIME sniffing labels the container as video; explicit `kindOverride: audio` is carried through retries and upload metadata.
- Cleared-chat Home previews now use one newest-page query plus explicit post-clear exception IDs. The unread scan is scoped to post-clear messages and separately counts preserved clock-skew exceptions, avoiding pagination through cleared history.
- Home preview UPDATE events ignore receipt-only rows where the old payload does not expose content columns; edited/deleted rows still cause a preview refresh.

- Quarantined attachment uploads are visible in chat with an example filename and failure reason; a Retry failed uploads action restores source files that still exist to the normal retry queue. Missing local files remain quarantined with a clear reselect instruction.
- Realtime reaction bursts are debounced per message before issuing a targeted reaction refresh.
- Concurrent delete-for-everyone tombstone handlers deduplicate remote Storage deletion requests while the operation is in flight.
- Audio MIME metadata now selects the audio player even for legacy payloads whose `kind` was missing but whose MIME was already audio.
- Fixed duplicate Supabase migration version `202611210001` by assigning unique versions and reissuing the additive profile/presence migration under `202611230002`.
