# Likedin 1.9.19+108 — analyzer cleanup source build

This is a source ZIP, not a prebuilt APK.

## Build

1. Extract the ZIP and open the extracted project directory.
2. Run `flutter pub get`.
3. Run `dart format lib test`.
4. Run `flutter analyze`.
5. Run `flutter test`.
6. Build using the project's existing Android/CI workflow.

No Supabase migration is included or required for this analyzer-cleanup patch. The reconnect, read-sync, older-message refresh, and Realtime body fallback fixes from 1.9.18 are retained.

See `RELEASE_NOTES_v1.9.19_ANALYZER_CLEANUP.md` for the changes and validation limitations.
