# Likedin 1.9.15 - chat bug fixes

Static code changes only; `flutter analyze` / `flutter test` were not run (no Flutter toolchain in the review environment). Please run both before release.

1. Delivered tick: the foreground push handler now acknowledges delivery (`notification_service.dart`), so messages received while the app is open on Home no longer stay at one check.
2. Offline gap: `_loadMessagesNow` fetches the missing middle when more than one page arrived while away (up to 20 pages).
3. Second edit: `_mergeMessagesByClientId` breaks equal-score ties by `editedAt`, then prefers the fresher copy.
4. Voice recording: the composer is read-only while recording and the mic/stop button stays visible.
5. Media queue: retried about every 60 s while items wait (`SharedMediaService.hasQueuedItems`).
6. Downloads: 45 s connect timeout and 30 s stall timeout so a bubble cannot spin forever.
7. Home preview: stops paging back through a cleared history.
8. Message menu: Edit / React / Delete for everyone hidden while a message is still sending.
9. Audio in .mp4/.3gp/.webm/.mkv containers renders as audio, not video.

Not changed: reply-quote full-image download, reply-target error handling, reload/quota tuning, pending-tick icon, in-chat bubbles for queued media.

## Second batch (remaining bugs)
- Reply quotes with an image now use the cached copy only instead of downloading the full image.
- Replying from gallery, file and keyboard-image flows no longer fails when the target is still sending; the error text now distinguishes network failure.
- Pending (not yet sent) messages show a clock icon.
- Repeated remote cleanup of deleted media is suppressed.
- `markDelivered` is only called when an incoming message actually needs it, and never concurrently. Foreground pushes now also acknowledge delivery.
- Reactions update instantly (optimistic) and roll back via refresh on error.
- Cleared chats no longer scan older history on the home preview.
- Saving an empty edit now explains why nothing happened.
- Jump-to-reply paging is capped at 50 pages.
- A banner shows how many attachments are waiting to upload.
- Media downloads have connection and stall timeouts.

## Still needs a device check (not changed)
- Mic button `onLongPressCancel` possibly discarding a recording on a plain tap.
- `isom`/`mp42` m4a files possibly sniffed as video/mp4.
- Realtime UPDATE payloads possibly omitting long text columns.

Nothing was compiled or tested. Run `flutter analyze` and `flutter test` before release.
