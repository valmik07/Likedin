# Likedin 1.9.18 — reconnect and receipt reliability fixes

Source update based on the 1.9.17 recommended-fixes archive. No Supabase schema migration is required.

## Fixes included

1. **Long message text no longer disappears on sparse Realtime UPDATE rows.** The handler now chooses the first non-null, non-empty value across `body_payload`, `encrypted_payload`, and legacy `ciphertext`, and applies the previous text fallback after merging the incoming row. Present-but-null/empty legacy keys cannot overwrite the fallback.
2. **Read receipts retry messages that arrive during an in-flight read RPC.** The handler snapshots unread IDs before each server call, marks only that snapshot locally, runs up to three passes, and records overlapping invocations for a follow-up pass.
3. **Reconnect now performs incoming-message processing.** Reconnect clears reaction hydration, reloads messages, refreshes reactions, refreshes loaded historical message rows, then processes delivery and visible-read acknowledgements.
4. **The late peer-registration subscription now includes `onReconnect`.** It receives the same recovery behavior as the initial subscription.
5. **Loaded older messages are refreshed by ID after reconnect.** IDs already loaded through pagination are fetched in chunks of 100 using the existing `loadMessagesByIds` helper. Fresh edits and delete-for-everyone tombstones are merged into the in-memory timeline, and deleted-media cache cleanup is run for refreshed rows. Known text is preserved if a legacy row returns an empty body.
6. **Delivery acknowledgement re-entry is hardened too.** Overlapping message events during the delivered RPC request a follow-up pass, preventing a narrow final-pass race.

## Regression tests added

- `test/realtime_message_payload_test.dart`: null/empty legacy payload fallback and current-column precedence.
- `test/receipt_reconciliation_test.dart`: a message arriving during the acknowledgement RPC is picked up by the next snapshot, empty queues stop immediately, and the pass cap is respected.

## Validation notes

- Source-level checks and ZIP integrity checks should be run before use.
- Flutter/Dart compilation and unit/widget tests require a Flutter toolchain. If unavailable in the authoring environment, they are explicitly marked as not run.
- No physical-device test is claimed by this source package.

## Version

- `pubspec.yaml`: `1.9.18+107`
- `lib/main.dart`: `likedinVersion = '1.9.18+107'`
