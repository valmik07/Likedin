# Likedin v1.9.14+100 — chat bug fixes

Fixes the 20 issues from the frontend audit of v1.9.13.

## Functional
1. **Typing indicator** — `sendTyping(true)` heartbeats are no longer de-duplicated (only repeated `false` is), so the peer's 5s expiry is refreshed while you keep typing. (`realtime_messaging_service.dart`)
2. **Jump to reply gap** — jumping to an old message pages backwards until the target ID is found, so the timeline stays contiguous. No page cap. The timestamp shortcut only stops when the oldest fetched row is strictly older than the target (matching the `(created_at, id)` cursor), so a page boundary inside equal timestamps cannot end it early. Older-message loads are single-flight, and a jump waits for any load already running however long it takes.
3. **Overlapping reloads** — `_loadMessages()` is now sequence-based. Each call completes only after a load that started after that call, with that load's result. A reload requested during a follow-up gets its own follow-up, and a failed load fails every caller it covers instead of reporting success.
4. **Reply while editing** — `_startReply` restores the pre-edit draft instead of leaving the edited text in the composer.
5. **Cancel reply** — only cancelling an *edit* touches the composer; cancelling a reply keeps your draft. A draft typed before starting an edit is restored when the edit ends.
6. **Reactions on older messages** — reaction refresh now covers every loaded message with a committed ID, not just the newest page.
7. **False error messages** — edit, delete-for-everyone and reactions use `_refreshMessagesQuietly()`; a failed refresh no longer reports a successful action as failed. Post-delete cache cleanup is also best-effort.
8. **Vanishing message** — both loaders re-merge against the *current* list after their awaits instead of overwriting with a stale snapshot.

## Voice and composer
9. **Stuck recording** — if `stop()` throws, recording state is reset and the recorder cancelled.
10. **Cancel tap-to-record** — a ✕ button appears while recording.
11. **Lost voice note** — a reply target that is still sending is retried for ~2.4s, then the note is sent without the reply link instead of being deleted (same for camera photos).
12. **Recording limit** — 5 minutes; auto-sends at the limit.
13. **Failed sticker** — no longer pushed into the composer; a snackbar is shown.
14. **No-op edit** — client skips the edit when text is unchanged; new migration `202611230001_v1914_edit_message_noop_guard.sql` makes `likedin_edit_message` leave `edited_at` alone for unchanged text.

## State and display
15. **Hidden/cleared state** — if the secure-storage read failed, saving retries the read and merges; if still unreadable the write is skipped so stored data is never overwritten.
16. **Delete for me** — hides both the temporary and client IDs, so a just-sent message stays hidden after it gets its real ID. Deleted-message placeholders now open a menu with "Delete for me".
17. **Jump-to-reply scrolling** — retries up to 14 times, steering by the rows that are built until the target row exists.
18. **Typing bubble** — scrolls into view when you are at the bottom.
19. **Registration text** — a failed peer lookup shows "Could not reach messaging… Retrying automatically…" instead of "Waiting for your friend to register."
20. **Voice playback** — the player row is kept alive while a clip is playing or paused part-way.

## Deploy
Run the new SQL migration (`supabase db push`) for fix 14's server side. The client works without it.

Note: this build was patched without a Flutter toolchain available, so run `flutter analyze` and `flutter test` before releasing.
