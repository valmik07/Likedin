# Likedin 1.9.18+107 — source build

This is a source ZIP, not a prebuilt APK.

## Build

1. Extract the ZIP and open the extracted project directory.
2. Run `flutter pub get`.
3. Run `dart format lib test`.
4. Run `flutter analyze`.
5. Run `flutter test`.
6. Build using the project's existing Android/CI workflow.

No new Supabase migration is included or required for this patch.

See `RELEASE_NOTES_v1.9.18_RECONNECT_READ_SYNC_FIXES.md` for the changes and validation scope.
