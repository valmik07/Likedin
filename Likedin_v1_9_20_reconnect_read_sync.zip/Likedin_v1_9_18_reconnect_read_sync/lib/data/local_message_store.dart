import 'dart:convert';
import 'dart:isolate';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'package:uuid/uuid.dart';

class LocalMessage {
  const LocalMessage({
    required this.id,
    required this.text,
    required this.createdAt,
    required this.isOutgoing,
    required this.status,
  });

  final String id;
  final String text;
  final DateTime createdAt;
  final bool isOutgoing;
  final String status;
}

/// Local-first message storage. Message bodies are encrypted before SQLite writes.
/// This is encryption at rest only; it is NOT end-to-end messaging encryption.
class LocalMessageStore {
  LocalMessageStore._(this._database, this._key, this._keyBytes);

  static const _keyName = 'whisper.local.message.key.v1';
  static const _conversationId = 'private-pair';
  static final _algorithm = AesGcm.with256bits();
  static const _secureStorage = FlutterSecureStorage();
  static const _uuid = Uuid();

  final Database _database;
  final SecretKey _key;
  final Uint8List _keyBytes;

  static Future<LocalMessageStore> open() async {
    final keyText = await _secureStorage.read(key: _keyName);
    late final Uint8List keyBytes;

    if (keyText == null) {
      final generated = await _algorithm.newSecretKey();
      final bytes = await generated.extractBytes();
      await _secureStorage.write(key: _keyName, value: base64Encode(bytes));
      keyBytes = Uint8List.fromList(bytes);
    } else {
      keyBytes = base64Decode(keyText);
    }

    final databasePath = p.join(await getDatabasesPath(), 'whisper_local.db');
    final database = await openDatabase(
      databasePath,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE messages (
            id TEXT PRIMARY KEY,
            conversation_id TEXT NOT NULL,
            ciphertext TEXT NOT NULL,
            nonce TEXT NOT NULL,
            mac TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            is_outgoing INTEGER NOT NULL,
            status TEXT NOT NULL
          )
        ''');
        await db.execute(
          'CREATE INDEX messages_conversation_time ON messages(conversation_id, created_at)',
        );
      },
    );

    return LocalMessageStore._(database, SecretKey(keyBytes), keyBytes);
  }

  Future<void> queueOutgoing(String text) async {
    final cleanText = text.trim();
    if (cleanText.isEmpty) return;

    final nonce = _algorithm.newNonce();
    final box = await _algorithm.encrypt(
      utf8.encode(cleanText),
      secretKey: _key,
      nonce: nonce,
    );

    await _database.insert('messages', {
      'id': _uuid.v4(),
      'conversation_id': _conversationId,
      'ciphertext': base64Encode(box.cipherText),
      'nonce': base64Encode(box.nonce),
      'mac': base64Encode(box.mac.bytes),
      'created_at': DateTime.now().millisecondsSinceEpoch,
      'is_outgoing': 1,
      'status': 'queued',
    });
  }

  /// Loads messages with optional keyset pagination. When [limit] is provided,
  /// fetches the newest [limit] rows (optionally older than [beforeCreatedAtMs])
  /// and returns them in ascending chronological order.
  /// Large batches are decrypted on a background isolate to keep the UI smooth.
  Future<List<LocalMessage>> loadMessages({
    int? limit,
    int? beforeCreatedAtMs,
  }) async {
    final whereClause = beforeCreatedAtMs == null
        ? 'conversation_id = ?'
        : 'conversation_id = ? AND created_at < ?';
    final whereArgs = beforeCreatedAtMs == null
        ? <Object?>[_conversationId]
        : <Object?>[_conversationId, beforeCreatedAtMs];

    final rows = await _database.query(
      'messages',
      where: whereClause,
      whereArgs: whereArgs,
      orderBy: limit != null ? 'created_at DESC' : 'created_at ASC',
      limit: limit,
    );
    if (rows.isEmpty) return const <LocalMessage>[];

    final orderedRows = limit != null ? rows.reversed.toList(growable: false) : rows;
    final keyBytes = _keyBytes;

    // Offload AES-GCM decryption off the main UI isolate for non-trivial batches.
    if (orderedRows.length > 15) {
      final rawRows = orderedRows
          .map((row) => <String, Object?>{
                'id': row['id'],
                'ciphertext': row['ciphertext'],
                'nonce': row['nonce'],
                'mac': row['mac'],
                'created_at': row['created_at'],
                'is_outgoing': row['is_outgoing'],
                'status': row['status'],
              })
          .toList(growable: false);
      return Isolate.run(() => _decryptRows(rawRows, keyBytes));
    }

    return _decryptRows(orderedRows, keyBytes);
  }

  static Future<List<LocalMessage>> _decryptRows(
    List<Map<String, Object?>> rows,
    Uint8List keyBytes,
  ) async {
    final algorithm = AesGcm.with256bits();
    final key = SecretKey(keyBytes);
    final messages = <LocalMessage>[];
    for (final row in rows) {
      final box = SecretBox(
        base64Decode(row['ciphertext']! as String),
        nonce: base64Decode(row['nonce']! as String),
        mac: Mac(base64Decode(row['mac']! as String)),
      );
      final clearBytes = await algorithm.decrypt(box, secretKey: key);
      messages.add(LocalMessage(
        id: row['id']! as String,
        text: utf8.decode(clearBytes),
        createdAt: DateTime.fromMillisecondsSinceEpoch(row['created_at']! as int),
        isOutgoing: (row['is_outgoing']! as int) == 1,
        status: row['status']! as String,
      ));
    }
    return messages;
  }

  /// Plaintext is returned only to the backup encoder, never written to disk here.
  Future<String> createBackupPayload() async {
    final messages = await loadMessages();
    return jsonEncode({
      'format': 'project-whisper-backup',
      'version': 1,
      'createdAt': DateTime.now().toUtc().toIso8601String(),
      'messages': messages.map((message) => {
        'id': message.id,
        'text': message.text,
        'createdAt': message.createdAt.toUtc().toIso8601String(),
        'isOutgoing': message.isOutgoing,
        'status': message.status,
      }).toList(),
    });
  }

  Future<void> close() => _database.close();
}
