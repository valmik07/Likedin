import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import '../backend/turn_config_service.dart';
import 'call_alert_controller.dart';

class LikedinCallService {
  LikedinCallService(this.client);
  final SupabaseClient client;
  final _uuid = const Uuid();
  RTCPeerConnection? _pc;
  MediaStream? _local;
  final _remote = RTCVideoRenderer();
  final _localRenderer = RTCVideoRenderer();
  bool _renderersInitialized = false;
  final List<RTCIceCandidate> _pendingCandidates = [];
  final Set<String> _seenIceSignalIds = <String>{};
  bool _remoteDescriptionReady = false;
  bool _applyingRemoteAnswer = false;
  bool _speakerOverriddenByUser = false;
  bool _terminalizing = false;
  RealtimeChannel? _channel;
  Timer? _ringTimer;
  Timer? _signalCatchupTimer;
  static int _channelGeneration = 0;
  bool _catchingUpSignals = false;
  Timer? _disconnectGraceTimer;
  String? callId, peerId;
  bool video = false, muted = false, speaker = false, camera = true;
  bool usingFrontCamera = true;
  String status = 'idle';
  final _changes = StreamController<String>.broadcast();
  Future<void>? _disposeFuture;
  Future<void>? _closeFuture;
  Stream<String> get changes => _changes.stream;
  RTCVideoRenderer get remoteRenderer => _remote;
  RTCVideoRenderer get localRenderer => _localRenderer;
  String get uid => client.auth.currentUser?.id ?? '';

  Future<void> initialize({bool withVideo = true}) async {
    if (!withVideo || _renderersInitialized) return;
    await _remote.initialize();
    await _localRenderer.initialize();
    _renderersInitialized = true;
  }

  // Audio calls start on the handset earpiece; video calls default to speakerphone.
  Future<void> _applyInitialAudioRoute() async {
    if (!_speakerOverriddenByUser) {
      speaker = video;
    }
    await Helper.setSpeakerphoneOn(speaker);
  }

  Future<List<Map<String, dynamic>>> _iceServers() =>
      TurnConfigService(client).fetchIceServers();

  Future<void> _createPeer() async {
    // Start peer creation with immediately-available STUN servers. Fetching
    // private TURN credentials must not block the answer path or prevent a
    // call during an Edge Function cold start/rate limit/outage.
    final turnServersFuture = _iceServers();
    _pc = await createPeerConnection({
      'iceServers': TurnConfigService.fallbackIceServers,
      'sdpSemantics': 'unified-plan',
    });
    final peerForConfiguration = _pc;
    unawaited(turnServersFuture.then<void>((servers) async {
      final activePeer = _pc;
      if (activePeer == null || !identical(activePeer, peerForConfiguration)) return;
      try {
        await activePeer.setConfiguration({
          'iceServers': servers,
          'sdpSemantics': 'unified-plan',
        });
      } catch (error) {
        debugPrint('Could not apply refreshed TURN configuration; keeping STUN fallback: $error');
      }
    }).catchError((Object error) {
      debugPrint('TURN configuration refresh failed; keeping STUN fallback: $error');
    }));
    _pc!.onIceCandidate = (candidate) {
      if (candidate.candidate != null && callId != null) {
        unawaited(_send('ice', {
          'candidate': candidate.candidate,
          'sdpMid': candidate.sdpMid,
          'sdpMLineIndex': candidate.sdpMLineIndex,
        }).catchError((Object error) {
          // ICE delivery is best-effort; avoid an unhandled async callback error.
        }));
      }
    };
    _pc!.onTrack = (event) {
      if (event.streams.isNotEmpty && _renderersInitialized) {
        _remote.srcObject = event.streams.first;
        // Track arrival is not proof of ICE connectivity. The connection-state
        // callback alone starts the connected timer/state.

      }
    };
    _pc!.onConnectionState = (state) {
      final raw = state.toString().split('.').last.toLowerCase();
      // 'disconnected' contains 'connected', so test it first.
      if (raw.contains('disconnected')) {
        status = 'disconnected';
        if (!_changes.isClosed) _changes.add(status);
        unawaited(_pc?.restartIce().catchError((Object _) {}));
        // Transient WebRTC ICE disconnections can recover; allow a 10-second grace
        // window before treating the connection as failed.
        _disconnectGraceTimer?.cancel();
        _disconnectGraceTimer = Timer(const Duration(seconds: 10), () {
          if (status == 'disconnected') {
            unawaited(_failCall('Call disconnected and did not recover.'));
          }
        });
        return;
      }
      _disconnectGraceTimer?.cancel();
      if (raw.contains('connected')) {
        status = 'connected';
        _signalCatchupTimer?.cancel();
        _signalCatchupTimer = null;
      } else if (raw.contains('connecting')) {
        status = 'connecting';
      } else if (raw.contains('failed')) {
        unawaited(_failCall('WebRTC connection failed.'));
        return;
      } else if (raw.contains('closed')) {
        if (!_terminalizing) {
          unawaited(_failCall('Call connection closed unexpectedly.'));
          return;
        }
        status = 'ended';
      } else {
        status = 'connecting';
      }
      if (!_changes.isClosed) _changes.add(status);
    };
    _local = await navigator.mediaDevices.getUserMedia({
      'audio': true,
      'video': video
          ? {
              'facingMode': 'user',
              'width': {'ideal': 640},
              'height': {'ideal': 480},
              'frameRate': {'ideal': 18, 'max': 20},
            }
          : false,
    });
    await CallAlertController.startCallService(video: video);
    // getUserMedia may reset Android's audio route; re-assert initial route afterwards.
    await _applyInitialAudioRoute();
    if (_renderersInitialized) {
      _localRenderer.srcObject = _local;
    }
    for (final track in _local!.getTracks()) {
      await _pc!.addTrack(track, _local!);
    }
  }

  Future<void> start(String recipient, {required bool withVideo}) async {
    if (uid.isEmpty) throw StateError('Sign in again before starting a call.');
    _disposeFuture = null;
    _terminalizing = false;
    _seenIceSignalIds.clear();
    _pendingCandidates.clear();
    _remoteDescriptionReady = false;
    _applyingRemoteAnswer = false;
    _speakerOverriddenByUser = false;
    video = withVideo;
    peerId = recipient;
    callId = _uuid.v4();
    status = 'calling';
    try {
      await _applyInitialAudioRoute();
      await _createPeer();
      final offer = await _pc!.createOffer();

      await client.from('likedin_calls').insert({
        'id': callId,
        'caller_id': uid,
        'callee_id': recipient,
        'call_type': video ? 'video' : 'audio',
        'status': 'ringing',
      });
      await CallAlertController.startOutgoing();
      _ringTimer?.cancel();
      _ringTimer = Timer(const Duration(seconds: 45), () async {
        if (status == 'calling' && callId != null) {
          _terminalizing = true;
          try {
            await client.rpc('likedin_update_call_status', params: {
              'p_call_id': callId,
              'p_new_status': 'missed',
            });
          } catch (_) {}
          try {
            await _send('end', {'reason': 'no_answer'});
          } catch (_) {}
          status = 'missed';
          if (!_changes.isClosed) _changes.add(status);
          await dispose();
        }
      });
      _listen();
      _startSignalCatchup();
      await _pc!.setLocalDescription(offer);
      await _send('offer', {'sdp': offer.sdp, 'type': offer.type});
      if (!_changes.isClosed) _changes.add(status);
    } catch (_) {
      _terminalizing = true;
      final id = callId;
      if (id != null) {
        try {
          await client.rpc('likedin_update_call_status', params: {
            'p_call_id': id,
            'p_new_status': 'ended',
          });
        } catch (_) {}
      }
      await dispose();
      rethrow;
    }
  }

  Future<void> accept(String id, String caller, Map<String, dynamic> offer, {required bool withVideo}) async {
    if (uid.isEmpty) throw StateError('Sign in again before answering a call.');
    _disposeFuture = null;
    _terminalizing = false;
    _seenIceSignalIds.clear();
    _pendingCandidates.clear();
    _remoteDescriptionReady = false;
    _applyingRemoteAnswer = false;
    _speakerOverriddenByUser = false;
    callId = id;
    peerId = caller;
    video = withVideo;
    status = 'connecting';
    var acceptedStatusCommitted = false;
    try {
      await _applyInitialAudioRoute();
      _listen();
      _startSignalCatchup();
      await _createPeer();
      await _pc!.setRemoteDescription(RTCSessionDescription(offer['sdp'] as String, offer['type'] as String));
      _remoteDescriptionReady = true;
      final existing = await client
          .from('likedin_call_signals')
          .select('id,sender_id,kind,payload')
          .eq('call_id', id)
          .eq('kind', 'ice')
          .neq('sender_id', uid)
          .order('created_at');
      for (final row in existing) {
        await _consumeIceSignal(Map<String, dynamic>.from(row));
      }
      for (final c in _pendingCandidates) {
        await _pc!.addCandidate(c);
      }
      _pendingCandidates.clear();
      final answer = await _pc!.createAnswer();
      await _pc!.setLocalDescription(answer);
      await client.rpc('likedin_update_call_status', params: {
        'p_call_id': id,
        'p_new_status': 'accepted',
      });
      acceptedStatusCommitted = true;
      await _send('answer', {'sdp': answer.sdp, 'type': answer.type});
      if (!_changes.isClosed) _changes.add(status);
    } catch (_) {
      _terminalizing = true;
      // If the accepted status was already committed but signaling failed,
      // rejected is no longer a legal transition (it only applies to ringing).
      // Persist a failed call so both devices and call history agree.
      try {
        await client.rpc('likedin_update_call_status', params: {
          'p_call_id': id,
          'p_new_status': acceptedStatusCommitted ? 'failed' : 'rejected',
        });
      } catch (_) {}
      await dispose();
      rethrow;
    }
  }

  Future<void> _consumeIceSignal(Map<String, dynamic> row) async {
    final signalId = row['id']?.toString();
    if (signalId != null && signalId.isNotEmpty && !_seenIceSignalIds.add(signalId)) return;
    final data = Map<String, dynamic>.from(row['payload'] as Map);
    if (data['candidate'] == null || _pc == null) return;
    final candidate = RTCIceCandidate(data['candidate'], data['sdpMid'], data['sdpMLineIndex']);
    if (_remoteDescriptionReady) {
      await _pc!.addCandidate(candidate);
    } else {
      _pendingCandidates.add(candidate);
    }
  }

  Future<void> _failCall(String reason) async {
    if (_terminalizing) return;
    _terminalizing = true;
    debugPrint('Likedin call terminating after failure: $reason');
    final id = callId;
    if (id != null) {
      try {
        await client.rpc('likedin_update_call_status', params: {
          'p_call_id': id,
          'p_new_status': 'failed',
        });
      } catch (error) {
        debugPrint('Could not persist failed call status: $error');
      }
      try {
        // The row status is authoritative, but the peer's active WebRTC
        // service primarily listens to signaling rows. Send a best-effort end
        // signal so it tears down immediately instead of waiting for polling.
        await _send('end', {'reason': reason});
      } catch (error) {
        debugPrint('Could not signal failed call termination: $error');
      }
    }
    await dispose();
    status = 'failed';
    if (!_changes.isClosed) _changes.add(status);
  }

  void _listen() {
    final gen = ++_channelGeneration;
    _channel = client
        .channel('call-$callId-${uid.substring(0, 6)}-$gen')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'likedin_call_signals',
          filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'call_id', value: callId),
          callback: (payload) async {
            final row = payload.newRecord;
            if (row['sender_id'] == uid) return;
            final signalId = row['id']?.toString();
            if (signalId != null && signalId.isNotEmpty && !_seenIceSignalIds.add('signal:$signalId')) return;
            final kind = row['kind'];
            final data = row['payload'] is Map ? Map<String, dynamic>.from(row['payload'] as Map) : <String, dynamic>{};
            try {
              if (kind == 'answer' && _pc != null && !_remoteDescriptionReady && !_applyingRemoteAnswer && data['sdp'] != null) {
                _applyingRemoteAnswer = true;
                try {
                  await CallAlertController.stop();
                  _ringTimer?.cancel();
                  await _pc!.setRemoteDescription(RTCSessionDescription(data['sdp'], data['type']));
                  _remoteDescriptionReady = true;
                  for (final c in _pendingCandidates) {
                    await _pc!.addCandidate(c);
                  }
                  _pendingCandidates.clear();
                  status = 'connecting';
                  if (!_changes.isClosed) _changes.add(status);
                } finally {
                  _applyingRemoteAnswer = false;
                }
              }
              if (kind == 'ice' && _pc != null) {
                await _consumeIceSignal(Map<String, dynamic>.from(row));
              }
              if (kind == 'end' || kind == 'reject') {
                final terminalStatus = kind == 'reject' ? 'rejected' : 'ended';
                _terminalizing = true;
                await dispose();
                status = terminalStatus;
                if (!_changes.isClosed) _changes.add(status);
              }
            } catch (error, stackTrace) {
              debugPrint('Call signaling failed: $error\n$stackTrace');
              await _failCall('Call signaling failed. Please check your connection and try again.');
            }
          },
        )..subscribe();
  }


  void _startSignalCatchup() {
    _signalCatchupTimer = Timer.periodic(const Duration(seconds: 4), (_) {
      unawaited(_catchUpSignals());
    });
    unawaited(_catchUpSignals());
  }

  Future<void> _catchUpSignals() async {
    final id = callId;
    if (id == null || _catchingUpSignals || _terminalizing || _pc == null) return;
    _catchingUpSignals = true;
    try {
      final rows = await client.from('likedin_call_signals')
          .select('id,sender_id,kind,payload')
          .eq('call_id', id)
          .neq('sender_id', uid)
          .order('created_at');
      for (final raw in rows) {
        final row = Map<String, dynamic>.from(raw);
        final signalId = row['id']?.toString();
        if (signalId != null && !_seenIceSignalIds.add('signal:$signalId')) continue;
        final kind = row['kind']?.toString();
        final payload = row['payload'] is Map ? Map<String, dynamic>.from(row['payload'] as Map) : <String, dynamic>{};
        if (kind == 'answer' && _pc != null && !_remoteDescriptionReady && !_applyingRemoteAnswer && payload['sdp'] != null) {
          _applyingRemoteAnswer = true;
          try {
            await CallAlertController.stop();
            _ringTimer?.cancel();
            await _pc!.setRemoteDescription(RTCSessionDescription(payload['sdp'], payload['type']));
            _remoteDescriptionReady = true;
            for (final candidate in _pendingCandidates) { await _pc!.addCandidate(candidate); }
            _pendingCandidates.clear();
            status = 'connecting';
            if (!_changes.isClosed) _changes.add(status);
          } finally {
            _applyingRemoteAnswer = false;
          }
        } else if (kind == 'ice' && _pc != null) {
          await _consumeIceSignal(row);
        } else if (kind == 'end' || kind == 'reject') {
          _terminalizing = true;
          await dispose();
          status = kind == 'reject' ? 'rejected' : 'ended';
          if (!_changes.isClosed) _changes.add(status);
          break;
        }
      }
    } catch (error) { debugPrint('Call signal catch-up failed: $error'); }
    finally { _catchingUpSignals = false; }
  }

  Future<void> _send(String kind, Map<String, dynamic> payload) async {
    await client.from('likedin_call_signals').insert({
      'call_id': callId,
      'sender_id': uid,
      'kind': kind,
      'payload': payload,
    });
  }

  Future<void> toggleMute() async {
    muted = !muted;
    for (final t in _local?.getAudioTracks() ?? []) {
      t.enabled = !muted;
    }
    if (!_changes.isClosed) _changes.add(status);
  }

  Future<void> toggleCamera() async {
    camera = !camera;
    for (final t in _local?.getVideoTracks() ?? []) {
      t.enabled = camera;
    }
    if (!_changes.isClosed) _changes.add(status);
  }

  Future<void> switchCamera() async {
    final tracks = _local?.getVideoTracks() ?? [];
    if (tracks.isEmpty) return;
    await Helper.switchCamera(tracks.first);
    usingFrontCamera = !usingFrontCamera;
    if (!_changes.isClosed) _changes.add(status);
  }

  Future<void> toggleSpeaker() async {
    final next = !speaker;
    _speakerOverriddenByUser = true;
    await Helper.setSpeakerphoneOn(next);
    speaker = next;
    if (!_changes.isClosed) _changes.add(status);
  }

  Future<void> end({bool rejected = false}) async {
    if (_terminalizing) return;
    _terminalizing = true;
    final id = callId;
    if (id == null) {
      await dispose();
      status = rejected ? 'rejected' : 'ended';
      if (!_changes.isClosed) _changes.add(status);
      return;
    }
    await CallAlertController.stop();
    _ringTimer?.cancel();
    _signalCatchupTimer?.cancel();
    _disconnectGraceTimer?.cancel();
    try {
      await _send(rejected ? 'reject' : 'end', {});
    } catch (_) {}
    try {
      await client.rpc('likedin_update_call_status', params: {
        'p_call_id': id,
        'p_new_status': rejected ? 'rejected' : 'ended',
      });
    } catch (_) {}
    await dispose();
    status = rejected ? 'rejected' : 'ended';
    if (!_changes.isClosed) _changes.add(status);
  }

  Future<void> dispose() => _disposeFuture ??= _disposeResources();

  Future<void> _disposeResources() async {
    await CallAlertController.stop();
    await CallAlertController.stopCallService();
    _ringTimer?.cancel();
    _signalCatchupTimer?.cancel();
    _signalCatchupTimer = null;
    _ringTimer = null;
    _disconnectGraceTimer?.cancel();
    _disconnectGraceTimer = null;

    final channel = _channel;
    _channel = null;
    if (channel != null) {
      try {
        await client.removeChannel(channel);
      } catch (_) {}
    }

    final peer = _pc;
    _pc = null;
    if (peer != null) {
      try {
        await peer.close();
      } catch (_) {}
    }

    final local = _local;
    _local = null;
    if (local != null) {
      try {
        await local.dispose();
      } catch (_) {}
    }

    if (_renderersInitialized) {
      _remote.srcObject = null;
      _localRenderer.srcObject = null;
    }
    _pendingCandidates.clear();
    _seenIceSignalIds.clear();
    _remoteDescriptionReady = false;
    _applyingRemoteAnswer = false;
    _speakerOverriddenByUser = false;
  }

  Future<void> close() => _closeFuture ??= _closeResources();

  Future<void> _closeResources() async {
    await dispose();
    if (_renderersInitialized) {
      _renderersInitialized = false;
      try {
        await _remote.dispose();
      } catch (_) {}
      try {
        await _localRenderer.dispose();
      } catch (_) {}
    }
    if (!_changes.isClosed) await _changes.close();
  }
}
