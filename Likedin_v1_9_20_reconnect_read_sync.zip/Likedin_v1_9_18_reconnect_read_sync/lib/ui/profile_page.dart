import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'glassmorphism.dart';

/// Profile screen (spec screen 11): large avatar over a soft accent gradient,
/// identity details in separate glass panels, and shortcuts to settings,
/// appearance, storage and files. Sign out is visually distinct.
class ProfilePage extends StatelessWidget {
  const ProfilePage({
    required this.displayName,
    required this.email,
    required this.photoPath,
    required this.onEditPhoto,
    required this.onOpenSettings,
    required this.onOpenAppearance,
    required this.onOpenStorage,
    required this.onOpenFiles,
    required this.onSignOut,
    super.key,
  });

  final String displayName;
  final String email;
  final ValueListenable<String?> photoPath;
  final VoidCallback onEditPhoto;
  final VoidCallback onOpenSettings;
  final VoidCallback onOpenAppearance;
  final VoidCallback onOpenStorage;
  final VoidCallback onOpenFiles;
  final VoidCallback onSignOut;

  String get _initial {
    final name = displayName.trim();
    return name.isEmpty ? '?' : String.fromCharCode(name.runes.first).toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final primary = likedinPrimary(brightness);
    final muted = likedinMutedText(brightness);
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
      children: [
        // Hero: gradient wash behind the avatar.
        Container(
          padding: const EdgeInsets.fromLTRB(16, 28, 16, 22),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                primary.withValues(alpha: brightness == Brightness.dark ? .28 : .20),
                primary.withValues(alpha: 0),
              ],
            ),
          ),
          child: Column(
            children: [
              ValueListenableBuilder<String?>(
                valueListenable: photoPath,
                builder: (context, path, _) {
                  return Container(
                    padding: const EdgeInsets.all(3),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: likedinPrimaryGradient(brightness),
                    ),
                    child: CircleAvatar(
                      radius: 52,
                      backgroundColor: likedinSurfaceRaised(brightness),
                      child: path == null || path.isEmpty
                          ? Text(
                              _initial,
                              style: TextStyle(
                                fontSize: 40,
                                fontWeight: FontWeight.w800,
                                color: primary,
                              ),
                            )
                          : RepaintBoundary(
                              child: ClipOval(
                                child: Image.file(
                                  File(path),
                                  width: 104,
                                  height: 104,
                                  cacheWidth: 320,
                                  fit: BoxFit.cover,
                                  gaplessPlayback: true,
                                  errorBuilder: (_, __, ___) => Text(
                                    _initial,
                                    style: TextStyle(
                                      fontSize: 40,
                                      fontWeight: FontWeight.w800,
                                      color: primary,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 14),
              Text(
                displayName.trim().isEmpty ? 'Likedin user' : displayName,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800, letterSpacing: -.6),
              ),
              const SizedBox(height: 4),
              Text(
                email,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 14, color: muted),
              ),
              const SizedBox(height: 14),
              OutlinedButton.icon(
                onPressed: onEditPhoto,
                icon: const Icon(Icons.photo_camera_outlined, size: 18),
                label: const Text('Edit profile photo'),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _title(context, 'Account'),
        GlassPanel(
          radius: BorderRadius.circular(20),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          child: Column(
            children: [
              _infoRow(context, Icons.person_outline_rounded, 'Name',
                  displayName.trim().isEmpty ? 'Not set' : displayName),
              Divider(color: likedinOutline(brightness)),
              _infoRow(context, Icons.alternate_email_rounded, 'Email', email),
              Divider(color: likedinOutline(brightness)),
              _infoRow(context, Icons.verified_user_outlined, 'Status', 'Signed in'),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _title(context, 'Shortcuts'),
        GlassPanel(
          radius: BorderRadius.circular(20),
          child: Column(
            children: [
              _navTile(context, Icons.tune_rounded, 'Settings and privacy', const Color(0xFF4C8BF5), onOpenSettings),
              Divider(height: 1, indent: 60, endIndent: 14, color: likedinOutline(brightness)),
              _navTile(context, Icons.palette_outlined, 'Appearance and themes', const Color(0xFF9B6BFF), onOpenAppearance),
              Divider(height: 1, indent: 60, endIndent: 14, color: likedinOutline(brightness)),
              _navTile(context, Icons.pie_chart_outline_rounded, 'Storage and media', const Color(0xFF2FBF86), onOpenStorage),
              Divider(height: 1, indent: 60, endIndent: 14, color: likedinOutline(brightness)),
              _navTile(context, Icons.folder_outlined, 'Your files', const Color(0xFFF59E0B), onOpenFiles),
            ],
          ),
        ),
        const SizedBox(height: 16),
        GlassPanel(
          radius: BorderRadius.circular(20),
          child: ListTile(
            onTap: () async {
              final confirmed = await showDialog<bool>(
                context: context,
                builder: (dialogContext) => AlertDialog(
                  title: const Text('Sign out?'),
                  content: const Text('You can sign back in with your account credentials.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')),
                    FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Sign out')),
                  ],
                ),
              );
              if (confirmed == true) onSignOut();
            },
            leading: Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: const Color(0xFFE5484D).withValues(alpha: .14),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.logout_rounded, color: Color(0xFFE5484D), size: 19),
            ),
            title: const Text(
              'Sign out',
              style: TextStyle(color: Color(0xFFE5484D), fontWeight: FontWeight.w700),
            ),
          ),
        ),
      ],
    );
  }

  Widget _title(BuildContext context, String text) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 4, 4, 10),
        child: Text(
          text,
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: -.4),
        ),
      );

  Widget _infoRow(BuildContext context, IconData icon, String label, String value) {
    final brightness = Theme.of(context).brightness;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: likedinPrimary(brightness).withValues(alpha: .12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: likedinPrimary(brightness), size: 18),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: TextStyle(fontSize: 12, color: likedinMutedText(brightness))),
                const SizedBox(height: 2),
                Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _navTile(
    BuildContext context,
    IconData icon,
    String title,
    Color badgeColor,
    VoidCallback onTap,
  ) {
    final brightness = Theme.of(context).brightness;
    return ListTile(
      onTap: onTap,
      leading: Container(
        width: 34,
        height: 34,
        decoration: BoxDecoration(
          color: badgeColor.withValues(alpha: .15),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: badgeColor, size: 19),
      ),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
      trailing: Icon(Icons.chevron_right_rounded, color: likedinMutedText(brightness)),
    );
  }
}
