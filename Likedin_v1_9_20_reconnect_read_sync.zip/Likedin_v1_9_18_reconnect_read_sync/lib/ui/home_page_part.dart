part of '../main.dart';

class HomePage extends StatefulWidget {
  const HomePage({
    required this.displayName,
    required this.onOpenChat,
    required this.onHiddenChatsChanged,
    this.isActive = true,
    super.key,
  });
  final String displayName;
  final VoidCallback onOpenChat;
  final VoidCallback onHiddenChatsChanged;
  final bool isActive;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  static final http.Client _httpClient = http.Client();
  late Future<List<_HomeNews>> _news;
  int _conversationTick = 0;
  bool _hiddenStateReady = false;
  bool _hasHiddenChats = false;
  String? _hiddenStateError;

  @override
  void didUpdateWidget(covariant HomePage oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Refresh the conversation row (latest message, unread count) on return.
    if (widget.isActive && !oldWidget.isActive) {
      setState(() => _conversationTick++);
      _refreshHiddenChatState();
    }
  }

  @override
  void initState() {
    super.initState();
    _news = _loadNews();
    _refreshHiddenChatState();
  }

  Future<void> _refreshHiddenChatState() async {
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (uid == null) {
      if (mounted) setState(() { _hasHiddenChats = false; _hiddenStateReady = true; _hiddenStateError = null; });
      return;
    }
    try {
      final hidden = await HiddenChatVault().hasHiddenChats(uid);
      if (!mounted) return;
      setState(() { _hasHiddenChats = hidden; _hiddenStateReady = true; _hiddenStateError = null; });
    } catch (error) {
      debugPrint('Hidden-chat state could not be read: $error');
      if (!mounted) return;
      // Fail closed: never show the regular conversation row when its hidden
      // state cannot be verified. The user can retry the secure-store read.
      setState(() { _hasHiddenChats = true; _hiddenStateReady = true; _hiddenStateError = 'Could not verify hidden-chat status.'; });
    }
  }

  Widget _buildConversationSection(BuildContext context) {
    if (!_hiddenStateReady) {
      return const SizedBox(
        height: 82,
        child: Center(child: SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))),
      );
    }
    if (_hiddenStateError != null) {
      return GlassPanel(
        padding: const EdgeInsets.all(14),
        radius: BorderRadius.circular(18),
        child: Row(children: [
          const Icon(Icons.lock_outline_rounded),
          const SizedBox(width: 10),
          Expanded(child: Text(_hiddenStateError!)),
          IconButton(tooltip: 'Retry', onPressed: _refreshHiddenChatState, icon: const Icon(Icons.refresh_rounded)),
        ]),
      );
    }
    // Hidden conversations are intentionally absent from Home. The only
    // entry point is the Likedin logo in the Home header.
    if (_hasHiddenChats) return const SizedBox.shrink();
    return ConversationCard(
      refreshToken: _conversationTick,
      onOpen: widget.onOpenChat,
      onHidden: () {
        widget.onHiddenChatsChanged();
        if (mounted) setState(() { _hasHiddenChats = true; _hiddenStateReady = true; _hiddenStateError = null; });
      },
    );
  }

  List<String> get _feeds {
    final locale = WidgetsBinding.instance.platformDispatcher.locale;
    final language = locale.languageCode.isEmpty ? 'en' : locale.languageCode;
    final country = locale.countryCode?.isNotEmpty == true ? locale.countryCode! : 'US';
    final hl = locale.countryCode?.isNotEmpty == true ? '$language-${locale.countryCode}' : language;
    final suffix = 'hl=$hl&gl=$country&ceid=$country:$language';
    return <String>[
      'https://news.google.com/rss?$suffix',
      'https://news.google.com/rss/headlines/section/topic/WORLD?$suffix',
      'https://news.google.com/rss/headlines/section/topic/BUSINESS?$suffix',
      'https://news.google.com/rss/headlines/section/topic/TECHNOLOGY?$suffix',
      'https://news.google.com/rss/headlines/section/topic/SPORTS?$suffix',
      'https://news.google.com/rss/headlines/section/topic/ENTERTAINMENT?$suffix',
    ];
  }

  Future<List<_HomeNews>> _loadNews({bool forceRefresh = false}) async {
    final prefs = await SharedPreferences.getInstance();
    final cycle = DateTime.now().toUtc().millisecondsSinceEpoch ~/ Duration.millisecondsPerDay;
    final cacheKey = 'likedin_home_news_cycle_$cycle';
    final staleCacheKey = 'likedin_home_news_latest';
    for (final key in prefs.getKeys().where((key) => key.startsWith('likedin_home_news_cycle_') && key != cacheKey).toList()) { await prefs.remove(key); }
    if (!forceRefresh) {
      final cached = prefs.getString(cacheKey);
      if (cached != null) {
        try {
          final decoded = (jsonDecode(cached) as List).cast<Map>();
          return decoded
              .map((item) => _HomeNews(
                    title: item['title'].toString(),
                    url: item['url'].toString(),
                    source: item['source'].toString(),
                    published: item['published'] == null
                        ? null
                        : DateTime.tryParse(item['published'].toString()),
                  ))
              .toList();
        } catch (_) {
          await prefs.remove(cacheKey);
        }
      }
    }
    try {
      final responses = await Future.wait(_feeds.map((feed) async {
        try {
          return await _httpClient
              .get(Uri.parse(feed), headers: {'User-Agent': 'Likedin/$likedinVersion'})
              .timeout(const Duration(seconds: 10));
        } catch (_) {
          return null;
        }
      }));
      final all = <_HomeNews>[];
      final completeFeedFetch = responses.every((response) => response != null && response.statusCode == 200);
      for (final response in responses) {
        if (response == null || response.statusCode != 200) continue;
        try {
          final document = XmlDocument.parse(response.body);
          for (final item in document.findAllElements('item')) {
            String tag(String name) => _decodeXml(item.getElement(name)?.innerText.trim() ?? '');
            final title = tag('title');
            final link = tag('link');
            final pub = tag('pubDate');
            final source = tag('source');
            if (title.isEmpty || link.isEmpty) continue;
            all.add(_HomeNews(
              title: title,
              url: link,
              source: source.isNotEmpty
                  ? source
                  : (Uri.tryParse(link)?.host.replaceFirst('www.', '') ?? 'News'),
              published: DateTime.tryParse(pub) ?? _parseNewsDate(pub),
            ));
          }
        } catch (parseError) {
          debugPrint('News feed XML could not be parsed: $parseError');
        }
      }
      final seen = <String>{};
      final unique = all.where((n) => seen.add(n.title.toLowerCase())).toList();
      unique.sort((a, b) => (b.published ?? DateTime(2000)).compareTo(a.published ?? DateTime(2000)));
      final selected = unique.take(15).toList();
      if (selected.isEmpty && !completeFeedFetch) {
        final stale = prefs.getString(staleCacheKey);
        if (stale != null) {
          try {
            return (jsonDecode(stale) as List).cast<Map>().map((item) => _HomeNews(
              title: item['title'].toString(), url: item['url'].toString(),
              source: item['source'].toString(),
              published: item['published'] == null ? null : DateTime.tryParse(item['published'].toString()),
            )).toList();
          } catch (_) { await prefs.remove(staleCacheKey); }
        }
      }
      if (selected.isNotEmpty) {
        final encodedNews = jsonEncode(selected
              .map((n) => {
                    'title': n.title,
                    'url': n.url,
                    'source': n.source,
                    'published': n.published?.toIso8601String(),
                  })
              .toList());
        await prefs.setString(staleCacheKey, encodedNews);
        await prefs.setString(
          cacheKey,
          jsonEncode(selected
              .map((n) => {
                    'title': n.title,
                    'url': n.url,
                    'source': n.source,
                    'published': n.published?.toIso8601String(),
                  })
              .toList()),
        );
      }
      return selected;
    } finally {
      // _httpClient is shared across refreshes for TCP/TLS keep-alive.
    }
  }

  static String _decodeXml(String value) {
    // XmlDocument decodes the XML entity layer. This second pass handles RSS
    // titles that intentionally contain HTML entities as text, including
    // decimal and hexadecimal numeric references. Decode ampersand last.
    var decoded = value
        .replaceAll('&quot;', '"')
        .replaceAll('&apos;', "'")
        .replaceAll('&#39;', "'")
        .replaceAll('&nbsp;', ' ')
        .replaceAll('&ndash;', '–')
        .replaceAll('&mdash;', '—')
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>');
    decoded = decoded.replaceAllMapped(RegExp(r'&#(\d+);'), (match) {
      final code = int.tryParse(match.group(1) ?? '');
      return code == null || !_isValidXmlCodePoint(code) ? match.group(0)! : String.fromCharCode(code);
    });
    decoded = decoded.replaceAllMapped(RegExp(r'&#x([0-9a-fA-F]+);'), (match) {
      final code = int.tryParse(match.group(1) ?? '', radix: 16);
      return code == null || !_isValidXmlCodePoint(code) ? match.group(0)! : String.fromCharCode(code);
    });
    return decoded.replaceAll('&amp;', '&');
  }

  static bool _isValidXmlCodePoint(int code) =>
      code == 0x9 || code == 0xA || code == 0xD ||
      (code >= 0x20 && code <= 0xD7FF) ||
      (code >= 0xE000 && code <= 0xFFFD) ||
      (code >= 0x10000 && code <= 0x10FFFF);

  static DateTime? _parseNewsDate(String value) {
    try {
      return HttpDate.parse(value);
    } catch (_) {
      return null;
    }
  }

  String get _firstName {
    final name = widget.displayName.trim();
    if (name.isEmpty) return 'there';
    return name.split(RegExp(r'\s+')).first;
  }

  String get _greeting {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  }

  String _dateLabel(DateTime date) {
    return MaterialLocalizations.of(context).formatFullDate(date);
  }

  String _storyDate(DateTime? date) {
    if (date == null) return 'Latest update';
    final local = date.toLocal();
    final difference = DateTime.now().difference(local);
    if (difference.inMinutes < 60 && !difference.isNegative) {
      return '${difference.inMinutes.clamp(1, 59)} min ago';
    }
    if (difference.inHours < 24 && !difference.isNegative) {
      return '${difference.inHours.clamp(1, 23)} hr ago';
    }
    return MaterialLocalizations.of(context).formatMediumDate(local);
  }

  Future<void> _openStory(_HomeNews story) async {
    final uri = Uri.tryParse(story.url);
    if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('This story has an invalid or unsafe link.')),
        );
      }
      return;
    }
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not open this story.')),
        );
      }
    }
  }

  Widget _buildWelcomeCard(BuildContext context) {
    final now = DateTime.now();
    final dark = Theme.of(context).brightness == Brightness.dark;
    final secondary = dark ? const Color(0xFFA6B3CC) : const Color(0xFF55637C);

    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 14, 4, 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _dateLabel(now),
            style: TextStyle(
              color: secondary,
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            '$_greeting,\n$_firstName',
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 38,
              height: 1.06,
              fontWeight: FontWeight.w800,
              letterSpacing: -1.4,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeaturedStory(BuildContext context, _HomeNews story) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    final accent = likedinPrimary(brightness);
    return LikedinPressScale(
      child: GlassPanel(
        padding: EdgeInsets.zero,
        radius: BorderRadius.circular(24),
        glow: true,
        child: Material(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(24),
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: () => _openStory(story),
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    accent.withValues(alpha: dark ? .18 : .10),
                    Colors.transparent,
                  ],
                ),
              ),
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: accent.withValues(alpha: dark ? .24 : .14),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          'TOP STORY',
                          style: TextStyle(
                            color: accent,
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            letterSpacing: .8,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          _storyDate(story.published),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: Theme.of(context).hintColor,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      Icon(Icons.arrow_outward_rounded, color: accent, size: 18),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Text(
                    story.title,
                    style: const TextStyle(
                      fontSize: 22,
                      height: 1.24,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -.5,
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    story.source,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: accent,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStoryRow(BuildContext context, _HomeNews story, int index) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => _openStory(story),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      story.title,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 15,
                        height: 1.32,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '${story.source} · ${_storyDate(story.published)}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Theme.of(context).hintColor,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Icon(Icons.chevron_right_rounded, color: Theme.of(context).hintColor, size: 18),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNewsContent(BuildContext context) {
    return FutureBuilder<List<_HomeNews>>(
      future: _news,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Container(
            padding: const EdgeInsets.symmetric(vertical: 34),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: Theme.of(context).dividerColor.withValues(alpha: .75)),
            ),
            child: const Center(child: CircularProgressIndicator(strokeWidth: 2.5)),
          );
        }
        if (snapshot.hasError || !snapshot.hasData || snapshot.data!.isEmpty) {
          return Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: Theme.of(context).dividerColor.withValues(alpha: .75)),
            ),
            child: Column(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(color: brandBlue.withValues(alpha: .12), borderRadius: BorderRadius.circular(17)),
                  child: Icon(Icons.wifi_off_rounded, color: brandBlue, size: 25),
                ),
                const SizedBox(height: 13),
                const Text('Your briefing is taking a break', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
                const SizedBox(height: 5),
                Text('Check your connection and try loading the latest stories again.',
                    textAlign: TextAlign.center, style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12, height: 1.45)),
                const SizedBox(height: 13),
                OutlinedButton.icon(
                  onPressed: () => setState(() { _news = _loadNews(forceRefresh: true); _conversationTick++; }),
                  icon: const Icon(Icons.refresh_rounded, size: 17),
                  label: const Text('Try again'),
                ),
              ],
            ),
          );
        }

        final stories = snapshot.data!;
        // The briefing cache is refreshed daily; show that day's five newest
        // stories instead of keeping the visible selection on a three-day cycle.
        final todays = stories.take(5).toList();
        if (todays.isEmpty) {
          return Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: Theme.of(context).dividerColor.withValues(alpha: .75)),
            ),
            child: const Text('No stories are available in this rotation yet. Refresh to try again.'),
          );
        }

        return Column(
          children: [
            _buildFeaturedStory(context, todays.first),
            if (todays.length > 1) ...[
              const SizedBox(height: 12),
              GlassPanel(
                radius: BorderRadius.circular(22),
                child: Column(
                  children: [
                    for (var i = 1; i < todays.length; i++) ...[
                      _buildStoryRow(context, todays[i], i),
                      if (i != todays.length - 1)
                        Divider(
                          height: 1,
                          indent: 16,
                          endIndent: 16,
                          color: likedinOutline(Theme.of(context).brightness),
                        ),
                    ],
                  ],
                ),
              ),
            ],
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
        onRefresh: () async {
          final previous = _news;
          final next = _loadNews(forceRefresh: true);
          setState(() {
            _news = next;
            _conversationTick++;
          });
          try {
            await next;
          } catch (error) {
            debugPrint('Home refresh failed: $error');
            if (mounted) setState(() => _news = previous);
          }
        },
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
          // Extra bottom space keeps the last story clear of the compose button.
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 88),
          children: [
            _buildWelcomeCard(context),
            const SizedBox(height: 22),
            _buildConversationSection(context),
            const SizedBox(height: 28),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Today’s briefing',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: -.4),
                      ),
                    ],
                  ),
                ),
                IconButton.filledTonal(
                  tooltip: 'Refresh stories',
                  onPressed: () => setState(() { _news = _loadNews(forceRefresh: true); _conversationTick++; }),
                  icon: const Icon(Icons.refresh_rounded, size: 19),
                ),
              ],
            ),
            const SizedBox(height: 13),
            _buildNewsContent(context),
          ],
        ),
    );
  }
}

class _HomeNews {
  const _HomeNews({required this.title, required this.url, required this.source, this.published});
  final String title, url, source;
  final DateTime? published;
}

class StatusRow extends StatelessWidget {
  const StatusRow({
    required this.icon,
    required this.title,
    required this.subtitle,
    super.key,
  });
  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) => GlassPanel(
        padding: const EdgeInsets.all(14),
        radius: BorderRadius.circular(20),
        blur: 5,
        glow: false,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: brandBlue),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                  const SizedBox(height: 2),
                  Text(subtitle, style: TextStyle(fontSize: 13, height: 1.35, color: Theme.of(context).hintColor)),
                ],
              ),
            ),
          ],
        ),
      );
}



/// Private chat list shown only after the Home logo has unlocked the vault.
/// The conversation itself remains the existing ChatPage; this page is only
/// the authenticated entry/list surface.
class HiddenChatsPage extends StatelessWidget {
  const HiddenChatsPage({
    required this.onBack,
    required this.onOpenChat,
    required this.onUnhidden,
    required this.onChangePassword,
    super.key,
  });

  final VoidCallback onBack;
  final VoidCallback onOpenChat;
  final Future<void> Function() onUnhidden;
  final VoidCallback onChangePassword;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final muted = likedinMutedText(brightness);
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              IconButton(
                tooltip: 'Back to Home',
                onPressed: onBack,
                icon: const Icon(Icons.arrow_back_rounded),
              ),
              const SizedBox(width: 4),
              const Expanded(
                child: Text(
                  'Private chat',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
                ),
              ),
              IconButton(
                tooltip: 'Change hidden-chat password',
                onPressed: onChangePassword,
                icon: const Icon(Icons.key_rounded),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.only(left: 12, bottom: 16),
            child: Text(
              'Your conversation is hidden from the normal chat and calls navigation.',
              style: TextStyle(color: muted, fontSize: 13),
            ),
          ),
          ConversationCard(
            isHidden: true,
            onOpen: onOpenChat,
            onUnhidden: onUnhidden,
          ),
        ],
      ),
    );
  }
}
