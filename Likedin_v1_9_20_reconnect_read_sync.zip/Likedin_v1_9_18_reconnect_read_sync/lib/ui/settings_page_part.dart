part of '../main.dart';

class FilesPage extends StatefulWidget {
  const FilesPage({
    required this.store,
    required this.isActive,
    this.allowHiddenConversationMedia = false,
    super.key,
  });
  final AttachmentVaultStore store;
  final bool isActive;
  final bool allowHiddenConversationMedia;
  @override
  State<FilesPage> createState() => _FilesPageState();
}

class _FilesPageState extends State<FilesPage> {
  late Future<List<LocalAttachment>> files;
  late Future<List<Map<String, dynamic>>> sharedFiles;
  bool importing = false;

  @override
  void initState() {
    super.initState();
    refresh();
  }

  @override
  void didUpdateWidget(covariant FilesPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isActive && !oldWidget.isActive) {
      setState(refresh);
    }
  }

  void refresh() {
    files = widget.store.list();
    sharedFiles = _loadSharedFiles();
  }

  Future<List<Map<String, dynamic>>> _loadSharedFiles() async {
    final client = Supabase.instance.client;
    final uid = client.auth.currentUser?.id;
    if (uid == null) return [];
    // This app currently has one active peer. Hide that peer's shared media
    // from the Files gallery while the conversation is hidden, so the gallery
    // cannot become a side door around the chat password.
    try {
      final hiddenIds = await HiddenChatVault().listHiddenChatIds(uid);
      final activePeerId = await RealtimeMessagingService(client).getPeerId();
      if (activePeerId != null &&
          hiddenIds.contains(activePeerId) &&
          !widget.allowHiddenConversationMedia) {
        return <Map<String, dynamic>>[];
      }
    } catch (error) {
      debugPrint('Hidden-chat media access could not be verified: $error');
      return <Map<String, dynamic>>[]; // Fail closed.
    }
    final hiddenIds = <String>{};
    final postClearVisibleIds = <String>{};
    int? clearedBeforeMs;
    try {
      final peer = await RealtimeMessagingService(client).getPeerId();
      if (peer != null) {
        final rawState = await const FlutterSecureStorage().read(
          key: 'likedin_local_chat_v1_${uid}_$peer',
        );
        if (rawState != null && rawState.isNotEmpty) {
          final data = Map<String, dynamic>.from(jsonDecode(rawState) as Map);
          hiddenIds.addAll((data['hidden'] as List? ?? const []).map((e) => e.toString()));
          postClearVisibleIds.addAll((data['postClearVisible'] as List? ?? const []).map((e) => e.toString()));
          clearedBeforeMs = data['clearedBeforeMs'] as int?;
        }
      }
    } catch (_) {}

    final result = <Map<String, dynamic>>[];
    const pageSize = 100;
    const maxPages = 20; // At most 2,000 recent messages are scanned here.
    var pageIndex = 0;
    DateTime? beforeCreatedAt;
    String? beforeId;
    while (pageIndex < maxPages) {
      pageIndex++;
      var query = client
          .from('messages')
          .select()
          .isFilter('deleted_for_everyone_at', null)
          .like('encrypted_payload', '%"__likedin_media_v1":true%');
      if (beforeCreatedAt == null) {
        query = query.or('sender_id.eq.$uid,recipient_id.eq.$uid');
      } else {
        final stamp = beforeCreatedAt.toUtc().toIso8601String();
        query = query.or(
          'and(sender_id.eq.$uid,created_at.lt.$stamp),'
          'and(recipient_id.eq.$uid,created_at.lt.$stamp),'
          'and(sender_id.eq.$uid,created_at.eq.$stamp,id.lt.$beforeId),'
          'and(recipient_id.eq.$uid,created_at.eq.$stamp,id.lt.$beforeId)',
        );
      }
      final rows = await query
          .order('created_at', ascending: false)
          .order('id', ascending: false)
          .limit(pageSize);
      if (rows.isEmpty) break;
      for (final row in rows) {
        final rowId = row['id']?.toString() ?? '';
        final clientMessageId = row['client_message_id']?.toString();
        if (hiddenIds.contains(rowId) ||
            (clientMessageId != null && hiddenIds.contains(clientMessageId))) {
          continue;
        }
        final isPostClearException = postClearVisibleIds.contains(rowId) ||
            (clientMessageId != null && postClearVisibleIds.contains(clientMessageId));
        final createdAt = DateTime.tryParse(row['created_at']?.toString() ?? '');
        if (!isPostClearException && clearedBeforeMs != null &&
            createdAt != null &&
            createdAt.millisecondsSinceEpoch <= clearedBeforeMs) {
          continue;
        }
        final raw =
            (row['body_payload'] ?? row['encrypted_payload'] ?? row['ciphertext'])?.toString() ?? '';
        final payload = SharedMediaService(client).decode(raw);
        if (payload != null) {
          result.add({
            ...payload,
            'created_at': row['created_at'],
            'sender_id': row['sender_id'],
          });
        }
      }
      final oldest = rows.last;
      beforeCreatedAt = DateTime.parse(oldest['created_at'].toString());
      beforeId = oldest['id']?.toString();
      if (rows.length < pageSize || beforeId == null || beforeId.isEmpty) break;
    }
    return result;
  }

  Future<void> _openShared(Map<String, dynamic> payload) async {
    final kind = payload['kind']?.toString() ?? 'file';
    final title = payload['name']?.toString() ?? 'Attachment';
    if (kind == 'audio') {
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: Text(title),
          content: _VoiceMessagePlayer(payload: payload),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Close'),
            ),
          ],
        ),
      );
      return;
    }
    if (kind != 'image' && kind != 'video') {
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Save shared document?'),
          content: Text('Save $title to the Downloads folder on this phone?'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Save')),
          ],
        ),
      );
      if (confirmed == true) await _saveShared(payload);
      return;
    }
    try {
      final file = await SharedMediaService(Supabase.instance.client).cachedFile(payload);
      if (!mounted) return;
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => kind == 'image'
              ? _LikedinImageViewer(file: file, title: title)
              : _LikedinVideoViewer(file: file, title: title),
        ),
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not open this attachment. Please try again.')),
        );
      }
    }
  }

  Future<void> _openLocal(LocalAttachment attachment) async {
    final file = File(attachment.path);
    if (!await file.exists()) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('This local file is no longer available.')),
        );
      }
      return;
    }
    final ext = p.extension(attachment.name).toLowerCase();
    if (['.jpg', '.jpeg', '.png', '.webp', '.gif'].contains(ext)) {
      if (!mounted) return;
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => _LikedinImageViewer(file: file, title: attachment.name),
        ),
      );
      return;
    }
    if (['.mp4', '.mov', '.webm', '.mkv', '.3gp'].contains(ext)) {
      if (!mounted) return;
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => _LikedinVideoViewer(file: file, title: attachment.name),
        ),
      );
      return;
    }
    try {
      await const MethodChannel('com.example.likedin/downloads').invokeMethod<bool>('openLocalFile', {
        'sourcePath': file.path,
        'displayName': attachment.name,
      });
        } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No compatible app could open this file.')),
        );
      }
    }
  }

  Future<void> _saveShared(Map<String, dynamic> payload) async {
    try {
      final saved =
          await SharedMediaService(Supabase.instance.client).downloadToPublicDownloads(payload);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Saved $saved to Downloads.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Download failed. Check your connection and storage, then try again.')),
        );
      }
    }
  }

  Future<void> importFiles() async {
    setState(() => importing = true);
    try {
      final saved = await widget.store.importFiles();
      if (!mounted) return;
      setState(refresh);
      if (saved.isNotEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${saved.length} file(s) copied into Likedin Downloads.')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not import those files.')),
        );
      }
    } finally {
      if (mounted) setState(() => importing = false);
    }
  }

  Future<void> deleteLocal(LocalAttachment file) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete downloaded copy?'),
        content: Text(
          'This deletes ${file.name} from this phone only. It does not delete any copy on another device or in cloud storage.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete from phone'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await widget.store.deleteLocal(file);
    if (mounted) setState(refresh);
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<List<LocalAttachment>>(
        future: files,
        builder: (context, snapshot) {
          final items = snapshot.data ?? const <LocalAttachment>[];
          final totalBytes = items.fold<int>(0, (sum, item) => sum + item.sizeBytes);
          return RefreshIndicator(
            onRefresh: () async {
              setState(refresh);
              try { await Future.wait([files, sharedFiles]); } catch (error) {
                debugPrint('Files refresh failed: $error');
              }
            },
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(0, 8, 0, 0),
                  child: Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'Files',
                          style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, letterSpacing: -1.1),
                        ),
                      ),
                      IconButton(
                        tooltip: 'Refresh',
                        onPressed: () => setState(refresh),
                        icon: const Icon(Icons.refresh_rounded),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Keep a copy on this phone before a shared cloud attachment is removed.',
                  style: TextStyle(
                    height: 1.4,
                    fontSize: 14,
                    color: Theme.of(context).hintColor,
                  ),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: importing ? null : importFiles,
                    icon: const Icon(Icons.download_outlined),
                    label: Text(importing ? 'Saving…' : 'Save files to this phone'),
                  ),
                ),
                const SizedBox(height: 26),
                const Text(
                  'Recent shared items',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: -.4),
                ),
                const SizedBox(height: 10),
                FutureBuilder<List<Map<String, dynamic>>>(
                  future: sharedFiles,
                  builder: (context, sharedSnapshot) {
                    final shared = sharedSnapshot.data ?? const <Map<String, dynamic>>[];
                    if (sharedSnapshot.connectionState == ConnectionState.waiting) {
                      return const Padding(
                        padding: EdgeInsets.all(18),
                        child: Center(child: CircularProgressIndicator()),
                      );
                    }
                    if (sharedSnapshot.hasError) {
                      return const Text('Could not load shared attachments.');
                    }
                    if (shared.isEmpty) {
                      return const Padding(
                        padding: EdgeInsets.symmetric(vertical: 12),
                        child: Text('No shared files yet.'),
                      );
                    }
                    return Column(
                      children: shared.map((item) {
                        final kind = item['kind']?.toString() ?? 'file';
                        final name = item['name']?.toString() ?? 'Attachment';
                        final icon = kind == 'image'
                            ? Icons.image_outlined
                            : kind == 'video'
                                ? Icons.video_file_outlined
                                : kind == 'audio'
                                    ? Icons.mic_none_rounded
                                    : Icons.insert_drive_file_outlined;
                        final when =
                            DateTime.tryParse(item['created_at']?.toString() ?? '')?.toLocal();
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: GlassPanel(
                            padding: EdgeInsets.zero,
                            radius: BorderRadius.circular(20),
                            blur: 5,
                            glow: false,
                            child: ListTile(
                            onTap: () => _openShared(item),
                            leading: CircleAvatar(
                              backgroundColor: brandBlue.withValues(alpha: .12),
                              child: Icon(icon, color: brandBlue),
                            ),
                            title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis),
                            subtitle: Text(
                              '${kind.isEmpty ? 'File' : '${kind[0].toUpperCase()}${kind.substring(1)}'}, ${when == null ? 'shared attachment' : '${MaterialLocalizations.of(context).formatMediumDate(when)} · ${MaterialLocalizations.of(context).formatTimeOfDay(TimeOfDay.fromDateTime(when))}'}',
                            ),
                            trailing: IconButton(
                              tooltip: 'Save to Downloads',
                              onPressed: () => _saveShared(item),
                              icon: const Icon(Icons.download_outlined),
                            ),
                          ),
                          ),
                        );
                      }).toList(),
                    );
                  },
                ),
                const SizedBox(height: 14),
                GlassPanel(
                  padding: const EdgeInsets.all(14),
                  radius: BorderRadius.circular(20),
                  blur: 5,
                  glow: false,
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.phone_android_rounded, color: brandBlue),
                            const SizedBox(width: 10),
                            const Text(
                              'On this phone',
                              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          '${items.length} ${items.length == 1 ? 'file' : 'files'} using ${(totalBytes / (1024 * 1024)).toStringAsFixed(1)} MB',
                          style: TextStyle(color: Theme.of(context).hintColor),
                        ),
                      ],
                    ),
                ),
                const SizedBox(height: 12),
                if (snapshot.connectionState == ConnectionState.waiting)
                  const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: CircularProgressIndicator(),
                    ),
                  ),
                if (snapshot.hasError) const Text('Could not load your saved files.'),
                if (snapshot.connectionState != ConnectionState.waiting && items.isEmpty)
                  GlassPanel(
                    padding: const EdgeInsets.all(28),
                    radius: BorderRadius.circular(22),
                    blur: 5,
                    glow: false,
                    child: const Column(
                      children: [
                        Icon(Icons.folder_open_outlined, size: 42),
                        SizedBox(height: 10),
                        Text('No saved files yet', style: TextStyle(fontWeight: FontWeight.w700)),
                        SizedBox(height: 5),
                        Text(
                          'Tap “Save files” to copy photos, videos or documents into Likedin Downloads.',
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                ...items.map(
                  (file) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: GlassPanel(
                      padding: EdgeInsets.zero,
                      radius: BorderRadius.circular(20),
                      blur: 5,
                      glow: false,
                      child: ListTile(
                      onTap: () => _openLocal(file),
                      leading: CircleAvatar(
                        backgroundColor: brandBlue.withValues(alpha: .12),
                        child: Icon(Icons.insert_drive_file_outlined, color: brandBlue),
                      ),
                      title: Text(file.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text('${file.readableSize}, saved on this phone'),
                      trailing: IconButton(
                        tooltip: 'Delete local copy',
                        onPressed: () => deleteLocal(file),
                        icon: const Icon(Icons.delete_outline, color: Color(0xFFB42318)),
                      ),
                    ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      );
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({
    required this.account,
    required this.onSignOut,
    required this.attachmentVault,
    super.key,
  });
  final LikedinAccount account;
  final Future<void> Function() onSignOut;
  final AttachmentVaultStore attachmentVault;
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> with WidgetsBindingObserver {
  bool get dark => likedinThemeMode.value == ThemeMode.dark;

  Future<void> _confirmSignOut() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Sign out?'),
        content: const Text('You can sign back in with your account credentials.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Sign out')),
        ],
      ),
    );
    if (confirmed == true) await widget.onSignOut();
  }
  bool _testingNotification = false;
  bool _checkingUpdates = false;
  bool _biometricAvailable = false;
  bool _biometricEnabled = true;
  bool _e2eeBusy = false;

  Future<void> _checkForUpdates() async {
    if (_checkingUpdates) return;
    setState(() => _checkingUpdates = true);
    try {
      await AppUpdater.checkAndPrompt(
        context,
        currentVersion: likedinVersion,
        manual: true,
      );
    } finally {
      if (mounted) setState(() => _checkingUpdates = false);
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refreshNotificationStatus();
    unawaited(_loadSecurityControls());
  }

  Future<void> _loadSecurityControls() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final enabled = prefs.getBool(likedinHiddenBiometricPrefKey) ?? true;
      final available = await _hiddenChatSecurityChannel
          .invokeMethod<bool>('canAuthenticateBiometric') ?? false;
      final client = Supabase.instance.client;
      final uid = client.auth.currentUser?.id;
      if (uid != null && !E2eeService.instance.isActive) {
        final peer = await RealtimeMessagingService(client).getPeerId();
        if (peer != null) {
          await E2eeService.instance.initialize(client, userId: uid, peerId: peer);
        }
      }
      if (mounted) {
        setState(() {
          _biometricAvailable = available;
          _biometricEnabled = enabled;
        });
      }
    } catch (_) {}
  }

  Future<void> _setBiometricEnabled(bool value) async {
    setState(() => _biometricEnabled = value);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(likedinHiddenBiometricPrefKey, value);
    } catch (_) {}
  }

  Future<void> _runE2eePassphraseFlow({required bool restore}) async {
    if (_e2eeBusy) return;
    final passController = TextEditingController();
    final confirmController = TextEditingController();
    String? validationError;
    final passphrase = await showDialog<String>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, updateDialog) => AlertDialog(
          title: Text(restore ? 'Restore E2EE key' : 'Back up E2EE key'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                restore
                    ? 'Enter your recovery passphrase to restore your private E2EE key and unlock encrypted history on this phone.'
                    : 'Your private key is encrypted on this phone with your passphrase before saving to Supabase so you can recover encrypted messages if you switch phones.',
                style: const TextStyle(fontSize: 12, height: 1.35),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: passController,
                obscureText: true,
                textInputAction: restore ? TextInputAction.done : TextInputAction.next,
                decoration: const InputDecoration(
                  labelText: 'Recovery passphrase (12+ characters)',
                ),
              ),
              if (!restore) ...[
                const SizedBox(height: 10),
                TextField(
                  controller: confirmController,
                  obscureText: true,
                  textInputAction: TextInputAction.done,
                  decoration: const InputDecoration(labelText: 'Confirm recovery passphrase'),
                ),
              ],
              if (validationError != null) ...[
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    validationError!,
                    style: TextStyle(color: Theme.of(context).colorScheme.error, fontSize: 12),
                  ),
                ),
              ],
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
            FilledButton(
              onPressed: () {
                final value = passController.text;
                if (value.length < 12) {
                  updateDialog(() => validationError = 'Use at least 12 characters.');
                  return;
                }
                if (!restore && value != confirmController.text) {
                  updateDialog(() => validationError = 'The passphrases do not match.');
                  return;
                }
                Navigator.pop(dialogContext, value);
              },
              child: Text(restore ? 'Restore' : 'Back up'),
            ),
          ],
        ),
      ),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      passController.dispose();
      confirmController.dispose();
    });
    if (passphrase == null || !mounted) return;
    setState(() => _e2eeBusy = true);
    final messenger = ScaffoldMessenger.of(context);
    try {
      if (restore) {
        await E2eeService.instance.restoreKeyWithPassphrase(Supabase.instance.client, passphrase);
        if (mounted) {
          messenger.showSnackBar(
            const SnackBar(content: Text('E2EE key restored! Encrypted messages are now readable.')),
          );
        }
      } else {
        await E2eeService.instance.backupKeyWithPassphrase(Supabase.instance.client, passphrase);
        if (mounted) {
          messenger.showSnackBar(
            const SnackBar(content: Text('Encrypted E2EE key backup saved to your account.')),
          );
        }
      }
    } catch (error) {
      if (mounted) {
        final msg = error is StateError
            ? error.message.toString()
            : 'Could not complete E2EE key ${restore ? 'restore' : 'backup'}. Make sure the likedin_e2ee_keys table is created in Supabase.';
        messenger.showSnackBar(SnackBar(content: Text(msg)));
      }
    } finally {
      if (mounted) setState(() => _e2eeBusy = false);
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _refreshNotificationStatus();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> _refreshNotificationStatus() async {
    await LikedinNotificationService.instance.registerCurrentToken();
    await LikedinNotificationService.instance.refreshNotificationPermissionStatus();
    if (mounted) setState(() {});
  }

  Future<void> _sendNotificationTest() async {
    if (_testingNotification) return;
    setState(() => _testingNotification = true);
    final result = await LikedinNotificationService.instance.showTestNotification();
    if (!mounted) return;
    setState(() => _testingNotification = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(result.message), duration: const Duration(seconds: 7)),
    );
    await _refreshNotificationStatus();
  }

  Future<void> _setDark(bool value) async {
    await setLikedinDarkMode(value);
    if (mounted) setState(() {});
  }

  Future<void> _exportEncryptedBackup() async {
    // Backup export is another route to the conversation contents, so it must
    // honor the hidden-chat password gate as well.
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (uid != null) {
      final hiddenVault = HiddenChatVault();
      if (await hiddenVault.hasHiddenChats(uid)) {
        if (!mounted) return;
        final hiddenPassword = await HiddenChatPinDialog.show(context, setup: false);
        if (!mounted || hiddenPassword == null) return;
        if (hiddenPassword.requestRecovery) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Reset the hidden-chats password from the Hidden chats section on Home, then retry the backup.')),
          );
          return;
        }
        final valid = hiddenPassword.password != null &&
            await hiddenVault.verifyPassword(uid, hiddenPassword.password!);
        if (!mounted) return;
        if (!valid) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Incorrect hidden-chats password. Backup was not created.')),
          );
          return;
        }
      }
    }
    if (!mounted) return;
    final passController = TextEditingController();
    final confirmController = TextEditingController();
    String? validationError;
    final passphrase = await showDialog<String>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, updateDialog) => AlertDialog(
          title: const Text('Encrypt chat backup'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: passController,
                obscureText: true,
                autofillHints: const [AutofillHints.newPassword],
                textInputAction: TextInputAction.next,
                decoration: const InputDecoration(
                  labelText: 'Passphrase (12+ characters)',
                  hintText: 'Enter a strong passphrase',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: confirmController,
                obscureText: true,
                textInputAction: TextInputAction.done,
                decoration: const InputDecoration(labelText: 'Confirm passphrase'),
              ),
              if (validationError != null) ...[
                const SizedBox(height: 8),
                Align(alignment: Alignment.centerLeft, child: Text(validationError!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
              ],
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
            FilledButton(
              onPressed: () {
                final value = passController.text;
                if (value.length < 12) {
                  updateDialog(() => validationError = 'Use at least 12 characters.');
                  return;
                }
                if (value != confirmController.text) {
                  updateDialog(() => validationError = 'The passphrases do not match.');
                  return;
                }
                Navigator.pop(dialogContext, value);
              },
              child: const Text('Export'),
            ),
          ],
        ),
      ),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      passController.dispose();
      confirmController.dispose();
    });
    if (passphrase == null || !mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    try {
      final service = RealtimeMessagingService(Supabase.instance.client);
      final allMessages = await service.loadAllConversation();
      final uid = service.currentUserId;
      final peerId = await service.getPeerId();
      final hiddenIds = <String>{};
      final postClearVisibleIds = <String>{};
      int? clearedBeforeMs;
      if (peerId != null) {
        try {
          final rawState = await const FlutterSecureStorage().read(
            key: 'likedin_local_chat_v1_${uid}_$peerId',
          );
          if (rawState != null && rawState.isNotEmpty) {
            final localState = Map<String, dynamic>.from(jsonDecode(rawState) as Map);
            hiddenIds.addAll((localState['hidden'] as List? ?? const []).map((value) => value.toString()));
            postClearVisibleIds.addAll((localState['postClearVisible'] as List? ?? const []).map((value) => value.toString()));
            clearedBeforeMs = localState['clearedBeforeMs'] as int?;
          }
        } catch (error) {
          debugPrint('Local chat visibility could not be read for backup: $error');
        }
      }
      final completeConversation = ChatInfoMetrics.visibleMessages(
        allMessages,
        hiddenMessageIds: hiddenIds,
        clearedBeforeMs: clearedBeforeMs,
        postClearVisibleMessageIds: postClearVisibleIds,
      );
      final payload = jsonEncode({
        'format': 'project-whisper-backup',
        'version': 1,
        'createdAt': DateTime.now().toUtc().toIso8601String(),
        'messages': completeConversation
            .map((m) => {
                  'id': m.id,
                  'senderId': m.senderId,
                  'recipientId': m.recipientId,
                  'text': m.text,
                  'createdAt': m.createdAt.toUtc().toIso8601String(),
                })
            .toList(),
      });
      final encrypted = await EncryptedBackupCodec().encrypt(payload, passphrase);
      final tempDir = await getTemporaryDirectory();
      final stamp = DateTime.now().millisecondsSinceEpoch;
      final fileName = 'likedin_backup_$stamp.json';
      final tempFile = File(p.join(tempDir.path, fileName));
      await tempFile.writeAsBytes(encrypted, flush: true);
      try {
        final saved = await const MethodChannel('com.example.likedin/downloads')
                .invokeMethod<String>('saveToDownloads', {
              'sourcePath': tempFile.path,
              'displayName': fileName,
              'mimeType': 'application/json',
            }) ??
            fileName;
        if (!mounted) return;
        messenger.showSnackBar(
          SnackBar(content: Text('Encrypted backup saved to Downloads as $saved. ${completeConversation.length} messages included.')),
        );
      } finally {
        if (await tempFile.exists()) await tempFile.delete();
      }
    } catch (error) {
      debugPrint('Encrypted backup export failed: $error');
      if (!mounted) return;
      messenger.showSnackBar(
        const SnackBar(content: Text('Could not export backup. Check your connection and available storage, then try again.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 118),
        children: [
          const Text(
            'Settings',
            style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, letterSpacing: -1.1),
          ),
          const SizedBox(height: 16),
          const _SettingsHeading('Account and profile'),
          GlassPanel(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            radius: BorderRadius.circular(20),
            blur: 5,
            glow: false,
            child: Row(
                children: [
                  CircleAvatar(
                    radius: 24,
                    backgroundColor: brandBlue.withValues(alpha: .14),
                    child: Text(
                      widget.account.displayName.trim().isEmpty
                          ? '?'
                          : String.fromCharCode(widget.account.displayName.trim().runes.first).toUpperCase(),
                      style: TextStyle(color: brandBlue, fontSize: 20, fontWeight: FontWeight.w800),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          widget.account.displayName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          widget.account.likedinId,
                          maxLines: 1,
                          softWrap: false,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .68),
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 4),
                  IconButton(
                    tooltip: 'Sign out',
                    onPressed: _confirmSignOut,
                    icon: const Icon(Icons.logout_rounded, color: Color(0xFFB42318)),
                  ),
                ],
              ),
          ),
          const SizedBox(height: 26),
          const _SettingsHeading('Appearance and themes'),
          GlassPanel(
            padding: EdgeInsets.zero,
            radius: BorderRadius.circular(20),
            child: Column(
              children: [
                ValueListenableBuilder<ThemeMode>(
                  valueListenable: likedinThemeMode,
                  builder: (context, mode, _) => SwitchListTile.adaptive(
                    value: mode == ThemeMode.dark,
                    onChanged: _setDark,
                    secondary: Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: const Color(0xFF4C8BF5).withValues(alpha: .15),
                        borderRadius: BorderRadius.circular(11),
                      ),
                      child: Icon(
                        mode == ThemeMode.dark ? Icons.dark_mode_outlined : Icons.light_mode_outlined,
                        color: const Color(0xFF4C8BF5),
                        size: 19,
                      ),
                    ),
                    title: Text(mode == ThemeMode.dark ? 'Obsidian Glass' : 'Arctic Glass'),
                    subtitle: const Text('Turn on for the dark Obsidian theme; off uses light Arctic.'),
                  ),
                ),
                Divider(height: 1, indent: 62, endIndent: 14, color: likedinOutline(Theme.of(context).brightness)),
                _SettingsNavTile(
                  icon: Icons.palette_outlined,
                  badgeColor: const Color(0xFF9B6BFF),
                  title: 'Theme customization',
                  subtitle: 'Accent colour, chat bubbles, effects and motion',
                  onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
                    builder: (_) => ThemeCustomizationPage(
                      themeMode: likedinThemeMode,
                      onSetDark: setLikedinDarkMode,
                    ),
                  )),
                ),
              ],
            ),
          ),
          const SizedBox(height: 26),
          const _SettingsHeading('Notifications'),
          GlassPanel(
            padding: const EdgeInsets.all(14),
            radius: BorderRadius.circular(20),
            blur: 5,
            glow: false,
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 34,
                        height: 34,
                        decoration: BoxDecoration(
                          color: const Color(0xFFF59E0B).withValues(alpha: .15),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.notifications_active_outlined, color: Color(0xFFF59E0B), size: 19),
                      ),
                      const SizedBox(width: 10),
                      const Text('Notifications', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Android app permission: ${LikedinNotificationService.instance.notificationsAllowed == null ? 'Unknown' : LikedinNotificationService.instance.notificationsAllowed! ? 'Allowed' : 'Blocked'}',
                  ),
                  if (LikedinNotificationService.instance.notificationsAllowed == false) ...[
                    const SizedBox(height: 4),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: TextButton.icon(
                        onPressed: () async {
                          await openAppSettings();
                          await _refreshNotificationStatus();
                        },
                        icon: const Icon(Icons.settings_outlined),
                        label: const Text('Open Android notification settings'),
                      ),
                    ),
                  ],
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: _testingNotification ? null : _sendNotificationTest,
                      icon: _testingNotification
                          ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.notifications_outlined),
                      label: Text(_testingNotification ? 'Posting test…' : 'Send test notification'),
                    ),
                  ),

                ],
              ),
          ),
          const SizedBox(height: 26),
          const _SettingsHeading('Privacy and security'),
          const StatusRow(
            icon: Icons.key_outlined,
            title: 'Local chat state',
            subtitle: 'Protected through Android Keystore secure storage',
          ),
          const SizedBox(height: 8),
          GlassPanel(
            padding: const EdgeInsets.all(14),
            radius: BorderRadius.circular(20),
            blur: 5,
            glow: false,
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 34,
                        height: 34,
                        decoration: BoxDecoration(
                          color: const Color(0xFF2FBF86).withValues(alpha: .15),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.backup_outlined, color: Color(0xFF2FBF86), size: 19),
                      ),
                      const SizedBox(width: 10),
                      const Text('Encrypted chat backup', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                    ],
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Export a password-encrypted AES-256-GCM snapshot of all messages visible in this chat on this device to Downloads.',
                    style: TextStyle(fontSize: 12),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: _exportEncryptedBackup,
                      icon: const Icon(Icons.lock_outline, size: 18),
                      label: const Text('Export encrypted backup'),
                    ),
                  ),
                ],
              ),
          ),
          const SizedBox(height: 8),
          ValueListenableBuilder<bool>(
            valueListenable: E2eeService.instance.activeNotifier,
            builder: (context, e2eeActive, _) {
              final fingerprint = E2eeService.instance.safetyFingerprint;
              return GlassPanel(
                padding: const EdgeInsets.all(14),
                radius: BorderRadius.circular(20),
                blur: 5,
                glow: false,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 34,
                          height: 34,
                          decoration: BoxDecoration(
                            color: (e2eeActive ? const Color(0xFF2FBF86) : const Color(0xFF4C8BF5))
                                .withValues(alpha: .15),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Icon(
                            e2eeActive ? Icons.enhanced_encryption_rounded : Icons.lock_clock_outlined,
                            color: e2eeActive ? const Color(0xFF2FBF86) : const Color(0xFF4C8BF5),
                            size: 19,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'End-to-End Encryption (E2EE)',
                                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                              ),
                              Text(
                                e2eeActive
                                    ? 'Active for text & media · X25519 + AES-256-GCM'
                                    : 'Compatibility mode · waiting for your friend to update',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: e2eeActive
                                      ? const Color(0xFF2FBF86)
                                      : Theme.of(context).hintColor,
                                  fontWeight: e2eeActive ? FontWeight.w600 : FontWeight.w400,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    if (fingerprint != null) ...[
                      const SizedBox(height: 10),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: likedinSurfaceRaised(Theme.of(context).brightness),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Safety fingerprint (compare on both phones)',
                              style: TextStyle(fontSize: 11, color: Theme.of(context).hintColor),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              fingerprint,
                              style: const TextStyle(
                                fontFamily: 'monospace',
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                                letterSpacing: .8,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: _e2eeBusy ? null : () => _runE2eePassphraseFlow(restore: false),
                            icon: const Icon(Icons.key_rounded, size: 17),
                            label: const Text('Back up key'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: _e2eeBusy ? null : () => _runE2eePassphraseFlow(restore: true),
                            icon: const Icon(Icons.restore_rounded, size: 17),
                            label: const Text('Restore key'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            },
          ),
          if (_biometricAvailable) ...[
            const SizedBox(height: 8),
            GlassPanel(
              padding: EdgeInsets.zero,
              radius: BorderRadius.circular(20),
              child: SwitchListTile.adaptive(
                value: _biometricEnabled,
                onChanged: _setBiometricEnabled,
                secondary: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: const Color(0xFF9B6BFF).withValues(alpha: .15),
                    borderRadius: BorderRadius.circular(11),
                  ),
                  child: const Icon(Icons.fingerprint_rounded, color: Color(0xFF9B6BFF), size: 20),
                ),
                title: const Text('Fingerprint unlock for hidden chats', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                subtitle: const Text('Use fingerprint when tapping the Home logo; password remains fallback.', style: TextStyle(fontSize: 12)),
              ),
            ),
          ],
          const SizedBox(height: 26),
          const _SettingsHeading('Media and storage'),
          GlassPanel(
            padding: EdgeInsets.zero,
            radius: BorderRadius.circular(20),
            child: _SettingsNavTile(
              icon: Icons.pie_chart_outline_rounded,
              badgeColor: const Color(0xFF2FBF86),
              title: 'Storage and media',
              subtitle: 'See what uses space, clear cache and retry uploads',
              onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
                builder: (_) => StoragePage(store: widget.attachmentVault),
              )),
            ),
          ),
          const SizedBox(height: 26),
          const _SettingsHeading('About Likedin'),
          GlassPanel(
            padding: EdgeInsets.zero,
            radius: BorderRadius.circular(20),
            child: Column(
              children: [
                _SettingsNavTile(
                  icon: Icons.system_update_rounded,
                  badgeColor: const Color(0xFF4C8BF5),
                  title: _checkingUpdates ? 'Checking for updates…' : 'Check for updates',
                  subtitle: 'Download and install new releases automatically',
                  onTap: _checkingUpdates ? () {} : _checkForUpdates,
                ),
                Divider(height: 1, indent: 62, endIndent: 14, color: likedinOutline(Theme.of(context).brightness)),
                ListTile(
                  leading: Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: const Color(0xFF9B6BFF).withValues(alpha: .15),
                      borderRadius: BorderRadius.circular(11),
                    ),
                    child: const Icon(Icons.info_outline, color: Color(0xFF9B6BFF), size: 19),
                  ),
                  title: const Text('Likedin', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                  subtitle: const Text('Version $likedinVersion', style: TextStyle(fontSize: 12)),
                ),
              ],
            ),
          ),
        ],
      );
}

class _SettingsNavTile extends StatelessWidget {
  const _SettingsNavTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.badgeColor = const Color(0xFF4C8BF5),
  });
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final Color badgeColor;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    return ListTile(
      onTap: onTap,
      leading: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: badgeColor.withValues(alpha: .15),
          borderRadius: BorderRadius.circular(11),
        ),
        child: Icon(icon, color: badgeColor, size: 19),
      ),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
      subtitle: Text(subtitle, style: const TextStyle(fontSize: 12)),
      trailing: Icon(Icons.chevron_right_rounded, color: likedinMutedText(brightness)),
    );
  }
}

class _SettingsHeading extends StatelessWidget {
  const _SettingsHeading(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 0, 4, 10),
        child: Text(
          text,
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: -.4),
        ),
      );
}

