import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ---------------------------------------------------------------------------
// Likedin design system: Obsidian Glass (dark) and Arctic Glass (light).
//
// Rules from the 15-screen specification:
//  * Readable first: glass never lowers text contrast.
//  * Controlled depth: real backdrop blur is opt-in (`frosted`) and only used
//    on a few surfaces (auth panel, bars, sheets). Everyday rows use a cheap
//    translucent fill + hairline highlight instead.
//  * Performance aware: the user can pick Full / Lighter / Off effects and
//    reduced motion; both are persisted and respected by shared widgets.
// ---------------------------------------------------------------------------

/// Accent choices. Each has a value tuned for text/controls on dark (Obsidian)
/// and on light (Arctic) surfaces so an accent can never drop below readable
/// contrast; [gradientEnd] is the cyan-leaning end of the primary gradient.
class LikedinAccent {
  const LikedinAccent({
    required this.name,
    required this.dark,
    required this.light,
    required this.gradientEnd,
  });

  final String name;
  final Color dark;
  final Color light;
  final Color gradientEnd;

  Color forBrightness(Brightness b) => b == Brightness.dark ? dark : light;
}

const List<LikedinAccent> likedinAccents = [
  LikedinAccent(
    name: 'Electric blue',
    dark: Color(0xFF6FA8FF),
    light: Color(0xFF0A5FD0),
    gradientEnd: Color(0xFF22D3EE),
  ),
  LikedinAccent(
    name: 'Cyan',
    dark: Color(0xFF3DD6F5),
    light: Color(0xFF00758F),
    gradientEnd: Color(0xFF5EEAD4),
  ),
  LikedinAccent(
    name: 'Violet',
    dark: Color(0xFFB39DFF),
    light: Color(0xFF5B3FD6),
    gradientEnd: Color(0xFF7DB8FF),
  ),
  LikedinAccent(
    name: 'Emerald',
    dark: Color(0xFF4FDBA5),
    light: Color(0xFF0B7A55),
    gradientEnd: Color(0xFF5EE1E8),
  ),
  LikedinAccent(
    name: 'Rose',
    dark: Color(0xFFFF8FB1),
    light: Color(0xFFC2255C),
    gradientEnd: Color(0xFFFFB08A),
  ),
];

enum LikedinEffects { full, lighter, off }

/// Persisted appearance preferences shared by every screen.
class LikedinAppearance {
  LikedinAppearance._();

  static const _accentKey = 'likedin_accent_index_v1';
  static const _effectsKey = 'likedin_effects_level_v1';
  static const _motionKey = 'likedin_reduce_motion_v1';

  static final ValueNotifier<int> accentIndex = ValueNotifier<int>(0);
  static final ValueNotifier<LikedinEffects> effects =
      ValueNotifier<LikedinEffects>(LikedinEffects.full);
  static final ValueNotifier<bool> reduceMotion = ValueNotifier<bool>(false);

  /// Rebuilds the MaterialApp when any appearance value changes.
  static final Listenable listenable =
      Listenable.merge([accentIndex, effects, reduceMotion]);

  static LikedinAccent get accent =>
      likedinAccents[accentIndex.value.clamp(0, likedinAccents.length - 1).toInt()];

  static Future<void> load([SharedPreferences? preferences]) async {
    try {
      final prefs = preferences ?? await SharedPreferences.getInstance();
      final a = prefs.getInt(_accentKey) ?? 0;
      accentIndex.value = a.clamp(0, likedinAccents.length - 1).toInt();
      final e = prefs.getInt(_effectsKey) ?? 0;
      effects.value = LikedinEffects.values[e.clamp(0, 2).toInt()];
      reduceMotion.value = prefs.getBool(_motionKey) ?? false;
    } catch (_) {
      // Defaults are fine if preferences are unavailable.
    }
  }

  static Future<void> setAccent(int index) async {
    accentIndex.value = index.clamp(0, likedinAccents.length - 1).toInt();
    await _save((p) => p.setInt(_accentKey, accentIndex.value));
  }

  static Future<void> setEffects(LikedinEffects value) async {
    effects.value = value;
    await _save((p) => p.setInt(_effectsKey, value.index));
  }

  static Future<void> setReduceMotion(bool value) async {
    reduceMotion.value = value;
    await _save((p) => p.setBool(_motionKey, value));
  }

  static Future<void> reset() async {
    accentIndex.value = 0;
    effects.value = LikedinEffects.full;
    reduceMotion.value = false;
    await _save((p) async {
      await p.remove(_accentKey);
      await p.remove(_effectsKey);
      await p.remove(_motionKey);
    });
  }

  static Future<void> _save(Future<void> Function(SharedPreferences) write) async {
    try {
      await write(await SharedPreferences.getInstance());
    } catch (_) {}
  }

  /// True when animations should be skipped or shortened: either the user
  /// chose reduced motion in Likedin or the OS asks for it.
  static bool motionReduced(BuildContext context) =>
      reduceMotion.value || MediaQuery.of(context).disableAnimations;
}

// ---- Palette ---------------------------------------------------------------

Color likedinBackground(Brightness brightness) => brightness == Brightness.dark
    ? const Color(0xFF060B18) // obsidian midnight
    : const Color(0xFFEAF1FB); // arctic frost

Color likedinBackgroundTop(Brightness brightness) =>
    brightness == Brightness.dark
        ? const Color(0xFF0B1530)
        : const Color(0xFFF7FAFF);

Color likedinSurface(Brightness brightness) => brightness == Brightness.dark
    ? const Color(0xFF0E1830)
    : const Color(0xFFFFFFFF);

Color likedinSurfaceRaised(Brightness brightness) =>
    brightness == Brightness.dark
        ? const Color(0xFF16233F)
        : const Color(0xFFE6EEF9);

Color likedinOutline(Brightness brightness) => brightness == Brightness.dark
    ? const Color(0xFF28385A)
    : const Color(0xFFD3DEEE);

Color likedinOnSurface(Brightness brightness) => brightness == Brightness.dark
    ? const Color(0xFFEAF0FF)
    : const Color(0xFF0C1A33);

Color likedinMutedText(Brightness brightness) => brightness == Brightness.dark
    ? const Color(0xFFA3B1CE)
    : const Color(0xFF51617F);

Color likedinPrimary(Brightness brightness) =>
    LikedinAppearance.accent.forBrightness(brightness);

/// Darkens [color] just enough that white text on it reaches [minContrast]
/// (WCAG ratio). This is what keeps every accent choice readable.
Color likedinEnsureWhiteContrast(Color color, {double minContrast = 4.5}) {
  var result = color;
  for (var i = 0; i < 24; i++) {
    final ratio = 1.05 / (result.computeLuminance() + .05);
    if (ratio >= minContrast) return result;
    result = Color.lerp(result, const Color(0xFF000000), .06)!;
  }
  return result;
}

/// Blue-to-cyan (or accent equivalent) gradient for primary actions. Both
/// stops are contrast-corrected for white labels, so it is safe with any accent.
LinearGradient likedinPrimaryGradient(Brightness brightness) {
  final accent = LikedinAppearance.accent;
  final dark = brightness == Brightness.dark;
  final start = likedinEnsureWhiteContrast(
    dark ? Color.lerp(accent.dark, const Color(0xFF2F6BFF), .5)! : accent.light,
  );
  final end = likedinEnsureWhiteContrast(
    dark ? accent.gradientEnd : Color.lerp(accent.light, accent.gradientEnd, .55)!,
  );
  return LinearGradient(
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
    colors: [start, end],
  );
}

/// Outgoing chat-bubble fill. Chosen so on-bubble text stays readable.
Color likedinOutgoingBubble(Brightness brightness) {
  final accent = likedinPrimary(brightness);
  return brightness == Brightness.dark
      ? Color.alphaBlend(accent.withValues(alpha: .30), const Color(0xFF0E1830))
      : Color.alphaBlend(accent.withValues(alpha: .14), Colors.white);
}

// ---- Surfaces --------------------------------------------------------------

/// Glass content surface for cards, bars and grouped rows.
///
/// The default look is a translucent tonal fill with a thin highlight border
/// (cheap to paint). Set [frosted] for true backdrop blur on the few surfaces
/// where it earns its cost; it is skipped when the user picks Lighter/Off
/// effects. [blur] is the requested sigma (capped at 12). [tint] overrides the
/// fill colour and [glow] adds a soft accent halo (Full effects only).
class GlassPanel extends StatelessWidget {
  const GlassPanel({
    required this.child,
    this.padding = EdgeInsets.zero,
    this.radius = const BorderRadius.all(Radius.circular(20)),
    this.blur = 0,
    this.tint,
    this.glow = false,
    this.frosted = false,
    super.key,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final BorderRadius radius;
  final double blur;
  final Color? tint;
  final bool glow;
  final bool frosted;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    return ValueListenableBuilder<LikedinEffects>(
      valueListenable: LikedinAppearance.effects,
      child: Padding(padding: padding, child: child),
      builder: (context, effects, builtChild) {
        final base = tint ?? likedinSurface(brightness);
        final fancy = effects != LikedinEffects.off;
        // Off: solid surface. Otherwise slightly translucent so the ambient
        // backdrop shows through; opacity stays high so text contrast holds.
        final fillAlpha = !fancy ? 1.0 : (dark ? .82 : .86);
        final border = dark
            ? Colors.white.withValues(alpha: fancy ? .10 : .07)
            : Colors.white.withValues(alpha: .9);
        final edge = fancy ? border : likedinOutline(brightness);
        final Widget body = DecoratedBox(
          decoration: BoxDecoration(
            color: base.withValues(alpha: fillAlpha),
            gradient: fancy
                ? LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Colors.white.withValues(alpha: dark ? .06 : .55),
                      Colors.white.withValues(alpha: 0),
                    ],
                  )
                : null,
            borderRadius: radius,
            border: Border.all(
              color: dark || !fancy ? edge : likedinOutline(brightness),
              width: 1,
            ),
          ),
          child: builtChild,
        );
        Widget result;
        if (frosted && effects == LikedinEffects.full) {
          final sigma = (blur <= 0 ? 10.0 : blur).clamp(0.0, 12.0).toDouble();
          result = RepaintBoundary(
            child: ClipRRect(
              borderRadius: radius,
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: sigma, sigmaY: sigma),
                child: body,
              ),
            ),
          );
        } else if (radius == BorderRadius.zero) {
          result = body;
        } else {
          result = ClipRRect(borderRadius: radius, child: body);
        }
        // The glow lives outside the clip so it is actually visible.
        if (glow && effects == LikedinEffects.full) {
          result = DecoratedBox(
            decoration: BoxDecoration(
              borderRadius: radius,
              boxShadow: [
                BoxShadow(
                  color: likedinPrimary(brightness).withValues(alpha: .22),
                  blurRadius: 22,
                  spreadRadius: -4,
                ),
              ],
            ),
            child: result,
          );
        }
        return result;
      },
    );
  }
}

/// Layered ambient page background: a vertical gradient plus two static soft
/// light pools. No animation and no blur filters, so it costs one cheap
/// repaint; with effects Off it collapses to a flat colour.
class AuroraBackdrop extends StatelessWidget {
  const AuroraBackdrop({required this.child, super.key});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    return ValueListenableBuilder<LikedinEffects>(
      valueListenable: LikedinAppearance.effects,
      child: child,
      builder: (context, effects, builtChild) {
        final accent = likedinPrimary(brightness);
        final children = <Widget>[
          if (effects == LikedinEffects.off)
            ColoredBox(color: likedinBackground(brightness))
          else
            RepaintBoundary(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      likedinBackgroundTop(brightness),
                      likedinBackground(brightness),
                    ],
                  ),
                ),
                child: effects == LikedinEffects.full
                    ? Stack(
                        fit: StackFit.expand,
                        children: [
                          DecoratedBox(
                            decoration: BoxDecoration(
                              gradient: RadialGradient(
                                center: const Alignment(-.9, -.95),
                                radius: 1.0,
                                colors: [
                                  accent.withValues(alpha: dark ? .20 : .16),
                                  accent.withValues(alpha: 0),
                                ],
                              ),
                            ),
                          ),
                          DecoratedBox(
                            decoration: BoxDecoration(
                              gradient: RadialGradient(
                                center: const Alignment(1.0, .9),
                                radius: .9,
                                colors: [
                                  LikedinAppearance.accent.gradientEnd
                                      .withValues(alpha: dark ? .12 : .10),
                                  LikedinAppearance.accent.gradientEnd
                                      .withValues(alpha: 0),
                                ],
                              ),
                            ),
                          ),
                        ],
                      )
                    : null,
              ),
            ),
          if (builtChild != null) builtChild,
        ];
        // Same Stack(expand) layout contract as before.
        return Stack(fit: StackFit.expand, children: children);
      },
    );
  }
}

/// Primary action button: blue-to-cyan gradient pill with a loading state.
class GradientButton extends StatelessWidget {
  const GradientButton({
    required this.onPressed,
    required this.child,
    this.height = 52,
    super.key,
  });

  final VoidCallback? onPressed;
  final Widget child;
  final double height;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final enabled = onPressed != null;
    return Opacity(
      opacity: enabled ? 1 : .55,
      child: Material(
        color: Colors.transparent,
        child: Ink(
          height: height,
          decoration: BoxDecoration(
            gradient: likedinPrimaryGradient(brightness),
            borderRadius: BorderRadius.circular(height),
          ),
          child: InkWell(
            onTap: onPressed,
            borderRadius: BorderRadius.circular(height),
            child: Center(
              child: DefaultTextStyle.merge(
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                ),
                child: IconTheme.merge(
                  data: const IconThemeData(color: Colors.white),
                  child: child,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
