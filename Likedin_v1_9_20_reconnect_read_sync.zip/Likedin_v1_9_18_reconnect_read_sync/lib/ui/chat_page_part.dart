part of '../main.dart';

class ChatPage extends StatefulWidget {
  const ChatPage({required this.attachmentVault, required this.isActive, required this.onBack, super.key});
  final AttachmentVaultStore attachmentVault;
  final bool isActive;
  final VoidCallback onBack;
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> with WidgetsBindingObserver {
  final controller = TextEditingController();
  final FocusNode _composerFocus = FocusNode();
  final nicknameController = TextEditingController();
  final ScrollController _chatScrollController = ScrollController();
  final ValueNotifier<bool> _showScrollToBottomNotifier = ValueNotifier<bool>(false);
  final ValueNotifier<String?> _floatingDateNotifier = ValueNotifier<String?>(null);
  Timer? _floatingDateTimer;
  int _wallpaperPreset = 0;
  String? _wallpaperCustomPath;
  double _wallpaperDim = 0.35;
  static const String _wpPresetKey = 'likedin_chat_wallpaper_preset_v1';
  static const String _wpPathKey = 'likedin_chat_wallpaper_path_v1';
  static const String _wpDimKey = 'likedin_chat_wallpaper_dim_v1';
  bool _initialChatPositioned = false;
  bool _initialLoadCompleted = false;
  late final RealtimeMessagingService messaging;
  late final SharedMediaService _mediaService;
  final Map<String, Map<String, dynamic>?> _decodedMediaCache = <String, Map<String, dynamic>?>{};
  final List<RemoteMessage> messages = <RemoteMessage>[];
  String? peerId, peerName, nickname, loadError, peerAvatarPath, peerAvatarUrl;
  DateTime? _peerAvatarUrlExpiresAt;
  bool messagesLoading = true;
  bool appResumed = true;
  bool _markingRead = false;
  bool _markingDelivered = false;
  bool _readMarkRequested = false;
  bool _deliveryMarkRequested = false;
  final Set<String> _remoteCleanedPaths = <String>{};
  final Set<String> _remoteCleanupInFlightPaths = <String>{};
  bool _remoteCleanedPathsLoaded = false;
  Future<bool>? _remoteCleanedPathsLoadFuture;
  bool _hasOlderMessages = false;
  bool _loadingOlderMessages = false;
  DateTime? lastSeen;
  bool peerOnline = false, peerTyping = false, peerRecording = false, saving = false, uploading = false, editingNickname = false;
  final Set<String> _hiddenMessageIds = <String>{};
  final Set<String> _starredMessageIds = <String>{};
  final Set<String> _openedViewOnceIds = <String>{};
  String? _pinnedMessageId;
  RealtimeChannel? _activityChannel;
  Timer? peerRecordingExpiryTimer;
  final Set<String> _animatedMessageIds = <String>{};
  List<RemoteMessage>? _visibleMessagesMemo;
  List<RemoteMessage>? _chatDisplayMessagesMemo;
  String? _chatDisplayMessagesMemoKey;
  final Map<String, Set<String>> _messageReactions = <String, Set<String>>{};
  final Map<String, Map<String, Set<String>>> _messageReactionUsers =
      <String, Map<String, Set<String>>>{};
  // Tracks even messages with zero reactions, preventing an empty result from
  // being queried again on every receipt or message refresh.
  final Set<String> _reactionHydratedMessageIds = <String>{};
  final Map<String, Timer> _reactionRefreshTimers = <String, Timer>{};
  final Map<String, String> _replyTargets = <String, String>{};
  final Map<String, RemoteMessage> _replySourceMessages = <String, RemoteMessage>{};
  final Map<String, GlobalKey> _messageKeys = <String, GlobalKey>{};
  bool _loadingMessages = false;
  int _loadRequestSeq = 0;
  int _queuedMediaCount = 0;
  int _quarantinedMediaCount = 0;
  bool _retryingQuarantinedMedia = false;
  List<String> _queuedMediaNames = <String>[];
  List<Map<String, String>> _quarantinedMediaItems = <Map<String, String>>[];
  bool _loadRunnerActive = false;
  final List<MapEntry<int, Completer<void>>> _loadWaiters = <MapEntry<int, Completer<void>>>[];
  Future<bool>? _olderLoadInFlight;
  bool _localChatStateLoaded = false;
  bool _peerLookupFailed = false;
  String? _draftBeforeEdit;
  static const int _maxVoiceSeconds = 300;
  int? _clearedBeforeMs;
  final Set<String> _postClearVisibleMessageIds = <String>{};
  String? _localStateKey;
  final FlutterSecureStorage _localChatSecureStorage = const FlutterSecureStorage();
  RemoteMessage? _replyingTo;
  String? _editingMessageId;
  String? _editingOriginalText;
  Timer? heartbeat, typingTimer, peerLookupTimer, peerTypingExpiryTimer;
  Timer? _typingPublishTimer;
  DateTime? _lastTypingSentAt;
  bool _voiceCancelRequested = false;
  final VoiceGestureGuard _voiceGesture = VoiceGestureGuard();
  bool _stoppingVoice = false;
  bool _jumpToReplyInProgress = false;
  bool _cancelJumpToReplyRequested = false;
  RealtimeChannel? _chatIncomingCallsChannel;
  Map<String, dynamic>? _chatIncomingCall;
  bool _joiningChatCall = false;
  final AudioRecorder _voiceRecorder = AudioRecorder();
  bool _startingVoiceRecording = false;
  bool _recordingVoice = false;
  bool _voiceReleaseRequested = false;
  DateTime? _voiceRecordStarted;
  Timer? _voiceTimer;
  final ValueNotifier<int> _voiceRecordSecondsNotifier = ValueNotifier<int>(0);
  bool _resolvingSend = false;
  Timer? _searchDebounceTimer;
  Timer? _reconnectResyncTimer;
  DateTime? _lastLoadCompletedAt;
  StreamSubscription<List<ConnectivityResult>>? _connectivitySubscription;
  String? _pendingTextDraftId;
  String? _pendingTextDraftValue;
  bool _clearingComposerForSend = false;
  final TextEditingController _messageSearchController = TextEditingController();
  bool _showMessageSearch = false;
  MessageMediaFilter _messageMediaFilter = MessageMediaFilter.all;
  DateTimeRange? _messageSearchDateRange;

  String get headerName =>
      (nickname?.trim().isNotEmpty == true) ? nickname!.trim() : (peerName ?? 'Your friend');

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _chatScrollController.addListener(_updateScrollButton);
    _composerFocus.addListener(() {
      if (_composerFocus.hasFocus) _scrollToLatest(animated: true);
    });
    messaging = RealtimeMessagingService(Supabase.instance.client);
    _mediaService = SharedMediaService(Supabase.instance.client);
    LikedinNotificationService.instance.setConversationVisible(widget.isActive);
    _connectivitySubscription = Connectivity().onConnectivityChanged.listen((results) {
      if (!mounted || !appResumed || !results.any((result) => result != ConnectivityResult.none)) return;
      _processQueuedMediaInBackground();
    });
    _initialise().whenComplete(() => _recoverLostCameraData());
  }

  Future<void> _refreshQueuedMediaCount() async {
    try {
      final status = await SharedMediaService.queueStatus(Supabase.instance.client);
      if (!mounted) return;
      final pending = (status['pendingCount'] as num?)?.toInt() ?? 0;
      final quarantined = (status['quarantinedCount'] as num?)?.toInt() ?? 0;
      final names = (status['pendingNames'] as List? ?? const [])
          .map((item) => item.toString())
          .toList(growable: false);
      final failedItems = (status['quarantinedItems'] as List? ?? const [])
          .whereType<Map>()
          .map((item) => Map<String, String>.from(item.map(
                (key, value) => MapEntry(key.toString(), value.toString()),
              )))
          .toList(growable: false);
      if (pending != _queuedMediaCount || quarantined != _quarantinedMediaCount ||
          names.join('|') != _queuedMediaNames.join('|') ||
          failedItems.toString() != _quarantinedMediaItems.toString()) {
        setState(() {
          _queuedMediaCount = pending;
          _quarantinedMediaCount = quarantined;
          _queuedMediaNames = names;
          _quarantinedMediaItems = failedItems;
        });
      }
    } catch (error) {
      debugPrint('Could not refresh queued attachment status: $error');
    }
  }

  Future<void> _retryQuarantinedAttachments() async {
    if (_retryingQuarantinedMedia) return;
    setState(() => _retryingQuarantinedMedia = true);
    String resultMessage;
    try {
      final restored = await SharedMediaService.restoreQuarantinedItems(Supabase.instance.client);
      if (restored == 0) {
        resultMessage = 'No quarantined attachment has a local file available to retry. Select the missing file again.';
      } else {
        final completed = await SharedMediaService.processRetryQueue(Supabase.instance.client);
        if (completed) {
          resultMessage = restored == 1 ? 'The failed attachment was sent.' : '$restored attachments were sent.';
        } else {
          resultMessage = SharedMediaService.lastQueueError ??
              'Some attachments are still waiting or need attention.';
        }
      }
    } catch (error) {
      debugPrint('Retrying quarantined attachments failed: $error');
      resultMessage = 'Could not retry failed attachments. Their local copies were kept where available.';
    } finally {
      if (mounted) {
        setState(() => _retryingQuarantinedMedia = false);
        await _refreshQueuedMediaCount();
      }
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(resultMessage)));
    }
  }

  void _processQueuedMediaInBackground() {
    unawaited(_refreshQueuedMediaCount());
    unawaited(
      SharedMediaService.processRetryQueue(Supabase.instance.client)
          .then<void>((completed) async {
        unawaited(_refreshQueuedMediaCount());
        if (completed && mounted && peerId != null) {
          try {
            await _loadMessages();
          } catch (error) {
            debugPrint('Sent media refresh is deferred: $error');
          }
        }
      }).catchError((Object error) {
        debugPrint('Queued media retry failed: $error');
      }),
    );
  }

  void _startHeartbeat() {
    heartbeat?.cancel();
    heartbeat = Timer.periodic(const Duration(seconds: 180), (_) async {
      if (!appResumed || !widget.isActive) return;
      try {
        await messaging.setOnline(true);
      } catch (_) {}
      unawaited(_refreshQueuedMediaCount());
      if (peerId != null) {
        try {
          if (await SharedMediaService.hasQueuedItems(Supabase.instance.client)) {
            _processQueuedMediaInBackground();
          }
        } catch (_) {}
      }
    });
  }

  Future<void> _initialise() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _wallpaperPreset = prefs.getInt(_wpPresetKey) ?? 0;
      _wallpaperCustomPath = prefs.getString(_wpPathKey);
      _wallpaperDim = prefs.getDouble(_wpDimKey) ?? 0.35;
      String? peer;
      try { peer = await messaging.getPeerId(); } catch (error) { _peerLookupFailed = true; debugPrint('Initial peer lookup failed: $error'); }
      if (!mounted) return;
      peerId = peer;
      if (peer != null) {
        _processQueuedMediaInBackground();
      }
      nickname = peer == null ? null : prefs.getString('likedIn_nickname_$peer');
      if (peer != null) await _loadLocalChatState(peer);
      try { await _refreshPeer(); } catch (_) {}
      try { await messaging.setOnline(true); } catch (_) {}
      _startHeartbeat();
      _startPeerLookupRetry();
      if (peer != null) {
        try {
          await E2eeService.instance.initialize(
            Supabase.instance.client,
            userId: messaging.currentUserId,
            peerId: peer,
          );
        } catch (error) {
          debugPrint('E2EE startup deferred: $error');
        }
        _subscribeActivityChannel(peer);
        final ownPub = E2eeService.instance.ownPublicKeyBase64;
        if (ownPub != null) _broadcastActivity({'e2eePubKey': ownPub});
        try { await _watchChatIncomingCalls(); } catch (_) {}
        messaging.subscribe(
          peerId: peer,
          onMessages: () => _handleIncomingMessages(),
          onProfile: _refreshPeer,
          onMessageInsert: _handleRealtimeMessageInsert,
          onMessageUpdate: _handleRealtimeMessageUpdate,
          onReactionChange: _scheduleSingleMessageReactionRefresh,
          onTyping: _handlePeerTyping,
          onReconnect: _resyncAfterReconnect,
        ); // Subscribe before initial load to avoid missing intervening messages.
        await _loadMessages();
        // Reconcile every historical media tombstone, not just those in the
        // currently loaded pages. This clears local files after an app was
        // killed or offline when a delete-for-everyone event arrived.
        try {
          await _reconcileDeletedMediaTombstones();
        } catch (error) {
          debugPrint('Deleted-media cache reconciliation deferred: $error');
        }
        if (appResumed) {
          try { await messaging.markDelivered(); } catch (_) {}
          if (widget.isActive) {
            try { await _markVisibleMessagesRead(); } catch (_) {}
          }
        }
      } else if (mounted) {
        setState(() => messagesLoading = false);
      }
      if (mounted) {
        setState(() {
          loadError = null;
        });
      }
    } catch (error) {
      debugPrint('Chat initialization failed: $error');
      if (mounted) setState(() => loadError = 'Could not connect to messaging. Check your connection and try again.');
    }
  }

  void _setChatIncomingCall(Map<String, dynamic>? row) {
    final hadCall = _chatIncomingCall != null;
    final hasCall = row != null;
    if (mounted) {
      setState(() => _chatIncomingCall = row);
    }
    if (hasCall && widget.isActive && appResumed && !_joiningChatCall) {
      CallAlertController.startIncoming();
    } else if (hadCall && !hasCall && !_joiningChatCall) {
      CallAlertController.stop();
    }
  }

  Future<void> _watchChatIncomingCalls() async {
    final client = Supabase.instance.client;
    final uid = messaging.currentUserId;
    // Resume and tab activation can call this together; do not orphan duplicate channels.
    if (_chatIncomingCallsChannel != null) return;
    _chatIncomingCallsChannel = client
        .channel('likedin-chat-calls-$uid')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'likedin_calls',
          filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'callee_id', value: uid),
          callback: (payload) {
            final row = Map<String, dynamic>.from(payload.newRecord);
            if (row['status'] == 'ringing' && mounted) {
              _setChatIncomingCall(row);
            }
          },
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'likedin_calls',
          filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'callee_id', value: uid),
          callback: (payload) {
            final row = payload.newRecord;
            if (row['status'] != 'ringing' &&
                mounted &&
                _chatIncomingCall?['id']?.toString() == row['id']?.toString()) {
              _setChatIncomingCall(null);
            }
          },
        )
      ..subscribe();
    try {
      final rows = await client
          .from('likedin_calls')
          .select()
          .eq('callee_id', uid)
          .eq('status', 'ringing')
          .order('created_at', ascending: false)
          .limit(1);
      if (mounted) {
        _setChatIncomingCall(rows.isEmpty ? null : Map<String, dynamic>.from(rows.first));
      }
    } catch (e) {
      debugPrint('Chat incoming-call recovery failed: $e');
    }
  }

  Future<void> _declineChatIncomingCall() async {
    final row = _chatIncomingCall;
    if (row == null || _joiningChatCall) return;
    final id = row['id']?.toString();
    if (id == null) return;

    // Commit the authoritative call state first. Signaling is best-effort and
    // must never prevent the caller from learning that the call was rejected.
    try {
      await Supabase.instance.client.rpc('likedin_update_call_status', params: {
        'p_call_id': id,
        'p_new_status': 'rejected',
      });
    } catch (e) {
      debugPrint('Could not commit incoming call rejection: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not decline the call. Please try again.')),
        );
      }
      return;
    }

    try {
      await LikedinNotificationService.instance.cancelIncomingCall(id);
    } catch (e) {
      debugPrint('Decline committed, but local incoming-call notification could not be cancelled: $e');
    }
    _setChatIncomingCall(null);
    try {
      await Supabase.instance.client.from('likedin_call_signals').insert({
        'call_id': id,
        'sender_id': messaging.currentUserId,
        'kind': 'reject',
        'payload': <String, dynamic>{},
      });
    } catch (e) {
      debugPrint('Call was rejected in the database; reject signal could not be sent: $e');
    }
  }

  Future<void> _joinChatIncomingCall() async {
    final row = _chatIncomingCall;
    if (row == null || _joiningChatCall || _globalCallDialogActive) return;
    setState(() => _joiningChatCall = true);
    _globalCallDialogActive = true;
    await CallAlertController.stop();
    try {
      final client = Supabase.instance.client;
      final id = row['id'].toString();
      await LikedinNotificationService.instance.cancelIncomingCall(id);
      Map<String, dynamic>? offer;
      for (var attempt = 0; attempt < 90 && offer == null; attempt++) {
        final latest = await client.from('likedin_calls').select('status').eq('id', id).maybeSingle();
        if (latest == null || latest['status'] != 'ringing') break;
        final signals = await client
            .from('likedin_call_signals')
            .select('payload')
            .eq('call_id', id)
            .eq('kind', 'offer')
            .order('created_at', ascending: false)
            .limit(1);
        if (signals.isNotEmpty) offer = Map<String, dynamic>.from(signals.first['payload'] as Map);
        if (offer == null) await Future<void>.delayed(const Duration(milliseconds: 500));
      }
      if (offer == null) {
        throw StateError('The caller is no longer ringing. Ask them to call again.');
      }
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (_) => _IncomingCallDialog(
          callId: id,
          callerId: row['caller_id'].toString(),
          offer: offer!,
          withVideo: row['call_type']?.toString().toLowerCase() == 'video',
          autoAccept: true,
        ),
      );
      if (mounted) _setChatIncomingCall(null);
    } catch (e) {
      final ended = e is StateError && e.message.toString().contains('no longer ringing');
      if (ended && mounted) _setChatIncomingCall(null);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(ended
              ? 'This call has already ended.'
              : 'Could not join the call. Check your connection and try again.'),
        ));
      }
    } finally {
      _globalCallDialogActive = false;
      if (mounted) setState(() => _joiningChatCall = false);
    }
  }

  Future<void> _loadLocalChatState(String peer) async {
    final user = messaging.currentUserId;
    final key = 'likedin_local_chat_v1_${user}_$peer';
    if (_localStateKey != key) _localChatStateLoaded = false;
    _localStateKey = key;
    String? raw;
    try {
      raw = await _localChatSecureStorage.read(key: key);
      _localChatStateLoaded = true;
    } catch (error) {
      // Leave _localChatStateLoaded false so a later save never overwrites the
      // stored hidden/cleared state with this session's incomplete copy.
      debugPrint('Local chat state unavailable (secure storage key may have changed): $error');
      return;
    }
    if (raw == null || raw.isEmpty) return;
    _applyStoredLocalState(raw, merge: false);
  }

  void _applyStoredLocalState(String raw, {required bool merge}) {
    try {
      final data = Map<String, dynamic>.from(jsonDecode(raw) as Map);
      final hidden = (data['hidden'] as List? ?? const []).map((e) => e.toString());
      final postClear = (data['postClearVisible'] as List? ?? const []).map((e) => e.toString());
      final starred = (data['starred'] as List? ?? const []).map((e) => e.toString());
      final openedOnce = (data['openedViewOnce'] as List? ?? const []).map((e) => e.toString());
      final storedCleared = data['clearedBeforeMs'] as int?;
      final storedPinned = data['pinnedMessageId']?.toString();
      if (!merge) {
        _hiddenMessageIds..clear()..addAll(hidden);
        _starredMessageIds..clear()..addAll(starred);
        _openedViewOnceIds..clear()..addAll(openedOnce);
        _pinnedMessageId = (storedPinned == null || storedPinned.isEmpty) ? null : storedPinned;
        _clearedBeforeMs = storedCleared;
        _postClearVisibleMessageIds..clear()..addAll(postClear);
      } else {
        _hiddenMessageIds.addAll(hidden);
        _starredMessageIds.addAll(starred);
        _openedViewOnceIds.addAll(openedOnce);
        _pinnedMessageId ??= (storedPinned == null || storedPinned.isEmpty) ? null : storedPinned;
        // A clear made in this session is newer than whatever was stored.
        if (_clearedBeforeMs == null) {
          _clearedBeforeMs = storedCleared;
          _postClearVisibleMessageIds.addAll(postClear);
        }
      }
      _invalidateMessageViewCache();
    } catch (_) {}
  }

  Future<void> _saveLocalChatState() async {
    final key = _localStateKey;
    if (key == null) return;
    if (!_localChatStateLoaded) {
      // The earlier read failed. Try once more and merge; if storage is still
      // unreadable, skip the write rather than destroy what is stored.
      try {
        final raw = await _localChatSecureStorage.read(key: key);
        _localChatStateLoaded = true;
        if (raw != null && raw.isNotEmpty) _applyStoredLocalState(raw, merge: true);
        if (mounted) setState(() {});
      } catch (error) {
        debugPrint('Local chat state not saved; storage is still unreadable: $error');
        return;
      }
    }
    try {
      await _localChatSecureStorage.write(key: key, value: jsonEncode({
        'hidden': _hiddenMessageIds.toList(),
        'clearedBeforeMs': _clearedBeforeMs,
        'postClearVisible': _postClearVisibleMessageIds.toList(),
        'starred': _starredMessageIds.toList(),
        'openedViewOnce': _openedViewOnceIds.toList(),
        'pinnedMessageId': _pinnedMessageId,
      }));
    } catch (error) { debugPrint('Could not persist local chat state: $error'); }
  }

  void _handlePeerTyping(bool value) {
    peerTypingExpiryTimer?.cancel();
    if (!mounted) return;
    // Measure before the typing bubble is added, so we only follow the
    // conversation when the reader was already at the bottom.
    final wasNearBottom = !_chatScrollController.hasClients || _isNearBottom;
    setState(() => peerTyping = value);
    if (value) {
      peerTypingExpiryTimer = Timer(const Duration(seconds: 5), () {
        if (mounted) setState(() => peerTyping = false);
      });
      if (wasNearBottom) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted && peerTyping) _scrollToLatest(animated: true);
        });
      }
    }
  }

  void _subscribeActivityChannel(String peer) {
    if (_activityChannel != null) return;
    final ids = <String>[messaging.currentUserId, peer]..sort();
    final channelName = 'likedin-activity-${ids[0]}-${ids[1]}';
    _activityChannel = Supabase.instance.client
        .channel(channelName)
        .onBroadcast(
          event: 'activity',
          callback: (payload) {
            if (!mounted) return;
            final sender = payload['uid']?.toString();
            if (sender == null || sender == messaging.currentUserId) return;
            if (payload.containsKey('recording')) {
              final rec = payload['recording'] == true;
              _handlePeerRecording(rec);
            }
            if (payload.containsKey('pinnedMessageId')) {
              final nextPin = payload['pinnedMessageId']?.toString();
              setState(() {
                _pinnedMessageId = (nextPin == null || nextPin.isEmpty) ? null : nextPin;
              });
              unawaited(_saveLocalChatState());
            }
            if (payload.containsKey('e2eePubKey')) {
              final peerKey = payload['e2eePubKey']?.toString();
              if (peerKey != null && peerKey.isNotEmpty) {
                final hadActive = E2eeService.instance.isActive;
                unawaited(
                  E2eeService.instance.acceptPeerPublicKey(peerKey).then((nowActive) {
                    if (!hadActive && nowActive && mounted) {
                      final ownPub = E2eeService.instance.ownPublicKeyBase64;
                      if (ownPub != null) _broadcastActivity({'e2eePubKey': ownPub});
                      unawaited(_loadMessages().catchError((_) {}));
                    }
                  }),
                );
              }
            }
          },
        )
      ..subscribe();
  }

  void _broadcastActivity(Map<String, dynamic> data) {
    final channel = _activityChannel;
    if (channel == null) return;
    unawaited(
      channel
          .sendBroadcastMessage(
            event: 'activity',
            payload: <String, dynamic>{'uid': messaging.currentUserId, ...data},
          )
          .then<void>((_) {}, onError: (Object _) {}),
    );
  }

  void _handlePeerRecording(bool value) {
    peerRecordingExpiryTimer?.cancel();
    if (!mounted) return;
    final wasNearBottom = !_chatScrollController.hasClients || _isNearBottom;
    setState(() => peerRecording = value);
    if (value) {
      peerRecordingExpiryTimer = Timer(const Duration(seconds: 5), () {
        if (mounted) setState(() => peerRecording = false);
      });
      if (wasNearBottom) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted && peerRecording) _scrollToLatest(animated: true);
        });
      }
    }
  }

  void _startPeerLookupRetry() {
    peerLookupTimer?.cancel();
    peerLookupTimer = Timer.periodic(const Duration(seconds: 60), (_) async {
      if (!mounted || !appResumed) return;
      if (peerId == null) {
        try {
          final found = await messaging.getPeerId();
          if (mounted && _peerLookupFailed) setState(() => _peerLookupFailed = false);
          if (found != null && mounted) {
            setState(() => peerId = found);
            await _loadLocalChatState(found);
            try {
              await E2eeService.instance.initialize(
                Supabase.instance.client,
                userId: messaging.currentUserId,
                peerId: found,
              );
            } catch (_) {}
            _subscribeActivityChannel(found);
            final ownPub = E2eeService.instance.ownPublicKeyBase64;
            if (ownPub != null) _broadcastActivity({'e2eePubKey': ownPub});
            messaging.subscribe(peerId: found, onMessages: _handleIncomingMessages,
              onProfile: _refreshPeer, onMessageInsert: _handleRealtimeMessageInsert,
              onMessageUpdate: _handleRealtimeMessageUpdate,
              onReactionChange: _scheduleSingleMessageReactionRefresh, onTyping: _handlePeerTyping,
              onReconnect: _resyncAfterReconnect);
            await _refreshPeer();
            await _loadMessages();
            try {
              await _reconcileDeletedMediaTombstones();
            } catch (error) {
              debugPrint('Deleted-media cache reconciliation after peer registration deferred: $error');
            }
            await _watchChatIncomingCalls();
          }
        } catch (error) {
          debugPrint('Peer lookup retry failed: $error');
          if (mounted && !_peerLookupFailed) setState(() => _peerLookupFailed = true);
        }
      } else if (loadError != null && widget.isActive) {
        try { await _loadMessages(); } catch (_) {}
      }
    });
  }

  void _openPeerProfilePhoto() {
    final url = peerAvatarUrl;
    if (url == null || url.isEmpty) return;
    Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (_) => ProfilePhotoViewerPage(
          imageUrl: url,
          displayName: headerName,
          heroTag: peerAvatarPath == null ? null : 'likedin-chat-avatar-$peerAvatarPath',
        ),
      ),
    );
  }

  void _closeInfoAndEditNickname() {
    Navigator.of(context).pop();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _beginNicknameEdit();
    });
  }

  Future<ChatInfoSnapshot> _loadChatInfoSnapshot({bool loadAllMessages = false}) async {
    await _refreshPeer();
    final currentPeer = peerId;
    if (currentPeer != null) {
      final prefs = await SharedPreferences.getInstance();
      final savedNickname = prefs.getString('likedIn_nickname_$currentPeer');
      if (mounted && savedNickname != nickname) {
        setState(() => nickname = savedNickname);
      }
    }
    List<RemoteMessage>? allVisible;
    if (loadAllMessages) {
      // Shared Items must represent the complete conversation history, not
      // just the latest 500 messages. Use the service's stable keyset-paginated
      // loader so older attachments are included without relying on chat UI
      // pagination state.
      final completeHistory = await E2eeService.instance.decryptMessages(
        await messaging.loadAllConversation(
          pageSize: 500,
          maxMessages: 100000,
        ),
      );
      // Include the full non-deleted cloud history in Contact Info so older
      // photos, videos, links, and documents remain accessible even if the
      // local chat view was cleared or only has the latest page loaded.
      allVisible = completeHistory
          .where((message) => message.deletedForEveryoneAt == null)
          .toList(growable: false);
    }
    return ChatInfoSnapshot(
      displayName: headerName,
      presence: _presenceText(),
      avatarUrl: peerAvatarUrl,
      messages: allVisible,
    );
  }

  Future<void> _openChatInfoMedia(Map<String, dynamic> payload) async {
    final name = payload['name']?.toString() ?? 'Shared attachment';
    final kind = payload['kind']?.toString() ?? 'file';
    if (kind != 'image' && kind != 'video') {
      try {
        final file = await SharedMediaService(Supabase.instance.client).cachedFile(payload);
        if (!mounted) return;
        await const MethodChannel('com.example.likedin/downloads').invokeMethod<bool>('openLocalFile', {
          'sourcePath': file.path,
          'displayName': name,
        });
      } catch (error) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Could not open this shared document.')),
          );
        }
      }
      return;
    }
    if (!mounted) return;
    Navigator.of(context).push<void>(MaterialPageRoute<void>(
      builder: (_) => Scaffold(
        appBar: AppBar(title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis)),
        body: Center(child: _ChatMediaMessage(
          payload: payload,
          name: name,
          sizeLabel: payload['size']?.toString() ?? '',
          autoLoadVideo: true,
        )),
      ),
    ));
  }

  void _openChatInfo() {
    Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (_) => ChatInfoPage(
          displayName: headerName,
          presence: _presenceText(),
          avatarUrl: peerAvatarUrl,
          messages: List<RemoteMessage>.unmodifiable(_visibleMessages),
          mediaService: SharedMediaService(Supabase.instance.client),
          loadSnapshot: _loadChatInfoSnapshot,
          onOpenAvatar: _openPeerProfilePhoto,
          onOpenMedia: _openChatInfoMedia,
          onManageStorage: () => Navigator.of(context).push<void>(
            MaterialPageRoute<void>(builder: (_) => StoragePage(store: widget.attachmentVault)),
          ),
          onClearChat: _clearChatForMe,
          onChangeNickname: _closeInfoAndEditNickname,
          starredCount: _starredMessageIds.length,
          onOpenStarred: () {
            Navigator.of(context).pop();
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (mounted) unawaited(_showStarredMessagesSheet());
            });
          },
        ),
      ),
    );
  }

  Future<void> _showPermissionSettingsPrompt(String permissionName) async {
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text('$permissionName permission needed'),
        content: Text('Allow $permissionName access in Android settings to use this feature.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Not now')),
          FilledButton(onPressed: () {
            Navigator.pop(dialogContext);
            openAppSettings();
          }, child: const Text('Open settings')),
        ],
      ),
    );
  }

  Future<void> _recoverLostCameraData() async {
    try {
      final response = await ImagePicker().retrieveLostData();
      if (response.isEmpty) return;
      final files = response.files ?? (response.file == null ? <XFile>[] : <XFile>[response.file!]);
      if (files.isEmpty) return;
      final recipient = peerId ?? await messaging.getPeerId();
      if (recipient == null) {
        for (final file in files) {
          try { if (await File(file.path).exists()) await File(file.path).delete(); } catch (error) {
            debugPrint('Could not clean up unrecoverable camera photo: $error');
          }
        }
        return;
      }
      for (var index = 0; index < files.length; index++) {
        final file = files[index];
        if (!mounted) {
          for (final unprocessed in files.skip(index)) {
            try { if (await File(unprocessed.path).exists()) await File(unprocessed.path).delete(); } catch (_) {}
          }
          break;
        }
        await _reviewAndSendCapturedPhoto(file, recipient, recovered: true);
      }
    } catch (error) {
      debugPrint('Android camera recovery failed: $error');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('A camera photo could not be recovered. Please take it again.')),
        );
      }
    }
  }

  Future<void> _sendCapturedPhotoFile(
    XFile captured,
    String recipient, {
    String? caption,
    bool viewOnce = false,
  }) async {
    final source = File(captured.path);
    try {
      if (!await source.exists()) throw StateError('The captured photo is no longer available.');
      if (!mounted) return;
      setState(() => uploading = true);
      final media = SharedMediaService(Supabase.instance.client);
      final prepared = await media.prepare(source);
      try {
        final replyId = await _resolveReplyTargetIdOrNull(_replyingTo);
        final prefix = viewOnce ? 'LikedinOnce_' : 'Camera_';
        await media.enqueue(
          prepared,
          recipient,
          originalName: '$prefix${DateTime.now().millisecondsSinceEpoch}.jpg',
          replyToMessageId: replyId,
        );
        if (replyId != null && mounted) setState(() => _replyingTo = null);
      } finally {
        if (prepared.path != source.path && await prepared.exists()) {
          try { await prepared.delete(); } catch (_) {}
        }
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Photo queued. Sending in the background…')),
        );
        _processQueuedMediaAfterFastSend();
        final cleanCaption = caption?.trim();
        if (cleanCaption != null && cleanCaption.isNotEmpty) {
          unawaited(send(messageOverride: cleanCaption));
        }
      }
    } catch (error) {
      debugPrint('Camera photo send failed: $error');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not send the photo. Please try again.')),
        );
      }
    } finally {
      try { if (await source.exists()) await source.delete(); } catch (cleanupError) {
        debugPrint('Could not delete temporary camera photo: $cleanupError');
      }
      if (mounted) setState(() => uploading = false);
    }
  }

  Future<void> _reviewAndSendCapturedPhoto(
    XFile captured,
    String recipient, {
    bool recovered = false,
  }) async {
    final source = File(captured.path);
    try {
      if (!await source.exists() || !mounted) return;
      final choice = await showDialog<String>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => PopScope<Object?>(
          canPop: false,
          child: AlertDialog(
          title: Text(recovered ? 'Recover camera photo?' : 'Send photo?'),
          content: ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: Image.file(source, fit: BoxFit.contain, height: 360, width: double.infinity,
              cacheWidth: 1200),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext, 'discard'), child: const Text('Discard')),
            FilledButton(onPressed: () => Navigator.pop(dialogContext, 'send'), child: const Text('Send')),
          ],
        )),
      );
      if (choice == 'send' && mounted) {
        // The send helper owns cleanup so the recovered file is deleted on all paths.
        await _sendCapturedPhotoFile(captured, recipient);
      }
    } catch (error) {
      debugPrint('Camera preview recovery failed: $error');
      try { if (await source.exists()) await source.delete(); } catch (_) {}
    } finally {
      // Discard/cancel also removes the temporary camera output.
      if (await source.exists()) {
        try { await source.delete(); } catch (_) {}
      }
    }
  }

  Future<void> _captureAndSendPhoto() async {
    if (uploading) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please wait for the current upload to finish.')),
      );
      return;
    }
    final recipient = peerId;
    if (recipient == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Your friend must register before sharing photos.')),
      );
      return;
    }
    var permission = await Permission.camera.status;
    if (!permission.isGranted) permission = await Permission.camera.request();
    if (!permission.isGranted) {
      if (permission.isPermanentlyDenied || permission.isRestricted) {
        await _showPermissionSettingsPrompt('Camera');
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Camera permission was not granted.')),
        );
      }
      return;
    }

    final picker = ImagePicker();
    while (mounted && !uploading) {
      XFile? captured;
      try {
        captured = await picker.pickImage(
          source: ImageSource.camera,
          imageQuality: 90,
          maxWidth: 1920,
          maxHeight: 1920,
        );
      } on PlatformException catch (error) {
        final denied = error.code.toLowerCase().contains('permission') ||
            error.code.toLowerCase().contains('denied');
        if (denied) {
          final current = await Permission.camera.status;
          if (current.isPermanentlyDenied) {
            await _showPermissionSettingsPrompt('Camera');
          } else if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Camera permission was denied. Please allow camera access and try again.')),
            );
          }
        } else if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('The camera could not be opened. Please try again.')),
          );
        }
        return;
      } catch (_) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('The camera could not be opened. Please try again.')),
          );
        }
        return;
      }
      if (captured == null) return;
      final source = File(captured.path);
      if (!mounted) {
        try { if (await source.exists()) await source.delete(); } catch (error) {
          debugPrint('Could not clean up camera photo after screen close: $error');
        }
        return;
      }
      String photoCaption = '';
      bool viewOnce = false;
      final choice = await showDialog<String>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => PopScope<Object?>(
          canPop: false,
          child: StatefulBuilder(
            builder: (dialogContext, setDialogState) => AlertDialog(
              title: const Text('Send photo?'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: Image.file(source, fit: BoxFit.contain, height: 300, width: double.infinity,
                        cacheWidth: 1200),
                    ),
                    const SizedBox(height: 10),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: FilterChip(
                        selected: viewOnce,
                        avatar: const Icon(Icons.looks_one_outlined, size: 17),
                        label: const Text('View once (1×)'),
                        onSelected: (v) => setDialogState(() => viewOnce = v),
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      textCapitalization: TextCapitalization.sentences,
                      maxLines: 3,
                      minLines: 1,
                      onChanged: (v) => photoCaption = v,
                      decoration: const InputDecoration(
                        hintText: 'Add a caption (optional)…',
                        isDense: true,
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(onPressed: () => Navigator.pop(dialogContext, 'discard'), child: const Text('Discard')),
                TextButton(onPressed: () => Navigator.pop(dialogContext, 'retake'), child: const Text('Retake')),
                FilledButton(onPressed: () => Navigator.pop(dialogContext, 'send'), child: const Text('Send')),
              ],
            ),
          ),
        ),
      );
      if (choice == 'retake') {
        try { if (await source.exists()) await source.delete(); } catch (_) {}
        continue;
      }
      if (choice != 'send') {
        try { if (await source.exists()) await source.delete(); } catch (_) {}
        return;
      }
      await _sendCapturedPhotoFile(captured, recipient, caption: photoCaption, viewOnce: viewOnce);
      return;
    }
  }

  Future<void> _refreshPeer() async {
    try {
      final profile = await messaging.getPeerProfile();
      if (!mounted) return;
      if (profile == null) {
        setState(() {
          peerOnline = false;
          peerAvatarPath = null;
          peerAvatarUrl = null;
          _peerAvatarUrlExpiresAt = null;
        });
        return;
      }

      var nextAvatarUrl = peerAvatarUrl;
      var nextExpiry = _peerAvatarUrlExpiresAt;
      final avatarPathChanged = profile.avatarPath != peerAvatarPath;
      final shouldRefreshUrl = profile.avatarPath != null &&
          (avatarPathChanged ||
              nextAvatarUrl == null ||
              nextExpiry == null ||
              nextExpiry.isBefore(DateTime.now().add(const Duration(minutes: 30))));
      if (profile.avatarPath == null) {
        nextAvatarUrl = null;
        nextExpiry = null;
      } else if (shouldRefreshUrl) {
        try {
          nextAvatarUrl = await messaging.profileAvatarSignedUrl(profile.avatarPath!);
          nextExpiry = DateTime.now().add(const Duration(hours: 24));
        } catch (error) {
          debugPrint('Peer profile photo could not be resolved yet: $error');
          if (avatarPathChanged) nextAvatarUrl = null;
        }
      }
      if (!mounted) return;
      setState(() {
        peerName = profile.name;
        peerOnline = profile.online;
        lastSeen = profile.lastSeen;
        peerAvatarPath = profile.avatarPath;
        peerAvatarUrl = nextAvatarUrl;
        _peerAvatarUrlExpiresAt = nextExpiry;
      });
    } catch (_) {
      if (mounted) setState(() => peerOnline = false);
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    appResumed = state == AppLifecycleState.resumed;
    LikedinNotificationService.instance.setConversationVisible(widget.isActive && appResumed);
    if (appResumed) {
      messaging.setOnline(true).catchError((_) {});
      _processQueuedMediaInBackground();
      _startHeartbeat();
      if (peerId != null) {
        unawaited(_refreshPeer());
        unawaited(_watchChatIncomingCalls());
      }
      if (peerId != null) {
        unawaited(_reconcileDeletedMediaTombstones().catchError((Object error) {
          debugPrint('Deleted-media cache reconciliation on resume deferred: $error');
        }));
      }
      if (peerId != null) {
        // Realtime reaction events are lost while backgrounded; forget which
        // messages were hydrated so the reload below refetches all of them.
        _reactionHydratedMessageIds.clear();
      }
      if (widget.isActive) {
        _loadMessages().then((_) => _markVisibleMessagesRead()).catchError((_) {});
      }
    } else if (state == AppLifecycleState.paused || state == AppLifecycleState.detached) {
      if (_recordingVoice || _startingVoiceRecording) {
        _voiceReleaseRequested = true;
        unawaited(_stopAndSendVoice(discard: true));
      }
      heartbeat?.cancel();
      CallAlertController.stop();
      messaging.setOnline(false).catchError((_) {});
    }
  }

  @override
  void didUpdateWidget(covariant ChatPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    LikedinNotificationService.instance.setConversationVisible(widget.isActive && appResumed);
    if (widget.isActive && !oldWidget.isActive && appResumed) {
      if (peerId != null) unawaited(_watchChatIncomingCalls());
      _loadMessages().then((_) => _markVisibleMessagesRead()).catchError((_) {});
    } else if (!widget.isActive && oldWidget.isActive) {
      CallAlertController.stop();
    }
  }

  bool get _isNearBottom {
    if (!_chatScrollController.hasClients) return true;
    return _chatScrollController.position.pixels <= 100;
  }

  void _updateScrollButton() {
    if (!mounted || !_chatScrollController.hasClients) return;
    final shouldShow = !_isNearBottom;
    if (shouldShow != _showScrollToBottomNotifier.value) {
      _showScrollToBottomNotifier.value = shouldShow;
    }
    final position = _chatScrollController.position;
    if (_initialChatPositioned &&
        !_loadingMessages &&
        !_loadingOlderMessages &&
        _hasOlderMessages &&
        position.maxScrollExtent - position.pixels <= 180) {
      unawaited(_loadOlderMessages());
    }
  }

  void _scrollToLatest({bool animated = true}) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || !_chatScrollController.hasClients) return;
      if (_chatScrollController.position.pixels <= 0.5) {
        if (_showScrollToBottomNotifier.value) _showScrollToBottomNotifier.value = false;
        return;
      }
      if (animated) {
        _chatScrollController.animateTo(
          0,
          duration: const Duration(milliseconds: 240),
          curve: Curves.easeOutCubic,
        );
      } else {
        _chatScrollController.jumpTo(0);
      }
      if (_showScrollToBottomNotifier.value) _showScrollToBottomNotifier.value = false;
    });
  }

  Map<String, dynamic>? _decodeMediaPayloadCached(String text) {
    if (_decodedMediaCache.containsKey(text)) return _decodedMediaCache[text];
    if (_decodedMediaCache.length > 600) _decodedMediaCache.clear();
    final decoded = _mediaService.decode(text);
    _decodedMediaCache[text] = decoded;
    return decoded;
  }

  String _summarizeMessage(RemoteMessage message) {
    if (message.deletedForEveryoneAt != null) return 'This message was deleted';
    final decoded = _decodeMediaPayloadCached(message.text);
    if (decoded != null) {
      return _mediaService.describePayload(decoded);
    }
    return message.text;
  }

  /// Returns the committed database ID for a reply target. Optimistic message
  /// objects temporarily use clientMessageId as their local ID; that value is
  /// not the messages.id foreign key stored in reply_to_message_id.
  Future<String?> _resolveReplyTargetId(RemoteMessage? target) async {
    if (target == null) return null;
    final clientId = target.clientMessageId;
    if (clientId == null || target.id != clientId) return target.id;

    final committed = await Supabase.instance.client
        .from('messages')
        .select('id')
        .eq('sender_id', target.senderId)
        .eq('client_message_id', clientId)
        .maybeSingle();
    final resolved = committed?['id']?.toString();
    if (resolved == null || resolved.isEmpty) {
      throw StateError('Wait until that message finishes sending before replying to it.');
    }
    return resolved;
  }

  /// Like [_resolveReplyTargetId], but for flows where the user's file would be
  /// lost on failure (voice notes, camera photos). Retries for a few seconds
  /// while the reply target finishes sending, then falls back to sending the
  /// file without a reply link instead of discarding it.
  Future<String?> _resolveReplyTargetIdOrNull(RemoteMessage? target) async {
    if (target == null) return null;
    var networkFailure = false;
    for (var attempt = 0; attempt < 4; attempt++) {
      try {
        return await _resolveReplyTargetId(target);
      } on StateError {
        if (attempt < 3) await Future<void>.delayed(const Duration(milliseconds: 800));
      } catch (error) {
        debugPrint('Reply target lookup failed; sending without a reply link: $error');
        networkFailure = true;
        break;
      }
      if (!mounted) return null;
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(networkFailure
            ? 'Could not check the message you replied to, so this was sent without the reply link.'
            : 'The message you replied to was still sending, so this was sent without the reply link.')),
      );
    }
    return null;
  }

  /// Merges database rows and optimistic local rows using the stable client
  /// id. A successfully persisted message replaces its local placeholder,
  /// even when its Postgres primary key differs. This prevents a stale grey
  /// optimistic bubble from surviving beside the delivered copy.
  List<RemoteMessage> _mergeMessagesByClientId(Iterable<RemoteMessage> source) =>
      mergeMessagesByClientId(source);

  String get _remoteCleanupStorageKey =>
      'likedin_remote_deleted_media_v1_${messaging.currentUserId}_${peerId ?? 'unknown'}';

  String get _deletedMediaCursorKey =>
      'likedin_deleted_media_cursor_v1_${messaging.currentUserId}_${peerId ?? 'unknown'}';

  Future<void> _reconcileDeletedMediaTombstones() async {
    final prefs = await SharedPreferences.getInstance();
    final rawCursor = prefs.getString(_deletedMediaCursorKey);
    final since = rawCursor == null ? null : DateTime.tryParse(rawCursor);
    final deletedMedia = await messaging.loadDeletedMediaMessages(since: since);
    if (deletedMedia.isNotEmpty) {
      final allCleaned = await _purgeDeletedMediaCaches(deletedMedia);
      if (allCleaned) {
        DateTime? newestDeletedAt;
        for (final item in deletedMedia) {
          final deletedAt = item.deletedForEveryoneAt;
          if (deletedAt != null &&
              (newestDeletedAt == null || deletedAt.isAfter(newestDeletedAt))) {
            newestDeletedAt = deletedAt;
          }
        }
        if (newestDeletedAt != null) {
          await prefs.setString(
            _deletedMediaCursorKey,
            newestDeletedAt.toUtc().toIso8601String(),
          );
        }
      }
    } else if (since == null) {
      await prefs.setString(
        _deletedMediaCursorKey,
        DateTime.now().toUtc().toIso8601String(),
      );
    }
  }

  Future<bool> _ensureRemoteCleanedPathsLoaded() {
    if (_remoteCleanedPathsLoaded) return Future<bool>.value(true);
    final running = _remoteCleanedPathsLoadFuture;
    if (running != null) return running;
    late final Future<bool> load;
    load = () async {
      try {
        final raw = await _localChatSecureStorage.read(key: _remoteCleanupStorageKey);
        if (raw != null && raw.isNotEmpty) {
          final decoded = jsonDecode(raw);
          if (decoded is List) {
            _remoteCleanedPaths.addAll(decoded.whereType<String>().where((value) => value.isNotEmpty));
          }
        }
        _remoteCleanedPathsLoaded = true;
        return true;
      } catch (error) {
        // Do not assume an unreadable marker is empty: doing so would issue all
        // historical Storage deletes again. A later call gets another chance.
        debugPrint('Deleted-media cleanup history could not be read: $error');
        return false;
      } finally {
        if (!_remoteCleanedPathsLoaded && identical(_remoteCleanedPathsLoadFuture, load)) {
          _remoteCleanedPathsLoadFuture = null;
        }
      }
    }();
    _remoteCleanedPathsLoadFuture = load;
    return load;
  }

  Future<void> _persistRemoteCleanedPaths() async {
    try {
      await _localChatSecureStorage.write(
        key: _remoteCleanupStorageKey,
        value: jsonEncode(_remoteCleanedPaths.toList(growable: false)),
      );
    } catch (error) {
      debugPrint('Deleted-media cleanup history could not be saved: $error');
    }
  }

  Future<bool> _purgeDeletedMediaCaches(Iterable<RemoteMessage> items) async {
    final media = SharedMediaService(Supabase.instance.client);
    final ownedPaths = <String>{};
    var allSucceeded = true;
    final deletedItems = items.where((item) =>
        item.deletedForEveryoneAt != null &&
        item.deletedMediaPath != null && item.deletedMediaPath!.isNotEmpty).toList();
    for (final item in deletedItems) {
      final path = item.deletedMediaPath!;
      try {
        await media.deleteCachedPath(path);
      } catch (error) {
        allSucceeded = false;
        debugPrint('Could not remove cached deleted attachment: $error');
      }
      // Only the sender owns the Storage object. The receiver clears its
      // local cached copy; the sender remembers successful remote cleanup
      // across app restarts to avoid repeatedly deleting old tombstones.
      if (item.senderId == messaging.currentUserId) ownedPaths.add(path);
    }
    if (ownedPaths.isEmpty) return allSucceeded;
    if (!await _ensureRemoteCleanedPathsLoaded()) return false;
    final pending = ownedPaths
        .where((path) => !_remoteCleanedPaths.contains(path) &&
            !_remoteCleanupInFlightPaths.contains(path))
        .toList();
    if (pending.isEmpty) return allSucceeded;
    _remoteCleanupInFlightPaths.addAll(pending);
    try {
      await media.deleteRemotePaths(pending);
      _remoteCleanedPaths.addAll(pending);
      await _persistRemoteCleanedPaths();
    } catch (error) {
      allSucceeded = false;
      debugPrint('Remote deleted attachment cleanup will be retried: $error');
    } finally {
      _remoteCleanupInFlightPaths.removeAll(pending);
    }
    return allSucceeded;
  }

  /// Loads the newest page. Every call gets a future that completes only when
  /// a load that STARTED AFTER the call has finished, and it completes with that
  /// load's result: success, or the same error. So a caller never proceeds on
  /// data older than its trigger, and never believes a failed refresh worked.
  /// Calls that arrive while a load is running are batched into one follow-up
  /// load; calls that arrive during that follow-up get another, and so on.
  Future<void> _loadMessages() {
    final completer = Completer<void>();
    _loadWaiters.add(MapEntry<int, Completer<void>>(++_loadRequestSeq, completer));
    if (!_loadRunnerActive) {
      _loadRunnerActive = true;
      unawaited(_runLoadLoop());
    }
    return completer.future;
  }

  Future<void> _runLoadLoop() async {
    try {
      while (_loadWaiters.isNotEmpty) {
        // Requests up to this number are covered by the load that starts now.
        final coveredSeq = _loadRequestSeq;
        Object? failure;
        StackTrace? failureTrace;
        try {
          if (mounted) await _loadMessagesNow();
        } catch (error, trace) {
          failure = error;
          failureTrace = trace;
        }
        final done = _loadWaiters.where((w) => w.key <= coveredSeq).toList();
        _loadWaiters.removeWhere((w) => w.key <= coveredSeq);
        for (final waiter in done) {
          if (waiter.value.isCompleted) continue;
          if (failure != null) {
            waiter.value.completeError(failure, failureTrace);
          } else {
            waiter.value.complete();
          }
        }
        if (!mounted) {
          for (final waiter in _loadWaiters) {
            if (!waiter.value.isCompleted) waiter.value.complete();
          }
          _loadWaiters.clear();
        }
      }
    } finally {
      _loadRunnerActive = false;
    }
  }

  /// Refreshes the list after an action that has already succeeded. A refresh
  /// failure must not be reported as a failure of the action itself.
  Future<void> _refreshMessagesQuietly() async {
    try {
      await _loadMessages();
    } catch (error) {
      debugPrint('Post-action refresh failed (the action itself succeeded): $error');
    }
  }

  Future<void> _loadMessagesNow() async {
    _loadingMessages = true;
    final hadInitialPosition = _initialChatPositioned;
    final wasAtBottom = !hadInitialPosition || _isNearBottom;
    try {
      var loaded = await E2eeService.instance.decryptMessages(
        await messaging.loadConversation(limit: RealtimeMessagingService.conversationPageSize),
      );
      // If a full newest page does not overlap what is already loaded, more
      // than one page arrived while we were away. Fetch the missing middle
      // (bounded to 20 pages) so the timeline has no hole. If the budget runs
      // out we keep only the fresh pages and let "Load older" fill the rest,
      // rather than showing a window with an unreachable gap.
      var catchUpCapped = false;
      if (messages.isNotEmpty) {
        final catchUp = await catchUpNewestPages(
          newestPage: loaded,
          known: List<RemoteMessage>.of(messages),
          pageSize: RealtimeMessagingService.conversationPageSize,
          maxPages: 20,
          fetchOlder: (cursor) async => E2eeService.instance.decryptMessages(
            await messaging.loadConversation(
              beforeCreatedAt: cursor.createdAt,
              beforeId: cursor.id,
              limit: RealtimeMessagingService.conversationPageSize,
            ),
          ),
        );
        loaded = catchUp.messages;
        catchUpCapped = catchUp.capped;
      }
      // After a capped catch-up the older local window is no longer contiguous
      // with the new pages; carry over only messages still being sent.
      List<RemoteMessage> baseMessages() => catchUpCapped
          ? messages.where((m) => m.clientMessageId != null && m.id == m.clientMessageId).toList()
          : List<RemoteMessage>.of(messages);
      await _purgeDeletedMediaCaches(loaded);
      if (!mounted) return;

      // Reactions are refreshed for every loaded message with a committed ID,
      // not just the newest page, so reactions on messages brought in through
      // "Load older" or "Jump to reply" stay current.
      final preliminary = _mergeMessagesByClientId([...baseMessages(), ...loaded]);
      final reactionIds = reactionIdsToFetch(preliminary, _reactionHydratedMessageIds);
      Map<String, Map<String, Set<String>>> detailedReactions =
          <String, Map<String, Set<String>>>{};
      Map<String, Set<String>> remoteReactions = <String, Set<String>>{};
      var reactionsRefreshed = false;
      try {
        detailedReactions = await messaging.loadDetailedReactions(reactionIds);
        _reactionHydratedMessageIds.addAll(reactionIds);
        remoteReactions = <String, Set<String>>{
          for (final entry in detailedReactions.entries)
            entry.key: entry.value.keys.toSet(),
        };
        reactionsRefreshed = true;
      } catch (error) {
        // Reaction availability must never determine whether the chat itself
        // can be displayed. Keep cached reactions and render the messages.
        debugPrint('Reaction refresh failed; displaying messages without new reactions: $error');
      }
      if (!mounted) return;

      final preliminaryIds = preliminary.map((m) => m.id).toSet();
      final missingReplyIds = preliminary
          .map((item) => item.replyToMessageId)
          .whereType<String>()
          .where((id) => !preliminaryIds.contains(id))
          .toSet();
      var fetchedReferences = <RemoteMessage>[];
      if (missingReplyIds.isNotEmpty) {
        try {
          fetchedReferences = await E2eeService.instance.decryptMessages(
            await messaging.loadMessagesByIds(missingReplyIds),
          );
          if (!mounted) return;
        } catch (error) {
          debugPrint('Some reply previews will be generic until their originals load: $error');
        }
      }

      // Merge against the list as it is NOW. Anything that arrived or was sent
      // while the awaits above were running is kept instead of overwritten.
      final mergedMessages = _mergeMessagesByClientId([...baseMessages(), ...loaded]);
      final originalsById = <String, RemoteMessage>{
        for (final item in mergedMessages) item.id: item,
      };
      final replySourceById = Map<String, RemoteMessage>.from(originalsById);
      for (final item in fetchedReferences) {
        replySourceById.putIfAbsent(item.id, () => item);
      }
      if (!_initialLoadCompleted) {
        _initialLoadCompleted = true;
        _hasOlderMessages = loaded.length >= RealtimeMessagingService.conversationPageSize;
      }
      if (catchUpCapped) _hasOlderMessages = true;
      _lastLoadCompletedAt = DateTime.now();
      _messageKeys.removeWhere((id, _) => !originalsById.containsKey(id));
      while (_messageKeys.length > 260) {
        _messageKeys.remove(_messageKeys.keys.first);
      }
      setState(() {
        messages
          ..clear()
          ..addAll(mergedMessages);
        _invalidateMessageViewCache();
        if (reactionsRefreshed) {
          for (final id in reactionIds) {
            _messageReactions.remove(id);
            _messageReactionUsers.remove(id);
          }
          _messageReactions.addAll(remoteReactions);
          _messageReactionUsers.addAll(detailedReactions);
        }
        _messageReactions.removeWhere((id, _) => !originalsById.containsKey(id));
        _messageReactionUsers.removeWhere((id, _) => !originalsById.containsKey(id));
        _reactionHydratedMessageIds.removeWhere((id) => !originalsById.containsKey(id));
        _replyTargets
          ..clear()
          ..addEntries(mergedMessages.where((m) => m.replyToMessageId != null).map((m) {
            final original = replySourceById[m.replyToMessageId];
            return MapEntry(
              m.id,
              original == null ? 'Replying to a message' : _summarizeMessage(original),
            );
          }));
        _replySourceMessages
          ..clear()
          ..addEntries(
            mergedMessages
                .where((m) => m.replyToMessageId != null &&
                    replySourceById.containsKey(m.replyToMessageId))
                .map((m) => MapEntry(m.id, replySourceById[m.replyToMessageId]!)),
          );
        messagesLoading = false;
        loadError = null;
      });
      if (wasAtBottom) {
        _initialChatPositioned = true;
        _scrollToLatest(animated: hadInitialPosition);
      } else {
        WidgetsBinding.instance.addPostFrameCallback((_) => _updateScrollButton());
      }
    } catch (error) {
      debugPrint('Conversation page load failed: $error');
      if (mounted) {
        setState(() {
          messagesLoading = false;
          loadError = 'Could not connect to messaging. Check your connection and try again.';
        });
      }
      rethrow;
    } finally {
      _loadingMessages = false;
    }
  }

  /// Loads one page of older messages. With [reachMessageId], keeps paging
  /// until that message is included, so the loaded timeline stays contiguous
  /// (no gap between the target and the previously loaded window).
  /// Returns false if nothing could be loaded.
  Future<bool> _loadOlderMessages({String? reachMessageId, DateTime? reachCreatedAt}) {
    // Single flight: callers that arrive during a load share its future.
    final running = _olderLoadInFlight;
    if (running != null) return running;
    late final Future<bool> wrapped;
    wrapped = _loadOlderMessagesNow(reachMessageId: reachMessageId, reachCreatedAt: reachCreatedAt)
        .whenComplete(() {
      if (identical(_olderLoadInFlight, wrapped)) _olderLoadInFlight = null;
    });
    _olderLoadInFlight = wrapped;
    return wrapped;
  }

  Future<bool> _loadOlderMessagesNow({String? reachMessageId, DateTime? reachCreatedAt}) async {
    if (!mounted || _loadingOlderMessages || !_hasOlderMessages || messages.isEmpty) return false;
    var cursor = messages.first;
    setState(() => _loadingOlderMessages = true);
    try {
      final older = <RemoteMessage>[];
      var lastPageFull = true;
      var pagesFetched = 0;
      while (true) {
        if (reachMessageId != null && _cancelJumpToReplyRequested) break;
        pagesFetched++;
        final page = await E2eeService.instance.decryptMessages(
          await messaging.loadConversation(
            beforeCreatedAt: cursor.createdAt,
            beforeId: cursor.id,
            limit: RealtimeMessagingService.conversationPageSize,
          ),
        );
        older.insertAll(0, page);
        lastPageFull = page.length >= RealtimeMessagingService.conversationPageSize;
        if (page.isNotEmpty) cursor = page.first;
        // Pages follow the database's (created_at, id) order, so the target's
        // ID is the only reliable proof it was reached. Timestamps alone are
        // used just to detect that it can no longer exist: once the oldest row
        // fetched is STRICTLY older than the target, every row at or after the
        // target's timestamp has already been seen. Equal timestamps keep going.
        final reached = reachMessageId == null ||
            older.any((m) => m.id == reachMessageId) ||
            (reachCreatedAt != null && page.isNotEmpty && page.first.createdAt.isBefore(reachCreatedAt));
        // Cap targeted jumps so a very old reply can't page the whole history.
        if (reached || !lastPageFull || page.isEmpty || !mounted || pagesFetched >= 50) break;
      }
      await _purgeDeletedMediaCaches(older);
      if (!mounted) return false;

      final existingIds = messages.map((message) => message.id).toSet();
      final additions = older.where((message) => !existingIds.contains(message.id)).toList();
      Map<String, Map<String, Set<String>>> olderDetailedReactions =
          <String, Map<String, Set<String>>>{};
      Map<String, Set<String>> olderReactions = <String, Set<String>>{};
      final olderReactionIds = additions
          .map((message) => message.id)
          .where((id) => !_reactionHydratedMessageIds.contains(id))
          .toList();
      try {
        olderDetailedReactions = await messaging.loadDetailedReactions(olderReactionIds);
        _reactionHydratedMessageIds.addAll(olderReactionIds);
        olderReactions = <String, Set<String>>{
          for (final entry in olderDetailedReactions.entries)
            entry.key: entry.value.keys.toSet(),
        };
      } catch (error) {
        debugPrint('Older-message reactions could not be loaded: $error');
      }

      final preliminary = _mergeMessagesByClientId([...additions, ...messages]);
      final preliminaryIds = preliminary.map((m) => m.id).toSet();
      final missingReplyIds = preliminary
          .map((item) => item.replyToMessageId)
          .whereType<String>()
          .where((id) => !preliminaryIds.contains(id))
          .toSet();
      var fetchedReferences = <RemoteMessage>[];
      if (missingReplyIds.isNotEmpty) {
        try {
          fetchedReferences = await E2eeService.instance.decryptMessages(
            await messaging.loadMessagesByIds(missingReplyIds),
          );
          if (!mounted) return false;
        } catch (error) {
          debugPrint('Older-page reply previews remain partial: $error');
        }
      }

      // Merge against the list as it is now so a message that arrived during
      // the awaits above is not dropped.
      final mergedMessages = _mergeMessagesByClientId([...additions, ...messages]);
      final originalsById = <String, RemoteMessage>{for (final item in mergedMessages) item.id: item};
      final replySourceById = Map<String, RemoteMessage>.from(originalsById);
      for (final item in fetchedReferences) {
        replySourceById.putIfAbsent(item.id, () => item);
      }
      setState(() {
        messages
          ..clear()
          ..addAll(mergedMessages);
        _invalidateMessageViewCache();
        _messageReactions.addAll(olderReactions);
        _messageReactionUsers.addAll(olderDetailedReactions);
        _replyTargets
          ..clear()
          ..addEntries(mergedMessages.where((m) => m.replyToMessageId != null).map((m) {
            final original = replySourceById[m.replyToMessageId];
            return MapEntry(
              m.id,
              original == null ? 'Replying to a message' : _summarizeMessage(original),
            );
          }));
        _replySourceMessages
          ..clear()
          ..addEntries(
            mergedMessages
                .where((m) => m.replyToMessageId != null &&
                    replySourceById.containsKey(m.replyToMessageId))
                .map((m) => MapEntry(m.id, replySourceById[m.replyToMessageId]!)),
          );
        _hasOlderMessages = lastPageFull;
        _loadingOlderMessages = false;
      });
      if (_messageKeys.keys.any((id) => !originalsById.containsKey(id))) {
        _messageKeys.removeWhere((id, _) => !originalsById.containsKey(id));
      }
      while (_messageKeys.length > 260) {
        _messageKeys.remove(_messageKeys.keys.first);
      }
      return true;
    } catch (error) {
      debugPrint('Older conversation page could not be loaded: $error');
      if (mounted) setState(() => _loadingOlderMessages = false);
      return false;
    }
  }

  Future<void> _jumpToMessage(String messageId) async {
    if (_jumpToReplyInProgress) {
      _cancelJumpToReplyRequested = true;
      return;
    }
    setState(() {
      _jumpToReplyInProgress = true;
      _cancelJumpToReplyRequested = false;
    });
    try {
      await _jumpToMessageImpl(messageId);
    } finally {
      if (mounted) setState(() => _jumpToReplyInProgress = false);
    }
  }

  Future<void> _jumpToMessageImpl(String messageId) async {
    // Search filters can hide an already-loaded original, so remove them before
    // resolving the target. Do not report a false "not loaded" error just
    // because the lazy ListView has not built that row yet.
    if (_hasActiveMessageSearch) _clearMessageSearch();

    RemoteMessage? target;
    for (final message in messages) {
      if (message.id == messageId) {
        target = message;
        break;
      }
    }
    if (target == null) {
      for (final original in _replySourceMessages.values) {
        if (original.id == messageId) {
          target = original;
          break;
        }
      }
    }

    if (target == null) {
      try {
        final matches = await messaging.loadMessagesByIds(<String>{messageId});
        if (!mounted) return;
        if (matches.isNotEmpty) target = matches.first;
      } catch (error) {
        debugPrint('Reply target lookup failed: $error');
      }
    }
    if (!mounted) return;

    final resolvedTarget = target;
    if (resolvedTarget == null || _hiddenMessageIds.contains(resolvedTarget.id)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('That original message is no longer available on this phone.')),
      );
      return;
    }

    // A message cleared from this phone can never become visible; do not page
    // through history just to discover that.
    final clearedBefore = _clearedBeforeMs;
    if (clearedBefore != null &&
        resolvedTarget.createdAt.millisecondsSinceEpoch <= clearedBefore &&
        !_postClearVisibleMessageIds.contains(resolvedTarget.id) &&
        !(resolvedTarget.clientMessageId != null &&
            _postClearVisibleMessageIds.contains(resolvedTarget.clientMessageId))) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('That original message is not visible on this phone.')),
      );
      return;
    }

    if (!messages.any((message) => message.id == resolvedTarget.id)) {
      final targetIsOlderThanWindow = messages.isNotEmpty &&
          resolvedTarget.createdAt.isBefore(messages.first.createdAt);
      if (targetIsOlderThanWindow) {
        // Page backwards until the target is loaded. Inserting only the target
        // would leave every message between it and the current window
        // unreachable, because "Load older" pages from the oldest loaded row.
        // Keep going until the target is loaded: wait for any load already in
        // flight (however long it takes), then start one aimed at the target.
        var reachAttempted = false;
        while (mounted && !_cancelJumpToReplyRequested &&
            !messages.any((message) => message.id == resolvedTarget.id)) {
          final running = _olderLoadInFlight;
          if (running != null) {
            await running;
            continue;
          }
          // One targeted load is enough: it pages until the target is found or
          // the history is exhausted. If it still is not there, give up.
          if (reachAttempted) break;
          reachAttempted = true;
          if (!_hasOlderMessages) setState(() => _hasOlderMessages = true);
          await _loadOlderMessages(
            reachMessageId: resolvedTarget.id,
            reachCreatedAt: resolvedTarget.createdAt,
          );
        }
        if (!mounted || _cancelJumpToReplyRequested) return;
        if (!messages.any((message) => message.id == resolvedTarget.id)) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Could not load the earlier messages. Check your connection and try again.')),
          );
          return;
        }
      } else {
        setState(() {
          messages.add(resolvedTarget);
          messages.sort((a, b) {
            final byTime = a.createdAt.compareTo(b.createdAt);
            return byTime != 0 ? byTime : a.id.compareTo(b.id);
          });
          _invalidateMessageViewCache();
        });
      }
    }

    await WidgetsBinding.instance.endOfFrame;
    if (!mounted || !_chatScrollController.hasClients) return;
    var rows = _chatDisplayMessages;
    var index = rows.indexWhere((message) => message.id == messageId);
    if (index < 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('That original message is not visible on this phone.')),
      );
      return;
    }

    // The list is lazy, so the target row may not be built yet. Scroll toward
    // it, and keep correcting from whichever rows ARE built until it appears.
    for (var attempt = 0; attempt < 14; attempt++) {
      if (!mounted || _cancelJumpToReplyRequested || !_chatScrollController.hasClients) return;
      final targetContext = _messageKeys[messageId]?.currentContext;
      if (targetContext != null && targetContext.mounted) {
        await Scrollable.ensureVisible(
          targetContext, duration: const Duration(milliseconds: 250),
          curve: Curves.easeInOut, alignment: .25,
        );
        return;
      }
      rows = _chatDisplayMessages;
      index = rows.indexWhere((message) => message.id == messageId);
      if (index < 0) return;
      final position = _chatScrollController.position;
      final hasOlderHeader = _hasOlderMessages || _loadingOlderMessages;
      final hasTypingFooter = peerTyping && !_hasActiveMessageSearch;
      final rowCount = rows.length + (hasOlderHeader ? 1 : 0) + (hasTypingFooter ? 1 : 0);
      // In a reverse: true ListView, index 0 is the newest message (offset 0)
      // and older messages sit at larger scroll offsets.
      final reversedTargetIndex = (rows.length - 1 - index) + (hasTypingFooter ? 1 : 0);

      var minBuilt = -1;
      var maxBuilt = -1;
      for (var i = 0; i < rows.length; i++) {
        if (_messageKeys[rows[i].id]?.currentContext != null) {
          if (minBuilt < 0) minBuilt = i;
          maxBuilt = i;
        }
      }
      double nextOffset;
      if (minBuilt < 0) {
        final fraction = ((reversedTargetIndex + .5) / rowCount).clamp(0.0, 1.0);
        nextOffset = position.maxScrollExtent * fraction;
      } else {
        final avgRow = ((position.maxScrollExtent + position.viewportDimension) / rowCount)
            .clamp(40.0, 600.0)
            .toDouble();
        if (index < minBuilt) {
          // Target is older than the built window -> scroll further from bottom (increase offset).
          final step = ((minBuilt - index) * avgRow).clamp(position.viewportDimension * .5, double.infinity);
          nextOffset = position.pixels + step;
        } else if (index > maxBuilt) {
          // Target is newer than the built window -> scroll closer to bottom (decrease offset).
          final step = ((index - maxBuilt) * avgRow).clamp(position.viewportDimension * .5, double.infinity);
          nextOffset = position.pixels - step;
        } else {
          // Inside the built range but its key is not mounted yet.
          await WidgetsBinding.instance.endOfFrame;
          continue;
        }
      }
      nextOffset = nextOffset.clamp(position.minScrollExtent, position.maxScrollExtent).toDouble();
      if ((nextOffset - position.pixels).abs() < 1) {
        await WidgetsBinding.instance.endOfFrame;
        continue;
      }
      if (attempt == 0) {
        await _chatScrollController.animateTo(
          nextOffset, duration: const Duration(milliseconds: 280), curve: Curves.easeOut,
        );
      } else {
        _chatScrollController.jumpTo(nextOffset);
      }
      await WidgetsBinding.instance.endOfFrame;
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not scroll to that message. Please try again.')),
      );
    }
  }

  void _handleRealtimeMessageInsert(Map<String, dynamic> row) {
    unawaited(_handleRealtimeMessageInsertAsync(row));
  }

  Future<void> _handleRealtimeMessageInsertAsync(Map<String, dynamic> row) async {
    try {
      final incoming = await E2eeService.instance.decryptMessage(RemoteMessage.fromMap(row));
      if (incoming.id.isEmpty || !mounted) {
        unawaited(_handleIncomingMessages());
        return;
      }
      final wasAtBottom = !_initialChatPositioned || _isNearBottom;
      if (_clearedBeforeMs != null &&
          incoming.createdAt.millisecondsSinceEpoch <= _clearedBeforeMs!) {
        _postClearVisibleMessageIds.add(incoming.id);
        final clientId = incoming.clientMessageId;
        if (clientId != null && clientId.isNotEmpty) {
          _postClearVisibleMessageIds.add(clientId);
        }
        unawaited(_saveLocalChatState());
      }
      final merged = _mergeMessagesByClientId([...messages, incoming]);
      final replyTargetId = incoming.replyToMessageId;
      RemoteMessage? replySource;
      if (replyTargetId != null) {
        for (final m in merged) {
          if (m.id == replyTargetId) {
            replySource = m;
            break;
          }
        }
      }
      setState(() {
        messages
          ..clear()
          ..addAll(merged);
        _invalidateMessageViewCache();
        if (replyTargetId != null) {
          _replyTargets[incoming.id] = replySource == null
              ? 'Replying to a message'
              : _summarizeMessage(replySource);
          if (replySource != null) {
            _replySourceMessages[incoming.id] = replySource;
          }
        }
      });
      if (wasAtBottom) {
        _initialChatPositioned = true;
        _scrollToLatest(animated: true);
      }
      if (replyTargetId != null && replySource == null) {
        unawaited(messaging.loadMessagesByIds(<String>{replyTargetId}).then((refs) {
          if (!mounted || refs.isEmpty) return;
          final original = refs.first;
          setState(() {
            _replyTargets[incoming.id] = _summarizeMessage(original);
            _replySourceMessages[incoming.id] = original;
          });
        }).catchError((_) {}));
      }
      if (appResumed) {
        unawaited(_acknowledgeReceiptsOnly());
      }
    } catch (error) {
      debugPrint('Direct realtime insert fallback to full reload: $error');
      unawaited(_handleIncomingMessages());
    }
  }

  Future<void> _acknowledgeReceiptsOnly() async {
    if (!mounted || !appResumed) return;
    final me = messaging.currentUserId;
    if (_markingDelivered) {
      _deliveryMarkRequested = true;
    } else {
      _markingDelivered = true;
      try {
        _deliveryMarkRequested = false;
        await acknowledgePendingReceiptPasses(
          pendingIds: () => messages
              .where((m) => m.recipientId == me && m.deliveredAt == null)
              .map((m) => m.id)
              .toSet(),
          acknowledgeOnServer: messaging.markDelivered,
          applyLocally: (ids) => _applyLocalReceipt(delivered: true, onlyIds: ids),
        );
      } catch (_) {
      } finally {
        _markingDelivered = false;
        if (_deliveryMarkRequested && mounted && appResumed) {
          _deliveryMarkRequested = false;
          unawaited(_acknowledgeReceiptsOnly());
        }
      }
    }
    if (widget.isActive) await _markVisibleMessagesRead();
  }

  void _handleRealtimeMessageUpdate(Map<String, dynamic> row) {
    unawaited(_handleRealtimeMessageUpdateAsync(row));
  }

  Future<void> _handleRealtimeMessageUpdateAsync(Map<String, dynamic> row) async {
    try {
      final rawId = row['id']?.toString();
      final rawClientId = row['client_message_id']?.toString();
      var index = rawId == null ? -1 : messages.indexWhere((message) => message.id == rawId);
      // A receipt update can arrive while this device still has the optimistic
      // client ID. Match that stable ID and promote the row instead of leaving
      // a grey placeholder next to the persisted server row.
      if (index < 0 && rawClientId != null) {
        index = messages.indexWhere((message) =>
            message.id == rawClientId || message.clientMessageId == rawClientId);
      }
      if (index < 0 || !mounted) return;
      final previous = messages[index];
      // Realtime UPDATE rows may include legacy payload columns with null or
      // empty values. Key presence is not proof that the message body arrived.
      // Select the first usable payload across current and legacy schemas.
      final incomingBody = resolveRealtimeMessageBody(row, fallback: previous.text);
      final mergedRow = <String, dynamic>{
        'id': previous.id,
        'client_message_id': previous.clientMessageId,
        'sender_id': previous.senderId,
        'recipient_id': previous.recipientId,
        'created_at': previous.createdAt.toUtc().toIso8601String(),
        'reply_to_message_id': previous.replyToMessageId,
        'delivered_at': previous.deliveredAt?.toUtc().toIso8601String(),
        'read_at': previous.readAt?.toUtc().toIso8601String(),
        'edited_at': previous.editedAt?.toUtc().toIso8601String(),
        'deleted_for_everyone_at': previous.deletedForEveryoneAt?.toUtc().toIso8601String(),
        'deleted_media_path': previous.deletedMediaPath,
      };
      mergedRow.addAll(row);
      // Apply fallback AFTER addAll, otherwise a present-but-null legacy key
      // overwrites it and RemoteMessage.fromMap produces blank text.
      mergedRow['body_payload'] = incomingBody;
      final updated = await E2eeService.instance.decryptMessage(RemoteMessage.fromMap(mergedRow));
      final previousId = previous.id;
      setState(() {
        messages[index] = updated;
        _invalidateMessageViewCache();
        if (previousId != updated.id) {
          final quote = _replyTargets.remove(previousId);
          if (quote != null) _replyTargets[updated.id] = quote;
          final quoteSource = _replySourceMessages.remove(previousId);
          if (quoteSource != null) _replySourceMessages[updated.id] = quoteSource;
        }
        // Keep reply quotes pointing to this message in sync after realtime edits/deletes.
        final updatedSummary = _summarizeMessage(updated);
        for (final reply in messages) {
          final targetId = reply.replyToMessageId;
          if (targetId == updated.id || targetId == previousId) {
            _replyTargets[reply.id] = updatedSummary;
            _replySourceMessages[reply.id] = updated;
          }
        }
      });
      if (previousId != updated.id) {
        final messageKey = _messageKeys.remove(previousId);
        if (messageKey != null) _messageKeys[updated.id] = messageKey;
      }
      if (updated.deletedForEveryoneAt != null && updated.deletedMediaPath != null) {
        unawaited(_purgeDeletedMediaCaches([updated]));
      }
    } catch (error) {
      debugPrint('Could not apply realtime message update: $error');
    }
  }

  void _scheduleSingleMessageReactionRefresh(String messageId) {
    _reactionRefreshTimers.remove(messageId)?.cancel();
    _reactionRefreshTimers[messageId] = Timer(const Duration(milliseconds: 140), () {
      _reactionRefreshTimers.remove(messageId);
      unawaited(_refreshSingleMessageReaction(messageId));
    });
  }

  Future<void> _refreshSingleMessageReaction(String messageId) async {
    if (!mounted || !messages.any((message) => message.id == messageId)) return;
    try {
      final result = await messaging.loadDetailedReactions(<String>[messageId]);
      if (!mounted) return;
      final users = result[messageId] ?? <String, Set<String>>{};
      setState(() {
        _messageReactionUsers.remove(messageId);
        _messageReactions.remove(messageId);
        if (users.isNotEmpty) {
          _messageReactionUsers[messageId] = users;
          _messageReactions[messageId] = users.keys.toSet();
        }
        _reactionHydratedMessageIds.add(messageId);
        _invalidateMessageViewCache();
      });
    } catch (error) {
      debugPrint('Reaction refresh for $messageId failed: $error');
    }
  }

  /// The Realtime socket re-subscribed after a drop: events may have been
  /// missed, so reload the timeline, refresh loaded historical rows/reactions,
  /// and acknowledge messages that arrived while this device was disconnected.
  void _resyncAfterReconnect() {
    if (!mounted || peerId == null) return;
    _reconnectResyncTimer?.cancel();
    _reconnectResyncTimer = Timer(const Duration(milliseconds: 280), () {
      if (!mounted || peerId == null) return;
      final recentLoad = _lastLoadCompletedAt != null &&
          DateTime.now().difference(_lastLoadCompletedAt!) < const Duration(milliseconds: 1200);
      _reactionHydratedMessageIds.clear();
      if (recentLoad) {
        unawaited(_refreshLoadedMessagesFromServer().catchError((_) {}));
        return;
      }
      unawaited(_handleIncomingMessages(refreshLoadedMessages: true));
    });
  }

  Future<void> _handleIncomingMessages({bool refreshLoadedMessages = false}) async {
    try {
      final beforeIds = messages.map((message) => message.id).toSet();
      final beforeClientIds = messages.map((message) => message.clientMessageId).whereType<String>().toSet();
      try {
        // Completes only after a reload that includes the triggering message,
        // even if another load was already running.
        await _loadMessages();
      } catch (error) {
        debugPrint('Incoming-message reload failed: $error');
      }
      if (refreshLoadedMessages && mounted) {
        try {
          await _refreshLoadedMessagesFromServer();
        } catch (error) {
          // A historical-row refresh must not prevent receipt acknowledgement.
          debugPrint('Loaded historical messages could not be refreshed after reconnect: $error');
        }
      }
      if (_clearedBeforeMs != null) {
        final newlyDelivered = messages.where((message) =>
          !beforeIds.contains(message.id) &&
          (message.clientMessageId == null || !beforeClientIds.contains(message.clientMessageId)));
        var visibilityChanged = false;
        for (final message in newlyDelivered) {
          if (message.createdAt.millisecondsSinceEpoch <= _clearedBeforeMs!) {
            visibilityChanged = _postClearVisibleMessageIds.add(message.id) || visibilityChanged;
            final clientId = message.clientMessageId;
            if (clientId != null) {
              visibilityChanged = _postClearVisibleMessageIds.add(clientId) || visibilityChanged;
            }
          }
        }
        if (visibilityChanged) {
          _invalidateMessageViewCache();
          unawaited(_saveLocalChatState());
        }
      }
      if (!appResumed) return;
      final me = messaging.currentUserId;
      if (_markingDelivered) {
        _deliveryMarkRequested = true;
      } else {
        _markingDelivered = true;
        try {
          _deliveryMarkRequested = false;
          await acknowledgePendingReceiptPasses(
            pendingIds: () => messages
                .where((m) => m.recipientId == me && m.deliveredAt == null)
                .map((m) => m.id)
                .toSet(),
            acknowledgeOnServer: messaging.markDelivered,
            applyLocally: (ids) => _applyLocalReceipt(delivered: true, onlyIds: ids),
          );
          if (messages.any((m) => m.recipientId == me && m.deliveredAt == null)) {
            _deliveryMarkRequested = true;
          } else {
            _deliveryMarkRequested = false;
          }
        } finally {
          _markingDelivered = false;
          if (_deliveryMarkRequested && mounted && appResumed) {
            _deliveryMarkRequested = false;
            unawaited(Future<void>.delayed(Duration.zero).then((_) => _handleIncomingMessages()));
          }
        }
      }
      if (widget.isActive) await _markVisibleMessagesRead();
    } catch (_) {}
  }

  void _applyLocalReceipt({bool delivered = false, bool read = false, required Set<String> onlyIds}) {
    if (!mounted || onlyIds.isEmpty) return;
    setState(() {
      final updated = applyReceiptToIds(
        messages,
        me: messaging.currentUserId,
        onlyIds: onlyIds,
        now: DateTime.now(),
        delivered: delivered,
        read: read,
      );
      messages
        ..clear()
        ..addAll(updated);
      _invalidateMessageViewCache();
    });
  }

  Future<void> _markVisibleMessagesRead() async {
    if (!mounted || !widget.isActive || !appResumed) return;
    if (_markingRead) {
      _readMarkRequested = true;
      return;
    }
    _markingRead = true;
    try {
      // Fresh ID snapshots catch messages that arrive during the RPC. A caller
      // overlapping this operation also sets _readMarkRequested for a follow-up.
      _readMarkRequested = false;
      await acknowledgePendingReceiptPasses(
        pendingIds: () => messages
            .where((m) => m.recipientId == messaging.currentUserId && m.readAt == null)
            .map((m) => m.id)
            .toSet(),
        acknowledgeOnServer: messaging.markRead,
        applyLocally: (ids) => _applyLocalReceipt(delivered: true, read: true, onlyIds: ids),
      );
      if (messages.any((m) => m.recipientId == messaging.currentUserId && m.readAt == null)) {
        _readMarkRequested = true;
      } else {
        _readMarkRequested = false;
      }
    } catch (error) {
      debugPrint('Visible-message read acknowledgement failed: $error');
    } finally {
      _markingRead = false;
      if (_readMarkRequested && mounted && widget.isActive && appResumed) {
        _readMarkRequested = false;
        unawaited(Future<void>.delayed(Duration.zero).then((_) => _markVisibleMessagesRead()));
      }
    }
  }

  /// Refresh every committed message currently loaded in memory, including
  /// older pages. The normal timeline reload fetches only the newest page, so
  /// this closes the offline edit/delete gap for messages loaded via pagination.
  Future<void> _refreshLoadedMessagesFromServer() async {
    final ids = messages
        .where((message) => message.clientMessageId == null || message.id != message.clientMessageId)
        .map((message) => message.id)
        .where((id) => id.isNotEmpty)
        .toSet();
    if (ids.isEmpty) return;

    final previousById = <String, RemoteMessage>{
      for (final message in messages) message.id: message,
    };
    // loadMessagesByIds chunks requests into groups of 100.
    final refreshed = await E2eeService.instance.decryptMessages(
      await messaging.loadMessagesByIds(ids),
    );
    if (!mounted || refreshed.isEmpty) return;

    // Preserve known text if an older/legacy row still has an empty ciphertext.
    final normalized = refreshed.map((fresh) {
      final previous = previousById[fresh.id];
      if (previous == null || fresh.text.isNotEmpty || previous.text.isEmpty) return fresh;
      return RemoteMessage(
        id: fresh.id,
        clientMessageId: fresh.clientMessageId ?? previous.clientMessageId,
        senderId: fresh.senderId,
        recipientId: fresh.recipientId,
        text: previous.text,
        createdAt: fresh.createdAt,
        deliveredAt: fresh.deliveredAt ?? previous.deliveredAt,
        readAt: fresh.readAt ?? previous.readAt,
        replyToMessageId: fresh.replyToMessageId ?? previous.replyToMessageId,
        editedAt: fresh.editedAt ?? previous.editedAt,
        deletedForEveryoneAt: fresh.deletedForEveryoneAt ?? previous.deletedForEveryoneAt,
        deletedMediaPath: fresh.deletedMediaPath ?? previous.deletedMediaPath,
      );
    }).toList();

    await _purgeDeletedMediaCaches(normalized);
    if (!mounted) return;
    final merged = _mergeMessagesByClientId([...messages, ...normalized]);
    final sourceById = <String, RemoteMessage>{
      for (final original in _replySourceMessages.values) original.id: original,
      for (final message in merged) message.id: message,
    };
    final nextReplyTargets = <String, String>{};
    final nextReplySources = <String, RemoteMessage>{};
    for (final message in merged) {
      final targetId = message.replyToMessageId;
      if (targetId == null) continue;
      final original = sourceById[targetId];
      nextReplyTargets[message.id] = original == null
          ? (_replyTargets[message.id] ?? 'Replying to a message')
          : _summarizeMessage(original);
      if (original != null) nextReplySources[message.id] = original;
    }

    setState(() {
      messages
        ..clear()
        ..addAll(merged);
      _replyTargets
        ..clear()
        ..addAll(nextReplyTargets);
      _replySourceMessages
        ..clear()
        ..addAll(nextReplySources);
      _invalidateMessageViewCache();
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    LikedinNotificationService.instance.setConversationVisible(false);
    if (typingTimer != null || _typingPublishTimer != null || _lastTypingSentAt != null) {
      unawaited(messaging.sendTyping(false).catchError((_) {}));
    }
    heartbeat?.cancel();
    typingTimer?.cancel();
    _typingPublishTimer?.cancel();
    peerLookupTimer?.cancel();
    peerTypingExpiryTimer?.cancel();
    peerRecordingExpiryTimer?.cancel();
    if (_recordingVoice) _broadcastActivity(const {'recording': false});
    final activityChannel = _activityChannel;
    if (activityChannel != null) Supabase.instance.client.removeChannel(activityChannel);
    _searchDebounceTimer?.cancel();
    _reconnectResyncTimer?.cancel();
    _connectivitySubscription?.cancel();
    for (final timer in _reactionRefreshTimers.values) {
      timer.cancel();
    }
    _reactionRefreshTimers.clear();
    _voiceTimer?.cancel();
    CallAlertController.stop();
    final incomingChannel = _chatIncomingCallsChannel;
    if (incomingChannel != null) Supabase.instance.client.removeChannel(incomingChannel);
    messaging.setOnline(false).catchError((_) {});
    messaging.unsubscribe();
    controller.dispose();
    _messageSearchController.dispose();
    _composerFocus.dispose();
    nicknameController.dispose();
    _voiceRecorder.dispose();
    _chatScrollController.removeListener(_updateScrollButton);
    _chatScrollController.dispose();
    _floatingDateTimer?.cancel();
    _floatingDateNotifier.dispose();
    _showScrollToBottomNotifier.dispose();
    _voiceRecordSecondsNotifier.dispose();
    super.dispose();
  }

  Future<void> send({String? messageOverride}) async {
    final text = (messageOverride ?? controller.text).trim();
    if (likedinMessageCodePointLength(text) > likedinMaxMessageCodePoints) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Messages can contain up to 10,000 characters.')),
      );
      return;
    }
    // Stickers can be sent as their own message without replacing a typed draft.
    final keepKeyboardOpen = _composerFocus.hasFocus || (messageOverride == null && text.isNotEmpty);
    final recipient = peerId;
    if (text.isEmpty && !saving && _editingMessageId != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("A message can't be empty. Delete it instead if you want it gone.")),
      );
      return;
    }
    if (text.isEmpty || saving || _resolvingSend) return;
    if (_editingMessageId != null) {
      final id = _editingMessageId!;
      // Saving unchanged text must not mark the message as edited.
      if (text == (_editingOriginalText ?? '').trim()) {
        setState(() {
          _editingMessageId = null;
          _editingOriginalText = null;
        });
        _restoreDraftAfterEdit();
        unawaited(messaging.sendTyping(false).catchError((_) {}));
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No changes to save.')),
        );
        return;
      }
      setState(() => saving = true);
      try {
        final encryptedEdit = await E2eeService.instance.encryptIfReady(text);
        await messaging.editMessage(id, encryptedEdit);
        if (!mounted) return;
        setState(() {
          _editingMessageId = null;
          _editingOriginalText = null;
        });
        _restoreDraftAfterEdit();
        if (keepKeyboardOpen) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (!mounted) return;
            _composerFocus.requestFocus();
            SystemChannels.textInput.invokeMethod<void>('TextInput.show');
          });
        }
        unawaited(messaging.sendTyping(false).catchError((_) {}));
        // The edit has succeeded; a failed refresh must not say otherwise.
        await _refreshMessagesQuietly();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Message edited for both phones.')),
          );
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Could not edit the message. Please try again.')),
          );
        }
      } finally {
        if (mounted) setState(() => saving = false);
      }
      return;
    }
    if (recipient == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Your friend must register before you can message.')),
      );
      return;
    }
    final clientMessageId = (_pendingTextDraftValue == text && _pendingTextDraftId != null)
        ? _pendingTextDraftId!
        : const Uuid().v4();
    _pendingTextDraftId = clientMessageId;
    _pendingTextDraftValue = text;
    final replyTarget = _replyingTo;
    String? replyId;
    _resolvingSend = true;
    try {
      replyId = await _resolveReplyTargetId(replyTarget);
    } catch (error) {
      _resolvingSend = false;
      if (_pendingTextDraftId == clientMessageId) {
        _pendingTextDraftId = null;
        _pendingTextDraftValue = null;
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(error is StateError ? error.message.toString() : 'The message could not be sent. Please try again.')),
        );
      }
      return;
    }
    if (!mounted) {
      _resolvingSend = false;
      return;
    }
    final replyText = replyTarget == null ? null : _summarizeMessage(replyTarget);
    final optimistic = RemoteMessage(
      id: clientMessageId,
      clientMessageId: clientMessageId,
      senderId: messaging.currentUserId,
      recipientId: recipient,
      text: text,
      createdAt: DateTime.now(),
      replyToMessageId: replyId,
    );
    if (_clearedBeforeMs != null &&
        optimistic.createdAt.millisecondsSinceEpoch <= _clearedBeforeMs!) {
      _postClearVisibleMessageIds.add(clientMessageId);
      unawaited(_saveLocalChatState());
    }
    setState(() {
      messages.add(optimistic);
      _invalidateMessageViewCache();
      if (replyText != null) _replyTargets[clientMessageId] = replyText;
      if (replyTarget != null) _replySourceMessages[clientMessageId] = replyTarget;
      _replyingTo = null;
    });
    _scrollToLatest();
    // Clearing the controller is not a user edit. Preserve the idempotency key
    // so a retry after a lost response reconciles the same server row instead
    // of creating a second message with a new client ID.
    if (messageOverride == null && controller.text.trim() == text) {
      _clearingComposerForSend = true;
      try {
        controller.clear();
      } finally {
        _clearingComposerForSend = false;
      }
    }
    _resolvingSend = false;
    if (keepKeyboardOpen) _restoreComposerKeyboard();
    String? sentId;
    try {
      final wireText = await E2eeService.instance.encryptIfReady(text);
      sentId = await messaging.sendMessage(
        recipient,
        wireText,
        clientMessageId: clientMessageId,
        replyToMessageId: replyId,
      );
    } catch (e) {
      // sendMessage already looked the row up by client id before throwing, so
      // reaching here means the server has no such message OR it could not be
      // reached. In the unreachable case the message may still have committed:
      // resync quietly so a delivered message reappears instead of vanishing.
      unawaited(_refreshMessagesQuietly());
      if (mounted) {
        setState(() {
          messages.removeWhere((m) => m.id == clientMessageId);
          _invalidateMessageViewCache();
          _replyTargets.remove(clientMessageId);
          _replySourceMessages.remove(clientMessageId);
          _messageReactions.remove(clientMessageId);
        });
        if (messageOverride != null) {
          // A sticker never came from the composer, so a failed sticker must
          // not be pushed into (or merged with) the user's draft.
          if (_pendingTextDraftId == clientMessageId) {
            _pendingTextDraftId = null;
            _pendingTextDraftValue = null;
          }
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Sticker not sent. Please try again.')),
          );
        } else {
          final currentDraft = controller.text.trim();
          if (currentDraft.isEmpty) {
            controller.text = text;
            _pendingTextDraftId = clientMessageId;
            _pendingTextDraftValue = text;
          } else if (currentDraft != text) {
            // Preserve both the failed send and anything typed while it was in flight.
            controller.text = '$text\n$currentDraft';
            _pendingTextDraftId = null;
            _pendingTextDraftValue = null;
          }
          controller.selection = TextSelection.collapsed(offset: controller.text.length);
          if (keepKeyboardOpen) _restoreComposerKeyboard();
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Message not sent. Your failed message and newer draft were kept in the composer. Review the text and retry.')));
        }
      }
      if (mounted && _replyingTo == null && replyTarget != null) {
        setState(() => _replyingTo = replyTarget);
      }
      return;
    }

    final persistedId = sentId;
    if (persistedId != null) {
      if (_postClearVisibleMessageIds.contains(clientMessageId)) {
        _postClearVisibleMessageIds.add(persistedId);
        unawaited(_saveLocalChatState());
      }
      if (_pendingTextDraftId == clientMessageId) {
        _pendingTextDraftId = null;
        _pendingTextDraftValue = null;
      }
      if (mounted && persistedId != clientMessageId) {
        setState(() {
          final optimisticIndex = messages.indexWhere((item) => item.id == clientMessageId);
          if (optimisticIndex >= 0) {
            final optimisticMessage = messages[optimisticIndex];
            messages[optimisticIndex] = RemoteMessage(
              id: persistedId,
              clientMessageId: clientMessageId,
              senderId: optimisticMessage.senderId,
              recipientId: optimisticMessage.recipientId,
              text: optimisticMessage.text,
              createdAt: optimisticMessage.createdAt,
              replyToMessageId: optimisticMessage.replyToMessageId,
            );
            _invalidateMessageViewCache();
          }
          final quote = _replyTargets.remove(clientMessageId);
          if (quote != null) _replyTargets[persistedId] = quote;
          final quoteSource = _replySourceMessages.remove(clientMessageId);
          if (quoteSource != null) _replySourceMessages[persistedId] = quoteSource;
        });
        final optimisticKey = _messageKeys.remove(clientMessageId);
        if (optimisticKey != null) _messageKeys[persistedId] = optimisticKey;
      }
    }
    if (replyText != null && sentId != null) _replyTargets[sentId] = replyText;
    try {
      await messaging.sendTyping(false);
    } catch (_) {}
    if (mounted) {
      if (keepKeyboardOpen) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (!mounted) return;
          _composerFocus.requestFocus();
          SystemChannels.textInput.invokeMethod<void>('TextInput.show');
        });
      }
    }
  }

  void _invalidateMessageViewCache() {
    _visibleMessagesMemo = null;
    _chatDisplayMessagesMemo = null;
    _chatDisplayMessagesMemoKey = null;
  }

  List<RemoteMessage> get _visibleMessages => _visibleMessagesMemo ??= messages
      .where((m) =>
          !_hiddenMessageIds.contains(m.id) &&
          !(m.clientMessageId != null && _hiddenMessageIds.contains(m.clientMessageId)) &&
          (_clearedBeforeMs == null ||
              m.createdAt.millisecondsSinceEpoch > _clearedBeforeMs! ||
              _postClearVisibleMessageIds.contains(m.id) ||
              (m.clientMessageId != null && _postClearVisibleMessageIds.contains(m.clientMessageId))))
      .toList(growable: false);

  MessageSearchFilter get _activeMessageSearchFilter => MessageSearchFilter(
        query: _messageSearchController.text,
        media: _messageMediaFilter,
        fromDate: _messageSearchDateRange?.start,
        toDate: _messageSearchDateRange?.end,
      );

  bool get _hasActiveMessageSearch => _activeMessageSearchFilter.isActive;

  List<RemoteMessage> get _chatDisplayMessages {
    final filter = _activeMessageSearchFilter;
    final key = [
      filter.query,
      filter.media.index,
      filter.fromDate?.millisecondsSinceEpoch ?? '',
      filter.toDate?.millisecondsSinceEpoch ?? '',
    ].join('|');
    if (_chatDisplayMessagesMemo != null && _chatDisplayMessagesMemoKey == key) {
      return _chatDisplayMessagesMemo!;
    }
    _chatDisplayMessagesMemoKey = key;
    _chatDisplayMessagesMemo = filter.isActive
        ? _visibleMessages.where(filter.matches).toList(growable: false)
        : _visibleMessages;
    return _chatDisplayMessagesMemo!;
  }

  Future<void> _chooseMessageSearchDates() async {
    final now = DateTime.now();
    final selected = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2000),
      lastDate: DateTime(now.year, now.month, now.day),
      initialDateRange: _messageSearchDateRange,
      helpText: 'Filter messages by date',
      saveText: 'APPLY',
    );
    if (!mounted || selected == null) return;
    setState(() => _messageSearchDateRange = selected);
  }

  void _clearMessageSearch() {
    setState(() {
      _messageSearchController.clear();
      _messageMediaFilter = MessageMediaFilter.all;
      _messageSearchDateRange = null;
      _showMessageSearch = false;
    });
  }

  Widget _buildMessageSearchPanel(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final resultCount = _chatDisplayMessages.length;
    final loadedCount = _visibleMessages.length;
    final dateRange = _messageSearchDateRange;
    final dateLabel = dateRange == null
        ? 'Any date'
        : '${MaterialLocalizations.of(context).formatCompactDate(dateRange.start)}'
            ' – ${MaterialLocalizations.of(context).formatCompactDate(dateRange.end)}';

    Widget filterChip(String label, MessageMediaFilter value) => ChoiceChip(
          label: Text(label),
          selected: _messageMediaFilter == value,
          onSelected: (_) => setState(() => _messageMediaFilter = value),
          visualDensity: VisualDensity.compact,
          labelStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
          padding: const EdgeInsets.symmetric(horizontal: 4),
        );

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 7, 12, 6),
      child: GlassPanel(
        blur: 13,
        frosted: true,
        radius: BorderRadius.circular(20),
        tint: Theme.of(context).brightness == Brightness.dark
            ? const Color(0xD9142942)
            : const Color(0xEAFBFDFF),
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 9),
        glow: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Icon(Icons.search_rounded, color: colors.primary, size: 19),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _messageSearchController,
                    autofocus: true,
                    textInputAction: TextInputAction.search,
                    onChanged: (_) {
                      _searchDebounceTimer?.cancel();
                      _searchDebounceTimer = Timer(const Duration(milliseconds: 180), () {
                        if (mounted) setState(() {});
                      });
                    },
                    decoration: InputDecoration(
                      hintText: 'Search messages or attachment names',
                      isDense: true,
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(vertical: 9),
                      hintStyle: TextStyle(color: colors.onSurface.withValues(alpha: .55)),
                    ),
                  ),
                ),
                if (_messageSearchController.text.isNotEmpty)
                  IconButton(
                    tooltip: 'Clear search text',
                    visualDensity: VisualDensity.compact,
                    onPressed: () {
                      _messageSearchController.clear();
                      setState(() {});
                    },
                    icon: const Icon(Icons.close_rounded, size: 18),
                  ),
              ],
            ),
            const Divider(height: 9),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  filterChip('All', MessageMediaFilter.all),
                  const SizedBox(width: 6),
                  filterChip('Photos', MessageMediaFilter.photos),
                  const SizedBox(width: 6),
                  filterChip('Videos', MessageMediaFilter.videos),
                  const SizedBox(width: 6),
                  filterChip('Audio', MessageMediaFilter.audio),
                  const SizedBox(width: 6),
                  filterChip('Files', MessageMediaFilter.files),
                ],
              ),
            ),
            const SizedBox(height: 5),
            Row(
              children: [
                Expanded(
                  child: TextButton.icon(
                    onPressed: _chooseMessageSearchDates,
                    icon: const Icon(Icons.calendar_month_rounded, size: 17),
                    label: Text(dateLabel, maxLines: 1, overflow: TextOverflow.ellipsis),
                    style: TextButton.styleFrom(
                      alignment: Alignment.centerLeft,
                      padding: const EdgeInsets.symmetric(horizontal: 7),
                      visualDensity: VisualDensity.compact,
                    ),
                  ),
                ),
                if (dateRange != null)
                  IconButton(
                    tooltip: 'Clear date filter',
                    visualDensity: VisualDensity.compact,
                    onPressed: () => setState(() => _messageSearchDateRange = null),
                    icon: const Icon(Icons.event_busy_rounded, size: 17),
                  ),
                Text(
                  '$resultCount / $loadedCount',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: colors.onSurface.withValues(alpha: .65),
                  ),
                ),
                const SizedBox(width: 7),
                TextButton(
                  onPressed: _clearMessageSearch,
                  style: TextButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 7),
                    visualDensity: VisualDensity.compact,
                  ),
                  child: const Text('Done'),
                ),
              ],
            ),
            Text(
              'Search covers $loadedCount loaded messages. Load older messages in the timeline to expand results.',
              style: TextStyle(
                fontSize: 12,
                height: 1.25,
                color: colors.onSurface.withValues(alpha: .58),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _startReply(RemoteMessage message) {
    final wasEditing = _editingMessageId != null;
    setState(() {
      _replyingTo = message;
      _editingMessageId = null;
      _editingOriginalText = null;
    });
    // Leaving edit mode must also remove the edited text from the composer,
    // otherwise it would be sent as a brand-new reply.
    if (wasEditing) _restoreDraftAfterEdit();
    _composerFocus.requestFocus();
  }

  void _startEdit(RemoteMessage message) {
    if (message.senderId != messaging.currentUserId) return;
    if (SharedMediaService(Supabase.instance.client).isMediaPayload(message.text)) return;
    // Keep whatever the user had typed so cancelling the edit can restore it.
    if (_editingMessageId == null) {
      final draft = controller.text;
      _draftBeforeEdit = draft.trim().isEmpty ? null : draft;
    }
    setState(() {
      _editingMessageId = message.id;
      _editingOriginalText = message.text;
      _replyingTo = null;
    });
    controller.text = message.text;
    controller.selection = TextSelection.collapsed(offset: controller.text.length);
    _composerFocus.requestFocus();
  }

  /// Replaces the edited text in the composer with the draft that was there
  /// before the edit began (or empties it).
  void _restoreDraftAfterEdit() {
    final draft = _draftBeforeEdit;
    _draftBeforeEdit = null;
    controller.text = draft ?? '';
    controller.selection = TextSelection.collapsed(offset: controller.text.length);
  }

  void _cancelComposerMode() {
    final wasEditing = _editingMessageId != null;
    setState(() {
      _editingMessageId = null;
      _editingOriginalText = null;
      _replyingTo = null;
    });
    // Cancelling a reply keeps the typed draft; only an edit's text is removed.
    if (wasEditing) {
      _restoreDraftAfterEdit();
      unawaited(messaging.sendTyping(false).catchError((_) {}));
    }
  }

  static const List<({String name, List<Color> colors})> _wallpaperPresets = [
    (name: 'Default', colors: <Color>[]),
    (name: 'Midnight Ocean', colors: <Color>[Color(0xFF071426), Color(0xFF0F294A), Color(0xFF09162B)]),
    (name: 'Rose Dusk', colors: <Color>[Color(0xFF1E0B1A), Color(0xFF3A1530), Color(0xFF140915)]),
    (name: 'Emerald Mist', colors: <Color>[Color(0xFF071C19), Color(0xFF0E3830), Color(0xFF061412)]),
    (name: 'Sunset Glow', colors: <Color>[Color(0xFF1E1024), Color(0xFF3D1A2B), Color(0xFF1A0F1F)]),
    (name: 'Pure Obsidian', colors: <Color>[Color(0xFF05070C), Color(0xFF0A0F1A)]),
    (name: 'Arctic Frost', colors: <Color>[Color(0xFFEAF3FF), Color(0xFFD6E6FB)]),
  ];

  Future<void> _saveWallpaperPrefs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_wpPresetKey, _wallpaperPreset);
      if (_wallpaperCustomPath == null || _wallpaperCustomPath!.isEmpty) {
        await prefs.remove(_wpPathKey);
      } else {
        await prefs.setString(_wpPathKey, _wallpaperCustomPath!);
      }
      await prefs.setDouble(_wpDimKey, _wallpaperDim);
    } catch (_) {}
  }

  Future<void> _pickCustomWallpaper() async {
    try {
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        maxWidth: 1600,
        maxHeight: 1600,
        imageQuality: 88,
      );
      if (picked == null) return;
      final support = await getApplicationSupportDirectory();
      final dest = File('${support.path}/likedin_chat_wallpaper_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await File(picked.path).copy(dest.path);
      final oldPath = _wallpaperCustomPath;
      if (mounted) {
        setState(() {
          _wallpaperCustomPath = dest.path;
          _wallpaperPreset = -1;
        });
      }
      await _saveWallpaperPrefs();
      if (oldPath != null && oldPath != dest.path) {
        try {
          final oldFile = File(oldPath);
          if (await oldFile.exists()) await oldFile.delete();
        } catch (_) {}
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not set custom wallpaper.')),
        );
      }
    }
  }

  Future<void> _showWallpaperPicker() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (sheetContext, setSheetState) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 6, 18, 22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Chat wallpaper',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  height: 92,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: _wallpaperPresets.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 10),
                    itemBuilder: (_, idx) {
                      final preset = _wallpaperPresets[idx];
                      final selected = _wallpaperCustomPath == null && _wallpaperPreset == idx;
                      return GestureDetector(
                        onTap: () {
                          HapticFeedback.selectionClick();
                          setState(() {
                            _wallpaperPreset = idx;
                            _wallpaperCustomPath = null;
                          });
                          setSheetState(() {});
                          unawaited(_saveWallpaperPrefs());
                        },
                        child: Column(
                          children: [
                            Container(
                              width: 64,
                              height: 64,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(18),
                                gradient: preset.colors.isEmpty
                                    ? LinearGradient(
                                        colors: [
                                          likedinBackgroundTop(Theme.of(context).brightness),
                                          likedinBackground(Theme.of(context).brightness),
                                        ],
                                      )
                                    : LinearGradient(
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                        colors: preset.colors,
                                      ),
                                border: Border.all(
                                  color: selected ? brandBlue : likedinOutline(Theme.of(context).brightness),
                                  width: selected ? 2.5 : 1,
                                ),
                              ),
                              child: selected
                                  ? Icon(Icons.check_rounded, color: brandBlue, size: 22)
                                  : null,
                            ),
                            const SizedBox(height: 6),
                            Text(
                              preset.name,
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: () async {
                      await _pickCustomWallpaper();
                      if (sheetContext.mounted) setSheetState(() {});
                    },
                    icon: const Icon(Icons.photo_library_outlined, size: 19),
                    label: Text(_wallpaperCustomPath == null
                        ? 'Choose photo from gallery'
                        : 'Change gallery photo'),
                  ),
                ),
                if (_wallpaperCustomPath != null) ...[
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      const Text('Dim background', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                      Expanded(
                        child: Slider(
                          value: _wallpaperDim.clamp(0.0, 0.75),
                          min: 0.0,
                          max: 0.75,
                          onChanged: (v) {
                            setState(() => _wallpaperDim = v);
                            setSheetState(() {});
                          },
                          onChangeEnd: (_) => unawaited(_saveWallpaperPrefs()),
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _wrapWithChatWallpaper(Widget child) {
    final customPath = _wallpaperCustomPath;
    if (customPath != null && customPath.isNotEmpty) {
      return Stack(
        fit: StackFit.expand,
        children: [
          Image.file(
            File(customPath),
            fit: BoxFit.cover,
            cacheWidth: 1080,
            errorBuilder: (_, __, ___) => const AuroraBackdrop(child: SizedBox.expand()),
          ),
          ColoredBox(color: Colors.black.withValues(alpha: _wallpaperDim.clamp(0.0, 0.75))),
          child,
        ],
      );
    }
    if (_wallpaperPreset > 0 && _wallpaperPreset < _wallpaperPresets.length) {
      final colors = _wallpaperPresets[_wallpaperPreset].colors;
      return DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: colors,
          ),
        ),
        child: child,
      );
    }
    return AuroraBackdrop(child: child);
  }

  Future<void> _showMessageActions(RemoteMessage message) async {
    HapticFeedback.mediumImpact();
    final mine = message.senderId == messaging.currentUserId;
    final isMedia = SharedMediaService(Supabase.instance.client).isMediaPayload(message.text);
    // A message still carrying its temporary client ID is not on the server
    // yet; edit/react/delete-for-everyone would fail until it is confirmed.
    final isPending = message.clientMessageId != null && message.id == message.clientMessageId;
    const quickEmojis = ['❤️', '😂', '👍', '😮', '😢', '🔥'];
    final action = await showModalBottomSheet<String>(
      context: context,
      builder: (sheetContext) => SafeArea(
        child: Wrap(
          children: [
            if (!isPending && message.deletedForEveryoneAt == null)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: likedinSurfaceRaised(Theme.of(sheetContext).brightness),
                    borderRadius: BorderRadius.circular(28),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: quickEmojis
                        .map((e) => InkWell(
                              borderRadius: BorderRadius.circular(24),
                              onTap: () {
                                HapticFeedback.selectionClick();
                                Navigator.pop(sheetContext, 'react:$e');
                              },
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                                child: Text(e, style: const TextStyle(fontSize: 26)),
                              ),
                            ))
                        .toList(),
                  ),
                ),
              ),
            if (message.deletedForEveryoneAt == null)
              ListTile(
                leading: const Icon(Icons.reply),
                title: const Text('Reply'),
                onTap: () => Navigator.pop(sheetContext, 'reply'),
              ),
            if (!isPending && message.deletedForEveryoneAt == null)
              ListTile(
                leading: Icon(_pinnedMessageId == message.id ? Icons.push_pin_rounded : Icons.push_pin_outlined),
                title: Text(_pinnedMessageId == message.id ? 'Unpin message' : 'Pin message'),
                onTap: () => Navigator.pop(sheetContext, 'pin'),
              ),
            if (!isPending && message.deletedForEveryoneAt == null)
              ListTile(
                leading: Icon(
                  _starredMessageIds.contains(message.id) ? Icons.star_rounded : Icons.star_outline_rounded,
                  color: _starredMessageIds.contains(message.id) ? const Color(0xFFF59E0B) : null,
                ),
                title: Text(_starredMessageIds.contains(message.id) ? 'Unstar message' : 'Star message'),
                onTap: () => Navigator.pop(sheetContext, 'star'),
              ),
            if (!isMedia && message.deletedForEveryoneAt == null)
              ListTile(
                leading: const Icon(Icons.copy_rounded),
                title: const Text('Copy text'),
                onTap: () => Navigator.pop(sheetContext, 'copy'),
              ),
            if (mine && !isPending && !isMedia && message.deletedForEveryoneAt == null)
              ListTile(
                leading: const Icon(Icons.edit_outlined),
                title: const Text('Edit'),
                onTap: () => Navigator.pop(sheetContext, 'edit'),
              ),
            if (!isPending && message.deletedForEveryoneAt == null)
              ListTile(
                leading: const Icon(Icons.add_reaction_outlined),
                title: const Text('React'),
                onTap: () => Navigator.pop(sheetContext, 'react'),
              ),
            ListTile(
              leading: const Icon(Icons.delete_outline),
              title: const Text('Delete for me'),
              onTap: () => Navigator.pop(sheetContext, 'delete_me'),
            ),
            if (mine && !isPending && message.deletedForEveryoneAt == null)
              ListTile(
                leading: const Icon(Icons.delete_forever_outlined),
                title: const Text('Delete for everyone'),
                onTap: () => Navigator.pop(sheetContext, 'delete_everyone'),
              ),
          ],
        ),
      ),
    );
    if (!mounted || action == null) return;
    if (action.startsWith('react:')) {
      await _toggleReaction(message.id, action.substring(6));
      return;
    }
    switch (action) {
      case 'reply':
        _startReply(message);
        break;
      case 'pin':
        final nextPin = _pinnedMessageId == message.id ? null : message.id;
        setState(() => _pinnedMessageId = nextPin);
        await _saveLocalChatState();
        _broadcastActivity({'pinnedMessageId': nextPin ?? ''});
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(nextPin == null ? 'Message unpinned.' : 'Message pinned to top of chat.')),
          );
        }
        break;
      case 'star':
        final wasStarred = _starredMessageIds.contains(message.id);
        setState(() {
          if (wasStarred) {
            _starredMessageIds.remove(message.id);
          } else {
            _starredMessageIds.add(message.id);
          }
        });
        await _saveLocalChatState();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(wasStarred ? 'Removed from starred messages.' : 'Message starred.')),
          );
        }
        break;
      case 'copy':
        await Clipboard.setData(ClipboardData(text: message.text));
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Message copied to clipboard.')),
          );
        }
        break;
      case 'edit':
        _startEdit(message);
        break;
      case 'react':
        _showReactionPicker(message);
        break;
      case 'delete_me':
        setState(() {
          // A just-sent message still carries its temporary ID. Hide the stable
          // client ID too, so it stays hidden once the real ID arrives.
          _hiddenMessageIds.add(message.id);
          final clientId = message.clientMessageId;
          if (clientId != null && clientId.isNotEmpty) _hiddenMessageIds.add(clientId);
          _invalidateMessageViewCache();
        });
        await _saveLocalChatState();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Message deleted from this device.')),
          );
        }
        break;
      case 'delete_everyone':
        final confirmed = await showDialog<bool>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: const Text('Delete for everyone?'),
            content: const Text(
              'Both phones will show a deleted-message placeholder. This action cannot be undone.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, false),
                child: const Text('Cancel'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, true),
                child: const Text('Delete for everyone'),
              ),
            ],
          ),
        );
        if (confirmed != true || !mounted) break;
        try {
          await messaging.deleteMessageForEveryone(message.id);
          // The deletion has succeeded. Local follow-up work is best effort and
          // must not turn into a "Could not delete" message.
          try {
            // Fetch the tombstone by ID so deletion also updates an older page
            // that is not part of the newest-100 conversation refresh.
            final tombstone = await messaging.getMessageById(message.id);
            if (tombstone != null) {
              final index = messages.indexWhere((item) => item.id == tombstone.id);
              if (index >= 0 && mounted) {
                setState(() {
                  messages[index] = tombstone;
                  _invalidateMessageViewCache();
                });
              }
              await _purgeDeletedMediaCaches([tombstone]);
            } else {
              final metadata = SharedMediaService(Supabase.instance.client).decode(message.text);
              final path = metadata?['path']?.toString();
              if (path != null && path.isNotEmpty) {
                final media = SharedMediaService(Supabase.instance.client);
                await media.deleteCachedPath(path);
                await media.deleteRemotePath(path);
              }
            }
          } catch (error) {
            debugPrint('Post-delete local cleanup deferred: $error');
          }
          await _refreshMessagesQuietly();
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Message deleted for everyone.')),
            );
          }
        } catch (e) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Could not delete the message. Please try again.')),
            );
          }
        }
        break;
    }
  }

  Future<void> _showStarredMessagesSheet() async {
    final starred = _visibleMessages
        .where((m) => _starredMessageIds.contains(m.id) && m.deletedForEveryoneAt == null)
        .toList()
        .reversed
        .toList();
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) => SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(sheetContext).height * .68),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 6, 18, 18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(
                        color: const Color(0xFFF59E0B).withValues(alpha: .16),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(Icons.star_rounded, color: Color(0xFFF59E0B), size: 19),
                    ),
                    const SizedBox(width: 10),
                    const Expanded(
                      child: Text('Starred messages', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                    ),
                    Text('${starred.length}', style: TextStyle(color: Theme.of(sheetContext).hintColor, fontWeight: FontWeight.w700)),
                  ],
                ),
                const SizedBox(height: 12),
                if (starred.isEmpty)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 28),
                    child: Center(
                      child: Text(
                        'Long-press any message and tap Star to save your favorite moments here.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Theme.of(sheetContext).hintColor, fontSize: 13),
                      ),
                    ),
                  )
                else
                  Flexible(
                    child: ListView.separated(
                      shrinkWrap: true,
                      itemCount: starred.length,
                      separatorBuilder: (_, __) => Divider(height: 1, color: likedinOutline(Theme.of(sheetContext).brightness)),
                      itemBuilder: (_, idx) {
                        final msg = starred[idx];
                        final mine = msg.senderId == messaging.currentUserId;
                        return ListTile(
                          contentPadding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                          title: Text(
                            _summarizeMessage(msg),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                          ),
                          subtitle: Text(
                            '${mine ? 'You' : headerName} · ${_dayBannerLabel(msg.createdAt)} · ${_time(msg.createdAt)}',
                            style: const TextStyle(fontSize: 12),
                          ),
                          trailing: const Icon(Icons.chevron_right_rounded, size: 19),
                          onTap: () {
                            Navigator.pop(sheetContext);
                            unawaited(_jumpToMessage(msg.id));
                          },
                        );
                      },
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _pickAndSendViewOncePhoto() async {
    if (uploading) return;
    final recipient = peerId;
    if (recipient == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Your friend must register before sharing photos.')),
      );
      return;
    }
    try {
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        imageQuality: 90,
        maxWidth: 1920,
        maxHeight: 1920,
      );
      if (picked == null || !mounted) return;
      final source = File(picked.path);
      String caption = '';
      final choice = await showDialog<String>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => AlertDialog(
          title: const Row(
            children: [
              Icon(Icons.looks_one_outlined, size: 22),
              SizedBox(width: 8),
              Text('Send view-once photo?'),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Image.file(source, fit: BoxFit.contain, height: 280, width: double.infinity, cacheWidth: 1200),
                ),
                const SizedBox(height: 10),
                TextField(
                  textCapitalization: TextCapitalization.sentences,
                  maxLines: 3,
                  minLines: 1,
                  onChanged: (v) => caption = v,
                  decoration: const InputDecoration(
                    hintText: 'Add a caption (optional)…',
                    isDense: true,
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext, 'cancel'), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(dialogContext, 'send'), child: const Text('Send 1×')),
          ],
        ),
      );
      if (choice != 'send' || !mounted) return;
      await _sendCapturedPhotoFile(picked, recipient, caption: caption, viewOnce: true);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not pick a view-once photo. Please try again.')),
        );
      }
    }
  }

  Widget _buildPinnedBanner(BuildContext context) {
    final pinId = _pinnedMessageId;
    if (pinId == null || pinId.isEmpty) return const SizedBox.shrink();
    RemoteMessage? pinned;
    for (final m in _visibleMessages) {
      if (m.id == pinId) {
        pinned = m;
        break;
      }
    }
    if (pinned == null || pinned.deletedForEveryoneAt != null) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 6, 12, 0),
      child: GlassPanel(
        blur: 12,
        frosted: true,
        glow: false,
        radius: BorderRadius.circular(16),
        padding: const EdgeInsets.fromLTRB(12, 7, 4, 7),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () => unawaited(_jumpToMessage(pinId)),
          child: Row(
            children: [
              Container(
                width: 3,
                height: 30,
                decoration: BoxDecoration(
                  color: brandBlue,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              const SizedBox(width: 10),
              Icon(Icons.push_pin_rounded, color: brandBlue, size: 17),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'Pinned message',
                      style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: brandBlue),
                    ),
                    Text(
                      _summarizeMessage(pinned),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: 'Unpin message',
                visualDensity: VisualDensity.compact,
                icon: const Icon(Icons.close_rounded, size: 18),
                onPressed: () {
                  setState(() => _pinnedMessageId = null);
                  unawaited(_saveLocalChatState());
                  _broadcastActivity(const {'pinnedMessageId': ''});
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _showReactionPicker(RemoteMessage message) async {
    const emojis = ['❤️', '😂', '👍', '😮', '😢', '🔥'];
    final picked = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Wrap(
            alignment: WrapAlignment.spaceEvenly,
            children: emojis
                .map((e) => InkWell(
                      onTap: () => Navigator.pop(ctx, e),
                      child: Padding(
                        padding: const EdgeInsets.all(10),
                        child: Text(e, style: const TextStyle(fontSize: 30)),
                      ),
                    ))
                .toList(),
          ),
        ),
      ),
    );
    if (picked != null && mounted) {
      await _toggleReaction(message.id, picked);
    }
  }

  Future<void> _toggleReaction(String messageId, String emoji) async {
    final me = messaging.currentUserId;
    final usersForMessage = _messageReactionUsers[messageId];
    final currentlyActive = usersForMessage?[emoji]?.contains(me) ?? false;
    // Show the change immediately; the refresh below reconciles with the server.
    if (mounted) {
      setState(() {
        final users = _messageReactionUsers.putIfAbsent(messageId, () => <String, Set<String>>{});
        final set = users.putIfAbsent(emoji, () => <String>{});
        if (currentlyActive) {
          set.remove(me);
          if (set.isEmpty) users.remove(emoji);
        } else {
          set.add(me);
        }
        if (users.isEmpty) {
          _messageReactionUsers.remove(messageId);
          _messageReactions.remove(messageId);
        } else {
          _messageReactions[messageId] = users.keys.toSet();
        }
        _invalidateMessageViewCache();
      });
    }
    try {
      await messaging.setReaction(messageId, emoji, active: !currentlyActive);
      // Realtime refreshes this one message's reactions. A tiny targeted
      // fallback covers delayed/disconnected Realtime without reloading chat.
      await _refreshSingleMessageReaction(messageId);
    } catch (e) {
      await _refreshSingleMessageReaction(messageId);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not update the reaction. Please try again.')),
        );
      }
    }
  }

  Future<void> _clearChatForMe() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Clear chat?'),
        content: const Text(
          'This clears the conversation only on this device. The other person’s chat is not affected.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Clear chat')),
        ],
      ),
    );
    if (confirm == true && mounted) {
      try {
        int cutoffMs;
        try {
          final serverNow = await Supabase.instance.client.rpc('likedin_server_now');
          final serverDate = DateTime.tryParse(serverNow.toString());
          cutoffMs = serverDate?.millisecondsSinceEpoch ?? DateTime.now().toUtc().millisecondsSinceEpoch;
        } catch (_) {
          cutoffMs = DateTime.now().toUtc().millisecondsSinceEpoch;
        }
        setState(() {
          _clearedBeforeMs = cutoffMs;
          _postClearVisibleMessageIds.clear();
          _invalidateMessageViewCache();
        });
        await _saveLocalChatState();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Chat cleared on this device. New messages will still appear.')),
          );
        }
      } catch (error) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Could not clear this chat. Please try again.')),
          );
        }
      }
    }
  }

  void _beginNicknameEdit() {
    nicknameController.text = nickname ?? '';
    setState(() => editingNickname = true);
  }

  void _cancelNicknameEdit() {
    nicknameController.clear();
    if (mounted) setState(() => editingNickname = false);
  }

  Future<void> _saveNickname() async {
    final peer = peerId;
    if (peer == null) return;
    final clean = nicknameController.text.trim();
    try {
      final prefs = await SharedPreferences.getInstance();
      if (clean.isEmpty) {
        await prefs.remove('likedIn_nickname_$peer');
      } else {
        await prefs.setString('likedIn_nickname_$peer', clean);
      }
      if (!mounted) return;
      setState(() {
        nickname = clean.isEmpty ? null : clean;
        editingNickname = false;
      });
      nicknameController.clear();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not save the nickname. Please try again.')),
        );
      }
    }
  }

  Future<void> _startVoiceRecording() async {
    if (saving || _recordingVoice || _startingVoiceRecording) return;
    if (peerId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Your friend must register before you can send a voice message.')),
      );
      return;
    }
    _startingVoiceRecording = true;
    _voiceReleaseRequested = false;
    try {
      var micPermission = await Permission.microphone.status;
      if (!micPermission.isGranted) micPermission = await Permission.microphone.request();
      if (!micPermission.isGranted) {
        if (micPermission.isPermanentlyDenied || micPermission.isRestricted) {
          await _showPermissionSettingsPrompt('Microphone');
        } else if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Microphone permission is required to record a voice message.')),
          );
        }
        return;
      }
      if (!await _voiceRecorder.hasPermission()) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Microphone access is unavailable. Check app permissions in Settings.')),
          );
        }
        return;
      }
      final dir = await getTemporaryDirectory();
      final path = '${dir.path}/likedin_voice_${DateTime.now().microsecondsSinceEpoch}.m4a';
      await _voiceRecorder.start(
        const RecordConfig(encoder: AudioEncoder.aacLc, bitRate: 96000, sampleRate: 44100),
        path: path,
      );
      if (_voiceReleaseRequested || !mounted) {
        final stoppedPath = await _voiceRecorder.stop();
        if (stoppedPath != null) {
          final f = File(stoppedPath);
          if (await f.exists()) await f.delete();
        }
        return;
      }
      _voiceRecordSecondsNotifier.value = 0;
      setState(() {
        _recordingVoice = true;
        _voiceRecordStarted = DateTime.now();
      });
      _broadcastActivity(const {'recording': true});
      _voiceTimer?.cancel();
      _voiceTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (!mounted || _voiceRecordStarted == null) return;
        final elapsed = DateTime.now().difference(_voiceRecordStarted!).inSeconds;
        _voiceRecordSecondsNotifier.value = elapsed;
        if (elapsed % 2 == 0) _broadcastActivity(const {'recording': true});
        if (elapsed >= _maxVoiceSeconds && _recordingVoice) {
          // Hard cap so a forgotten recording cannot grow without bound.
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Reached the ${_maxVoiceSeconds ~/ 60}-minute limit. Sending your voice message.')),
          );
          unawaited(_stopAndSendVoice());
        }
      });
      HapticFeedback.mediumImpact();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not start recording. Check microphone access and try again.')),
        );
      }
    } finally {
      _startingVoiceRecording = false;
    }
  }

  Future<void> _stopAndSendVoice({bool discard = false}) async {
    String? pathForCleanup;
    if (_startingVoiceRecording && !_recordingVoice) {
      _voiceReleaseRequested = true;
      return;
    }
    // Single flight: two overlapping stop calls would race on the recorder and
    // one of them could delete the file the other is about to send.
    if (!_recordingVoice || _stoppingVoice) return;
    _stoppingVoice = true;
    _voiceTimer?.cancel();
    _voiceTimer = null;
    _broadcastActivity(const {'recording': false});
    try {
      String? path;
      try {
        path = await _voiceRecorder.stop();
      } catch (error) {
        // If the recorder cannot be stopped, still leave the recording UI so
        // the mic does not stay red with a frozen timer.
        debugPrint('Voice recorder stop failed: $error');
        try { await _voiceRecorder.cancel(); } catch (_) {}
        _voiceRecordSecondsNotifier.value = 0;
        if (mounted) {
          setState(() {
            _recordingVoice = false;
            _voiceRecordStarted = null;
          });
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('The recording could not be saved. Please try again.')),
          );
        }
        return;
      }
      pathForCleanup = path;
      _voiceRecordSecondsNotifier.value = 0;
      if (mounted) {
        setState(() {
          _recordingVoice = false;
          _voiceRecordStarted = null;
          uploading = true;
        });
      }
      if (path == null || discard) return;
      final file = File(path);
      if (!await file.exists() || await file.length() < 1200) {
        if (await file.exists()) await file.delete();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Recording was too short. Record a little longer, then tap the microphone (or release it) to send.')),
          );
        }
        return;
      }
      final recipient = peerId;
      if (recipient == null) return;
      final media = SharedMediaService(Supabase.instance.client);
      // Copy into the account-bound persistent media outbox before removing the
      // recorder temp file. A stable outbox ID is also the message idempotency key.
      // A reply target that is still sending must never cost the user a
      // finished recording: wait briefly, then send without the reply link.
      final replyId = await _resolveReplyTargetIdOrNull(_replyingTo);
      if (!mounted) return;
      await media.enqueue(
        file,
        recipient,
        originalName: 'Voice message.m4a',
        replyToMessageId: replyId,
      );
      if (mounted && _replyingTo != null) setState(() => _replyingTo = null);
      final completed = await SharedMediaService.processRetryQueue(Supabase.instance.client);
      if (completed) await _refreshMessagesQuietly();
      if (mounted) {
        final quarantined = SharedMediaService.lastQuarantinedCount > 0;
        final detail = SharedMediaService.lastQueueError;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(completed
                ? 'Voice message sent.'
                : quarantined
                    ? 'Voice message was not sent: ${detail ?? 'the file cannot be uploaded'}. It was kept in the local quarantine and removed from automatic retries.'
                    : 'Voice message saved for retry when the connection is available.'),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Voice message could not be sent. Please try again.')),
        );
      }
    } finally {
      _stoppingVoice = false;
      _voiceGesture.reset();
      try {
        if (pathForCleanup != null) {
          final recording = File(pathForCleanup);
          if (await recording.exists()) await recording.delete();
        }
      } catch (error) {
        debugPrint('Voice temp-file cleanup deferred: $error');
      }
      if (mounted) {
        setState(() {
          uploading = false;
          if (_recordingVoice && _voiceTimer == null) {
            _recordingVoice = false;
            _voiceRecordStarted = null;
            _voiceRecordSecondsNotifier.value = 0;
          }
        });
      }
    }
  }

  Future<void> _showAttachmentPicker() async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Theme.of(context).colorScheme.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (sheetContext) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const SizedBox(height: 10),
        ListTile(leading: Icon(Icons.photo_camera_outlined, color: brandBlue), title: const Text('Camera'), subtitle: const Text('Take a photo and send it'), onTap: () => Navigator.pop(sheetContext, 'camera')),
        ListTile(leading: Icon(Icons.photo_library_outlined, color: brandBlue), title: const Text('Gallery'), subtitle: const Text('Photos, videos and GIFs'), onTap: () => Navigator.pop(sheetContext, 'gallery')),
        ListTile(leading: Icon(Icons.looks_one_outlined, color: brandBlue), title: const Text('View-once photo'), subtitle: const Text('Photo vanishes after being opened once'), onTap: () => Navigator.pop(sheetContext, 'view_once')),
        ListTile(leading: Icon(Icons.audiotrack_rounded, color: brandBlue), title: const Text('Audio'), subtitle: const Text('Share music and audio files'), onTap: () => Navigator.pop(sheetContext, 'audio')),
        ListTile(leading: const Icon(Icons.folder_open_rounded), title: const Text('Browse files'), subtitle: const Text('Documents and other files'), onTap: () => Navigator.pop(sheetContext, 'files')),
        ListTile(leading: Icon(Icons.gif_box_outlined, color: brandBlue), title: const Text('Choose a GIF'), subtitle: const Text('Pick an animated GIF file'), onTap: () => Navigator.pop(sheetContext, 'gif')),
        const SizedBox(height: 8),
      ])),
    );
    if (!mounted || choice == null) return;
    if (choice == 'camera') await _captureAndSendPhoto();
    if (choice == 'gallery') await _openInAppGallery();
    if (choice == 'view_once') await _pickAndSendViewOncePhoto();
    if (choice == 'audio') await attach(audioOnly: true);
    if (choice == 'files') await attach();
    if (choice == 'gif') await attach(gifsOnly: true);
  }

  Future<void> _showStickerPicker() async {
    const stickers = <String>[
      '😂', '🥹', '😍', '😘', '🤗', '🥳', '😎', '🤌',
      '❤️', '💖', '💗', '💯', '🔥', '✨', '🌸', '🫶',
      '😭', '🙄', '😴', '🤔', '😤', '🤝', '👏', '🫡',
      '🐼', '🐻', '🐸', '🦋', '🌈', '☀️', '🎉', '💐',
    ];
    final selected = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Theme.of(context).colorScheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(width: 38, height: 4, decoration: BoxDecoration(
                color: Theme.of(context).dividerColor,
                borderRadius: BorderRadius.circular(4),
              )),
              const SizedBox(height: 16),
              Row(children: [
                const Expanded(child: Text('Stickers', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
                Text('Tap to send', style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor)),
              ]),
              const SizedBox(height: 14),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: stickers.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 4, mainAxisSpacing: 8, crossAxisSpacing: 8,
                ),
                itemBuilder: (_, index) => Material(
                  color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: .55),
                  borderRadius: BorderRadius.circular(16),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () => Navigator.pop(sheetContext, stickers[index]),
                    child: Center(child: Text(stickers[index], style: const TextStyle(fontSize: 34))),
                  ),
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
    if (selected == null || !mounted) return;
    if (_editingMessageId != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Finish editing the current message before sending a sticker.')),
      );
      return;
    }
    await send(messageOverride: selected);
  }

  Future<void> _openInAppGallery() async {
    if (uploading) return;
    final selected = await InAppGalleryPicker.show(context, maxSelection: 10);
    if (!mounted || selected == null || selected.isEmpty) return;
    final canViewOnce = selected.length == 1 && selected.first.typeInt == 1;
    String caption = '';
    bool viewOnce = false;
    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: Text(
            selected.length == 1
                ? 'Send 1 item?'
                : 'Send ${selected.length} items?',
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (canViewOnce) ...[
                  FilterChip(
                    selected: viewOnce,
                    avatar: const Icon(Icons.looks_one_outlined, size: 17),
                    label: const Text('View once (1×)'),
                    onSelected: (v) => setDialogState(() => viewOnce = v),
                  ),
                  const SizedBox(height: 10),
                ],
                TextField(
                  textCapitalization: TextCapitalization.sentences,
                  maxLines: 3,
                  minLines: 1,
                  onChanged: (v) => caption = v,
                  decoration: const InputDecoration(
                    hintText: 'Add a caption (optional)…',
                    isDense: true,
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: Text(viewOnce ? 'Send 1×' : 'Send'),
            ),
          ],
        ),
      ),
    );
    if (confirmed != true || !mounted) return;
    await _sendGalleryAssets(
      selected,
      caption: caption,
      viewOnce: viewOnce && canViewOnce,
    );
  }

  Future<void> _sendGalleryAssets(
    List<AssetEntity> assets, {
    String? caption,
    bool viewOnce = false,
  }) async {
    final recipient = peerId;
    if (recipient == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Your friend must register before sharing media.')),
      );
      return;
    }
    if (uploading) return;
    setState(() => uploading = true);
    var queued = 0;
    final failures = <String>[];
    try {
      final media = SharedMediaService(Supabase.instance.client);
      final replyId = await _resolveReplyTargetIdOrNull(_replyingTo);
      for (var index = 0; index < assets.length; index++) {
        final asset = assets[index];
        try {
          final original = await asset.file;
          if (original == null || !await original.exists()) {
            throw StateError('This item is no longer available on the device.');
          }
          if (!mounted) return;
          final baseName = asset.title?.trim().isNotEmpty == true
              ? asset.title!.trim()
              : p.basename(original.path);
          final displayName = viewOnce && assets.length == 1
              ? 'LikedinOnce_${DateTime.now().millisecondsSinceEpoch}.jpg'
              : baseName;
          final sourceMime = await SharedMediaService.detectMimeType(
            original,
            displayName: displayName,
          );
          final isAnimatedGif = sourceMime == 'image/gif';
          final prepared = await media.prepare(original, mimeType: sourceMime);
          try {
            await media.enqueue(
              prepared,
              recipient,
              originalName: displayName,
              replyToMessageId: replyId,
              animated: isAnimatedGif,
            );
            queued++;
          } finally {
            if (prepared.path != original.path && await prepared.exists()) {
              try { await prepared.delete(); } catch (_) {}
            }
          }
        } catch (error) {
          failures.add('${asset.title ?? 'media'}: $error');
        }
      }
      if (replyId != null && queued > 0 && mounted) {
        setState(() => _replyingTo = null);
      }
      if (queued > 0) {
        if (!mounted) return;
        setState(() => uploading = false);
        final summary = '$queued item${queued == 1 ? '' : 's'} queued. Sending in the background…';
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(failures.isEmpty ? summary : '$summary ${failures.length} item(s) could not be queued.')),
        );
        _processQueuedMediaAfterFastSend();
        final cleanCaption = caption?.trim();
        if (cleanCaption != null && cleanCaption.isNotEmpty) {
          unawaited(send(messageOverride: cleanCaption));
        }
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(failures.isEmpty ? 'No media was selected.' : 'Some media could not be queued. Please try again.')),
        );
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Some selected media could not be sent. Please try again.')),
        );
      }
    } finally {
      if (mounted) setState(() => uploading = false);
    }
  }

  void _handleKeyboardContent(KeyboardInsertedContent content) {
    // Android keyboards such as Gboard use the image-keyboard commitContent API.
    // Keep this handler fire-and-forget because TextField's callback is void.
    unawaited(_sendKeyboardContent(content));
  }

  Future<void> _sendKeyboardContent(KeyboardInsertedContent content) async {
    final recipient = peerId;
    if (recipient == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Your friend must register before sharing media.')),
        );
      }
      return;
    }
    if (uploading) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please wait for the current upload to finish.')),
        );
      }
      return;
    }

    final keepKeyboardOpen = _composerFocus.hasFocus;
    final mime = content.mimeType.toLowerCase().trim();
    const supported = <String>{
      'image/gif', 'image/png', 'image/jpeg', 'image/jpg', 'image/webp',
      'image/bmp', 'image/tiff',
    };
    if (!supported.contains(mime)) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gboard inserted an unsupported media type: $mime')),
        );
      }
      return;
    }

    // Keep the raw keyboard payload bounded. GIFs are further optimized to
    // animated WebP and limited to 2 MB before they enter the durable outbox.
    const keyboardMediaLimit = 8 * 1024 * 1024;
    final bytes = content.data;
    if (bytes != null && bytes.length > keyboardMediaLimit) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('That keyboard GIF/image is over 8 MB. Choose a smaller one.')),
        );
      }
      return;
    }

    final extension = switch (mime) {
      'image/gif' => 'gif',
      'image/png' => 'png',
      'image/webp' => 'webp',
      'image/bmp' => 'bmp',
      'image/tiff' => 'tiff',
      _ => 'jpg',
    };
    final fileName = 'Gboard_${DateTime.now().microsecondsSinceEpoch}.$extension';
    File? tempFile;
    File? preparedFile;
    if (!mounted) return;
    setState(() => uploading = true);
    try {
      late final File uploadFile;
      if (bytes != null && bytes.isNotEmpty) {
        final temp = await getTemporaryDirectory();
        uploadFile = File(p.join(temp.path, 'likedin_$fileName'));
        tempFile = uploadFile;
        await uploadFile.writeAsBytes(bytes, flush: true);
      } else {
        final uri = content.uri.trim();
        if (!uri.startsWith('content://')) {
          throw StateError('The keyboard did not provide readable image data.');
        }
        final copiedPath = await _keyboardMediaChannel.invokeMethod<String>(
          'copyContentUriToCache',
          <String, Object>{
            'uri': uri,
            'mimeType': mime,
            'maxBytes': keyboardMediaLimit,
          },
        );
        if (copiedPath == null || copiedPath.isEmpty) {
          throw StateError('The keyboard media could not be read. Try the in-app Gallery.');
        }
        uploadFile = File(copiedPath);
        tempFile = uploadFile;
      }

      final actualSize = await uploadFile.length();
      if (actualSize <= 0 || actualSize > keyboardMediaLimit) {
        throw StateError('Keyboard media must be smaller than 8 MB before optimization.');
      }
      final replyId = await _resolveReplyTargetIdOrNull(_replyingTo);
      final media = SharedMediaService(Supabase.instance.client);
      preparedFile = await media.prepare(uploadFile, mimeType: mime);
      await media.enqueue(
        preparedFile,
        recipient,
        originalName: fileName,
        replyToMessageId: replyId,
        animated: mime == 'image/gif',
      );
      if (!mounted) return;
      setState(() {
        if (replyId != null) _replyingTo = null;
        uploading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(mime == 'image/gif'
            ? 'GIF optimized and queued. Sending in the background…'
            : 'Media queued. Sending in the background…')),
      );
      if (keepKeyboardOpen) _restoreComposerKeyboard();
      _processQueuedMediaAfterFastSend();
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not send this keyboard media. Please try again.')),
        );
      }
    } finally {
      if (preparedFile != null && tempFile != null && preparedFile.path != tempFile.path) {
        try { if (await preparedFile.exists()) await preparedFile.delete(); } catch (_) {}
      }
      if (tempFile != null) {
        try { if (await tempFile.exists()) await tempFile.delete(); } catch (_) {}
      }
      if (mounted && uploading) setState(() => uploading = false);
      if (keepKeyboardOpen && mounted) _restoreComposerKeyboard();
    }
  }

  void _restoreComposerKeyboard() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _composerFocus.requestFocus();
      SystemChannels.textInput.invokeMethod<void>('TextInput.show');
    });
  }

  void _processQueuedMediaAfterFastSend() {
    unawaited(() async {
      try {
        final completed = await SharedMediaService.processRetryQueue(Supabase.instance.client);
        if (!mounted) return;
        try { await _loadMessages(); } catch (_) {}
        if (!mounted) return;
        if (completed) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Media sent.')),
          );
        } else {
          final quarantined = SharedMediaService.lastQuarantinedCount > 0;
          final detail = SharedMediaService.lastQueueError;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(quarantined
                ? 'Media could not be sent: ${detail ?? 'the file was rejected'}.'
                : 'Media is saved locally and will retry when the connection is available.')),
          );
        }
      } catch (error) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Media is safely queued. Sending will retry automatically.')),
        );
      }
    }());
  }

  Future<void> attach({bool gifsOnly = false, bool audioOnly = false}) async {
    if (uploading) return;
    final recipient = peerId;
    if (recipient == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Your friend must register before sharing files.')),
      );
      return;
    }
    setState(() => uploading = true);
    var queued = 0;
    final failures = <String>[];
    try {
      final picked = await FilePicker.platform.pickFiles(
        allowMultiple: true,
        withData: false,
        withReadStream: true,
        type: audioOnly
            ? FileType.audio
            : gifsOnly
                ? FileType.custom
                : FileType.any,
        allowedExtensions: gifsOnly ? const ['gif'] : null,
      );
      if (picked == null || picked.files.isEmpty) return;
      final media = SharedMediaService(Supabase.instance.client);
      final replyId = await _resolveReplyTargetIdOrNull(_replyingTo);
      if (!mounted) return;
      for (final item in picked.files) {
        File? stagedFile;
        File? original;
        File? prepared;
        try {
          final path = item.path;
          if (path != null && path.isNotEmpty && !path.startsWith('content://')) {
            final candidate = File(path);
            if (await candidate.exists()) original = candidate;
          }
          // Some Android providers expose a content URI or no path at all.
          // Use the stream returned by FilePicker instead of failing the whole
          // multi-file selection.
          if (original == null) {
            final stream = item.readStream;
            if (stream == null) {
              throw StateError('Android could not read ${item.name}. Try selecting it from Gallery or Downloads.');
            }
            stagedFile = await SharedMediaService.copyStreamToTemporaryFile(
              stream,
              item.name,
              maxSizeBytes: SharedMediaService.maxBytes,
            );
            original = stagedFile;
          }
          if (!mounted) return;
          final sourceMime = await SharedMediaService.detectMimeType(
            original,
            displayName: item.name,
          );
          final audioContainerExtension = const {
            '.mp4', '.3gp', '.3g2', '.webm', '.mkv',
          }.contains(p.extension(item.name).toLowerCase());
          if (audioOnly && !sourceMime.startsWith('audio/') && !audioContainerExtension) {
            throw FormatException('${item.name} is not recognized as an audio file.');
          }
          final isAnimatedGif = sourceMime == 'image/gif';
          prepared = audioOnly ? original : await media.prepare(original, mimeType: sourceMime);
          await media.enqueue(
            prepared,
            recipient,
            originalName: item.name,
            replyToMessageId: replyId,
            animated: isAnimatedGif,
            kindOverride: audioOnly ? 'audio' : null,
          );
          queued++;
        } catch (error) {
          failures.add('${item.name}: $error');
        } finally {
          if (prepared != null && original != null && prepared.path != original.path) {
            try { if (await prepared.exists()) await prepared.delete(); } catch (_) {}
          }
          if (stagedFile != null) {
            try { if (await stagedFile.exists()) await stagedFile.delete(); } catch (_) {}
          }
        }
      }
      if (replyId != null && queued > 0 && mounted) setState(() => _replyingTo = null);
      if (mounted && queued > 0) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(failures.isEmpty
              ? '$queued attachment${queued == 1 ? '' : 's'} queued. Sending…'
              : '$queued attachment${queued == 1 ? '' : 's'} queued; ${failures.length} could not be queued.')),
        );
        _processQueuedMediaAfterFastSend();
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(failures.isEmpty
              ? 'No files were selected.'
              : 'No attachments were queued. Check the selected files and try again.')),
        );
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Attachments could not be opened. Please try again.')),
        );
      }
    } finally {
      if (mounted) setState(() => uploading = false);
    }
  }

  bool _isEmojiOnlyText(String text) {
    final runes = text.runes.toList(growable: false);
    if (runes.isEmpty || runes.length > 24 || runes.contains(0xFE0E)) return false;
    final variationSelector = runes.contains(0xFE0F);
    var hasEmojiBase = false;
    for (final rune in runes) {
      final core = (rune >= 0x1F300 && rune <= 0x1FAFF) ||
          (rune >= 0x1F1E6 && rune <= 0x1F1FF) ||
          (rune >= 0x1F170 && rune <= 0x1F251);
      final variation = variationSelector && rune >= 0x2600 && rune <= 0x27BF;
      final modifier = rune == 0xFE0F || rune == 0x200D || rune == 0x20E3 ||
          (rune >= 0x1F3FB && rune <= 0x1F3FF);
      if (core || variation) { hasEmojiBase = true; continue; }
      if (modifier) continue;
      return false;
    }
    return hasEmojiBase;
  }

  Future<void> _previewLegacyAttachment(Map<String, dynamic> payload, String name) async {
    final messenger = ScaffoldMessenger.of(context);
    File? preparedFile;
    try {
      final media = SharedMediaService(Supabase.instance.client);
      final source = await media.cachedFile(payload);
      final rawMime = await SharedMediaService.detectRawMimeType(source, displayName: name);
      if (!mounted) return;
      if (rawMime == null || (!rawMime.startsWith('image/') && !rawMime.startsWith('video/'))) {
        messenger.showSnackBar(
          const SnackBar(content: Text('This attachment is not a supported photo or video.')),
        );
        return;
      }

      // Older releases sometimes stored extensionless photos/GIFs as generic
      // files. Convert legacy BMP/TIFF images for display, but keep normal
      // images and GIF animations untouched.
      final displayFile = (rawMime == 'image/bmp' || rawMime == 'image/tiff')
          ? await media.prepare(source, mimeType: rawMime)
          : source;
      if (displayFile.path != source.path) preparedFile = displayFile;
      if (!mounted) return;
      if (rawMime.startsWith('image/')) {
        await Navigator.of(context).push<void>(MaterialPageRoute<void>(
          builder: (_) => _LikedinImageViewer(file: displayFile, title: name),
        ));
      } else {
        await Navigator.of(context).push<void>(MaterialPageRoute<void>(
          builder: (_) => _LikedinVideoViewer(file: displayFile, title: name),
        ));
      }
    } catch (error) {
      debugPrint('Legacy attachment preview failed: $error');
      if (mounted) {
        messenger.showSnackBar(
          const SnackBar(content: Text('Could not preview this attachment. Try saving it to Downloads.')),
        );
      }
    } finally {
      final temporary = preparedFile;
      if (temporary != null) {
        try { if (await temporary.exists()) await temporary.delete(); } catch (_) {}
      }
    }
  }

  Widget _messageContent(RemoteMessage message) {
    if (message.deletedForEveryoneAt != null) {
      return Text(
        'This message was deleted',
        style: TextStyle(fontSize: 15, fontStyle: FontStyle.italic, color: Theme.of(context).hintColor),
      );
    }
    final payload = _decodeMediaPayloadCached(message.text);
    if (payload == null) {
      final isSticker = _isEmojiOnlyText(message.text.trim());
      if (isSticker) {
        return Text(
          message.text,
          textAlign: TextAlign.center,
          softWrap: true,
          style: const TextStyle(fontSize: 42, height: 1.15),
        );
      }
      final firstUrl = _extractFirstUrl(message.text);
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          _RichMessageText(
            text: message.text,
            style: const TextStyle(fontSize: 15, height: 1.35),
            linkColor: likedinPrimary(Theme.of(context).brightness),
          ),
          if (firstUrl != null) _LinkPreviewCard(url: firstUrl),
        ],
      );
    }
    final storedName = payload['name']?.toString() ?? 'Attachment';
    final name = payload['animated'] == true ? 'GIF' : storedName;
    final kind = payload['kind']?.toString() ?? 'file';
    final mime = payload['mime']?.toString().toLowerCase() ?? '';
    final extension = p.extension(storedName).toLowerCase();
    final looksLikeImage = payload['animated'] == true || mime.startsWith('image/') ||
        const {'.jpg', '.jpeg', '.png', '.gif', '.webp'}.contains(extension);
    // Explicit semantic metadata wins over generic container MIME/extension:
    // MP4, 3GP, WebM and MKV can all carry audio-only tracks.
    final explicitlyAudio = kind == 'audio' || mime.startsWith('audio/');
    final looksLikeVideo = !explicitlyAudio && (mime.startsWith('video/') ||
        const {'.mp4', '.mov', '.webm', '.3gp', '.mkv'}.contains(extension));
    final renderPayload = Map<String, dynamic>.from(payload);
    if (kind != 'image' && looksLikeImage) renderPayload['kind'] = 'image';
    if (mime.startsWith('audio/')) renderPayload['kind'] = 'audio';
    if (kind != 'video' && looksLikeVideo && !looksLikeImage && !explicitlyAudio) {
      renderPayload['kind'] = 'video';
    }
    final renderKind = renderPayload['kind']?.toString() ?? 'file';
    final size = (payload['size'] as num?)?.toInt() ?? 0;
    final sizeLabel = size >= 1048576
        ? '${(size / 1048576).toStringAsFixed(1)} MB'
        : '${(size / 1024).toStringAsFixed(0)} KB';
    if (renderKind == 'image' && storedName.startsWith('LikedinOnce_')) {
      final opened = _openedViewOnceIds.contains(message.id);
      final mine = message.senderId == messaging.currentUserId;
      return _ViewOncePhotoTile(
        opened: opened,
        outgoing: mine,
        onOpen: opened
            ? null
            : () async {
                final messenger = ScaffoldMessenger.of(context);
                try {
                  final media = SharedMediaService(Supabase.instance.client);
                  final file = await media.cachedFile(renderPayload);
                  if (!mounted) return;
                  await Navigator.of(context).push<void>(
                    MaterialPageRoute<void>(
                      builder: (_) => _LikedinImageViewer(
                        file: file,
                        title: 'Photo',
                        viewOnce: true,
                      ),
                    ),
                  );
                  if (!mounted) return;
                  setState(() => _openedViewOnceIds.add(message.id));
                  unawaited(_saveLocalChatState());
                  final path = renderPayload['path']?.toString();
                  if (path != null && path.isNotEmpty) {
                    unawaited(media.deleteCachedPath(path).catchError((_) {}));
                  }
                } catch (_) {
                  if (mounted) {
                    messenger.showSnackBar(
                      const SnackBar(content: Text('Could not open this view-once photo.')),
                    );
                  }
                }
              },
      );
    }
    if (renderKind == 'image' || renderKind == 'video') {
      return _ChatMediaMessage(
        key: ValueKey('media-${message.id}-${payload['path']}'),
        payload: renderPayload,
        name: name,
        sizeLabel: sizeLabel,
      );
    }
    if (renderKind == 'audio') {
      return _VoiceMessagePlayer(
        key: ValueKey('audio-${message.id}-${payload['path']}'),
        payload: payload,
      );
    }
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(Icons.insert_drive_file_outlined, size: 28),
        const SizedBox(width: 10),
        Flexible(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                name,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
              Text(sizeLabel, style: TextStyle(fontSize: 12, color: likedinMutedText(Theme.of(context).brightness))),
            ],
          ),
        ),
        IconButton(
          tooltip: 'Preview photo or video',
          icon: const Icon(Icons.visibility_outlined, size: 20),
          visualDensity: VisualDensity.compact,
          onPressed: () => _previewLegacyAttachment(payload, storedName),
        ),
        IconButton(
          tooltip: 'Save to Downloads',
          onPressed: () async {
            try {
              final saved = await SharedMediaService(Supabase.instance.client)
                  .downloadToPublicDownloads(payload);
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Saved $saved to Downloads.')),
                );
              }
            } catch (e) {
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Download failed. Check your connection and storage, then try again.')),
                );
              }
            }
          },
          icon: const Icon(Icons.download_rounded),
        ),
      ],
    );
  }

  Map<String, dynamic>? _standardImagePayload(RemoteMessage msg) {
    if (msg.deletedForEveryoneAt != null) return null;
    if (msg.replyToMessageId != null) return null;
    final payload = _decodeMediaPayloadCached(msg.text);
    if (payload == null) return null;
    final storedName = payload['name']?.toString() ?? '';
    if (storedName.startsWith('LikedinOnce_')) return null;
    final kind = payload['kind']?.toString() ?? '';
    final mime = payload['mime']?.toString().toLowerCase() ?? '';
    final ext = p.extension(storedName).toLowerCase();
    final isImg = kind == 'image' ||
        mime.startsWith('image/') ||
        const {'.jpg', '.jpeg', '.png', '.webp'}.contains(ext);
    if (!isImg || payload['animated'] == true || mime == 'image/gif' || ext == '.gif') {
      return null;
    }
    return payload;
  }

  List<List<RemoteMessage>> _groupTimelineEntries(List<RemoteMessage> source) {
    final result = <List<RemoteMessage>>[];
    var i = 0;
    while (i < source.length) {
      final current = source[i];
      if (_standardImagePayload(current) != null) {
        final group = <RemoteMessage>[current];
        var j = i + 1;
        while (j < source.length && group.length < 10) {
          final next = source[j];
          if (_standardImagePayload(next) != null &&
              next.senderId == current.senderId &&
              _isSameCalendarDay(current.createdAt, next.createdAt) &&
              next.createdAt.difference(group.last.createdAt).inMinutes.abs() <= 3) {
            group.add(next);
            j++;
          } else {
            break;
          }
        }
        result.add(group);
        i = j;
      } else {
        result.add(<RemoteMessage>[current]);
        i++;
      }
    }
    return result;
  }

  String _time(DateTime value) {
    final local = value.toLocal();
    return MaterialLocalizations.of(context).formatTimeOfDay(TimeOfDay.fromDateTime(local));
  }

  bool _isSameCalendarDay(DateTime a, DateTime b) {
    final la = a.toLocal();
    final lb = b.toLocal();
    return la.year == lb.year && la.month == lb.month && la.day == lb.day;
  }

  String _dayBannerLabel(DateTime value) {
    final local = value.toLocal();
    final now = DateTime.now();
    if (_isSameCalendarDay(local, now)) return 'Today';
    if (_isSameCalendarDay(local, DateTime(now.year, now.month, now.day - 1))) return 'Yesterday';
    return MaterialLocalizations.of(context).formatMediumDate(local);
  }

  String _presenceText() {
    if (peerRecording) return 'Recording audio…';
    if (peerTyping) return 'Typing…';
    if (peerOnline) return 'Online';
    if (lastSeen == null) return 'Last seen unavailable';
    final delta = DateTime.now().difference(lastSeen!);
    if (delta.inMinutes < 1) return 'Last seen just now';
    if (delta.inHours < 1) return 'Last seen ${delta.inMinutes}m ago';
    if (delta.inDays < 1) return 'Last seen ${delta.inHours}h ago';
    return 'Last seen ${delta.inDays}d ago';
  }

  Widget _receipt(RemoteMessage message) {
    if (message.readAt != null) {
      return const Icon(Icons.done_all, size: 15, color: Color(0xFF1685E8));
    }
    if (message.deliveredAt != null) return const Icon(Icons.done_all, size: 15);
    final pending = message.clientMessageId != null && message.id == message.clientMessageId;
    if (pending) return const Icon(Icons.schedule, size: 14);
    return const Icon(Icons.check, size: 15);
  }

  @override
  Widget build(BuildContext context) {
    // Materialize this filtered message view once per build. The old getter
    // allocated a new list each time itemBuilder accessed it, multiplying the
    // work across every visible row on low-end phones.
    final chatDisplayMessages = _chatDisplayMessages;
    final timelineEntries = _groupTimelineEntries(chatDisplayMessages);
    final animateOnThisBuild = <String>{};
    for (final message in chatDisplayMessages) {
      final stableKey = message.clientMessageId ?? message.id;
      if (!_animatedMessageIds.contains(stableKey)) animateOnThisBuild.add(stableKey);
    }
    if (animateOnThisBuild.isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _animatedMessageIds.addAll(animateOnThisBuild);
      });
    }
    final hasActiveMessageSearch = _hasActiveMessageSearch;
    final queuedMediaCountLabel = _queuedMediaCount == 1
        ? '1 attachment is waiting to upload'
        : '$_queuedMediaCount attachments are waiting to upload';
    final queuedMediaNamesLabel = _queuedMediaNames.join(', ');
    final queuedMediaStatusText =
        '$queuedMediaCountLabel${queuedMediaNamesLabel.isEmpty ? '' : ': $queuedMediaNamesLabel'}. Likedin retries while open and when your connection returns.';
    final quarantinedMediaCountLabel = _quarantinedMediaCount == 1
        ? '1 attachment could not be sent'
        : '$_quarantinedMediaCount attachments could not be sent';
    final quarantinedMediaDetail = _quarantinedMediaItems.isEmpty
        ? ''
        : ': ${_quarantinedMediaItems.first['name']} — ${_quarantinedMediaItems.first['reason']}';
    final quarantinedMediaStatusText =
        '$quarantinedMediaCountLabel$quarantinedMediaDetail Open Storage to review them.';
    return _wrapWithChatWallpaper(
        Column(
          children: [
          GlassPanel(
            blur: 14,
            frosted: true,
            glow: false,
            radius: const BorderRadius.vertical(bottom: Radius.circular(20)),
            tint: Theme.of(context).brightness == Brightness.dark
                ? const Color(0xE0101E31)
                : const Color(0xDDFBFDFF),
            padding: const EdgeInsets.fromLTRB(4, 6, 8, 6),
            child: Row(
              children: [
                IconButton(
                  tooltip: 'Back to home',
                  onPressed: widget.onBack,
                  icon: const Icon(Icons.arrow_back_rounded),
                ),
                Tooltip(
                  message: peerAvatarUrl == null ? 'Profile photo unavailable' : 'View profile photo',
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: peerAvatarUrl == null ? null : _openPeerProfilePhoto,
                    child: RepaintBoundary(
                      child: CircleAvatar(
                        backgroundColor: brandBlue.withValues(alpha: .14),
                        child: peerAvatarUrl == null
                            ? Icon(Icons.person, color: brandBlue)
                            : Hero(
                                tag: 'likedin-chat-avatar-${peerAvatarPath ?? ''}',
                                child: ClipOval(
                                  child: Image.network(
                                    peerAvatarUrl!,
                                  width: 40,
                                  height: 40,
                                  cacheWidth: 120,
                                  fit: BoxFit.cover,
                                  filterQuality: FilterQuality.low,
                                  gaplessPlayback: true,
                                    errorBuilder: (_, __, ___) => Icon(Icons.person, color: brandBlue),
                                  ),
                                ),
                              ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: editingNickname
                      ? TextField(
                          controller: nicknameController,
                          autofocus: true,
                          maxLength: 30,
                          decoration: const InputDecoration(
                            hintText: 'Nickname for this person',
                            counterText: '',
                            isDense: true,
                          ),
                          onSubmitted: (_) => _saveNickname(),
                        )
                      : GestureDetector(
                          onTap: _openChatInfo,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Flexible(
                                    child: Text(
                                      headerName,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17, letterSpacing: -.2),
                                    ),
                                  ),
                                  ValueListenableBuilder<bool>(
                                    valueListenable: E2eeService.instance.activeNotifier,
                                    builder: (_, active, __) => active
                                        ? const Padding(
                                            padding: EdgeInsets.only(left: 5),
                                            child: Tooltip(
                                              message: 'End-to-end encrypted',
                                              child: Icon(
                                                Icons.lock_rounded,
                                                size: 14,
                                                color: Color(0xFF2FBF86),
                                              ),
                                            ),
                                          )
                                        : const SizedBox.shrink(),
                                  ),
                                ],
                              ),
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  if (peerRecording) ...[
                                    const Icon(Icons.mic_rounded, size: 13, color: Color(0xFFE5484D)),
                                    const SizedBox(width: 4),
                                  ] else if (peerOnline) ...[
                                    Container(
                                      width: 7,
                                      height: 7,
                                      decoration: const BoxDecoration(
                                        color: Color(0xFF2FBF86),
                                        shape: BoxShape.circle,
                                      ),
                                    ),
                                    const SizedBox(width: 5),
                                  ],
                                  Flexible(
                                    child: Text(
                                      _presenceText(),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: (peerOnline || peerTyping || peerRecording) ? FontWeight.w600 : FontWeight.w400,
                                        color: peerRecording
                                            ? const Color(0xFFE5484D)
                                            : peerTyping
                                                ? brandBlue
                                                : peerOnline
                                                    ? const Color(0xFF2FBF86)
                                                    : likedinMutedText(Theme.of(context).brightness),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                ),
                if (editingNickname) ...[
                  IconButton(
                    tooltip: 'Cancel nickname',
                    onPressed: _cancelNicknameEdit,
                    icon: const Icon(Icons.close, size: 19),
                  ),
                  IconButton(
                    tooltip: 'Save nickname',
                    onPressed: _saveNickname,
                    icon: Icon(Icons.check, color: brandBlue, size: 20),
                  ),
                ],
                if (!editingNickname) ...[
                  IconButton(
                    tooltip: 'Audio call',
                  onPressed: peerId == null
                      ? null
                      : () => _showCallSetup(context, video: false, recipientId: peerId),
                  icon: Icon(Icons.call_outlined, color: brandBlue),
                ),
                  IconButton(
                    tooltip: 'Video call',
                    onPressed: peerId == null
                        ? null
                        : () => _showCallSetup(context, video: true, recipientId: peerId),
                    icon: Icon(Icons.videocam_outlined, color: brandBlue),
                  ),
                  PopupMenuButton<String>(
                    tooltip: 'Chat options',
                    onSelected: (v) {
                      if (v == 'search') {
                        if (_showMessageSearch) {
                          _clearMessageSearch();
                        } else {
                          setState(() => _showMessageSearch = true);
                        }
                      }
                      if (v == 'starred') unawaited(_showStarredMessagesSheet());
                      if (v == 'wallpaper') unawaited(_showWallpaperPicker());
                      if (v == 'nickname') _beginNicknameEdit();
                      if (v == 'clear') _clearChatForMe();
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'search', child: Text('Search messages')),
                      PopupMenuItem(value: 'starred', child: Text('Starred messages')),
                      PopupMenuItem(value: 'wallpaper', child: Text('Chat wallpaper')),
                      PopupMenuItem(value: 'nickname', child: Text('Change nickname')),
                      PopupMenuItem(value: 'clear', child: Text('Clear chat on this device')),
                    ],
                  ),
                ],
              ],
            ),
          ),
          _buildPinnedBanner(context),
          if (_showMessageSearch) _buildMessageSearchPanel(context),
          if (_chatIncomingCall != null)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surfaceContainerHigh,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
              ),
              child: Row(
                children: [
                  Icon(
                    _chatIncomingCall!['call_type']?.toString().toLowerCase() == 'video'
                        ? Icons.videocam
                        : Icons.call,
                    color: brandBlue,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${_chatIncomingCall!['call_type']?.toString().toLowerCase() == 'video' ? 'Video' : 'Audio'} call incoming',
                          style: TextStyle(fontWeight: FontWeight.w700, color: Theme.of(context).colorScheme.onSurface),
                        ),
                        Text(
                          'Your friend is waiting for you to join.',
                          style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant),
                        ),
                      ],
                    ),
                  ),
                  TextButton(
                    onPressed: _joiningChatCall ? null : _declineChatIncomingCall,
                    child: const Text('Decline', style: TextStyle(color: Color(0xFFB42318))),
                  ),
                  const SizedBox(width: 6),
                  FilledButton(
                    onPressed: _joiningChatCall ? null : _joinChatIncomingCall,
                    child: _joiningChatCall
                        ? SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Theme.of(context).colorScheme.onPrimary),
                          )
                        : const Text('Join call'),
                  ),
                ],
              ),
            ),
          Expanded(
            child: Stack(
              children: [
                Positioned.fill(
                  child: loadError != null
                      ? Center(
                          child: Padding(
                            padding: const EdgeInsets.all(20),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Text('Could not connect to messaging. Check your connection and try again.', textAlign: TextAlign.center),
                                const SizedBox(height: 12),
                                FilledButton.tonalIcon(
                                  onPressed: messagesLoading ? null : () => _loadMessages().catchError((_) {}),
                                  icon: const Icon(Icons.refresh_rounded), label: const Text('Retry'),
                                ),
                              ],
                            ),
                          ),
                        )
                      : messagesLoading
                          ? const Center(child: CircularProgressIndicator())
                          : peerId == null
                              ? Center(
                                  child: Padding(
                                    padding: const EdgeInsets.all(28),
                                    child: Text(
                                      _peerLookupFailed
                                          ? 'Could not reach messaging to look up your friend. Retrying automatically…'
                                          : 'Waiting for your friend to register.',
                                      textAlign: TextAlign.center,
                                    ),
                                  ),
                                )
                              : NotificationListener<ScrollNotification>(
                                  onNotification: (notification) {
                                    if (notification is ScrollUpdateNotification &&
                                        chatDisplayMessages.isNotEmpty) {
                                      final pos = notification.metrics;
                                      final ratio = pos.maxScrollExtent <= 0
                                          ? 0.0
                                          : (pos.pixels / pos.maxScrollExtent).clamp(0.0, 1.0);
                                      final approxIndex = ((1.0 - ratio) * (chatDisplayMessages.length - 1))
                                          .round()
                                          .clamp(0, chatDisplayMessages.length - 1);
                                      final label = _dayBannerLabel(chatDisplayMessages[approxIndex].createdAt);
                                      if (_floatingDateNotifier.value != label) {
                                        _floatingDateNotifier.value = label;
                                      }
                                      _floatingDateTimer?.cancel();
                                      _floatingDateTimer = Timer(const Duration(milliseconds: 1100), () {
                                        if (mounted) _floatingDateNotifier.value = null;
                                      });
                                    }
                                    return false;
                                  },
                                  child: ListView.builder(
                                  controller: _chatScrollController,
                                  reverse: true,
                                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 18),
                                  itemCount: timelineEntries.length +
                                      ((_hasOlderMessages || _loadingOlderMessages) ? 1 : 0) +
                                      ((peerTyping || peerRecording) && !hasActiveMessageSearch ? 1 : 0) +
                                      (timelineEntries.isEmpty &&
                                              (!(peerTyping || peerRecording) || hasActiveMessageSearch)
                                          ? 1
                                          : 0),
                                  itemBuilder: (context, i) {
                                    final hasOlderHeader = _hasOlderMessages || _loadingOlderMessages;
                                    final hasTypingFooter = (peerTyping || peerRecording) && !hasActiveMessageSearch;
                                    final hasEmptyPlaceholder = chatDisplayMessages.isEmpty && !hasTypingFooter;
                                    var cursorIndex = i;
                                    if (hasTypingFooter) {
                                      if (cursorIndex == 0) return _TypingBubble(recording: peerRecording);
                                      cursorIndex--;
                                    } else if (hasEmptyPlaceholder) {
                                      if (cursorIndex == 0) {
                                        if (hasActiveMessageSearch) {
                                          return Padding(
                                            padding: const EdgeInsets.all(28),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Icon(Icons.search_off_rounded, size: 34,
                                                    color: Theme.of(context).hintColor),
                                                const SizedBox(height: 9),
                                                const Text('No messages match these filters.',
                                                    textAlign: TextAlign.center,
                                                    style: TextStyle(fontWeight: FontWeight.w700)),
                                                const SizedBox(height: 4),
                                                Text('Try another phrase, media type or date range.',
                                                    textAlign: TextAlign.center,
                                                    style: TextStyle(color: Theme.of(context).hintColor,
                                                        fontSize: 12)),
                                              ],
                                            ),
                                          );
                                        }
                                        return Padding(
                                          padding: const EdgeInsets.fromLTRB(28, 56, 28, 28),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Container(
                                                width: 64,
                                                height: 64,
                                                decoration: BoxDecoration(
                                                  color: brandBlue.withValues(alpha: .10),
                                                  shape: BoxShape.circle,
                                                ),
                                                child: Icon(
                                                   Icons.chat_bubble_outline_rounded,
                                                  size: 28,
                                                  color: brandBlue,
                                                ),
                                              ),
                                              const SizedBox(height: 14),
                                              Text(
                                                'No messages with $headerName yet',
                                                textAlign: TextAlign.center,
                                                style: const TextStyle(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.w700,
                                                ),
                                              ),
                                              const SizedBox(height: 6),
                                              Text(
                                                'Type below to say hello. Hold the mic button to record a voice message.',
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                  fontSize: 13,
                                                  height: 1.35,
                                                  color: Theme.of(context).hintColor,
                                                ),
                                              ),
                                            ],
                                          ),
                                        );
                                      }
                                      cursorIndex--;
                                    }
                                    if (hasOlderHeader && cursorIndex == timelineEntries.length) {
                                      return Center(
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(vertical: 10),
                                          child: _loadingOlderMessages
                                              ? const SizedBox(
                                                  width: 18,
                                                  height: 18,
                                                  child: CircularProgressIndicator(strokeWidth: 2),
                                                )
                                              : TextButton.icon(
                                                  onPressed: _loadOlderMessages,
                                                  icon: const Icon(Icons.history_rounded, size: 17),
                                                  label: const Text('Load older messages'),
                                                ),
                                        ),
                                      );
                                    }
                                    final entryIndex = timelineEntries.length - 1 - cursorIndex;
                                    final entryGroup = timelineEntries[entryIndex];
                                    final isPhotoAlbum = entryGroup.length >= 2;
                                    final message = entryGroup.last;
                                    final prevEntry = entryIndex > 0 ? timelineEntries[entryIndex - 1] : null;
                                    final nextEntry = entryIndex + 1 < timelineEntries.length
                                        ? timelineEntries[entryIndex + 1]
                                        : null;
                                    final showDayHeader = prevEntry == null ||
                                        !_isSameCalendarDay(
                                          prevEntry.last.createdAt,
                                          entryGroup.first.createdAt,
                                        );
                                    final outgoing = message.senderId == messaging.currentUserId;
                                    final prevMsg = prevEntry?.last;
                                    final nextMsg = nextEntry?.first;
                                    final sameAsPrev = prevMsg != null &&
                                        !showDayHeader &&
                                        prevMsg.senderId == message.senderId &&
                                        message.createdAt.difference(prevMsg.createdAt).inMinutes.abs() <= 3;
                                    final sameAsNext = nextMsg != null &&
                                        _isSameCalendarDay(message.createdAt, nextMsg.createdAt) &&
                                        nextMsg.senderId == message.senderId &&
                                        nextMsg.createdAt.difference(message.createdAt).inMinutes.abs() <= 3;
                                    final canQuickHeart = message.deletedForEveryoneAt == null &&
                                        !(message.clientMessageId != null && message.id == message.clientMessageId);
                                    final quoted = _replyTargets[message.id] ??
                                        (message.clientMessageId == null
                                            ? null
                                            : _replyTargets[message.clientMessageId!]);
                                    final replySource = _replySourceMessages[message.id] ??
                                        (message.clientMessageId == null
                                            ? null
                                            : _replySourceMessages[message.clientMessageId!]);
                                    final messageKey = _messageKeys.putIfAbsent(message.id, GlobalKey.new);
                                    final reactions = _messageReactions[message.id] ?? <String>{};
                                    final reactionUsers =
                                        _messageReactionUsers[message.id] ?? const <String, Set<String>>{};
                                    final stableKey = message.clientMessageId ?? message.id;
                                    final shouldAnimate = animateOnThisBuild.contains(stableKey);
                                    final bubbleWidget = Align(
                                      alignment: outgoing
                                          ? Alignment.centerRight
                                          : Alignment.centerLeft,
                                      child: Container(
                                        margin: EdgeInsets.only(
                                          top: sameAsPrev ? 1.5 : 7,
                                          bottom: sameAsNext ? 1.5 : 4,
                                        ),
                                        padding: const EdgeInsets.fromLTRB(14, 10, 14, 8),
                                        constraints: const BoxConstraints(maxWidth: 310),
                                        decoration: BoxDecoration(
                                          color: outgoing
                                              ? likedinOutgoingBubble(Theme.of(context).brightness)
                                              : likedinSurface(Theme.of(context).brightness),
                                          border: outgoing
                                              ? Border.all(
                                                  color: likedinPrimary(Theme.of(context).brightness)
                                                      .withValues(alpha: .40),
                                                )
                                              : Border.all(color: likedinOutline(Theme.of(context).brightness)),
                                          borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(!outgoing && sameAsPrev ? 7 : 20),
                                            topRight: Radius.circular(outgoing && sameAsPrev ? 7 : 20),
                                            bottomLeft: Radius.circular(!outgoing ? (sameAsNext ? 7 : 5) : 20),
                                            bottomRight: Radius.circular(outgoing ? (sameAsNext ? 7 : 5) : 20),
                                          ),
                                        ),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.end,
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            if (quoted != null)
                                              GestureDetector(
                                                onTap: message.replyToMessageId == null
                                                    ? null
                                                    : () => _jumpToMessage(message.replyToMessageId!),
                                                child: Container(
                                                  width: double.infinity,
                                                  margin: const EdgeInsets.only(bottom: 8),
                                                  padding: const EdgeInsets.fromLTRB(9, 7, 9, 7),
                                                  decoration: BoxDecoration(
                                                    color: Theme.of(context).brightness ==
                                                            Brightness.dark
                                                        ? const Color(0xFF172B3B)
                                                        : const Color(0xFFF0F5FB),
                                                    borderRadius: BorderRadius.circular(10),
                                                    border: Border(
                                                      left: BorderSide(
                                                        color: outgoing
                                                            ? const Color(0xFF55A7F5)
                                                            : brandBlue,
                                                        width: 3,
                                                      ),
                                                    ),
                                                  ),
                                                  child: Column(
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    mainAxisSize: MainAxisSize.min,
                                                    children: [
                                                      Text(
                                                        'Replying to',
                                                        style: TextStyle(
                                                          fontSize: 12,
                                                          fontWeight: FontWeight.w700,
                                                          color: Theme.of(context).brightness ==
                                                                  Brightness.dark
                                                              ? const Color(0xFF80BDF5)
                                                              : brandBlue,
                                                        ),
                                                      ),
                                                      const SizedBox(height: 4),
                                                      _ReplyQuotePreview(
                                                        original: replySource,
                                                        fallbackText: quoted,
                                                        compact: true,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            if (message.deletedForEveryoneAt == null &&
                                                _decodeMediaPayloadCached(message.text) == null &&
                                                !_isEmojiOnlyText(message.text.trim()) &&
                                                reactions.isEmpty &&
                                                _extractFirstUrl(message.text) == null)
                                              Wrap(
                                                alignment: WrapAlignment.end,
                                                crossAxisAlignment: WrapCrossAlignment.end,
                                                spacing: 8,
                                                runSpacing: 2,
                                                children: [
                                                  _RichMessageText(
                                                    text: message.text,
                                                    style: const TextStyle(fontSize: 15, height: 1.35),
                                                    linkColor: likedinPrimary(Theme.of(context).brightness),
                                                  ),
                                                  Row(
                                                    mainAxisSize: MainAxisSize.min,
                                                    children: [
                                                      if (_starredMessageIds.contains(message.id))
                                                        const Padding(
                                                          padding: EdgeInsets.only(right: 4),
                                                          child: Icon(Icons.star_rounded, size: 12, color: Color(0xFFF59E0B)),
                                                        ),
                                                      if (message.editedAt != null)
                                                        Padding(
                                                          padding: const EdgeInsets.only(right: 4),
                                                          child: Text(
                                                            'Edited',
                                                            style: TextStyle(
                                                              fontSize: 11,
                                                              fontStyle: FontStyle.italic,
                                                              color: likedinMutedText(Theme.of(context).brightness),
                                                            ),
                                                          ),
                                                        ),
                                                      Text(
                                                        _time(message.createdAt),
                                                        style: TextStyle(
                                                          fontSize: 11,
                                                          color: likedinMutedText(Theme.of(context).brightness),
                                                        ),
                                                      ),
                                                      if (outgoing) ...[
                                                        const SizedBox(width: 3),
                                                        _receipt(message),
                                                      ],
                                                    ],
                                                  ),
                                                ],
                                              )
                                            else ...[
                                              if (isPhotoAlbum)
                                                _PhotoAlbumGrid(
                                                  items: entryGroup
                                                      .map((m) => (
                                                            payload: _standardImagePayload(m)!,
                                                            name: _standardImagePayload(m)!['name']?.toString() ?? 'Photo',
                                                          ))
                                                      .toList(growable: false),
                                                )
                                              else
                                                _messageContent(message),
                                              if (message.deletedForEveryoneAt == null &&
                                                  message.editedAt != null)
                                                Padding(
                                                  padding: const EdgeInsets.only(top: 2),
                                                  child: Text(
                                                    'Edited',
                                                    style: TextStyle(
                                                      fontSize: 11,
                                                      fontStyle: FontStyle.italic,
                                                      color: likedinMutedText(Theme.of(context).brightness),
                                                    ),
                                                  ),
                                                ),
                                              if (reactions.isNotEmpty)
                                                Padding(
                                                  padding: const EdgeInsets.only(top: 5),
                                                  child: Wrap(
                                                    spacing: 5,
                                                    runSpacing: 4,
                                                    children: reactions.map((emoji) {
                                                      final users = reactionUsers[emoji] ?? const <String>{};
                                                      final count = users.isEmpty ? 1 : users.length;
                                                      final mineReacted = users.contains(messaging.currentUserId);
                                                      return TweenAnimationBuilder<double>(
                                                        key: ValueKey('rx-${message.id}-$emoji-$count'),
                                                        tween: Tween<double>(begin: 0.78, end: 1.0),
                                                        duration: LikedinAppearance.reduceMotion.value
                                                            ? Duration.zero
                                                            : const Duration(milliseconds: 180),
                                                        curve: Curves.easeOutBack,
                                                        builder: (context, scale, child) => Transform.scale(
                                                          scale: scale,
                                                          child: child,
                                                        ),
                                                        child: GestureDetector(
                                                          onTap: () => _toggleReaction(message.id, emoji),
                                                          child: Container(
                                                            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                                                            decoration: BoxDecoration(
                                                              color: mineReacted
                                                                  ? brandBlue.withValues(alpha: .16)
                                                                  : Theme.of(context).colorScheme.surface.withValues(alpha: .75),
                                                              borderRadius: BorderRadius.circular(12),
                                                              border: Border.all(
                                                                color: mineReacted
                                                                    ? brandBlue
                                                                    : Theme.of(context).dividerColor,
                                                              ),
                                                            ),
                                                            child: Text(
                                                              count > 1 ? '$emoji $count' : emoji,
                                                              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                                                            ),
                                                          ),
                                                        ),
                                                      );
                                                    }).toList(),
                                                  ),
                                                ),
                                              const SizedBox(height: 4),
                                              Row(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  if (_starredMessageIds.contains(message.id))
                                                    const Padding(
                                                      padding: EdgeInsets.only(right: 4),
                                                      child: Icon(Icons.star_rounded, size: 12, color: Color(0xFFF59E0B)),
                                                    ),
                                                  Text(
                                                    _time(message.createdAt),
                                                    style: TextStyle(
                                                      fontSize: 11,
                                                      color: likedinMutedText(Theme.of(context).brightness),
                                                    ),
                                                  ),
                                                  if (outgoing) ...[
                                                    const SizedBox(width: 3),
                                                    _receipt(message),
                                                  ],
                                                ],
                                              ),
                                            ],
                                          ],
                                        ),
                                      ),
                                    );
                                    return RepaintBoundary(
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          if (showDayHeader)
                                            Padding(
                                              padding: const EdgeInsets.symmetric(vertical: 8),
                                              child: Container(
                                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                                                decoration: BoxDecoration(
                                                  color: Theme.of(context).brightness == Brightness.dark
                                                      ? const Color(0xFF1E2D3B)
                                                      : const Color(0xFFE8EEF5),
                                                  borderRadius: BorderRadius.circular(14),
                                                ),
                                                child: Text(
                                                  _dayBannerLabel(message.createdAt),
                                                  style: TextStyle(
                                                    fontSize: 12,
                                                    fontWeight: FontWeight.w700,
                                                    color: Theme.of(context).hintColor,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          _SwipeReplyGesture(
                                            key: messageKey,
                                            onReply: message.deletedForEveryoneAt == null
                                                ? () {
                                                    HapticFeedback.selectionClick();
                                                    _startReply(message);
                                                  }
                                                : null,
                                            child: GestureDetector(
                                              onDoubleTap: canQuickHeart
                                                  ? () {
                                                      HapticFeedback.lightImpact();
                                                      unawaited(_toggleReaction(message.id, '❤️'));
                                                    }
                                                  : null,
                                              onLongPress: () => _showMessageActions(message),
                                              child: shouldAnimate
                                                  ? TweenAnimationBuilder<double>(
                                                      key: ValueKey('message-$stableKey'),
                                                      tween: Tween<double>(begin: 0, end: 1),
                                                      duration: LikedinAppearance.reduceMotion.value
                                                          ? Duration.zero
                                                          : const Duration(milliseconds: 240),
                                                      curve: Curves.easeOutCubic,
                                                      builder: (context, value, child) => Opacity(
                                                        opacity: value,
                                                        child: Transform.translate(
                                                          offset: Offset(0, 12 * (1 - value)),
                                                          child: Transform.scale(
                                                            scale: 0.94 + 0.06 * value,
                                                            alignment: outgoing
                                                                ? Alignment.bottomRight
                                                                : Alignment.bottomLeft,
                                                            child: child,
                                                          ),
                                                        ),
                                                      ),
                                                      child: bubbleWidget,
                                                    )
                                                  : bubbleWidget,
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                ),
                                ),
                ),
                Positioned(
                  top: 10,
                  left: 0,
                  right: 0,
                  child: IgnorePointer(
                    child: Center(
                      child: ValueListenableBuilder<String?>(
                        valueListenable: _floatingDateNotifier,
                        builder: (context, label, _) {
                          final visible = label != null;
                          return AnimatedOpacity(
                            opacity: visible ? 1.0 : 0.0,
                            duration: LikedinAppearance.reduceMotion.value
                                ? Duration.zero
                                : const Duration(milliseconds: 180),
                            child: GlassPanel(
                              radius: BorderRadius.circular(18),
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                              child: Text(
                                label ?? '',
                                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
                Positioned(
                  right: 18,
                  bottom: 14,
                  child: ValueListenableBuilder<bool>(
                    valueListenable: _showScrollToBottomNotifier,
                    builder: (context, showButton, _) {
                      final visible = showButton && messages.isNotEmpty;
                      final dur = LikedinAppearance.reduceMotion.value
                          ? Duration.zero
                          : const Duration(milliseconds: 170);
                      return IgnorePointer(
                        ignoring: !visible,
                        child: AnimatedScale(
                          scale: visible ? 1.0 : 0.72,
                          duration: dur,
                          curve: Curves.easeOutBack,
                          child: AnimatedOpacity(
                            opacity: visible ? 1.0 : 0.0,
                            duration: dur,
                            child: Material(
                              elevation: 4,
                              color: Theme.of(context).colorScheme.surface,
                              shape: const CircleBorder(),
                              child: IconButton(
                                tooltip: 'Jump to latest message',
                                onPressed: () => _scrollToLatest(),
                                icon: Icon(
                                  Icons.keyboard_arrow_down_rounded,
                                  color: brandBlue,
                                  size: 30,
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
          if (_jumpToReplyInProgress)
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 6, 14, 0),
              child: Row(children: [
                const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 1.8)),
                const SizedBox(width: 8),
                const Expanded(child: Text('Finding the original message…', style: TextStyle(fontSize: 12))),
                TextButton(
                  onPressed: () => setState(() => _cancelJumpToReplyRequested = true),
                  child: const Text('Cancel'),
                ),
              ]),
            ),
          if (_queuedMediaCount > 0)
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 6, 14, 0),
              child: Row(children: [
                const Icon(Icons.schedule, size: 14),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    queuedMediaStatusText,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12),
                  ),
                ),
              ]),
            ),
          if (_quarantinedMediaCount > 0)
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 6, 14, 0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.warning_amber_rounded, size: 16, color: Colors.orange),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          quarantinedMediaStatusText,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 12),
                        ),
                        TextButton.icon(
                          onPressed: _retryingQuarantinedMedia ? null : _retryQuarantinedAttachments,
                          icon: _retryingQuarantinedMedia
                              ? const SizedBox(width: 14, height: 14,
                                  child: CircularProgressIndicator(strokeWidth: 1.6))
                              : const Icon(Icons.refresh_rounded, size: 16),
                          label: const Text('Retry failed uploads'),
                          style: TextButton.styleFrom(
                            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                            visualDensity: VisualDensity.compact,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          AnimatedSize(
            duration: LikedinAppearance.reduceMotion.value
                ? Duration.zero
                : const Duration(milliseconds: 180),
            curve: Curves.easeOutCubic,
            alignment: Alignment.bottomCenter,
            child: (_replyingTo == null && _editingMessageId == null)
                ? const SizedBox.shrink()
                : Container(
                    margin: const EdgeInsets.fromLTRB(12, 8, 12, 2),
              padding: const EdgeInsets.fromLTRB(11, 8, 4, 8),
              decoration: BoxDecoration(
                color: likedinSurfaceRaised(Theme.of(context).brightness),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Row(
                children: [
                  Container(
                    width: 3,
                    height: 34,
                    decoration: BoxDecoration(
                      color: brandBlue,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          _editingMessageId != null
                              ? 'Editing message'
                              : 'Replying to ${_replyingTo!.senderId == messaging.currentUserId ? 'yourself' : headerName}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                             fontSize: 12,
                             color: brandBlue,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 2),
                        if (_editingMessageId != null)
                          Text(
                            _editingOriginalText ?? '',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 12,
                              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .78),
                            ),
                          )
                        else
                          _ReplyQuotePreview(
                            original: _replyingTo,
                            fallbackText: _summarizeMessage(_replyingTo!),
                            compact: true,
                          ),
                      ],
                    ),
                  ),
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    tooltip: 'Cancel',
                    onPressed: _cancelComposerMode,
                    icon: const Icon(Icons.close_rounded, size: 19),
                  ),
                ],
              ),
            ),
          ),
          if (uploading)
            LinearProgressIndicator(minHeight: 2.5, color: brandBlue),
          ValueListenableBuilder<TextEditingValue>(
            valueListenable: controller,
            builder: (context, editingValue, child) => SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10, 4, 10, 8),
                child: GlassPanel(
                  blur: 0,
                  glow: false,
                  radius: BorderRadius.circular(28),
                  tint: Theme.of(context).brightness == Brightness.dark
                      ? const Color(0xE0101E31)
                      : const Color(0xF2FFFFFF),
                  padding: const EdgeInsets.fromLTRB(6, 5, 6, 5),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  IconButton(
                    onPressed: uploading ? null : _showAttachmentPicker,
                    tooltip: uploading ? 'Uploading attachment…' : 'Gallery, camera and files',
                    visualDensity: VisualDensity.compact,
                    icon: uploading
                        ? const SizedBox(width: 19, height: 19, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.add_circle_outline_rounded, size: 24),
                  ),
                  IconButton(
                    onPressed: uploading ? null : _showStickerPicker,
                    tooltip: 'Stickers',
                    visualDensity: VisualDensity.compact,
                    icon: Icon(Icons.sticky_note_2_outlined, size: 22, color: brandBlue),
                  ),
                  const SizedBox(width: 3),
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: likedinSurfaceRaised(Theme.of(context).brightness),
                        borderRadius: BorderRadius.circular(26),
                      ),
                      child: ValueListenableBuilder<int>(
                        valueListenable: _voiceRecordSecondsNotifier,
                        builder: (context, voiceSeconds, _) => TextField(
                          focusNode: _composerFocus,
                          controller: controller,
                          // Typing during a recording would swap the mic button
                          // for Send and strand the recording.
                          readOnly: _recordingVoice,
                          minLines: 1,
                          maxLines: 5,
                          textCapitalization: TextCapitalization.sentences,
                          contentInsertionConfiguration: ContentInsertionConfiguration(
                            allowedMimeTypes: const [
                              'image/gif', 'image/png', 'image/jpeg', 'image/jpg', 'image/webp',
                              'image/bmp', 'image/tiff',
                            ],
                            onContentInserted: _handleKeyboardContent,
                          ),
                          inputFormatters: const [CodePointLengthLimitingTextInputFormatter(10000)],
                          buildCounter: (context, {required currentLength, required isFocused, maxLength}) {
                            final count = likedinMessageCodePointLength(controller.text);
                            if (count < 9500) return null;
                            return Text('$count / 10000', style: const TextStyle(fontSize: 12));
                          },
                          onChanged: (value) {
                            if (!_clearingComposerForSend && _pendingTextDraftId != null) {
                              _pendingTextDraftId = null;
                              _pendingTextDraftValue = null;
                            }
                            if (value.trim().isNotEmpty) {
                              final now = DateTime.now();
                              if (_lastTypingSentAt == null ||
                                  now.difference(_lastTypingSentAt!) >= const Duration(milliseconds: 1400)) {
                                _lastTypingSentAt = now;
                                unawaited(messaging.sendTyping(true).catchError((_) {}));
                              }
                              _typingPublishTimer ??= Timer.periodic(const Duration(milliseconds: 1400), (_) {
                                if (!mounted || controller.text.trim().isEmpty) return;
                                _lastTypingSentAt = DateTime.now();
                                messaging.sendTyping(true).catchError((_) {});
                              });
                              typingTimer?.cancel();
                              typingTimer = Timer(const Duration(seconds: 2), () {
                                _typingPublishTimer?.cancel();
                                _typingPublishTimer = null;
                                _lastTypingSentAt = null;
                                messaging.sendTyping(false).catchError((_) {});
                              });
                            } else {
                              _typingPublishTimer?.cancel();
                              _typingPublishTimer = null;
                              typingTimer?.cancel();
                              _lastTypingSentAt = null;
                              unawaited(messaging.sendTyping(false).catchError((_) {}));
                            }
                          },
                          onSubmitted: (_) => send(),
                          decoration: InputDecoration(
                            hintText: _recordingVoice
                                ? (_voiceCancelRequested ? 'Release to cancel recording' : 'Recording (${voiceSeconds}s)… slide left or tap ✕ to cancel')
                                : _editingMessageId != null
                                    ? 'Edit message…'
                                    : _replyingTo != null
                                        ? 'Write a reply…'
                                        : 'Message…',
                            filled: false,
                            border: InputBorder.none,
                            enabledBorder: InputBorder.none,
                            focusedBorder: InputBorder.none,
                            contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  if (_recordingVoice)
                    IconButton(
                      tooltip: 'Cancel recording',
                      icon: const Icon(Icons.close_rounded),
                      onPressed: () {
                        _voiceCancelRequested = false;
                        unawaited(_stopAndSendVoice(discard: true));
                      },
                    ),
                  AnimatedSwitcher(
                    duration: LikedinAppearance.reduceMotion.value
                        ? Duration.zero
                        : const Duration(milliseconds: 220),
                    transitionBuilder: (child, animation) => RotationTransition(
                      turns: Tween<double>(begin: 0.92, end: 1.0).animate(
                        CurvedAnimation(parent: animation, curve: Curves.easeOutCubic),
                      ),
                      child: ScaleTransition(
                        scale: CurvedAnimation(parent: animation, curve: Curves.easeOutBack),
                        child: FadeTransition(opacity: animation, child: child),
                      ),
                    ),
                    child: (_recordingVoice || (editingValue.text.trim().isEmpty && _editingMessageId == null))
                        ? Semantics(
                            key: const ValueKey('composer-mic'),
                            button: true,
                      label: _recordingVoice ? 'Recording voice message' : 'Voice message recording',
                      hint: 'Tap to start or stop a voice message. Hold and slide left to cancel.',
                      onTap: () {
                        if (_recordingVoice) { _voiceCancelRequested = false; _stopAndSendVoice(); }
                        else { _voiceCancelRequested = false; _startVoiceRecording(); }
                      },
                      child: GestureDetector(
                        onTap: () {
                          if (_recordingVoice) { _voiceCancelRequested = false; _stopAndSendVoice(); }
                          else { _voiceCancelRequested = false; _startVoiceRecording(); }
                        },
                        onLongPressStart: (_) { _voiceCancelRequested = false; _voiceGesture.longPressStarted(); _startVoiceRecording(); },
                        onLongPressMoveUpdate: (details) {
                          final dx = details.localOffsetFromOrigin.dx;
                          if (!_voiceCancelRequested && dx < -76) {
                            _voiceCancelRequested = true;
                            HapticFeedback.lightImpact();
                            if (mounted) setState(() {});
                          } else if (_voiceCancelRequested && dx > -42) {
                            _voiceCancelRequested = false;
                            if (mounted) setState(() {});
                          }
                        },
                        onLongPressEnd: (_) {
                          final cancel = _voiceCancelRequested;
                          _voiceCancelRequested = false;
                          // Only a long-press that began a recording may stop it.
                          if (_voiceGesture.longPressEnded()) _stopAndSendVoice(discard: cancel);
                        },
                        // Flutter also fires this for every plain TAP (the tap
                        // wins the gesture arena). It must not discard a
                        // recording that a tap is about to stop and send.
                        onLongPressCancel: () {
                          _voiceCancelRequested = false;
                          if (_voiceGesture.shouldDiscardOnCancel()) _stopAndSendVoice(discard: true);
                        },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 160),
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            color: _recordingVoice ? const Color(0xFFE5484D) : Theme.of(context).colorScheme.primary,
                            shape: BoxShape.circle,
                            boxShadow: [BoxShadow(
                              color: Theme.of(context).colorScheme.primary.withValues(alpha: .20),
                              blurRadius: 12,
                              offset: const Offset(0, 3),
                            )],
                          ),
                          child: Icon(_recordingVoice ? Icons.mic : Icons.mic_none_rounded, color: Theme.of(context).colorScheme.onPrimary),
                        ),
                      ),
                    )
                        : IconButton.filled(
                            key: const ValueKey('composer-send'),
                            tooltip: _editingMessageId != null ? 'Save edit' : 'Send message',
                      onPressed: saving || peerId == null ||
                              (editingValue.text.trim().isEmpty && _editingMessageId == null)
                          ? null
                          : () {
                              HapticFeedback.lightImpact();
                              send();
                            },
                      style: IconButton.styleFrom(
                        backgroundColor: Theme.of(context).colorScheme.primary,
                        foregroundColor: Theme.of(context).colorScheme.onPrimary,
                        disabledBackgroundColor: Theme.of(context).disabledColor.withValues(alpha: .25),
                      ),
                      icon: saving
                          ? SizedBox(
                              width: 19,
                              height: 19,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Theme.of(context).colorScheme.onPrimary,
                              ),
                            )
                          : const Icon(Icons.arrow_upward_rounded),
                          ),
                  ),
                ],
              ),
                ),
              ),
            ),
          ),
          ],
        ),
      );
  }
}

class _SwipeReplyGesture extends StatefulWidget {
  const _SwipeReplyGesture({super.key, required this.child, required this.onReply});
  final Widget child;
  final VoidCallback? onReply;

  @override
  State<_SwipeReplyGesture> createState() => _SwipeReplyGestureState();
}

class _SwipeReplyGestureState extends State<_SwipeReplyGesture> {
  final ValueNotifier<double> _dragNotifier = ValueNotifier<double>(0);

  @override
  void dispose() {
    _dragNotifier.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final canReply = widget.onReply != null;
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onHorizontalDragUpdate: canReply
          ? (details) {
              _dragNotifier.value =
                  (_dragNotifier.value + details.delta.dx).clamp(-58.0, 58.0);
            }
          : null,
      onHorizontalDragEnd: canReply
          ? (details) {
              final drag = _dragNotifier.value;
              final shouldReply =
                  drag.abs() > 42 || (details.primaryVelocity?.abs() ?? 0) > 260;
              _dragNotifier.value = 0;
              if (shouldReply) widget.onReply?.call();
            }
          : null,
      onHorizontalDragCancel: canReply
          ? () {
              if (mounted) _dragNotifier.value = 0;
            }
          : null,
      child: ValueListenableBuilder<double>(
        valueListenable: _dragNotifier,
        child: widget.child,
        builder: (context, drag, bubbleChild) {
          final offset = drag.clamp(-58.0, 58.0);
          return Stack(
            alignment: Alignment.center,
            children: [
              Positioned.fill(
                child: Align(
                  alignment: drag >= 0 ? Alignment.centerLeft : Alignment.centerRight,
                  child: Opacity(
                    opacity: canReply ? (offset.abs() / 58).clamp(0.0, 1.0) : 0,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Icon(Icons.reply_rounded, color: brandBlue, size: 20),
                    ),
                  ),
                ),
              ),
              AnimatedContainer(
                duration: drag == 0 ? const Duration(milliseconds: 180) : Duration.zero,
                curve: Curves.easeOutCubic,
                transform: Matrix4.translationValues(offset, 0, 0),
                child: bubbleChild,
              ),
            ],
          );
        },
      ),
    );
  }
}

class _TypingBubble extends StatefulWidget {
  const _TypingBubble({this.recording = false});
  final bool recording;
  @override
  State<_TypingBubble> createState() => _TypingBubbleState();
}

class _TypingBubbleState extends State<_TypingBubble> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 850));
    LikedinAppearance.reduceMotion.addListener(_syncMotion);
    WidgetsBinding.instance.addPostFrameCallback((_) => _syncMotion());
  }

  bool get _reduceMotion => LikedinAppearance.reduceMotion.value ||
      (mounted && MediaQuery.maybeOf(context)?.disableAnimations == true);

  void _syncMotion() {
    if (!mounted) return;
    if (_reduceMotion) {
      _controller.stop();
      _controller.value = .33;
    } else if (!_controller.isAnimating) {
      _controller.repeat();
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    WidgetsBinding.instance.addPostFrameCallback((_) => _syncMotion());
  }

  @override
  void dispose() {
    LikedinAppearance.reduceMotion.removeListener(_syncMotion);
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Align(
        alignment: Alignment.centerLeft,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 5),
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            border: Border.all(color: Theme.of(context).dividerColor),
            borderRadius: BorderRadius.circular(18),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: widget.recording
                ? [
                    const Icon(Icons.mic_rounded, size: 15, color: Color(0xFFE5484D)),
                    const SizedBox(width: 6),
                    const Text('Recording audio ', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                    ...List.generate(
                      4,
                      (i) => AnimatedBuilder(
                        animation: _controller,
                        builder: (_, __) {
                          final phase = ((_controller.value * 4 - i) % 1.0).abs();
                          final height = 6.0 + 10.0 * (1.0 - (phase - 0.5).abs() * 2.0);
                          return Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 1.5),
                            child: Container(
                              width: 3,
                              height: height,
                              decoration: BoxDecoration(
                                color: const Color(0xFFE5484D),
                                borderRadius: BorderRadius.circular(2),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ]
                : [
                    const Text('Typing ', style: TextStyle(fontSize: 12)),
                    ...List.generate(
                      3,
                      (i) => AnimatedBuilder(
                        animation: _controller,
                        builder: (_, __) {
                          final v = (_controller.value * 3 - i).clamp(0.0, 1.0);
                          return Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 2),
                            child: Transform.translate(
                              offset: Offset(0, -4 * v),
                              child: CircleAvatar(radius: 3, backgroundColor: brandBlue),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
          ),
        ),
      );
}

class _IncomingCallDialog extends StatefulWidget {
  const _IncomingCallDialog({
    required this.callId,
    required this.callerId,
    required this.offer,
    required this.withVideo,
    this.autoAccept = false,
  });
  final String callId, callerId;
  final Map<String, dynamic> offer;
  final bool withVideo;
  final bool autoAccept;
  @override
  State<_IncomingCallDialog> createState() => _IncomingCallDialogState();
}

class _IncomingCallDialogState extends State<_IncomingCallDialog> {
  late final LikedinCallService call;
  final ProximityCallController proximity = ProximityCallController();
  StreamSubscription<String>? subscription;
  bool accepting = false, accepted = false, connected = false, finished = false, _checkingRemoteStatus = false;
  bool _handlingBack = false, _dialogClosing = false;
  String status = 'Incoming call';
  String callerDisplayName = 'Likedin contact';
  Timer? _incomingStatusTimer;
  Timer? _durationTicker;
  Stopwatch? _stopwatch;
  final ValueNotifier<int> _elapsedSecondsNotifier = ValueNotifier<int>(0);

  String _formatDuration(int seconds) =>
      '${(seconds ~/ 60).toString().padLeft(2, '0')}:${(seconds % 60).toString().padLeft(2, '0')}';

  @override
  void initState() {
    super.initState();
    call = LikedinCallService(Supabase.instance.client);
    _loadCallerDisplayName();
    if (!widget.autoAccept) CallAlertController.startIncoming();
    _incomingStatusTimer = Timer.periodic(
      const Duration(seconds: 2),
      (_) => _checkIncomingStatus(),
    );
    if (widget.autoAccept) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) unawaited(_accept());
      });
    }
  }

  Future<void> _loadCallerDisplayName() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getString('likedIn_nickname_${widget.callerId}');
      if (saved != null && saved.trim().isNotEmpty) {
        if (mounted) setState(() => callerDisplayName = saved.trim());
        return;
      }
      final row = await Supabase.instance.client.from('profiles')
          .select('display_name').eq('user_id', widget.callerId).maybeSingle();
      final name = row?['display_name']?.toString().trim();
      if (mounted && name != null && name.isNotEmpty) setState(() => callerDisplayName = name);
    } catch (error) { debugPrint('Incoming caller-name lookup deferred: $error'); }
  }

  void _closeDialog() {
    if (!mounted || _dialogClosing) return;
    _dialogClosing = true;
    if (Navigator.of(context).canPop()) Navigator.of(context).pop();
  }

  Future<void> _handleSystemBack() async {
    if (_handlingBack || accepting) return;
    _handlingBack = true;
    try {
      if (!finished) {
        if (accepted) {
          try { await call.end(); } catch (error) {
            debugPrint('Incoming call termination failed; closing dialog anyway: $error');
          }
        } else {
          try {
            await _reject();
          } catch (error) {
            debugPrint('Incoming call decline failed; closing dialog anyway: $error');
          }
        }
      }
    } finally {
      _closeDialog();
      _handlingBack = false;
    }
  }

  Future<void> _checkIncomingStatus() async {
    if (!mounted || accepting || accepted || finished || _checkingRemoteStatus) return;
    _checkingRemoteStatus = true;
    try {
      final row = await Supabase.instance.client
          .from('likedin_calls')
          .select('status')
          .eq('id', widget.callId)
          .maybeSingle();
      final remoteStatus = row?['status']?.toString();
      if (remoteStatus != null &&
          remoteStatus != 'ringing' &&
          mounted &&
          !accepting &&
          !accepted) {
        await CallAlertController.stop();
        if (!mounted) return;
        setState(() {
          status = remoteStatus == 'missed' ? 'Missed call' : remoteStatus == 'failed' ? 'Call failed' : 'Call ended';
          finished = true;
        });
        Future<void>.delayed(const Duration(milliseconds: 900), () {
          _closeDialog();
        });
      }
    } catch (_) {
    } finally {
      _checkingRemoteStatus = false;
    }
  }

  Future<void> _accept() async {
    if (accepting || accepted || finished) return;
    await CallAlertController.stop();
    if (!mounted) return;
    setState(() {
      accepting = true;
      status = 'Connecting…';
    });
    try {
      await call.initialize(withVideo: widget.withVideo);
      if (!mounted) return;
      subscription = call.changes.listen((value) {
        if (!mounted) return;
        if (value == 'connected' && !connected) {
          connected = true;
          if (widget.withVideo) {
            unawaited(_callAlertsMethodChannel
                .invokeMethod<bool>('setVideoCallActive', const {'active': true})
                .catchError((Object _) => false));
          }
          _stopwatch = Stopwatch()..start();
          _durationTicker?.cancel();
          _durationTicker = Timer.periodic(const Duration(seconds: 1), (_) {
            if (mounted && _stopwatch != null) {
              _elapsedSecondsNotifier.value = _stopwatch!.elapsed.inSeconds;
            }
          });
        }
        setState(() {
          status = value == 'disconnected'
              ? 'Reconnecting…'
              : value == 'connected'
                  ? 'Connected'
                  : value.startsWith('failed') || value.startsWith('error:')
                      ? 'Call connection failed'
                      : value == 'ringing' ? 'Ringing…' : value == 'ended' ? 'Call ended'
                      : value == 'missed' ? 'Missed call' : value == 'rejected' ? 'Call declined'
                      : 'Connecting…';
          if (value == 'ended' ||
              value == 'missed' ||
              value == 'rejected' ||
              value.startsWith('failed') ||
              value.startsWith('error:')) {
            finished = true;
          }
        });
        if (finished) {
          Future<void>.delayed(const Duration(milliseconds: 650), () {
            _closeDialog();
          });
        }
      });
      await call.accept(widget.callId, widget.callerId, widget.offer, withVideo: widget.withVideo);
      await proximity.update(
        active: !widget.withVideo,
        enabled: !widget.withVideo && !call.speaker,
      );
      if (mounted) {
        setState(() {
          accepted = true;
          accepting = false;
          status = connected ? 'Connected' : 'Connecting…';
        });
      }
    } catch (e) {
      // Renderer initialization can fail before CallService.accept() runs its
      // own rejection cleanup. Make the server state terminal in either case;
      // a failed answer must never leave the other handset ringing forever.
      try {
        await Supabase.instance.client.rpc('likedin_update_call_status', params: {
          'p_call_id': widget.callId,
          'p_new_status': 'rejected',
        });
      } catch (_) {
        // If accept() already committed and then failed, CallService has
        // already changed the row to ended; rejection is no longer legal.
      }
      try {
        final currentUid = Supabase.instance.client.auth.currentUser?.id;
        if (currentUid != null) {
          await Supabase.instance.client.from('likedin_call_signals').insert({
            'call_id': widget.callId,
            'sender_id': currentUid,
            'kind': 'reject',
            'payload': <String, dynamic>{},
          });
        }
      } catch (_) {}
      try { await LikedinNotificationService.instance.cancelIncomingCall(widget.callId); } catch (_) {}
      if (mounted) {
        setState(() {
          accepting = false;
          finished = true;
          status = 'Could not answer the call. Check permissions and try again.';
        });
        Future<void>.delayed(const Duration(milliseconds: 1500), () {
          if (mounted) _closeDialog();
        });
      }
    }
  }

  Future<void> _toggleSpeaker() async {
    if (!mounted) return;
    await call.toggleSpeaker();
    if (!mounted) return;
    await proximity.update(
      active: accepted && !widget.withVideo,
      enabled: accepted && !widget.withVideo && !call.speaker,
    );
    if (mounted) setState(() {});
  }

  Future<void> _reject() async {
    await CallAlertController.stop();
    try {
      await Supabase.instance.client.rpc('likedin_update_call_status', params: {
        'p_call_id': widget.callId,
        'p_new_status': 'rejected',
      });
    } catch (e) {
      debugPrint('Could not commit incoming call rejection: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not decline the call. Please try again.')),
        );
      }
      return;
    }
    try {
      await LikedinNotificationService.instance.cancelIncomingCall(widget.callId);
    } catch (e) {
      debugPrint('Call declined, but local incoming-call notification could not be cancelled: $e');
    }
    try {
      final currentUid = Supabase.instance.client.auth.currentUser?.id;
      if (currentUid != null) {
        await Supabase.instance.client.from('likedin_call_signals').insert({
          'call_id': widget.callId,
          'sender_id': currentUid,
          'kind': 'reject',
          'payload': <String, dynamic>{},
        });
      }
    } catch (e) {
      // The server-side state is authoritative; missing signaling must not
      // turn a declined call into a missed call.
      debugPrint('Call was declined, but reject signaling failed: $e');
    }
    if (mounted) {
      setState(() {
        finished = true;
        status = 'Call declined';
      });
      _closeDialog();
    }
  }

  @override
  void dispose() {
    if (widget.withVideo) {
      unawaited(_callAlertsMethodChannel
          .invokeMethod<bool>('setVideoCallActive', const {'active': false})
          .catchError((Object _) => false));
    }
    _incomingStatusTimer?.cancel();
    _durationTicker?.cancel();
    _stopwatch?.stop();
    _elapsedSecondsNotifier.dispose();
    CallAlertController.stop();
    proximity.dispose();
    subscription?.cancel();
    call.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isActive = accepted && !finished;
    final headline = widget.withVideo ? 'Video call' : 'Audio call';
    final subtitle = isActive
        ? 'Connected'
        : finished
            ? headline
            : 'Incoming ${widget.withVideo ? 'video' : 'audio'} call';

    String statusTextFor(int seconds) => (accepted || finished)
        ? (connected && !finished && status != 'Reconnecting…' ? _formatDuration(seconds) : status)
        : 'Your friend is calling';

    final activeControlsWrap = Wrap(
      alignment: WrapAlignment.center,
      crossAxisAlignment: WrapCrossAlignment.center,
      spacing: 8,
      runSpacing: 18,
      children: [
        _activeCallControl(
          call.muted ? Icons.mic_off_rounded : Icons.mic_rounded,
          call.muted ? 'Unmute' : 'Mute',
          call.muted,
          () async {
            await call.toggleMute();
            if (mounted) setState(() {});
          },
        ),
        _activeCallControl(
          call.speaker ? Icons.volume_up_rounded : Icons.hearing_rounded,
          'Speaker',
          call.speaker,
          _toggleSpeaker,
        ),
        if (widget.withVideo)
          _activeCallControl(
            call.camera ? Icons.videocam_rounded : Icons.videocam_off_rounded,
            'Camera',
            !call.camera,
            () async {
              await call.toggleCamera();
              if (mounted) setState(() {});
            },
          ),
        if (widget.withVideo)
          _activeCallControl(Icons.cameraswitch_rounded, 'Flip', false, call.switchCamera),
        _incomingCallAction(
          icon: Icons.call_end_rounded,
          label: 'End call',
          color: _callDanger,
          onTap: () async {
            try {
              await call.end();
            } catch (error) {
              debugPrint('Incoming call end failed; closing dialog anyway: $error');
            } finally {
              _closeDialog();
            }
          },
        ),
      ],
    );

    return PopScope<Object?>(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) unawaited(_handleSystemBack());
      },
      child: Dialog.fullscreen(
        backgroundColor: _callBackground,
        child: isActive && widget.withVideo
            ? Builder(builder: (context) {
                final inPip = MediaQuery.sizeOf(context).width < 260;
                return Stack(
                fit: StackFit.expand,
                children: [
                  RTCVideoView(
                    call.remoteRenderer,
                    objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                  ),
                  if (!inPip) ...[
                  Positioned(
                    left: 0,
                    right: 0,
                    top: 0,
                    height: 110,
                    child: IgnorePointer(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.black.withValues(alpha: .55),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    height: 200,
                    child: IgnorePointer(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            colors: [
                              Colors.black.withValues(alpha: .72),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 16,
                    top: MediaQuery.paddingOf(context).top + 12,
                    child: _CallPill(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          ValueListenableBuilder<int>(
                            valueListenable: _elapsedSecondsNotifier,
                            builder: (_, seconds, __) => Text(
                              connected ? _formatDuration(seconds) : status,
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                            ),
                          ),
                          const SizedBox(width: 6),
                          InkWell(
                            borderRadius: BorderRadius.circular(14),
                            onTap: () => unawaited(_callAlertsMethodChannel
                                .invokeMethod<bool>('enterPipMode')
                                .catchError((Object _) => false)),
                            child: const Padding(
                              padding: EdgeInsets.all(2),
                              child: Icon(
                                Icons.picture_in_picture_alt_rounded,
                                color: Colors.white70,
                                size: 17,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    right: 16,
                    top: MediaQuery.paddingOf(context).top + 12,
                    width: 106,
                    height: 146,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(18),
                      child: Container(
                        decoration: BoxDecoration(
                          color: _callPanel,
                          border: Border.all(color: Colors.white24),
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: RTCVideoView(
                          call.localRenderer,
                          mirror: call.usingFrontCamera,
                          objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 16,
                    right: 16,
                    bottom: MediaQuery.paddingOf(context).bottom + 20,
                    child: activeControlsWrap,
                  ),
                  ],
                ],
              );
              })
            : SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(24, 20, 24, 28),
                  child: Column(
                    children: [
                      Expanded(
                        child: Center(
                          child: SingleChildScrollView(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                _CallHaloAvatar(
                                  icon: widget.withVideo ? Icons.videocam_rounded : Icons.person_rounded,
                                  size: 132,
                                  animate: !isActive && !finished,
                                ),
                                const SizedBox(height: 28),
                                Text(
                                  callerDisplayName,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 30,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: -.8,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  subtitle,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(color: _callMuted, fontSize: 16),
                                ),
                                const SizedBox(height: 20),
                                ValueListenableBuilder<int>(
                                  valueListenable: _elapsedSecondsNotifier,
                                  builder: (_, seconds, __) => _CallStatusLine(
                                    text: statusTextFor(seconds),
                                    color: isActive ? _callPositive : _callAccent,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),
                      if (!accepted && !finished)
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            _incomingCallAction(
                              icon: Icons.call_end_rounded,
                              label: 'Decline',
                              color: _callDanger,
                              onTap: accepting ? null : _reject,
                            ),
                            _incomingCallAction(
                              icon: Icons.call_rounded,
                              label: accepting ? 'Connecting' : 'Answer',
                              color: _callPositive,
                              onTap: (accepting || finished) ? null : _accept,
                            ),
                          ],
                        )
                      else if (isActive)
                        activeControlsWrap
                      else
                        SizedBox(
                          width: double.infinity,
                          child: FilledButton(
                            onPressed: _closeDialog,
                            style: FilledButton.styleFrom(
                              backgroundColor: _callButton,
                              foregroundColor: Colors.white,
                            ),
                            child: const Text('Close'),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
      ),
    );
  }
}

Widget _incomingCallAction({
  required IconData icon,
  required String label,
  required Color color,
  required VoidCallback? onTap,
}) =>
    SizedBox(
      width: 84,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Semantics(
            button: true,
            enabled: onTap != null,
            label: label,
            child: Material(
              color: onTap == null ? color.withValues(alpha: .45) : color,
              shape: const CircleBorder(),
              child: InkWell(
                customBorder: const CircleBorder(),
                onTap: onTap,
                child: SizedBox(
                  width: 72,
                  height: 72,
                  child: Icon(icon, size: 30, color: Colors.white),
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );

Widget _activeCallControl(
  IconData icon,
  String label,
  bool active,
  VoidCallback onPressed,
) =>
    _CallRoundButton(icon: icon, label: label, active: active, onPressed: onPressed);



String? _extractFirstUrl(String text) {
  final match = RegExp(r'((https?:\/\/|www\.)[^\s<>"]+)', caseSensitive: false).firstMatch(text);
  return match?.group(0);
}

class _RichMessageText extends StatefulWidget {
  const _RichMessageText({
    required this.text,
    required this.style,
    required this.linkColor,
  });
  final String text;
  final TextStyle style;
  final Color linkColor;

  @override
  State<_RichMessageText> createState() => _RichMessageTextState();
}

class _RichMessageTextState extends State<_RichMessageText> {
  static final RegExp _tokenRegex = RegExp(
    r'((https?:\/\/|www\.)[^\s<>"]+)|\|\|([^|\n]+)\|\||\*([^*\n]+)\*|_([^_\n]+)_|~([^~\n]+)~|`([^`\n]+)`',
    caseSensitive: false,
  );
  final List<TapGestureRecognizer> _recognizers = <TapGestureRecognizer>[];

  @override
  void dispose() {
    for (final r in _recognizers) {
      r.dispose();
    }
    _recognizers.clear();
    super.dispose();
  }

  Future<void> _openUrl(String raw) async {
    final normalized = raw.startsWith('http://') || raw.startsWith('https://')
        ? raw
        : 'https://$raw';
    final uri = Uri.tryParse(normalized);
    if (uri == null) return;
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    for (final r in _recognizers) {
      r.dispose();
    }
    _recognizers.clear();

    final matches = _tokenRegex.allMatches(widget.text).toList();
    if (matches.isEmpty) {
      return Text(widget.text, softWrap: true, style: widget.style);
    }
    final dark = Theme.of(context).brightness == Brightness.dark;
    final spans = <InlineSpan>[];
    var lastEnd = 0;
    for (final m in matches) {
      if (m.start > lastEnd) {
        spans.add(TextSpan(text: widget.text.substring(lastEnd, m.start)));
      }
      final urlText = m.group(1);
      final spoilerText = m.group(3);
      final boldText = m.group(4);
      final italicText = m.group(5);
      final strikeText = m.group(6);
      final codeText = m.group(7);

      if (urlText != null) {
        final recognizer = TapGestureRecognizer()..onTap = () => _openUrl(urlText);
        _recognizers.add(recognizer);
        spans.add(TextSpan(
          text: urlText,
          style: TextStyle(
            color: widget.linkColor,
            decoration: TextDecoration.underline,
            decorationColor: widget.linkColor,
            fontWeight: FontWeight.w600,
          ),
          recognizer: recognizer,
        ));
      } else if (spoilerText != null) {
        spans.add(WidgetSpan(
          alignment: PlaceholderAlignment.baseline,
          baseline: TextBaseline.alphabetic,
          child: _SpoilerChip(text: spoilerText, style: widget.style),
        ));
      } else if (boldText != null) {
        spans.add(TextSpan(text: boldText, style: const TextStyle(fontWeight: FontWeight.w800)));
      } else if (italicText != null) {
        spans.add(TextSpan(text: italicText, style: const TextStyle(fontStyle: FontStyle.italic)));
      } else if (strikeText != null) {
        spans.add(TextSpan(
          text: strikeText,
          style: const TextStyle(decoration: TextDecoration.lineThrough),
        ));
      } else if (codeText != null) {
        spans.add(TextSpan(
          text: ' $codeText ',
          style: TextStyle(
            fontFamily: 'monospace',
            fontSize: (widget.style.fontSize ?? 15) - 1,
            backgroundColor: (dark ? Colors.white : Colors.black).withValues(alpha: .10),
          ),
        ));
      }
      lastEnd = m.end;
    }
    if (lastEnd < widget.text.length) {
      spans.add(TextSpan(text: widget.text.substring(lastEnd)));
    }
    return Text.rich(
      TextSpan(style: widget.style, children: spans),
      softWrap: true,
    );
  }
}

class _SpoilerChip extends StatefulWidget {
  const _SpoilerChip({required this.text, required this.style});
  final String text;
  final TextStyle style;

  @override
  State<_SpoilerChip> createState() => _SpoilerChipState();
}

class _SpoilerChipState extends State<_SpoilerChip> {
  bool _revealed = false;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() => _revealed = !_revealed);
      },
      child: AnimatedContainer(
        duration: LikedinAppearance.reduceMotion.value
            ? Duration.zero
            : const Duration(milliseconds: 220),
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
        decoration: BoxDecoration(
          color: _revealed
              ? (dark ? Colors.white : Colors.black).withValues(alpha: .06)
              : (dark ? const Color(0xFF475569) : const Color(0xFFCBD5E1)),
          borderRadius: BorderRadius.circular(6),
        ),
        child: AnimatedOpacity(
          duration: LikedinAppearance.reduceMotion.value
              ? Duration.zero
              : const Duration(milliseconds: 200),
          opacity: _revealed ? 1.0 : 0.0,
          child: Text(widget.text, style: widget.style),
        ),
      ),
    );
  }
}

class _LinkPreviewData {
  const _LinkPreviewData({
    required this.title,
    required this.siteName,
    this.imageUrl,
  });
  final String title;
  final String siteName;
  final String? imageUrl;
}

class _LinkPreviewCard extends StatefulWidget {
  const _LinkPreviewCard({required this.url});
  final String url;

  @override
  State<_LinkPreviewCard> createState() => _LinkPreviewCardState();
}

class _LinkPreviewCardState extends State<_LinkPreviewCard> {
  static final Map<String, _LinkPreviewData?> _cache = <String, _LinkPreviewData?>{};
  static final Map<String, Future<_LinkPreviewData?>> _inFlight =
      <String, Future<_LinkPreviewData?>>{};
  _LinkPreviewData? _data;

  String get _normalizedUrl =>
      widget.url.startsWith('http://') || widget.url.startsWith('https://')
          ? widget.url
          : 'https://${widget.url}';

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant _LinkPreviewCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.url != widget.url) _load();
  }

  Future<void> _load() async {
    final url = _normalizedUrl;
    if (_cache.containsKey(url)) {
      if (mounted) setState(() => _data = _cache[url]);
      return;
    }
    final future = _inFlight.putIfAbsent(url, () => _fetchMetadata(url));
    final result = await future;
    _inFlight.remove(url);
    if (_cache.length > 120) _cache.clear();
    _cache[url] = result;
    if (mounted) setState(() => _data = result);
  }

  static String _decodeHtml(String raw) => raw
      .replaceAll('&amp;', '&')
      .replaceAll('&quot;', '"')
      .replaceAll('&#39;', "'")
      .replaceAll('&apos;', "'")
      .replaceAll('&lt;', '<')
      .replaceAll('&gt;', '>')
      .replaceAll('&nbsp;', ' ')
      .trim();

  static String? _extractMeta(String html, String property) {
    final p1 = RegExp(
      '<meta[^>]+(?:property|name)=["\']$property["\'][^>]+content=["\']([^"\']+)["\']',
      caseSensitive: false,
    ).firstMatch(html);
    if (p1 != null) return _decodeHtml(p1.group(1)!);
    final p2 = RegExp(
      '<meta[^>]+content=["\']([^"\']+)["\'][^>]+(?:property|name)=["\']$property["\']',
      caseSensitive: false,
    ).firstMatch(html);
    return p2 == null ? null : _decodeHtml(p2.group(1)!);
  }

  static Future<_LinkPreviewData?> _fetchMetadata(String url) async {
    final uri = Uri.tryParse(url);
    if (uri == null || (uri.scheme != 'https' && uri.scheme != 'http')) return null;
    try {
      final response = await http
          .get(uri, headers: const {'User-Agent': 'Mozilla/5.0 (compatible; LikedinPreview/1.0)'})
          .timeout(const Duration(seconds: 5));
      if (response.statusCode != 200) return null;
      final contentType = response.headers['content-type']?.toLowerCase() ?? '';
      if (!contentType.contains('text/html') && !contentType.contains('application/xhtml')) {
        return null;
      }
      final body = response.body.length > 65536 ? response.body.substring(0, 65536) : response.body;
      var title = _extractMeta(body, 'og:title') ?? _extractMeta(body, 'twitter:title');
      if (title == null || title.isEmpty) {
        final titleMatch = RegExp(r'<title[^>]*>([^<]+)</title>', caseSensitive: false).firstMatch(body);
        if (titleMatch != null) title = _decodeHtml(titleMatch.group(1)!);
      }
      if (title == null || title.isEmpty) return null;
      var image = _extractMeta(body, 'og:image') ?? _extractMeta(body, 'twitter:image');
      if (image != null && image.startsWith('/')) {
        image = '${uri.scheme}://${uri.host}$image';
      }
      if (image != null && !image.startsWith('http://') && !image.startsWith('https://')) {
        image = null;
      }
      final site = _extractMeta(body, 'og:site_name') ?? uri.host.replaceFirst('www.', '');
      return _LinkPreviewData(title: title, siteName: site, imageUrl: image);
    } catch (_) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final data = _data;
    if (data == null) return const SizedBox.shrink();
    final dark = Theme.of(context).brightness == Brightness.dark;
    final accent = likedinPrimary(Theme.of(context).brightness);
    return GestureDetector(
      onTap: () async {
        final uri = Uri.tryParse(_normalizedUrl);
        if (uri != null) {
          try {
            await launchUrl(uri, mode: LaunchMode.externalApplication);
          } catch (_) {}
        }
      },
      child: Container(
        margin: const EdgeInsets.only(top: 8),
        padding: const EdgeInsets.all(9),
        decoration: BoxDecoration(
          color: (dark ? Colors.white : Colors.black).withValues(alpha: dark ? .06 : .04),
          borderRadius: BorderRadius.circular(12),
          border: Border(left: BorderSide(color: accent, width: 3)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (data.imageUrl != null) ...[
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.network(
                  data.imageUrl!,
                  width: 52,
                  height: 52,
                  cacheWidth: 160,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                ),
              ),
              const SizedBox(width: 9),
            ],
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    data.siteName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: accent),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    data.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, height: 1.25),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ViewOncePhotoTile extends StatelessWidget {
  const _ViewOncePhotoTile({
    required this.opened,
    required this.outgoing,
    required this.onOpen,
  });
  final bool opened;
  final bool outgoing;
  final VoidCallback? onOpen;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final accent = likedinPrimary(brightness);
    final mutedColor = likedinMutedText(brightness);
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: opened ? null : onOpen,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 4),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: (opened ? mutedColor : accent).withValues(alpha: .15),
                border: Border.all(
                  color: opened ? mutedColor.withValues(alpha: .4) : accent,
                  width: 1.5,
                ),
              ),
              child: Icon(
                opened ? Icons.check_rounded : Icons.looks_one_outlined,
                size: 18,
                color: opened ? mutedColor : accent,
              ),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  opened ? 'Opened' : 'Photo',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    fontStyle: opened ? FontStyle.italic : FontStyle.normal,
                    color: opened ? mutedColor : null,
                  ),
                ),
                if (!opened)
                  Text(
                    outgoing ? 'Sent as view-once' : 'Tap to view once',
                    style: TextStyle(fontSize: 11, color: mutedColor),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}


class _PhotoAlbumGrid extends StatelessWidget {
  const _PhotoAlbumGrid({required this.items});
  final List<({Map<String, dynamic> payload, String name})> items;

  void _openAt(BuildContext context, int index) {
    Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (_) => _AlbumViewerPage(items: items, initialIndex: index),
      ),
    );
  }

  Widget _tile(BuildContext context, int idx, {int extraCount = 0}) {
    final item = items[idx];
    return GestureDetector(
      onTap: () => _openAt(context, idx),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: FutureBuilder<File>(
          future: SharedMediaService(Supabase.instance.client).cachedFile(item.payload),
          builder: (context, snap) {
            final file = snap.data;
            return Stack(
              fit: StackFit.expand,
              children: [
                if (file != null)
                  Image.file(
                    file,
                    fit: BoxFit.cover,
                    cacheWidth: 360,
                    errorBuilder: (_, __, ___) => const ColoredBox(
                      color: Color(0x22000000),
                      child: Center(child: Icon(Icons.broken_image_outlined)),
                    ),
                  )
                else
                  ColoredBox(
                    color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: .55),
                    child: const Center(
                      child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
                    ),
                  ),
                if (extraCount > 0)
                  ColoredBox(
                    color: Colors.black.withValues(alpha: .52),
                    child: Center(
                      child: Text(
                        '+$extraCount',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final visibleCount = items.length > 4 ? 4 : items.length;
    final extra = items.length - 4;
    if (visibleCount == 2) {
      return SizedBox(
        width: 268,
        height: 150,
        child: Row(
          children: [
            Expanded(child: _tile(context, 0)),
            const SizedBox(width: 4),
            Expanded(child: _tile(context, 1)),
          ],
        ),
      );
    }
    if (visibleCount == 3) {
      return SizedBox(
        width: 268,
        height: 236,
        child: Column(
          children: [
            Expanded(
              child: Row(
                children: [
                  Expanded(child: _tile(context, 0)),
                  const SizedBox(width: 4),
                  Expanded(child: _tile(context, 1)),
                ],
              ),
            ),
            const SizedBox(height: 4),
            Expanded(child: _tile(context, 2)),
          ],
        ),
      );
    }
    return SizedBox(
      width: 268,
      height: 268,
      child: Column(
        children: [
          Expanded(
            child: Row(
              children: [
                Expanded(child: _tile(context, 0)),
                const SizedBox(width: 4),
                Expanded(child: _tile(context, 1)),
              ],
            ),
          ),
          const SizedBox(height: 4),
          Expanded(
            child: Row(
              children: [
                Expanded(child: _tile(context, 2)),
                const SizedBox(width: 4),
                Expanded(child: _tile(context, 3, extraCount: extra > 0 ? extra : 0)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
