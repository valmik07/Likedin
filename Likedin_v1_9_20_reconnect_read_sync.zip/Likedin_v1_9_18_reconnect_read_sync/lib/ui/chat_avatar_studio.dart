import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'glassmorphism.dart';

/// Live chat activity states shown by the Snapchat-style peeking avatar.
enum ChatAvatarActivity { hidden, present, typing, recording }

/// Compact (~100-byte JSON) customizable avatar configuration synced over
/// Realtime Broadcast with zero database writes or Storage uploads.
class ChatAvatarConfig {
  const ChatAvatarConfig({
    this.gender = 'male',
    this.skinIndex = 2,
    this.hairStyle = 0,
    this.hairColor = 0,
    this.outfitStyle = 0,
    this.outfitColor = 0,
    this.accessory = 0,
    this.facialHair = 0,
  });

  final String gender; // 'male' | 'female'
  final int skinIndex; // 0..5
  final int hairStyle; // 0..7
  final int hairColor; // 0..6
  final int outfitStyle; // 0..5
  final int outfitColor; // 0..9
  final int accessory; // 0..4
  final int facialHair; // 0..3

  static const ChatAvatarConfig maleDefault = ChatAvatarConfig(
    gender: 'male',
    skinIndex: 2,
    hairStyle: 1,
    hairColor: 0,
    outfitStyle: 0,
    outfitColor: 0,
    accessory: 0,
    facialHair: 1,
  );

  static const ChatAvatarConfig femaleDefault = ChatAvatarConfig(
    gender: 'female',
    skinIndex: 1,
    hairStyle: 4,
    hairColor: 1,
    outfitStyle: 0,
    outfitColor: 9,
    accessory: 0,
    facialHair: 0,
  );

  static const List<Color> skinTones = <Color>[
    Color(0xFFFFE0CC),
    Color(0xFFF6C7A3),
    Color(0xFFE0A97E),
    Color(0xFFC68657),
    Color(0xFF9C623B),
    Color(0xFF6B3E26),
  ];

  static const List<Color> hairColors = <Color>[
    Color(0xFF1A1A22), // Jet Black
    Color(0xFF3E2723), // Espresso
    Color(0xFF6D4C41), // Chestnut
    Color(0xFF9E3B2B), // Auburn
    Color(0xFFD7A857), // Honey Blonde
    Color(0xFF94A3B8), // Silver
    Color(0xFFD96C95), // Rose
  ];

  static const List<String> hairStyleNames = <String>[
    'Short Fade',
    'Messy Waves',
    'Curly Top',
    'Side Part',
    'Long Sleek',
    'Ponytail',
    'Cute Bob',
    'Twin Buns',
  ];

  static const List<String> outfitNames = <String>[
    'Hoodie',
    'T-Shirt',
    'Polo',
    'Jacket',
    'Sweater',
    'Kurta',
  ];

  static const List<Color> outfitColors = <Color>[
    Color(0xFF2563EB), // Cobalt
    Color(0xFF10B981), // Mint
    Color(0xFFEF4444), // Coral Red
    Color(0xFF8B5CF6), // Lavender
    Color(0xFF1E293B), // Charcoal
    Color(0xFF9F1239), // Burgundy
    Color(0xFFD97706), // Mustard
    Color(0xFF0EA5E9), // Sky
    Color(0xFF15803D), // Forest
    Color(0xFFEC4899), // Rose Pink
  ];

  static const List<String> accessoryNames = <String>[
    'None',
    'Glasses',
    'Shades',
    'Cap',
    'Headphones',
  ];

  static const List<String> facialHairNames = <String>[
    'None',
    'Stubble',
    'Beard',
    'Goatee',
  ];

  ChatAvatarConfig copyWith({
    String? gender,
    int? skinIndex,
    int? hairStyle,
    int? hairColor,
    int? outfitStyle,
    int? outfitColor,
    int? accessory,
    int? facialHair,
  }) =>
      ChatAvatarConfig(
        gender: gender ?? this.gender,
        skinIndex: (skinIndex ?? this.skinIndex).clamp(0, skinTones.length - 1),
        hairStyle: (hairStyle ?? this.hairStyle).clamp(0, hairStyleNames.length - 1),
        hairColor: (hairColor ?? this.hairColor).clamp(0, hairColors.length - 1),
        outfitStyle: (outfitStyle ?? this.outfitStyle).clamp(0, outfitNames.length - 1),
        outfitColor: (outfitColor ?? this.outfitColor).clamp(0, outfitColors.length - 1),
        accessory: (accessory ?? this.accessory).clamp(0, accessoryNames.length - 1),
        facialHair: (facialHair ?? this.facialHair).clamp(0, facialHairNames.length - 1),
      );

  Map<String, dynamic> toJson() => <String, dynamic>{
        'g': gender == 'female' ? 'f' : 'm',
        's': skinIndex,
        'hs': hairStyle,
        'hc': hairColor,
        'os': outfitStyle,
        'oc': outfitColor,
        'a': accessory,
        'f': facialHair,
      };

  static ChatAvatarConfig fromJson(Map<dynamic, dynamic> map) {
    int readInt(String key, int fallback, int max) {
      final raw = map[key];
      final v = raw is num ? raw.toInt() : int.tryParse(raw?.toString() ?? '');
      return (v ?? fallback).clamp(0, max);
    }

    final g = map['g']?.toString().toLowerCase() == 'f' ? 'female' : 'male';
    return ChatAvatarConfig(
      gender: g,
      skinIndex: readInt('s', 2, skinTones.length - 1),
      hairStyle: readInt('hs', g == 'female' ? 4 : 1, hairStyleNames.length - 1),
      hairColor: readInt('hc', 0, hairColors.length - 1),
      outfitStyle: readInt('os', 0, outfitNames.length - 1),
      outfitColor: readInt('oc', g == 'female' ? 9 : 0, outfitColors.length - 1),
      accessory: readInt('a', 0, accessoryNames.length - 1),
      facialHair: readInt('f', 0, facialHairNames.length - 1),
    );
  }

  static String _ownKey(String uid) => 'likedin_my_avatar_v1_$uid';
  static String _peerKey(String uid, String peerId) => 'likedin_peer_avatar_v1_${uid}_$peerId';

  static Future<ChatAvatarConfig> loadOwn(String uid) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_ownKey(uid));
      if (raw != null && raw.isNotEmpty) {
        final decoded = jsonDecode(raw);
        if (decoded is Map) return fromJson(decoded);
      }
    } catch (_) {}
    return maleDefault;
  }

  static Future<void> saveOwn(String uid, ChatAvatarConfig config) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_ownKey(uid), jsonEncode(config.toJson()));
    } catch (_) {}
  }

  static Future<ChatAvatarConfig> loadPeer(String uid, String peerId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_peerKey(uid, peerId));
      if (raw != null && raw.isNotEmpty) {
        final decoded = jsonDecode(raw);
        if (decoded is Map) return fromJson(decoded);
      }
    } catch (_) {}
    return femaleDefault;
  }

  static Future<void> savePeer(String uid, String peerId, ChatAvatarConfig config) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_peerKey(uid, peerId), jsonEncode(config.toJson()));
    } catch (_) {}
  }
}

/// Renders the custom cartoon Bitmoji-style character natively with crisp vector
/// shapes, optional peeking hands gripping the composer bar, and live expressions.
class ChatBitmojiAvatar extends StatelessWidget {
  const ChatBitmojiAvatar({
    required this.config,
    this.size = 76,
    this.activity = ChatAvatarActivity.present,
    this.blinking = false,
    this.showPeekingHands = true,
    super.key,
  });

  final ChatAvatarConfig config;
  final double size;
  final ChatAvatarActivity activity;
  final bool blinking;
  final bool showPeekingHands;

  @override
  Widget build(BuildContext context) => SizedBox(
        width: size,
        height: size,
        child: CustomPaint(
          painter: _BitmojiPainter(
            config: config,
            activity: activity,
            blinking: blinking,
            showPeekingHands: showPeekingHands,
          ),
        ),
      );
}

class _BitmojiPainter extends CustomPainter {
  _BitmojiPainter({
    required this.config,
    required this.activity,
    required this.blinking,
    required this.showPeekingHands,
  });

  final ChatAvatarConfig config;
  final ChatAvatarActivity activity;
  final bool blinking;
  final bool showPeekingHands;

  Color _darken(Color c, double amount) {
    final hsl = HSLColor.fromColor(c);
    return hsl.withLightness((hsl.lightness - amount).clamp(0.0, 1.0)).toColor();
  }

  Color _lighten(Color c, double amount) {
    final hsl = HSLColor.fromColor(c);
    return hsl.withLightness((hsl.lightness + amount).clamp(0.0, 1.0)).toColor();
  }

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final cx = w * 0.50;
    final headCy = h * 0.45;
    final headRx = w * 0.255;
    final headRy = h * 0.275;

    final skin = ChatAvatarConfig.skinTones[config.skinIndex];
    final skinShadow = _darken(skin, 0.09);
    final hair = ChatAvatarConfig.hairColors[config.hairColor];
    final hairLight = _lighten(hair, 0.12);
    final outfit = ChatAvatarConfig.outfitColors[config.outfitColor];
    final outfitDark = _darken(outfit, 0.14);
    final outfitLight = _lighten(outfit, 0.12);
    final isFemale = config.gender == 'female';

    // 1. Back hair layer (behind head & shoulders for long/bob/ponytail/buns)
    _paintBackHair(canvas, w, h, cx, headCy, headRx, headRy, hair);

    // 2. Shoulders & chosen outfit
    _paintOutfit(canvas, w, h, cx, headCy, headRx, headRy, skin, skinShadow, outfit, outfitDark, outfitLight);

    // 3. Neck
    final neckRect = RRect.fromRectAndRadius(
      Rect.fromCenter(center: Offset(cx, headCy + headRy * 0.98), width: headRx * 0.62, height: headRy * 0.56),
      Radius.circular(headRx * 0.25),
    );
    canvas.drawRRect(neckRect, Paint()..color = skinShadow);

    // 4. Ears
    final earPaint = Paint()..color = skin;
    final earInner = Paint()..color = skinShadow.withValues(alpha: .55);
    for (final side in const [-1.0, 1.0]) {
      final ex = cx + side * headRx * 0.96;
      final ey = headCy + headRy * 0.06;
      canvas.drawOval(Rect.fromCenter(center: Offset(ex, ey), width: headRx * 0.28, height: headRy * 0.36), earPaint);
      canvas.drawOval(Rect.fromCenter(center: Offset(ex - side * 1.2, ey), width: headRx * 0.12, height: headRy * 0.18), earInner);
    }

    // 5. Headphones band (if accessory == 4, behind/over crown)
    if (config.accessory == 4) {
      final bandPaint = Paint()
        ..color = const Color(0xFF1F2937)
        ..style = PaintingStyle.stroke
        ..strokeWidth = w * 0.055
        ..strokeCap = StrokeCap.round;
      canvas.drawArc(
        Rect.fromCenter(center: Offset(cx, headCy - headRy * 0.05), width: headRx * 2.26, height: headRy * 2.15),
        pi,
        pi,
        false,
        bandPaint,
      );
    }

    // 6. Head oval with subtle rim shadow
    final headRect = Rect.fromCenter(center: Offset(cx, headCy), width: headRx * 2, height: headRy * 2);
    canvas.drawOval(headRect, Paint()..color = skin);
    canvas.drawOval(
      headRect,
      Paint()
        ..color = skinShadow.withValues(alpha: .28)
        ..style = PaintingStyle.stroke
        ..strokeWidth = w * 0.014,
    );

    // Soft blush cheeks
    final blushPaint = Paint()..color = const Color(0xFFF472B6).withValues(alpha: isFemale ? .24 : .12);
    canvas.drawOval(
      Rect.fromCenter(center: Offset(cx - headRx * 0.52, headCy + headRy * 0.22), width: headRx * 0.34, height: headRy * 0.16),
      blushPaint,
    );
    canvas.drawOval(
      Rect.fromCenter(center: Offset(cx + headRx * 0.52, headCy + headRy * 0.22), width: headRx * 0.34, height: headRy * 0.16),
      blushPaint,
    );

    // 7. Facial hair (for male or custom)
    if (config.facialHair > 0) {
      _paintFacialHair(canvas, cx, headCy, headRx, headRy, hair, config.facialHair);
    }

    // 8. Eyes, eyebrows, nose & live animated mouth expression
    _paintFace(canvas, w, cx, headCy, headRx, headRy, hair, skinShadow, isFemale);

    // 9. Front hair layer
    _paintFrontHair(canvas, w, h, cx, headCy, headRx, headRy, hair, hairLight);

    // 10. Accessories (glasses, shades, cap, headphone cups)
    _paintAccessories(canvas, w, cx, headCy, headRx, headRy, outfit);

    // 11. Peeking hands gripping the bottom edge of the avatar (composer rail!)
    if (showPeekingHands) {
      _paintPeekingHands(canvas, w, h, cx, skin, skinShadow);
    }
  }

  void _paintBackHair(Canvas canvas, double w, double h, double cx, double headCy, double headRx, double headRy, Color hair) {
    final paint = Paint()..color = hair;
    switch (config.hairStyle) {
      case 4: // Long Sleek
        final path = Path()
          ..moveTo(cx - headRx * 1.12, headCy - headRy * 0.25)
          ..quadraticBezierTo(cx - headRx * 1.28, headCy + headRy * 1.25, cx - headRx * 1.04, h * 0.96)
          ..lineTo(cx + headRx * 1.04, h * 0.96)
          ..quadraticBezierTo(cx + headRx * 1.28, headCy + headRy * 1.25, cx + headRx * 1.12, headCy - headRy * 0.25)
          ..close();
        canvas.drawPath(path, paint);
        break;
      case 5: // Ponytail
        canvas.drawOval(
          Rect.fromCenter(center: Offset(cx + headRx * 0.92, headCy + headRy * 0.28), width: headRx * 0.72, height: headRy * 1.22),
          paint,
        );
        canvas.drawCircle(Offset(cx + headRx * 0.72, headCy - headRy * 0.22), headRx * 0.22, Paint()..color = ChatAvatarConfig.outfitColors[config.outfitColor]);
        break;
      case 6: // Cute Bob
        canvas.drawRRect(
          RRect.fromRectAndRadius(
            Rect.fromCenter(center: Offset(cx, headCy + headRy * 0.24), width: headRx * 2.38, height: headRy * 1.72),
            Radius.circular(headRx * 0.75),
          ),
          paint,
        );
        break;
      case 7: // Twin Buns
        canvas.drawCircle(Offset(cx - headRx * 0.92, headCy - headRy * 0.68), headRx * 0.42, paint);
        canvas.drawCircle(Offset(cx + headRx * 0.92, headCy - headRy * 0.68), headRx * 0.42, paint);
        break;
      default:
        break;
    }
  }

  void _paintOutfit(
    Canvas canvas,
    double w,
    double h,
    double cx,
    double headCy,
    double headRx,
    double headRy,
    Color skin,
    Color skinShadow,
    Color outfit,
    Color outfitDark,
    Color outfitLight,
  ) {
    final shoulderTop = headCy + headRy * 1.04;
    final bodyRect = RRect.fromRectAndCorners(
      Rect.fromLTRB(cx - w * 0.36, shoulderTop, cx + w * 0.36, h * 1.04),
      topLeft: Radius.circular(w * 0.26),
      topRight: Radius.circular(w * 0.26),
    );
    canvas.drawRRect(bodyRect, Paint()..color = outfit);

    // Subtle shoulder highlight
    canvas.drawArc(
      Rect.fromLTRB(cx - w * 0.34, shoulderTop + 1, cx + w * 0.34, shoulderTop + h * 0.22),
      pi,
      pi,
      false,
      Paint()
        ..color = outfitLight.withValues(alpha: .35)
        ..style = PaintingStyle.stroke
        ..strokeWidth = w * 0.025,
    );

    switch (config.outfitStyle) {
      case 0: // Hoodie: hood collar + drawstrings
        canvas.drawArc(
          Rect.fromCenter(center: Offset(cx, shoulderTop + h * 0.02), width: w * 0.34, height: h * 0.14),
          0,
          pi,
          false,
          Paint()
            ..color = outfitDark
            ..style = PaintingStyle.stroke
            ..strokeWidth = w * 0.045
            ..strokeCap = StrokeCap.round,
        );
        final stringPaint = Paint()
          ..color = Colors.white.withValues(alpha: .88)
          ..strokeWidth = w * 0.020
          ..strokeCap = StrokeCap.round;
        canvas.drawLine(Offset(cx - w * 0.055, shoulderTop + h * 0.07), Offset(cx - w * 0.055, shoulderTop + h * 0.21), stringPaint);
        canvas.drawLine(Offset(cx + w * 0.055, shoulderTop + h * 0.07), Offset(cx + w * 0.055, shoulderTop + h * 0.19), stringPaint);
        break;
      case 1: // T-Shirt: crew neckline
        canvas.drawArc(
          Rect.fromCenter(center: Offset(cx, shoulderTop), width: w * 0.24, height: h * 0.13),
          0,
          pi,
          false,
          Paint()
            ..color = outfitDark
            ..style = PaintingStyle.stroke
            ..strokeWidth = w * 0.026,
        );
        break;
      case 2: // Polo Collar
        final leftCollar = Path()
          ..moveTo(cx - w * 0.13, shoulderTop)
          ..lineTo(cx, shoulderTop + h * 0.12)
          ..lineTo(cx - w * 0.04, shoulderTop + h * 0.15)
          ..close();
        final rightCollar = Path()
          ..moveTo(cx + w * 0.13, shoulderTop)
          ..lineTo(cx, shoulderTop + h * 0.12)
          ..lineTo(cx + w * 0.04, shoulderTop + h * 0.15)
          ..close();
        canvas.drawPath(leftCollar, Paint()..color = outfitLight);
        canvas.drawPath(rightCollar, Paint()..color = outfitLight);
        canvas.drawCircle(Offset(cx, shoulderTop + h * 0.16), w * 0.014, Paint()..color = Colors.white70);
        break;
      case 3: // Denim/Zip Jacket with inner white tee
        canvas.drawRect(
          Rect.fromCenter(center: Offset(cx, shoulderTop + h * 0.16), width: w * 0.18, height: h * 0.30),
          Paint()..color = Colors.white.withValues(alpha: .92),
        );
        final lapelPaint = Paint()..color = outfitDark;
        canvas.drawRect(Rect.fromLTRB(cx - w * 0.14, shoulderTop + h * 0.02, cx - w * 0.08, h), lapelPaint);
        canvas.drawRect(Rect.fromLTRB(cx + w * 0.08, shoulderTop + h * 0.02, cx + w * 0.14, h), lapelPaint);
        break;
      case 4: // Cozy Sweater: horizontal knit stripes
        final stripe = Paint()
          ..color = Colors.white.withValues(alpha: .28)
          ..strokeWidth = h * 0.035;
        canvas.drawLine(Offset(cx - w * 0.33, shoulderTop + h * 0.13), Offset(cx + w * 0.33, shoulderTop + h * 0.13), stripe);
        canvas.drawLine(Offset(cx - w * 0.35, shoulderTop + h * 0.22), Offset(cx + w * 0.35, shoulderTop + h * 0.22), stripe);
        break;
      case 5: // Kurta: mandarin collar + gold placket & buttons
        canvas.drawRRect(
          RRect.fromRectAndRadius(
            Rect.fromCenter(center: Offset(cx, shoulderTop + h * 0.09), width: w * 0.065, height: h * 0.18),
            Radius.circular(w * 0.02),
          ),
          Paint()..color = outfitDark,
        );
        final gold = Paint()..color = const Color(0xFFFBBF24);
        canvas.drawCircle(Offset(cx, shoulderTop + h * 0.07), w * 0.013, gold);
        canvas.drawCircle(Offset(cx, shoulderTop + h * 0.12), w * 0.013, gold);
        canvas.drawCircle(Offset(cx, shoulderTop + h * 0.17), w * 0.013, gold);
        break;
    }
  }

  void _paintFacialHair(Canvas canvas, double cx, double headCy, double headRx, double headRy, Color hair, int style) {
    if (style == 1) {
      // Light stubble
      canvas.drawArc(
        Rect.fromCenter(center: Offset(cx, headCy + headRy * 0.05), width: headRx * 1.92, height: headRy * 1.88),
        0.15,
        pi - 0.30,
        false,
        Paint()..color = hair.withValues(alpha: .22),
      );
    } else if (style == 2) {
      // Short full beard
      final path = Path()
        ..moveTo(cx - headRx * 0.92, headCy + headRy * 0.14)
        ..quadraticBezierTo(cx - headRx * 0.88, headCy + headRy * 1.06, cx, headCy + headRy * 1.08)
        ..quadraticBezierTo(cx + headRx * 0.88, headCy + headRy * 1.06, cx + headRx * 0.92, headCy + headRy * 0.14)
        ..quadraticBezierTo(cx + headRx * 0.50, headCy + headRy * 0.45, cx, headCy + headRy * 0.40)
        ..quadraticBezierTo(cx - headRx * 0.50, headCy + headRy * 0.45, cx - headRx * 0.92, headCy + headRy * 0.14)
        ..close();
      canvas.drawPath(path, Paint()..color = hair.withValues(alpha: .90));
    } else if (style == 3) {
      // Goatee
      canvas.drawOval(
        Rect.fromCenter(center: Offset(cx, headCy + headRy * 0.72), width: headRx * 0.68, height: headRy * 0.54),
        Paint()..color = hair.withValues(alpha: .88),
      );
    }
  }

  void _paintFace(
    Canvas canvas,
    double w,
    double cx,
    double headCy,
    double headRx,
    double headRy,
    Color hair,
    Color skinShadow,
    bool isFemale,
  ) {
    final eyeY = headCy - headRy * 0.02 + (activity == ChatAvatarActivity.typing ? headRy * 0.06 : 0);
    final eyeOffsetX = headRx * 0.39;
    final eyeRadius = w * 0.036;

    // Eyebrows
    final browPaint = Paint()
      ..color = hair
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * (isFemale ? 0.020 : 0.028)
      ..strokeCap = StrokeCap.round;
    final browLift = activity == ChatAvatarActivity.recording ? -headRy * 0.07 : 0.0;
    for (final side in const [-1.0, 1.0]) {
      final bx = cx + side * eyeOffsetX;
      final by = eyeY - headRy * 0.25 + browLift;
      final path = Path()
        ..moveTo(bx - side * headRx * 0.16, by + headRy * 0.02)
        ..quadraticBezierTo(bx, by - headRy * 0.07, bx + side * headRx * 0.18, by + headRy * 0.04);
      canvas.drawPath(path, browPaint);
    }

    // Eyes (with blink & typing downward gaze!)
    if (blinking) {
      final closedPaint = Paint()
        ..color = const Color(0xFF1F2937)
        ..style = PaintingStyle.stroke
        ..strokeWidth = w * 0.024
        ..strokeCap = StrokeCap.round;
      for (final side in const [-1.0, 1.0]) {
        final ex = cx + side * eyeOffsetX;
        canvas.drawArc(
          Rect.fromCenter(center: Offset(ex, eyeY), width: eyeRadius * 2.3, height: eyeRadius * 1.4),
          0.15,
          pi - 0.30,
          false,
          closedPaint,
        );
      }
    } else {
      final pupilShiftY = activity == ChatAvatarActivity.typing ? eyeRadius * 0.28 : 0.0;
      for (final side in const [-1.0, 1.0]) {
        final ex = cx + side * eyeOffsetX;
        // White sclera
        canvas.drawOval(
          Rect.fromCenter(center: Offset(ex, eyeY), width: eyeRadius * 2.2, height: eyeRadius * 2.1),
          Paint()..color = Colors.white,
        );
        // Dark iris
        canvas.drawCircle(Offset(ex, eyeY + pupilShiftY), eyeRadius * 0.80, Paint()..color = const Color(0xFF18181B));
        // Catchlight sparkle
        canvas.drawCircle(Offset(ex - eyeRadius * 0.28, eyeY - eyeRadius * 0.28 + pupilShiftY), eyeRadius * 0.28, Paint()..color = Colors.white);
        // Subtle lashes for female preset
        if (isFemale) {
          canvas.drawLine(
            Offset(ex + side * eyeRadius * 0.95, eyeY - eyeRadius * 0.45),
            Offset(ex + side * eyeRadius * 1.35, eyeY - eyeRadius * 0.78),
            Paint()
              ..color = const Color(0xFF18181B)
              ..strokeWidth = w * 0.015
              ..strokeCap = StrokeCap.round,
          );
        }
      }
    }

    // Cute minimal nose
    canvas.drawArc(
      Rect.fromCenter(center: Offset(cx, headCy + headRy * 0.16), width: headRx * 0.18, height: headRy * 0.14),
      0.2,
      pi - 0.4,
      false,
      Paint()
        ..color = skinShadow
        ..style = PaintingStyle.stroke
        ..strokeWidth = w * 0.017
        ..strokeCap = StrokeCap.round,
    );

    // Live expression mouth
    final mouthY = headCy + headRy * 0.44;
    if (activity == ChatAvatarActivity.recording) {
      // Speaking / voice-note open oval mouth
      canvas.drawOval(
        Rect.fromCenter(center: Offset(cx, mouthY + headRy * 0.02), width: headRx * 0.34, height: headRy * 0.26),
        Paint()..color = const Color(0xFF991B1B),
      );
      canvas.drawArc(
        Rect.fromCenter(center: Offset(cx, mouthY + headRy * 0.08), width: headRx * 0.22, height: headRy * 0.14),
        0,
        pi,
        true,
        Paint()..color = const Color(0xFFF472B6),
      );
    } else if (activity == ChatAvatarActivity.typing) {
      // Excited open grin while typing
      final smileRect = Rect.fromCenter(center: Offset(cx, mouthY - headRy * 0.02), width: headRx * 0.56, height: headRy * 0.34);
      canvas.drawArc(smileRect, 0, pi, true, Paint()..color = const Color(0xFF991B1B));
      canvas.drawArc(
        Rect.fromCenter(center: Offset(cx, mouthY - headRy * 0.03), width: headRx * 0.46, height: headRy * 0.12),
        0,
        pi,
        true,
        Paint()..color = Colors.white,
      );
    } else {
      // Warm friendly smile
      canvas.drawArc(
        Rect.fromCenter(center: Offset(cx, mouthY - headRy * 0.06), width: headRx * 0.52, height: headRy * 0.30),
        0.18,
        pi - 0.36,
        false,
        Paint()
          ..color = isFemale ? const Color(0xFFBE185D) : const Color(0xFF7C2D12)
          ..style = PaintingStyle.stroke
          ..strokeWidth = w * 0.025
          ..strokeCap = StrokeCap.round,
      );
    }
  }

  void _paintFrontHair(
    Canvas canvas,
    double w,
    double h,
    double cx,
    double headCy,
    double headRx,
    double headRy,
    Color hair,
    Color hairLight,
  ) {
    final paint = Paint()..color = hair;
    final highlight = Paint()
      ..color = hairLight.withValues(alpha: .35)
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * 0.022
      ..strokeCap = StrokeCap.round;

    switch (config.hairStyle) {
      case 0: // Short Fade
        final path = Path()
          ..moveTo(cx - headRx * 0.94, headCy - headRy * 0.25)
          ..quadraticBezierTo(cx - headRx * 0.90, headCy - headRy * 1.15, cx, headCy - headRy * 1.12)
          ..quadraticBezierTo(cx + headRx * 0.90, headCy - headRy * 1.15, cx + headRx * 0.94, headCy - headRy * 0.25)
          ..quadraticBezierTo(cx + headRx * 0.45, headCy - headRy * 0.62, cx, headCy - headRy * 0.58)
          ..quadraticBezierTo(cx - headRx * 0.45, headCy - headRy * 0.62, cx - headRx * 0.94, headCy - headRy * 0.25)
          ..close();
        canvas.drawPath(path, paint);
        break;
      case 1: // Messy Waves
        final path = Path()
          ..moveTo(cx - headRx * 1.02, headCy - headRy * 0.16)
          ..quadraticBezierTo(cx - headRx * 1.08, headCy - headRy * 1.15, cx - headRx * 0.15, headCy - headRy * 1.24)
          ..quadraticBezierTo(cx + headRx * 0.65, headCy - headRy * 1.32, cx + headRx * 1.05, headCy - headRy * 0.55)
          ..quadraticBezierTo(cx + headRx * 1.05, headCy - headRy * 0.16, cx + headRx * 0.88, headCy - headRy * 0.16)
          ..quadraticBezierTo(cx + headRx * 0.45, headCy - headRy * 0.62, cx + headRx * 0.08, headCy - headRy * 0.42)
          ..quadraticBezierTo(cx - headRx * 0.35, headCy - headRy * 0.68, cx - headRx * 0.82, headCy - headRy * 0.36)
          ..close();
        canvas.drawPath(path, paint);
        break;
      case 2: // Curly Top
        for (final offset in [
          Offset(cx - headRx * 0.72, headCy - headRy * 0.68),
          Offset(cx - headRx * 0.38, headCy - headRy * 0.94),
          Offset(cx, headCy - headRy * 1.02),
          Offset(cx + headRx * 0.38, headCy - headRy * 0.94),
          Offset(cx + headRx * 0.72, headCy - headRy * 0.68),
          Offset(cx - headRx * 0.84, headCy - headRy * 0.38),
          Offset(cx + headRx * 0.84, headCy - headRy * 0.38),
        ]) {
          canvas.drawCircle(offset, headRx * 0.34, paint);
        }
        break;
      case 3: // Side Part
        final path = Path()
          ..moveTo(cx - headRx * 0.98, headCy - headRy * 0.14)
          ..quadraticBezierTo(cx - headRx * 1.02, headCy - headRy * 1.18, cx, headCy - headRy * 1.18)
          ..quadraticBezierTo(cx + headRx * 1.06, headCy - headRy * 1.14, cx + headRx * 0.98, headCy - headRy * 0.14)
          ..quadraticBezierTo(cx + headRx * 0.48, headCy - headRy * 0.55, cx - headRx * 0.35, headCy - headRy * 0.76)
          ..quadraticBezierTo(cx - headRx * 0.72, headCy - headRy * 0.52, cx - headRx * 0.98, headCy - headRy * 0.14)
          ..close();
        canvas.drawPath(path, paint);
        break;
      default: // 4..7 (Long Sleek, Ponytail, Cute Bob, Twin Buns) — soft curtain bangs
        final path = Path()
          ..moveTo(cx - headRx * 1.06, headCy - headRy * 0.05)
          ..quadraticBezierTo(cx - headRx * 1.08, headCy - headRy * 1.18, cx, headCy - headRy * 1.18)
          ..quadraticBezierTo(cx + headRx * 1.08, headCy - headRy * 1.18, cx + headRx * 1.06, headCy - headRy * 0.05)
          ..quadraticBezierTo(cx + headRx * 0.62, headCy - headRy * 0.45, cx + headRx * 0.08, headCy - headRy * 0.72)
          ..quadraticBezierTo(cx - headRx * 0.58, headCy - headRy * 0.45, cx - headRx * 1.06, headCy - headRy * 0.05)
          ..close();
        canvas.drawPath(path, paint);
        break;
    }

    // Soft glossy arc on crown
    canvas.drawArc(
      Rect.fromCenter(center: Offset(cx, headCy - headRy * 0.25), width: headRx * 1.35, height: headRy * 1.35),
      -2.3,
      1.1,
      false,
      highlight,
    );
  }

  void _paintAccessories(Canvas canvas, double w, double cx, double headCy, double headRx, double headRy, Color outfit) {
    final eyeY = headCy - headRy * 0.02 + (activity == ChatAvatarActivity.typing ? headRy * 0.06 : 0);
    final eyeOffsetX = headRx * 0.39;

    if (config.accessory == 1 || config.accessory == 2) {
      // Round glasses or dark shades
      final isShades = config.accessory == 2;
      final lensR = headRx * 0.34;
      final framePaint = Paint()
        ..color = const Color(0xFF1E293B)
        ..style = PaintingStyle.stroke
        ..strokeWidth = w * 0.024;
      final lensPaint = Paint()
        ..color = isShades ? const Color(0xE00F172A) : Colors.white.withValues(alpha: .16);
      for (final side in const [-1.0, 1.0]) {
        final rect = Rect.fromCenter(center: Offset(cx + side * eyeOffsetX, eyeY), width: lensR * 2, height: lensR * 1.78);
        canvas.drawOval(rect, lensPaint);
        canvas.drawOval(rect, framePaint);
      }
      canvas.drawLine(
        Offset(cx - eyeOffsetX + lensR, eyeY),
        Offset(cx + eyeOffsetX - lensR, eyeY),
        framePaint,
      );
    } else if (config.accessory == 3) {
      // Baseball cap
      final capColor = _darken(outfit, 0.08);
      canvas.drawArc(
        Rect.fromCenter(center: Offset(cx, headCy - headRy * 0.52), width: headRx * 2.15, height: headRy * 1.48),
        pi,
        pi,
        true,
        Paint()..color = capColor,
      );
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTRB(cx - headRx * 1.05, headCy - headRy * 0.62, cx + headRx * 1.28, headCy - headRy * 0.44),
          Radius.circular(headRx * 0.16),
        ),
        Paint()..color = _darken(capColor, 0.10),
      );
    } else if (config.accessory == 4) {
      // Headphone ear cups
      for (final side in const [-1.0, 1.0]) {
        canvas.drawRRect(
          RRect.fromRectAndRadius(
            Rect.fromCenter(center: Offset(cx + side * headRx * 1.08, headCy + headRy * 0.02), width: headRx * 0.34, height: headRy * 0.66),
            Radius.circular(headRx * 0.16),
          ),
          Paint()..color = outfit,
        );
      }
    }
  }

  void _paintPeekingHands(Canvas canvas, double w, double h, double cx, Color skin, Color skinShadow) {
    final handPaint = Paint()..color = skin;
    final outline = Paint()
      ..color = skinShadow.withValues(alpha: .65)
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * 0.016;
    final handY = h * 0.92;
    for (final side in const [-1.0, 1.0]) {
      final hx = cx + side * w * 0.27;
      final rect = RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(hx, handY), width: w * 0.16, height: h * 0.13),
        Radius.circular(w * 0.07),
      );
      canvas.drawRRect(rect, handPaint);
      canvas.drawRRect(rect, outline);
      // Little finger knuckle marks
      canvas.drawLine(
        Offset(hx - w * 0.025, handY - h * 0.04),
        Offset(hx - w * 0.025, handY + h * 0.02),
        outline,
      );
      canvas.drawLine(
        Offset(hx + w * 0.025, handY - h * 0.04),
        Offset(hx + w * 0.025, handY + h * 0.02),
        outline,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _BitmojiPainter oldDelegate) =>
      oldDelegate.config != config ||
      oldDelegate.activity != activity ||
      oldDelegate.blinking != blinking ||
      oldDelegate.showPeekingHands != showPeekingHands;
}

/// Animated Snapchat-style peeking Bitmoji that rests directly on the top-left
/// edge of the chat composer bar.
class PeekingBitmojiBar extends StatefulWidget {
  const PeekingBitmojiBar({
    required this.config,
    required this.activity,
    required this.peerName,
    this.nudgeEmoji,
    this.onTapWave,
    super.key,
  });

  final ChatAvatarConfig config;
  final ChatAvatarActivity activity;
  final String peerName;
  final String? nudgeEmoji;
  final VoidCallback? onTapWave;

  @override
  State<PeekingBitmojiBar> createState() => _PeekingBitmojiBarState();
}

class _PeekingBitmojiBarState extends State<PeekingBitmojiBar>
    with SingleTickerProviderStateMixin {
  late final AnimationController _anim = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  );
  Timer? _blinkTimer;
  bool _blinking = false;

  @override
  void initState() {
    super.initState();
    LikedinAppearance.reduceMotion.addListener(_syncAnimation);
    _syncAnimation();
    _scheduleBlink();
  }

  void _syncAnimation() {
    if (!mounted) return;
    final active = widget.activity != ChatAvatarActivity.hidden && !LikedinAppearance.reduceMotion.value;
    if (active) {
      _anim.duration = widget.activity == ChatAvatarActivity.present
          ? const Duration(milliseconds: 1800)
          : const Duration(milliseconds: 700);
      if (!_anim.isAnimating) _anim.repeat(reverse: true);
    } else {
      if (_anim.isAnimating) _anim.stop();
      _anim.value = 0;
    }
  }

  void _scheduleBlink() {
    _blinkTimer?.cancel();
    _blinkTimer = Timer.periodic(const Duration(milliseconds: 3600), (_) {
      if (!mounted || widget.activity == ChatAvatarActivity.hidden) return;
      setState(() => _blinking = true);
      Future<void>.delayed(const Duration(milliseconds: 140), () {
        if (mounted) setState(() => _blinking = false);
      });
    });
  }

  @override
  void didUpdateWidget(covariant PeekingBitmojiBar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.activity != widget.activity) {
      _syncAnimation();
    }
  }

  @override
  void dispose() {
    _blinkTimer?.cancel();
    LikedinAppearance.reduceMotion.removeListener(_syncAnimation);
    _anim.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final visible = widget.activity != ChatAvatarActivity.hidden;
    final reduced = LikedinAppearance.reduceMotion.value;
    final dur = reduced ? Duration.zero : const Duration(milliseconds: 280);
    final primary = likedinPrimary(Theme.of(context).brightness);

    return IgnorePointer(
      ignoring: !visible,
      child: AnimatedOpacity(
        opacity: visible ? 1.0 : 0.0,
        duration: dur,
        child: AnimatedSlide(
          offset: visible
              ? (widget.activity == ChatAvatarActivity.present ? const Offset(0, 0.14) : Offset.zero)
              : const Offset(0, 1.0),
          duration: dur,
          curve: Curves.easeOutBack,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              GestureDetector(
                onTap: widget.onTapWave,
                child: Tooltip(
                  message: 'Tap to wave at ${widget.peerName}',
                  child: AnimatedBuilder(
                    animation: _anim,
                    builder: (context, child) {
                      final bounce = widget.activity == ChatAvatarActivity.present
                          ? -2.5 * _anim.value
                          : -6.0 * Curves.easeInOut.transform(_anim.value);
                      return Transform.translate(
                        offset: Offset(0, bounce),
                        child: child,
                      );
                    },
                    child: ChatBitmojiAvatar(
                      config: widget.config,
                      size: 68,
                      activity: widget.activity,
                      blinking: _blinking,
                      showPeekingHands: true,
                    ),
                  ),
                ),
              ),
              if (widget.nudgeEmoji != null)
                Padding(
                  padding: const EdgeInsets.only(left: 2, bottom: 26),
                  child: TweenAnimationBuilder<double>(
                    key: ValueKey('nudge-${widget.nudgeEmoji}'),
                    tween: Tween<double>(begin: 0.5, end: 1.0),
                    duration: reduced ? Duration.zero : const Duration(milliseconds: 240),
                    curve: Curves.easeOutBack,
                    builder: (_, s, child) => Transform.scale(scale: s, child: child),
                    child: GlassPanel(
                      blur: 8,
                      radius: BorderRadius.circular(16),
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      child: Text(widget.nudgeEmoji!, style: const TextStyle(fontSize: 18)),
                    ),
                  ),
                )
              else if (widget.activity == ChatAvatarActivity.typing)
                Padding(
                  padding: const EdgeInsets.only(left: 2, bottom: 24),
                  child: GlassPanel(
                    blur: 8,
                    radius: BorderRadius.circular(16),
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: List.generate(3, (i) {
                        return AnimatedBuilder(
                          animation: _anim,
                          builder: (_, __) {
                            final phase = ((_anim.value * 3 - i) % 1.0).abs();
                            final dy = -3.5 * (1.0 - (phase - 0.5).abs() * 2.0);
                            return Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 2),
                              child: Transform.translate(
                                offset: Offset(0, dy),
                                child: CircleAvatar(radius: 3.2, backgroundColor: primary),
                              ),
                            );
                          },
                        );
                      }),
                    ),
                  ),
                )
              else if (widget.activity == ChatAvatarActivity.recording)
                Padding(
                  padding: const EdgeInsets.only(left: 2, bottom: 24),
                  child: GlassPanel(
                    blur: 8,
                    radius: BorderRadius.circular(16),
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.mic_rounded, size: 15, color: Color(0xFFE5484D)),
                        const SizedBox(width: 5),
                        ...List.generate(4, (i) {
                          return AnimatedBuilder(
                            animation: _anim,
                            builder: (_, __) {
                              final phase = ((_anim.value * 4 - i) % 1.0).abs();
                              final barH = 5.0 + 9.0 * (1.0 - (phase - 0.5).abs() * 2.0);
                              return Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 1.5),
                                child: Container(
                                  width: 2.8,
                                  height: barH,
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFE5484D),
                                    borderRadius: BorderRadius.circular(2),
                                  ),
                                ),
                              );
                            },
                          );
                        }),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Interactive Avatar Studio for customizing your Bitmoji (and optionally your
/// friend's fallback look while their phone is still on an older APK).
class ChatAvatarStudioPage extends StatefulWidget {
  const ChatAvatarStudioPage({
    required this.initialOwn,
    this.initialPeer,
    this.peerName,
    super.key,
  });

  final ChatAvatarConfig initialOwn;
  final ChatAvatarConfig? initialPeer;
  final String? peerName;

  @override
  State<ChatAvatarStudioPage> createState() => _ChatAvatarStudioPageState();
}

class _ChatAvatarStudioPageState extends State<ChatAvatarStudioPage> {
  late ChatAvatarConfig _own = widget.initialOwn;
  late ChatAvatarConfig _peer = widget.initialPeer ?? ChatAvatarConfig.femaleDefault;
  bool _editingPeer = false;
  ChatAvatarActivity _previewActivity = ChatAvatarActivity.present;

  ChatAvatarConfig get _current => _editingPeer ? _peer : _own;

  void _updateCurrent(ChatAvatarConfig next) {
    HapticFeedback.selectionClick();
    setState(() {
      if (_editingPeer) {
        _peer = next;
      } else {
        _own = next;
      }
    });
  }

  void _randomize() {
    final rng = Random();
    final isFemale = rng.nextBool();
    _updateCurrent(ChatAvatarConfig(
      gender: isFemale ? 'female' : 'male',
      skinIndex: rng.nextInt(ChatAvatarConfig.skinTones.length),
      hairStyle: isFemale ? 4 + rng.nextInt(4) : rng.nextInt(4),
      hairColor: rng.nextInt(ChatAvatarConfig.hairColors.length),
      outfitStyle: rng.nextInt(ChatAvatarConfig.outfitNames.length),
      outfitColor: rng.nextInt(ChatAvatarConfig.outfitColors.length),
      accessory: rng.nextInt(ChatAvatarConfig.accessoryNames.length),
      facialHair: isFemale ? 0 : rng.nextInt(ChatAvatarConfig.facialHairNames.length),
    ));
  }

  Widget _swatchRow({
    required String label,
    required List<Color> colors,
    required int selectedIndex,
    required ValueChanged<int> onSelect,
  }) =>
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: List.generate(colors.length, (i) {
              final selected = i == selectedIndex;
              return GestureDetector(
                onTap: () => onSelect(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 160),
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    color: colors[i],
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: selected ? likedinPrimary(Theme.of(context).brightness) : Colors.white24,
                      width: selected ? 3 : 1.5,
                    ),
                  ),
                  child: selected
                      ? Icon(
                          Icons.check_rounded,
                          size: 17,
                          color: colors[i].computeLuminance() > 0.55 ? Colors.black87 : Colors.white,
                        )
                      : null,
                ),
              );
            }),
          ),
        ],
      );

  Widget _choiceRow({
    required String label,
    required List<String> options,
    required int selectedIndex,
    required ValueChanged<int> onSelect,
  }) =>
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 6,
            children: List.generate(options.length, (i) {
              return ChoiceChip(
                label: Text(options[i]),
                selected: i == selectedIndex,
                visualDensity: VisualDensity.compact,
                onSelected: (_) => onSelect(i),
              );
            }),
          ),
        ],
      );

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final hasPeerTab = widget.initialPeer != null;
    final current = _current;

    return AuroraBackdrop(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          title: const Text('Chat Avatar Studio', style: TextStyle(fontWeight: FontWeight.w800)),
          actions: [
            IconButton(
              tooltip: 'Randomize',
              onPressed: _randomize,
              icon: const Icon(Icons.casino_outlined),
            ),
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: FilledButton(
                onPressed: () => Navigator.of(context).pop(
                  (own: _own, peer: _peer),
                ),
                child: const Text('Save'),
              ),
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
          children: [
            if (hasPeerTab) ...[
              SegmentedButton<bool>(
                segments: [
                  const ButtonSegment<bool>(value: false, label: Text('My Bitmoji'), icon: Icon(Icons.person_outline, size: 17)),
                  ButtonSegment<bool>(
                    value: true,
                    label: Text(widget.peerName ?? 'Friend look'),
                    icon: const Icon(Icons.face_outlined, size: 17),
                  ),
                ],
                selected: <bool>{_editingPeer},
                onSelectionChanged: (s) => setState(() => _editingPeer = s.first),
              ),
              const SizedBox(height: 12),
            ],
            // Live Peeking Preview Stage
            GlassPanel(
              radius: BorderRadius.circular(26),
              padding: const EdgeInsets.fromLTRB(16, 18, 16, 14),
              glow: true,
              child: Column(
                children: [
                  SizedBox(
                    height: 122,
                    child: Stack(
                      alignment: Alignment.bottomCenter,
                      clipBehavior: Clip.none,
                      children: [
                        Positioned(
                          left: 0,
                          right: 0,
                          bottom: 0,
                          child: Container(
                            height: 44,
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            decoration: BoxDecoration(
                              color: likedinSurfaceRaised(brightness),
                              borderRadius: BorderRadius.circular(24),
                              border: Border.all(color: likedinOutline(brightness)),
                            ),
                            alignment: Alignment.centerLeft,
                            child: Text(
                              'Message…',
                              style: TextStyle(color: likedinMutedText(brightness), fontSize: 14),
                            ),
                          ),
                        ),
                        Positioned(
                          left: 16,
                          bottom: 34,
                          child: PeekingBitmojiBar(
                            config: current,
                            activity: _previewActivity,
                            peerName: _editingPeer ? (widget.peerName ?? 'Friend') : 'You',
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    children: [
                      ChoiceChip(
                        label: const Text('In chat'),
                        selected: _previewActivity == ChatAvatarActivity.present,
                        visualDensity: VisualDensity.compact,
                        onSelected: (_) => setState(() => _previewActivity = ChatAvatarActivity.present),
                      ),
                      ChoiceChip(
                        label: const Text('Typing'),
                        selected: _previewActivity == ChatAvatarActivity.typing,
                        visualDensity: VisualDensity.compact,
                        onSelected: (_) => setState(() => _previewActivity = ChatAvatarActivity.typing),
                      ),
                      ChoiceChip(
                        label: const Text('Recording'),
                        selected: _previewActivity == ChatAvatarActivity.recording,
                        visualDensity: VisualDensity.compact,
                        onSelected: (_) => setState(() => _previewActivity = ChatAvatarActivity.recording),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            // Starter Presets (Male / Female)
            GlassPanel(
              radius: BorderRadius.circular(22),
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Starter preset', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => _updateCurrent(ChatAvatarConfig.maleDefault.copyWith(
                            skinIndex: current.skinIndex,
                          )),
                          icon: const Icon(Icons.male_rounded, size: 19),
                          label: const Text('Male'),
                          style: OutlinedButton.styleFrom(
                            backgroundColor: current.gender == 'male'
                                ? likedinPrimary(brightness).withValues(alpha: .14)
                                : null,
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => _updateCurrent(ChatAvatarConfig.femaleDefault.copyWith(
                            skinIndex: current.skinIndex,
                          )),
                          icon: const Icon(Icons.female_rounded, size: 19),
                          label: const Text('Female'),
                          style: OutlinedButton.styleFrom(
                            backgroundColor: current.gender == 'female'
                                ? likedinPrimary(brightness).withValues(alpha: .14)
                                : null,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  _swatchRow(
                    label: 'Skin tone',
                    colors: ChatAvatarConfig.skinTones,
                    selectedIndex: current.skinIndex,
                    onSelect: (i) => _updateCurrent(current.copyWith(skinIndex: i)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            // Hair & Face
            GlassPanel(
              radius: BorderRadius.circular(22),
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _choiceRow(
                    label: 'Hairstyle',
                    options: ChatAvatarConfig.hairStyleNames,
                    selectedIndex: current.hairStyle,
                    onSelect: (i) => _updateCurrent(current.copyWith(hairStyle: i)),
                  ),
                  const SizedBox(height: 14),
                  _swatchRow(
                    label: 'Hair color',
                    colors: ChatAvatarConfig.hairColors,
                    selectedIndex: current.hairColor,
                    onSelect: (i) => _updateCurrent(current.copyWith(hairColor: i)),
                  ),
                  if (current.gender == 'male' || current.facialHair > 0) ...[
                    const SizedBox(height: 14),
                    _choiceRow(
                      label: 'Facial hair',
                      options: ChatAvatarConfig.facialHairNames,
                      selectedIndex: current.facialHair,
                      onSelect: (i) => _updateCurrent(current.copyWith(facialHair: i)),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 14),
            // Clothing & Accessories
            GlassPanel(
              radius: BorderRadius.circular(22),
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _choiceRow(
                    label: 'Clothing',
                    options: ChatAvatarConfig.outfitNames,
                    selectedIndex: current.outfitStyle,
                    onSelect: (i) => _updateCurrent(current.copyWith(outfitStyle: i)),
                  ),
                  const SizedBox(height: 14),
                  _swatchRow(
                    label: 'Outfit color',
                    colors: ChatAvatarConfig.outfitColors,
                    selectedIndex: current.outfitColor,
                    onSelect: (i) => _updateCurrent(current.copyWith(outfitColor: i)),
                  ),
                  const SizedBox(height: 14),
                  _choiceRow(
                    label: 'Accessories',
                    options: ChatAvatarConfig.accessoryNames,
                    selectedIndex: current.accessory,
                    onSelect: (i) => _updateCurrent(current.copyWith(accessory: i)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
