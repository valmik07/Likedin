import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../backend/realtime_messaging_service.dart';

/// Client-side End-to-End Encryption (X25519 + HKDF-SHA256 + AES-256-GCM)
/// with automatic fallback to plaintext whenever the peer has not yet updated
/// to a v2.2.0+ build that publishes an X25519 public key.
///
/// Includes a PBKDF2-HMAC-SHA256 + AES-256-GCM recovery passphrase backup so
/// users can restore their private key after reinstalling or switching phones.
class E2eeService {
  E2eeService._();
  static final E2eeService instance = E2eeService._();

  static const String envelopeMarker = '__likedin_e2ee_v1';
  static const String _backupFormat = 'likedin-e2ee-key-backup-v1';
  static const String _storagePrefix = 'likedin_e2ee_v1';
  // 8-byte magic header for encrypted media blobs: "LKE2EE1\0"
  static const List<int> _mediaMagic = <int>[0x4C, 0x4B, 0x45, 0x32, 0x45, 0x45, 0x31, 0x00];

  final FlutterSecureStorage _storage = const FlutterSecureStorage();
  final X25519 _x25519 = X25519();
  final AesGcm _aesGcm = AesGcm.with256bits();
  final Hkdf _hkdf = Hkdf(hmac: Hmac.sha256(), outputLength: 32);

  final ValueNotifier<bool> activeNotifier = ValueNotifier<bool>(false);

  String? _userId;
  String? _peerId;
  List<int>? _privateKeyBytes;
  List<int>? _publicKeyBytes;
  List<int>? _peerPublicKeyBytes;
  SecretKey? _sessionKey;
  String? _safetyFingerprint;
  bool _cloudTableAvailable = true;

  bool get isActive => _sessionKey != null;
  String? get ownPublicKeyBase64 =>
      _publicKeyBytes == null ? null : base64Encode(_publicKeyBytes!);
  String? get safetyFingerprint => _safetyFingerprint;
  bool get cloudBackupSupported => _cloudTableAvailable;

  String _privStorageKey(String uid) => '${_storagePrefix}_priv_$uid';
  String _pubStorageKey(String uid) => '${_storagePrefix}_pub_$uid';
  String _peerPubStorageKey(String uid, String peer) =>
      '${_storagePrefix}_peer_${uid}_$peer';

  static bool isEncryptedEnvelope(String text) =>
      text.startsWith('{"$envelopeMarker":');

  /// Loads or generates this user's X25519 key pair, publishes the public key,
  /// and attempts to fetch the peer's public key to derive the shared secret.
  Future<bool> initialize(
    SupabaseClient client, {
    required String userId,
    required String peerId,
  }) async {
    if (_userId != userId || _peerId != peerId) {
      _userId = userId;
      _peerId = peerId;
      _privateKeyBytes = null;
      _publicKeyBytes = null;
      _peerPublicKeyBytes = null;
      _sessionKey = null;
      _safetyFingerprint = null;
      activeNotifier.value = false;
    }

    await _ensureOwnKeyPair(userId);
    await _publishOwnPublicKey(client, userId);

    // Load any cached peer public key first for instant offline/startup decryption.
    final cachedPeerB64 = await _readSecure(_peerPubStorageKey(userId, peerId));
    if (cachedPeerB64 != null && cachedPeerB64.isNotEmpty) {
      try {
        final bytes = base64Decode(cachedPeerB64);
        if (bytes.length == 32) {
          _peerPublicKeyBytes = bytes;
        }
      } catch (_) {}
    }

    // Fetch latest peer public key from Supabase (if table exists and peer published one).
    final remotePeerB64 = await _fetchPeerPublicKey(client, peerId);
    if (remotePeerB64 != null && remotePeerB64.isNotEmpty) {
      await acceptPeerPublicKey(
        remotePeerB64,
        userId: userId,
        peerId: peerId,
      );
    } else if (_peerPublicKeyBytes != null) {
      await _deriveSessionKey();
    }

    return isActive;
  }

  /// Accepts a peer's 32-byte X25519 public key (from Supabase table or Realtime
  /// broadcast), caches it in secure storage, and derives the shared AES key.
  Future<bool> acceptPeerPublicKey(
    String publicKeyB64, {
    String? userId,
    String? peerId,
  }) async {
    final uid = userId ?? _userId;
    final pid = peerId ?? _peerId;
    if (uid == null || pid == null) return false;
    final List<int> bytes;
    try {
      bytes = base64Decode(publicKeyB64.trim());
    } on FormatException catch (error) {
      debugPrint('Ignoring malformed peer E2EE public key: $error');
      return false;
    }
    if (bytes.length != 32) return false;
    final unchanged = _peerPublicKeyBytes != null &&
        _bytesEqual(_peerPublicKeyBytes!, bytes) &&
        _sessionKey != null;
    if (unchanged) return true;
    // Persist before updating in-memory state so a storage write failure
    // fails closed rather than activating an unpersisted session key.
    await _writeSecure(_peerPubStorageKey(uid, pid), base64Encode(bytes));
    _peerPublicKeyBytes = bytes;
    await _ensureOwnKeyPair(uid);
    await _deriveSessionKey();
    return isActive;
  }

  /// Encrypts [plaintext] into an authenticated AES-256-GCM envelope when E2EE
  /// is active with the peer. Falls back to [plaintext] unchanged when the peer
  /// has not updated to an E2EE-capable build yet.
  Future<String> encryptIfReady(String plaintext) async {
    final key = _sessionKey;
    if (key == null || plaintext.isEmpty) return plaintext;
    // Never double-encrypt an existing envelope.
    if (isEncryptedEnvelope(plaintext)) return plaintext;
    try {
      final nonce = _randomBytes(12);
      final box = await _aesGcm.encrypt(
        utf8.encode(plaintext),
        secretKey: key,
        nonce: nonce,
      );
      return jsonEncode(<String, Object>{
        envelopeMarker: 1,
        'n': base64Encode(box.nonce),
        'c': base64Encode(box.cipherText),
        'm': base64Encode(box.mac.bytes),
      });
    } catch (error) {
      debugPrint('E2EE encryption failed while session is active: $error');
      rethrow;
    }
  }

  /// Decrypts an E2EE envelope back into plaintext. Older unencrypted messages
  /// and media JSON payloads pass through untouched.
  Future<String> decryptIfNeeded(String payload) async {
    if (!isEncryptedEnvelope(payload)) return payload;
    final key = _sessionKey;
    if (key == null) {
      return '🔒 Encrypted message (open Settings → E2EE to sync or restore your key)';
    }
    try {
      final decoded = jsonDecode(payload);
      if (decoded is! Map || decoded[envelopeMarker] != 1) return payload;
      final nonce = base64Decode(decoded['n'].toString());
      final cipherText = base64Decode(decoded['c'].toString());
      final macBytes = base64Decode(decoded['m'].toString());
      final clearBytes = await _aesGcm.decrypt(
        SecretBox(cipherText, nonce: nonce, mac: Mac(macBytes)),
        secretKey: key,
      );
      return utf8.decode(clearBytes);
    } catch (error) {
      debugPrint('E2EE message decryption failed: $error');
      return '🔒 Encrypted message (restore your E2EE recovery key in Settings to read)';
    }
  }

  static bool isEncryptedMediaBytes(Uint8List data) {
    if (data.length < _mediaMagic.length + 12 + 16) return false;
    for (var i = 0; i < _mediaMagic.length; i++) {
      if (data[i] != _mediaMagic[i]) return false;
    }
    return true;
  }

  /// Encrypts raw media bytes with AES-256-GCM when an E2EE session is active
  /// with the peer. Leaves bytes unchanged when the peer has not updated yet
  /// so older app versions remain compatible.
  Future<Uint8List> encryptBytesIfReady(Uint8List plainBytes) async {
    final key = _sessionKey;
    if (key == null || plainBytes.isEmpty || isEncryptedMediaBytes(plainBytes)) {
      return plainBytes;
    }
    final nonce = _randomBytes(12);
    final box = await _aesGcm.encrypt(
      plainBytes,
      secretKey: key,
      nonce: nonce,
    );
    final out = BytesBuilder(copy: false)
      ..add(_mediaMagic)
      ..add(box.nonce)
      ..add(box.cipherText)
      ..add(box.mac.bytes);
    return out.takeBytes();
  }

  /// Decrypts an E2EE media blob back to raw bytes. Legacy unencrypted media
  /// files pass through untouched.
  Future<Uint8List> decryptBytesIfNeeded(Uint8List data) async {
    if (!isEncryptedMediaBytes(data)) return data;
    final key = _sessionKey;
    if (key == null) {
      throw StateError('E2EE session key is unavailable to decrypt this media file.');
    }
    final magicLen = _mediaMagic.length;
    final nonce = data.sublist(magicLen, magicLen + 12);
    final macStart = data.length - 16;
    final cipherText = data.sublist(magicLen + 12, macStart);
    final macBytes = data.sublist(macStart);
    final clear = await _aesGcm.decrypt(
      SecretBox(cipherText, nonce: nonce, mac: Mac(macBytes)),
      secretKey: key,
    );
    return Uint8List.fromList(clear);
  }

  Future<RemoteMessage> decryptMessage(RemoteMessage message) async {
    if (message.deletedForEveryoneAt != null || !isEncryptedEnvelope(message.text)) {
      return message;
    }
    final clear = await decryptIfNeeded(message.text);
    return RemoteMessage(
      id: message.id,
      clientMessageId: message.clientMessageId,
      senderId: message.senderId,
      recipientId: message.recipientId,
      text: clear,
      createdAt: message.createdAt,
      deliveredAt: message.deliveredAt,
      readAt: message.readAt,
      replyToMessageId: message.replyToMessageId,
      editedAt: message.editedAt,
      deletedForEveryoneAt: message.deletedForEveryoneAt,
      deletedMediaPath: message.deletedMediaPath,
    );
  }

  Future<List<RemoteMessage>> decryptMessages(List<RemoteMessage> list) async {
    if (list.isEmpty) return list;
    final hasEncrypted = list.any((m) => m.deletedForEveryoneAt == null && isEncryptedEnvelope(m.text));
    if (!hasEncrypted) return list;
    return Future.wait(list.map(decryptMessage));
  }

  /// Encrypts this device's X25519 private key with [passphrase] (PBKDF2 100k
  /// + AES-256-GCM) and uploads the encrypted blob to `likedin_e2ee_keys`.
  Future<void> backupKeyWithPassphrase(
    SupabaseClient client,
    String passphrase,
  ) async {
    final uid = client.auth.currentUser?.id ?? _userId;
    if (uid == null) throw StateError('Sign in before backing up your E2EE key.');
    if (passphrase.length < 12) {
      throw StateError('Use a recovery passphrase of at least 12 characters.');
    }
    await _ensureOwnKeyPair(uid);
    final priv = _privateKeyBytes;
    final pub = _publicKeyBytes;
    if (priv == null || pub == null) {
      throw StateError('E2EE key pair is not ready yet.');
    }

    final salt = _randomBytes(16);
    final nonce = _randomBytes(12);
    final wrappingKey = await Pbkdf2(
      macAlgorithm: Hmac.sha256(),
      iterations: 100000,
      bits: 256,
    ).deriveKeyFromPassword(password: passphrase, nonce: salt);

    final box = await _aesGcm.encrypt(
      priv,
      secretKey: wrappingKey,
      nonce: nonce,
    );
    final backupEnvelope = jsonEncode(<String, Object>{
      'format': _backupFormat,
      'iterations': 100000,
      'salt': base64Encode(salt),
      'nonce': base64Encode(box.nonce),
      'cipher': base64Encode(box.cipherText),
      'mac': base64Encode(box.mac.bytes),
    });

    await client.from('likedin_e2ee_keys').upsert(
      <String, Object>{
        'user_id': uid,
        'public_key': base64Encode(pub),
        'encrypted_key_backup': backupEnvelope,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      },
      onConflict: 'user_id',
    );
    _cloudTableAvailable = true;
  }

  /// Downloads and decrypts the user's X25519 private key from Supabase using
  /// [passphrase], saves it in secure storage, and re-derives the session key.
  Future<void> restoreKeyWithPassphrase(
    SupabaseClient client,
    String passphrase,
  ) async {
    final uid = client.auth.currentUser?.id ?? _userId;
    if (uid == null) throw StateError('Sign in before restoring your E2EE key.');
    final row = await client
        .from('likedin_e2ee_keys')
        .select('encrypted_key_backup')
        .eq('user_id', uid)
        .maybeSingle();
    final rawBackup = row?['encrypted_key_backup']?.toString();
    if (rawBackup == null || rawBackup.isEmpty) {
      throw StateError('No E2EE key backup was found for this account.');
    }
    final decoded = jsonDecode(rawBackup);
    if (decoded is! Map || decoded['format'] != _backupFormat) {
      throw StateError('The stored E2EE key backup format is unrecognized.');
    }
    final iterations = (decoded['iterations'] as num?)?.toInt() ?? 100000;
    final salt = base64Decode(decoded['salt'].toString());
    final nonce = base64Decode(decoded['nonce'].toString());
    final cipher = base64Decode(decoded['cipher'].toString());
    final mac = base64Decode(decoded['mac'].toString());

    final wrappingKey = await Pbkdf2(
      macAlgorithm: Hmac.sha256(),
      iterations: iterations,
      bits: 256,
    ).deriveKeyFromPassword(password: passphrase, nonce: salt);

    List<int> privBytes;
    try {
      privBytes = await _aesGcm.decrypt(
        SecretBox(cipher, nonce: nonce, mac: Mac(mac)),
        secretKey: wrappingKey,
      );
    } catch (_) {
      throw StateError('Incorrect recovery passphrase. Your E2EE key was not changed.');
    }
    if (privBytes.length != 32) {
      throw StateError('The restored key data is invalid.');
    }

    final restoredPair = await _x25519.newKeyPairFromSeed(privBytes);
    final restoredPub = await restoredPair.extractPublicKey();
    await _writeSecure(_privStorageKey(uid), base64Encode(privBytes));
    await _writeSecure(_pubStorageKey(uid), base64Encode(restoredPub.bytes));
    _privateKeyBytes = privBytes;
    _publicKeyBytes = restoredPub.bytes;
    await _publishOwnPublicKey(client, uid);
    if (_peerPublicKeyBytes != null) {
      await _deriveSessionKey();
    }
  }

  /// Clears in-memory session state on sign-out without destroying stored keys
  /// (which are scoped by user ID in secure storage).
  void resetMemoryState() {
    _userId = null;
    _peerId = null;
    _privateKeyBytes = null;
    _publicKeyBytes = null;
    _peerPublicKeyBytes = null;
    _sessionKey = null;
    _safetyFingerprint = null;
    activeNotifier.value = false;
  }

  Future<void> _ensureOwnKeyPair(String uid) async {
    if (_privateKeyBytes != null && _publicKeyBytes != null) return;
    final savedPriv = await _readSecure(_privStorageKey(uid));
    final savedPub = await _readSecure(_pubStorageKey(uid));
    if (savedPriv != null && savedPriv.isNotEmpty && savedPub != null && savedPub.isNotEmpty) {
      try {
        final priv = base64Decode(savedPriv);
        final pub = base64Decode(savedPub);
        if (priv.length == 32 && pub.length == 32) {
          _privateKeyBytes = priv;
          _publicKeyBytes = pub;
          return;
        }
      } catch (_) {}
    }

    final generated = await _x25519.newKeyPair();
    final extractedPriv = await generated.extractPrivateKeyBytes();
    final extractedPub = await generated.extractPublicKey();
    await _writeSecure(_privStorageKey(uid), base64Encode(extractedPriv));
    await _writeSecure(_pubStorageKey(uid), base64Encode(extractedPub.bytes));
    _privateKeyBytes = extractedPriv;
    _publicKeyBytes = extractedPub.bytes;
  }

  Future<void> _publishOwnPublicKey(SupabaseClient client, String uid) async {
    final pub = _publicKeyBytes;
    if (pub == null) return;
    try {
      await client.from('likedin_e2ee_keys').upsert(
        <String, Object>{
          'user_id': uid,
          'public_key': base64Encode(pub),
          'updated_at': DateTime.now().toUtc().toIso8601String(),
        },
        onConflict: 'user_id',
      );
      _cloudTableAvailable = true;
    } catch (error) {
      // If likedin_e2ee_keys has not been created in Supabase yet, fail softly;
      // live Realtime key exchange still works seamlessly between active devices.
      _cloudTableAvailable = false;
      debugPrint('E2EE cloud key publish skipped (table optional): $error');
    }
  }

  Future<String?> _fetchPeerPublicKey(SupabaseClient client, String peerId) async {
    try {
      final row = await client
          .from('likedin_e2ee_keys')
          .select('public_key')
          .eq('user_id', peerId)
          .maybeSingle();
      _cloudTableAvailable = true;
      return row?['public_key']?.toString();
    } catch (error) {
      debugPrint('E2EE peer key lookup skipped (table optional): $error');
      return null;
    }
  }

  Future<void> _deriveSessionKey() async {
    final priv = _privateKeyBytes;
    final pub = _publicKeyBytes;
    final peerPub = _peerPublicKeyBytes;
    if (priv == null || pub == null || peerPub == null) return;

    final localPair = SimpleKeyPairData(
      priv,
      publicKey: SimplePublicKey(pub, type: KeyPairType.x25519),
      type: KeyPairType.x25519,
    );
    final remotePub = SimplePublicKey(peerPub, type: KeyPairType.x25519);
    final sharedSecret = await _x25519.sharedSecretKey(
      keyPair: localPair,
      remotePublicKey: remotePub,
    );

    // Non-empty salt avoids the empty-HMAC-key bug in cryptography 2.7.0.
    final derived = await _hkdf.deriveKey(
      secretKey: sharedSecret,
      nonce: utf8.encode('likedin-e2ee-v1-salt'),
      info: utf8.encode('likedin-e2ee-v1-aes256gcm'),
    );

    // Build a deterministic 6-group safety fingerprint from sorted public keys.
    final keysSorted = <String>[base64Encode(pub), base64Encode(peerPub)]..sort();
    final digest = await Sha256().hash(utf8.encode(keysSorted.join(':')));
    final hex = digest.bytes
        .take(12)
        .map((b) => b.toRadixString(16).padLeft(2, '0').toUpperCase())
        .join();
    final groups = <String>[
      for (var i = 0; i < hex.length; i += 4) hex.substring(i, i + 4),
    ];

    _sessionKey = derived;
    _safetyFingerprint = groups.join(' ');
    activeNotifier.value = true;
  }

  Future<String?> _readSecure(String key) async {
    try {
      return await _storage.read(key: key);
    } catch (_) {
      return null;
    }
  }

  Future<void> _writeSecure(String key, String value) async {
    await _storage.write(key: key, value: value);
  }

  static List<int> _randomBytes(int length) {
    final rng = Random.secure();
    return List<int>.generate(length, (_) => rng.nextInt(256), growable: false);
  }

  static bool _bytesEqual(List<int> a, List<int> b) {
    if (a.length != b.length) return false;
    var diff = 0;
    for (var i = 0; i < a.length; i++) {
      diff |= a[i] ^ b[i];
    }
    return diff == 0;
  }
}
