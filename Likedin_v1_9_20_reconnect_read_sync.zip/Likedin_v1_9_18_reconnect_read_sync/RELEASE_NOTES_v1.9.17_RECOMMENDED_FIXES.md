# Likedin 1.9.17 - recommended fixes

Static changes only. `flutter analyze` / `flutter test` were NOT run (no Flutter toolchain in the authoring environment).
Run both, then do the two-phone checks at the bottom, before release. No new Supabase migration is required.

## Protect user messages and recordings
1. **Tap-to-stop no longer discards the recording.** Flutter fires `onLongPressCancel` for every plain tap; it used to call `_stopAndSendVoice(discard: true)`. A new `VoiceGestureGuard` only allows cancel to discard when a long-press actually started the recording. `_stopAndSendVoice` is also single-flight (`_stoppingVoice`) so two overlapping stops cannot race on the recorder.
2. **Uncertain sends are reconciled before showing failure.** `sendMessage` now goes through `sendWithReconciliation`: if the RPC throws (or returns an unreadable reply) the row is looked up by `client_message_id`; a committed message counts as success. The original error is rethrown only if nothing was committed or the lookup also fails. When the UI still reports failure it also resyncs quietly, so a message that did commit reappears instead of vanishing.
3. **Delivery-receipt race fixed.** Ids needing delivery/read are snapshotted before the RPC and only those are acknowledged locally; `_handleIncomingMessages` makes up to 3 passes so a message that arrives mid-RPC is acknowledged on the next pass instead of staying at one tick.
4. **Deletion has merge precedence.** `mergeMessageCopies` (lib/utils/message_merge.dart): a delete-for-everyone tombstone always wins; otherwise the later `editedAt` supplies the text; receipts (delivered/read) merge field-by-field so an edit never loses a tick and a stale copy never resurrects deleted text. Server row id/created_at are kept over optimistic ones.

## Keep conversations synchronized
5. **Reactions refresh on resume and reconnect.** The hydrated-reaction set is cleared on app resume and whenever the Realtime channel re-subscribes (`onReconnect`), then messages reload, so reactions missed while offline are refetched.
6. **Offline pagination is resource-safe.** Gap fill moved to `catchUpNewestPages` with a real 20-page cap (the 1.9.15 notes claimed this; the code had no cap). If the cap is hit, only the fresh pages are kept and `_hasOlderMessages` is set so "Load older" fills the gap, rather than showing a window with an unreachable hole.
7. **Redundant send query removed.** The pre-send `SELECT` is gone; the server function is idempotent on `(sender_id, client_message_id)` (unique index + ON CONFLICT), so a retry returns the existing row.

## Polish
8. Short-recording message now reads: "Recording was too short. Record a little longer, then tap the microphone (or release it) to send."
9. Regression tests added (see below). Version bumped to 1.9.17+106.

## New / changed files
- New: `lib/utils/message_merge.dart`, `offline_catch_up.dart`, `send_reconciliation.dart`, `voice_gesture_guard.dart`
- Changed: `lib/ui/chat_page_part.dart`, `lib/backend/realtime_messaging_service.dart`, `lib/main.dart` (imports, version), `pubspec.yaml`
- Tests: `message_merge_test.dart` (deletion/edit precedence, optimistic reconcile, receipt race, reaction hydration), `offline_catch_up_test.dart` (no gap, multi-page gap, 20-page cap, optimistic-only, stuck cursor), `send_reconciliation_test.dart`, `voice_gesture_guard_test.dart`

## Not covered by unit tests - verify on two phones
- Tap mic to start, tap again to stop: the voice message must send (previously discarded). Also hold-to-record, release to send, and slide-left to cancel.
- Put phone B in airplane mode mid-send, restore it: message must appear exactly once on both phones.
- Phone B backgrounded, phone A adds/removes a reaction, B resumes: reaction updates without restarting.
- Phone B offline while A sends 250+ messages, then B reconnects: no gap, no hang; with 2,000+ the chat shows the newest pages and "Load older" works.
- Send a message to B at the instant B is receiving another: both show delivered ticks on A.
- Known unresolved from 1.9.15: Realtime UPDATE payloads possibly omitting long text columns, and `isom`/`mp42` m4a sniffed as video.
