import '../backend/realtime_messaging_service.dart';

/// A single unsent outgoing message persisted locally so it survives chat exits
/// and app restarts, while avoiding Double Ratchet re-encryption on retries and
/// expiring or invalidating stale ciphertext when the ratchet session changes.
class FailedSendEntry {
  const FailedSendEntry({
    required this.id,
    required this.text,
    required this.recipientId,
    required this.createdAtMs,
    this.wireText,
    this.ratchetSessionId,
    this.replyId,
  });

  final String id;
  final String text;
  final String? wireText;
  final String? ratchetSessionId;
  final String recipientId;
  final String? replyId;
  final int createdAtMs;

  bool isExpired(DateTime now, {Duration maxAge = FailedSendQueue.maxRetention}) =>
      now.millisecondsSinceEpoch - createdAtMs > maxAge.inMilliseconds;

  /// Returns the cached encrypted [wireText] ONLY when it is fresh (not expired)
  /// and was encrypted under the exact active [currentRatchetSessionId].
  /// Returns `null` if the session was reset/re-paired or the entry is stale,
  /// signalling the caller to encrypt [text] fresh under the current session.
  String? reusableWireText({
    required String? currentRatchetSessionId,
    DateTime? now,
    Duration maxAge = FailedSendQueue.maxRetention,
  }) {
    final wire = wireText;
    if (wire == null || wire.isEmpty) return null;
    if (isExpired(now ?? DateTime.now(), maxAge: maxAge)) return null;
    if (ratchetSessionId == null ||
        currentRatchetSessionId == null ||
        ratchetSessionId != currentRatchetSessionId) {
      return null;
    }
    return wire;
  }

  Map<String, Object?> toJson() => <String, Object?>{
        'id': id,
        'text': text,
        'wireText': wireText,
        'ratchetSessionId': ratchetSessionId,
        'recipientId': recipientId,
        'replyId': replyId,
        'createdAtMs': createdAtMs,
      };

  static FailedSendEntry? fromJson(Map<dynamic, dynamic> raw, {DateTime? now}) {
    final id = raw['id']?.toString() ?? '';
    final text = raw['text']?.toString() ?? '';
    final recipientId = raw['recipientId']?.toString() ?? '';
    if (id.isEmpty || text.isEmpty || recipientId.isEmpty) return null;
    final wire = raw['wireText']?.toString();
    final sid = raw['ratchetSessionId']?.toString();
    final replyId = raw['replyId']?.toString();
    final createdAtMs = (raw['createdAtMs'] as num?)?.toInt() ??
        (now ?? DateTime.now()).millisecondsSinceEpoch;
    return FailedSendEntry(
      id: id,
      text: text,
      wireText: (wire == null || wire.isEmpty) ? null : wire,
      ratchetSessionId: (sid == null || sid.isEmpty) ? null : sid,
      recipientId: recipientId,
      replyId: (replyId == null || replyId.isEmpty) ? null : replyId,
      createdAtMs: createdAtMs,
    );
  }
}

/// Pure-Dart queue managing persisted failed outgoing sends: serialization,
/// 7-day TTL expiration, session-aware ciphertext reuse, server-confirmed
/// pruning, and chronological timeline rehydration.
class FailedSendQueue {
  static const Duration maxRetention = Duration(days: 7);

  final Map<String, FailedSendEntry> _entries = <String, FailedSendEntry>{};

  bool get isEmpty => _entries.isEmpty;
  bool get isNotEmpty => _entries.isNotEmpty;
  int get length => _entries.length;
  bool containsId(String id) => _entries.containsKey(id);
  FailedSendEntry? operator [](String id) => _entries[id];
  Iterable<FailedSendEntry> get values => _entries.values;

  void upsert(FailedSendEntry entry) {
    _entries[entry.id] = entry;
  }

  FailedSendEntry? remove(String id) => _entries.remove(id);

  void clear() => _entries.clear();

  /// Drops any failed sends older than [maxAge]. Returns `true` if any entry
  /// was expired and removed.
  bool pruneExpired({DateTime? now, Duration maxAge = maxRetention}) {
    if (_entries.isEmpty) return false;
    final clock = now ?? DateTime.now();
    final before = _entries.length;
    _entries.removeWhere((_, entry) => entry.isExpired(clock, maxAge: maxAge));
    return _entries.length != before;
  }

  /// Removes failed entries whose `clientMessageId` has already been persisted
  /// on the server (`id != clientMessageId`). Returns `true` if modified.
  bool prunePersisted(Iterable<RemoteMessage> timeline) {
    if (_entries.isEmpty) return false;
    final persistedClientIds = timeline
        .where((m) => m.clientMessageId != null && m.id != m.clientMessageId)
        .map((m) => m.clientMessageId!)
        .toSet();
    if (persistedClientIds.isEmpty) return false;
    final before = _entries.length;
    _entries.removeWhere((id, _) => persistedClientIds.contains(id));
    return _entries.length != before;
  }

  /// Loads persisted JSON entries, dropping expired items (> 7 days old).
  /// Returns `true` if expired entries were dropped during load.
  bool loadFromJson(
    List<dynamic> rawList, {
    required bool merge,
    DateTime? now,
    Duration maxAge = maxRetention,
  }) {
    final clock = now ?? DateTime.now();
    var droppedExpired = false;
    final parsed = <String, FailedSendEntry>{};
    for (final item in rawList.whereType<Map>()) {
      final entry = FailedSendEntry.fromJson(item, now: clock);
      if (entry == null) continue;
      if (entry.isExpired(clock, maxAge: maxAge)) {
        droppedExpired = true;
        continue;
      }
      parsed[entry.id] = entry;
    }
    if (!merge) {
      _entries
        ..clear()
        ..addAll(parsed);
    } else {
      for (final e in parsed.entries) {
        _entries.putIfAbsent(e.key, () => e.value);
      }
      droppedExpired = pruneExpired(now: clock, maxAge: maxAge) || droppedExpired;
    }
    return droppedExpired;
  }

  List<Map<String, Object?>> toJsonList({
    DateTime? now,
    Duration maxAge = maxRetention,
  }) {
    pruneExpired(now: now, maxAge: maxAge);
    return _entries.values.map((e) => e.toJson()).toList(growable: false);
  }

  /// Rehydrates non-expired failed sends into [timeline] without duplicating
  /// existing rows by `id` or `clientMessageId`, keeping chronological order.
  /// Returns `true` if any expired entries were pruned or rows added.
  bool rehydrateInto(
    List<RemoteMessage> timeline, {
    required String currentUserId,
    DateTime? now,
    Duration maxAge = maxRetention,
  }) {
    final expiredPruned = pruneExpired(now: now, maxAge: maxAge);
    if (_entries.isEmpty) return expiredPruned;

    final existingIds = <String>{
      for (final m in timeline) m.id,
      for (final m in timeline)
        if (m.clientMessageId != null) m.clientMessageId!,
    };
    var added = false;
    for (final entry in _entries.values) {
      if (existingIds.contains(entry.id)) continue;
      timeline.add(
        RemoteMessage(
          id: entry.id,
          clientMessageId: entry.id,
          senderId: currentUserId,
          recipientId: entry.recipientId,
          text: entry.text,
          createdAt: DateTime.fromMillisecondsSinceEpoch(entry.createdAtMs),
          replyToMessageId: entry.replyId,
        ),
      );
      added = true;
    }
    if (added) {
      timeline.sort((a, b) {
        final byTime = a.createdAt.compareTo(b.createdAt);
        return byTime != 0 ? byTime : a.id.compareTo(b.id);
      });
    }
    return expiredPruned || added;
  }
}
