import 'package:flutter/material.dart';

/// Constraint- and width-aware layout metrics for Likedin.
///
/// Uses [MediaQuery.sizeOf] so widgets only rebuild when actual window
/// dimensions change (never on keyboard insets or theme updates), scaling
/// cleanly from 720p phones like Vivo Y12 (360dp native / ~320dp zoomed)
/// through modern 1080p phones (393–420dp) and landscape screens.
class LikedinResponsive {
  const LikedinResponsive._(this.size);

  factory LikedinResponsive.of(BuildContext context) =>
      LikedinResponsive._(MediaQuery.sizeOf(context));

  factory LikedinResponsive.fromSize(Size size) => LikedinResponsive._(size);

  final Size size;

  double get width => size.width;
  double get height => size.height;
  double get shortestSide => size.shortestSide;

  /// True on ~320dp viewports (e.g., 720p Vivo Y12 with Display Size set to Large).
  bool get isUltraCompact => width < 345.0;

  /// True on compact 720p phones (e.g., Vivo Y12 native 360dp width).
  bool get isCompact => width < 380.0;

  bool get isWide => width >= 600.0;
  bool get isLandscape => width > height;

  /// Subtle automatic font scale multiplier so 720p / ~268 PPI displays
  /// (320–360dp logical width) render with the same visual balance as 1080p
  /// phones (393–412dp) while preserving the user's in-app Text Size control.
  double get autoTextScale {
    if (width <= 340.0) return 0.88;
    if (width <= 375.0) return 0.93;
    if (width <= 430.0) return 1.00;
    return 1.04;
  }

  /// Combines the automatic screen-width multiplier with the user's chosen
  /// in-app text scale (`0.85–1.20`), clamped to a safe readable range.
  double effectiveTextScale(double userScale) =>
      (userScale * autoTextScale).clamp(0.78, 1.30).toDouble();

  /// Chat bubble max width (~78% on compact 720p screens, ~74% on standard,
  /// capped at 420dp on wide/landscape screens).
  double get bubbleMaxWidth =>
      (width * (isCompact ? 0.78 : 0.74)).clamp(220.0, 420.0).toDouble();

  /// Single photo / video preview width inside a chat bubble.
  double get mediaWidth =>
      (width * (isCompact ? 0.64 : 0.68)).clamp(196.0, 320.0).toDouble();

  /// Single photo / video preview height proportional to [mediaWidth].
  double get mediaHeight =>
      (mediaWidth * 0.64).clamp(132.0, 210.0).toDouble();

  /// Maximum decoded image height inside a chat bubble.
  double get mediaMaxHeight =>
      (height * 0.42).clamp(220.0, 360.0).toDouble();

  /// Photo album grid width inside a chat bubble.
  double get albumWidth =>
      (width * (isCompact ? 0.62 : 0.66)).clamp(192.0, 300.0).toDouble();

  /// Chat header dimensions so contact names have generous room on 320–360dp phones.
  double get chatHeaderAvatarRadius =>
      isUltraCompact ? 16.0 : (isCompact ? 18.0 : 20.0);

  double get chatHeaderIconSize =>
      isUltraCompact ? 20.0 : (isCompact ? 21.0 : 23.0);

  double get chatHeaderNameSize =>
      isUltraCompact ? 15.5 : (isCompact ? 16.0 : 17.0);

  VisualDensity get chatHeaderDensity =>
      isCompact ? VisualDensity.compact : VisualDensity.standard;

  /// Left (+) and right (Mic / Send) circular composer button diameter.
  double get composerButtonSize =>
      isUltraCompact ? 38.0 : (isCompact ? 41.0 : 44.0);

  /// Video call floating self-preview width & height (never crowds top pill on 320–360dp).
  double get callSelfPreviewWidth =>
      (width * 0.24).clamp(76.0, 114.0).toDouble();

  double get callSelfPreviewHeight =>
      (callSelfPreviewWidth * 1.36).clamp(104.0, 156.0).toDouble();

  /// Audio call halo avatar diameter.
  double get callAvatarSize =>
      (shortestSide * 0.31).clamp(92.0, 134.0).toDouble();

  /// Maximum width of Origin Island status pill so it never clips on 320dp screens.
  double get originIslandMaxWidth =>
      (width - 28.0).clamp(220.0, 360.0).toDouble();

  /// Adaptive grid tile max extents (replaces hardcoded crossAxisCount).
  double get mediaGridMaxExtent => isUltraCompact ? 112.0 : 128.0;
  double get emojiGridMaxExtent => isUltraCompact ? 42.0 : 46.0;
  double get stickerGridMaxExtent => isUltraCompact ? 76.0 : 88.0;
  double get featuredEmojiMaxExtent => isUltraCompact ? 78.0 : 92.0;

  SliverGridDelegateWithMaxCrossAxisExtent adaptiveGridDelegate({
    required double maxExtent,
    double spacing = 8.0,
    double childAspectRatio = 1.0,
  }) =>
      SliverGridDelegateWithMaxCrossAxisExtent(
        maxCrossAxisExtent: maxExtent,
        crossAxisSpacing: spacing,
        mainAxisSpacing: spacing,
        childAspectRatio: childAspectRatio,
      );
}
