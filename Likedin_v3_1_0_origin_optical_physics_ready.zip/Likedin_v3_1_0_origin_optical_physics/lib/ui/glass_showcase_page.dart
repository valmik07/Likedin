import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../motion/origin_motion.dart';
import 'glassmorphism.dart';
import 'origin_optical_glass.dart';

enum _ShowcaseBg {
  vivoBluePetals('Vivo Blue'),
  solidDark('Solid Dark'),
  solidLight('Solid Light'),
  brightPhoto('Bright Photo'),
  darkPhoto('Dark Photo'),
  highContrast('High Contrast'),
  textAndIcons('Text & Icons'),
  overlapping('Overlapping');

  const _ShowcaseBg(this.label);
  final String label;
}

class GlassShowcasePage extends StatefulWidget {
  const GlassShowcasePage({super.key});

  @override
  State<GlassShowcasePage> createState() => _GlassShowcasePageState();
}

class _GlassShowcasePageState extends State<GlassShowcasePage> {
  _ShowcaseBg _bg = _ShowcaseBg.vivoBluePetals;
  bool _simulateLowRam = false;
  bool _simulateReduceMotion = false;
  bool _darkGlassText = false;

  @override
  void initState() {
    super.initState();
    OriginGlassShaderEngine.preload();
  }

  Widget _buildBackground() {
    switch (_bg) {
      case _ShowcaseBg.vivoBluePetals:
        return CustomPaint(
          painter: _VivoBotanicalPainter(),
          child: const SizedBox.expand(),
        );
      case _ShowcaseBg.solidDark:
        return const ColoredBox(color: Color(0xFF0A101E));
      case _ShowcaseBg.solidLight:
        return const ColoredBox(color: Color(0xFFEAF1FB));
      case _ShowcaseBg.brightPhoto:
        return DecoratedBox(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFFFFF1C1),
                Color(0xFF7DD3FC),
                Color(0xFF38BDF8),
                Color(0xFFFDE68A),
              ],
            ),
          ),
          child: CustomPaint(painter: _SunburstShapesPainter()),
        );
      case _ShowcaseBg.darkPhoto:
        return DecoratedBox(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color(0xFF050816),
                Color(0xFF10204A),
                Color(0xFF1E1B4B),
                Color(0xFF090D1F),
              ],
            ),
          ),
          child: CustomPaint(painter: _NightOrbsPainter()),
        );
      case _ShowcaseBg.highContrast:
        return CustomPaint(
          painter: _HighContrastGridPainter(),
          child: const SizedBox.expand(),
        );
      case _ShowcaseBg.textAndIcons:
        return ColoredBox(
          color: const Color(0xFF0F1B33),
          child: GridView.builder(
            physics: const NeverScrollableScrollPhysics(),
            padding: const EdgeInsets.all(10),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
            ),
            itemCount: 48,
            itemBuilder: (_, i) {
              const icons = [
                Icons.chat_bubble_rounded,
                Icons.lock_rounded,
                Icons.videocam_rounded,
                Icons.photo_rounded,
                Icons.bolt_rounded,
                Icons.auto_awesome_rounded,
              ];
              return Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    icons[i % icons.length],
                    color: i.isEven ? const Color(0xFF38BDF8) : const Color(0xFFF472B6),
                    size: 26,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'OPTIC ${i + 1}',
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              );
            },
          ),
        );
      case _ShowcaseBg.overlapping:
        return CustomPaint(
          painter: _VivoBotanicalPainter(),
          child: const SizedBox.expand(),
        );
    }
  }

  Widget _buildComparisonPill({
    required LikedinEffects tier,
    required String title,
    required String subtitle,
  }) {
    final fg = _darkGlassText ? const Color(0xFF0C1A33) : Colors.white;
    final subFg = _darkGlassText ? const Color(0xFF334155) : Colors.white.withValues(alpha: .82);
    final profile = OriginGlassMaterialProfile.resolve(
      tierName: tier.name,
      lowRamDevice: _simulateLowRam,
      reduceMotion: _simulateReduceMotion,
    );

    return GlassPanel(
      frosted: true,
      glow: tier == LikedinEffects.real,
      radius: BorderRadius.circular(36),
      effectsOverride: tier,
      lowRamOverride: _simulateLowRam,
      reduceMotionOverride: _simulateReduceMotion,
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: fg.withValues(alpha: .85), width: 3.2),
            ),
            child: Icon(Icons.smartphone_rounded, color: fg, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: fg,
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  '$subtitle · refr ${profile.refractionPx.toStringAsFixed(1)}px · frost ${profile.frostRadiusPx.toStringAsFixed(1)}px',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: subFg,
                    fontSize: 11.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          Text(
            '75%',
            style: TextStyle(
              color: fg,
              fontSize: 20,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final shaderReady = OriginGlassShaderEngine.isReady;
    final shaderSupported = OriginGlassShaderEngine.isSupported;

    return Scaffold(
      appBar: AppBar(
        title: const Text('OriginOS 7 Glass Showcase'),
        actions: [
          IconButton(
            tooltip: _darkGlassText ? 'Switch text to white' : 'Switch text to dark',
            onPressed: () => setState(() => _darkGlassText = !_darkGlassText),
            icon: Icon(_darkGlassText ? Icons.dark_mode_outlined : Icons.light_mode_outlined),
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
            color: Theme.of(context).colorScheme.surface,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: _ShowcaseBg.values.map((bg) {
                      final selected = bg == _bg;
                      return Padding(
                        padding: const EdgeInsets.only(right: 6),
                        child: ChoiceChip(
                          label: Text(bg.label, style: const TextStyle(fontSize: 12)),
                          selected: selected,
                          onSelected: (_) {
                            OriginHaptics.selection();
                            setState(() => _bg = bg);
                          },
                        ),
                      );
                    }).toList(growable: false),
                  ),
                ),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 12,
                  runSpacing: 4,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text('3 GB Fallback', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                        const SizedBox(width: 6),
                        OriginSpringToggle(
                          value: _simulateLowRam,
                          semanticLabel: 'Simulate 3 GB low RAM device',
                          onChanged: (v) => setState(() => _simulateLowRam = v),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text('Reduce Motion', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                        const SizedBox(width: 6),
                        OriginSpringToggle(
                          value: _simulateReduceMotion,
                          semanticLabel: 'Simulate reduce motion',
                          onChanged: (v) => setState(() => _simulateReduceMotion = v),
                        ),
                      ],
                    ),
                    Chip(
                      visualDensity: VisualDensity.compact,
                      label: Text(
                        shaderReady
                            ? 'GPU Shader: Active'
                            : (shaderSupported ? 'GPU Shader: Loading' : 'Fallback: Canvas/Blur'),
                        style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: BackdropGroup(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  _buildBackground(),
                  if (_bg == _ShowcaseBg.overlapping)
                    Center(
                      child: SizedBox(
                        width: 320,
                        height: 360,
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            Positioned(
                              top: 0,
                              left: 0,
                              right: 36,
                              child: _buildComparisonPill(
                                tier: LikedinEffects.soft,
                                title: 'Soft (柔和) Base',
                                subtitle: 'Background glass',
                              ),
                            ),
                            Positioned(
                              top: 62,
                              left: 24,
                              right: 12,
                              child: _buildComparisonPill(
                                tier: LikedinEffects.natural,
                                title: 'Natural (自然) Mid',
                                subtitle: 'Overlapping glass',
                              ),
                            ),
                            Positioned(
                              top: 126,
                              left: 8,
                              right: 20,
                              child: _buildComparisonPill(
                                tier: LikedinEffects.real,
                                title: 'Real (真实) Top',
                                subtitle: 'Refractive glass',
                              ),
                            ),
                            Positioned(
                              top: 214,
                              left: 16,
                              right: 16,
                              child: _buildComparisonPill(
                                tier: LikedinEffects.off,
                                title: 'Off (Solid)',
                                subtitle: 'Opaque control',
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  else
                    ListView(
                      padding: const EdgeInsets.fromLTRB(18, 22, 18, 28),
                      children: [
                        _buildComparisonPill(
                          tier: LikedinEffects.real,
                          title: 'Real · 真实',
                          subtitle: 'Crystal refractive',
                        ),
                        const SizedBox(height: 16),
                        _buildComparisonPill(
                          tier: LikedinEffects.natural,
                          title: 'Natural · 自然',
                          subtitle: 'Balanced optical',
                        ),
                        const SizedBox(height: 16),
                        _buildComparisonPill(
                          tier: LikedinEffects.soft,
                          title: 'Soft · 柔和',
                          subtitle: 'Deep satin frost',
                        ),
                        const SizedBox(height: 16),
                        _buildComparisonPill(
                          tier: LikedinEffects.off,
                          title: 'Off · Solid',
                          subtitle: 'High-contrast flat',
                        ),
                      ],
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _VivoBotanicalPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF0A2E5C), Color(0xFF2162A6), Color(0xFF0A4396)],
        ).createShader(rect),
    );
    final petals = [
      (Offset(size.width * 0.25, size.height * 0.36), size.width * 0.38, const Color(0xFF0EA5E9)),
      (Offset(size.width * 0.72, size.height * 0.42), size.width * 0.42, const Color(0xFF2563EB)),
      (Offset(size.width * 0.48, size.height * 0.68), size.width * 0.45, const Color(0xFF1D4ED8)),
      (Offset(size.width * 0.56, size.height * 0.22), size.width * 0.16, const Color(0xFF061630)),
    ];
    for (final (center, radius, color) in petals) {
      canvas.drawCircle(
        center,
        radius,
        Paint()
          ..shader = RadialGradient(
            colors: [
              color.withValues(alpha: .95),
              color.withValues(alpha: .35),
              color.withValues(alpha: 0.0),
            ],
          ).createShader(Rect.fromCircle(center: center, radius: radius)),
      );
    }
    final stemPaint = Paint()
      ..color = const Color(0xFF061938)
      ..strokeWidth = 5.0
      ..style = PaintingStyle.stroke;
    final stem = Path()
      ..moveTo(size.width * 0.55, size.height)
      ..quadraticBezierTo(size.width * 0.62, size.height * 0.50, size.width * 0.54, size.height * 0.16);
    canvas.drawPath(stem, stemPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _HighContrastGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    const cell = 36.0;
    final dark = Paint()..color = const Color(0xFF090D16);
    final light = Paint()..color = const Color(0xFFF8FAFC);
    final cols = (size.width / cell).ceil();
    final rows = (size.height / cell).ceil();
    for (var r = 0; r < rows; r++) {
      for (var c = 0; c < cols; c++) {
        canvas.drawRect(
          Rect.fromLTWH(c * cell, r * cell, cell, cell),
          (r + c).isEven ? dark : light,
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _SunburstShapesPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p1 = Paint()..color = Colors.white.withValues(alpha: .55);
    final p2 = Paint()..color = const Color(0xFFFB7185).withValues(alpha: .45);
    canvas.drawCircle(Offset(size.width * 0.22, size.height * 0.25), 95, p1);
    canvas.drawCircle(Offset(size.width * 0.78, size.height * 0.58), 115, p2);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _NightOrbsPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p1 = Paint()..color = const Color(0xFF38BDF8).withValues(alpha: .40);
    final p2 = Paint()..color = const Color(0xFFA855F7).withValues(alpha: .40);
    for (var i = 0; i < 6; i++) {
      final angle = i * math.pi / 3;
      final c = Offset(
        size.width * 0.5 + math.cos(angle) * size.width * 0.28,
        size.height * 0.45 + math.sin(angle) * size.height * 0.24,
      );
      canvas.drawCircle(c, 58, i.isEven ? p1 : p2);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
