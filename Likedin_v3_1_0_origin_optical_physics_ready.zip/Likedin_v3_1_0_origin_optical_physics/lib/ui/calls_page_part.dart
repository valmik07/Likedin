part of '../main.dart';

class CallsPage extends StatefulWidget {
  const CallsPage({super.key});
  @override
  State<CallsPage> createState() => _CallsPageState();
}

class _CallsPageState extends State<CallsPage> {
  Future<List<Map<String, dynamic>>>? _history;
  List<Map<String, dynamic>>? _lastHistory;
  static int _historyChannelGen = 0;
  RealtimeChannel? _channel;
  String _filter = 'All';

  @override
  void initState() {
    super.initState();
    _load();
    _subscribe();
  }

  void _load() {
    _history = _fetch();
  }

  Future<List<Map<String, dynamic>>> _fetch() async {
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (uid == null) return _lastHistory ?? const <Map<String, dynamic>>[];
    final rows = await Supabase.instance.client
        .from('likedin_calls')
        .select()
        .or('caller_id.eq.$uid,callee_id.eq.$uid')
        .order('created_at', ascending: false)
        .limit(100);
    final fetched = rows.map((e) => Map<String, dynamic>.from(e)).toList();
    _lastHistory = fetched;
    return fetched;
  }

  void _subscribe() {
    final client = Supabase.instance.client;
    final uid = client.auth.currentUser?.id;
    if (uid == null) return;
    final gen = ++_historyChannelGen;
    _channel = client
        .channel('likedin-call-history-$uid-$gen')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'likedin_calls',
          callback: (_) {
            if (mounted) setState(_load);
          },
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'likedin_calls',
          callback: (_) {
            if (mounted) setState(_load);
          },
        )
      ..subscribe();
  }

  @override
  void dispose() {
    final c = _channel;
    if (c != null) Supabase.instance.client.removeChannel(c);
    super.dispose();
  }

  String _label(Map<String, dynamic> row, String uid) {
    final outgoing = row['caller_id'] == uid;
    final status = row['status']?.toString() ?? 'ended';
    if (status == 'missed') return outgoing ? 'No answer' : 'Missed call';
    if (status == 'rejected') return outgoing ? 'Declined' : 'You declined';
    if (status == 'failed') return 'Call failed';
    if (status == 'ringing') return 'Ringing';
    if (status == 'accepted' || row['answered_at'] != null) return 'Completed';
    return status == 'ended' ? 'Ended' : status;
  }

  IconData _icon(Map<String, dynamic> row, String uid) {
    if (row['status'] == 'missed' && row['callee_id'] == uid) return Icons.call_missed;
    if (row['caller_id'] == uid) return Icons.call_made;
    return Icons.call_received;
  }

  bool _matchesFilter(Map<String, dynamic> row) {
    switch (_filter) {
      case 'Missed':
        return row['status'] == 'missed';
      case 'Video':
        return row['call_type'] == 'video';
      case 'Audio':
        return row['call_type'] != 'video';
      default:
        return true;
    }
  }

  String _dateLabel(Map<String, dynamic> row) {
    final created = DateTime.tryParse(row['created_at']?.toString() ?? '')?.toLocal();
    if (created == null) return 'Date unavailable';
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final day = DateTime(created.year, created.month, created.day);
    final dayText = day == today
        ? 'Today'
        : day == DateTime(today.year, today.month, today.day - 1)
            ? 'Yesterday'
            : MaterialLocalizations.of(context).formatMediumDate(created);
    final timeText = MaterialLocalizations.of(context).formatTimeOfDay(
      TimeOfDay.fromDateTime(created),
    );
    return '$dayText · $timeText';
  }

  Widget _filterPill(String value, {required Brightness brightness, required Color foreground}) {
    final dark = brightness == Brightness.dark;
    final primary = likedinPrimary(brightness);
    final selected = _filter == value;
    final background = selected
        ? primary.withValues(alpha: dark ? .28 : .16)
        : likedinSurface(brightness).withValues(alpha: dark ? .72 : .80);
    final label = selected ? primary : foreground.withValues(alpha: .86);
    final border = selected
        ? primary.withValues(alpha: dark ? .65 : .48)
        : (dark ? Colors.white.withValues(alpha: .14) : Colors.white.withValues(alpha: .92));

    return Semantics(
      button: true,
      selected: selected,
      label: '$value calls filter',
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(30),
          onTap: () => setState(() => _filter = value),
          child: AnimatedContainer(
            duration: LikedinAppearance.reduceMotion.value
                ? Duration.zero
                : const Duration(milliseconds: 160),
            curve: Curves.easeOut,
            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 9),
            decoration: BoxDecoration(
              color: background,
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: border),
            ),
            child: Text(
              value,
              style: TextStyle(color: label, fontSize: 12, fontWeight: FontWeight.w800),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final uid = Supabase.instance.client.auth.currentUser?.id ?? '';
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    final foreground = likedinOnSurface(brightness);
    final secondary = likedinMutedText(brightness);
    final accent = likedinPrimary(brightness);

    return RefreshIndicator(
      color: accent,
      backgroundColor: likedinSurface(brightness),
      onRefresh: () async {
        if (!mounted) return;
        setState(_load);
        try {
          await _history;
        } catch (error) {
          debugPrint('Call history refresh failed: $error');
        }
      },
      child: FutureBuilder<List<Map<String, dynamic>>>(
        future: _history,
        builder: (context, snapshot) {
          final isLoadingInitial =
              snapshot.connectionState == ConnectionState.waiting && _lastHistory == null;
          final hasInitialError = snapshot.hasError && _lastHistory == null;
          final allRows = snapshot.data ?? _lastHistory ?? const <Map<String, dynamic>>[];
          final rows = allRows.where(_matchesFilter).toList(growable: false);
          final outlineColor = likedinOutline(brightness);
          final rowBg = likedinSurface(brightness).withValues(alpha: dark ? .54 : .82);
          final rimColor = dark
              ? Colors.white.withValues(alpha: .16)
              : Colors.white.withValues(alpha: .95);

          return CustomScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            cacheExtent: LikedinAppearance.isLowRamDevice ? 320 : 560,
            slivers: [
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                sliver: SliverToBoxAdapter(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              'Calls',
                              style: TextStyle(
                                color: foreground,
                                fontSize: 34,
                                fontWeight: FontWeight.w800,
                                letterSpacing: -1.1,
                              ),
                            ),
                          ),
                          IconButton(
                            tooltip: 'Refresh call history',
                            onPressed: () => setState(_load),
                            icon: Icon(Icons.refresh_rounded, color: secondary),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      Row(
                        children: [
                          Expanded(
                            child: _callStartTile(
                              context,
                              icon: Icons.call_rounded,
                              title: 'Voice call',
                              subtitle: 'Audio only',
                              accent: const Color(0xFF32B98D),
                              onTap: () => _showCallSetup(context, video: false),
                            ),
                          ),
                          const SizedBox(width: 11),
                          Expanded(
                            child: _callStartTile(
                              context,
                              icon: Icons.videocam_rounded,
                              title: 'Video call',
                              subtitle: 'Face to face',
                              accent: const Color(0xFF3B9FD0),
                              onTap: () => _showCallSetup(context, video: true),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 26),
                      Text(
                        'Recent',
                        style: TextStyle(
                          color: foreground,
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                          letterSpacing: -.4,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: ['All', 'Missed', 'Video', 'Audio']
                            .map((value) => _filterPill(value, brightness: brightness, foreground: foreground))
                            .toList(),
                      ),
                      const SizedBox(height: 14),
                    ],
                  ),
                ),
              ),
              if (isLoadingInitial)
                SliverPadding(
                  padding: const EdgeInsets.all(34),
                  sliver: SliverToBoxAdapter(
                    child: Center(child: CircularProgressIndicator(color: accent)),
                  ),
                )
              else if (hasInitialError)
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 118),
                  sliver: SliverToBoxAdapter(
                    child: GlassPanel(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        children: [
                          Icon(
                            Icons.cloud_off_rounded,
                            color: dark ? const Color(0xFFFFB4AB) : const Color(0xFFB5473A),
                            size: 30,
                          ),
                          const SizedBox(height: 9),
                          Text('Call history unavailable', style: TextStyle(color: foreground, fontWeight: FontWeight.w700)),
                          const SizedBox(height: 4),
                          Text('Pull down to try again.', style: TextStyle(color: secondary, fontSize: 12)),
                        ],
                      ),
                    ),
                  ),
                )
              else if (allRows.isEmpty)
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 118),
                  sliver: SliverToBoxAdapter(
                    child: GlassPanel(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                      child: Column(
                        children: [
                          Icon(Icons.history_rounded, color: accent, size: 42),
                          const SizedBox(height: 12),
                          Text('No calls yet', style: TextStyle(color: foreground, fontWeight: FontWeight.w800)),
                          const SizedBox(height: 5),
                          Text(
                            'Your recent audio and video calls will appear here.',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: secondary, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              else if (rows.isEmpty)
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 118),
                  sliver: SliverToBoxAdapter(
                    child: GlassPanel(
                      padding: const EdgeInsets.all(22),
                      child: Column(
                        children: [
                          Icon(Icons.filter_list_off_rounded, color: accent, size: 34),
                          const SizedBox(height: 9),
                          Text('Nothing in this filter', style: TextStyle(color: foreground, fontWeight: FontWeight.w700)),
                          const SizedBox(height: 4),
                          Text('Try another call type.', style: TextStyle(color: secondary, fontSize: 12)),
                        ],
                      ),
                    ),
                  ),
                )
              else ...[
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(23, 0, 23, 9),
                  sliver: SliverToBoxAdapter(
                    child: Text(
                      '${rows.length} ${rows.length == 1 ? 'call' : 'calls'}',
                      style: TextStyle(color: secondary, fontSize: 12, fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 118),
                  sliver: SliverList.builder(
                    itemCount: rows.length,
                    itemBuilder: (context, i) {
                      final row = rows[i];
                      final isFirst = i == 0;
                      final isLast = i == rows.length - 1;
                      final missed = row['status'] == 'missed';
                      final outgoing = row['caller_id'] == uid;
                      final isVideo = row['call_type'] == 'video';
                      final peerId = outgoing ? row['callee_id']?.toString() : row['caller_id']?.toString();
                      final answered = DateTime.tryParse(row['answered_at']?.toString() ?? '');
                      final ended = DateTime.tryParse(row['ended_at']?.toString() ?? '');
                      final duration = answered == null || ended == null
                          ? null
                          : ended.difference(answered).inSeconds.clamp(0, 86400);
                      final statusColor = missed
                          ? (dark ? const Color(0xFFFF848B) : const Color(0xFFC43D4A))
                          : row['status'] == 'failed'
                              ? (dark ? const Color(0xFFFFB66D) : const Color(0xFFB96B19))
                              : (dark ? const Color(0xFF72DDB7) : const Color(0xFF208B68));
                      final rowRadius = BorderRadius.vertical(
                        top: Radius.circular(isFirst ? 22 : 0),
                        bottom: Radius.circular(isLast ? 22 : 0),
                      );
                      return RepaintBoundary(
                        child: Container(
                          decoration: BoxDecoration(
                            color: rowBg,
                            borderRadius: rowRadius,
                            border: Border(
                              left: BorderSide(color: rimColor, width: 1),
                              right: BorderSide(color: rimColor, width: 1),
                              top: isFirst ? BorderSide(color: rimColor, width: 1) : BorderSide.none,
                              bottom: isLast ? BorderSide(color: rimColor, width: 1) : BorderSide.none,
                            ),
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                                child: Row(
                                  children: [
                                    Container(
                                      width: 40,
                                      height: 40,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(13),
                                        color: statusColor.withValues(alpha: .16),
                                      ),
                                      child: Icon(
                                        isVideo ? Icons.videocam_rounded : _icon(row, uid),
                                        color: statusColor,
                                        size: 20,
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            '${isVideo ? 'Video' : 'Audio'} · ${_label(row, uid)}',
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                              color: missed ? statusColor : foreground,
                                              fontWeight: FontWeight.w700,
                                              fontSize: 14,
                                            ),
                                          ),
                                          const SizedBox(height: 3),
                                          Text(
                                            '${outgoing ? 'Outgoing' : 'Incoming'} · ${_dateLabel(row)}${duration == null ? '' : ' · ${duration ~/ 60}m ${duration % 60}s'}',
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(color: secondary, fontSize: 12),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: 6),
                                    IconButton(
                                      tooltip: 'Call back',
                                      visualDensity: VisualDensity.compact,
                                      onPressed: peerId == null || peerId.isEmpty
                                          ? null
                                          : () => _showCallSetup(context, video: isVideo, recipientId: peerId),
                                      icon: Icon(Icons.call_rounded, color: accent, size: 20),
                                    ),
                                  ],
                                ),
                              ),
                              if (!isLast)
                                Divider(
                                  height: 1,
                                  indent: 66,
                                  endIndent: 14,
                                  color: outlineColor.withValues(alpha: .65),
                                ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ],
          );
        },
      ),
    );
  }

  Widget _callStartTile(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required Color accent,
    required VoidCallback onTap,
  }) {
    final brightness = Theme.of(context).brightness;
    final dark = brightness == Brightness.dark;
    final foreground = likedinOnSurface(brightness);
    final secondary = likedinMutedText(brightness);
    return LikedinPressScale(
      child: Semantics(
        button: true,
        label: '$title, $subtitle',
        child: GlassPanel(
          radius: BorderRadius.circular(26),
          glow: true,
          glint: true,
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(22),
              onTap: onTap,
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      accent.withValues(alpha: dark ? .18 : .11),
                      accent.withValues(alpha: 0.0),
                    ],
                  ),
                ),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        color: accent.withValues(alpha: dark ? .22 : .15),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Icon(icon, color: accent, size: 23),
                    ),
                    const SizedBox(height: 16),
                    Text(title, style: TextStyle(color: foreground, fontSize: 16, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 2),
                    Text(subtitle, style: TextStyle(color: secondary, fontSize: 13)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

}

Future<void> _showCallSetup(BuildContext context, {required bool video, String? recipientId}) async {
  final client = Supabase.instance.client;
  final messenger = ScaffoldMessenger.of(context);
  if (LikedinActiveCallHost.isActive) {
    LikedinActiveCallHost.setMinimized(false);
    return;
  }
  if (_globalCallDialogActive) {
    messenger.showSnackBar(const SnackBar(content: Text('A call is already active. Finish it before starting another.')));
    return;
  }
  try {
    final peer = recipientId ?? await client.rpc('likedin_get_peer_id') as String?;
    if (peer == null) {
      messenger.showSnackBar(
        const SnackBar(content: Text('Your friend has not registered yet.')),
      );
      return;
    }
    if (!context.mounted) return;
    if (LikedinActiveCallHost.isActive || _globalCallDialogActive) {
      LikedinActiveCallHost.setMinimized(false);
      return;
    }
    await LikedinActiveCallHost.startOutgoing(peerId: peer, video: video);
  } catch (e) {
    messenger.showSnackBar(const SnackBar(content: Text('Could not start the call. Check your connection and try again.')));
  }
}

class _LiveCallDialog extends StatefulWidget {
  const _LiveCallDialog({
    super.key,
    required this.peerId,
    required this.video,
    this.minimized = false,
    this.onMinimize,
    this.onExpand,
    this.onClose,
  });
  final String peerId;
  final bool video;
  final bool minimized;
  final VoidCallback? onMinimize;
  final VoidCallback? onExpand;
  final VoidCallback? onClose;
  @override
  State<_LiveCallDialog> createState() => _LiveCallDialogState();
}

class _LiveCallDialogState extends State<_LiveCallDialog> {
  late final LikedinCallService call;
  final ProximityCallController proximity = ProximityCallController();
  StreamSubscription<String>? sub;
  Timer? durationTicker;
  Stopwatch? stopwatch;
  String status = 'Preparing call…';
  bool ready = false, failed = false, connected = false;
  final ValueNotifier<int> _elapsedSecondsNotifier = ValueNotifier<int>(0);
  String peerDisplayName = 'Likedin contact';

  void _closeOverlay() {
    if (!mounted) return;
    final close = widget.onClose;
    if (close != null) {
      close();
    } else if (Navigator.of(context).canPop()) {
      Navigator.of(context).pop();
    }
  }

  @override
  void initState() {
    super.initState();
    LikedinActiveCallHost._onBackPressed = _handleBackOrMinimize;
    LikedinActiveCallHost._onEndCall = _handleEndCall;
    _loadPeerDisplayName();
    _start();
  }

  @override
  void didUpdateWidget(covariant _LiveCallDialog oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.minimized != widget.minimized && !widget.video && connected) {
      unawaited(proximity.update(
        active: !widget.minimized,
        enabled: !widget.minimized && !call.speaker,
      ));
    }
  }

  Future<void> _loadPeerDisplayName() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getString('likedIn_nickname_${widget.peerId}');
      if (saved != null && saved.trim().isNotEmpty) {
        if (mounted) setState(() => peerDisplayName = saved.trim());
        return;
      }
      final row = await Supabase.instance.client.from('profiles')
          .select('display_name').eq('user_id', widget.peerId).maybeSingle();
      final name = row?['display_name']?.toString().trim();
      if (mounted && name != null && name.isNotEmpty) setState(() => peerDisplayName = name);
    } catch (error) {
      debugPrint('Call peer-name lookup deferred: $error');
    }
  }

  Future<void> _start() async {
    call = LikedinCallService(Supabase.instance.client);
    try {
      await call.initialize(withVideo: widget.video);
      sub = call.changes.listen((v) {
        if (!mounted) return;
        final nowConnected = v == 'connected';
        if (nowConnected && !connected) {
          connected = true;
          if (widget.video) {
            unawaited(_callAlertsMethodChannel
                .invokeMethod<bool>('setVideoCallActive', const {'active': true})
                .catchError((Object _) => false));
          }
          stopwatch = Stopwatch()..start();
          durationTicker?.cancel();
          durationTicker = Timer.periodic(const Duration(seconds: 1), (_) {
            if (mounted && stopwatch != null) {
              _elapsedSecondsNotifier.value = stopwatch!.elapsed.inSeconds;
            }
          });
        }
        setState(() {
          status = v;
          if (v.startsWith('failed') || v.startsWith('error:')) failed = true;
        });
        if (v == 'connected') {
          proximity.update(
            active: !widget.video && !widget.minimized,
            enabled: !widget.video && !widget.minimized && !call.speaker,
          );
        }
        if (v == 'ended' ||
            v == 'missed' ||
            v == 'rejected' ||
            v.startsWith('failed') ||
            v.startsWith('error:')) {
          Future<void>.delayed(const Duration(milliseconds: 900), () {
            _closeOverlay();
          });
        }
      });
      await call.start(widget.peerId, withVideo: widget.video);
      if (mounted) setState(() => ready = true);
    } catch (e) {
      if (mounted) {
        setState(() {
          status = 'Call connection failed';
          failed = true;
        });
      }
    }
  }

  Future<void> _toggleSpeaker() async {
    await call.toggleSpeaker();
    await proximity.update(
      active: connected && !widget.video && !widget.minimized,
      enabled: connected && !widget.video && !widget.minimized && !call.speaker,
    );
    if (mounted) setState(() {});
  }

  String _formatDuration(int seconds) =>
      '${(seconds ~/ 60).toString().padLeft(2, '0')}:${(seconds % 60).toString().padLeft(2, '0')}';

  String _statusLabelFor(int seconds) {
    final v = status.toLowerCase().trim();
    if (v.startsWith('failed') || v.startsWith('error')) return 'Call connection failed';
    if (v == 'disconnected' || v == 'reconnecting' || v.contains('disconnected')) return 'Reconnecting…';
    if (v == 'ringing' || v == 'ring') return 'Ringing…';
    if (v == 'ended' || v == 'closed') return 'Call ended';
    if (v == 'missed') return 'Missed call';
    if (v == 'rejected') return 'Call declined';
    if (connected || v == 'connected') return _formatDuration(seconds);
    if (v.contains('offer') || v.contains('connecting') || v.contains('preparing') || v.contains('calling')) {
      return 'Calling…';
    }
    return 'Connecting…';
  }

  @override
  void dispose() {
    if (identical(LikedinActiveCallHost._onBackPressed, _handleBackOrMinimize)) {
      LikedinActiveCallHost._onBackPressed = null;
    }
    if (identical(LikedinActiveCallHost._onEndCall, _handleEndCall)) {
      LikedinActiveCallHost._onEndCall = null;
    }
    if (widget.video) {
      unawaited(_callAlertsMethodChannel
          .invokeMethod<bool>('setVideoCallActive', const {'active': false})
          .catchError((Object _) => false));
    }
    durationTicker?.cancel();
    stopwatch?.stop();
    _elapsedSecondsNotifier.dispose();
    proximity.dispose();
    sub?.cancel();
    call.close();
    super.dispose();
  }

  bool _handlingBack = false;

  void _handleBackOrMinimize() {
    if (!failed && widget.onMinimize != null) {
      widget.onMinimize!();
      return;
    }
    unawaited(_handleEndCall());
  }

  Future<void> _handleEndCall() async {
    if (_handlingBack) return;
    _handlingBack = true;
    try {
      try { await call.end(); } catch (error) {
        debugPrint('Call termination failed; closing the call screen anyway: $error');
      }
    } finally {
      _closeOverlay();
      _handlingBack = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final inPip = MediaQuery.sizeOf(context).width < 260;
    if (inPip && widget.video && connected) {
      return Positioned.fill(
        child: Material(
          color: _callBackground,
          child: RTCVideoView(
            call.remoteRenderer,
            objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
          ),
        ),
      );
    }
    if (widget.minimized) {
      if (widget.video) {
        return _MinimizedVideoCallBubble(
          remoteRenderer: call.remoteRenderer,
          localRenderer: call.localRenderer,
          mirrorLocal: call.usingFrontCamera,
          cameraOn: call.camera,
          muted: call.muted,
          connected: connected,
          statusNotifier: _elapsedSecondsNotifier,
          statusBuilder: _statusLabelFor,
          onExpand: () => widget.onExpand?.call(),
          onToggleMute: () async {
            if (!ready) return;
            await call.toggleMute();
            if (mounted) setState(() {});
          },
          onEnd: () => unawaited(_handleEndCall()),
        );
      }
      return _MinimizedAudioCallBar(
        name: peerDisplayName,
        statusNotifier: _elapsedSecondsNotifier,
        statusBuilder: _statusLabelFor,
        muted: call.muted,
        speaker: call.speaker,
        onExpand: () => widget.onExpand?.call(),
        onToggleMute: () async {
          if (!ready) return;
          await call.toggleMute();
          if (mounted) setState(() {});
        },
        onToggleSpeaker: () {
          if (ready) unawaited(_toggleSpeaker());
        },
        onEnd: () => unawaited(_handleEndCall()),
      );
    }

    final title = connected
        ? 'In ${widget.video ? 'video' : 'audio'} call'
        : (widget.video ? 'Video call' : 'Audio call');
    final controlsWrap = Wrap(
      alignment: WrapAlignment.center,
      crossAxisAlignment: WrapCrossAlignment.center,
      spacing: 8,
      runSpacing: 18,
      children: [
        _callControl(
          call.muted ? Icons.mic_off_rounded : Icons.mic_rounded,
          call.muted ? 'Unmute' : 'Mute',
          ready
              ? () async {
                  await call.toggleMute();
                  if (mounted) setState(() {});
                }
              : null,
          active: call.muted,
        ),
        _callControl(
          call.speaker ? Icons.volume_up_rounded : Icons.hearing_rounded,
          call.speaker ? 'Speaker' : 'Earpiece',
          ready ? _toggleSpeaker : null,
          active: call.speaker,
        ),
        if (widget.video)
          _callControl(
            call.camera ? Icons.videocam_rounded : Icons.videocam_off_rounded,
            'Camera',
            ready
                ? () async {
                    await call.toggleCamera();
                    if (mounted) setState(() {});
                  }
                : null,
            active: !call.camera,
          ),
        if (widget.video)
          _callControl(Icons.cameraswitch_rounded, 'Flip', ready ? call.switchCamera : null),
        if (widget.video)
          _callControl(
            Icons.eco_rounded,
            call.dataSaver ? 'Saver On' : 'Saver',
            ready
                ? () async {
                    await call.toggleDataSaver();
                    if (mounted) setState(() {});
                  }
                : null,
            active: call.dataSaver,
          ),
      ],
    );

    return Positioned.fill(
      child: Material(
        color: _callBackground,
        child: widget.video && connected
            ? Builder(builder: (context) {
                final inPip = MediaQuery.sizeOf(context).width < 260;
                return Stack(
                fit: StackFit.expand,
                children: [
                  RTCVideoView(
                    call.remoteRenderer,
                    objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                  ),
                  if (!inPip) ...[
                  // Subtle top scrim for status pill legibility.
                  Positioned(
                    left: 0,
                    right: 0,
                    top: 0,
                    height: 110,
                    child: IgnorePointer(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.black.withValues(alpha: .55),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  // Subtle bottom scrim for floating call controls.
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    height: 220,
                    child: IgnorePointer(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            colors: [
                              Colors.black.withValues(alpha: .72),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  // Floating top-left status & timer pill (bounded so it never overlaps self-preview on 320-360dp).
                  Positioned(
                    left: 12,
                    right: LikedinResponsive.of(context).callSelfPreviewWidth + 24,
                    top: MediaQuery.paddingOf(context).top + 12,
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: _CallPill(
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 7,
                              height: 7,
                              decoration: const BoxDecoration(
                                color: _callPositive,
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 6),
                            Flexible(
                              child: ValueListenableBuilder<int>(
                                valueListenable: _elapsedSecondsNotifier,
                                builder: (_, seconds, __) => Text(
                                  _statusLabelFor(seconds),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                                ),
                              ),
                            ),
                            if (ready) ...[
                              const SizedBox(width: 6),
                              Flexible(
                                child: _CallQualityBadge(notifier: call.networkStatsNotifier),
                              ),
                            ],
                            const SizedBox(width: 6),
                            if (widget.onMinimize != null)
                              Semantics(
                                button: true,
                                label: 'Minimize call',
                                child: InkWell(
                                  borderRadius: BorderRadius.circular(14),
                                  onTap: widget.onMinimize,
                                  child: const Padding(
                                    padding: EdgeInsets.all(3),
                                    child: Icon(
                                      Icons.keyboard_arrow_down_rounded,
                                      color: Colors.white,
                                      size: 20,
                                    ),
                                  ),
                                ),
                              ),
                            const SizedBox(width: 2),
                            Semantics(
                              button: true,
                              label: 'Picture in picture',
                              child: InkWell(
                                borderRadius: BorderRadius.circular(14),
                                onTap: () => unawaited(_callAlertsMethodChannel
                                    .invokeMethod<bool>('enterPipMode')
                                    .catchError((Object _) => false)),
                                child: const Padding(
                                  padding: EdgeInsets.all(2),
                                  child: Icon(
                                    Icons.picture_in_picture_alt_rounded,
                                    color: Colors.white70,
                                    size: 17,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  // Floating top-right self preview.
                  Positioned(
                    right: 12,
                    top: MediaQuery.paddingOf(context).top + 12,
                    width: LikedinResponsive.of(context).callSelfPreviewWidth,
                    height: LikedinResponsive.of(context).callSelfPreviewHeight,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(18),
                      child: Container(
                        decoration: BoxDecoration(
                          color: _callPanel,
                          border: Border.all(color: Colors.white24),
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: call.camera
                            ? RTCVideoView(
                                call.localRenderer,
                                mirror: call.usingFrontCamera,
                                objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                              )
                            : const Center(
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(Icons.videocam_off_rounded, color: Colors.white54, size: 26),
                                    SizedBox(height: 4),
                                    Text(
                                      'Camera off',
                                      style: TextStyle(color: Colors.white54, fontSize: 10.5, fontWeight: FontWeight.w600),
                                    ),
                                  ],
                                ),
                              ),
                      ),
                    ),
                  ),
                  // Floating bottom controls over full-screen video.
                  Positioned(
                    left: 16,
                    right: 16,
                    bottom: MediaQuery.paddingOf(context).bottom + 20,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        controlsWrap,
                        const SizedBox(height: 18),
                        _incomingCallAction(
                          icon: Icons.call_end_rounded,
                          label: failed ? 'Close' : 'End call',
                          color: _callDanger,
                          onTap: _handleEndCall,
                        ),
                      ],
                    ),
                  ),
                  ],
                ],
              );
              })
            : SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(24, 8, 24, 28),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          if (widget.onMinimize != null && !failed)
                            TextButton.icon(
                              onPressed: widget.onMinimize,
                              style: TextButton.styleFrom(
                                foregroundColor: Colors.white,
                                backgroundColor: Colors.white.withValues(alpha: .10),
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              ),
                              icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 20),
                              label: const Text('Minimize', style: TextStyle(fontSize: 13)),
                            )
                          else
                            Semantics(
                              button: true,
                              label: 'Close',
                              child: IconButton(
                                onPressed: _handleEndCall,
                                icon: const Icon(Icons.close_rounded, color: Colors.white70, size: 24),
                              ),
                            ),
                          const Spacer(),
                          if (connected && ready) ...[
                            _CallQualityBadge(notifier: call.networkStatsNotifier),
                            const SizedBox(width: 10),
                          ],
                          Icon(
                            widget.video ? Icons.videocam_rounded : Icons.call_rounded,
                            color: _callMuted,
                            size: 22,
                          ),
                          const SizedBox(width: 12),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Expanded(
                        child: Center(
                          child: SingleChildScrollView(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                _CallHaloAvatar(
                                  icon: Icons.person_rounded,
                                  size: LikedinResponsive.of(context).callAvatarSize,
                                  animate: !connected && !failed,
                                ),
                                const SizedBox(height: 28),
                                Text(
                                  peerDisplayName,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 30,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: -.8,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  title,
                                  style: const TextStyle(color: _callMuted, fontSize: 16),
                                ),
                                const SizedBox(height: 20),
                                ValueListenableBuilder<int>(
                                  valueListenable: _elapsedSecondsNotifier,
                                  builder: (_, seconds, __) => _CallStatusLine(
                                    text: _statusLabelFor(seconds),
                                    color: failed
                                        ? const Color(0xFFFF7C83)
                                        : connected
                                            ? _callPositive
                                            : _callAccent,
                                  ),
                                ),
                                if (failed)
                                  const Padding(
                                    padding: EdgeInsets.only(top: 14),
                                    child: Text(
                                      'Call connection failed. Check your connection and try again.',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(color: Color(0xFFFFB4AB), fontSize: 13),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),
                      controlsWrap,
                      const SizedBox(height: 22),
                      _incomingCallAction(
                        icon: Icons.call_end_rounded,
                        label: failed ? 'Close' : 'End call',
                        color: _callDanger,
                        onTap: _handleEndCall,
                      ),
                    ],
                  ),
                ),
              ),
      ),
    );
  }

  Widget _callControl(
    IconData icon,
    String label,
    VoidCallback? action, {
    bool active = false,
  }) =>
      _CallRoundButton(icon: icon, label: label, active: active, onPressed: action);
}

class _IncomingCallDialog extends StatefulWidget {
  const _IncomingCallDialog({
    super.key,
    required this.callId,
    required this.callerId,
    required this.offer,
    required this.withVideo,
    this.autoAccept = false,
    this.minimized = false,
    this.onMinimize,
    this.onExpand,
    this.onClose,
  });
  final String callId, callerId;
  final Map<String, dynamic> offer;
  final bool withVideo;
  final bool autoAccept;
  final bool minimized;
  final VoidCallback? onMinimize;
  final VoidCallback? onExpand;
  final VoidCallback? onClose;
  @override
  State<_IncomingCallDialog> createState() => _IncomingCallDialogState();
}

class _IncomingCallDialogState extends State<_IncomingCallDialog> {
  late final LikedinCallService call;
  final ProximityCallController proximity = ProximityCallController();
  StreamSubscription<String>? subscription;
  bool accepting = false, accepted = false, connected = false, finished = false, _checkingRemoteStatus = false;
  bool _handlingBack = false, _dialogClosing = false;
  String status = 'Incoming call';
  String callerDisplayName = 'Likedin contact';
  Timer? _incomingStatusTimer;
  Timer? _durationTicker;
  Stopwatch? _stopwatch;
  final ValueNotifier<int> _elapsedSecondsNotifier = ValueNotifier<int>(0);

  String _formatDuration(int seconds) =>
      '${(seconds ~/ 60).toString().padLeft(2, '0')}:${(seconds % 60).toString().padLeft(2, '0')}';

  @override
  void initState() {
    super.initState();
    LikedinActiveCallHost._onBackPressed = _handleBackOrMinimize;
    LikedinActiveCallHost._onEndCall = _handleSystemBack;
    call = LikedinCallService(Supabase.instance.client);
    _loadCallerDisplayName();
    if (!widget.autoAccept) CallAlertController.startIncoming();
    _incomingStatusTimer = Timer.periodic(
      const Duration(seconds: 2),
      (_) => _checkIncomingStatus(),
    );
    if (widget.autoAccept) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) unawaited(_accept());
      });
    }
  }

  Future<void> _loadCallerDisplayName() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getString('likedIn_nickname_${widget.callerId}');
      if (saved != null && saved.trim().isNotEmpty) {
        if (mounted) setState(() => callerDisplayName = saved.trim());
        return;
      }
      final row = await Supabase.instance.client.from('profiles')
          .select('display_name').eq('user_id', widget.callerId).maybeSingle();
      final name = row?['display_name']?.toString().trim();
      if (mounted && name != null && name.isNotEmpty) setState(() => callerDisplayName = name);
    } catch (error) { debugPrint('Incoming caller-name lookup deferred: $error'); }
  }

  void _closeDialog() {
    if (!mounted || _dialogClosing) return;
    _dialogClosing = true;
    final close = widget.onClose;
    if (close != null) {
      close();
    } else if (Navigator.of(context).canPop()) {
      Navigator.of(context).pop();
    }
  }

  void _handleBackOrMinimize() {
    if (accepted && !finished && widget.onMinimize != null) {
      widget.onMinimize!();
      return;
    }
    unawaited(_handleSystemBack());
  }

  Future<void> _handleSystemBack() async {
    if (_handlingBack || accepting) return;
    _handlingBack = true;
    try {
      if (!finished) {
        if (accepted) {
          try { await call.end(); } catch (error) {
            debugPrint('Incoming call termination failed; closing dialog anyway: $error');
          }
        } else {
          try {
            await _reject();
          } catch (error) {
            debugPrint('Incoming call decline failed; closing dialog anyway: $error');
          }
        }
      }
    } finally {
      _closeDialog();
      _handlingBack = false;
    }
  }

  Future<void> _checkIncomingStatus() async {
    if (!mounted || accepting || accepted || finished || _checkingRemoteStatus) return;
    _checkingRemoteStatus = true;
    try {
      final row = await Supabase.instance.client
          .from('likedin_calls')
          .select('status')
          .eq('id', widget.callId)
          .maybeSingle();
      final remoteStatus = row?['status']?.toString();
      if (remoteStatus != null &&
          remoteStatus != 'ringing' &&
          mounted &&
          !accepting &&
          !accepted) {
        await CallAlertController.stop();
        if (!mounted) return;
        setState(() {
          status = remoteStatus == 'missed' ? 'Missed call' : remoteStatus == 'failed' ? 'Call failed' : 'Call ended';
          finished = true;
        });
        Future<void>.delayed(const Duration(milliseconds: 900), () {
          _closeDialog();
        });
      }
    } catch (_) {
    } finally {
      _checkingRemoteStatus = false;
    }
  }

  Future<void> _accept() async {
    if (accepting || accepted || finished) return;
    await CallAlertController.stop();
    if (!mounted) return;
    setState(() {
      accepting = true;
      status = 'Connecting…';
    });
    try {
      await call.initialize(withVideo: widget.withVideo);
      if (!mounted) return;
      subscription = call.changes.listen((value) {
        if (!mounted) return;
        if (value == 'connected' && !connected) {
          connected = true;
          if (widget.withVideo) {
            unawaited(_callAlertsMethodChannel
                .invokeMethod<bool>('setVideoCallActive', const {'active': true})
                .catchError((Object _) => false));
          }
          _stopwatch = Stopwatch()..start();
          _durationTicker?.cancel();
          _durationTicker = Timer.periodic(const Duration(seconds: 1), (_) {
            if (mounted && _stopwatch != null) {
              _elapsedSecondsNotifier.value = _stopwatch!.elapsed.inSeconds;
            }
          });
        }
        setState(() {
          status = (value == 'disconnected' || value == 'reconnecting')
              ? 'Reconnecting…'
              : value == 'connected'
                  ? 'Connected'
                  : value.startsWith('failed') || value.startsWith('error:')
                      ? 'Call connection failed'
                      : value == 'ringing' ? 'Ringing…' : value == 'ended' ? 'Call ended'
                      : value == 'missed' ? 'Missed call' : value == 'rejected' ? 'Call declined'
                      : 'Connecting…';
          if (value == 'ended' ||
              value == 'missed' ||
              value == 'rejected' ||
              value.startsWith('failed') ||
              value.startsWith('error:')) {
            finished = true;
          }
        });
        if (finished) {
          Future<void>.delayed(const Duration(milliseconds: 650), () {
            _closeDialog();
          });
        }
      });
      await call.accept(widget.callId, widget.callerId, widget.offer, withVideo: widget.withVideo);
      await proximity.update(
        active: !widget.withVideo && !widget.minimized,
        enabled: !widget.withVideo && !widget.minimized && !call.speaker,
      );
      if (mounted) {
        setState(() {
          accepted = true;
          accepting = false;
          status = connected ? 'Connected' : 'Connecting…';
        });
      }
    } catch (e) {
      // Renderer initialization can fail before CallService.accept() runs its
      // own rejection cleanup. Make the server state terminal in either case;
      // a failed answer must never leave the other handset ringing forever.
      try {
        await Supabase.instance.client.rpc('likedin_update_call_status', params: {
          'p_call_id': widget.callId,
          'p_new_status': 'rejected',
        });
      } catch (_) {
        // If accept() already committed and then failed, CallService has
        // already changed the row to ended; rejection is no longer legal.
      }
      try {
        final currentUid = Supabase.instance.client.auth.currentUser?.id;
        if (currentUid != null) {
          await Supabase.instance.client.from('likedin_call_signals').insert({
            'call_id': widget.callId,
            'sender_id': currentUid,
            'kind': 'reject',
            'payload': <String, dynamic>{},
          });
        }
      } catch (_) {}
      try { await LikedinNotificationService.instance.cancelIncomingCall(widget.callId); } catch (_) {}
      if (mounted) {
        setState(() {
          accepting = false;
          finished = true;
          status = 'Could not answer the call. Check permissions and try again.';
        });
        Future<void>.delayed(const Duration(milliseconds: 1500), () {
          if (mounted) _closeDialog();
        });
      }
    }
  }

  Future<void> _toggleSpeaker() async {
    if (!mounted) return;
    await call.toggleSpeaker();
    if (!mounted) return;
    await proximity.update(
      active: accepted && !widget.withVideo && !widget.minimized,
      enabled: accepted && !widget.withVideo && !widget.minimized && !call.speaker,
    );
    if (mounted) setState(() {});
  }

  @override
  void didUpdateWidget(covariant _IncomingCallDialog oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.minimized != widget.minimized && accepted && !widget.withVideo) {
      unawaited(proximity.update(
        active: !widget.minimized,
        enabled: !widget.minimized && !call.speaker,
      ));
    }
  }

  Future<void> _reject() async {
    await CallAlertController.stop();
    try {
      await Supabase.instance.client.rpc('likedin_update_call_status', params: {
        'p_call_id': widget.callId,
        'p_new_status': 'rejected',
      });
    } catch (e) {
      debugPrint('Could not commit incoming call rejection: $e');
      if (mounted) {
        ScaffoldMessenger.maybeOf(context)?.showSnackBar(
          const SnackBar(content: Text('Could not decline the call. Please try again.')),
        );
      }
      return;
    }
    try {
      await LikedinNotificationService.instance.cancelIncomingCall(widget.callId);
    } catch (e) {
      debugPrint('Call declined, but local incoming-call notification could not be cancelled: $e');
    }
    try {
      final currentUid = Supabase.instance.client.auth.currentUser?.id;
      if (currentUid != null) {
        await Supabase.instance.client.from('likedin_call_signals').insert({
          'call_id': widget.callId,
          'sender_id': currentUid,
          'kind': 'reject',
          'payload': <String, dynamic>{},
        });
      }
    } catch (e) {
      // The server-side state is authoritative; missing signaling must not
      // turn a declined call into a missed call.
      debugPrint('Call was declined, but reject signaling failed: $e');
    }
    if (mounted) {
      setState(() {
        finished = true;
        status = 'Call declined';
      });
      _closeDialog();
    }
  }

  @override
  void dispose() {
    if (identical(LikedinActiveCallHost._onBackPressed, _handleBackOrMinimize)) {
      LikedinActiveCallHost._onBackPressed = null;
    }
    if (identical(LikedinActiveCallHost._onEndCall, _handleSystemBack)) {
      LikedinActiveCallHost._onEndCall = null;
    }
    if (widget.withVideo) {
      unawaited(_callAlertsMethodChannel
          .invokeMethod<bool>('setVideoCallActive', const {'active': false})
          .catchError((Object _) => false));
    }
    _incomingStatusTimer?.cancel();
    _durationTicker?.cancel();
    _stopwatch?.stop();
    _elapsedSecondsNotifier.dispose();
    CallAlertController.stop();
    proximity.dispose();
    subscription?.cancel();
    call.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isActive = accepted && !finished;
    final headline = widget.withVideo ? 'Video call' : 'Audio call';
    final subtitle = isActive
        ? 'Connected'
        : finished
            ? headline
            : 'Incoming ${widget.withVideo ? 'video' : 'audio'} call';

    String statusTextFor(int seconds) => (accepted || finished)
        ? (connected && !finished && status != 'Reconnecting…' ? _formatDuration(seconds) : status)
        : 'Your friend is calling';

    final inPip = MediaQuery.sizeOf(context).width < 260;
    if (inPip && isActive && widget.withVideo) {
      return Positioned.fill(
        child: Material(
          color: _callBackground,
          child: RTCVideoView(
            call.remoteRenderer,
            objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
          ),
        ),
      );
    }

    if (widget.minimized && finished) {
      return const SizedBox.shrink();
    }

    if (widget.minimized && isActive) {
      if (widget.withVideo) {
        return _MinimizedVideoCallBubble(
          remoteRenderer: call.remoteRenderer,
          localRenderer: call.localRenderer,
          mirrorLocal: call.usingFrontCamera,
          cameraOn: call.camera,
          muted: call.muted,
          connected: connected,
          statusNotifier: _elapsedSecondsNotifier,
          statusBuilder: statusTextFor,
          onExpand: () => widget.onExpand?.call(),
          onToggleMute: () async {
            await call.toggleMute();
            if (mounted) setState(() {});
          },
          onEnd: () async {
            try { await call.end(); } catch (_) {} finally { _closeDialog(); }
          },
        );
      }
      return _MinimizedAudioCallBar(
        name: callerDisplayName,
        statusNotifier: _elapsedSecondsNotifier,
        statusBuilder: statusTextFor,
        muted: call.muted,
        speaker: call.speaker,
        onExpand: () => widget.onExpand?.call(),
        onToggleMute: () async {
          await call.toggleMute();
          if (mounted) setState(() {});
        },
        onToggleSpeaker: () => unawaited(_toggleSpeaker()),
        onEnd: () async {
          try { await call.end(); } catch (_) {} finally { _closeDialog(); }
        },
      );
    }

    final activeControlsWrap = Wrap(
      alignment: WrapAlignment.center,
      crossAxisAlignment: WrapCrossAlignment.center,
      spacing: 8,
      runSpacing: 18,
      children: [
        _activeCallControl(
          call.muted ? Icons.mic_off_rounded : Icons.mic_rounded,
          call.muted ? 'Unmute' : 'Mute',
          call.muted,
          () async {
            await call.toggleMute();
            if (mounted) setState(() {});
          },
        ),
        _activeCallControl(
          call.speaker ? Icons.volume_up_rounded : Icons.hearing_rounded,
          'Speaker',
          call.speaker,
          _toggleSpeaker,
        ),
        if (widget.withVideo)
          _activeCallControl(
            call.camera ? Icons.videocam_rounded : Icons.videocam_off_rounded,
            'Camera',
            !call.camera,
            () async {
              await call.toggleCamera();
              if (mounted) setState(() {});
            },
          ),
        if (widget.withVideo)
          _activeCallControl(Icons.cameraswitch_rounded, 'Flip', false, call.switchCamera),
        if (widget.withVideo)
          _activeCallControl(
            Icons.eco_rounded,
            call.dataSaver ? 'Saver On' : 'Saver',
            call.dataSaver,
            () async {
              await call.toggleDataSaver();
              if (mounted) setState(() {});
            },
          ),
        _incomingCallAction(
          icon: Icons.call_end_rounded,
          label: 'End call',
          color: _callDanger,
          onTap: () async {
            try {
              await call.end();
            } catch (error) {
              debugPrint('Incoming call end failed; closing dialog anyway: $error');
            } finally {
              _closeDialog();
            }
          },
        ),
      ],
    );

    return Positioned.fill(
      child: Material(
        color: _callBackground,
        child: isActive && widget.withVideo
            ? Builder(builder: (context) {
                final inPip = MediaQuery.sizeOf(context).width < 260;
                return Stack(
                fit: StackFit.expand,
                children: [
                  RTCVideoView(
                    call.remoteRenderer,
                    objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                  ),
                  if (!inPip) ...[
                  Positioned(
                    left: 0,
                    right: 0,
                    top: 0,
                    height: 110,
                    child: IgnorePointer(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.black.withValues(alpha: .55),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    height: 200,
                    child: IgnorePointer(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            colors: [
                              Colors.black.withValues(alpha: .72),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 12,
                    right: LikedinResponsive.of(context).callSelfPreviewWidth + 24,
                    top: MediaQuery.paddingOf(context).top + 12,
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: _CallPill(
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Flexible(
                              child: ValueListenableBuilder<int>(
                                valueListenable: _elapsedSecondsNotifier,
                                builder: (_, seconds, __) => Text(
                                  connected ? _formatDuration(seconds) : status,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                                ),
                              ),
                            ),
                            if (connected) ...[
                              const SizedBox(width: 6),
                              Flexible(
                                child: _CallQualityBadge(notifier: call.networkStatsNotifier),
                              ),
                            ],
                            const SizedBox(width: 6),
                            if (widget.onMinimize != null)
                              Semantics(
                                button: true,
                                label: 'Minimize call',
                                child: InkWell(
                                  borderRadius: BorderRadius.circular(14),
                                  onTap: widget.onMinimize,
                                  child: const Padding(
                                    padding: EdgeInsets.all(3),
                                    child: Icon(
                                      Icons.keyboard_arrow_down_rounded,
                                      color: Colors.white,
                                      size: 20,
                                    ),
                                  ),
                                ),
                              ),
                            const SizedBox(width: 2),
                            Semantics(
                              button: true,
                              label: 'Picture in picture',
                              child: InkWell(
                                borderRadius: BorderRadius.circular(14),
                                onTap: () => unawaited(_callAlertsMethodChannel
                                    .invokeMethod<bool>('enterPipMode')
                                    .catchError((Object _) => false)),
                                child: const Padding(
                                  padding: EdgeInsets.all(2),
                                  child: Icon(
                                    Icons.picture_in_picture_alt_rounded,
                                    color: Colors.white70,
                                    size: 17,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    right: 12,
                    top: MediaQuery.paddingOf(context).top + 12,
                    width: LikedinResponsive.of(context).callSelfPreviewWidth,
                    height: LikedinResponsive.of(context).callSelfPreviewHeight,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(18),
                      child: Container(
                        decoration: BoxDecoration(
                          color: _callPanel,
                          border: Border.all(color: Colors.white24),
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: call.camera
                            ? RTCVideoView(
                                call.localRenderer,
                                mirror: call.usingFrontCamera,
                                objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                              )
                            : const Center(
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(Icons.videocam_off_rounded, color: Colors.white54, size: 26),
                                    SizedBox(height: 4),
                                    Text(
                                      'Camera off',
                                      style: TextStyle(color: Colors.white54, fontSize: 10.5, fontWeight: FontWeight.w600),
                                    ),
                                  ],
                                ),
                              ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 16,
                    right: 16,
                    bottom: MediaQuery.paddingOf(context).bottom + 20,
                    child: activeControlsWrap,
                  ),
                  ],
                ],
              );
              })
            : SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(24, 10, 24, 28),
                  child: Column(
                    children: [
                      if (isActive)
                        Row(
                          children: [
                            if (widget.onMinimize != null)
                              TextButton.icon(
                                onPressed: widget.onMinimize,
                                style: TextButton.styleFrom(
                                  foregroundColor: Colors.white,
                                  backgroundColor: Colors.white.withValues(alpha: .10),
                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                ),
                                icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 20),
                                label: const Text('Minimize', style: TextStyle(fontSize: 13)),
                              ),
                            const Spacer(),
                            if (connected) _CallQualityBadge(notifier: call.networkStatsNotifier),
                          ],
                        ),
                      Expanded(
                        child: Center(
                          child: SingleChildScrollView(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                _CallHaloAvatar(
                                  icon: widget.withVideo ? Icons.videocam_rounded : Icons.person_rounded,
                                  size: LikedinResponsive.of(context).callAvatarSize,
                                  animate: !isActive && !finished,
                                ),
                                const SizedBox(height: 28),
                                Text(
                                  callerDisplayName,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 30,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: -.8,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  subtitle,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(color: _callMuted, fontSize: 16),
                                ),
                                const SizedBox(height: 20),
                                ValueListenableBuilder<int>(
                                  valueListenable: _elapsedSecondsNotifier,
                                  builder: (_, seconds, __) => _CallStatusLine(
                                    text: statusTextFor(seconds),
                                    color: isActive ? _callPositive : _callAccent,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),
                      if (!accepted && !finished)
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            _incomingCallAction(
                              icon: Icons.call_end_rounded,
                              label: 'Decline',
                              color: _callDanger,
                              onTap: accepting ? null : _reject,
                            ),
                            _incomingCallAction(
                              icon: Icons.call_rounded,
                              label: accepting ? 'Connecting' : 'Answer',
                              color: _callPositive,
                              onTap: (accepting || finished) ? null : _accept,
                            ),
                          ],
                        )
                      else if (isActive)
                        activeControlsWrap
                      else
                        SizedBox(
                          width: double.infinity,
                          child: FilledButton(
                            onPressed: _closeDialog,
                            style: FilledButton.styleFrom(
                              backgroundColor: _callButton,
                              foregroundColor: Colors.white,
                            ),
                            child: const Text('Close'),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
      ),
    );
  }
}

Widget _incomingCallAction({
  required IconData icon,
  required String label,
  required Color color,
  required VoidCallback? onTap,
}) =>
    SizedBox(
      width: 84,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Semantics(
            button: true,
            enabled: onTap != null,
            label: label,
            child: LikedinPressScale(
              enabled: onTap != null,
              pressedScale: 0.90,
              glowRadius: BorderRadius.circular(36),
              child: Material(
                color: onTap == null ? color.withValues(alpha: .45) : color,
                shape: const CircleBorder(),
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: onTap == null
                      ? null
                      : () {
                          OriginHaptics.buttonTap();
                          onTap();
                        },
                  child: SizedBox(
                    width: 72,
                    height: 72,
                    child: Icon(icon, size: 30, color: Colors.white),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );

Widget _activeCallControl(
  IconData icon,
  String label,
  bool active,
  VoidCallback onPressed,
) =>
    _CallRoundButton(icon: icon, label: label, active: active, onPressed: onPressed);



final RegExp _firstUrlRegex = RegExp(r'((https?:\/\/|www\.)[^\s<>"]+)', caseSensitive: false);

String? _extractFirstUrl(String text) {
  if (!text.contains('.') || (!text.contains('http') && !text.contains('www.') && !text.contains('HTTP') && !text.contains('WWW.'))) {
    return null;
  }
  return _firstUrlRegex.firstMatch(text)?.group(0);
}


class _CallQualityBadge extends StatelessWidget {
  const _CallQualityBadge({required this.notifier});
  final ValueNotifier<CallNetworkStats> notifier;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<CallNetworkStats>(
      valueListenable: notifier,
      builder: (_, stats, __) {
        final (Color color, IconData icon) = switch (stats.tier) {
          CallQualityTier.hd => (const Color(0xFF2FBF86), Icons.signal_cellular_alt_rounded),
          CallQualityTier.good => (const Color(0xFF38BDF8), Icons.signal_cellular_alt_rounded),
          CallQualityTier.fair => (const Color(0xFFF59E0B), Icons.signal_cellular_alt_2_bar_rounded),
          CallQualityTier.weak => (const Color(0xFFFF7C83), Icons.signal_cellular_alt_1_bar_rounded),
          CallQualityTier.reconnecting => (const Color(0xFFF59E0B), Icons.sync_rounded),
        };
        final accent = stats.dataSaver && !stats.reconnecting
            ? const Color(0xFF34D399)
            : color;
        final labelText = stats.rttMs != null && !stats.reconnecting && !stats.dataSaver
            ? '${stats.label} · ${stats.rttMs}ms'
            : stats.label;
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
          decoration: BoxDecoration(
            color: accent.withValues(alpha: .20),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: accent.withValues(alpha: .55), width: 0.9),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(stats.dataSaver && !stats.reconnecting ? Icons.eco_rounded : icon, size: 12, color: accent),
              const SizedBox(width: 4),
              Flexible(
                child: Text(
                  labelText,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: accent,
                    fontSize: 10.5,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
