import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'glassmorphism.dart';

/// Clean, focused Profile tab with zero duplicate shortcuts to Settings or Files.
class ProfilePage extends StatelessWidget {
  const ProfilePage({
    required this.displayName,
    required this.email,
    required this.photoPath,
    required this.onEditPhoto,
    required this.onOpenBitmoji,
    required this.onSignOut,
    super.key,
  });

  final String displayName;
  final String email;
  final ValueListenable<String?> photoPath;
  final Future<void> Function() onEditPhoto;
  final Future<void> Function() onOpenBitmoji;
  final Future<void> Function() onSignOut;

  Future<void> _confirmSignOut(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Sign out?'),
        content: const Text('You can sign back in anytime with your account credentials.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Sign out'),
          ),
        ],
      ),
    );
    if (confirmed == true) await onSignOut();
  }

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final primary = likedinPrimary(brightness);
    final muted = likedinMutedText(brightness);
    final initial = displayName.trim().isEmpty
        ? '?'
        : String.fromCharCode(displayName.trim().runes.first).toUpperCase();

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 118),
      children: [
        const Text(
          'Profile',
          style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, letterSpacing: -1.1),
        ),
        const SizedBox(height: 18),
        GlassPanel(
          radius: BorderRadius.circular(28),
          padding: const EdgeInsets.fromLTRB(20, 24, 20, 22),
          glow: true,
          glint: true,
          child: Column(
            children: [
              Semantics(
                button: true,
                label: 'Change profile photo',
                child: GestureDetector(
                onTap: () => onEditPhoto(),
                child: Stack(
                  alignment: Alignment.bottomRight,
                  children: [
                    ValueListenableBuilder<String?>(
                      valueListenable: photoPath,
                      builder: (context, path, _) {
                        final hasFile = path != null && path.isNotEmpty;
                        return Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              colors: [primary, primary.withValues(alpha: .35)],
                            ),
                          ),
                          child: CircleAvatar(
                            radius: 54,
                            backgroundColor: likedinSurfaceRaised(brightness),
                            child: hasFile
                                ? ClipOval(
                                    child: Image.file(
                                      File(path),
                                      width: 108,
                                      height: 108,
                                      cacheWidth: 260,
                                      fit: BoxFit.cover,
                                      gaplessPlayback: true,
                                      errorBuilder: (_, __, ___) => Text(
                                        initial,
                                        style: TextStyle(
                                          fontSize: 38,
                                          fontWeight: FontWeight.w800,
                                          color: primary,
                                        ),
                                      ),
                                    ),
                                  )
                                : Text(
                                    initial,
                                    style: TextStyle(
                                      fontSize: 38,
                                      fontWeight: FontWeight.w800,
                                      color: primary,
                                    ),
                                  ),
                          ),
                        );
                      },
                    ),
                    Container(
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(
                        color: primary,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: likedinSurface(brightness),
                          width: 2.5,
                        ),
                      ),
                      child: const Icon(Icons.camera_alt_rounded, color: Colors.white, size: 17),
                    ),
                  ],
                ),
              ),
              ),
              const SizedBox(height: 16),
              Text(
                displayName,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, letterSpacing: -.4),
              ),
              const SizedBox(height: 4),
              Text(
                email,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: muted),
              ),
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: primary.withValues(alpha: brightness == Brightness.dark ? .18 : .12),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: primary.withValues(alpha: brightness == Brightness.dark ? .35 : .24),
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.auto_awesome_rounded, size: 14, color: primary),
                    const SizedBox(width: 6),
                    Text(
                      '${LikedinAppearance.theme.name} · ${LikedinAppearance.textureLabel} Glass',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: primary,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        GlassPanel(
          padding: EdgeInsets.zero,
          radius: BorderRadius.circular(26),
          child: Column(
            children: [
              ListTile(
                onTap: () => onEditPhoto(),
                leading: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: const Color(0xFF4C8BF5).withValues(alpha: .15),
                    borderRadius: BorderRadius.circular(11),
                  ),
                  child: const Icon(Icons.photo_camera_outlined, color: Color(0xFF4C8BF5), size: 19),
                ),
                title: const Text('Change profile photo', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                subtitle: const Text('Update the photo your friend sees', style: TextStyle(fontSize: 12)),
                trailing: Icon(Icons.chevron_right_rounded, color: muted),
              ),
              Divider(height: 1, indent: 62, endIndent: 14, color: likedinOutline(brightness)),
              ListTile(
                onTap: () => onOpenBitmoji(),
                leading: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: const Color(0xFFEC4899).withValues(alpha: .15),
                    borderRadius: BorderRadius.circular(11),
                  ),
                  child: const Icon(Icons.face_retouching_natural_rounded, color: Color(0xFFEC4899), size: 19),
                ),
                title: const Text('My Bitmoji', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                subtitle: const Text('Customize your peeking character in chat', style: TextStyle(fontSize: 12)),
                trailing: Icon(Icons.chevron_right_rounded, color: muted),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        LikedinPressScale(
          glowRadius: BorderRadius.circular(26),
          child: GlassPanel(
            padding: EdgeInsets.zero,
            radius: BorderRadius.circular(26),
            child: ListTile(
              onTap: () => _confirmSignOut(context),
            leading: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: const Color(0xFFE5484D).withValues(alpha: .15),
                borderRadius: BorderRadius.circular(11),
              ),
              child: const Icon(Icons.logout_rounded, color: Color(0xFFE5484D), size: 19),
            ),
            title: const Text(
              'Sign out',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: Color(0xFFE5484D)),
            ),
            subtitle: const Text('Sign out of this device', style: TextStyle(fontSize: 12)),
            ),
          ),
        ),
      ],
    );
  }
}
