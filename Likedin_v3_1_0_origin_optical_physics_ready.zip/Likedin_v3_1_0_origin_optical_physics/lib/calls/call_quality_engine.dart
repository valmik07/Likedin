/// Pure-Dart WebRTC call quality, SDP tuning, adaptive bitrate ladder, and
/// glare-safe ICE-restart helper engine. Zero platform dependencies so every
/// rule is deterministically unit-tested.
enum CallQualityTier {
  hd,
  good,
  fair,
  weak,
  reconnecting,
}

class CallQualityProfile {
  const CallQualityProfile({
    required this.tier,
    required this.maxVideoBitrateBps,
    required this.maxFramerate,
    required this.scaleResolutionDownBy,
    required this.maxAudioBitrateBps,
    required this.label,
  });

  final CallQualityTier tier;
  final int maxVideoBitrateBps;
  final int maxFramerate;
  final double scaleResolutionDownBy;
  final int maxAudioBitrateBps;
  final String label;

  @override
  bool operator ==(Object other) =>
      other is CallQualityProfile &&
      other.tier == tier &&
      other.maxVideoBitrateBps == maxVideoBitrateBps &&
      other.maxFramerate == maxFramerate &&
      other.scaleResolutionDownBy == scaleResolutionDownBy &&
      other.maxAudioBitrateBps == maxAudioBitrateBps &&
      other.label == label;

  @override
  int get hashCode => Object.hash(
        tier,
        maxVideoBitrateBps,
        maxFramerate,
        scaleResolutionDownBy,
        maxAudioBitrateBps,
        label,
      );
}

class CallNetworkStats {
  const CallNetworkStats({
    this.tier = CallQualityTier.good,
    this.rttMs,
    this.lossPercent = 0.0,
    this.dataSaver = false,
    this.reconnecting = false,
  });

  final CallQualityTier tier;
  final int? rttMs;
  final double lossPercent;
  final bool dataSaver;
  final bool reconnecting;

  String get label {
    if (reconnecting || tier == CallQualityTier.reconnecting) {
      return 'Reconnecting';
    }
    if (dataSaver) return 'Saver';
    return switch (tier) {
      CallQualityTier.hd => 'HD',
      CallQualityTier.good => 'Good',
      CallQualityTier.fair => 'Fair',
      CallQualityTier.weak => 'Weak',
      CallQualityTier.reconnecting => 'Reconnecting',
    };
  }
}

class CallStatsSample {
  const CallStatsSample({
    required this.rttMs,
    required this.packetsLost,
    required this.packetsReceived,
  });

  final double? rttMs;
  final int packetsLost;
  final int packetsReceived;
}

class CallQualityEngine {
  CallQualityEngine._();

  /// Deterministic polite/impolite role tie-breaker for simultaneous ICE-restart
  /// glare when both phones switch networks at the exact same instant.
  static bool isPoliteIcePeer({
    required String localUid,
    required String peerUid,
  }) =>
      localUid.compareTo(peerUid) < 0;

  /// Evaluates live WebRTC RTT (ms) and packet loss (%) into a quality tier.
  static CallQualityTier evaluateTier({
    required double? rttMs,
    required double lossPercent,
    required bool reconnecting,
  }) {
    if (reconnecting) return CallQualityTier.reconnecting;
    if (lossPercent >= 8.0 || (rttMs != null && rttMs >= 420.0)) {
      return CallQualityTier.weak;
    }
    if (lossPercent >= 4.0 || (rttMs != null && rttMs >= 250.0)) {
      return CallQualityTier.fair;
    }
    if (lossPercent >= 1.5 || (rttMs != null && rttMs >= 130.0)) {
      return CallQualityTier.good;
    }
    return CallQualityTier.hd;
  }

  /// Maps a network tier + Data/Battery Saver + device RAM class to concrete
  /// RTP video/audio encoding limits.
  static CallQualityProfile profileFor(
    CallQualityTier tier, {
    required bool dataSaver,
    required bool lowRamDevice,
  }) {
    if (dataSaver) {
      return CallQualityProfile(
        tier: tier,
        maxVideoBitrateBps: tier == CallQualityTier.weak ? 140000 : 260000,
        maxFramerate: tier == CallQualityTier.weak ? 12 : 15,
        scaleResolutionDownBy: tier == CallQualityTier.weak ? 2.0 : 1.6,
        maxAudioBitrateBps: 28000,
        label: 'Saver',
      );
    }
    return switch (tier) {
      CallQualityTier.hd => CallQualityProfile(
          tier: CallQualityTier.hd,
          maxVideoBitrateBps: lowRamDevice ? 720000 : 1100000,
          maxFramerate: lowRamDevice ? 20 : 24,
          scaleResolutionDownBy: 1.0,
          maxAudioBitrateBps: 40000,
          label: 'HD',
        ),
      CallQualityTier.good => CallQualityProfile(
          tier: CallQualityTier.good,
          maxVideoBitrateBps: lowRamDevice ? 480000 : 620000,
          maxFramerate: 20,
          scaleResolutionDownBy: 1.25,
          maxAudioBitrateBps: 36000,
          label: 'Good',
        ),
      CallQualityTier.fair => const CallQualityProfile(
          tier: CallQualityTier.fair,
          maxVideoBitrateBps: 320000,
          maxFramerate: 15,
          scaleResolutionDownBy: 1.6,
          maxAudioBitrateBps: 32000,
          label: 'Fair',
        ),
      CallQualityTier.weak || CallQualityTier.reconnecting => const CallQualityProfile(
          tier: CallQualityTier.weak,
          maxVideoBitrateBps: 160000,
          maxFramerate: 12,
          scaleResolutionDownBy: 2.0,
          maxAudioBitrateBps: 24000,
          label: 'Weak',
        ),
    };
  }

  /// Computes incremental packet loss percentage between two consecutive stats snapshots.
  static double computeLossPercent({
    required int prevLost,
    required int prevReceived,
    required int currLost,
    required int currReceived,
  }) {
    final deltaLost = currLost - prevLost;
    final deltaRecv = currReceived - prevReceived;
    if (deltaLost <= 0) return 0.0;
    final total = deltaLost + (deltaRecv > 0 ? deltaRecv : 0);
    if (total <= 0) return 0.0;
    return ((deltaLost / total) * 100.0).clamp(0.0, 100.0).toDouble();
  }

  /// Extracts active candidate-pair RTT (ms) and inbound RTP packet counts from
  /// normalized WebRTC stats reports.
  static CallStatsSample extractStatsSample(
    Iterable<({String type, Map<dynamic, dynamic> values})> reports,
  ) {
    double? rttMs;
    var packetsLost = 0;
    var packetsReceived = 0;

    for (final report in reports) {
      final type = report.type;
      final values = report.values;
      if (type == 'candidate-pair') {
        final state = values['state']?.toString();
        final nominated = values['nominated'] == true;
        final selected = state == 'succeeded' || nominated;
        if (selected && values['currentRoundTripTime'] is num) {
          final rttSec = (values['currentRoundTripTime'] as num).toDouble();
          if (rttSec >= 0 && rttSec < 15.0) {
            rttMs = rttSec * 1000.0;
          }
        }
      } else if (type == 'remote-inbound-rtp' && rttMs == null) {
        if (values['roundTripTime'] is num) {
          final rttSec = (values['roundTripTime'] as num).toDouble();
          if (rttSec >= 0 && rttSec < 15.0) {
            rttMs = rttSec * 1000.0;
          }
        }
      } else if (type == 'inbound-rtp') {
        final lost = (values['packetsLost'] as num?)?.toInt() ?? 0;
        final recv = (values['packetsReceived'] as num?)?.toInt() ?? 0;
        if (lost > 0) packetsLost += lost;
        if (recv > 0) packetsReceived += recv;
      }
    }
    return CallStatsSample(
      rttMs: rttMs,
      packetsLost: packetsLost,
      packetsReceived: packetsReceived,
    );
  }

  /// Tunes an SDP offer or answer:
  /// 1. Configures Opus with in-band FEC (`useinbandfec=1`), silence suppression
  ///    (`usedtx=1`), low framing (`minptime=10`), and a clear voice bitrate ceiling.
  /// 2. Prioritizes hardware-accelerated H264 and VP8 video codecs so Android
  ///    mid-range & low-RAM chips offload video encoding off the CPU.
  static String tuneSdpForVoiceAndHardwareVideo(
    String sdp, {
    bool dataSaver = false,
  }) {
    if (sdp.isEmpty) return sdp;
    final hasCrlf = sdp.contains('\r\n');
    final sep = hasCrlf ? '\r\n' : '\n';
    final lines = sdp.replaceAll('\r\n', '\n').split('\n');

    final tunedAudio = _tuneOpusFmtp(lines, dataSaver: dataSaver);
    final tunedAll = _prioritizeHardwareVideoCodecs(tunedAudio);
    return tunedAll.join(sep);
  }

  static List<String> _tuneOpusFmtp(List<String> lines, {required bool dataSaver}) {
    final out = List<String>.of(lines);
    final rtpmapRegex = RegExp(r'^a=rtpmap:(\d+)\s+opus/48000', caseSensitive: false);
    String? opusPt;
    int? opusRtpmapIdx;
    for (var i = 0; i < out.length; i++) {
      final m = rtpmapRegex.firstMatch(out[i]);
      if (m != null) {
        opusPt = m.group(1);
        opusRtpmapIdx = i;
        break;
      }
    }
    if (opusPt == null || opusRtpmapIdx == null) return out;

    final targetBitrate = dataSaver ? '28000' : '36000';
    final desired = <String, String>{
      'minptime': '10',
      'useinbandfec': '1',
      'usedtx': '1',
      'maxaveragebitrate': targetBitrate,
    };

    final fmtpPrefix = 'a=fmtp:$opusPt ';
    var fmtpIdx = -1;
    for (var i = 0; i < out.length; i++) {
      if (out[i].startsWith(fmtpPrefix)) {
        fmtpIdx = i;
        break;
      }
    }

    if (fmtpIdx >= 0) {
      final existingRaw = out[fmtpIdx].substring(fmtpPrefix.length).trim();
      final params = <String, String>{};
      final bareTokens = <String>[];
      for (final part in existingRaw.split(';')) {
        final trimmed = part.trim();
        if (trimmed.isEmpty) continue;
        final eq = trimmed.indexOf('=');
        if (eq > 0) {
          params[trimmed.substring(0, eq).trim()] = trimmed.substring(eq + 1).trim();
        } else {
          bareTokens.add(trimmed);
        }
      }
      params.addAll(desired);
      final rebuilt = <String>[
        ...bareTokens,
        for (final entry in params.entries) '${entry.key}=${entry.value}',
      ].join(';');
      out[fmtpIdx] = '$fmtpPrefix$rebuilt';
    } else {
      final rebuilt = desired.entries.map((e) => '${e.key}=${e.value}').join(';');
      out.insert(opusRtpmapIdx + 1, '$fmtpPrefix$rebuilt');
    }
    return out;
  }

  static List<String> _prioritizeHardwareVideoCodecs(List<String> lines) {
    final out = List<String>.of(lines);
    var videoMLineIdx = -1;
    for (var i = 0; i < out.length; i++) {
      if (out[i].startsWith('m=video ')) {
        videoMLineIdx = i;
        break;
      }
    }
    if (videoMLineIdx < 0) return out;

    var videoEndIdx = out.length;
    for (var i = videoMLineIdx + 1; i < out.length; i++) {
      if (out[i].startsWith('m=')) {
        videoEndIdx = i;
        break;
      }
    }

    final h264Pts = <String>[];
    final vp8Pts = <String>[];
    final rtpmapRegex = RegExp(r'^a=rtpmap:(\d+)\s+([A-Za-z0-9_-]+)/');
    for (var i = videoMLineIdx + 1; i < videoEndIdx; i++) {
      final m = rtpmapRegex.firstMatch(out[i]);
      if (m == null) continue;
      final pt = m.group(1)!;
      final codec = m.group(2)!.toUpperCase();
      if (codec == 'H264') {
        h264Pts.add(pt);
      } else if (codec == 'VP8') {
        vp8Pts.add(pt);
      }
    }
    if (h264Pts.isEmpty && vp8Pts.isEmpty) return out;

    final tokens = out[videoMLineIdx].split(' ');
    if (tokens.length <= 4) return out;
    final header = tokens.sublist(0, 3);
    final payloads = tokens.sublist(3);
    final preferred = <String>[
      ...h264Pts.where(payloads.contains),
      ...vp8Pts.where(payloads.contains),
    ];
    final remaining = payloads.where((pt) => !preferred.contains(pt)).toList();
    out[videoMLineIdx] = <String>[...header, ...preferred, ...remaining].join(' ');
    return out;
  }
}
