import 'package:flutter/services.dart';

/// Coordinated, frame-throttled tactile feedback engine inspired by OriginOS 7.
/// Guarantees haptics never fire on every animation frame and degrade silently
/// on devices without haptic motors or in headless test environments.
class OriginHaptics {
  OriginHaptics._();

  static const Duration _minGap = Duration(milliseconds: 28);
  static DateTime? _lastFiredAt;

  static bool _canFire() {
    final now = DateTime.now();
    final last = _lastFiredAt;
    if (last != null && now.difference(last) < _minGap) {
      return false;
    }
    _lastFiredAt = now;
    return true;
  }

  static Future<void> _safe(Future<void> Function() action) async {
    if (!_canFire()) return;
    try {
      await action();
    } catch (_) {}
  }

  /// Light tactile tick for primary & interactive buttons.
  static void buttonTap() {
    _safe(HapticFeedback.lightImpact);
  }

  /// Crisp detent for tab selection, reaction pick, and preset switches.
  static void selection() {
    _safe(HapticFeedback.selectionClick);
  }

  /// Tactile activation for spring toggles crossing the midpoint / completing.
  static void toggle() {
    _safe(HapticFeedback.lightImpact);
  }

  /// Subtle pickup cue when a draggable surface lifts under the finger.
  static void dragStart() {
    _safe(HapticFeedback.selectionClick);
  }

  /// Detent when a sheet, card, or swipe-to-reply crosses its snap threshold.
  static void snapArrival() {
    _safe(HapticFeedback.lightImpact);
  }

  /// Distinct confirmation feedback for successful drag-and-drop commits.
  static void dropSuccess() {
    _safe(HapticFeedback.mediumImpact);
  }

  /// Soft opening impulse when an Origin bottom sheet or liquid menu expands.
  static void menuExpand() {
    _safe(HapticFeedback.lightImpact);
  }

  /// Subtle completion tick when an interactive swipe/dismiss commits.
  static void gestureComplete() {
    _safe(HapticFeedback.selectionClick);
  }

  /// Crisp droplet-rupture click when two merged liquid surfaces separate.
  static void liquidSeparate() {
    _safe(HapticFeedback.lightImpact);
  }
}
