import 'dart:math' as math;

import 'package:flutter/widgets.dart';

import 'origin_motion_presets.dart';

class OriginFluidState {
  const OriginFluidState({
    required this.direction,
    required this.stretchAlong,
    required this.compressAcross,
    required this.pullVector,
    required this.intensity,
  });

  static const OriginFluidState rest = OriginFluidState(
    direction: Offset.zero,
    stretchAlong: 1.0,
    compressAcross: 1.0,
    pullVector: Offset.zero,
    intensity: 0.0,
  );

  final Offset direction;
  final double stretchAlong;
  final double compressAcross;
  final Offset pullVector;
  final double intensity;

  bool get isRest => intensity < 0.003;

  Matrix4 buildContentTransform(Size size) {
    if (isRest || size.isEmpty) return Matrix4.identity();
    final angle = math.atan2(direction.dy, direction.dx);
    final contentAlong = 1.0 + (stretchAlong - 1.0) * 0.28;
    final contentAcross = 1.0 - (1.0 - compressAcross) * 0.28;
    final cx = size.width * 0.5;
    final cy = size.height * 0.5;
    return Matrix4.translationValues(cx, cy, 0.0) *
        Matrix4.rotationZ(angle) *
        Matrix4.diagonal3Values(contentAlong, contentAcross, 1.0) *
        Matrix4.rotationZ(-angle) *
        Matrix4.translationValues(-cx, -cy, 0.0);
  }
}

class OriginFluidPhysics {
  OriginFluidPhysics._();

  static OriginFluidState computeDeformation({
    required Offset displacement,
    Offset velocity = Offset.zero,
    double maxStretch = 0.14,
    double referenceDistance = 84.0,
    double? intensityOverride,
    BuildContext? context,
  }) {
    final scaleFactor =
        intensityOverride ?? OriginMotionEngine.effectiveIntensityFor(context);
    if (scaleFactor <= 0.0) return OriginFluidState.rest;

    final combined = displacement + velocity * 0.022;
    final mag = combined.distance;
    if (mag < 0.5) return OriginFluidState.rest;

    final dir = Offset(combined.dx / mag, combined.dy / mag);
    final rawNorm = (1.0 - 1.0 / (1.0 + mag / referenceDistance)).clamp(0.0, 1.0).toDouble();
    final intensity = (rawNorm * scaleFactor).clamp(0.0, 1.0).toDouble();

    final stretch = 1.0 + (maxStretch * intensity).clamp(0.0, 0.20).toDouble();
    final compress = (1.0 / math.sqrt(stretch)).clamp(0.88, 1.0).toDouble();
    final pullMag = (intensity * 10.5).clamp(0.0, 14.0).toDouble();

    return OriginFluidState(
      direction: dir,
      stretchAlong: stretch,
      compressAcross: compress,
      pullVector: Offset(dir.dx * pullMag, dir.dy * pullMag),
      intensity: intensity,
    );
  }

  static Path buildDeformedRRectPath(
    Size size,
    BorderRadius radius,
    OriginFluidState state,
  ) {
    final rect = Offset.zero & size;
    if (state.isRest || size.isEmpty) {
      return Path()..addRRect(radius.toRRect(rect));
    }

    final w = size.width;
    final h = size.height;
    final px = state.pullVector.dx;
    final py = state.pullVector.dy;
    final squeezeX = (1.0 - state.compressAcross) * w * 0.16 * state.direction.dy.abs();
    final squeezeY = (1.0 - state.compressAcross) * h * 0.16 * state.direction.dx.abs();

    final leftX = squeezeX + (px < 0 ? px * 0.48 : px * 0.10);
    final rightX = w - squeezeX + (px > 0 ? px * 0.48 : px * 0.10);
    final topY = squeezeY + (py < 0 ? py * 0.48 : py * 0.10);
    final bottomY = h - squeezeY + (py > 0 ? py * 0.48 : py * 0.10);

    final effW = math.max(4.0, rightX - leftX);
    final effH = math.max(4.0, bottomY - topY);
    final maxR = math.min(effW, effH) * 0.48;

    final tl = radius.topLeft.x.clamp(0.0, maxR).toDouble();
    final tr = radius.topRight.x.clamp(0.0, maxR).toDouble();
    final br = radius.bottomRight.x.clamp(0.0, maxR).toDouble();
    final bl = radius.bottomLeft.x.clamp(0.0, maxR).toDouble();

    final topMidX = (leftX + rightX) * 0.5 + px * 0.32;
    final topMidY = topY + (py < 0 ? py * 0.38 : py * 0.06);
    final bottomMidX = (leftX + rightX) * 0.5 + px * 0.32;
    final bottomMidY = bottomY + (py > 0 ? py * 0.38 : py * 0.06);
    final rightMidX = rightX + (px > 0 ? px * 0.38 : px * 0.06);
    final rightMidY = (topY + bottomY) * 0.5 + py * 0.32;
    final leftMidX = leftX + (px < 0 ? px * 0.38 : px * 0.06);
    final leftMidY = (topY + bottomY) * 0.5 + py * 0.32;

    return Path()
      ..moveTo(leftX + tl, topY)
      ..quadraticBezierTo(topMidX, topMidY, rightX - tr, topY)
      ..quadraticBezierTo(rightX, topY, rightX, topY + tr)
      ..quadraticBezierTo(rightMidX, rightMidY, rightX, bottomY - br)
      ..quadraticBezierTo(rightX, bottomY, rightX - br, bottomY)
      ..quadraticBezierTo(bottomMidX, bottomMidY, leftX + bl, bottomY)
      ..quadraticBezierTo(leftX, bottomY, leftX, bottomY - bl)
      ..quadraticBezierTo(leftMidX, leftMidY, leftX, topY + tl)
      ..quadraticBezierTo(leftX, topY, leftX + tl, topY)
      ..close();
  }

  static Path? buildLiquidBridgePath({
    required Offset centerA,
    required double radiusA,
    required Offset centerB,
    required double radiusB,
    double maxBridgeDistance = 72.0,
  }) {
    final delta = centerB - centerA;
    final dist = delta.distance;
    if (dist <= 0.5 || dist >= maxBridgeDistance + radiusA + radiusB) {
      return null;
    }

    final gap = math.max(0.0, dist - (radiusA + radiusB));
    final t = (1.0 - (gap / maxBridgeDistance)).clamp(0.0, 1.0).toDouble();
    if (t <= 0.02) return null;

    final ux = delta.dx / dist;
    final uy = delta.dy / dist;
    final nx = -uy;
    final ny = ux;

    final attachA = radiusA * (0.52 + 0.34 * t);
    final attachB = radiusB * (0.52 + 0.34 * t);
    final neckHalf = math.min(radiusA, radiusB) * (0.12 + 0.44 * t * t);

    final aOffset = centerA + Offset(ux * radiusA * 0.48, uy * radiusA * 0.48);
    final bOffset = centerB - Offset(ux * radiusB * 0.48, uy * radiusB * 0.48);

    final aTop = aOffset + Offset(nx * attachA, ny * attachA);
    final aBot = aOffset - Offset(nx * attachA, ny * attachA);
    final bTop = bOffset + Offset(nx * attachB, ny * attachB);
    final bBot = bOffset - Offset(nx * attachB, ny * attachB);

    final mid = Offset(
      (aOffset.dx + bOffset.dx) * 0.5,
      (aOffset.dy + bOffset.dy) * 0.5,
    );
    final ctrlTop = mid + Offset(nx * neckHalf, ny * neckHalf);
    final ctrlBot = mid - Offset(nx * neckHalf, ny * neckHalf);

    return Path()
      ..moveTo(aTop.dx, aTop.dy)
      ..quadraticBezierTo(ctrlTop.dx, ctrlTop.dy, bTop.dx, bTop.dy)
      ..lineTo(bBot.dx, bBot.dy)
      ..quadraticBezierTo(ctrlBot.dx, ctrlBot.dy, aBot.dx, aBot.dy)
      ..close();
  }
}

class OriginLiquidClipper extends CustomClipper<Path> {
  const OriginLiquidClipper({
    required this.radius,
    required this.state,
  });

  final BorderRadius radius;
  final OriginFluidState state;

  @override
  Path getClip(Size size) =>
      OriginFluidPhysics.buildDeformedRRectPath(size, radius, state);

  @override
  bool shouldReclip(covariant OriginLiquidClipper old) =>
      old.radius != radius ||
      old.state.pullVector != state.pullVector ||
      old.state.intensity != state.intensity;
}

class OriginLiquidBoundaryPainter extends CustomPainter {
  const OriginLiquidBoundaryPainter({
    required this.radius,
    required this.state,
    required this.fillColor,
    required this.rimColor,
    this.gradient,
    this.strokeWidth = 1.1,
  });

  final BorderRadius radius;
  final OriginFluidState state;
  final Color fillColor;
  final Color rimColor;
  final Gradient? gradient;
  final double strokeWidth;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final path = OriginFluidPhysics.buildDeformedRRectPath(size, radius, state);
    final fillPaint = Paint();
    if (gradient != null) {
      fillPaint.shader = gradient!.createShader(Offset.zero & size);
    } else {
      fillPaint.color = fillColor;
    }
    canvas.drawPath(path, fillPaint);
    if (strokeWidth > 0.0 && rimColor.a > 0.0) {
      canvas.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = strokeWidth
          ..color = rimColor,
      );
    }
  }

  @override
  bool shouldRepaint(covariant OriginLiquidBoundaryPainter old) =>
      old.radius != radius ||
      old.state.pullVector != state.pullVector ||
      old.state.intensity != state.intensity ||
      old.fillColor != fillColor ||
      old.rimColor != rimColor ||
      old.gradient != gradient ||
      old.strokeWidth != strokeWidth;
}

class OriginLiquidSurface extends StatelessWidget {
  const OriginLiquidSurface({
    required this.radius,
    required this.state,
    required this.child,
    this.fillColor = const Color(0x00000000),
    this.rimColor = const Color(0x2EFFFFFF),
    this.strokeWidth = 1.0,
    super.key,
  });

  final BorderRadius radius;
  final OriginFluidState state;
  final Widget child;
  final Color fillColor;
  final Color rimColor;
  final double strokeWidth;

  @override
  Widget build(BuildContext context) {
    if (state.isRest) return child;
    return CustomPaint(
      foregroundPainter: OriginLiquidBoundaryPainter(
        radius: radius,
        state: state,
        fillColor: fillColor,
        rimColor: rimColor.withValues(alpha: (rimColor.a * state.intensity).clamp(0.0, 1.0)),
        strokeWidth: strokeWidth,
      ),
      child: ClipPath(
        clipper: OriginLiquidClipper(radius: radius, state: state),
        child: child,
      ),
    );
  }
}

class OriginMetaballBridgePainter extends CustomPainter {
  const OriginMetaballBridgePainter({
    required this.centerA,
    required this.radiusA,
    required this.centerB,
    required this.radiusB,
    required this.color,
    this.rimColor,
    this.maxBridgeDistance = 68.0,
  });

  final Offset centerA;
  final double radiusA;
  final Offset centerB;
  final double radiusB;
  final Color color;
  final Color? rimColor;
  final double maxBridgeDistance;

  @override
  void paint(Canvas canvas, Size size) {
    final path = OriginFluidPhysics.buildLiquidBridgePath(
      centerA: centerA,
      radiusA: radiusA,
      centerB: centerB,
      radiusB: radiusB,
      maxBridgeDistance: maxBridgeDistance,
    );
    if (path == null) return;
    canvas.drawPath(path, Paint()..color = color);
    if (rimColor != null) {
      canvas.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 0.9
          ..color = rimColor!,
      );
    }
  }

  @override
  bool shouldRepaint(covariant OriginMetaballBridgePainter old) =>
      old.centerA != centerA ||
      old.centerB != centerB ||
      old.radiusA != radiusA ||
      old.radiusB != radiusB ||
      old.color != color ||
      old.rimColor != rimColor ||
      old.maxBridgeDistance != maxBridgeDistance;
}
