import 'dart:math' as math;

import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

class OriginSpringSpec {
  const OriginSpringSpec({
    required this.mass,
    required this.stiffness,
    required this.damping,
    this.distanceTolerance = 0.001,
    this.velocityTolerance = 0.005,
  });

  final double mass;
  final double stiffness;
  final double damping;
  final double distanceTolerance;
  final double velocityTolerance;

  SpringDescription get description => SpringDescription(
        mass: mass,
        stiffness: stiffness,
        damping: damping,
      );

  Tolerance get tolerance => Tolerance(
        distance: distanceTolerance,
        velocity: velocityTolerance,
      );

  double get dampingRatio => damping / (2.0 * math.sqrt(mass * stiffness));

  OriginSpringSpec copyWith({
    double? mass,
    double? stiffness,
    double? damping,
    double? distanceTolerance,
    double? velocityTolerance,
  }) =>
      OriginSpringSpec(
        mass: mass ?? this.mass,
        stiffness: stiffness ?? this.stiffness,
        damping: damping ?? this.damping,
        distanceTolerance: distanceTolerance ?? this.distanceTolerance,
        velocityTolerance: velocityTolerance ?? this.velocityTolerance,
      );
}

class OriginMotionPresets {
  OriginMotionPresets._();

  static const OriginSpringSpec general = OriginSpringSpec(
    mass: 1.0,
    stiffness: 300.0,
    damping: 22.0,
  );

  static const OriginSpringSpec soft = OriginSpringSpec(
    mass: 1.0,
    stiffness: 220.0,
    damping: 22.0,
  );

  static const OriginSpringSpec elastic = OriginSpringSpec(
    mass: 1.0,
    stiffness: 250.0,
    damping: 16.0,
  );

  static const OriginSpringSpec crisp = OriginSpringSpec(
    mass: 1.0,
    stiffness: 420.0,
    damping: 25.0,
  );

  static const OriginSpringSpec dock = OriginSpringSpec(
    mass: 1.0,
    stiffness: 360.0,
    damping: 23.0,
  );

  static const OriginSpringSpec sheet = OriginSpringSpec(
    mass: 1.0,
    stiffness: 320.0,
    damping: 28.0,
  );

  static const OriginSpringSpec toggle = OriginSpringSpec(
    mass: 1.0,
    stiffness: 460.0,
    damping: 23.0,
  );

  static const OriginSpringSpec page = OriginSpringSpec(
    mass: 1.0,
    stiffness: 310.0,
    damping: 26.0,
  );

  static const OriginSpringSpec swipeReply = OriginSpringSpec(
    mass: 1.0,
    stiffness: 440.0,
    damping: 24.0,
  );

  static const OriginSpringSpec floatingWindow = OriginSpringSpec(
    mass: 1.0,
    stiffness: 290.0,
    damping: 22.0,
  );

  static OriginSpringSpec adaptForVelocity(
    OriginSpringSpec base,
    double speedPxPerSec,
  ) {
    final normalized = (speedPxPerSec.abs() / 1600.0).clamp(0.0, 1.0).toDouble();
    final stiffnessFactor = 0.88 + normalized * 0.44;
    final dampingFactor = 0.94 + normalized * 0.22;
    return base.copyWith(
      stiffness: base.stiffness * stiffnessFactor,
      damping: base.damping * dampingFactor,
    );
  }
}

class OriginMotionEngine {
  OriginMotionEngine._();

  static const String _intensityKey = 'likedin_origin_deformation_intensity_v1';

  /// Minimum restrained default (`0.30` = 30%). Adjustable in Appearance settings.
  static const double defaultDeformationIntensity = 0.30;

  static final ValueNotifier<double> deformationIntensity =
      ValueNotifier<double>(defaultDeformationIntensity);

  static final ValueNotifier<bool> reduceMotion = ValueNotifier<bool>(false);

  static bool isLowRamDevice = false;

  static bool isReducedMotion(BuildContext? context) {
    if (reduceMotion.value) return true;
    if (context == null) return false;
    return MediaQuery.maybeDisableAnimationsOf(context) ?? false;
  }

  static double get effectiveDeformationIntensity {
    if (reduceMotion.value) return 0.0;
    final raw = deformationIntensity.value.clamp(0.0, 1.4).toDouble();
    return isLowRamDevice ? (raw * 0.85) : raw;
  }

  static double effectiveIntensityFor(BuildContext? context) {
    if (isReducedMotion(context)) return 0.0;
    final raw = deformationIntensity.value.clamp(0.0, 1.4).toDouble();
    return isLowRamDevice ? (raw * 0.85) : raw;
  }

  static Future<void> load({
    SharedPreferences? preferences,
    bool lowRamDevice = false,
    bool reducedMotion = false,
  }) async {
    isLowRamDevice = lowRamDevice;
    reduceMotion.value = reducedMotion;
    try {
      final prefs = preferences ?? await SharedPreferences.getInstance();
      final saved = prefs.getDouble(_intensityKey);
      deformationIntensity.value =
          (saved ?? defaultDeformationIntensity).clamp(0.0, 1.4).toDouble();
    } catch (_) {}
  }

  static Future<void> setDeformationIntensity(double value) async {
    final clamped = value.clamp(0.0, 1.4).toDouble();
    deformationIntensity.value = clamped;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setDouble(_intensityKey, clamped);
    } catch (_) {}
  }

  static Future<void> reset() async {
    deformationIntensity.value = defaultDeformationIntensity;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_intensityKey);
    } catch (_) {}
  }
}
