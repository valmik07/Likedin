import 'dart:math' as math;

import 'package:flutter/physics.dart';
import 'package:flutter/widgets.dart';

import 'origin_motion_presets.dart';

/// State snapshot of a 1D damped spring (`m*x'' = -k*(x - target) - c*x'`).
class OriginSpringState1D {
  const OriginSpringState1D({
    required this.position,
    required this.velocity,
  });

  final double position;
  final double velocity;
}

/// Core damped-spring solver and Flutter [SpringSimulation] factory.
///
/// Implements `F = -k*(x - target) - c*v` with configurable mass, stiffness,
/// damping, initial velocity preservation, dynamic retargeting, progressive
/// hyperbolic rubber-banding, and exact rest snapping.
class OriginSpringPhysics {
  OriginSpringPhysics._();

  /// Creates a Flutter [SpringSimulation] preserving [velocity] with tight
  /// settling tolerance so animations stop crisply at identity without lingering.
  static SpringSimulation createSimulation({
    required OriginSpringSpec spec,
    required double start,
    required double end,
    double velocity = 0.0,
    bool adaptVelocity = true,
  }) {
    final effectiveSpec = adaptVelocity
        ? OriginMotionPresets.adaptForVelocity(spec, velocity)
        : spec;
    return SpringSimulation(
      effectiveSpec.description,
      start,
      end,
      velocity,
      tolerance: effectiveSpec.tolerance,
    );
  }

  /// Advances a 1D damped spring (`m*x'' = -k*(x - target) - c*x'`) by [dt]
  /// seconds using 4th-order Runge-Kutta (RK4) integration for high numerical
  /// accuracy across 60 Hz, 90 Hz, and 120 Hz frames (and deterministic tests).
  static OriginSpringState1D step1D({
    required double position,
    required double velocity,
    required double target,
    required OriginSpringSpec spec,
    required double dt,
  }) {
    if (dt <= 0.0) {
      return OriginSpringState1D(position: position, velocity: velocity);
    }
    final safeDt = dt.clamp(0.0, 0.05).toDouble();
    final k = spec.stiffness;
    final c = spec.damping;
    final m = math.max(0.001, spec.mass);

    double accel(double x, double v) => (-k * (x - target) - c * v) / m;

    final k1x = velocity;
    final k1v = accel(position, velocity);

    final k2x = velocity + 0.5 * safeDt * k1v;
    final k2v = accel(position + 0.5 * safeDt * k1x, k2x);

    final k3x = velocity + 0.5 * safeDt * k2v;
    final k3v = accel(position + 0.5 * safeDt * k2x, k3x);

    final k4x = velocity + safeDt * k3v;
    final k4v = accel(position + safeDt * k3x, k4x);

    final nextX = position + (safeDt / 6.0) * (k1x + 2.0 * k2x + 2.0 * k3x + k4x);
    final nextV = velocity + (safeDt / 6.0) * (k1v + 2.0 * k2v + 2.0 * k3v + k4v);

    if ((nextX - target).abs() <= spec.distanceTolerance &&
        nextV.abs() <= spec.velocityTolerance) {
      return OriginSpringState1D(position: target, velocity: 0.0);
    }
    return OriginSpringState1D(position: nextX, velocity: nextV);
  }

  /// Smooth progressive hyperbolic rubber-band resistance for elastic overscroll.
  /// Resistance increases asymptotically so content never drags infinitely past edges.
  static double rubberBand(double overscroll, double limit) {
    if (overscroll == 0.0 || limit <= 0.0) return 0.0;
    final sign = overscroll < 0 ? -1.0 : 1.0;
    final abs = overscroll.abs();
    return sign * limit * (1.0 - (1.0 / (1.0 + (abs / limit))));
  }

  /// Inverse of [rubberBand] so grabbing an already-displaced elastic surface
  /// preserves exact finger continuity without jumping.
  static double inverseRubberBand(double visual, double limit) {
    if (visual == 0.0 || limit <= 0.0) return 0.0;
    final sign = visual < 0 ? -1.0 : 1.0;
    final clampedAbs = visual.abs().clamp(0.0, limit * 0.96).toDouble();
    return sign * limit * (clampedAbs / (limit - clampedAbs));
  }

  /// Projects where a surface moving at [velocity] will naturally decelerate to,
  /// enabling velocity-aware snap-point selection for sheets, cards, and tabs.
  static double projectPosition({
    required double position,
    required double velocity,
    double decelerationRate = 0.996,
  }) {
    if (velocity.abs() < 1.0) return position;
    return position + (velocity / 1000.0) * decelerationRate / (1.0 - decelerationRate);
  }
}

/// Reusable interruptible 2D + Scale spring controller built on Flutter's
/// unbounded [AnimationController]s.
///
/// Key guarantees:
///  * Calling [grab] mid-flight stops springs immediately WITHOUT resetting position.
///  * Calling [springTo] preserves current animation velocity (or uses explicit
///    gesture release velocity) and supports dynamic mid-flight retargeting.
///  * Snaps cleanly to exact target values on completion so idle widgets never
///    waste GPU resampling or keep tickers awake.
class OriginMotionController extends ChangeNotifier {
  OriginMotionController({
    required TickerProvider vsync,
    Offset initialOffset = Offset.zero,
    double initialScale = 1.0,
  })  : _xCtrl = AnimationController.unbounded(vsync: vsync, value: initialOffset.dx),
        _yCtrl = AnimationController.unbounded(vsync: vsync, value: initialOffset.dy),
        _scaleCtrl = AnimationController.unbounded(vsync: vsync, value: initialScale) {
    _xCtrl.addListener(notifyListeners);
    _yCtrl.addListener(notifyListeners);
    _scaleCtrl.addListener(notifyListeners);
  }

  final AnimationController _xCtrl;
  final AnimationController _yCtrl;
  final AnimationController _scaleCtrl;
  bool _disposed = false;

  Offset get offset => Offset(_xCtrl.value, _yCtrl.value);
  Offset get velocity => Offset(_xCtrl.velocity, _yCtrl.velocity);
  double get scale => _scaleCtrl.value;
  double get scaleVelocity => _scaleCtrl.velocity;
  bool get isAnimating =>
      _xCtrl.isAnimating || _yCtrl.isAnimating || _scaleCtrl.isAnimating;

  /// Interrupts any active spring without resetting position or scale.
  void grab() {
    if (_disposed) return;
    _xCtrl.stop(canceled: false);
    _yCtrl.stop(canceled: false);
    _scaleCtrl.stop(canceled: false);
  }

  /// Directly sets 2D offset during active pointer tracking.
  void jumpToOffset(Offset value) {
    if (_disposed) return;
    _xCtrl.value = value.dx;
    _yCtrl.value = value.dy;
  }

  /// Directly sets scale during active pointer press/pinch.
  void jumpToScale(double value) {
    if (_disposed) return;
    _scaleCtrl.value = value;
  }

  /// Drives X and Y to [target] with velocity-aware spring physics.
  void springOffsetTo(
    Offset target, {
    Offset? velocity,
    OriginSpringSpec spec = OriginMotionPresets.general,
    bool adaptVelocity = true,
  }) {
    if (_disposed) return;
    if (OriginMotionEngine.reduceMotion.value) {
      jumpToOffset(target);
      return;
    }
    final vx = (velocity?.dx ?? _xCtrl.velocity).clamp(-4500.0, 4500.0).toDouble();
    final vy = (velocity?.dy ?? _yCtrl.velocity).clamp(-4500.0, 4500.0).toDouble();
    final speed = math.sqrt(vx * vx + vy * vy);
    final effective = adaptVelocity
        ? OriginMotionPresets.adaptForVelocity(spec, speed)
        : spec;

    _xCtrl
        .animateWith(
          SpringSimulation(
            effective.description,
            _xCtrl.value,
            target.dx,
            vx,
            tolerance: effective.tolerance,
          ),
        )
        .whenComplete(() {
      if (!_disposed && !_xCtrl.isAnimating && (_xCtrl.value - target.dx).abs() < 0.05) {
        _xCtrl.value = target.dx;
      }
    });
    _yCtrl
        .animateWith(
          SpringSimulation(
            effective.description,
            _yCtrl.value,
            target.dy,
            vy,
            tolerance: effective.tolerance,
          ),
        )
        .whenComplete(() {
      if (!_disposed && !_yCtrl.isAnimating && (_yCtrl.value - target.dy).abs() < 0.05) {
        _yCtrl.value = target.dy;
      }
    });
  }

  /// Drives scale to [target] with spring physics, snapping cleanly on settle.
  void springScaleTo(
    double target, {
    double? velocity,
    OriginSpringSpec spec = OriginMotionPresets.crisp,
  }) {
    if (_disposed) return;
    if (OriginMotionEngine.reduceMotion.value) {
      jumpToScale(target);
      return;
    }
    final v = (velocity ?? _scaleCtrl.velocity).clamp(-20.0, 20.0).toDouble();
    _scaleCtrl
        .animateWith(
          SpringSimulation(
            spec.description,
            _scaleCtrl.value,
            target,
            v,
            tolerance: const Tolerance(distance: 0.0005, velocity: 0.002),
          ),
        )
        .whenComplete(() {
      if (!_disposed && !_scaleCtrl.isAnimating && (_scaleCtrl.value - target).abs() < 0.005) {
        _scaleCtrl.value = target;
      }
    });
  }

  @override
  void dispose() {
    _disposed = true;
    _xCtrl.dispose();
    _yCtrl.dispose();
    _scaleCtrl.dispose();
    super.dispose();
  }
}

/// A [Curve] backed directly by our damped-spring differential equation
/// (`F = -kx - cv`), allowing [OriginPageRoute] forward/reverse transitions to
/// follow true spring kinematics while preserving exact Navigator route status
/// (`completed` / `dismissed`) and mid-flight edge-swipe interruption.
class OriginSpringCurve extends Curve {
  const OriginSpringCurve(
    this.spec, {
    this.durationSeconds = 0.36,
  });

  final OriginSpringSpec spec;
  final double durationSeconds;

  @override
  double transformInternal(double t) {
    final sim = SpringSimulation(spec.description, 0.0, 1.0, 0.0);
    return sim.x(t * durationSeconds);
  }
}
