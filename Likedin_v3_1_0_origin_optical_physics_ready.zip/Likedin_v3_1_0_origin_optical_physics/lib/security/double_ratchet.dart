import 'dart:convert';
import 'dart:math';

import 'package:cryptography/cryptography.dart';

/// Pure-Dart Signal-style Double Ratchet (X25519 DH ratchet + HKDF-SHA256 root
/// KDF + HMAC-SHA256 symmetric chain KDF + AES-256-GCM AEAD with header AAD).
///
/// Provides per-message forward secrecy and post-compromise security with zero
/// native/Rust dependencies, deterministic handling of simultaneous first
/// messages for a 2-user pair, and bounded skipped-key storage for out-of-order
/// delivery.
class DoubleRatchetSession {
  DoubleRatchetSession._({
    required this.sessionId,
    required this.userId,
    required this.peerId,
    required this.initialRootKey,
    required this.ownIdentityPriv,
    required this.ownIdentityPub,
    required this.peerIdentityPub,
    required List<int> rootKey,
    required List<int> dhSelfPriv,
    required List<int> dhSelfPub,
    List<int>? dhRemotePub,
    List<int>? sendChainKey,
    List<int>? recvChainKey,
    int sendCount = 0,
    int recvCount = 0,
    int prevSendCount = 0,
    int revision = 0,
    Map<String, List<int>>? skippedKeys,
    String? altInitDhPubB64,
    List<int>? altInitRecvChainKey,
    int altInitRecvCount = 0,
  })  : _rootKey = List<int>.of(rootKey),
        _dhSelfPriv = List<int>.of(dhSelfPriv),
        _dhSelfPub = List<int>.of(dhSelfPub),
        _dhRemotePub = dhRemotePub == null ? null : List<int>.of(dhRemotePub),
        _sendChainKey = sendChainKey == null ? null : List<int>.of(sendChainKey),
        _recvChainKey = recvChainKey == null ? null : List<int>.of(recvChainKey),
        _sendCount = sendCount,
        _recvCount = recvCount,
        _prevSendCount = prevSendCount,
        _revision = revision,
        _skippedKeys = skippedKeys == null
            ? <String, List<int>>{}
            : <String, List<int>>{
                for (final e in skippedKeys.entries) e.key: List<int>.of(e.value),
              },
        _altInitDhPubB64 = altInitDhPubB64,
        _altInitRecvChainKey =
            altInitRecvChainKey == null ? null : List<int>.of(altInitRecvChainKey),
        _altInitRecvCount = altInitRecvCount;

  static const String envelopeMarker = '__likedin_e2ee_v2';
  static const int maxSkipPerStep = 120;
  static const int maxStoredSkippedKeys = 400;

  static final X25519 _x25519 = X25519();
  static final AesGcm _aesGcm = AesGcm.with256bits();
  static final Hkdf _hkdf64 = Hkdf(hmac: Hmac.sha256(), outputLength: 64);
  static final Hkdf _hkdf32 = Hkdf(hmac: Hmac.sha256(), outputLength: 32);
  static final Hmac _hmacSha256 = Hmac.sha256();
  static final Sha256 _sha256 = Sha256();

  /// Unique identifier generated whenever a Double Ratchet session is created
  /// or reset. Used to detect stale cached ciphertexts across re-pairing/resets.
  final String sessionId;
  final String userId;
  final String peerId;
  final List<int> initialRootKey;
  final List<int> ownIdentityPriv;
  final List<int> ownIdentityPub;
  final List<int> peerIdentityPub;

  List<int> _rootKey;
  List<int> _dhSelfPriv;
  List<int> _dhSelfPub;
  List<int>? _dhRemotePub;
  List<int>? _sendChainKey;
  List<int>? _recvChainKey;
  int _sendCount;
  int _recvCount;
  int _prevSendCount;
  int _revision;
  final Map<String, List<int>> _skippedKeys;

  // Auxiliary initial receive chain used only if both peers simultaneously send
  // their very first v2 message before seeing each other's ephemeral DH key.
  String? _altInitDhPubB64;
  List<int>? _altInitRecvChainKey;
  int _altInitRecvCount;

  int get revision => _revision;
  int get sendCount => _sendCount;
  int get recvCount => _recvCount;
  int get skippedKeyCount => _skippedKeys.length;
  String get ownRatchetPublicKeyBase64 => base64Encode(_dhSelfPub);
  String? get remoteRatchetPublicKeyBase64 =>
      _dhRemotePub == null ? null : base64Encode(_dhRemotePub!);

  static bool isV2Envelope(String text) =>
      text.startsWith('{"$envelopeMarker":2,');

  /// Computes a deterministic 32-byte base64 envelope ID from header + MAC for
  /// local decrypted-plaintext caching without storing any key material.
  static Future<String> envelopeFingerprint(String envelopeJson) async {
    final digest = await _sha256.hash(utf8.encode(envelopeJson));
    return base64Url.encode(digest.bytes).replaceAll('=', '');
  }

  /// Creates a fresh Double Ratchet session bootstrapped from the pair's
  /// authenticated X25519 identity keys. Both peers derive the exact same
  /// initial 32-byte root key `RK_0` and can send first in any order (including
  /// simultaneous crossing first messages).
  static Future<DoubleRatchetSession> create({
    required String userId,
    required String peerId,
    required List<int> ownIdentityPriv,
    required List<int> ownIdentityPub,
    required List<int> peerIdentityPub,
  }) async {
    final sk = await _deriveInitialRootKey(
      ownIdentityPriv: ownIdentityPriv,
      ownIdentityPub: ownIdentityPub,
      peerIdentityPub: peerIdentityPub,
    );
    // Start with our identity key pair as the initial DH receiving key so
    // whichever peer sends first can immediately ratchet against our known
    // identity public key without an extra network round trip.
    final sid = base64Url.encode(_randomBytes(16)).replaceAll('=', '');
    return DoubleRatchetSession._(
      sessionId: sid,
      userId: userId,
      peerId: peerId,
      initialRootKey: sk,
      ownIdentityPriv: ownIdentityPriv,
      ownIdentityPub: ownIdentityPub,
      peerIdentityPub: peerIdentityPub,
      rootKey: sk,
      dhSelfPriv: ownIdentityPriv,
      dhSelfPub: ownIdentityPub,
    );
  }

  /// Encrypts [plaintext] into an authenticated v2 Double Ratchet envelope and
  /// advances the sending chain immediately, destroying the ephemeral message key.
  Future<String> encrypt(String plaintext) async {
    // If we have not yet established a sending chain, generate a fresh ephemeral
    // X25519 key pair and perform a DH ratchet step against the peer's latest
    // DH public key (or peer's identity public key on the very first message).
    if (_sendChainKey == null) {
      final targetRemotePub = _dhRemotePub ?? peerIdentityPub;
      final freshPair = await _x25519.newKeyPair();
      final freshPriv = await freshPair.extractPrivateKeyBytes();
      final freshPub = (await freshPair.extractPublicKey()).bytes;
      final dhOut = await _dh(freshPriv, targetRemotePub);
      final kdf = await _kdfRootKey(_rootKey, dhOut);
      _prevSendCount = _sendCount;
      _sendCount = 0;
      _dhSelfPriv = freshPriv;
      _dhSelfPub = freshPub;
      _dhRemotePub = List<int>.of(targetRemotePub);
      _rootKey = kdf.rootKey;
      _sendChainKey = kdf.chainKey;
    }

    final step = await _kdfChainKey(_sendChainKey!);
    _sendChainKey = step.nextChainKey;
    final msgNumber = _sendCount;
    _sendCount++;
    _revision++;

    final dhB64 = base64Encode(_dhSelfPub);
    final rpkB64 = await _keyTag(_dhRemotePub ?? peerIdentityPub);
    final aad = _headerAad(
      dhB64: dhB64,
      prevCount: _prevSendCount,
      msgNumber: msgNumber,
      rpkB64: rpkB64,
    );
    final nonce = _randomBytes(12);
    final box = await _aesGcm.encrypt(
      utf8.encode(plaintext),
      secretKey: SecretKey(step.messageKey),
      nonce: nonce,
      aad: aad,
    );

    return jsonEncode(<String, Object>{
      envelopeMarker: 2,
      'dh': dhB64,
      'pn': _prevSendCount,
      'n': msgNumber,
      'rpk': rpkB64,
      'n2': base64Encode(box.nonce),
      'c': base64Encode(box.cipherText),
      'm': base64Encode(box.mac.bytes),
    });
  }

  /// Decrypts an incoming v2 Double Ratchet envelope, advancing the DH/chain
  /// ratchets and deleting the consumed ephemeral message key immediately.
  Future<String> decrypt(String envelopeJson) async {
    final decoded = jsonDecode(envelopeJson);
    if (decoded is! Map || decoded[envelopeMarker] != 2) {
      throw const FormatException('Not a Double Ratchet v2 envelope.');
    }
    final dhB64 = decoded['dh']?.toString() ?? '';
    final pn = (decoded['pn'] as num?)?.toInt();
    final n = (decoded['n'] as num?)?.toInt();
    final rpkB64 = decoded['rpk']?.toString() ?? '';
    final nonceB64 = decoded['n2']?.toString() ?? '';
    final cipherB64 = decoded['c']?.toString() ?? '';
    final macB64 = decoded['m']?.toString() ?? '';
    if (dhB64.isEmpty ||
        pn == null ||
        n == null ||
        pn < 0 ||
        n < 0 ||
        rpkB64.isEmpty ||
        nonceB64.isEmpty ||
        cipherB64.isEmpty ||
        macB64.isEmpty) {
      throw const FormatException('Incomplete Double Ratchet v2 envelope.');
    }
    final remoteDhBytes = base64Decode(dhB64);
    if (remoteDhBytes.length != 32) {
      throw const FormatException('Invalid Double Ratchet DH public key length.');
    }
    final nonce = base64Decode(nonceB64);
    final cipherText = base64Decode(cipherB64);
    final macBytes = base64Decode(macB64);
    final aad = _headerAad(
      dhB64: dhB64,
      prevCount: pn,
      msgNumber: n,
      rpkB64: rpkB64,
    );

    // 1. Check skipped message keys first (out-of-order delivery).
    final skipKeyId = _skippedKeyId(dhB64, n);
    final skippedMk = _skippedKeys[skipKeyId];
    if (skippedMk != null) {
      final clear = await _decryptWithKey(
        messageKey: skippedMk,
        nonce: nonce,
        cipherText: cipherText,
        macBytes: macBytes,
        aad: aad,
      );
      _skippedKeys.remove(skipKeyId);
      _revision++;
      return clear;
    }

    // 2. Same active receiving DH chain -> advance symmetric receiving chain.
    if (_dhRemotePub != null &&
        _recvChainKey != null &&
        _bytesEqual(_dhRemotePub!, remoteDhBytes)) {
      if (n < _recvCount) {
        throw StateError('Duplicate or already-consumed Double Ratchet message.');
      }
      final staged = await _advanceChainTo(
        chainKey: _recvChainKey!,
        currentCount: _recvCount,
        targetCount: n,
        dhB64: dhB64,
      );
      final clear = await _decryptWithKey(
        messageKey: staged.messageKey,
        nonce: nonce,
        cipherText: cipherText,
        macBytes: macBytes,
        aad: aad,
      );
      _commitSkipped(staged.skipped);
      _recvChainKey = staged.nextChainKey;
      _recvCount = n + 1;
      _revision++;
      return clear;
    }

    // 3. Auxiliary simultaneous-first-message chain (if both peers sent their
    // very first v2 message before receiving each other's ephemeral DH key).
    if (_altInitDhPubB64 == dhB64 && _altInitRecvChainKey != null) {
      if (n < _altInitRecvCount) {
        throw StateError('Already-consumed simultaneous initial ratchet message.');
      }
      final staged = await _advanceChainTo(
        chainKey: _altInitRecvChainKey!,
        currentCount: _altInitRecvCount,
        targetCount: n,
        dhB64: dhB64,
      );
      final clear = await _decryptWithKey(
        messageKey: staged.messageKey,
        nonce: nonce,
        cipherText: cipherText,
        macBytes: macBytes,
        aad: aad,
      );
      _commitSkipped(staged.skipped);
      _altInitRecvChainKey = staged.nextChainKey;
      _altInitRecvCount = n + 1;
      _revision++;
      return clear;
    }

    final ownIdentityTag = await _keyTag(ownIdentityPub);
    final ownCurrentDhTag = await _keyTag(_dhSelfPub);

    // 4. Simultaneous crossing first message: peer encrypted against our
    // long-term identity public key (`rpk == tag(ownIdentityPub)`) while we had
    // already rotated `_dhSelfPub` to a fresh ephemeral key on our own first send!
    if (rpkB64 == ownIdentityTag && ownCurrentDhTag != ownIdentityTag) {
      final dhOut = await _dh(ownIdentityPriv, remoteDhBytes);
      final initKdf = await _kdfRootKey(initialRootKey, dhOut);
      final staged = await _advanceChainTo(
        chainKey: initKdf.chainKey,
        currentCount: 0,
        targetCount: n,
        dhB64: dhB64,
      );
      final clear = await _decryptWithKey(
        messageKey: staged.messageKey,
        nonce: nonce,
        cipherText: cipherText,
        macBytes: macBytes,
        aad: aad,
      );
      _commitSkipped(staged.skipped);
      // Deterministic convergence: smaller userId keeps its initiated DH chain;
      // larger userId converges onto the peer's ephemeral DH key for next send.
      if (userId.compareTo(peerId) > 0) {
        _rootKey = initKdf.rootKey;
        _dhRemotePub = List<int>.of(remoteDhBytes);
        _recvChainKey = staged.nextChainKey;
        _recvCount = n + 1;
        _prevSendCount = _sendCount;
        _sendCount = 0;
        _sendChainKey = null; // Forces fresh DH ratchet step on next send!
      } else {
        _altInitDhPubB64 = dhB64;
        _altInitRecvChainKey = staged.nextChainKey;
        _altInitRecvCount = n + 1;
      }
      _revision++;
      return clear;
    }

    // 5. Standard Signal Double Ratchet DH step (new remote DH public key).
    // Stage all skipped keys & new state BEFORE mutating so tampered messages
    // can never corrupt the ratchet state!
    final prevSkipped = <String, List<int>>{};
    if (_recvChainKey != null && _dhRemotePub != null) {
      final prevDhB64 = base64Encode(_dhRemotePub!);
      if (pn > _recvCount) {
        final gap = pn - _recvCount;
        if (gap > maxSkipPerStep) {
          throw StateError('Too many skipped messages ($gap) in previous ratchet chain.');
        }
        var ck = _recvChainKey!;
        for (var i = _recvCount; i < pn; i++) {
          final s = await _kdfChainKey(ck);
          prevSkipped[_skippedKeyId(prevDhB64, i)] = s.messageKey;
          ck = s.nextChainKey;
        }
      }
    }

    final dhRecvOut = await _dh(_dhSelfPriv, remoteDhBytes);
    final kdfRecv = await _kdfRootKey(_rootKey, dhRecvOut);
    final staged = await _advanceChainTo(
      chainKey: kdfRecv.chainKey,
      currentCount: 0,
      targetCount: n,
      dhB64: dhB64,
    );

    // Authenticate & decrypt BEFORE committing the new ratchet state.
    final clear = await _decryptWithKey(
      messageKey: staged.messageKey,
      nonce: nonce,
      cipherText: cipherText,
      macBytes: macBytes,
      aad: aad,
    );

    // Perform fresh DH sending ratchet step for post-compromise security.
    final nextPair = await _x25519.newKeyPair();
    final nextPriv = await nextPair.extractPrivateKeyBytes();
    final nextPub = (await nextPair.extractPublicKey()).bytes;
    final dhSendOut = await _dh(nextPriv, remoteDhBytes);
    final kdfSend = await _kdfRootKey(kdfRecv.rootKey, dhSendOut);

    _commitSkipped(prevSkipped);
    _commitSkipped(staged.skipped);
    _dhRemotePub = List<int>.of(remoteDhBytes);
    _recvChainKey = staged.nextChainKey;
    _recvCount = n + 1;
    _prevSendCount = _sendCount;
    _sendCount = 0;
    _dhSelfPriv = nextPriv;
    _dhSelfPub = nextPub;
    _rootKey = kdfSend.rootKey;
    _sendChainKey = kdfSend.chainKey;
    _altInitDhPubB64 = null;
    _altInitRecvChainKey = null;
    _altInitRecvCount = 0;
    _revision++;
    return clear;
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'v': 2,
        'sid': sessionId,
        'uid': userId,
        'pid': peerId,
        'irk': base64Encode(initialRootKey),
        'rk': base64Encode(_rootKey),
        'dhs_priv': base64Encode(_dhSelfPriv),
        'dhs_pub': base64Encode(_dhSelfPub),
        if (_dhRemotePub != null) 'dhr_pub': base64Encode(_dhRemotePub!),
        if (_sendChainKey != null) 'cks': base64Encode(_sendChainKey!),
        if (_recvChainKey != null) 'ckr': base64Encode(_recvChainKey!),
        'ns': _sendCount,
        'nr': _recvCount,
        'pn': _prevSendCount,
        'rev': _revision,
        'skip': <String, String>{
          for (final e in _skippedKeys.entries) e.key: base64Encode(e.value),
        },
        if (_altInitDhPubB64 != null) 'alt_dh': _altInitDhPubB64,
        if (_altInitRecvChainKey != null) 'alt_ckr': base64Encode(_altInitRecvChainKey!),
        'alt_nr': _altInitRecvCount,
      };

  static DoubleRatchetSession? fromJson(
    Map<String, dynamic> map, {
    required String userId,
    required String peerId,
    required List<int> ownIdentityPriv,
    required List<int> ownIdentityPub,
    required List<int> peerIdentityPub,
  }) {
    try {
      if (map['v'] != 2 || map['uid'] != userId || map['pid'] != peerId) {
        return null;
      }
      final irk = base64Decode(map['irk'].toString());
      final rk = base64Decode(map['rk'].toString());
      final dhsPriv = base64Decode(map['dhs_priv'].toString());
      final dhsPub = base64Decode(map['dhs_pub'].toString());
      if (irk.length != 32 ||
          rk.length != 32 ||
          dhsPriv.length != 32 ||
          dhsPub.length != 32) {
        return null;
      }
      final dhrPub = map['dhr_pub'] == null ? null : base64Decode(map['dhr_pub'].toString());
      final cks = map['cks'] == null ? null : base64Decode(map['cks'].toString());
      final ckr = map['ckr'] == null ? null : base64Decode(map['ckr'].toString());
      final altCkr = map['alt_ckr'] == null ? null : base64Decode(map['alt_ckr'].toString());
      final rawSkip = map['skip'];
      final skipped = <String, List<int>>{};
      if (rawSkip is Map) {
        for (final entry in rawSkip.entries) {
          final mk = base64Decode(entry.value.toString());
          if (mk.length == 32) skipped[entry.key.toString()] = mk;
        }
      }
      final rawSid = map['sid']?.toString();
      final sid = (rawSid != null && rawSid.isNotEmpty)
          ? rawSid
          : base64Url.encode(irk.sublist(0, 16)).replaceAll('=', '');
      return DoubleRatchetSession._(
        sessionId: sid,
        userId: userId,
        peerId: peerId,
        initialRootKey: irk,
        ownIdentityPriv: ownIdentityPriv,
        ownIdentityPub: ownIdentityPub,
        peerIdentityPub: peerIdentityPub,
        rootKey: rk,
        dhSelfPriv: dhsPriv,
        dhSelfPub: dhsPub,
        dhRemotePub: dhrPub,
        sendChainKey: cks,
        recvChainKey: ckr,
        sendCount: (map['ns'] as num?)?.toInt() ?? 0,
        recvCount: (map['nr'] as num?)?.toInt() ?? 0,
        prevSendCount: (map['pn'] as num?)?.toInt() ?? 0,
        revision: (map['rev'] as num?)?.toInt() ?? 0,
        skippedKeys: skipped,
        altInitDhPubB64: map['alt_dh']?.toString(),
        altInitRecvChainKey: altCkr,
        altInitRecvCount: (map['alt_nr'] as num?)?.toInt() ?? 0,
      );
    } catch (_) {
      return null;
    }
  }

  void _commitSkipped(Map<String, List<int>> additions) {
    if (additions.isEmpty) return;
    _skippedKeys.addAll(additions);
    while (_skippedKeys.length > maxStoredSkippedKeys) {
      _skippedKeys.remove(_skippedKeys.keys.first);
    }
  }

  static String _skippedKeyId(String dhB64, int n) => '$dhB64:$n';

  static List<int> _headerAad({
    required String dhB64,
    required int prevCount,
    required int msgNumber,
    required String rpkB64,
  }) =>
      utf8.encode('likedin-dr-v2|$dhB64|$prevCount|$msgNumber|$rpkB64');

  static Future<String> _keyTag(List<int> pubKeyBytes) async {
    final hash = await _sha256.hash(pubKeyBytes);
    return base64Encode(hash.bytes.sublist(0, 8));
  }

  static Future<List<int>> _deriveInitialRootKey({
    required List<int> ownIdentityPriv,
    required List<int> ownIdentityPub,
    required List<int> peerIdentityPub,
  }) async {
    final dhBytes = await _dh(ownIdentityPriv, peerIdentityPub);
    final keysSorted = <String>[
      base64Encode(ownIdentityPub),
      base64Encode(peerIdentityPub),
    ]..sort();
    // Non-empty salt avoids the empty-HMAC-key bug in cryptography 2.7.0.
    final derived = await _hkdf32.deriveKey(
      secretKey: SecretKey(dhBytes),
      nonce: utf8.encode('likedin-dr-v2-init-salt'),
      info: utf8.encode('likedin-dr-v2-root:${keysSorted.join(':')}'),
    );
    return derived.extractBytes();
  }

  static Future<List<int>> _dh(List<int> privBytes, List<int> remotePubBytes) async {
    final pair = await _x25519.newKeyPairFromSeed(privBytes);
    final shared = await _x25519.sharedSecretKey(
      keyPair: pair,
      remotePublicKey: SimplePublicKey(remotePubBytes, type: KeyPairType.x25519),
    );
    return shared.extractBytes();
  }

  static Future<({List<int> rootKey, List<int> chainKey})> _kdfRootKey(
    List<int> rk,
    List<int> dhOut,
  ) async {
    final derived = await _hkdf64.deriveKey(
      secretKey: SecretKey(dhOut),
      nonce: rk,
      info: utf8.encode('likedin-dr-rk-v2'),
    );
    final bytes = await derived.extractBytes();
    return (
      rootKey: bytes.sublist(0, 32),
      chainKey: bytes.sublist(32, 64),
    );
  }

  static Future<({List<int> messageKey, List<int> nextChainKey})> _kdfChainKey(
    List<int> ck,
  ) async {
    final key = SecretKey(ck);
    final mkMac = await _hmacSha256.calculateMac(const <int>[0x01], secretKey: key);
    final ckMac = await _hmacSha256.calculateMac(const <int>[0x02], secretKey: key);
    return (
      messageKey: mkMac.bytes,
      nextChainKey: ckMac.bytes,
    );
  }

  static Future<({
    List<int> messageKey,
    List<int> nextChainKey,
    Map<String, List<int>> skipped,
  })> _advanceChainTo({
    required List<int> chainKey,
    required int currentCount,
    required int targetCount,
    required String dhB64,
  }) async {
    final gap = targetCount - currentCount;
    if (gap < 0) {
      throw StateError('Cannot rewind Double Ratchet chain ($targetCount < $currentCount).');
    }
    if (gap > maxSkipPerStep) {
      throw StateError('Too many skipped Double Ratchet messages ($gap).');
    }
    final skipped = <String, List<int>>{};
    var ck = chainKey;
    for (var i = currentCount; i < targetCount; i++) {
      final step = await _kdfChainKey(ck);
      skipped[_skippedKeyId(dhB64, i)] = step.messageKey;
      ck = step.nextChainKey;
    }
    final finalStep = await _kdfChainKey(ck);
    return (
      messageKey: finalStep.messageKey,
      nextChainKey: finalStep.nextChainKey,
      skipped: skipped,
    );
  }

  static Future<String> _decryptWithKey({
    required List<int> messageKey,
    required List<int> nonce,
    required List<int> cipherText,
    required List<int> macBytes,
    required List<int> aad,
  }) async {
    final clear = await _aesGcm.decrypt(
      SecretBox(cipherText, nonce: nonce, mac: Mac(macBytes)),
      secretKey: SecretKey(messageKey),
      aad: aad,
    );
    return utf8.decode(clear);
  }

  static List<int> _randomBytes(int length) {
    final rng = Random.secure();
    return List<int>.generate(length, (_) => rng.nextInt(256), growable: false);
  }

  static bool _bytesEqual(List<int> a, List<int> b) {
    if (a.length != b.length) return false;
    var diff = 0;
    for (var i = 0; i < a.length; i++) {
      diff |= a[i] ^ b[i];
    }
    return diff == 0;
  }
}
