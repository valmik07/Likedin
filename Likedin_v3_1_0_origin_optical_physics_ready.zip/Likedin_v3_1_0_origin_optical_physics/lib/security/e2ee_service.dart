import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../backend/realtime_messaging_service.dart';
import 'double_ratchet.dart';

/// Explicit E2EE lifecycle state surfaced to the UI so pending setup, active
/// Double Ratchet encryption, verified identity, key changes, and errors are
/// clearly distinguished.
enum E2eeStatus {
  /// Waiting for the paired peer to publish an X25519 public key (sending blocked).
  pending,

  /// Strict Double Ratchet session active, safety fingerprint not yet verified.
  active,

  /// Strict Double Ratchet session active and safety fingerprint manually verified.
  verified,

  /// Peer's identity key changed since the last trusted session; sending paused
  /// until the user verifies or explicitly accepts the new fingerprint.
  keyChanged,

  /// Initialization or cryptographic failure (sending blocked fail-closed).
  error,
}

/// Strict Fail-Closed End-to-End Encryption service with pure-Dart Double
/// Ratchet forward secrecy (X25519 DH ratchet + HKDF-SHA256 + HMAC-SHA256
/// chain ratchet + AES-256-GCM AEAD).
///
/// Security guarantees (v2.8.0+):
///  * **Strict fail-closed send:** Plaintext fallback is disabled. Refuses to
///    send text or upload media when the peer key is missing (`pending`), when
///    the peer's identity key changed (`keyChanged`), or on crypto errors.
///  * **Forward secrecy & post-compromise security:** Every outgoing message
///    and media metadata JSON uses a fresh Double Ratchet message key (`v2`
///    envelope) that is destroyed immediately after use.
///  * **Per-file forward-secret media:** Every uploaded attachment & thumbnail
///    is encrypted with a unique random 256-bit key (`mk`) transported inside
///    the Double-Ratchet-encrypted media metadata envelope.
///  * **History preservation:** Older `v1` static-E2EE messages and legacy
///    pre-E2EE messages remain readable on-device; consumed `v2` plaintexts are
///    stored in an app-private, device-encrypted local cache so Supabase
///    reloads never re-ratchet deleted message keys.
class E2eeService {
  E2eeService._({
    FlutterSecureStorage? storage,
    Directory? cacheDirectoryOverride,
    bool disableDiskPlaintextCache = false,
  })  : _storage = storage ?? const FlutterSecureStorage(),
        _cacheDirectoryOverride = cacheDirectoryOverride,
        _disableDiskPlaintextCache = disableDiskPlaintextCache;

  /// Creates an isolated instance backed by [storage] for unit tests.
  @visibleForTesting
  factory E2eeService.forTesting(
    FlutterSecureStorage storage, {
    Directory? cacheDirectory,
  }) =>
      E2eeService._(
        storage: storage,
        cacheDirectoryOverride: cacheDirectory,
        disableDiskPlaintextCache: cacheDirectory == null,
      );

  static final E2eeService instance = E2eeService._();

  static const String envelopeMarker = '__likedin_e2ee_v1';
  static const String envelopeMarkerV2 = DoubleRatchetSession.envelopeMarker;
  static const String _backupFormat = 'likedin-e2ee-key-backup-v1';
  static const String _storagePrefix = 'likedin_e2ee_v1';
  // 8-byte magic headers for encrypted media blobs:
  // v1 ("LKE2EE1\0"): single-shot AES-256-GCM
  // v2 ("LKE2EE2\0"): streaming 512 KB chunked AES-256-GCM with chunk-index & finality AAD
  static const List<int> _mediaMagic = <int>[0x4C, 0x4B, 0x45, 0x32, 0x45, 0x45, 0x31, 0x00];
  static const List<int> _mediaMagicV2 = <int>[0x4C, 0x4B, 0x45, 0x32, 0x45, 0x45, 0x32, 0x00];
  static const int _mediaChunkBytes = 512 * 1024;
  static const int _maxCachedPlaintexts = 4000;

  final FlutterSecureStorage _storage;
  final Directory? _cacheDirectoryOverride;
  final bool _disableDiskPlaintextCache;
  final X25519 _x25519 = X25519();
  final AesGcm _aesGcm = AesGcm.with256bits();
  final Hkdf _hkdf = Hkdf(hmac: Hmac.sha256(), outputLength: 32);

  final ValueNotifier<bool> activeNotifier = ValueNotifier<bool>(false);
  final ValueNotifier<E2eeStatus> statusNotifier =
      ValueNotifier<E2eeStatus>(E2eeStatus.pending);

  // Serializes all stateful Double Ratchet encrypt/decrypt operations so
  // concurrent Realtime inserts and conversation reloads never race.
  Future<void> _ratchetQueue = Future<void>.value();

  String? _userId;
  String? _peerId;
  List<int>? _privateKeyBytes;
  List<int>? _publicKeyBytes;
  List<int>? _peerPublicKeyBytes;
  SecretKey? _sessionKey; // Legacy v1 decryption key + fallback for older media
  DoubleRatchetSession? _ratchet;
  SecretKey? _localCacheKey;
  final Map<String, String> _decryptedCache = <String, String>{};
  bool _decryptedCacheLoaded = false;
  String? _safetyFingerprint;
  String? _verifiedFingerprint;
  bool _peerKeyChanged = false;
  String? _lastError;
  bool _cloudTableAvailable = true;

  bool get isActive => _sessionKey != null && _ratchet != null;
  bool get canSendEncrypted => isActive && !_peerKeyChanged && _lastError == null;
  bool get isStrictMode => true;
  bool get hasForwardSecrecy => _ratchet != null;
  E2eeStatus get status => statusNotifier.value;
  bool get isVerified =>
      isActive &&
      !_peerKeyChanged &&
      _safetyFingerprint != null &&
      _verifiedFingerprint == _safetyFingerprint;
  bool get hasPeerKeyChanged => _peerKeyChanged;
  String? get lastError => _lastError;
  String? get ownPublicKeyBase64 =>
      _publicKeyBytes == null ? null : base64Encode(_publicKeyBytes!);
  String? get safetyFingerprint => _safetyFingerprint;
  bool get cloudBackupSupported => _cloudTableAvailable;
  String? get ratchetSessionId => _ratchet?.sessionId;
  int get ratchetSendCount => _ratchet?.sendCount ?? 0;
  int get ratchetRecvCount => _ratchet?.recvCount ?? 0;

  String _privStorageKey(String uid) => '${_storagePrefix}_priv_$uid';
  String _pubStorageKey(String uid) => '${_storagePrefix}_pub_$uid';
  String _peerPubStorageKey(String uid, String peer) =>
      '${_storagePrefix}_peer_${uid}_$peer';
  String _verifiedFingerprintKey(String uid, String peer) =>
      '${_storagePrefix}_verified_${uid}_$peer';
  String _keyChangedFlagKey(String uid, String peer) =>
      '${_storagePrefix}_key_changed_${uid}_$peer';
  String _ratchetStateKey(String uid, String peer) =>
      'likedin_e2ee_dr_v2_${uid}_$peer';
  String _localCacheKeyName(String uid) =>
      'likedin_e2ee_cache_key_v2_$uid';

  static bool isV1Envelope(String text) =>
      text.startsWith('{"$envelopeMarker":');

  static bool isV2Envelope(String text) =>
      DoubleRatchetSession.isV2Envelope(text);

  static bool isEncryptedEnvelope(String text) =>
      isV2Envelope(text) || isV1Envelope(text);

  /// Generates a fresh 256-bit base64 per-file media key for forward-secret
  /// attachment and thumbnail encryption.
  static String generatePerFileMediaKeyBase64() => base64Encode(_randomBytes(32));

  Future<T> _runRatchetExclusive<T>(Future<T> Function() action) {
    final completer = Completer<T>();
    _ratchetQueue = _ratchetQueue.then((_) async {
      try {
        final res = await action();
        completer.complete(res);
      } catch (error, stackTrace) {
        completer.completeError(error, stackTrace);
      }
    });
    return completer.future;
  }

  void _syncNotifiers() {
    final active = isActive;
    activeNotifier.value = active;
    if (_lastError != null && !active) {
      statusNotifier.value = E2eeStatus.error;
    } else if (!active) {
      statusNotifier.value = E2eeStatus.pending;
    } else if (_peerKeyChanged) {
      statusNotifier.value = E2eeStatus.keyChanged;
    } else if (_safetyFingerprint != null &&
        _verifiedFingerprint == _safetyFingerprint) {
      statusNotifier.value = E2eeStatus.verified;
    } else {
      statusNotifier.value = E2eeStatus.active;
    }
  }

  /// Loads or generates this user's X25519 key pair, publishes the public key,
  /// fetches the peer's public key, and hydrates the persisted Double Ratchet.
  Future<bool> initialize(
    SupabaseClient client, {
    required String userId,
    required String peerId,
  }) async {
    try {
      await _prepareLocalPairContext(userId: userId, peerId: peerId);
      await _publishOwnPublicKey(client, userId);

      final remotePeerB64 = await _fetchPeerPublicKey(client, peerId);
      if (remotePeerB64 != null && remotePeerB64.isNotEmpty) {
        await acceptPeerPublicKey(
          remotePeerB64,
          userId: userId,
          peerId: peerId,
        );
      } else if (_peerPublicKeyBytes != null) {
        await _deriveSessionKeyAndRatchet();
      } else {
        _lastError = null;
        _syncNotifiers();
      }
      return isActive;
    } catch (error) {
      _lastError = 'Strict E2EE initialization failed. Restart or restore your key in Settings.';
      _sessionKey = null;
      _ratchet = null;
      _syncNotifiers();
      debugPrint('E2EE initialize failed: $error');
      rethrow;
    }
  }

  /// Local-only initialization used by unit tests (skips Supabase network calls).
  @visibleForTesting
  Future<bool> initializeLocalForTesting({
    required String userId,
    required String peerId,
  }) async {
    await _prepareLocalPairContext(userId: userId, peerId: peerId);
    if (_peerPublicKeyBytes != null) {
      await _deriveSessionKeyAndRatchet();
    } else {
      _lastError = null;
      _syncNotifiers();
    }
    return isActive;
  }

  Future<void> _prepareLocalPairContext({
    required String userId,
    required String peerId,
  }) async {
    if (_userId != userId || _peerId != peerId) {
      _userId = userId;
      _peerId = peerId;
      _privateKeyBytes = null;
      _publicKeyBytes = null;
      _peerPublicKeyBytes = null;
      _sessionKey = null;
      _ratchet = null;
      _localCacheKey = null;
      _decryptedCache.clear();
      _decryptedCacheLoaded = false;
      _safetyFingerprint = null;
      _verifiedFingerprint = null;
      _peerKeyChanged = false;
      _lastError = null;
      _syncNotifiers();
    }

    await _ensureOwnKeyPair(userId);
    await _ensureLocalCacheLoaded(userId, peerId);

    _verifiedFingerprint =
        await _readSecure(_verifiedFingerprintKey(userId, peerId));
    _peerKeyChanged =
        (await _readSecure(_keyChangedFlagKey(userId, peerId))) == '1';

    final cachedPeerB64 = await _readSecure(_peerPubStorageKey(userId, peerId));
    if (cachedPeerB64 != null && cachedPeerB64.isNotEmpty) {
      try {
        final bytes = base64Decode(cachedPeerB64);
        if (bytes.length == 32) {
          _peerPublicKeyBytes = bytes;
        }
      } catch (_) {}
    }
  }

  /// Accepts a peer's 32-byte X25519 public key, detects identity key changes,
  /// caches the key, and initializes/resets the Double Ratchet session.
  Future<bool> acceptPeerPublicKey(
    String publicKeyB64, {
    String? userId,
    String? peerId,
  }) async {
    final uid = userId ?? _userId;
    final pid = peerId ?? _peerId;
    if (uid == null || pid == null) return false;
    final List<int> bytes;
    try {
      bytes = base64Decode(publicKeyB64.trim());
    } on FormatException catch (error) {
      debugPrint('Ignoring malformed peer E2EE public key: $error');
      return false;
    }
    if (bytes.length != 32) return false;

    List<int>? previousPeerBytes = _peerPublicKeyBytes;
    if (previousPeerBytes == null) {
      final stored = await _readSecure(_peerPubStorageKey(uid, pid));
      if (stored != null && stored.isNotEmpty) {
        try {
          final decoded = base64Decode(stored);
          if (decoded.length == 32) {
            previousPeerBytes = decoded;
          }
        } catch (_) {}
      }
    }

    final unchanged = previousPeerBytes != null &&
        _bytesEqual(previousPeerBytes, bytes) &&
        _sessionKey != null &&
        _ratchet != null;
    if (unchanged) {
      _syncNotifiers();
      return true;
    }

    final keyChanged =
        previousPeerBytes != null && !_bytesEqual(previousPeerBytes, bytes);

    await _writeSecure(_peerPubStorageKey(uid, pid), base64Encode(bytes));
    if (keyChanged) {
      _peerKeyChanged = true;
      _verifiedFingerprint = null;
      _ratchet = null;
      await _deleteSecure(_verifiedFingerprintKey(uid, pid));
      await _deleteSecure(_ratchetStateKey(uid, pid));
      await _writeSecure(_keyChangedFlagKey(uid, pid), '1');
    }
    _userId = uid;
    _peerId = pid;
    _peerPublicKeyBytes = bytes;
    await _ensureOwnKeyPair(uid);
    await _ensureLocalCacheLoaded(uid, pid);
    await _deriveSessionKeyAndRatchet(forceResetRatchet: keyChanged);
    return isActive;
  }

  /// Marks the active peer safety fingerprint as manually verified, clears any
  /// key-change send lock, and unlocks strict sending.
  Future<void> markCurrentFingerprintVerified() async {
    final uid = _userId;
    final pid = _peerId;
    final fp = _safetyFingerprint;
    if (uid == null || pid == null || fp == null || !isActive) return;
    await _writeSecure(_verifiedFingerprintKey(uid, pid), fp);
    await _deleteSecure(_keyChangedFlagKey(uid, pid));
    _verifiedFingerprint = fp;
    _peerKeyChanged = false;
    _syncNotifiers();
  }

  /// Clears a verified badge (e.g., if the user wants to re-check in person).
  Future<void> clearFingerprintVerification() async {
    final uid = _userId;
    final pid = _peerId;
    if (uid == null || pid == null) return;
    await _deleteSecure(_verifiedFingerprintKey(uid, pid));
    _verifiedFingerprint = null;
    _syncNotifiers();
  }

  /// Accepts a peer key change without marking it verified yet, lifting the
  /// strict key-change send lock.
  Future<void> acknowledgePeerKeyChange() async {
    final uid = _userId;
    final pid = _peerId;
    if (uid == null || pid == null) return;
    await _deleteSecure(_keyChangedFlagKey(uid, pid));
    _peerKeyChanged = false;
    _syncNotifiers();
  }

  void _requireStrictSendReady({required String actionLabel}) {
    if (_peerKeyChanged) {
      throw StateError(
        'Sending paused: your friend’s security key changed. Compare fingerprints in Settings → E2EE and verify or accept the new key before $actionLabel.',
      );
    }
    if (!isActive || _lastError != null) {
      throw StateError(
        'Strict E2EE is active: encryption session is not ready yet. Open Chat on both phones or check Settings → E2EE before $actionLabel.',
      );
    }
  }

  /// Strictly encrypts [plaintext] using the pure-Dart Double Ratchet (`v2`
  /// envelope). Plaintext fallback is permanently disabled (fail-closed).
  /// Pass [alreadyEncrypted] = true only if the caller explicitly holds an
  /// already-encrypted wire payload; never sniff user-typed content.
  Future<String> encryptIfReady(
    String plaintext, {
    bool alreadyEncrypted = false,
  }) async {
    if (plaintext.isEmpty || alreadyEncrypted) return plaintext;
    _requireStrictSendReady(actionLabel: 'sending messages');

    return _runRatchetExclusive<String>(() async {
      _requireStrictSendReady(actionLabel: 'sending messages');
      await _syncRatchetFromStorageIfNewer();
      final ratchet = _ratchet;
      if (ratchet == null) {
        throw StateError('Double Ratchet session is unavailable.');
      }
      final envelope = await ratchet.encrypt(plaintext);
      await _persistRatchetState(ratchet);
      final fp = await DoubleRatchetSession.envelopeFingerprint(envelope);
      await _rememberDecryptedPlaintext(fp, plaintext);
      return envelope;
    });
  }

  /// Decrypts a `v2` Double Ratchet or legacy `v1` E2EE envelope back into
  /// plaintext. Older pre-E2EE history passes through untouched on read.
  Future<String> decryptIfNeeded(String payload) async {
    if (!isEncryptedEnvelope(payload)) return payload;

    // Handle v2 Double Ratchet forward-secret envelopes.
    if (isV2Envelope(payload)) {
      final fp = await DoubleRatchetSession.envelopeFingerprint(payload);
      final cached = _decryptedCache[fp];
      if (cached != null) return cached;

      if (!isActive) {
        return '🔒 Encrypted message (open Settings → E2EE to sync or restore your key)';
      }

      return _runRatchetExclusive<String>(() async {
        final again = _decryptedCache[fp];
        if (again != null) return again;

        await _syncRatchetFromStorageIfNewer();
        final ratchet = _ratchet;
        if (ratchet == null) {
          return '🔒 Encrypted message (open Settings → E2EE to sync or restore your key)';
        }
        try {
          final clear = await ratchet.decrypt(payload);
          await _persistRatchetState(ratchet);
          await _rememberDecryptedPlaintext(fp, clear);
          return clear;
        } catch (error) {
          debugPrint('Double Ratchet v2 decryption failed: $error');
          return '🔒 Forward-secret message (key rotated or encrypted on another install)';
        }
      });
    }

    // Handle legacy v1 static-key E2EE envelopes (preserves existing history).
    final key = _sessionKey;
    if (key == null) {
      return '🔒 Encrypted message (open Settings → E2EE to sync or restore your key)';
    }
    try {
      final decoded = jsonDecode(payload);
      if (decoded is! Map || decoded[envelopeMarker] != 1) return payload;
      final nonce = base64Decode(decoded['n'].toString());
      final cipherText = base64Decode(decoded['c'].toString());
      final macBytes = base64Decode(decoded['m'].toString());
      final clearBytes = await _aesGcm.decrypt(
        SecretBox(cipherText, nonce: nonce, mac: Mac(macBytes)),
        secretKey: key,
      );
      return utf8.decode(clearBytes);
    } catch (error) {
      debugPrint('Legacy E2EE v1 message decryption failed: $error');
      return '🔒 Encrypted message (restore your E2EE recovery key in Settings to read)';
    }
  }

  static bool isEncryptedMediaBytes(Uint8List data) {
    if (data.length < _mediaMagic.length + 12 + 16) return false;
    for (var i = 0; i < _mediaMagic.length; i++) {
      if (data[i] != _mediaMagic[i]) return false;
    }
    return true;
  }

  /// Strictly encrypts raw bytes with AES-256-GCM.
  Future<Uint8List> encryptBytesIfReady(
    Uint8List plainBytes, {
    String? keyBase64Override,
  }) async {
    if (plainBytes.isEmpty || isEncryptedMediaBytes(plainBytes)) {
      return plainBytes;
    }
    _requireStrictSendReady(actionLabel: 'uploading media');
    final key = _resolveMediaSecretKey(keyBase64Override);
    if (key == null) {
      throw StateError('Media encryption key is unavailable.');
    }
    final nonce = _randomBytes(12);
    final box = await _aesGcm.encrypt(
      plainBytes,
      secretKey: key,
      nonce: nonce,
    );
    final out = BytesBuilder(copy: false)
      ..add(_mediaMagic)
      ..add(box.nonce)
      ..add(box.cipherText)
      ..add(box.mac.bytes);
    return out.toBytes();
  }

  /// Decrypts raw bytes if they carry the LKE2EE1 header.
  Future<Uint8List> decryptBytesIfNeeded(
    Uint8List data, {
    String? mediaKeyBase64,
  }) async {
    if (!isEncryptedMediaBytes(data)) return data;
    final key = _resolveMediaSecretKey(mediaKeyBase64);
    if (key == null) {
      throw StateError('E2EE key is unavailable to decrypt this attachment.');
    }
    final offset = _mediaMagic.length;
    final nonce = data.sublist(offset, offset + 12);
    final macStart = data.length - 16;
    final cipherText = data.sublist(offset + 12, macStart);
    final macBytes = data.sublist(macStart);
    final clear = await _aesGcm.decrypt(
      SecretBox(cipherText, nonce: nonce, mac: Mac(macBytes)),
      secretKey: key,
    );
    return Uint8List.fromList(clear);
  }

  /// Inspects the first 8 bytes of [file] and returns 1 for LKE2EE1, 2 for
  /// LKE2EE2 (streaming 512 KB chunks), or 0 for legacy unencrypted files.
  static Future<int> detectEncryptedMediaVersion(File file) async {
    if (!await file.exists()) return 0;
    final len = await file.length();
    if (len < 8 + 12 + 16) return 0;
    RandomAccessFile? raf;
    try {
      raf = await file.open(mode: FileMode.read);
      final header = await raf.read(8);
      if (header.length < 8) return 0;
      if (_bytesEqual(header, _mediaMagicV2)) return 2;
      if (_bytesEqual(header, _mediaMagic)) return 1;
      return 0;
    } finally {
      try { await raf?.close(); } catch (_) {}
    }
  }

  /// Strictly streams [source] into [destination] using 512 KB AES-256-GCM
  /// chunks (LKE2EE2 format). Fails closed when E2EE is pending, key-changed,
  /// or errored. Supplying [keyBase64Override] encrypts with a unique per-file
  /// forward-secret 256-bit key!
  Future<bool> encryptFileToDestination(
    File source,
    File destination, {
    String? keyBase64Override,
  }) async {
    _requireStrictSendReady(actionLabel: 'uploading media');
    final key = _resolveMediaSecretKey(keyBase64Override);
    if (key == null) {
      throw StateError('End-to-end encryption key is unavailable. Refusing unencrypted upload.');
    }
    final totalLength = await source.length();
    if (totalLength <= 0) return false;
    if (await detectEncryptedMediaVersion(source) != 0) {
      await source.copy(destination.path);
      return true;
    }

    final part = File('${destination.path}.part');
    RandomAccessFile? reader;
    RandomAccessFile? writer;
    try {
      if (await part.exists()) await part.delete();
      reader = await source.open(mode: FileMode.read);
      writer = await part.open(mode: FileMode.write);
      await writer.writeFrom(_mediaMagicV2);

      var bytesRead = 0;
      var chunkIndex = 0;
      while (bytesRead < totalLength) {
        final chunk = await reader.read(_mediaChunkBytes);
        if (chunk.isEmpty) break;
        bytesRead += chunk.length;
        final isFinal = bytesRead >= totalLength;
        final nonce = _randomBytes(12);
        final aad = utf8.encode('likedin-media-v2:$chunkIndex:${isFinal ? 1 : 0}');
        final box = await _aesGcm.encrypt(
          chunk,
          secretKey: key,
          nonce: nonce,
          aad: aad,
        );
        // Allocate a fresh 4-byte length prefix per chunk and write directly via
        // RandomAccessFile so buffered IOSink references can never alias or
        // overwrite earlier chunks, keeping peak RAM constant (~512 KB).
        final lenBuf = ByteData(4)..setUint32(0, box.cipherText.length, Endian.big);
        await writer.writeFrom(lenBuf.buffer.asUint8List());
        await writer.writeFrom(box.nonce);
        await writer.writeFrom(box.cipherText);
        await writer.writeFrom(box.mac.bytes);
        chunkIndex++;
      }
      await writer.flush();
      await writer.close();
      writer = null;
      await reader.close();
      reader = null;
      if (await destination.exists()) await destination.delete();
      await part.rename(destination.path);
      return true;
    } catch (_) {
      try { await writer?.close(); } catch (_) {}
      try { await reader?.close(); } catch (_) {}
      try { if (await part.exists()) await part.delete(); } catch (_) {}
      rethrow;
    }
  }

  /// Decrypts [file] in place if it carries an LKE2EE1 or LKE2EE2 header.
  /// Uses [mediaKeyBase64] for forward-secret per-file media (v2.8.0+), falling
  /// back to `_sessionKey` for older v2.2–v2.7 encrypted media.
  Future<void> decryptFileInPlaceIfNeeded(
    File file, {
    bool requireEncrypted = false,
    String? mediaKeyBase64,
  }) async {
    final version = await detectEncryptedMediaVersion(file);
    if (version == 0) {
      if (requireEncrypted) {
        throw StateError('Expected encrypted media bytes, but received an unencrypted file.');
      }
      return;
    }
    final key = _resolveMediaSecretKey(mediaKeyBase64);
    if (key == null) {
      throw StateError('E2EE session key is unavailable to decrypt this media file.');
    }

    final decodedTemp = File('${file.path}.dec');
    try {
      if (await decodedTemp.exists()) await decodedTemp.delete();
      if (version == 1) {
        final encrypted = await file.readAsBytes();
        final plain = await decryptBytesIfNeeded(encrypted, mediaKeyBase64: mediaKeyBase64);
        await decodedTemp.writeAsBytes(plain, flush: true);
      } else {
        try {
          await _decryptV2FileStream(
            file,
            decodedTemp,
            key: key,
            recoverLegacyAliasedChunkLengths: false,
          );
        } catch (_) {
          // Auto-recover multi-chunk media uploaded by v2.8.0–v2.9.1 where a
          // reused 4-byte length buffer overwrote earlier chunk lengths in
          // IOSink. Every chunk is still cryptographically authenticated by its
          // 128-bit AES-256-GCM tag and chunk-index/finality AAD.
          try {
            if (await decodedTemp.exists()) await decodedTemp.delete();
            await _decryptV2FileStream(
              file,
              decodedTemp,
              key: key,
              recoverLegacyAliasedChunkLengths: true,
            );
            debugPrint('Recovered legacy multi-chunk E2EE media via fixed-stride fallback.');
          } catch (_) {
            rethrow;
          }
        }
      }
      await file.delete();
      await decodedTemp.rename(file.path);
    } catch (_) {
      try { if (await decodedTemp.exists()) await decodedTemp.delete(); } catch (_) {}
      rethrow;
    }
  }

  Future<void> _decryptV2FileStream(
    File source,
    File destination, {
    required SecretKey key,
    required bool recoverLegacyAliasedChunkLengths,
  }) async {
    RandomAccessFile? reader;
    RandomAccessFile? writer;
    try {
      final fileLength = await source.length();
      reader = await source.open(mode: FileMode.read);
      final header = await reader.read(8);
      if (header.length != 8 || !_bytesEqual(header, _mediaMagicV2)) {
        throw StateError('Invalid encrypted media header.');
      }
      final bodyLen = fileLength - 8;
      const fullChunkOnDisk = 4 + 12 + _mediaChunkBytes + 16;
      if (recoverLegacyAliasedChunkLengths && bodyLen <= fullChunkOnDisk) {
        throw StateError('File is single-chunk; legacy multi-chunk recovery does not apply.');
      }

      writer = await destination.open(mode: FileMode.write);
      var readPos = 8;
      var chunkIndex = 0;
      while (readPos < fileLength) {
        final lenBytes = await reader.read(4);
        if (lenBytes.length != 4) {
          throw StateError('Truncated encrypted media chunk length.');
        }
        final remainingAfterLen = fileLength - (readPos + 4);
        final int cipherLen;
        if (recoverLegacyAliasedChunkLengths) {
          final remainingIncludingHeader = fileLength - readPos;
          if (remainingIncludingHeader > fullChunkOnDisk) {
            cipherLen = _mediaChunkBytes;
          } else {
            cipherLen = remainingAfterLen - 12 - 16;
          }
        } else {
          cipherLen = ByteData.sublistView(lenBytes).getUint32(0, Endian.big);
        }
        if (cipherLen <= 0 || cipherLen > _mediaChunkBytes + 64) {
          throw StateError('Invalid encrypted media chunk size ($cipherLen).');
        }
        final nonce = await reader.read(12);
        final cipherText = await reader.read(cipherLen);
        final macBytes = await reader.read(16);
        if (nonce.length != 12 || cipherText.length != cipherLen || macBytes.length != 16) {
          throw StateError('Truncated encrypted media chunk body.');
        }
        readPos += 4 + 12 + cipherLen + 16;
        final isFinal = readPos >= fileLength;
        final aad = utf8.encode('likedin-media-v2:$chunkIndex:${isFinal ? 1 : 0}');
        final clear = await _aesGcm.decrypt(
          SecretBox(cipherText, nonce: nonce, mac: Mac(macBytes)),
          secretKey: key,
          aad: aad,
        );
        await writer.writeFrom(clear);
        chunkIndex++;
      }
      if (chunkIndex == 0) {
        throw StateError('Encrypted media file contains no chunks.');
      }
      await writer.flush();
      await writer.close();
      writer = null;
      await reader.close();
      reader = null;
    } catch (_) {
      try { await writer?.close(); } catch (_) {}
      try { await reader?.close(); } catch (_) {}
      rethrow;
    }
  }

  Future<RemoteMessage> decryptMessage(RemoteMessage message) async {
    if (message.deletedForEveryoneAt != null || !isEncryptedEnvelope(message.text)) {
      return message;
    }
    final clear = await decryptIfNeeded(message.text);
    return RemoteMessage(
      id: message.id,
      clientMessageId: message.clientMessageId,
      senderId: message.senderId,
      recipientId: message.recipientId,
      text: clear,
      createdAt: message.createdAt,
      deliveredAt: message.deliveredAt,
      readAt: message.readAt,
      replyToMessageId: message.replyToMessageId,
      editedAt: message.editedAt,
      deletedForEveryoneAt: message.deletedForEveryoneAt,
      deletedMediaPath: message.deletedMediaPath,
    );
  }

  /// Decrypts a batch of messages sequentially in strict chronological order so
  /// Double Ratchet steps always execute in send order without race conditions,
  /// returning the decrypted messages in the caller's original order.
  Future<List<RemoteMessage>> decryptMessages(List<RemoteMessage> list) async {
    if (list.isEmpty) return list;
    final hasEncrypted = list.any(
      (m) => m.deletedForEveryoneAt == null && isEncryptedEnvelope(m.text),
    );
    if (!hasEncrypted) return list;

    final indexed = List<({int idx, RemoteMessage msg})>.generate(
      list.length,
      (i) => (idx: i, msg: list[i]),
      growable: false,
    );
    final ordered = List<({int idx, RemoteMessage msg})>.of(indexed)
      ..sort((a, b) {
        final byTime = a.msg.createdAt.compareTo(b.msg.createdAt);
        return byTime != 0 ? byTime : a.msg.id.compareTo(b.msg.id);
      });

    final out = List<RemoteMessage>.of(list, growable: false);
    for (final entry in ordered) {
      out[entry.idx] = await decryptMessage(entry.msg);
    }
    return out;
  }

  /// Encrypts this device's X25519 identity private key with [passphrase]
  /// (PBKDF2 100k + AES-256-GCM) and uploads the encrypted blob to `likedin_e2ee_keys`.
  Future<void> backupKeyWithPassphrase(
    SupabaseClient client,
    String passphrase,
  ) async {
    final uid = client.auth.currentUser?.id ?? _userId;
    if (uid == null) throw StateError('Sign in before backing up your E2EE key.');
    if (passphrase.length < 12) {
      throw StateError('Use a recovery passphrase of at least 12 characters.');
    }
    await _ensureOwnKeyPair(uid);
    final priv = _privateKeyBytes;
    final pub = _publicKeyBytes;
    if (priv == null || pub == null) {
      throw StateError('E2EE key pair is not ready yet.');
    }

    final salt = _randomBytes(16);
    final nonce = _randomBytes(12);
    final wrappingKey = await Pbkdf2(
      macAlgorithm: Hmac.sha256(),
      iterations: 100000,
      bits: 256,
    ).deriveKeyFromPassword(password: passphrase, nonce: salt);

    final box = await _aesGcm.encrypt(
      priv,
      secretKey: wrappingKey,
      nonce: nonce,
    );
    final backupEnvelope = jsonEncode(<String, Object>{
      'format': _backupFormat,
      'iterations': 100000,
      'salt': base64Encode(salt),
      'nonce': base64Encode(box.nonce),
      'cipher': base64Encode(box.cipherText),
      'mac': base64Encode(box.mac.bytes),
    });

    await client.from('likedin_e2ee_keys').upsert(
      <String, Object>{
        'user_id': uid,
        'public_key': base64Encode(pub),
        'encrypted_key_backup': backupEnvelope,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      },
      onConflict: 'user_id',
    );
    _cloudTableAvailable = true;
  }

  /// Downloads and decrypts the user's X25519 identity private key from
  /// Supabase using [passphrase], saves it in secure storage, and re-derives
  /// the session & Double Ratchet.
  Future<void> restoreKeyWithPassphrase(
    SupabaseClient client,
    String passphrase,
  ) async {
    final uid = client.auth.currentUser?.id ?? _userId;
    if (uid == null) throw StateError('Sign in before restoring your E2EE key.');
    final row = await client
        .from('likedin_e2ee_keys')
        .select('encrypted_key_backup')
        .eq('user_id', uid)
        .maybeSingle();
    final rawBackup = row?['encrypted_key_backup']?.toString();
    if (rawBackup == null || rawBackup.isEmpty) {
      throw StateError('No E2EE key backup was found for this account.');
    }
    final decoded = jsonDecode(rawBackup);
    if (decoded is! Map || decoded['format'] != _backupFormat) {
      throw StateError('The stored E2EE key backup format is unrecognized.');
    }
    final iterations = (decoded['iterations'] as num?)?.toInt() ?? 100000;
    final salt = base64Decode(decoded['salt'].toString());
    final nonce = base64Decode(decoded['nonce'].toString());
    final cipher = base64Decode(decoded['cipher'].toString());
    final mac = base64Decode(decoded['mac'].toString());

    final wrappingKey = await Pbkdf2(
      macAlgorithm: Hmac.sha256(),
      iterations: iterations,
      bits: 256,
    ).deriveKeyFromPassword(password: passphrase, nonce: salt);

    List<int> privBytes;
    try {
      privBytes = await _aesGcm.decrypt(
        SecretBox(cipher, nonce: nonce, mac: Mac(mac)),
        secretKey: wrappingKey,
      );
    } catch (_) {
      throw StateError('Incorrect recovery passphrase. Your E2EE key was not changed.');
    }
    if (privBytes.length != 32) {
      throw StateError('The restored key data is invalid.');
    }

    final restoredPair = await _x25519.newKeyPairFromSeed(privBytes);
    final restoredPub = await restoredPair.extractPublicKey();
    await _writeSecure(_privStorageKey(uid), base64Encode(privBytes));
    await _writeSecure(_pubStorageKey(uid), base64Encode(restoredPub.bytes));
    _privateKeyBytes = privBytes;
    _publicKeyBytes = restoredPub.bytes;
    await _publishOwnPublicKey(client, uid);
    if (_peerPublicKeyBytes != null) {
      await _deriveSessionKeyAndRatchet(forceResetRatchet: true);
    }
  }

  /// Clears in-memory session state on sign-out without destroying persisted
  /// secure-storage keys or device-encrypted plaintext caches.
  void resetMemoryState() {
    _userId = null;
    _peerId = null;
    _privateKeyBytes = null;
    _publicKeyBytes = null;
    _peerPublicKeyBytes = null;
    _sessionKey = null;
    _ratchet = null;
    _localCacheKey = null;
    _decryptedCache.clear();
    _decryptedCacheLoaded = false;
    _safetyFingerprint = null;
    _verifiedFingerprint = null;
    _peerKeyChanged = false;
    _lastError = null;
    _syncNotifiers();
  }

  SecretKey? _resolveMediaSecretKey(String? keyBase64Override) {
    if (keyBase64Override != null && keyBase64Override.isNotEmpty) {
      try {
        final raw = base64Decode(keyBase64Override.trim());
        if (raw.length == 32) return SecretKey(raw);
      } catch (_) {}
    }
    return _sessionKey;
  }

  Future<void> _ensureOwnKeyPair(String uid) async {
    if (_privateKeyBytes != null && _publicKeyBytes != null) return;
    final savedPriv = await _readSecure(_privStorageKey(uid));
    final savedPub = await _readSecure(_pubStorageKey(uid));
    if (savedPriv != null && savedPriv.isNotEmpty && savedPub != null && savedPub.isNotEmpty) {
      try {
        final priv = base64Decode(savedPriv);
        final pub = base64Decode(savedPub);
        if (priv.length == 32 && pub.length == 32) {
          _privateKeyBytes = priv;
          _publicKeyBytes = pub;
          return;
        }
      } catch (_) {}
    }

    final generated = await _x25519.newKeyPair();
    final extractedPriv = await generated.extractPrivateKeyBytes();
    final extractedPub = await generated.extractPublicKey();
    await _writeSecure(_privStorageKey(uid), base64Encode(extractedPriv));
    await _writeSecure(_pubStorageKey(uid), base64Encode(extractedPub.bytes));
    _privateKeyBytes = extractedPriv;
    _publicKeyBytes = extractedPub.bytes;
  }

  Future<void> _publishOwnPublicKey(SupabaseClient client, String uid) async {
    final pub = _publicKeyBytes;
    if (pub == null) return;
    try {
      await client.from('likedin_e2ee_keys').upsert(
        <String, Object>{
          'user_id': uid,
          'public_key': base64Encode(pub),
          'updated_at': DateTime.now().toUtc().toIso8601String(),
        },
        onConflict: 'user_id',
      );
      _cloudTableAvailable = true;
    } catch (error) {
      _cloudTableAvailable = false;
      debugPrint('E2EE cloud key publish skipped: $error');
    }
  }

  Future<String?> _fetchPeerPublicKey(SupabaseClient client, String peerId) async {
    try {
      final row = await client
          .from('likedin_e2ee_keys')
          .select('public_key')
          .eq('user_id', peerId)
          .maybeSingle();
      _cloudTableAvailable = true;
      return row?['public_key']?.toString();
    } catch (error) {
      debugPrint('E2EE peer key lookup skipped: $error');
      return null;
    }
  }

  Future<void> _deriveSessionKeyAndRatchet({bool forceResetRatchet = false}) async {
    final uid = _userId;
    final pid = _peerId;
    final priv = _privateKeyBytes;
    final pub = _publicKeyBytes;
    final peerPub = _peerPublicKeyBytes;
    if (uid == null || pid == null || priv == null || pub == null || peerPub == null) {
      return;
    }

    final localPair = SimpleKeyPairData(
      priv,
      publicKey: SimplePublicKey(pub, type: KeyPairType.x25519),
      type: KeyPairType.x25519,
    );
    final remotePub = SimplePublicKey(peerPub, type: KeyPairType.x25519);
    final sharedSecret = await _x25519.sharedSecretKey(
      keyPair: localPair,
      remotePublicKey: remotePub,
    );

    // Non-empty salt avoids the empty-HMAC-key bug in cryptography 2.7.0.
    final derived = await _hkdf.deriveKey(
      secretKey: sharedSecret,
      nonce: utf8.encode('likedin-e2ee-v1-salt'),
      info: utf8.encode('likedin-e2ee-v1-aes256gcm'),
    );

    // Deterministic 6-group safety fingerprint from sorted identity public keys.
    final keysSorted = <String>[base64Encode(pub), base64Encode(peerPub)]..sort();
    final digest = await Sha256().hash(utf8.encode(keysSorted.join(':')));
    final hex = digest.bytes
        .take(12)
        .map((b) => b.toRadixString(16).padLeft(2, '0').toUpperCase())
        .join();
    final groups = <String>[
      for (var i = 0; i < hex.length; i += 4) hex.substring(i, i + 4),
    ];

    DoubleRatchetSession? ratchet;
    if (!forceResetRatchet) {
      ratchet = await _loadRatchetState(
        uid: uid,
        pid: pid,
        ownPriv: priv,
        ownPub: pub,
        peerPub: peerPub,
      );
    }
    if (ratchet == null) {
      ratchet = await DoubleRatchetSession.create(
        userId: uid,
        peerId: pid,
        ownIdentityPriv: priv,
        ownIdentityPub: pub,
        peerIdentityPub: peerPub,
      );
      await _persistRatchetState(ratchet);
    }

    _sessionKey = derived;
    _ratchet = ratchet;
    _safetyFingerprint = groups.join(' ');
    _lastError = null;
    _syncNotifiers();
  }

  Future<DoubleRatchetSession?> _loadRatchetState({
    required String uid,
    required String pid,
    required List<int> ownPriv,
    required List<int> ownPub,
    required List<int> peerPub,
  }) async {
    final raw = await _readSecure(_ratchetStateKey(uid, pid));
    if (raw == null || raw.isEmpty) return null;
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! Map) return null;
      return DoubleRatchetSession.fromJson(
        Map<String, dynamic>.from(decoded),
        userId: uid,
        peerId: pid,
        ownIdentityPriv: ownPriv,
        ownIdentityPub: ownPub,
        peerIdentityPub: peerPub,
      );
    } catch (_) {
      return null;
    }
  }

  /// Reloads Double Ratchet state if another isolate (such as an Android
  /// background notification inline reply) advanced the persisted revision.
  Future<void> _syncRatchetFromStorageIfNewer() async {
    final uid = _userId;
    final pid = _peerId;
    final priv = _privateKeyBytes;
    final pub = _publicKeyBytes;
    final peerPub = _peerPublicKeyBytes;
    if (uid == null || pid == null || priv == null || pub == null || peerPub == null) {
      return;
    }
    final persisted = await _loadRatchetState(
      uid: uid,
      pid: pid,
      ownPriv: priv,
      ownPub: pub,
      peerPub: peerPub,
    );
    if (persisted != null &&
        (_ratchet == null || persisted.revision > _ratchet!.revision)) {
      _ratchet = persisted;
      await _reloadLocalPlaintextCacheFromDisk(uid, pid);
    }
  }

  Future<void> _persistRatchetState(DoubleRatchetSession session) async {
    final uid = _userId;
    final pid = _peerId;
    if (uid == null || pid == null) return;
    await _writeSecure(_ratchetStateKey(uid, pid), jsonEncode(session.toJson()));
  }

  Future<SecretKey> _ensureLocalCacheKey(String uid) async {
    final existing = _localCacheKey;
    if (existing != null) return existing;
    final saved = await _readSecure(_localCacheKeyName(uid));
    if (saved != null && saved.isNotEmpty) {
      try {
        final raw = base64Decode(saved);
        if (raw.length == 32) {
          final key = SecretKey(raw);
          _localCacheKey = key;
          return key;
        }
      } catch (_) {}
    }
    final generated = _randomBytes(32);
    await _writeSecure(_localCacheKeyName(uid), base64Encode(generated));
    final key = SecretKey(generated);
    _localCacheKey = key;
    return key;
  }

  Future<File?> _localCacheFile(String uid, String pid) async {
    if (_disableDiskPlaintextCache) return null;
    final dir = _cacheDirectoryOverride ?? await getApplicationSupportDirectory();
    final safeUid = uid.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_');
    final safePid = pid.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_');
    return File(p.join(dir.path, 'likedin_dr_cache_${safeUid}_$safePid.enc'));
  }

  Future<void> _ensureLocalCacheLoaded(String uid, String pid) async {
    if (_decryptedCacheLoaded) return;
    _decryptedCacheLoaded = true;
    await _reloadLocalPlaintextCacheFromDisk(uid, pid);
  }

  Future<void> _reloadLocalPlaintextCacheFromDisk(String uid, String pid) async {
    try {
      final file = await _localCacheFile(uid, pid);
      if (file == null || !await file.exists()) return;
      final key = await _ensureLocalCacheKey(uid);
      final raw = await file.readAsBytes();
      if (raw.length < 12 + 16) return;
      final nonce = raw.sublist(0, 12);
      final macBytes = raw.sublist(raw.length - 16);
      final cipher = raw.sublist(12, raw.length - 16);
      final clear = await _aesGcm.decrypt(
        SecretBox(cipher, nonce: nonce, mac: Mac(macBytes)),
        secretKey: key,
      );
      final decoded = jsonDecode(utf8.decode(clear));
      if (decoded is Map) {
        for (final entry in decoded.entries) {
          _decryptedCache[entry.key.toString()] = entry.value.toString();
        }
      }
    } catch (error) {
      debugPrint('Local E2EE plaintext cache reload skipped: $error');
    }
  }

  Future<void> _rememberDecryptedPlaintext(String envelopeFp, String plaintext) async {
    _decryptedCache.remove(envelopeFp);
    _decryptedCache[envelopeFp] = plaintext;
    while (_decryptedCache.length > _maxCachedPlaintexts) {
      _decryptedCache.remove(_decryptedCache.keys.first);
    }
    final uid = _userId;
    final pid = _peerId;
    if (uid == null || pid == null) return;
    try {
      final file = await _localCacheFile(uid, pid);
      if (file == null) return;
      final key = await _ensureLocalCacheKey(uid);
      final nonce = _randomBytes(12);
      final box = await _aesGcm.encrypt(
        utf8.encode(jsonEncode(_decryptedCache)),
        secretKey: key,
        nonce: nonce,
      );
      final bytes = BytesBuilder(copy: false)
        ..add(box.nonce)
        ..add(box.cipherText)
        ..add(box.mac.bytes);
      final temp = File('${file.path}.tmp');
      await temp.writeAsBytes(bytes.toBytes(), flush: true);
      if (await file.exists()) await file.delete();
      await temp.rename(file.path);
    } catch (error) {
      debugPrint('Local E2EE plaintext cache save skipped: $error');
    }
  }

  Future<String?> _readSecure(String key) async {
    try {
      return await _storage.read(key: key);
    } catch (_) {
      return null;
    }
  }

  Future<void> _writeSecure(String key, String value) async {
    await _storage.write(key: key, value: value);
  }

  Future<void> _deleteSecure(String key) async {
    await _storage.delete(key: key);
  }

  static List<int> _randomBytes(int length) {
    final rng = Random.secure();
    return List<int>.generate(length, (_) => rng.nextInt(256), growable: false);
  }

  static bool _bytesEqual(List<int> a, List<int> b) {
    if (a.length != b.length) return false;
    var diff = 0;
    for (var i = 0; i < a.length; i++) {
      diff |= a[i] ^ b[i];
    }
    return diff == 0;
  }
}
