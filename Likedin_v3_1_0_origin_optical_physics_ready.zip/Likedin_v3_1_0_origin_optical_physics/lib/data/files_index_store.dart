import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Immutable snapshot of parsed shared Media, Audio, and Docs metadata for a
/// conversation, persisted encrypted-at-rest so the Files tab renders instantly
/// on open and only fetches messages newer than [lastMessageCreatedAt].
class FilesIndexSnapshot {
  const FilesIndexSnapshot({
    required this.items,
    this.lastMessageCreatedAt,
    this.lastMessageId,
    this.lastDeletedAt,
    this.builtWhileE2eeInactive = false,
  });

  static const int formatVersion = 1;

  /// Newest-first shared attachment metadata entries.
  final List<Map<String, dynamic>> items;

  /// Composite cursor of the newest message scanned (text OR media) so
  /// subsequent refreshes skip already-scanned history.
  final DateTime? lastMessageCreatedAt;
  final String? lastMessageId;

  /// Cursor of the newest `deleted_for_everyone_at` tombstone processed.
  final DateTime? lastDeletedAt;

  /// True when the index was built before E2EE finished initializing; triggers
  /// a one-time full rebuild once E2EE becomes active.
  final bool builtWhileE2eeInactive;

  bool get hasSyncCursor => lastMessageCreatedAt != null;

  /// Merges newly synced media items and deletion tombstones into this snapshot,
  /// deduplicating by message ID / storage path, sorting newest-first, and
  /// advancing sync cursors monotonically.
  FilesIndexSnapshot mergeIncremental({
    required List<Map<String, dynamic>> addedItems,
    DateTime? newestMessageCreatedAt,
    String? newestMessageId,
    Set<String> deletedMessageIds = const <String>{},
    Set<String> deletedMediaPaths = const <String>{},
    DateTime? newestDeletedAt,
    bool? builtWhileE2eeInactive,
  }) {
    final byKey = <String, Map<String, dynamic>>{};

    String itemKey(Map<String, dynamic> item) {
      final id = item['id']?.toString();
      if (id != null && id.isNotEmpty) return 'id:$id';
      final path = item['path']?.toString() ?? '';
      final createdAt = item['created_at']?.toString() ?? '';
      return 'path:$path:$createdAt';
    }

    bool isDeleted(Map<String, dynamic> item) {
      final id = item['id']?.toString();
      if (id != null && id.isNotEmpty && deletedMessageIds.contains(id)) {
        return true;
      }
      final clientId = item['client_message_id']?.toString();
      if (clientId != null &&
          clientId.isNotEmpty &&
          deletedMessageIds.contains(clientId)) {
        return true;
      }
      final path = item['path']?.toString();
      if (path != null && path.isNotEmpty && deletedMediaPaths.contains(path)) {
        return true;
      }
      return false;
    }

    for (final existing in items) {
      if (isDeleted(existing)) continue;
      byKey[itemKey(existing)] = Map<String, dynamic>.from(existing);
    }
    for (final added in addedItems) {
      if (isDeleted(added)) continue;
      byKey[itemKey(added)] = Map<String, dynamic>.from(added);
    }

    final merged = byKey.values.toList(growable: false)
      ..sort((a, b) {
        final aDate = DateTime.tryParse(a['created_at']?.toString() ?? '') ??
            DateTime.fromMillisecondsSinceEpoch(0, isUtc: true);
        final bDate = DateTime.tryParse(b['created_at']?.toString() ?? '') ??
            DateTime.fromMillisecondsSinceEpoch(0, isUtc: true);
        final byTime = bDate.compareTo(aDate); // Newest first
        if (byTime != 0) return byTime;
        final aId = a['id']?.toString() ?? '';
        final bId = b['id']?.toString() ?? '';
        return bId.compareTo(aId);
      });

    DateTime? nextMsgAt = lastMessageCreatedAt;
    String? nextMsgId = lastMessageId;
    if (newestMessageCreatedAt != null) {
      final candidateUtc = newestMessageCreatedAt.toUtc();
      if (nextMsgAt == null || candidateUtc.isAfter(nextMsgAt.toUtc())) {
        nextMsgAt = candidateUtc;
        nextMsgId = newestMessageId;
      } else if (candidateUtc.isAtSameMomentAs(nextMsgAt.toUtc()) &&
          newestMessageId != null &&
          newestMessageId.isNotEmpty &&
          (nextMsgId == null || newestMessageId.compareTo(nextMsgId) > 0)) {
        nextMsgId = newestMessageId;
      }
    }

    DateTime? nextDeletedAt = lastDeletedAt;
    if (newestDeletedAt != null) {
      final candidateUtc = newestDeletedAt.toUtc();
      if (nextDeletedAt == null || candidateUtc.isAfter(nextDeletedAt.toUtc())) {
        nextDeletedAt = candidateUtc;
      }
    }

    return FilesIndexSnapshot(
      items: List<Map<String, dynamic>>.unmodifiable(merged),
      lastMessageCreatedAt: nextMsgAt,
      lastMessageId: nextMsgId,
      lastDeletedAt: nextDeletedAt,
      builtWhileE2eeInactive:
          builtWhileE2eeInactive ?? this.builtWhileE2eeInactive,
    );
  }

  /// Applies local per-device chat rules (Delete for me & Clear chat) without
  /// mutating the underlying cached index.
  List<Map<String, dynamic>> filterForDisplay({
    required Set<String> hiddenIds,
    required Set<String> postClearVisibleIds,
    required int? clearedBeforeMs,
  }) {
    if (items.isEmpty) return const <Map<String, dynamic>>[];
    if (hiddenIds.isEmpty && clearedBeforeMs == null) {
      return items;
    }
    final visible = <Map<String, dynamic>>[];
    for (final item in items) {
      final rowId = item['id']?.toString();
      final clientId = item['client_message_id']?.toString();
      if ((rowId != null && hiddenIds.contains(rowId)) ||
          (clientId != null && hiddenIds.contains(clientId))) {
        continue;
      }
      final isPostClearException =
          (rowId != null && postClearVisibleIds.contains(rowId)) ||
              (clientId != null && postClearVisibleIds.contains(clientId));
      if (!isPostClearException && clearedBeforeMs != null) {
        final createdAt =
            DateTime.tryParse(item['created_at']?.toString() ?? '');
        if (createdAt != null &&
            createdAt.millisecondsSinceEpoch <= clearedBeforeMs) {
          continue;
        }
      }
      visible.add(item);
    }
    return List<Map<String, dynamic>>.unmodifiable(visible);
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'v': formatVersion,
        'lastMessageCreatedAt': lastMessageCreatedAt?.toUtc().toIso8601String(),
        'lastMessageId': lastMessageId,
        'lastDeletedAt': lastDeletedAt?.toUtc().toIso8601String(),
        'builtWhileE2eeInactive': builtWhileE2eeInactive,
        'items': items,
      };

  static FilesIndexSnapshot? fromJson(Map<dynamic, dynamic> raw) {
    if (raw['v'] != formatVersion) return null;
    final rawItems = raw['items'];
    if (rawItems is! List) return null;
    final parsedItems = rawItems
        .whereType<Map>()
        .map((e) => Map<String, dynamic>.from(e))
        .toList(growable: false);
    final lastMsgRaw = raw['lastMessageCreatedAt']?.toString();
    final lastDelRaw = raw['lastDeletedAt']?.toString();
    final lastMsgId = raw['lastMessageId']?.toString();
    return FilesIndexSnapshot(
      items: List<Map<String, dynamic>>.unmodifiable(parsedItems),
      lastMessageCreatedAt:
          lastMsgRaw == null ? null : DateTime.tryParse(lastMsgRaw)?.toUtc(),
      lastMessageId: (lastMsgId == null || lastMsgId.isEmpty) ? null : lastMsgId,
      lastDeletedAt:
          lastDelRaw == null ? null : DateTime.tryParse(lastDelRaw)?.toUtc(),
      builtWhileE2eeInactive: raw['builtWhileE2eeInactive'] == true,
    );
  }
}

/// Device-private AES-256-GCM encrypted store for [FilesIndexSnapshot], backed
/// by a 256-bit key in [FlutterSecureStorage] and a hot in-memory cache so the
/// Files tab opens instantaneously across tab switches and cold app restarts.
class FilesIndexStore {
  FilesIndexStore({
    FlutterSecureStorage? storage,
    Directory? directoryOverride,
  })  : _storage = storage ?? const FlutterSecureStorage(),
        _directoryOverride = directoryOverride;

  static final AesGcm _aesGcm = AesGcm.with256bits();
  static const String _keyPrefix = 'likedin_files_index_key_v1_';
  static const String _lastPeerPrefPrefix = 'likedin_files_last_peer_v1_';
  static final Map<String, FilesIndexSnapshot> _memoryCache =
      <String, FilesIndexSnapshot>{};
  static final Map<String, SecretKey> _keyCache = <String, SecretKey>{};

  final FlutterSecureStorage _storage;
  final Directory? _directoryOverride;

  static String _cacheId(String uid, String peerId) => '$uid::$peerId';

  static void clearMemoryCache() {
    _memoryCache.clear();
    _keyCache.clear();
  }

  /// Synchronous in-memory lookup for zero-latency tab switches.
  static FilesIndexSnapshot? peekMemory(String uid, String peerId) =>
      _memoryCache[_cacheId(uid, peerId)];

  /// Remembers the last paired peer ID so cold starts can check hidden-chat
  /// status and paint the local encrypted Files index before network RPCs return.
  Future<String?> readLastPeerId(String uid) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getString('$_lastPeerPrefPrefix$uid');
      return (saved == null || saved.isEmpty) ? null : saved;
    } catch (_) {
      return null;
    }
  }

  Future<void> saveLastPeerId(String uid, String peerId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('$_lastPeerPrefPrefix$uid', peerId);
    } catch (_) {}
  }

  Future<SecretKey> _ensureKey(String uid) async {
    final cached = _keyCache[uid];
    if (cached != null) return cached;
    final storageKey = '$_keyPrefix$uid';
    try {
      final saved = await _storage.read(key: storageKey);
      if (saved != null && saved.isNotEmpty) {
        final raw = base64Decode(saved);
        if (raw.length == 32) {
          final key = SecretKey(raw);
          _keyCache[uid] = key;
          return key;
        }
      }
    } catch (_) {}
    final rng = Random.secure();
    final bytes = List<int>.generate(32, (_) => rng.nextInt(256), growable: false);
    await _storage.write(key: storageKey, value: base64Encode(bytes));
    final key = SecretKey(bytes);
    _keyCache[uid] = key;
    return key;
  }

  Future<File> _indexFile(String uid, String peerId) async {
    final dir = _directoryOverride ?? await getApplicationSupportDirectory();
    final safeUid = uid.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_');
    final safePid = peerId.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_');
    return File(p.join(dir.path, 'likedin_files_index_v1_${safeUid}_$safePid.enc'));
  }

  /// Loads the encrypted Files index from memory or disk. Returns `null` if
  /// absent or unreadable (triggering a clean full rebuild).
  Future<FilesIndexSnapshot?> load(String uid, String peerId) async {
    final mem = _memoryCache[_cacheId(uid, peerId)];
    if (mem != null) return mem;
    try {
      final file = await _indexFile(uid, peerId);
      if (!await file.exists()) return null;
      final raw = await file.readAsBytes();
      if (raw.length < 12 + 16) return null;
      final key = await _ensureKey(uid);
      final nonce = raw.sublist(0, 12);
      final macBytes = raw.sublist(raw.length - 16);
      final cipher = raw.sublist(12, raw.length - 16);
      final clear = await _aesGcm.decrypt(
        SecretBox(cipher, nonce: nonce, mac: Mac(macBytes)),
        secretKey: key,
        aad: utf8.encode('likedin-files-index-v1:$uid:$peerId'),
      );
      final decoded = jsonDecode(utf8.decode(clear));
      if (decoded is! Map) return null;
      final snapshot = FilesIndexSnapshot.fromJson(decoded);
      if (snapshot != null) {
        _memoryCache[_cacheId(uid, peerId)] = snapshot;
      }
      return snapshot;
    } catch (error) {
      debugPrint('Files index cache unreadable (will rebuild cleanly): $error');
      return null;
    }
  }

  /// Atomically encrypts and saves [snapshot] on disk and updates memory cache.
  Future<void> save(
    String uid,
    String peerId,
    FilesIndexSnapshot snapshot,
  ) async {
    _memoryCache[_cacheId(uid, peerId)] = snapshot;
    try {
      final file = await _indexFile(uid, peerId);
      await file.parent.create(recursive: true);
      final key = await _ensureKey(uid);
      final rng = Random.secure();
      final nonce = List<int>.generate(12, (_) => rng.nextInt(256), growable: false);
      final box = await _aesGcm.encrypt(
        utf8.encode(jsonEncode(snapshot.toJson())),
        secretKey: key,
        nonce: nonce,
        aad: utf8.encode('likedin-files-index-v1:$uid:$peerId'),
      );
      final bytes = BytesBuilder(copy: false)
        ..add(box.nonce)
        ..add(box.cipherText)
        ..add(box.mac.bytes);
      final temp = File('${file.path}.tmp');
      await temp.writeAsBytes(bytes.toBytes(), flush: true);
      if (await file.exists()) await file.delete();
      await temp.rename(file.path);
    } catch (error) {
      debugPrint('Could not persist encrypted Files index: $error');
    }
  }

  Future<void> delete(String uid, String peerId) async {
    _memoryCache.remove(_cacheId(uid, peerId));
    try {
      final file = await _indexFile(uid, peerId);
      if (await file.exists()) await file.delete();
    } catch (_) {}
  }
}
