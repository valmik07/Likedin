import 'dart:async';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import '../utils/message_length.dart';
import '../utils/send_reconciliation.dart';

class RemoteMessage {
  const RemoteMessage({
    required this.id,
    required this.senderId,
    required this.recipientId,
    required this.text,
    required this.createdAt,
    this.clientMessageId,
    this.deliveredAt,
    this.readAt,
    this.replyToMessageId,
    this.editedAt,
    this.deletedForEveryoneAt,
    this.deletedMediaPath,
  });
  final String id, senderId, recipientId, text;
  final String? clientMessageId;
  final DateTime createdAt;
  final DateTime? deliveredAt, readAt, editedAt, deletedForEveryoneAt;
  final String? replyToMessageId;
  final String? deletedMediaPath;

  static DateTime? _parseOptionalDate(Object? value) {
    if (value == null) return null;
    return DateTime.tryParse(value.toString())?.toLocal();
  }

  factory RemoteMessage.fromMap(Map<String, dynamic> row) => RemoteMessage(
        id: (row['id'] ?? '').toString(),
        clientMessageId: row['client_message_id']?.toString(),
        senderId: (row['sender_id'] ?? '').toString(),
        recipientId: (row['recipient_id'] ?? '').toString(),
        // Compatibility with the two schemas shipped in prior migrations.
        // IMPORTANT: neither field name proves cryptographic encryption.
        text: (row['body_payload'] ?? row['encrypted_payload'] ?? row['ciphertext'] ?? '').toString(),
        createdAt: _parseOptionalDate(row['created_at']) ?? DateTime.now(),
        deliveredAt: _parseOptionalDate(row['delivered_at']),
        readAt: _parseOptionalDate(row['read_at']),
        replyToMessageId: row['reply_to_message_id']?.toString(),
        editedAt: _parseOptionalDate(row['edited_at']),
        deletedForEveryoneAt: _parseOptionalDate(row['deleted_for_everyone_at']),
        deletedMediaPath: row['deleted_media_path']?.toString(),
      );
}

class PeerProfile {
  const PeerProfile({
    required this.id,
    required this.name,
    required this.online,
    this.lastSeen,
    this.avatarPath,
  });
  final String id, name;
  final bool online;
  final DateTime? lastSeen;
  final String? avatarPath;
}

class RealtimeMessagingService {
  static const int conversationPageSize = 100;
  static const int reactionChunkSize = 100;

  RealtimeMessagingService(this._client);
  final SupabaseClient _client;
  static const _uuid = Uuid();
  RealtimeChannel? _channel;
  RealtimeChannel? _signalChannel;
  bool? _lastTypingState;
  bool _signalSubscribed = false;
  int _subscribeGeneration = 0;
  static String? _cachedPeerOwnerUid;
  static String? _cachedPeerId;

  static void clearCachedPeerId() {
    _cachedPeerOwnerUid = null;
    _cachedPeerId = null;
  }

  String get currentUserId {
    final id = _client.auth.currentUser?.id;
    if (id == null) throw StateError('Please sign in first.');
    return id;
  }

  Future<String?> getPeerId({bool forceRefresh = false}) async {
    final uid = _client.auth.currentUser?.id;
    if (!forceRefresh &&
        uid != null &&
        uid == _cachedPeerOwnerUid &&
        _cachedPeerId != null &&
        _cachedPeerId!.isNotEmpty) {
      return _cachedPeerId;
    }
    final value = await _client.rpc('likedin_get_peer_id');
    final peer = value?.toString();
    if (uid != null && peer != null && peer.isNotEmpty) {
      _cachedPeerOwnerUid = uid;
      _cachedPeerId = peer;
    }
    return peer;
  }

  Future<PeerProfile?> getPeerProfile() async {
    final peer = await getPeerId();
    if (peer == null) return null;
    final row = await _client
        .from('profiles')
        .select('user_id,display_name,is_online,last_seen_at,avatar_path')
        .eq('user_id', peer)
        .maybeSingle();
    if (row == null) return null;
    return PeerProfile(
      id: peer,
      name: (row['display_name'] as String?)?.trim().isNotEmpty == true
          ? (row['display_name'] as String).trim()
          : 'Likedin friend',
      online: row['is_online'] == true &&
          row['last_seen_at'] != null &&
          DateTime.parse(row['last_seen_at'] as String)
              .isAfter(DateTime.now().toUtc().subtract(const Duration(seconds: 90))),
      lastSeen: row['last_seen_at'] == null ? null : DateTime.parse(row['last_seen_at'] as String).toLocal(),
      avatarPath: row['avatar_path']?.toString(),
    );
  }

  /// Stores only the private Storage object path; the bucket remains private.
  Future<void> setProfileAvatarPath(String? path) async {
    await _client.rpc('likedin_set_profile_avatar', params: {'p_avatar_path': path});
  }

  /// Fetches the signed-in user's own stored profile avatar path from Supabase.
  Future<String?> getOwnProfileAvatarPath() async {
    final uid = _client.auth.currentUser?.id;
    if (uid == null) return null;
    final row = await _client
        .from('profiles')
        .select('avatar_path')
        .eq('user_id', uid)
        .maybeSingle();
    final path = row?['avatar_path']?.toString();
    return (path != null && path.isNotEmpty) ? path : null;
  }

  /// Creates a time-limited URL for the peer's private profile image.
  Future<String> profileAvatarSignedUrl(String path) =>
      _client.storage.from('likedin-media').createSignedUrl(path, 24 * 60 * 60);

  /// Loads the newest page by default. Older pages use a composite keyset
  /// cursor so newly-arriving messages do not shift the next page boundary.
  Future<List<RemoteMessage>> loadConversation({
    DateTime? beforeCreatedAt,
    String? beforeId,
    int limit = conversationPageSize,
  }) async {
    final uid = currentUserId;
    var query = _client.from('messages').select();
    if (beforeCreatedAt != null) {
      final stamp = beforeCreatedAt.toUtc().toIso8601String();
      if (beforeId != null && beforeId.isNotEmpty) {
        // Keep the account filter and composite cursor in one PostgREST OR
        // expression. This avoids repeated `or` query parameters while
        // preserving a deterministic (created_at, id) pagination boundary.
        query = query.or(
          'and(sender_id.eq.$uid,created_at.lt.$stamp),'
          'and(recipient_id.eq.$uid,created_at.lt.$stamp),'
          'and(sender_id.eq.$uid,created_at.eq.$stamp,id.lt.$beforeId),'
          'and(recipient_id.eq.$uid,created_at.eq.$stamp,id.lt.$beforeId)',
        );
      } else {
        query = query
            .or('sender_id.eq.$uid,recipient_id.eq.$uid')
            .lt('created_at', stamp);
      }
    } else {
      query = query.or('sender_id.eq.$uid,recipient_id.eq.$uid');
    }
    final rows = await query
        .order('created_at', ascending: false)
        .order('id', ascending: false)
        .limit(limit.clamp(1, 500).toInt());
    return rows.reversed.map((row) => RemoteMessage.fromMap(row)).toList();
  }

  /// Loads the complete conversation using the same stable composite cursor as
  /// chat pagination. Used for Contact Info counts and full encrypted backups.
  Future<List<RemoteMessage>> loadAllConversation({
    int pageSize = 500,
    int maxMessages = 100000,
    bool throwOnLimit = true,
  }) async {
    final safePageSize = pageSize.clamp(1, 500).toInt();
    final result = <RemoteMessage>[];
    DateTime? beforeCreatedAt;
    String? beforeId;

    while (true) {
      final page = await loadConversation(
        beforeCreatedAt: beforeCreatedAt,
        beforeId: beforeId,
        limit: safePageSize,
      );
      if (page.isEmpty) break;
      result.addAll(page);
      if (result.length >= maxMessages) {
        if (throwOnLimit && result.length > maxMessages) {
          throw StateError(
            'Conversation exceeds the configured export limit of $maxMessages messages.',
          );
        }
        if (result.length > maxMessages) {
          result.removeRange(maxMessages, result.length);
        }
        break;
      }
      if (page.length < safePageSize) break;
      // loadConversation returns each page oldest-first; the first row is the
      // stable cursor for fetching the next older page.
      beforeCreatedAt = page.first.createdAt;
      beforeId = page.first.id;
    }
    // Each fetched page is oldest-first internally, but pages are requested
    // newest-to-oldest. Sort once across page boundaries so callers receive a
    // globally chronological conversation (Contact Info previews and backups
    // both depend on that ordering).
    result.sort((a, b) {
      final byDate = a.createdAt.compareTo(b.createdAt);
      return byDate != 0 ? byDate : a.id.compareTo(b.id);
    });
    return result;
  }

  /// Incrementally loads messages strictly newer than `(afterCreatedAt, afterId)`
  /// in chronological ascending order. Used by the Files tab so refreshes only
  /// fetch and decrypt new messages instead of re-downloading the full history.
  Future<List<RemoteMessage>> loadConversationAfter({
    required DateTime afterCreatedAt,
    String? afterId,
    int pageSize = 500,
    int maxMessages = 100000,
  }) async {
    final uid = currentUserId;
    final safePageSize = pageSize.clamp(1, 500).toInt();
    final result = <RemoteMessage>[];
    var cursorAt = afterCreatedAt.toUtc();
    var cursorId = afterId;

    while (true) {
      final stamp = cursorAt.toIso8601String();
      var query = _client.from('messages').select();
      if (cursorId != null && cursorId.isNotEmpty) {
        query = query.or(
          'and(sender_id.eq.$uid,created_at.gt.$stamp),'
          'and(recipient_id.eq.$uid,created_at.gt.$stamp),'
          'and(sender_id.eq.$uid,created_at.eq.$stamp,id.gt.$cursorId),'
          'and(recipient_id.eq.$uid,created_at.eq.$stamp,id.gt.$cursorId)',
        );
      } else {
        query = query
            .or('sender_id.eq.$uid,recipient_id.eq.$uid')
            .gt('created_at', stamp);
      }
      final rows = await query
          .order('created_at', ascending: true)
          .order('id', ascending: true)
          .limit(safePageSize);
      if (rows.isEmpty) break;
      final page = rows.map((row) => RemoteMessage.fromMap(row)).toList();
      result.addAll(page);
      if (result.length >= maxMessages) {
        if (result.length > maxMessages) {
          result.removeRange(maxMessages, result.length);
        }
        break;
      }
      if (page.length < safePageSize) break;
      cursorAt = page.last.createdAt.toUtc();
      cursorId = page.last.id;
    }
    return result;
  }

  /// Lightweight tombstone fetch for messages deleted for everyone since
  /// [since], covering BOTH v2 Double-Ratchet encrypted media (whose server
  /// `deleted_media_path` is null) and legacy plaintext media.
  Future<List<({String id, DateTime? deletedAt, String? deletedMediaPath})>>
      loadDeletedMessageTombstones({
    DateTime? since,
    int limit = 200,
    int maxPages = 20,
  }) async {
    final uid = currentUserId;
    final results =
        <({String id, DateTime? deletedAt, String? deletedMediaPath})>[];
    DateTime? cursorDeletedAt = since?.toUtc();
    var pages = 0;

    while (pages < maxPages) {
      pages++;
      var query = _client
          .from('messages')
          .select('id,deleted_for_everyone_at,deleted_media_path')
          .or('sender_id.eq.$uid,recipient_id.eq.$uid')
          .not('deleted_for_everyone_at', 'is', null);
      if (cursorDeletedAt != null) {
        query = query.gt(
          'deleted_for_everyone_at',
          cursorDeletedAt.toIso8601String(),
        );
      }
      final rows = await query
          .order('deleted_for_everyone_at', ascending: true)
          .order('id', ascending: true)
          .limit(limit);
      if (rows.isEmpty) break;
      for (final row in rows) {
        final id = row['id']?.toString() ?? '';
        if (id.isEmpty) continue;
        final delRaw = row['deleted_for_everyone_at']?.toString();
        final delAt = delRaw == null ? null : DateTime.tryParse(delRaw)?.toUtc();
        final mediaPath = row['deleted_media_path']?.toString();
        results.add((
          id: id,
          deletedAt: delAt,
          deletedMediaPath:
              (mediaPath == null || mediaPath.isEmpty) ? null : mediaPath,
        ));
        if (delAt != null) {
          cursorDeletedAt = delAt;
        }
      }
      if (rows.length < limit) break;
    }
    return results;
  }

  Future<String?> sendMessage(
    String recipientId,
    String text, {
    String? clientMessageId,
    String? replyToMessageId,
  }) async {
    final clean = text.trim();
    if (clean.isEmpty) return null;
    if (likedinMessageCodePointLength(clean) > likedinMaxMessageCodePoints) {
      throw ArgumentError('Message must contain no more than 10000 characters.');
    }
    final stableId = clientMessageId ?? _uuid.v4();
    // The server function is idempotent on (sender_id, client_message_id)
    // (unique index + ON CONFLICT), so no pre-check query is needed: a retry of
    // the same ID returns the existing row. If the request fails or its reply
    // is unreadable, look the row up by the same ID before reporting failure.
    return sendWithReconciliation(
      send: () async {
        final result = await _client.rpc('likedin_send_message_v2', params: {
          'p_recipient_id': recipientId,
          'p_payload': clean,
          'p_client_message_id': stableId,
          'p_reply_to_message_id': replyToMessageId,
        });
        if (result is String && result.isNotEmpty) return result;
        if (result is Map) {
          final candidate = result['likedin_send_message_v2'] ?? result['id'];
          if (candidate != null && candidate.toString().isNotEmpty) return candidate.toString();
        }
        return null;
      },
      lookup: () => findSentMessageId(stableId),
    );
  }

  /// Returns the server row id for a message this account sent with
  /// [clientMessageId], or null if the server has no such message.
  Future<String?> findSentMessageId(String clientMessageId) async {
    final row = await _client
        .from('messages')
        .select('id')
        .eq('sender_id', currentUserId)
        .eq('client_message_id', clientMessageId)
        .maybeSingle();
    final id = row?['id']?.toString();
    return (id == null || id.isEmpty) ? null : id;
  }

  Future<void> deleteMessageForEveryone(String messageId) async {
    await _client.rpc('likedin_delete_message_for_everyone_v2', params: {'p_message_id': messageId});
  }

  /// Returns every deleted media tombstone in the user's conversation.
  /// This is paged because the chat's visible history may only contain the
  /// newest 100 messages; a device that was offline during an old deletion
  /// must still remove that attachment from its private cache on resume.
  Future<List<RemoteMessage>> loadDeletedMediaMessages({
    int limit = 100,
    int maxPages = 50,
    DateTime? since,
  }) async {
    final uid = currentUserId;
    final results = <RemoteMessage>[];
    DateTime? beforeCreatedAt;
    String? beforeId;
    var pages = 0;
    while (pages < maxPages) {
      pages++;
      var query = _client
          .from('messages')
          .select()
          .not('deleted_for_everyone_at', 'is', null)
          .not('deleted_media_path', 'is', null);
      if (since != null) {
        query = query.gt('deleted_for_everyone_at', since.toUtc().toIso8601String());
      }
      if (beforeCreatedAt == null) {
        query = query.or('sender_id.eq.$uid,recipient_id.eq.$uid');
      } else {
        final stamp = beforeCreatedAt.toUtc().toIso8601String();
        query = query.or(
          'and(sender_id.eq.$uid,created_at.lt.$stamp),'
          'and(recipient_id.eq.$uid,created_at.lt.$stamp),'
          'and(sender_id.eq.$uid,created_at.eq.$stamp,id.lt.$beforeId),'
          'and(recipient_id.eq.$uid,created_at.eq.$stamp,id.lt.$beforeId)',
        );
      }
      final rows = await query
          .order('created_at', ascending: false)
          .order('id', ascending: false)
          .limit(limit);
      if (rows.isEmpty) break;
      results.addAll(rows.map((row) => RemoteMessage.fromMap(row)));
      final oldest = rows.last;
      beforeCreatedAt = DateTime.parse(oldest['created_at'].toString());
      beforeId = oldest['id']?.toString();
      if (rows.length < limit || beforeId == null || beforeId.isEmpty) break;
    }
    return results;
  }

  Future<RemoteMessage?> getMessageById(String messageId) async {
    final row = await _client.from('messages').select().eq('id', messageId).maybeSingle();
    return row == null ? null : RemoteMessage.fromMap(row);
  }

  /// Fetches reply targets that are outside the currently loaded chat page.
  /// This keeps reply context (including photo/video names) intact after an
  /// app restart without pulling older messages into the visible timeline.
  Future<List<RemoteMessage>> loadMessagesByIds(Iterable<String> ids) async {
    final uniqueIds = ids.where((id) => id.isNotEmpty).toSet().toList();
    if (uniqueIds.isEmpty) return <RemoteMessage>[];
    final result = <RemoteMessage>[];
    for (var start = 0; start < uniqueIds.length; start += 100) {
      final end = (start + 100).clamp(0, uniqueIds.length).toInt();
      final rows = await _client
          .from('messages')
          .select()
          .inFilter('id', uniqueIds.sublist(start, end));
      result.addAll(rows.map((row) => RemoteMessage.fromMap(row)));
    }
    return result;
  }

  Future<void> editMessage(String messageId, String text) async {
    final clean = text.trim();
    if (clean.isEmpty || likedinMessageCodePointLength(clean) > likedinMaxMessageCodePoints) {
      throw ArgumentError('Message must contain 1 to 10000 characters.');
    }
    await _client.rpc('likedin_edit_message', params: {'p_message_id': messageId, 'p_new_payload': clean});
  }

  Future<Map<String, Set<String>>> loadReactions(List<String> messageIds) async {
    final detailed = await loadDetailedReactions(messageIds);
    return <String, Set<String>>{
      for (final entry in detailed.entries) entry.key: entry.value.keys.toSet(),
    };
  }

  /// Returns `message_id -> { emoji -> Set<user_id> }` so the chat UI can render
  /// reaction counts, highlight the current user's own reactions, and toggle on tap.
  Future<Map<String, Map<String, Set<String>>>> loadDetailedReactions(
    List<String> messageIds,
  ) async {
    if (messageIds.isEmpty) return <String, Map<String, Set<String>>>{};
    final result = <String, Map<String, Set<String>>>{};
    for (var start = 0; start < messageIds.length; start += reactionChunkSize) {
      final end = (start + reactionChunkSize).clamp(0, messageIds.length).toInt();
      final chunk = messageIds.sublist(start, end);
      final rows = await _client
          .from('message_reactions')
          .select('message_id,emoji,user_id')
          .inFilter('message_id', chunk);
      for (final row in rows) {
        final id = row['message_id']?.toString();
        final emoji = row['emoji']?.toString();
        final userId = row['user_id']?.toString();
        if (id == null || emoji == null || userId == null) continue;
        final byEmoji = result[id] ??= <String, Set<String>>{};
        (byEmoji[emoji] ??= <String>{}).add(userId);
      }
    }
    return result;
  }

  Future<bool> hasMyReaction(String messageId, String emoji) async {
    final row = await _client
        .from('message_reactions')
        .select('message_id')
        .eq('message_id', messageId)
        .eq('user_id', currentUserId)
        .eq('emoji', emoji)
        .maybeSingle();
    return row != null;
  }

  Future<void> setReaction(String messageId, String emoji, {required bool active}) async {
    await _client.rpc('likedin_set_message_reaction', params: {
      'p_message_id': messageId,
      'p_emoji': emoji,
      'p_active': active,
    });
  }

  Future<void> setOnline(bool online) async {
    await _client.rpc('likedin_set_presence', params: {'p_online': online});
  }

  Future<void> markDelivered() async {
    await _client.rpc('likedin_mark_delivered');
  }

  Future<void> markRead() async {
    await _client.rpc('likedin_mark_read');
  }

  void subscribe({
    required String? peerId,
    required void Function() onMessages,
    required void Function() onProfile,
    required void Function(bool) onTyping,
    void Function(Map<String, dynamic>)? onMessageInsert,
    void Function(Map<String, dynamic>)? onMessageUpdate,
    void Function(String messageId)? onReactionChange,
    void Function()? onReconnect,
    void Function(bool connected)? onConnectionStateChanged,
  }) {
    unsubscribe();
    final uid = currentUserId;
    final gen = ++_subscribeGeneration;
    var dataChannel = _client.channel('likedin-data-$uid-$gen');

    // Only the recipient device needs the INSERT event. The sender reconciles
    // its own send from the RPC result/REST load; subscribing to its own INSERT
    // would create a second copy of the same message event for no benefit.
    dataChannel = dataChannel.onPostgresChanges(
      event: PostgresChangeEvent.insert,
      schema: 'public',
      table: 'messages',
      filter: PostgresChangeFilter(
        type: PostgresChangeFilterType.eq,
        column: 'recipient_id',
        value: uid,
      ),
      callback: (payload) {
        if (onMessageInsert != null && payload.newRecord.isNotEmpty) {
          onMessageInsert(Map<String, dynamic>.from(payload.newRecord));
        } else {
          onMessages();
        }
      },
    );

    // Receipt changes for our sent messages and delete-for-everyone changes
    // for messages addressed to us are both needed by the UI.
    dataChannel = dataChannel.onPostgresChanges(
      event: PostgresChangeEvent.update,
      schema: 'public',
      table: 'messages',
      filter: PostgresChangeFilter(
        type: PostgresChangeFilterType.eq,
        column: 'sender_id',
        value: uid,
      ),
      callback: (payload) {
        // PostgreSQL UPDATE records include the complete row. Receipt changes,
        // edits and delete-for-everyone are applied directly to an already
        // loaded bubble; they do not need a full conversation/reaction reload.
        onMessageUpdate?.call(Map<String, dynamic>.from(payload.newRecord));
      },
    );
    dataChannel = dataChannel.onPostgresChanges(
      event: PostgresChangeEvent.update,
      schema: 'public',
      table: 'messages',
      filter: PostgresChangeFilter(
        type: PostgresChangeFilterType.eq,
        column: 'recipient_id',
        value: uid,
      ),
      callback: (payload) {
        onMessageUpdate?.call(Map<String, dynamic>.from(payload.newRecord));
      },
    );
    dataChannel = dataChannel
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'message_reactions',
          callback: (payload) {
            final id = payload.newRecord['message_id']?.toString();
            if (id != null && id.isNotEmpty) onReactionChange?.call(id);
          },
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.delete,
          schema: 'public',
          table: 'message_reactions',
          callback: (payload) {
            final id = payload.oldRecord['message_id']?.toString();
            if (id != null && id.isNotEmpty) onReactionChange?.call(id);
          },
        );

    // Each phone only listens for the other account's profile. This avoids
    // consuming Realtime quota on its own profile heartbeat/avatar update.
    if (peerId != null) {
      dataChannel = dataChannel.onPostgresChanges(
        event: PostgresChangeEvent.update,
        schema: 'public',
        table: 'profiles',
        filter: PostgresChangeFilter(
          type: PostgresChangeFilterType.eq,
          column: 'user_id',
          value: peerId,
        ),
        callback: (_) => onProfile(),
      );
    }

    // Realtime events are lost while the socket is down. Every (re)subscribe
    // after the first tells the UI to resynchronise messages and reactions.
    var subscribedBefore = false;
    _channel = dataChannel
      ..subscribe((status, error) {
        // Ignore stale callbacks from channels already torn down by unsubscribe().
        if (gen != _subscribeGeneration || !identical(_channel, dataChannel)) {
          return;
        }
        if (status == RealtimeSubscribeStatus.subscribed) {
          onConnectionStateChanged?.call(true);
          if (subscribedBefore) onReconnect?.call();
          subscribedBefore = true;
        } else if (status == RealtimeSubscribeStatus.channelError ||
            status == RealtimeSubscribeStatus.timedOut ||
            status == RealtimeSubscribeStatus.closed) {
          onConnectionStateChanged?.call(false);
        }
      });
    _lastTypingState = null;
    final ids = <String>[uid, if (peerId != null) peerId]..sort();
    _signalSubscribed = false;
    _signalChannel = _client
        .channel('likedin-typing-${ids.join('-')}')
        .onBroadcast(
          event: 'typing',
          callback: (payload) {
            final from = payload['user_id']?.toString();
            if (from != null && from != uid) onTyping(payload['typing'] == true);
          },
        )
      ..subscribe((status, _) {
        _signalSubscribed = status == RealtimeSubscribeStatus.subscribed;
      });
  }

  Future<void> sendTyping(bool typing) async {
    final channel = _signalChannel;
    if (channel == null || !_signalSubscribed) return;
    // Repeated "typing: true" messages are intentional heartbeats: the peer
    // expires the indicator after 5s, so they must keep going out. Callers
    // already throttle them (the composer sends one per ~1.4s). Only redundant
    // "typing: false" messages are dropped.
    if (!typing && _lastTypingState == false) return;
    _lastTypingState = typing;
    try {
      await channel.sendBroadcastMessage(
        event: 'typing',
        payload: {'user_id': currentUserId, 'typing': typing},
      );
    } catch (_) {
      if (_lastTypingState == typing) _lastTypingState = null;
      rethrow;
    }
  }

  void unsubscribe() {
    // Advance generation BEFORE removing channels so the resulting `closed`
    // callback is recognized as intentional teardown, not an offline drop.
    _subscribeGeneration++;
    final a = _channel;
    final b = _signalChannel;
    _channel = null;
    _signalChannel = null;
    _lastTypingState = null;
    _signalSubscribed = false;
    if (a != null) _client.removeChannel(a);
    if (b != null) _client.removeChannel(b);
  }
}
