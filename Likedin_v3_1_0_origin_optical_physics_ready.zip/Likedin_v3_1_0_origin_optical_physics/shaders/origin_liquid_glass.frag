#version 460 core
#include <flutter/runtime_effect.glsl>

// Engine-bound uniforms for ImageFilter.shader (indices 0..1 + sampler 0).
uniform vec2 uSize;
uniform sampler2D uTexture;

// Custom optical glass uniforms (float indices 2..21).
uniform vec4 uRect;          // 2..5: physical px (left, top, width, height)
uniform float uRadius;       // 6: physical px corner radius
uniform float uRefraction;   // 7: bezel displacement strength (px)
uniform float uDispersion;   // 8: subtle RGB edge dispersion ratio
uniform float uFrostRadius;  // 9: single-pass micro-diffusion radius (px)
uniform vec2 uLightDir;      // 10..11: normalized directional light vector
uniform float uEdgeIntensity;// 12: material Fresnel/specular response
uniform float uDarkMode;     // 13: 1.0 dark, 0.0 light
uniform vec4 uTint;          // 14..17: glass tint (r, g, b, a)
uniform vec4 uAccent;        // 18..21: accent (r, g, b, causticStrength)

out vec4 fragColor;

float sdRoundedBox(vec2 p, vec2 b, float r) {
  vec2 q = abs(p) - b + vec2(r);
  return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r;
}

vec2 sdfNormal(vec2 p, vec2 b, float r) {
  vec2 e = vec2(1.25, 0.0);
  float dx = sdRoundedBox(p + e.xy, b, r) - sdRoundedBox(p - e.xy, b, r);
  float dy = sdRoundedBox(p + e.yx, b, r) - sdRoundedBox(p - e.yx, b, r);
  vec2 g = vec2(dx, dy);
  float len = length(g);
  return len > 0.0001 ? (g / len) : vec2(0.0, -1.0);
}

vec2 toTexUv(vec2 physPos) {
  vec2 safeSize = max(uSize, vec2(1.0));
  vec2 uv = clamp(physPos / safeSize, vec2(0.001), vec2(0.999));
  #ifdef IMPELLER_TARGET_OPENGLES
    uv.y = 1.0 - uv.y;
  #endif
  return uv;
}

vec4 sampleFrosted(vec2 centerPx, float radiusPx) {
  if (radiusPx <= 0.35) {
    return texture(uTexture, toTexUv(centerPx));
  }
  vec4 acc = texture(uTexture, toTexUv(centerPx)) * 0.24;
  float r1 = radiusPx * 0.52;
  float r2 = radiusPx;

  acc += texture(uTexture, toTexUv(centerPx + vec2( r1,  0.0))) * 0.11;
  acc += texture(uTexture, toTexUv(centerPx + vec2(-r1,  0.0))) * 0.11;
  acc += texture(uTexture, toTexUv(centerPx + vec2( 0.0,  r1))) * 0.11;
  acc += texture(uTexture, toTexUv(centerPx + vec2( 0.0, -r1))) * 0.11;

  float d2 = r2 * 0.70710678;
  acc += texture(uTexture, toTexUv(centerPx + vec2( d2,  d2))) * 0.08;
  acc += texture(uTexture, toTexUv(centerPx + vec2(-d2,  d2))) * 0.08;
  acc += texture(uTexture, toTexUv(centerPx + vec2( d2, -d2))) * 0.08;
  acc += texture(uTexture, toTexUv(centerPx + vec2(-d2, -d2))) * 0.08;
  return acc;
}

void main() {
  vec2 fragPx = FlutterFragCoord().xy;

  if (uRect.z <= 2.0 || uRect.w <= 2.0) {
    fragColor = texture(uTexture, toTexUv(fragPx));
    return;
  }

  vec2 halfSize = uRect.zw * 0.5;
  vec2 center = uRect.xy + halfSize;
  vec2 localP = fragPx - center;
  float r = clamp(uRadius, 1.0, min(halfSize.x, halfSize.y));

  float dist = sdRoundedBox(localP, halfSize, r);
  if (dist > 1.0) {
    fragColor = texture(uTexture, toTexUv(fragPx));
    return;
  }

  float bezelWidth = clamp(min(halfSize.x, halfSize.y) * 0.42, 8.0, 44.0);
  float depthIn = max(0.0, -dist);
  float edgeT = clamp(1.0 - (depthIn / bezelWidth), 0.0, 1.0);
  float smoothBezel = edgeT * edgeT * (3.0 - 2.0 * edgeT);
  float boundaryTaper = smoothstep(0.0, 1.5, depthIn);

  vec2 n2d = sdfNormal(localP, halfSize, r);
  float slope = smoothBezel * 0.82;
  vec3 normal3d = normalize(vec3(n2d * slope, sqrt(max(0.05, 1.0 - slope * slope))));

  float dispMag = smoothBezel * smoothBezel * boundaryTaper * uRefraction;
  vec2 baseSamplePx = fragPx - n2d * dispMag;

  vec4 refracted;
  if (uDispersion > 0.005 && dispMag > 0.6) {
    vec2 redPx = fragPx - n2d * (dispMag * (1.0 - uDispersion));
    vec2 bluePx = fragPx - n2d * (dispMag * (1.0 + uDispersion));
    vec4 gSample = sampleFrosted(baseSamplePx, uFrostRadius);
    float rChan = sampleFrosted(redPx, uFrostRadius * 0.75).r;
    float bChan = sampleFrosted(bluePx, uFrostRadius * 0.75).b;
    refracted = vec4(rChan, gSample.g, bChan, gSample.a);
  } else {
    refracted = sampleFrosted(baseSamplePx, uFrostRadius);
  }

  vec3 viewDir = vec3(0.0, 0.0, 1.0);
  vec3 lightDir = normalize(vec3(uLightDir, 0.62));
  vec3 halfVec = normalize(lightDir + viewDir);

  float ndotv = clamp(dot(normal3d, viewDir), 0.0, 1.0);
  float fresnel = pow(1.0 - ndotv, 2.6) * uEdgeIntensity;
  float ndotl = clamp(dot(normal3d, lightDir), 0.0, 1.0);
  float spec = pow(clamp(dot(normal3d, halfVec), 0.0, 1.0), 14.0) * smoothBezel * uEdgeIntensity;

  float innerContour = exp(-pow((depthIn - 3.2) / 2.2, 2.0)) * uEdgeIntensity;

  vec2 oppLight = -normalize(uLightDir);
  float oppAlign = clamp(dot(n2d, oppLight), 0.0, 1.0);
  float caustic = smoothBezel * oppAlign * uAccent.a;

  vec3 color = mix(refracted.rgb, uTint.rgb, clamp(uTint.a, 0.0, 0.92));

  float specGain = mix(0.28, 0.22, uDarkMode);
  float fresnelGain = mix(0.22, 0.16, uDarkMode);
  float contourGain = mix(0.16, 0.12, uDarkMode);

  color += vec3(1.0) * (spec * specGain + fresnel * fresnelGain + innerContour * contourGain * (0.45 + 0.55 * ndotl));
  color += mix(vec3(1.0), uAccent.rgb, 0.55) * (caustic * mix(0.24, 0.28, uDarkMode));

  fragColor = vec4(clamp(color, 0.0, 1.0), refracted.a);
}
