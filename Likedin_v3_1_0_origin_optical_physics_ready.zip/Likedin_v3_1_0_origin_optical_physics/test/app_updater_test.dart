import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/utils/app_updater.dart';

void main() {
  group('AppUpdater.selectArm64ApkUrl', () {
    test('selects strict HTTPS arm64 APK and ignores non-ARM64 assets', () {
      final url = AppUpdater.selectArm64ApkUrl([
        {
          'name': 'likedin-armeabi-v7a-v2.5.0.apk',
          'browser_download_url': 'https://example.com/v7a.apk',
        },
        {
          'name': 'likedin-x86_64-v2.5.0.apk',
          'browser_download_url': 'https://example.com/x86.apk',
        },
        {
          'name': 'likedin-arm64-v2.5.0+129.apk',
          'browser_download_url': 'https://example.com/arm64.apk',
        },
      ]);
      expect(url, 'https://example.com/arm64.apk');
    });

    test('returns null instead of falling back to incompatible or non-HTTPS APK', () {
      expect(
        AppUpdater.selectArm64ApkUrl([
          {
            'name': 'likedin-universal-debug.apk',
            'browser_download_url': 'https://example.com/universal.apk',
          },
          {
            'name': 'likedin-arm64-v2.5.0.apk',
            'browser_download_url': 'http://insecure.example.com/arm64.apk',
          },
        ]),
        isNull,
      );
    });
  });

  group('AppUpdater.shouldRunAutomaticCheck', () {
    test('throttles successful checks for 6 hours but retries failed checks after 15 minutes', () {
      const now = 1000 * 60 * 60 * 24;
      // 1 hour after success -> skip
      expect(
        AppUpdater.shouldRunAutomaticCheck(
          nowMs: now,
          lastSuccessMs: now - const Duration(hours: 1).inMilliseconds,
          lastFailureMs: 0,
        ),
        isFalse,
      );
      // 7 hours after success -> run
      expect(
        AppUpdater.shouldRunAutomaticCheck(
          nowMs: now,
          lastSuccessMs: now - const Duration(hours: 7).inMilliseconds,
          lastFailureMs: 0,
        ),
        isTrue,
      );
      // 5 minutes after failure -> wait
      expect(
        AppUpdater.shouldRunAutomaticCheck(
          nowMs: now,
          lastSuccessMs: 0,
          lastFailureMs: now - const Duration(minutes: 5).inMilliseconds,
        ),
        isFalse,
      );
      // 16 minutes after failure -> retry
      expect(
        AppUpdater.shouldRunAutomaticCheck(
          nowMs: now,
          lastSuccessMs: 0,
          lastFailureMs: now - const Duration(minutes: 16).inMilliseconds,
        ),
        isTrue,
      );
    });
  });

  test('isNewerVersion compares semver and build numbers accurately', () {
    expect(AppUpdater.isNewerVersion('2.5.0+129', '2.4.3+128'), isTrue);
    expect(AppUpdater.isNewerVersion('v2.5.0+130', '2.5.0+129'), isTrue);
    expect(AppUpdater.isNewerVersion('2.5.0+129', '2.5.0+129'), isFalse);
    expect(AppUpdater.isNewerVersion('2.4.3+128', '2.5.0+129'), isFalse);
  });

  group('AppUpdater SHA-256 integrity verification', () {
    test('selectArm64Sha256Url selects HTTPS ARM64 .apk.sha256 asset only', () {
      final url = AppUpdater.selectArm64Sha256Url([
        {
          'name': 'likedin-arm64-v2.8.3+137.apk',
          'browser_download_url': 'https://example.com/arm64.apk',
        },
        {
          'name': 'likedin-x86_64-v2.8.3+137.apk.sha256',
          'browser_download_url': 'https://example.com/x86.apk.sha256',
        },
        {
          'name': 'likedin-arm64-v2.8.3+137.apk.sha256',
          'browser_download_url': 'https://example.com/arm64.apk.sha256',
        },
      ]);
      expect(url, 'https://example.com/arm64.apk.sha256');
    });

    test('parseSha256Hex extracts standard sha256sum digest and rejects invalid text', () {
      const digest = '72a635cb3d2f3524c51620cdde406b217204e8a6a06c6a096ff8ed4b5fd6e27b';
      expect(
        AppUpdater.parseSha256Hex('${digest.toUpperCase()}  likedin-arm64-v2.8.3+137.apk\n'),
        digest,
      );
      expect(AppUpdater.parseSha256Hex('not-a-valid-hash'), isNull);
    });

    test('computeFileSha256Hex matches known SHA-256 vector', () async {
      final dir = await Directory.systemTemp.createTemp('likedin_updater_sha_');
      addTearDown(() => dir.delete(recursive: true));
      final f = File('${dir.path}/sample.apk')..writeAsStringSync('abc');
      // Standard NIST SHA-256("abc")
      expect(
        await AppUpdater.computeFileSha256Hex(f),
        'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad',
      );
    });

    test('requiresSha256Checksum enforces checksum for v2.8.3+ and fails closed when absent', () {
      expect(AppUpdater.requiresSha256Checksum('2.8.2+136'), isFalse);
      expect(AppUpdater.requiresSha256Checksum('2.8.3'), isTrue);
      expect(AppUpdater.requiresSha256Checksum('2.8.3+137'), isTrue);
      expect(AppUpdater.requiresSha256Checksum('v2.8.4+138'), isTrue);
      expect(AppUpdater.requiresSha256Checksum('3.0.0+200'), isTrue);

      final apkOnlyAssets = [
        {
          'name': 'likedin-arm64-v2.8.4+138.apk',
          'browser_download_url': 'https://example.com/arm64.apk',
        },
      ];
      expect(
        () => AppUpdater.resolveReleaseAssets('2.8.4+138', apkOnlyAssets),
        throwsA(isA<StateError>()),
      );

      // Legacy pre-2.8.3 releases without a checksum remain selectable.
      final legacy = AppUpdater.resolveReleaseAssets('2.8.2+136', apkOnlyAssets);
      expect(legacy.apkUrl, 'https://example.com/arm64.apk');
      expect(legacy.sha256Url, isNull);

      // v2.8.4+ with both APK and .apk.sha256 succeeds.
      final valid = AppUpdater.resolveReleaseAssets('2.8.4+138', [
        ...apkOnlyAssets,
        {
          'name': 'likedin-arm64-v2.8.4+138.apk.sha256',
          'browser_download_url': 'https://example.com/arm64.apk.sha256',
        },
      ]);
      expect(valid.sha256Url, 'https://example.com/arm64.apk.sha256');
    });
  });
}
