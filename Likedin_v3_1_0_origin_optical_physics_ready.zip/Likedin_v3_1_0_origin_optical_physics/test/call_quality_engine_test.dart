import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/calls/call_quality_engine.dart';

void main() {
  group('CallQualityEngine SDP tuning', () {
    const sampleSdp = 'v=0\r\n'
        'o=- 123 2 IN IP4 127.0.0.1\r\n'
        's=-\r\n'
        'm=audio 9 UDP/TLS/RTP/SAVPF 111 103 0\r\n'
        'a=rtpmap:111 opus/48000/2\r\n'
        'a=fmtp:111 minptime=10;useinbandfec=0\r\n'
        'm=video 9 UDP/TLS/RTP/SAVPF 96 98 100 102\r\n'
        'a=rtpmap:96 VP9/90000\r\n'
        'a=rtpmap:98 AV1/90000\r\n'
        'a=rtpmap:100 VP8/90000\r\n'
        'a=rtpmap:102 H264/90000\r\n';

    test('enables Opus in-band FEC, DTX silence suppression, and voice bitrate cap', () {
      final tuned = CallQualityEngine.tuneSdpForVoiceAndHardwareVideo(sampleSdp);
      expect(tuned, contains('useinbandfec=1'));
      expect(tuned, contains('usedtx=1'));
      expect(tuned, contains('maxaveragebitrate=36000'));

      final saver = CallQualityEngine.tuneSdpForVoiceAndHardwareVideo(
        sampleSdp,
        dataSaver: true,
      );
      expect(saver, contains('maxaveragebitrate=28000'));
    });

    test('reorders video m-line to prioritize hardware H264 and VP8 ahead of VP9/AV1', () {
      final tuned = CallQualityEngine.tuneSdpForVoiceAndHardwareVideo(sampleSdp);
      final videoLine = tuned.split('\r\n').firstWhere((l) => l.startsWith('m=video '));
      expect(videoLine, 'm=video 9 UDP/TLS/RTP/SAVPF 102 100 96 98');
    });

    test('inserts a=fmtp line for Opus when absent', () {
      const noFmtp = 'm=audio 9 UDP/TLS/RTP/SAVPF 111\r\na=rtpmap:111 opus/48000/2\r\n';
      final tuned = CallQualityEngine.tuneSdpForVoiceAndHardwareVideo(noFmtp);
      expect(tuned, contains('a=fmtp:111 '));
      expect(tuned, contains('useinbandfec=1'));
      expect(tuned, contains('usedtx=1'));
    });
  });

  group('CallQualityEngine adaptive ladder & stats', () {
    test('evaluates RTT and packet loss into HD/Good/Fair/Weak/Reconnecting', () {
      expect(
        CallQualityEngine.evaluateTier(rttMs: 45, lossPercent: 0.2, reconnecting: false),
        CallQualityTier.hd,
      );
      expect(
        CallQualityEngine.evaluateTier(rttMs: 160, lossPercent: 0.5, reconnecting: false),
        CallQualityTier.good,
      );
      expect(
        CallQualityEngine.evaluateTier(rttMs: 280, lossPercent: 2.0, reconnecting: false),
        CallQualityTier.fair,
      );
      expect(
        CallQualityEngine.evaluateTier(rttMs: 90, lossPercent: 9.5, reconnecting: false),
        CallQualityTier.weak,
      );
      expect(
        CallQualityEngine.evaluateTier(rttMs: 25, lossPercent: 0.0, reconnecting: true),
        CallQualityTier.reconnecting,
      );
    });

    test('dataSaver caps bitrate, framerate, and downscales resolution cleanly', () {
      final hdNormal = CallQualityEngine.profileFor(
        CallQualityTier.hd,
        dataSaver: false,
        lowRamDevice: false,
      );
      final hdLowRam = CallQualityEngine.profileFor(
        CallQualityTier.hd,
        dataSaver: false,
        lowRamDevice: true,
      );
      final saver = CallQualityEngine.profileFor(
        CallQualityTier.hd,
        dataSaver: true,
        lowRamDevice: false,
      );

      expect(hdNormal.maxVideoBitrateBps, greaterThan(hdLowRam.maxVideoBitrateBps));
      expect(saver.maxVideoBitrateBps, 260000);
      expect(saver.maxFramerate, 15);
      expect(saver.scaleResolutionDownBy, 1.6);
      expect(saver.label, 'Saver');
    });

    test('extractStatsSample and computeLossPercent calculate RTT and delta loss accurately', () {
      final sample = CallQualityEngine.extractStatsSample([
        (
          type: 'candidate-pair',
          values: {'state': 'succeeded', 'nominated': true, 'currentRoundTripTime': 0.084},
        ),
        (
          type: 'inbound-rtp',
          values: {'packetsLost': 5, 'packetsReceived': 195},
        ),
      ]);
      expect(sample.rttMs, closeTo(84.0, 0.001));
      expect(sample.packetsLost, 5);
      expect(sample.packetsReceived, 195);

      final loss = CallQualityEngine.computeLossPercent(
        prevLost: 5,
        prevReceived: 195,
        currLost: 10,
        currReceived: 290,
      );
      expect(loss, closeTo(5.0, 0.001));
    });

    test('isPoliteIcePeer deterministically assigns opposite roles to any pair', () {
      final aPolite = CallQualityEngine.isPoliteIcePeer(localUid: 'user-a', peerUid: 'user-b');
      final bPolite = CallQualityEngine.isPoliteIcePeer(localUid: 'user-b', peerUid: 'user-a');
      expect(aPolite, isNot(bPolite));
    });
  });
}
