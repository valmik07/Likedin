import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:likedin/motion/origin_motion.dart';
import 'package:likedin/ui/glassmorphism.dart';
import 'package:likedin/ui/origin_island.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('OriginOS 7 defaults to minimum effects (Soft glass, Glint off, 30% motion) across all devices', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await LikedinAppearance.load(null, false);
    expect(LikedinAppearance.effects.value, LikedinEffects.soft);
    expect(LikedinAppearance.glintEnabled.value, isFalse);
    expect(OriginMotionEngine.deformationIntensity.value, closeTo(0.30, 0.001));

    SharedPreferences.setMockInitialValues(<String, Object>{});
    await LikedinAppearance.load(null, true);
    expect(LikedinAppearance.effects.value, LikedinEffects.soft);
    expect(LikedinAppearance.glintEnabled.value, isFalse);
    expect(OriginMotionEngine.deformationIntensity.value, closeTo(0.30, 0.001));
  });

  test('All 4 OriginOS 7 glass textures persist and expose readable labels', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    for (final texture in LikedinEffects.values) {
      await LikedinAppearance.setEffects(texture);
      expect(LikedinAppearance.effects.value, texture);
      expect(LikedinAppearance.textureLabel.isNotEmpty, isTrue);
    }
    await LikedinAppearance.reset();
  });

  test('OriginIslandHost shows and clears live events cleanly', () {
    OriginIslandHost.clear();
    expect(OriginIslandHost.current.value, isNull);

    OriginIslandHost.show(
      title: 'Sending media…',
      loading: true,
      icon: Icons.cloud_upload_rounded,
      accent: const Color(0xFF4FDBA5),
    );
    expect(OriginIslandHost.current.value?.title, 'Sending media…');
    expect(OriginIslandHost.current.value?.loading, isTrue);

    OriginIslandHost.clear();
    expect(OriginIslandHost.current.value, isNull);
  });

  testWidgets('LikedinPressScale never cancels descendant InkWell onTap when glow activates', (tester) async {
    LikedinAppearance.effects.value = LikedinEffects.real;
    LikedinAppearance.reduceMotion.value = false;
    var tapped = 0;

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Center(
            child: LikedinPressScale(
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () => tapped++,
                  child: const SizedBox(width: 140, height: 60, child: Center(child: Text('Open Chat'))),
                ),
              ),
            ),
          ),
        ),
      ),
    );

    await tester.tap(find.text('Open Chat'));
    await tester.pumpAndSettle();
    expect(tapped, 1);
  });

  testWidgets('OriginFloatingDock fires onSelect for every tab with Real glass enabled', (tester) async {
    LikedinAppearance.effects.value = LikedinEffects.real;
    LikedinAppearance.reduceMotion.value = false;
    var selectedTab = 0;

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          bottomNavigationBar: Padding(
            padding: const EdgeInsets.all(16),
            child: StatefulBuilder(
              builder: (context, setState) => OriginFloatingDock(
                activeTab: selectedTab,
                onSelect: (tab) => setState(() => selectedTab = tab),
                items: const [
                  OriginDockItem(
                    tab: 0,
                    icon: Icons.chat_bubble_outline_rounded,
                    activeIcon: Icons.chat_bubble_rounded,
                    label: 'Chats',
                  ),
                  OriginDockItem(
                    tab: 2,
                    icon: Icons.call_outlined,
                    activeIcon: Icons.call_rounded,
                    label: 'Calls',
                  ),
                  OriginDockItem(
                    tab: 3,
                    icon: Icons.perm_media_outlined,
                    activeIcon: Icons.perm_media_rounded,
                    label: 'Files',
                  ),
                  OriginDockItem(
                    tab: 5,
                    icon: Icons.person_outline_rounded,
                    activeIcon: Icons.person_rounded,
                    label: 'Profile',
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );

    await tester.tap(find.text('Calls'));
    await tester.pumpAndSettle();
    expect(selectedTab, 2);

    await tester.tap(find.text('Files'));
    await tester.pumpAndSettle();
    expect(selectedTab, 3);

    await tester.tap(find.text('Profile'));
    await tester.pumpAndSettle();
    expect(selectedTab, 5);
  });

  testWidgets('OriginFloatingDock glides with finger drag to switch tabs seamlessly', (tester) async {
    LikedinAppearance.effects.value = LikedinEffects.real;
    LikedinAppearance.reduceMotion.value = false;
    var selectedTab = 0;

    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          bottomNavigationBar: Padding(
            padding: const EdgeInsets.all(16),
            child: StatefulBuilder(
              builder: (context, setState) => OriginFloatingDock(
                activeTab: selectedTab,
                onSelect: (tab) => setState(() => selectedTab = tab),
                items: const [
                  OriginDockItem(
                    tab: 0,
                    icon: Icons.chat_bubble_outline_rounded,
                    activeIcon: Icons.chat_bubble_rounded,
                    label: 'Chats',
                  ),
                  OriginDockItem(
                    tab: 2,
                    icon: Icons.call_outlined,
                    activeIcon: Icons.call_rounded,
                    label: 'Calls',
                  ),
                  OriginDockItem(
                    tab: 3,
                    icon: Icons.perm_media_outlined,
                    activeIcon: Icons.perm_media_rounded,
                    label: 'Files',
                  ),
                  OriginDockItem(
                    tab: 5,
                    icon: Icons.person_outline_rounded,
                    activeIcon: Icons.person_rounded,
                    label: 'Profile',
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );

    final chatsCenter = tester.getCenter(find.text('Chats'));
    final filesCenter = tester.getCenter(find.text('Files'));
    final profileCenter = tester.getCenter(find.text('Profile'));

    // Glide finger from Chats -> Files
    final gesture1 = await tester.startGesture(chatsCenter);
    await tester.pump(const Duration(milliseconds: 16));
    await gesture1.moveTo(filesCenter);
    await tester.pump(const Duration(milliseconds: 32));
    await gesture1.up();
    await tester.pumpAndSettle();
    expect(selectedTab, 3);

    // Glide finger from Files -> Profile
    final gesture2 = await tester.startGesture(filesCenter);
    await tester.pump(const Duration(milliseconds: 16));
    await gesture2.moveTo(profileCenter);
    await tester.pump(const Duration(milliseconds: 32));
    await gesture2.up();
    await tester.pumpAndSettle();
    expect(selectedTab, 5);
  });

  test('OriginPhysics.rubberBand stays bounded and symmetric', () {
    expect(OriginPhysics.rubberBand(0, 60), 0.0);
    expect(OriginPhysics.rubberBand(60, 60), closeTo(30.0, 0.001));
    expect(OriginPhysics.rubberBand(-60, 60), closeTo(-30.0, 0.001));
    expect(OriginPhysics.rubberBand(5000, 60), lessThan(60.0));
  });

  test('LikedinAppearance.textScale defaults to 1.0, clamps bounds, persists, and resets', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await LikedinAppearance.load(null, false);
    expect(LikedinAppearance.textScale.value, 1.0);

    await LikedinAppearance.setTextScale(1.8);
    expect(LikedinAppearance.textScale.value, LikedinAppearance.maxTextScale);

    await LikedinAppearance.setTextScale(0.5);
    expect(LikedinAppearance.textScale.value, LikedinAppearance.minTextScale);

    await LikedinAppearance.setTextScale(0.92);
    expect(LikedinAppearance.textScale.value, closeTo(0.92, 0.0001));

    await LikedinAppearance.reset();
    expect(LikedinAppearance.textScale.value, 1.0);
  });
}
