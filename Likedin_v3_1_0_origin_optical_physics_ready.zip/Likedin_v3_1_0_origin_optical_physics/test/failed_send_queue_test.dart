import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/backend/realtime_messaging_service.dart';
import 'package:likedin/utils/failed_send_queue.dart';

void main() {
  group('FailedSendQueue', () {
    test('round-trips JSON serialization and preserves ratchetSessionId & wireText', () {
      final now = DateTime.utc(2026, 11, 28, 12, 0);
      final queue = FailedSendQueue();
      queue.upsert(
        FailedSendEntry(
          id: 'client-1',
          text: 'hello offline',
          wireText: '{"__likedin_e2ee_v2":2,"c":"abc"}',
          ratchetSessionId: 'session-A',
          recipientId: 'peer-1',
          replyId: 'msg-99',
          createdAtMs: now.millisecondsSinceEpoch,
        ),
      );

      final encoded = queue.toJsonList(now: now);
      final restored = FailedSendQueue();
      final dropped = restored.loadFromJson(encoded, merge: false, now: now);

      expect(dropped, isFalse);
      expect(restored.length, 1);
      final item = restored['client-1']!;
      expect(item.text, 'hello offline');
      expect(item.wireText, '{"__likedin_e2ee_v2":2,"c":"abc"}');
      expect(item.ratchetSessionId, 'session-A');
      expect(item.recipientId, 'peer-1');
      expect(item.replyId, 'msg-99');
    });

    test('reusableWireText returns cached ciphertext only for matching session & unexpired age', () {
      final created = DateTime.utc(2026, 11, 20, 12, 0);
      final entry = FailedSendEntry(
        id: 'client-2',
        text: 'retry me',
        wireText: '{"__likedin_e2ee_v2":2,"c":"cipher"}',
        ratchetSessionId: 'session-A',
        recipientId: 'peer-1',
        createdAtMs: created.millisecondsSinceEpoch,
      );

      // Same session & within 7 days -> reuses exact ciphertext (zero ratchet burn).
      expect(
        entry.reusableWireText(
          currentRatchetSessionId: 'session-A',
          now: created.add(const Duration(days: 2)),
        ),
        '{"__likedin_e2ee_v2":2,"c":"cipher"}',
      );

      // Different session (ratchet reset / re-paired) -> forces fresh encryption!
      expect(
        entry.reusableWireText(
          currentRatchetSessionId: 'session-B',
          now: created.add(const Duration(minutes: 5)),
        ),
        isNull,
      );

      // Older than 7 days -> expired, cannot reuse stale ciphertext!
      expect(
        entry.reusableWireText(
          currentRatchetSessionId: 'session-A',
          now: created.add(const Duration(days: 8)),
        ),
        isNull,
      );
    });

    test('expires entries older than 7 days during loadFromJson and pruneExpired', () {
      final now = DateTime.utc(2026, 11, 28, 12, 0);
      final oldMs = now.subtract(const Duration(days: 8)).millisecondsSinceEpoch;
      final freshMs = now.subtract(const Duration(hours: 2)).millisecondsSinceEpoch;

      final queue = FailedSendQueue();
      final dropped = queue.loadFromJson(
        [
          {
            'id': 'stale-1',
            'text': 'too old',
            'wireText': 'cipher-old',
            'ratchetSessionId': 'sid-1',
            'recipientId': 'peer-1',
            'createdAtMs': oldMs,
          },
          {
            'id': 'fresh-1',
            'text': 'still valid',
            'wireText': 'cipher-fresh',
            'ratchetSessionId': 'sid-1',
            'recipientId': 'peer-1',
            'createdAtMs': freshMs,
          },
        ],
        merge: false,
        now: now,
      );

      expect(dropped, isTrue);
      expect(queue.containsId('stale-1'), isFalse);
      expect(queue.containsId('fresh-1'), isTrue);

      expect(
        queue.pruneExpired(now: now.add(const Duration(days: 7, minutes: 1))),
        isTrue,
      );
      expect(queue.isEmpty, isTrue);
    });

    test('rehydrateInto inserts missing failed bubbles chronologically without duplicates', () {
      final base = DateTime.utc(2026, 11, 28, 10, 0);
      final timeline = <RemoteMessage>[
        RemoteMessage(
          id: 'srv-1',
          clientMessageId: 'cli-1',
          senderId: 'me',
          recipientId: 'peer',
          text: 'first',
          createdAt: base,
        ),
        RemoteMessage(
          id: 'srv-3',
          clientMessageId: 'cli-3',
          senderId: 'peer',
          recipientId: 'me',
          text: 'third',
          createdAt: base.add(const Duration(minutes: 2)),
        ),
      ];

      final queue = FailedSendQueue()
        ..upsert(
          FailedSendEntry(
            id: 'cli-1',
            text: 'first',
            recipientId: 'peer',
            createdAtMs: base.millisecondsSinceEpoch,
          ),
        )
        ..upsert(
          FailedSendEntry(
            id: 'cli-2',
            text: 'second (failed)',
            recipientId: 'peer',
            createdAtMs: base.add(const Duration(minutes: 1)).millisecondsSinceEpoch,
          ),
        );

      final changed = queue.rehydrateInto(
        timeline,
        currentUserId: 'me',
        now: base.add(const Duration(minutes: 5)),
      );
      expect(changed, isTrue);
      expect(timeline.map((m) => m.id).toList(), ['srv-1', 'cli-2', 'srv-3']);
    });

    test('prunePersisted drops server-confirmed sends while keeping unsent failures', () {
      final now = DateTime.utc(2026, 11, 28, 12, 0);
      final queue = FailedSendQueue()
        ..upsert(
          FailedSendEntry(
            id: 'cli-confirmed',
            text: 'reached server',
            recipientId: 'peer',
            createdAtMs: now.millisecondsSinceEpoch,
          ),
        )
        ..upsert(
          FailedSendEntry(
            id: 'cli-still-failed',
            text: 'still offline',
            recipientId: 'peer',
            createdAtMs: now.millisecondsSinceEpoch,
          ),
        );

      final merged = <RemoteMessage>[
        RemoteMessage(
          id: 'server-uuid-123',
          clientMessageId: 'cli-confirmed',
          senderId: 'me',
          recipientId: 'peer',
          text: 'reached server',
          createdAt: now,
        ),
        RemoteMessage(
          id: 'cli-still-failed',
          clientMessageId: 'cli-still-failed',
          senderId: 'me',
          recipientId: 'peer',
          text: 'still offline',
          createdAt: now,
        ),
      ];

      expect(queue.prunePersisted(merged), isTrue);
      expect(queue.containsId('cli-confirmed'), isFalse);
      expect(queue.containsId('cli-still-failed'), isTrue);
    });
  });
}
