import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/motion/origin_motion.dart';
import 'package:likedin/ui/glassmorphism.dart';

void main() {
  setUp(() {
    OriginMotionEngine.reduceMotion.value = false;
    OriginMotionEngine.isLowRamDevice = false;
    OriginMotionEngine.deformationIntensity.value = 1.0;
    LikedinAppearance.reduceMotion.value = false;
    LikedinAppearance.isLowRamDevice = false;
  });

  group('A. Spring Physics & Smooth Continuous Scroll Friction', () {
    test('fast release produces crisper higher-stiffness spring than slow release', () {
      final slowSpec = OriginMotionPresets.adaptForVelocity(OriginMotionPresets.general, 60.0);
      final fastSpec = OriginMotionPresets.adaptForVelocity(OriginMotionPresets.general, 1800.0);
      expect(fastSpec.stiffness, greaterThan(slowSpec.stiffness));
      expect(fastSpec.damping, greaterThan(slowSpec.damping));
    });

    test('damped spring RK4 integrator preserves initial velocity and settles cleanly', () {
      expect(OriginMotionPresets.elastic.dampingRatio, lessThan(1.0));
      var fast = const OriginSpringState1D(position: 100.0, velocity: -1400.0);
      var minFastPos = fast.position;
      for (var i = 0; i < 120; i++) {
        fast = OriginSpringPhysics.step1D(
          position: fast.position,
          velocity: fast.velocity,
          target: 0.0,
          spec: OriginMotionPresets.elastic,
          dt: 1 / 60,
        );
        if (fast.position < minFastPos) minFastPos = fast.position;
      }
      expect(minFastPos, lessThan(-10.0));
      expect(fast.position, closeTo(0.0, 0.5));
    });

    test('OriginElasticScrollPhysics frictionFactor is smooth and continuous across [0, 1]', () {
      const physics = OriginElasticScrollPhysics();
      double prev = physics.frictionFactor(0.0);
      for (var i = 1; i <= 100; i++) {
        final f = physics.frictionFactor(i / 100.0);
        expect(f, lessThanOrEqualTo(prev));
        expect(prev - f, lessThan(0.05));
        expect(f, greaterThan(0.0));
        prev = f;
      }
    });

    testWidgets('OriginMotionController supports mid-flight interruption and retargeting without reset', (tester) async {
      late OriginMotionController ctrl;
      await tester.pumpWidget(
        MaterialApp(
          home: _ControllerHost(onReady: (c) => ctrl = c),
        ),
      );

      ctrl.springOffsetTo(
        const Offset(120, 60),
        velocity: const Offset(400, 200),
        spec: OriginMotionPresets.general,
      );
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 50));
      final midPos = ctrl.offset;
      expect(midPos.dx, greaterThan(5.0));

      ctrl.grab();
      expect(ctrl.offset, midPos);
      expect(ctrl.isAnimating, isFalse);

      ctrl.springOffsetTo(const Offset(-40, 10), spec: OriginMotionPresets.soft);
      await tester.pumpAndSettle();
      expect(ctrl.offset.dx, closeTo(-40.0, 0.5));
      expect(ctrl.offset.dy, closeTo(10.0, 0.5));
    });
  });

  group('B. Liquid Boundary Rendering, Button & Elastic Card Widget Tests', () {
    testWidgets('OriginElasticCard renders genuine OriginLiquidBoundaryPainter & ClipPath during drag and springs back', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: OriginElasticCard(
                radius: BorderRadius.circular(24),
                child: const SizedBox(
                  width: 240,
                  height: 76,
                  child: Center(child: Text('Elastic Card')),
                ),
              ),
            ),
          ),
        ),
      );

      expect(find.byType(ClipPath), findsNothing);

      final gesture = await tester.startGesture(tester.getCenter(find.text('Elastic Card')));
      await gesture.moveBy(const Offset(36, 0));
      await tester.pump();

      expect(find.byType(OriginLiquidSurface), findsOneWidget);
      expect(find.byType(ClipPath), findsOneWidget);

      await gesture.up();
      await tester.pumpAndSettle();
      expect(find.byType(ClipPath), findsNothing);
    });

    testWidgets('OriginLiquidButton responds to touch press, fires onTap, and rebounds cleanly', (tester) async {
      var tapped = 0;
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: OriginLiquidButton(
                onTap: () => tapped++,
                child: const SizedBox(
                  width: 140,
                  height: 52,
                  child: Center(child: Text('Liquid Action')),
                ),
              ),
            ),
          ),
        ),
      );

      final gesture = await tester.startGesture(tester.getCenter(find.text('Liquid Action')));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 30));
      await gesture.up();
      await tester.pumpAndSettle();
      expect(tapped, 1);
      expect(tester.takeException(), isNull);
    });
  });

  group('C. Spring Toggle Velocity Preservation & Zero Duplicate Restart', () {
    testWidgets('fast drag release preserves initial spring velocity without duplicate didUpdateWidget restart', (tester) async {
      var value = false;
      final toggleKey = GlobalKey<OriginSpringToggleState>();

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: StatefulBuilder(
                builder: (context, setLocal) => OriginSpringToggle(
                  key: toggleKey,
                  value: value,
                  semanticLabel: 'Velocity toggle',
                  onChanged: (v) => setLocal(() => value = v),
                ),
              ),
            ),
          ),
        ),
      );

      await tester.fling(find.byType(OriginSpringToggle), const Offset(120, 0), 900);
      await tester.pump();
      expect(value, isTrue);

      expect(toggleKey.currentState!.springStartCount, 1);
      expect(toggleKey.currentState!.lastSpringLaunchVelocity, greaterThan(5.0));

      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
    });
  });

  group('D. OriginDraggableSurface Magnetic Snap, Rejection & Interruption', () {
    testWidgets('snaps to magnetic target on drop and recovers elastically on rejection', (tester) async {
      Offset? snappedTarget;
      var rejectedCount = 0;

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: OriginDraggableSurface(
                snapTargets: const <Offset>[Offset(0, -60)],
                snapRadius: 55.0,
                onSnapped: (t) => snappedTarget = t,
                onRejected: () => rejectedCount++,
                child: const SizedBox(
                  width: 140,
                  height: 44,
                  child: Center(child: Text('Drag Pill')),
                ),
              ),
            ),
          ),
        ),
      );

      await tester.drag(find.text('Drag Pill'), const Offset(0, 24));
      await tester.pumpAndSettle();
      expect(snappedTarget, isNull);
      expect(rejectedCount, 1);

      await tester.drag(find.text('Drag Pill'), const Offset(0, -56));
      await tester.pumpAndSettle();
      expect(snappedTarget, const Offset(0, -60));
    });
  });

  group('E. Multi-Touch Safety & Real Nested Horizontal/Vertical Scroll Handoff', () {
    testWidgets('second pointer joining does not trigger vertical dismiss or end gesture prematurely', (tester) async {
      var verticalEnds = 0;
      var cancels = 0;
      var zoomed = false;

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: OriginCoordinatedPanSurface(
              shouldAllowVertical: () => !zoomed,
              onVerticalEnd: (_) => verticalEnds++,
              onCancel: () => cancels++,
              child: const SizedBox.expand(child: Center(child: Text('Media Canvas'))),
            ),
          ),
        ),
      );

      final p1 = await tester.startGesture(const Offset(180, 250), pointer: 1);
      await p1.moveBy(const Offset(0, 25));
      await tester.pump();

      final p2 = await tester.startGesture(const Offset(240, 250), pointer: 2);
      await tester.pump();
      expect(cancels, greaterThanOrEqualTo(1));

      await p1.up();
      await tester.pump();
      expect(verticalEnds, 0);

      await p2.up();
      await tester.pump();
      expect(verticalEnds, 0);

      zoomed = true;
      await tester.drag(find.text('Media Canvas'), const Offset(0, 140));
      await tester.pump();
      expect(verticalEnds, 0);
    });

    testWidgets('nested horizontal ScrollController transfers movement and preserves scroll offset during H->V handoff', (tester) async {
      final hCtrl = ScrollController();
      addTearDown(hCtrl.dispose);
      final vDeltas = <double>[];

      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: OriginCoordinatedPanSurface(
              horizontalController: hCtrl,
              onVerticalDelta: vDeltas.add,
              child: ListView.builder(
                controller: hCtrl,
                scrollDirection: Axis.horizontal,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: 10,
                itemBuilder: (_, i) => SizedBox(width: 200, child: Center(child: Text('Card $i'))),
              ),
            ),
          ),
        ),
      );

      final g = await tester.startGesture(const Offset(300, 250));
      await g.moveBy(const Offset(-90, 0));
      await tester.pump(const Duration(milliseconds: 16));
      final scrolledOffset = hCtrl.offset;
      expect(scrolledOffset, greaterThan(40.0));

      await g.moveBy(const Offset(0, 35));
      await tester.pump(const Duration(milliseconds: 16));
      await g.moveBy(const Offset(0, 35));
      await tester.pump(const Duration(milliseconds: 16));
      await g.up();
      await tester.pumpAndSettle();

      expect(hCtrl.offset, greaterThanOrEqualTo(scrolledOffset));
      expect(vDeltas, isNotEmpty);
    });
  });

  group('F. Navigation Interruption, Bottom Sheet Snap & System Reduced Motion', () {
    testWidgets('OriginPageRoute supports interactive edge swipe back, cancellation rebound, and pop commit', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Builder(
            builder: (context) => Scaffold(
              body: Center(
                child: ElevatedButton(
                  onPressed: () => Navigator.of(context).push(
                    OriginPageRoute<void>(
                      builder: (_) => const Scaffold(
                        body: Center(child: Text('Detail Page')),
                      ),
                    ),
                  ),
                  child: const Text('Push Detail'),
                ),
              ),
            ),
          ),
        ),
      );

      await tester.tap(find.text('Push Detail'));
      await tester.pumpAndSettle();
      expect(find.text('Detail Page'), findsOneWidget);

      final g1 = await tester.startGesture(const Offset(6, 300));
      await g1.moveBy(const Offset(60, 0));
      await tester.pump();
      await g1.up();
      await tester.pumpAndSettle();
      expect(find.text('Detail Page'), findsOneWidget);

      await tester.flingFrom(const Offset(6, 300), const Offset(220, 0), 1200);
      await tester.pumpAndSettle();
      expect(find.text('Detail Page'), findsNothing);
    });

    testWidgets('showOriginBottomSheet supports nested scrolling without fighting and dismisses via handle fling', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Builder(
            builder: (context) => Scaffold(
              body: ElevatedButton(
                onPressed: () => showOriginBottomSheet<void>(
                  context: context,
                  wrapInMaterialSurface: true,
                  snapFractions: const <double>[0.5, 1.0],
                  builder: (_) => SizedBox(
                    height: 360,
                    child: ListView.builder(
                      itemCount: 30,
                      itemBuilder: (_, i) => ListTile(title: Text('Sheet Item $i')),
                    ),
                  ),
                ),
                child: const Text('Open Multi Sheet'),
              ),
            ),
          ),
        ),
      );

      await tester.tap(find.text('Open Multi Sheet'));
      await tester.pumpAndSettle();
      expect(find.text('Sheet Item 0'), findsOneWidget);

      // Scroll inner ListView down — sheet must stay open and not fight!
      await tester.drag(find.text('Sheet Item 0'), const Offset(0, -180));
      await tester.pumpAndSettle();
      expect(find.byType(ListView), findsOneWidget);

      // Fling downward from the dedicated top handle -> dismisses cleanly
      await tester.fling(find.byKey(const Key('origin-sheet-handle')), const Offset(0, 260), 1400);
      await tester.pumpAndSettle();
      expect(find.byType(ListView), findsNothing);
    });

    testWidgets('All physics components respect Android system disableAnimations', (tester) async {
      OriginMotionEngine.reduceMotion.value = false;
      OriginMotionEngine.deformationIntensity.value = 1.0;

      late bool reducedFromContext;
      await tester.pumpWidget(
        MediaQuery(
          data: const MediaQueryData(disableAnimations: true),
          child: MaterialApp(
            home: Builder(
              builder: (context) {
                reducedFromContext = OriginMotionEngine.isReducedMotion(context);
                return Scaffold(
                  body: Center(
                    child: OriginElasticCard(
                      child: const SizedBox(
                        width: 200,
                        height: 60,
                        child: Center(child: Text('Reduced Card')),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      );

      expect(reducedFromContext, isTrue);
      final g = await tester.startGesture(tester.getCenter(find.text('Reduced Card')));
      await g.moveBy(const Offset(40, 0));
      await tester.pump();
      expect(find.byType(ClipPath), findsNothing);
      await g.up();
      await tester.pumpAndSettle();
    });
  });
}

class _ControllerHost extends StatefulWidget {
  const _ControllerHost({required this.onReady});
  final ValueChanged<OriginMotionController> onReady;

  @override
  State<_ControllerHost> createState() => _ControllerHostState();
}

class _ControllerHostState extends State<_ControllerHost>
    with TickerProviderStateMixin {
  late final OriginMotionController _ctrl = OriginMotionController(vsync: this);

  @override
  void initState() {
    super.initState();
    widget.onReady(_ctrl);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => const SizedBox.shrink();
}
