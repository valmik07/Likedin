import 'dart:io';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/data/files_index_store.dart';

class _MemorySecureStorage extends FlutterSecureStorage {
  final Map<String, String> values = <String, String>{};

  @override
  Future<String?> read({
    required String key,
    IOSOptions? iOptions,
    AndroidOptions? aOptions,
    LinuxOptions? lOptions,
    WebOptions? webOptions,
    MacOsOptions? mOptions,
    WindowsOptions? wOptions,
  }) async =>
      values[key];

  @override
  Future<void> write({
    required String key,
    required String? value,
    IOSOptions? iOptions,
    AndroidOptions? aOptions,
    LinuxOptions? lOptions,
    WebOptions? webOptions,
    MacOsOptions? mOptions,
    WindowsOptions? wOptions,
  }) async {
    if (value == null) {
      values.remove(key);
    } else {
      values[key] = value;
    }
  }

  @override
  Future<void> delete({
    required String key,
    IOSOptions? iOptions,
    AndroidOptions? aOptions,
    LinuxOptions? lOptions,
    WebOptions? webOptions,
    MacOsOptions? mOptions,
    WindowsOptions? wOptions,
  }) async {
    values.remove(key);
  }
}

void main() {
  setUp(() {
    FilesIndexStore.clearMemoryCache();
  });

  group('FilesIndexStore encryption & persistence', () {
    test('encrypts snapshot on disk (no plaintext leak) and restores cleanly across cold start', () async {
      final tmp = await Directory.systemTemp.createTemp('likedin_files_idx_');
      addTearDown(() => tmp.delete(recursive: true));

      final storage = _MemorySecureStorage();
      final store = FilesIndexStore(storage: storage, directoryOverride: tmp);
      final t1 = DateTime.utc(2026, 11, 28, 10, 0, 0);
      final snap = FilesIndexSnapshot(
        lastMessageCreatedAt: t1,
        lastMessageId: 'msg-100',
        lastDeletedAt: t1,
        items: <Map<String, dynamic>>[
          <String, dynamic>{
            'id': 'msg-100',
            'path': 'alice/secret_beach_photo.jpg',
            'name': 'secret_beach_photo.jpg',
            'kind': 'image',
            'mk': 'super-secret-per-file-key',
            'created_at': t1.toIso8601String(),
          },
        ],
      );

      await store.save('alice', 'bob', snap);

      // Verify on-disk file is AES-256-GCM ciphertext (contains zero plaintext metadata).
      final files = tmp.listSync().whereType<File>().toList();
      expect(files.length, 1);
      final rawBytes = await files.first.readAsBytes();
      final rawAsLatin1 = String.fromCharCodes(rawBytes);
      expect(rawAsLatin1.contains('secret_beach_photo'), isFalse);
      expect(rawAsLatin1.contains('super-secret-per-file-key'), isFalse);

      // Simulate cold app restart (clear in-memory cache, keep secure storage + disk).
      FilesIndexStore.clearMemoryCache();
      expect(FilesIndexStore.peekMemory('alice', 'bob'), isNull);

      final restored = await store.load('alice', 'bob');
      expect(restored, isNotNull);
      expect(restored!.lastMessageCreatedAt, t1);
      expect(restored.lastMessageId, 'msg-100');
      expect(restored.items.length, 1);
      expect(restored.items.first['name'], 'secret_beach_photo.jpg');
      expect(restored.items.first['mk'], 'super-secret-per-file-key');
    });

    test('returns null cleanly if encrypted index file is corrupted', () async {
      final tmp = await Directory.systemTemp.createTemp('likedin_files_idx_bad_');
      addTearDown(() => tmp.delete(recursive: true));

      final store = FilesIndexStore(
        storage: _MemorySecureStorage(),
        directoryOverride: tmp,
      );
      await store.save(
        'alice',
        'bob',
        const FilesIndexSnapshot(items: <Map<String, dynamic>>[]),
      );

      // Corrupt the file bytes on disk.
      final encFile = tmp.listSync().whereType<File>().first;
      await encFile.writeAsBytes(List<int>.filled(64, 0xAB), flush: true);

      FilesIndexStore.clearMemoryCache();
      expect(await store.load('alice', 'bob'), isNull);
    });
  });

  group('FilesIndexSnapshot incremental merge & display filtering', () {
    test('merges new items newest-first, deduplicates, prunes deletions, and advances cursors', () {
      final t1 = DateTime.utc(2026, 11, 28, 9, 0);
      final t2 = DateTime.utc(2026, 11, 28, 9, 30);
      final t3 = DateTime.utc(2026, 11, 28, 10, 0);
      final t4 = DateTime.utc(2026, 11, 28, 10, 5); // Plain text message (no media!)

      final initial = FilesIndexSnapshot(
        lastMessageCreatedAt: t2,
        lastMessageId: 'm2',
        lastDeletedAt: t1,
        items: <Map<String, dynamic>>[
          <String, dynamic>{
            'id': 'm2',
            'path': 'alice/audio.m4a',
            'name': 'audio.m4a',
            'kind': 'audio',
            'created_at': t2.toIso8601String(),
          },
          <String, dynamic>{
            'id': 'm1',
            'path': 'alice/old_photo.jpg',
            'name': 'old_photo.jpg',
            'kind': 'image',
            'created_at': t1.toIso8601String(),
          },
        ],
      );

      final updated = initial.mergeIncremental(
        addedItems: <Map<String, dynamic>>[
          <String, dynamic>{
            'id': 'm3',
            'path': 'bob/report.pdf',
            'name': 'report.pdf',
            'kind': 'file',
            'created_at': t3.toIso8601String(),
          },
          // Duplicate of m2 should not create two rows
          <String, dynamic>{
            'id': 'm2',
            'path': 'alice/audio.m4a',
            'name': 'audio.m4a',
            'kind': 'audio',
            'created_at': t2.toIso8601String(),
          },
        ],
        newestMessageCreatedAt: t4,
        newestMessageId: 'm4-text',
        deletedMessageIds: const <String>{'m1'},
        newestDeletedAt: t4,
      );

      expect(updated.items.map((e) => e['id']).toList(), <String>['m3', 'm2']);
      expect(updated.lastMessageCreatedAt, t4);
      expect(updated.lastMessageId, 'm4-text');
      expect(updated.lastDeletedAt, t4);
    });

    test('filterForDisplay respects hiddenIds, clearedBeforeMs, and postClearVisibleIds', () {
      final t1 = DateTime.utc(2026, 11, 28, 8, 0);
      final t2 = DateTime.utc(2026, 11, 28, 9, 0);
      final t3 = DateTime.utc(2026, 11, 28, 10, 0);

      final snap = FilesIndexSnapshot(
        items: <Map<String, dynamic>>[
          <String, dynamic>{
            'id': 'm3',
            'client_message_id': 'c3',
            'path': 'a/3.jpg',
            'created_at': t3.toIso8601String(),
          },
          <String, dynamic>{
            'id': 'm2',
            'client_message_id': 'c2',
            'path': 'a/2.jpg',
            'created_at': t2.toIso8601String(),
          },
          <String, dynamic>{
            'id': 'm1',
            'client_message_id': 'c1',
            'path': 'a/1.jpg',
            'created_at': t1.toIso8601String(),
          },
        ],
      );

      final visible = snap.filterForDisplay(
        hiddenIds: const <String>{'c3'}, // Hidden by client_message_id
        postClearVisibleIds: const <String>{'m1'}, // Exempted from clear timestamp
        clearedBeforeMs: t2.millisecondsSinceEpoch,
      );

      expect(visible.map((e) => e['id']).toList(), <String>['m1']);
    });
  });
}
