import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'backend/backend_config.dart';
import 'backend/realtime_messaging_service.dart';
import 'backend/shared_media_service.dart';
import 'notifications/notification_service.dart';
import 'calls/call_service.dart';
import 'calls/call_alert_controller.dart';
import 'calls/proximity_call_controller.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

import 'data/attachment_vault_store.dart';

import 'data/local_message_store.dart';
import 'auth/local_account_store.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Paint the branded launch animation immediately; backend setup happens after
  // the first frame so the user never waits on network/service initialization.
  runApp(const LikedinBootstrap());
}

class LikedinBootstrap extends StatefulWidget {
  const LikedinBootstrap({super.key});
  @override State<LikedinBootstrap> createState() => _LikedinBootstrapState();
}

class _LikedinBootstrapState extends State<LikedinBootstrap> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 850))..forward();
  Widget? _readyApp;
  String? _error;
  bool _supabaseInitialized = false;
  @override void initState() { super.initState(); WidgetsBinding.instance.addPostFrameCallback((_) => _initialize()); }
  Future<void> _initialize() async {
    try {
      if (!_supabaseInitialized) {
        await Supabase.initialize(url: BackendConfig.supabaseUrl, anonKey: BackendConfig.supabaseAnonKey);
        _supabaseInitialized = true;
      }
      await LikedinNotificationService.instance.initialize();
      final store = await LocalMessageStore.open();
      final attachmentVault = AttachmentVaultStore();
      final preferences = await SharedPreferences.getInstance();
      likedinThemeMode.value = preferences.getBool(likedinThemePreferenceKey) == true ? ThemeMode.dark : ThemeMode.light;
      likedinProfilePhotoPath.value = preferences.getString(likedinProfilePhotoPreferenceKey);
      if (!mounted) return;
      setState(() => _readyApp = LikedinApp(store: store, attachmentVault: attachmentVault));
    } catch (e) { if (mounted) setState(() => _error = 'Could not start Likedin. Check your connection and try again.'); }
  }
  @override void dispose() { _controller.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) {
    if (_readyApp != null) return _readyApp!;
    return MaterialApp(debugShowCheckedModeBanner: false, home: Scaffold(
      backgroundColor: Colors.white,
      body: Container(decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFEAF4FF), Colors.white, Colors.white])),
        child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
          ScaleTransition(scale: CurvedAnimation(parent: _controller, curve: Curves.easeOutBack), child: FadeTransition(opacity: _controller, child: Container(width: 112, height: 112, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(32), boxShadow: const [BoxShadow(color: Color(0x180A66C2), blurRadius: 28, offset: Offset(0, 12))]), child: const Center(child: LikedinLogo(size: 66))))),
          const SizedBox(height: 22), const Text('Likedin', style: TextStyle(color: ink, fontSize: 22, fontWeight: FontWeight.w800, letterSpacing: -.5)),
          if (_error != null) ...[const SizedBox(height: 20), Text(_error!, textAlign: TextAlign.center), TextButton(onPressed: () { setState(() => _error = null); _initialize(); }, child: const Text('Retry'))]
        ])),
      ),
    ));
  }
}

const brandBlue = Color(0xFF0A66C2);
const ink = Color(0xFF172B4D);
const muted = Color(0xFF667085);
const page = Color(0xFFF3F6F8);
final ValueNotifier<ThemeMode> likedinThemeMode = ValueNotifier<ThemeMode>(ThemeMode.light);
const String likedinThemePreferenceKey = 'likedin_theme_mode_v1';
const String likedinProfilePhotoPreferenceKey = 'likedin_profile_photo_path_v1';
final ValueNotifier<String?> likedinProfilePhotoPath = ValueNotifier<String?>(null);

class LikedinApp extends StatelessWidget {
  const LikedinApp({required this.store, required this.attachmentVault, super.key});
  final LocalMessageStore store;
  final AttachmentVaultStore attachmentVault;

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<ThemeMode>(
        valueListenable: likedinThemeMode,
        builder: (context, mode, _) => MaterialApp(
          title: 'Likedin',
          debugShowCheckedModeBanner: false,
          themeMode: mode,
          theme: ThemeData(
            useMaterial3: true,
            brightness: Brightness.light,
            scaffoldBackgroundColor: page,
            colorScheme: ColorScheme.fromSeed(seedColor: brandBlue, brightness: Brightness.light),
            appBarTheme: const AppBarTheme(backgroundColor: Colors.white, foregroundColor: ink, elevation: 0),
            navigationBarTheme: const NavigationBarThemeData(backgroundColor: Colors.white, indicatorColor: Color(0xFFE8F2FC), labelTextStyle: WidgetStatePropertyAll(TextStyle(fontSize: 11, fontWeight: FontWeight.w600))),
            cardTheme: CardThemeData(color: Colors.white, elevation: 0.5, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
            inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: const Color(0xFFF2F4F7), border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none), contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12)),
          ),
          darkTheme: ThemeData(
            useMaterial3: true,
            brightness: Brightness.dark,
            scaffoldBackgroundColor: const Color(0xFF101820),
            colorScheme: ColorScheme.fromSeed(seedColor: brandBlue, brightness: Brightness.dark, surface: const Color(0xFF17232E)),
            appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF17232E), foregroundColor: Colors.white, elevation: 0),
            navigationBarTheme: const NavigationBarThemeData(backgroundColor: Color(0xFF17232E), indicatorColor: Color(0xFF243F57), labelTextStyle: WidgetStatePropertyAll(TextStyle(fontSize: 11, fontWeight: FontWeight.w600))),
            cardTheme: CardThemeData(color: const Color(0xFF17232E), elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
            inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: const Color(0xFF24313D), border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none), contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12)),
          ),
          home: AuthGate(store: store, attachmentVault: attachmentVault),
        ),
      );
}



class StartScreen extends StatefulWidget {
  const StartScreen({required this.store, required this.attachmentVault, super.key});
  final LocalMessageStore store;
  final AttachmentVaultStore attachmentVault;
  @override State<StartScreen> createState() => _StartScreenState();
}
class _StartScreenState extends State<StartScreen> {
  bool continued = false;
  @override Widget build(BuildContext context) {
    if (continued) return AuthGate(store: widget.store, attachmentVault: widget.attachmentVault);
    return Scaffold(backgroundColor: Colors.white, body: Container(
      decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFEAF4FF), Colors.white, Colors.white])),
      child: SafeArea(child: Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(width: 112, height: 112, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(32), boxShadow: const [BoxShadow(color: Color(0x180A66C2), blurRadius: 28, offset: Offset(0, 12))]), child: const Center(child: LikedinLogo(size: 66))),
        const SizedBox(height: 30), const Text('Your space. Your people.', textAlign: TextAlign.center, style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900, letterSpacing: -.8)),
        const SizedBox(height: 10), const Text('A private place to talk, share and stay close.', textAlign: TextAlign.center, style: TextStyle(fontSize: 15, height: 1.5)),
        const SizedBox(height: 38), SizedBox(width: double.infinity, child: FilledButton(onPressed: () => setState(() => continued = true), style: _primaryButtonStyle, child: const Text('Get started'))),
        const SizedBox(height: 14), const Text('Made for two. Built for connection.', style: TextStyle(fontSize: 12, )),
      ]))))));
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({required this.store, required this.attachmentVault, super.key});
  final LocalMessageStore store;
  final AttachmentVaultStore attachmentVault;

  @override
  Widget build(BuildContext context) => StreamBuilder<AuthState>(
        stream: Supabase.instance.client.auth.onAuthStateChange,
        builder: (context, snapshot) {
          final user = Supabase.instance.client.auth.currentUser;
          if (user == null) {
            return const SignInPage();
          }
          final account = LikedinAccount(
            displayName: (user.userMetadata?['display_name'] as String?) ??
                user.email?.split('@').first ?? 'Likedin user',
            likedinId: user.email ?? user.id,
            salt: '',
            passwordHash: '',
            createdAt: user.createdAt,
          );
          return AppShell(
            store: store,
            attachmentVault: attachmentVault,
            account: account,
            onSignOut: () => Supabase.instance.client.auth.signOut(),
          );
        },
      );
}

class SignInPage extends StatefulWidget {
  const SignInPage({super.key});
  @override
  State<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final nameController = TextEditingController();
  bool creating = false;
  bool busy = false;
  bool obscure = true;
  String? error;
  String? notice;

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    nameController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final email = emailController.text.trim();
    final password = passwordController.text;
    if (email.isEmpty || !email.contains('@')) {
      setState(() => error = 'Enter a valid email address.');
      return;
    }
    if (password.length < 8) {
      setState(() => error = 'Password must contain at least 8 characters.');
      return;
    }
    if (creating && nameController.text.trim().isEmpty) {
      setState(() => error = 'Enter your display name.');
      return;
    }
    setState(() { busy = true; error = null; notice = null; });
    try {
      if (creating) {
        final response = await Supabase.instance.client.auth.signUp(
          email: email,
          password: password,
          data: {'display_name': nameController.text.trim()},
        );
        if (response.session == null) {
          setState(() => notice = 'Account request accepted. Check your email and confirm it, then return here to sign in.');
        }
      } else {
        await Supabase.instance.client.auth.signInWithPassword(
          email: email,
          password: password,
        );
      }
    } on AuthException catch (e) {
      final message = e.message;
      setState(() => error = message.contains('LIKEDIN_PAIR_FULL') || message.contains('limited to two')
          ? 'Both Likedin account slots are already occupied.'
          : message);
    } catch (e) {
      setState(() => error = 'Could not connect. Check your internet and try again.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: Theme.of(context).scaffoldBackgroundColor,
    body: SafeArea(child: Center(child: SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 28),
      child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 430), child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Center(child: LikedinLogo(size: 58)),
          const SizedBox(height: 20),
          const Text('Your space. Your people.', textAlign: TextAlign.center,
            style: TextStyle(fontSize: 27, height: 1.15, fontWeight: FontWeight.w800, letterSpacing: -.7)),
          const SizedBox(height: 8),
          const Text('A private place for just two accounts.', textAlign: TextAlign.center, style: TextStyle(fontSize: 14, )),
          const SizedBox(height: 30),
          Container(padding: const EdgeInsets.all(4), decoration: BoxDecoration(color: Theme.of(context).brightness == Brightness.dark ? const Color(0xFF24313D) : const Color(0xFFF2F5F8), borderRadius: BorderRadius.circular(14)), child: Row(children: [
            Expanded(child: _AuthTab(label: 'Sign in', selected: !creating, onTap: () => setState(() { creating = false; error = null; notice = null; }))),
            Expanded(child: _AuthTab(label: 'Create account', selected: creating, onTap: () => setState(() { creating = true; error = null; notice = null; }))),
          ])),
          const SizedBox(height: 22),
          Text(creating ? 'Create your Likedin account' : 'Welcome back', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, )),
          const SizedBox(height: 6),
          Text(creating ? 'Use your own email address. The server enforces the two-account limit.' : 'Sign in from any device using your email.', style: const TextStyle()),
          const SizedBox(height: 20),
          if (creating) ...[
            _AuthField(controller: nameController, label: 'Your name', hint: 'How should we call you?', icon: Icons.person_outline),
            const SizedBox(height: 13),
          ],
          _AuthField(controller: emailController, label: 'Email address', hint: 'you@example.com', icon: Icons.email_outlined),
          const SizedBox(height: 13),
          _AuthField(controller: passwordController, label: 'Password', hint: 'At least 8 characters', icon: Icons.lock_outline, obscure: obscure,
            suffix: IconButton(onPressed: () => setState(() => obscure = !obscure), icon: Icon(obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined))),
          const SizedBox(height: 16),
          if (error != null) _AuthError(message: error!),
          if (notice != null) Container(padding: const EdgeInsets.all(12), margin: const EdgeInsets.only(bottom: 12), decoration: BoxDecoration(color: const Color(0xFFEAF7F0), borderRadius: BorderRadius.circular(10)), child: Text(notice!, style: const TextStyle(color: Color(0xFF176B45), fontSize: 12))),
          FilledButton(onPressed: busy ? null : _submit, style: _primaryButtonStyle,
            child: busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : Text(creating ? 'Create account' : 'Sign in')),
          const SizedBox(height: 22),
          const Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.cloud_done_outlined, size: 15, color: Color(0xFF16865A)), SizedBox(width: 6), Text('Connected to Likedin backend', style: TextStyle(fontSize: 11, ))]),
        ],
      )),
    ))),
  );
}

class _AuthTab extends StatelessWidget {
  const _AuthTab({required this.label, required this.selected, required this.onTap});
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 11),
      decoration: BoxDecoration(color: selected ? Colors.white : Colors.transparent, borderRadius: BorderRadius.circular(11), boxShadow: selected ? [const BoxShadow(color: Color(0x10000000), blurRadius: 5, offset: Offset(0, 2))] : null),
      child: Text(label, textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w700, color: selected ? brandBlue : muted)),
    ),
  );
}

class _AuthField extends StatelessWidget {
  const _AuthField({required this.controller, required this.label, required this.hint, required this.icon, this.obscure = false, this.suffix});
  final TextEditingController controller;
  final String label;
  final String hint;
  final IconData icon;
  final bool obscure;
  final Widget? suffix;

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, )),
      const SizedBox(height: 7),
      TextField(
        controller: controller,
        obscureText: obscure,
        autocorrect: false,
        enableSuggestions: !obscure,
        decoration: InputDecoration(
          hintText: hint,
          prefixIcon: Icon(icon, size: 19, ),
          suffixIcon: suffix,
        ),
      ),
    ],
  );
}

class _AuthError extends StatelessWidget {
  const _AuthError({required this.message});
  final String message;
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 12),
    padding: const EdgeInsets.all(11),
    decoration: BoxDecoration(color: const Color(0xFFFFF0EF), borderRadius: BorderRadius.circular(10)),
    child: Row(children: [const Icon(Icons.error_outline, color: Color(0xFFB42318), size: 18), const SizedBox(width: 8), Expanded(child: Text(message, style: const TextStyle(color: Color(0xFFB42318), fontSize: 12)))]),
  );
}

const ButtonStyle _primaryButtonStyle = ButtonStyle(
  minimumSize: WidgetStatePropertyAll(Size.fromHeight(50)),
  backgroundColor: WidgetStatePropertyAll(brandBlue),
  foregroundColor: WidgetStatePropertyAll(Colors.white),
  textStyle: WidgetStatePropertyAll(TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
  shape: WidgetStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(14)))),
);

class LikedinLogo extends StatelessWidget {
  const LikedinLogo({super.key, this.size = 36});
  final double size;
  @override
  Widget build(BuildContext context) => Container(
        width: size, height: size,
        alignment: Alignment.center,
        decoration: BoxDecoration(color: brandBlue, borderRadius: BorderRadius.circular(size * .19)),
        child: Text('in', style: TextStyle(color: Colors.white, fontSize: size * .61, fontWeight: FontWeight.w800, letterSpacing: -1.5, height: 1)),
      );
}

class AppShell extends StatefulWidget {
  const AppShell({required this.store, required this.attachmentVault, required this.account, required this.onSignOut, super.key});
  final LocalMessageStore store;
  final AttachmentVaultStore attachmentVault;
  final LikedinAccount account;
  final VoidCallback onSignOut;
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;
  RealtimeChannel? _incomingCallsChannel;
  final Set<String> _handledIncomingCallIds = <String>{};
  bool _incomingDialogOpen = false;
  @override
  void initState() {
    super.initState();
    LikedinNotificationService.instance.setOnOpenChat(() {
      if (mounted) setState(() => index = 1);
    });
    LikedinNotificationService.instance.setOnOpenIncomingCall(_openIncomingCallById);
    LikedinNotificationService.instance.setOnOpenCalls(() { if (mounted) setState(() => index = 2); });
    LikedinNotificationService.instance.registerCurrentToken();
    _watchIncomingCalls();
  }
  Future<void> _openIncomingCallById(String callId) async {
    try {
      final row = await Supabase.instance.client.from('likedin_calls').select()
        .eq('id', callId).eq('status', 'ringing').maybeSingle();
      if (row != null && mounted) await _showIncomingCall(Map<String,dynamic>.from(row));
    } catch (e) { debugPrint('Could not open call from notification: $e'); }
  }

  Future<void> _watchIncomingCalls() async {
    final client = Supabase.instance.client;
    final uid = client.auth.currentUser?.id;
    if (uid == null) return;
    _incomingCallsChannel = client.channel('likedin-incoming-calls-$uid')
      .onPostgresChanges(
        event: PostgresChangeEvent.insert,
        schema: 'public', table: 'likedin_calls',
        filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'callee_id', value: uid),
        callback: (payload) {
          final row = payload.newRecord;
          if (row['status'] == 'ringing') _showIncomingCall(Map<String,dynamic>.from(row));
        },
      )
      ..subscribe();
    // Catch a ringing call created just before this device subscribed.
    try {
      final pending = await client.from('likedin_calls').select()
        .eq('callee_id', uid).eq('status', 'ringing')
        .order('created_at', ascending: false).limit(3);
      for (final row in pending) {
        await _showIncomingCall(Map<String,dynamic>.from(row));
        if (_incomingDialogOpen) break;
      }
    } catch (e) { debugPrint('Incoming-call recovery query failed: $e'); }
  }

  Future<void> _showIncomingCall(Map<String,dynamic> callRow) async {
    // When the conversation is already visible, its inline invitation owns the
    // accept action. Avoid covering the chat with a second automatic dialog.
    if (LikedinNotificationService.instance.isConversationVisible) return;
    final id = callRow['id']?.toString();
    if (!mounted || id == null || _incomingDialogOpen || !_handledIncomingCallIds.add(id)) return;
    await LikedinNotificationService.instance.cancelIncomingCall(id);
    final client = Supabase.instance.client;
    try {
      // Offer may be inserted just after the call row; retry briefly for that race.
      Map<String,dynamic>? offer;
      for (var attempt = 0; attempt < 60 && offer == null; attempt++) {
        final rows = await client.from('likedin_call_signals').select('payload')
          .eq('call_id', id).eq('kind', 'offer').order('created_at', ascending: false).limit(1);
        if (rows.isNotEmpty) offer = Map<String,dynamic>.from(rows.first['payload'] as Map);
        if (offer == null) {
          final latest = await client.from('likedin_calls').select('status').eq('id', id).maybeSingle();
          if (latest == null || latest['status'] != 'ringing') break;
          await Future<void>.delayed(const Duration(milliseconds: 500));
        }
      }
      if (offer == null || !mounted) { _handledIncomingCallIds.remove(id); return; }
      _incomingDialogOpen = true;
      await showDialog<void>(
        context: context, barrierDismissible: false,
        builder: (_) => _IncomingCallDialog(
          callId: id,
          callerId: callRow['caller_id'].toString(),
          offer: offer!,
          withVideo: callRow['call_type']?.toString().toLowerCase() == 'video',
        ),
      );
    } catch (e) {
      debugPrint('Could not present incoming call: $e');
      _handledIncomingCallIds.remove(id);
    } finally { _incomingDialogOpen = false; }
  }

  @override
  void dispose() {
    final channel = _incomingCallsChannel;
    if (channel != null) Supabase.instance.client.removeChannel(channel);
    super.dispose();
  }

  Future<void> _pickProfilePhoto() async {
    try {
      final result = await FilePicker.platform.pickFiles(type: FileType.image, allowMultiple: false, withData: false);
      if (result == null || result.files.single.path == null) return;
      final source = File(result.files.single.path!);
      final support = await getApplicationSupportDirectory();
      final extension = result.files.single.extension?.toLowerCase();
      final safeExtension = (extension == 'png' || extension == 'webp' || extension == 'gif') ? extension! : 'jpg';
      final destination = File('${support.path}/likedin_profile_photo.$safeExtension');
      await destination.writeAsBytes(await source.readAsBytes(), flush: true);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(likedinProfilePhotoPreferenceKey, destination.path);
      likedinProfilePhotoPath.value = destination.path;
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Profile photo updated on this device.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not update profile photo: $e')));
    }
  }

  void _openProfileMenu() {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(leading: const Icon(Icons.photo_camera_outlined), title: const Text('Add or change profile photo'), onTap: () { Navigator.pop(sheetContext); _pickProfilePhoto(); }),
        ListTile(leading: const Icon(Icons.folder_outlined), title: const Text('Your files'), onTap: () { Navigator.pop(sheetContext); setState(() => index = 3); }),
      ])),
    );
  }

  Widget _profileAvatar(bool dark) => ValueListenableBuilder<String?>(
    valueListenable: likedinProfilePhotoPath,
    builder: (context, path, _) {
      final file = path == null ? null : File(path);
      return CircleAvatar(
        radius: 18,
        backgroundColor: dark ? const Color(0xFF29445B) : const Color(0xFFDCEBFA),
        backgroundImage: file != null && file.existsSync() ? FileImage(file) : null,
        child: file != null && file.existsSync() ? null : const Icon(Icons.person, color: brandBlue, size: 20),
      );
    },
  );

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final pages = [
      HomePage(store: widget.store, openChat: () => setState(() => index = 1)),
      ChatPage(store: widget.store, isActive: index == 1),
      const CallsPage(),
      FilesPage(store: widget.attachmentVault),
      const SettingsPage(),
    ];
    return Scaffold(
      body: SafeArea(child: Column(children: [
        Container(
          color: Theme.of(context).colorScheme.surface,
          padding: const EdgeInsets.fromLTRB(16, 10, 12, 10),
          child: Row(children: [
            const LikedinLogo(size: 38), const SizedBox(width: 10),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Likedin', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              Text('Your private space', style: TextStyle(fontSize: 12, )),
            ])),
            IconButton(tooltip: 'More', onPressed: () => showModalBottomSheet<void>(
              context: context,
              showDragHandle: true,
              builder: (sheetContext) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
                ListTile(leading: const Icon(Icons.chat_bubble_outline), title: const Text('Private conversation'), onTap: () { Navigator.pop(sheetContext); setState(() => index = 1); }),
                ListTile(leading: const Icon(Icons.call_outlined), title: const Text('Voice and video calls'), onTap: () { Navigator.pop(sheetContext); setState(() => index = 2); }),
                ListTile(leading: const Icon(Icons.settings_outlined), title: const Text('Settings & privacy'), onTap: () { Navigator.pop(sheetContext); setState(() => index = 4); }),
              ])),
            ), icon: const Icon(Icons.more_horiz)),
            IconButton(tooltip: 'Profile and files', onPressed: _openProfileMenu, icon: _profileAvatar(dark)),
          ]),
        ),
        Divider(height: 1, color: Theme.of(context).dividerColor),
        Expanded(child: IndexedStack(index: index, children: pages)),
      ])),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index == 4 ? 1 : 0,
        onDestinationSelected: (v) => setState(() => index = v == 0 ? 0 : 4),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.tune_outlined), selectedIcon: Icon(Icons.tune), label: 'Preferences'),
        ],
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({required this.store, required this.openChat, super.key});
  final LocalMessageStore store;
  final VoidCallback openChat;
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late Future<List<_HomeNews>> _news;
  @override void initState() { super.initState(); _news = _loadNews(); }

  // Google News RSS supplies current headlines; no API key or account is required.
  static const _feeds = <String>[
    'https://news.google.com/rss?hl=en-IN&gl=IN&ceid=IN:en',
    'https://news.google.com/rss/headlines/section/topic/WORLD?hl=en-IN&gl=IN&ceid=IN:en',
    'https://news.google.com/rss/headlines/section/topic/BUSINESS?hl=en-IN&gl=IN&ceid=IN:en',
    'https://news.google.com/rss/headlines/section/topic/TECHNOLOGY?hl=en-IN&gl=IN&ceid=IN:en',
    'https://news.google.com/rss/headlines/section/topic/SPORTS?hl=en-IN&gl=IN&ceid=IN:en',
    'https://news.google.com/rss/headlines/section/topic/ENTERTAINMENT?hl=en-IN&gl=IN&ceid=IN:en',
  ];

  Future<List<_HomeNews>> _loadNews() async {
    final prefs = await SharedPreferences.getInstance();
    final cycle = DateTime.now().difference(DateTime(2026, 1, 1)).inDays ~/ 3;
    final cacheKey = 'likedin_home_news_cycle_$cycle';
    final cached = prefs.getString(cacheKey);
    if (cached != null) {
      try {
        final decoded = (jsonDecode(cached) as List).cast<Map>();
        return decoded.map((item) => _HomeNews(title: item['title'].toString(), url: item['url'].toString(), source: item['source'].toString(), published: item['published'] == null ? null : DateTime.tryParse(item['published'].toString()))).toList();
      } catch (_) { await prefs.remove(cacheKey); }
    }
    final client = http.Client();
    try {
      final responses = await Future.wait(_feeds.map((feed) async {
        try {
          return await client.get(Uri.parse(feed), headers: {'User-Agent': 'Likedin/1.7.24'}).timeout(const Duration(seconds: 10));
        } catch (_) { return null; }
      }));
      final all = <_HomeNews>[];
      for (final response in responses) {
        if (response == null || response.statusCode != 200) continue;
        final items = RegExp(r'<item>([\s\S]*?)</item>', caseSensitive: false).allMatches(response.body);
        for (final match in items) {
          final block = match.group(1) ?? '';
          String tag(String name) {
            final m = RegExp('<$name(?:\\s[^>]*)?>([\\s\\S]*?)</$name>', caseSensitive: false).firstMatch(block);
            return _decodeXml(m?.group(1)?.replaceAll(RegExp(r'<[^>]+>'), '').trim() ?? '');
          }
          final title = tag('title');
          final link = tag('link');
          final pub = tag('pubDate');
          final source = tag('source');
          if (title.isEmpty || link.isEmpty) continue;
          all.add(_HomeNews(title: title, url: link, source: source.isNotEmpty ? source : (Uri.tryParse(link)?.host.replaceFirst('www.', '') ?? 'News'), published: DateTime.tryParse(pub) ?? _parseNewsDate(pub)));
        }
      }
      final seen = <String>{};
      final unique = all.where((n) => seen.add(n.title.toLowerCase())).toList();
      unique.sort((a,b) => (b.published ?? DateTime(2000)).compareTo(a.published ?? DateTime(2000)));
      final selected = unique.take(15).toList();
      await prefs.setString(cacheKey, jsonEncode(selected.map((n) => {'title': n.title, 'url': n.url, 'source': n.source, 'published': n.published?.toIso8601String()}).toList()));
      return selected;
    } finally { client.close(); }
  }

  static String _decodeXml(String value) => value
      .replaceAll('&amp;', '&').replaceAll('&quot;', '"').replaceAll('&#39;', "'")
      .replaceAll('&apos;', "'").replaceAll('&lt;', '<').replaceAll('&gt;', '>');
  static DateTime? _parseNewsDate(String value) { try { return HttpDate.parse(value); } catch (_) { return null; } }

  @override Widget build(BuildContext context) {
    final day = DateTime.now().difference(DateTime(2026, 1, 1)).inDays;
    return ListView(padding: const EdgeInsets.fromLTRB(12, 12, 12, 20), children: [
      const Text('Your private feed', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
      Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [const CircleAvatar(backgroundColor: Color(0xFFE5F0FC), child: Icon(Icons.person, color: brandBlue)), const SizedBox(width: 10), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('You', style: TextStyle(fontWeight: FontWeight.w700)), Text('Private update · Just now', style: TextStyle(fontSize: 12))])), const Icon(Icons.lock_outline, color: Color(0xFF16865A), size: 19)]),
        const SizedBox(height: 14), const Text('A private space for the two of us. Share updates, plans, photos and files without a public audience.', style: TextStyle(fontSize: 15, height: 1.4)),
        const Divider(height: 24), const Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [FeedAction(icon: Icons.thumb_up_alt_outlined, label: 'Like'), FeedAction(icon: Icons.mode_comment_outlined, label: 'Comment'), FeedAction(icon: Icons.send_outlined, label: 'Share')]),
      ]))),
      const SizedBox(height: 12),
      Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Row(children: [Icon(Icons.shield_outlined, color: brandBlue), SizedBox(width: 8), Text('Private connection status', style: TextStyle(fontWeight: FontWeight.w800))]), const SizedBox(height: 6), const Text('Local-first storage. No public profile or public feed.'), const SizedBox(height: 14), const StatusRow(icon: Icons.storage_outlined, title: 'Local message storage', subtitle: 'Encrypted message bodies saved on this device', tint: Color(0xFFEAF7F0)), const SizedBox(height: 8), const StatusRow(icon: Icons.sync_outlined, title: 'Offline message queue', subtitle: 'Messages wait locally until transport is available', tint: Color(0xFFEEF5FD))]))),
      const SizedBox(height: 14),
      Row(children: [const Expanded(child: Text('Today’s news', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800))), IconButton(tooltip: 'Refresh news', onPressed: () => setState(() => _news = _loadNews()), icon: const Icon(Icons.refresh))]),
      Text('5 stories per day · 15-story, three-day rotation', style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12)),
      const SizedBox(height: 8),
      FutureBuilder<List<_HomeNews>>(future: _news, builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) return const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator()));
        if (snapshot.hasError || !snapshot.hasData || snapshot.data!.isEmpty) return Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [const Icon(Icons.wifi_off_rounded, size: 30), const SizedBox(height: 8), const Text('News could not load. Check your internet connection.'), TextButton(onPressed: () => setState(() => _news = _loadNews()), child: const Text('Try again'))])));
        final stories = snapshot.data!;
        final start = (DateTime.now().difference(DateTime(2026, 1, 1)).inDays % 3) * 5;
        final todays = stories.skip(start).take(5).toList();
        if (todays.isEmpty) return const Text('No stories available for this rotation yet. Refresh to try again.');
        return Column(children: [for (var i = 0; i < todays.length; i++) Card(child: ListTile(leading: CircleAvatar(backgroundColor: const Color(0xFFEAF2FC), child: Text('${i+1}', style: const TextStyle(color: brandBlue, fontWeight: FontWeight.bold))), title: Text(todays[i].title, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Padding(padding: const EdgeInsets.only(top: 6), child: Text('${todays[i].source}${todays[i].published == null ? '' : ' · ${todays[i].published!.toLocal().toString().substring(0,16)}'}')), trailing: const Icon(Icons.open_in_new_rounded), onTap: () async { final uri = Uri.tryParse(todays[i].url); if (uri != null) await launchUrl(uri, mode: LaunchMode.externalApplication); })) ]);
      }),
    ]);
  }
}

class _HomeNews {
  const _HomeNews({required this.title, required this.url, required this.source, this.published});
  final String title, url, source;
  final DateTime? published;
}

class FeedAction extends StatelessWidget {
  const FeedAction({required this.icon, required this.label, super.key});
  final IconData icon; final String label;
  @override Widget build(BuildContext context) => Row(children: [Icon(icon, size: 18, ), const SizedBox(width: 5), Text(label, style: const TextStyle(fontSize: 12))]);
}

class StatusRow extends StatelessWidget {
  const StatusRow({required this.icon, required this.title, required this.subtitle, required this.tint, super.key});
  final IconData icon; final String title; final String subtitle; final Color tint;
  @override Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(11), decoration: BoxDecoration(color: Theme.of(context).brightness == Brightness.dark ? const Color(0xFF22313F) : tint, borderRadius: BorderRadius.circular(10)), child: Row(children: [Icon(icon, color: brandBlue), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w700, )), Text(subtitle, style: const TextStyle(fontSize: 12, ))]))]));
}

class ChatPage extends StatefulWidget {
  const ChatPage({required this.store, required this.isActive, super.key});
  final LocalMessageStore store;
  final bool isActive;
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> with WidgetsBindingObserver {
  final controller = TextEditingController();
  final FocusNode _composerFocus = FocusNode();
  final nicknameController = TextEditingController();
  final ScrollController _chatScrollController = ScrollController();
  bool _showScrollToBottom = false;
  bool _initialChatPositioned = false;
  late final RealtimeMessagingService messaging;
  final List<RemoteMessage> messages = <RemoteMessage>[];
  String? peerId, peerName, nickname, loadError;
  bool messagesLoading = true;
  bool appResumed = true;
  bool _markingRead = false;
  DateTime? lastSeen;
  bool peerOnline = false, peerTyping = false, saving = false, editingNickname = false;
  final Set<String> _hiddenMessageIds = <String>{};
  final Set<String> _editedMessageIds = <String>{};
  final Map<String, String> _editedMessageText = <String, String>{};
  final Map<String, Set<String>> _messageReactions = <String, Set<String>>{};
  final Map<String, String> _replyTargets = <String, String>{};
  int? _clearedBeforeMs;
  String? _localStateKey;
  final FlutterSecureStorage _localChatSecureStorage = const FlutterSecureStorage();
  RemoteMessage? _replyingTo;
  String? _editingMessageId;
  Timer? heartbeat, typingTimer;
  RealtimeChannel? _chatIncomingCallsChannel;
  Map<String, dynamic>? _chatIncomingCall;
  bool _joiningChatCall = false;

  String get headerName => (nickname?.trim().isNotEmpty == true) ? nickname!.trim() : (peerName ?? 'Your friend');

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _chatScrollController.addListener(_updateScrollButton);
    _composerFocus.addListener(() { if (_composerFocus.hasFocus) _scrollToLatest(animated: true); });
    messaging = RealtimeMessagingService(Supabase.instance.client);
    LikedinNotificationService.instance.setConversationVisible(widget.isActive);
    _initialise();
  }

  Future<void> _initialise() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final peer = await messaging.getPeerId();
      if (!mounted) return;
      peerId = peer;
      nickname = peer == null ? null : prefs.getString('likedIn_nickname_$peer');
      if (peer != null) await _loadLocalChatState(peer);
      await _refreshPeer();
      await messaging.setOnline(true);
      heartbeat?.cancel();
      heartbeat = Timer.periodic(const Duration(seconds: 30), (_) async {
        try { await messaging.setOnline(true); } catch (_) {}
      });
      if (peer != null) {
        await _watchChatIncomingCalls();
        await _loadMessages();
        messaging.subscribe(peerId: peer,
          onMessages: () => _handleIncomingMessages(),
          onProfile: _refreshPeer,
          onTyping: (value) { if (mounted) setState(() => peerTyping = value); },
        );
        // A device acknowledges delivery only after the message is synchronized
        // into the active app. Read receipts require the visible chat screen.
        if (appResumed) {
          await messaging.markDelivered();
          if (widget.isActive) await _markVisibleMessagesRead();
        }
      } else if (mounted) {
        setState(() => messagesLoading = false);
      }
      if (mounted) setState(() { loadError = null; });
    } catch (e) {
      if (mounted) setState(() => loadError = e.toString());
    }
  }

  Future<void> _watchChatIncomingCalls() async {
    final client = Supabase.instance.client;
    final uid = messaging.currentUserId;
    final existing = _chatIncomingCallsChannel;
    if (existing != null) await client.removeChannel(existing);
    _chatIncomingCallsChannel = client.channel('likedin-chat-calls-$uid')
      .onPostgresChanges(
        event: PostgresChangeEvent.insert,
        schema: 'public', table: 'likedin_calls',
        filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'callee_id', value: uid),
        callback: (payload) {
          final row = Map<String, dynamic>.from(payload.newRecord);
          if (row['status'] == 'ringing' && mounted) {
            setState(() => _chatIncomingCall = row);
          }
        },
      ).onPostgresChanges(
        event: PostgresChangeEvent.update,
        schema: 'public', table: 'likedin_calls',
        filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'callee_id', value: uid),
        callback: (payload) {
          final row = payload.newRecord;
          if (row['status'] != 'ringing' && mounted && _chatIncomingCall?['id']?.toString() == row['id']?.toString()) {
            setState(() => _chatIncomingCall = null);
          }
        },
      )..subscribe();
    try {
      final rows = await client.from('likedin_calls').select()
        .eq('callee_id', uid).eq('status', 'ringing')
        .order('created_at', ascending: false).limit(1);
      if (rows.isNotEmpty && mounted) {
        setState(() => _chatIncomingCall = Map<String, dynamic>.from(rows.first));
      }
    } catch (e) { debugPrint('Chat incoming-call recovery failed: $e'); }
  }

  Future<void> _joinChatIncomingCall() async {
    final row = _chatIncomingCall;
    if (row == null || _joiningChatCall) return;
    setState(() => _joiningChatCall = true);
    try {
      final client = Supabase.instance.client;
      final id = row['id'].toString();
      Map<String, dynamic>? offer;
      for (var attempt = 0; attempt < 90 && offer == null; attempt++) {
        final latest = await client.from('likedin_calls').select('status').eq('id', id).maybeSingle();
        if (latest == null || latest['status'] != 'ringing') break;
        final signals = await client.from('likedin_call_signals').select('payload')
          .eq('call_id', id).eq('kind', 'offer').order('created_at', ascending: false).limit(1);
        if (signals.isNotEmpty) offer = Map<String, dynamic>.from(signals.first['payload'] as Map);
        if (offer == null) await Future<void>.delayed(const Duration(milliseconds: 500));
      }
      if (offer == null) throw StateError('The caller is no longer ringing. Ask them to call again.');
      if (!mounted) return;
      await showDialog<void>(
        context: context, barrierDismissible: false,
        builder: (_) => _IncomingCallDialog(
          callId: id,
          callerId: row['caller_id'].toString(),
          offer: offer!,
          withVideo: row['call_type']?.toString().toLowerCase() == 'video',
        ),
      );
      if (mounted) setState(() => _chatIncomingCall = null);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not join call: $e')));
    } finally {
      if (mounted) setState(() => _joiningChatCall = false);
    }
  }

  Future<void> _loadLocalChatState(String peer) async {
    final user = messaging.currentUserId;
    _localStateKey = 'likedin_local_chat_v1_${user}_$peer';
    final raw = await _localChatSecureStorage.read(key: _localStateKey!);
    if (raw == null || raw.isEmpty) return;
    try {
      final data = Map<String, dynamic>.from(jsonDecode(raw) as Map);
      _hiddenMessageIds
        ..clear()
        ..addAll((data['hidden'] as List? ?? const []).map((e) => e.toString()));
      _editedMessageText
        ..clear()
        ..addAll(Map<String, dynamic>.from(data['editedText'] as Map? ?? const {}).map((k, v) => MapEntry(k, v.toString())));
      _editedMessageIds
        ..clear()
        ..addAll((data['editedIds'] as List? ?? const []).map((e) => e.toString()));
      _replyTargets
        ..clear()
        ..addAll(Map<String, dynamic>.from(data['replies'] as Map? ?? const {}).map((k, v) => MapEntry(k, v.toString())));
      _messageReactions
        ..clear()
        ..addAll(Map<String, dynamic>.from(data['reactions'] as Map? ?? const {}).map((k, v) => MapEntry(k, (v as List).map((e) => e.toString()).toSet())));
      _clearedBeforeMs = data['clearedBeforeMs'] as int?;
    } catch (_) {
      // Ignore corrupt local metadata rather than preventing chat from opening.
    }
  }

  Future<void> _saveLocalChatState() async {
    final key = _localStateKey;
    if (key == null) return;
    await _localChatSecureStorage.write(key: key, value: jsonEncode({
      'hidden': _hiddenMessageIds.toList(),
      'editedText': _editedMessageText,
      'editedIds': _editedMessageIds.toList(),
      'replies': _replyTargets,
      'reactions': _messageReactions.map((k, v) => MapEntry(k, v.toList())),
      'clearedBeforeMs': _clearedBeforeMs,
    }));
  }

  Future<void> _refreshPeer() async {
    try {
      final profile = await messaging.getPeerProfile();
      if (!mounted || profile == null) return;
      setState(() { peerName = profile.name; peerOnline = profile.online; lastSeen = profile.lastSeen; });
    } catch (_) {}
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    appResumed = state == AppLifecycleState.resumed;
    LikedinNotificationService.instance.setConversationVisible(widget.isActive && appResumed);
    if (appResumed) {
      messaging.setOnline(true).catchError((_) {});
      if (widget.isActive) {
        _loadMessages().then((_) => _markVisibleMessagesRead()).catchError((_) {});
      }
    } else if (state == AppLifecycleState.paused || state == AppLifecycleState.detached) {
      heartbeat?.cancel();
      messaging.setOnline(false).catchError((_) {});
    }
  }

  @override
  void didUpdateWidget(covariant ChatPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    LikedinNotificationService.instance.setConversationVisible(widget.isActive && appResumed);
    if (widget.isActive && !oldWidget.isActive && appResumed) {
      _loadMessages().then((_) => _markVisibleMessagesRead()).catchError((_) {});
    }
  }

  bool get _isNearBottom {
    if (!_chatScrollController.hasClients) return true;
    return _chatScrollController.position.maxScrollExtent - _chatScrollController.position.pixels <= 100;
  }

  void _updateScrollButton() {
    if (!mounted || !_chatScrollController.hasClients) return;
    final shouldShow = !_isNearBottom;
    if (shouldShow != _showScrollToBottom) setState(() => _showScrollToBottom = shouldShow);
  }

  void didChangeMetrics() {
    if (MediaQuery.of(context).viewInsets.bottom > 0) _scrollToLatest(animated: false);
  }

  void _scrollToLatest({bool animated = true}) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || !_chatScrollController.hasClients) return;
      final target = _chatScrollController.position.maxScrollExtent;
      if (animated) {
        _chatScrollController.animateTo(target, duration: const Duration(milliseconds: 260), curve: Curves.easeOut);
      } else {
        _chatScrollController.jumpTo(target);
      }
      if (_showScrollToBottom) setState(() => _showScrollToBottom = false);
    });
  }

  Future<void> _loadMessages() async {
    final hadInitialPosition = _initialChatPositioned;
    final wasAtBottom = !hadInitialPosition || _isNearBottom;
    try {
      final loaded = await messaging.loadConversation();
      final remoteReactions = await messaging.loadReactions();
      if (!mounted) return;
      final originalsById = <String, RemoteMessage>{for (final item in loaded) item.id: item};
      setState(() {
        messages
          ..clear()
          ..addAll(loaded);
        _messageReactions
          ..clear()
          ..addAll(remoteReactions);
        _replyTargets
          ..clear()
          ..addEntries(loaded.where((m) => m.replyToMessageId != null).map((m) {
            final original = originalsById[m.replyToMessageId];
            return MapEntry(
              m.id,
              original == null
                  ? 'Replying to a message'
                  : original.deletedForEveryoneAt != null
                      ? 'This message was deleted'
                      : _messageText(original),
            );
          }));
        messagesLoading = false;
        loadError = null;
      });
      if (wasAtBottom) {
        _initialChatPositioned = true;
        _scrollToLatest(animated: hadInitialPosition);
      } else {
        WidgetsBinding.instance.addPostFrameCallback((_) => _updateScrollButton());
      }
    } catch (e) {
      if (mounted) setState(() { messagesLoading = false; loadError = e.toString(); });
      rethrow;
    }
  }

  Future<void> _handleIncomingMessages() async {
    try {
      await _loadMessages();
      if (!appResumed) return;
      await messaging.markDelivered();
      if (widget.isActive) await _markVisibleMessagesRead();
    } catch (_) {}
  }

  Future<void> _markVisibleMessagesRead() async {
    if (!mounted || !widget.isActive || !appResumed || _markingRead) return;
    final hasUnread = messages.any((m) => m.recipientId == messaging.currentUserId && m.readAt == null);
    if (!hasUnread) return;
    _markingRead = true;
    try {
      await messaging.markRead();
      await _loadMessages();
    } catch (_) {
    } finally {
      _markingRead = false;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    LikedinNotificationService.instance.setConversationVisible(false);
    heartbeat?.cancel(); typingTimer?.cancel();
    final incomingChannel = _chatIncomingCallsChannel;
    if (incomingChannel != null) Supabase.instance.client.removeChannel(incomingChannel);
    messaging.setOnline(false).catchError((_) {});
    messaging.unsubscribe(); controller.dispose(); _composerFocus.dispose(); nicknameController.dispose();
    _chatScrollController.removeListener(_updateScrollButton);
    _chatScrollController.dispose();
    super.dispose();
  }

  Future<void> send() async {
    final text = controller.text.trim(); final recipient = peerId;
    if (text.isEmpty || saving) return;
    if (_editingMessageId != null) {
      final id = _editingMessageId!;
      try {
        await messaging.editMessage(id, text);
        if (!mounted) return;
        setState(() { _editedMessageText.remove(id); _editedMessageIds.remove(id); _editingMessageId = null; });
        controller.clear();
        await _loadMessages();
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Message edited for both phones.')));
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not edit message: $e')));
      }
      return;
    }
    if (recipient == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Your friend must register before you can message.')));
      return;
    }
    final optimisticId = 'local-${DateTime.now().microsecondsSinceEpoch}';
    final replyText = _replyingTo == null ? null : _messageText(_replyingTo!);
    final replyId = _replyingTo?.id;
    final optimistic = RemoteMessage(
      id: optimisticId,
      senderId: messaging.currentUserId,
      recipientId: recipient,
      text: text,
      createdAt: DateTime.now(),
    );
    setState(() { saving = true; messages.add(optimistic); _replyingTo = null; });
    _scrollToLatest();
    controller.clear();
    try {
      final sentId = await messaging.sendMessage(recipient, text, replyToMessageId: replyId);
      if (replyText != null && sentId != null) {
        _replyTargets[sentId] = replyText;
        await _saveLocalChatState();
      }
      await messaging.sendTyping(false);
      await _loadMessages();
    } catch (e) {
      if (mounted) {
        setState(() => messages.removeWhere((m) => m.id == optimisticId));
        controller.text = text;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Message not sent: $e')));
      }
    } finally { if (mounted) setState(() => saving = false); }
  }

  List<RemoteMessage> get _visibleMessages => messages.where((m) => !_hiddenMessageIds.contains(m.id) && (_clearedBeforeMs == null || m.createdAt.millisecondsSinceEpoch > _clearedBeforeMs!)).toList();

  String _messageText(RemoteMessage message) => _editedMessageText[message.id] ?? message.text;

  void _startReply(RemoteMessage message) {
    setState(() { _replyingTo = message; _editingMessageId = null; });
    _composerFocus.requestFocus();
  }

  void _startEdit(RemoteMessage message) {
    if (message.senderId != messaging.currentUserId) return;
    setState(() { _editingMessageId = message.id; _replyingTo = null; });
    controller.text = _messageText(message);
    controller.selection = TextSelection.collapsed(offset: controller.text.length);
    _composerFocus.requestFocus();
  }

  void _cancelComposerMode() {
    setState(() { _editingMessageId = null; _replyingTo = null; });
    controller.clear();
  }

  Future<void> _showMessageActions(RemoteMessage message) async {
    final mine = message.senderId == messaging.currentUserId;
    final action = await showModalBottomSheet<String>(context: context, builder: (sheetContext) => SafeArea(child: Wrap(children: [
      ListTile(leading: const Icon(Icons.reply), title: const Text('Reply'), onTap: () => Navigator.pop(sheetContext, 'reply')),
      if (mine) ListTile(leading: const Icon(Icons.edit_outlined), title: const Text('Edit'), onTap: () => Navigator.pop(sheetContext, 'edit')),
      ListTile(leading: const Icon(Icons.add_reaction_outlined), title: const Text('React'), onTap: () => Navigator.pop(sheetContext, 'react')),
      ListTile(leading: const Icon(Icons.delete_outline), title: const Text('Delete for me'), onTap: () => Navigator.pop(sheetContext, 'delete_me')),
      if (mine) ListTile(leading: const Icon(Icons.delete_forever_outlined), title: const Text('Delete for everyone'), onTap: () => Navigator.pop(sheetContext, 'delete_everyone')),
    ])));
    if (!mounted || action == null) return;
    switch (action) {
      case 'reply': _startReply(message); break;
      case 'edit': _startEdit(message); break;
      case 'react': _showReactionPicker(message); break;
      case 'delete_me':
        setState(() => _hiddenMessageIds.add(message.id));
        await _saveLocalChatState();
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Message deleted from this device.')));
        break;
      case 'delete_everyone':
        final confirmed = await showDialog<bool>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: const Text('Delete for everyone?'),
            content: const Text('Both phones will show a deleted-message placeholder. This action cannot be undone.'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')),
              TextButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Delete for everyone')),
            ],
          ),
        );
        if (confirmed != true || !mounted) break;
        try {
          await messaging.deleteMessageForEveryone(message.id);
          await _loadMessages();
          if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Message deleted for everyone.')));
        } catch (e) {
          if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not delete message: $e')));
        }
        break;
    }
  }

  Future<void> _showReactionPicker(RemoteMessage message) async {
    const emojis = ['❤️', '😂', '👍', '😮', '😢', '🔥'];
    final picked = await showModalBottomSheet<String>(context: context, builder: (ctx) => SafeArea(child: Padding(padding: const EdgeInsets.all(18), child: Wrap(alignment: WrapAlignment.spaceEvenly, children: emojis.map((e) => InkWell(onTap: () => Navigator.pop(ctx, e), child: Padding(padding: const EdgeInsets.all(10), child: Text(e, style: const TextStyle(fontSize: 30))))).toList()))));
    if (picked != null && mounted) {
      final currentlyActive = await messaging.hasMyReaction(message.id, picked);
      try {
        await messaging.setReaction(message.id, picked, active: !currentlyActive);
        await _loadMessages();
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not sync reaction: $e')));
      }
    }
  }

  Future<void> _clearChatForMe() async {
    final confirm = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: const Text('Clear chat?'), content: const Text('This clears the conversation only on this device. The other person’s chat is not affected.'), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Clear chat'))]));
    if (confirm == true && mounted) {
      setState(() => _clearedBeforeMs = DateTime.now().millisecondsSinceEpoch);
      await _saveLocalChatState();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Chat cleared on this device. New messages will still appear.')));
    }
  }

  void _beginNicknameEdit() {
    nicknameController.text = nickname ?? '';
    setState(() => editingNickname = true);
  }

  void _cancelNicknameEdit() {
    nicknameController.clear();
    if (mounted) setState(() => editingNickname = false);
  }

  Future<void> _saveNickname() async {
    final peer = peerId;
    if (peer == null) return;
    final clean = nicknameController.text.trim();
    try {
      final prefs = await SharedPreferences.getInstance();
      if (clean.isEmpty) {
        await prefs.remove('likedIn_nickname_$peer');
      } else {
        await prefs.setString('likedIn_nickname_$peer', clean);
      }
      if (!mounted) return;
      setState(() {
        nickname = clean.isEmpty ? null : clean;
        editingNickname = false;
      });
      nicknameController.clear();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not save nickname: $e')),
        );
      }
    }
  }

  Future<void> attach() async {
    final recipient = peerId;
    if (recipient == null) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Your friend must register before sharing files.'))); return; }
    try {
      final picked = await FilePicker.platform.pickFiles(allowMultiple: true, withData: false);
      if (picked == null || picked.files.isEmpty) return;
      final media = SharedMediaService(Supabase.instance.client);
      for (final item in picked.files) {
        final path = item.path;
        if (path == null) throw StateError('Android did not provide a readable file path for ${item.name}. Please choose the file from Downloads or Gallery.');
        final original = File(path);
        if (!await original.exists()) continue;
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Preparing ${item.name}…')));
        final prepared = await media.prepare(original);
        await media.enqueue(prepared, recipient);
      }
      // Transfer immediately while the app is open. Failed items can be retried manually.
      final completed = await SharedMediaService.processRetryQueue(Supabase.instance.client);
      await _loadMessages();
      if (mounted) {
        final detail = SharedMediaService.lastQueueError;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          duration: const Duration(seconds: 10),
          content: Text(completed ? 'Attachments sent.' : 'Upload failed: ${detail ?? 'Unknown storage error'}. Your file is saved in the retry queue.'),
        ));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Attachment not sent: $e')));
    }
  }

  Widget _messageContent(RemoteMessage message) {
    if (message.deletedForEveryoneAt != null) return Text('This message was deleted', style: TextStyle(fontSize: 15, fontStyle: FontStyle.italic, color: Theme.of(context).hintColor));
    final payload = SharedMediaService(Supabase.instance.client).decode(_messageText(message));
    if (payload == null) return Text(_messageText(message), softWrap: true, style: const TextStyle(fontSize: 15, height: 1.35));
    final name = payload['name']?.toString() ?? 'Attachment';
    final kind = payload['kind']?.toString() ?? 'file';
    final path = payload['path']?.toString() ?? '';
    final size = (payload['size'] as num?)?.toInt() ?? 0;
    final sizeLabel = size >= 1048576 ? '${(size / 1048576).toStringAsFixed(1)} MB' : '${(size / 1024).toStringAsFixed(0)} KB';
    return FutureBuilder<String>(
      future: kind == 'image' ? SharedMediaService(Supabase.instance.client).signedUrl(path) : null,
      builder: (context, snapshot) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (kind == 'image' && snapshot.hasData) ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.network(snapshot.data!, width: 230, fit: BoxFit.cover, errorBuilder: (_,__,___) => const Icon(Icons.broken_image_outlined, size: 48))),
        if (kind == 'image' && snapshot.connectionState == ConnectionState.waiting) const SizedBox(width: 220, height: 120, child: Center(child: CircularProgressIndicator())),
        Row(mainAxisSize: MainAxisSize.min, children: [Icon(kind == 'video' ? Icons.videocam_outlined : kind == 'image' ? Icons.image_outlined : Icons.insert_drive_file_outlined, size: 22), const SizedBox(width: 8), Flexible(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)), Text(sizeLabel, style: const TextStyle(fontSize: 11, color: muted))])), IconButton(tooltip: 'Download attachment', onPressed: () async { try { final dir = await getApplicationDocumentsDirectory(); final file = await SharedMediaService(Supabase.instance.client).download(payload, Directory('${dir.path}/Likedin Downloads')); if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Saved ${p.basename(file.path)} in Likedin Downloads.'))); } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Download failed: $e'))); } }, icon: const Icon(Icons.download_rounded))])
      ]),
    );
  }

  String _time(DateTime value) {
    final local = value.toLocal(); final hour = local.hour % 12 == 0 ? 12 : local.hour % 12;
    return '$hour:${local.minute.toString().padLeft(2, '0')} ${local.hour >= 12 ? 'PM' : 'AM'}';
  }

  String _presenceText() {
    if (peerOnline) return 'Online';
    if (lastSeen == null) return 'Last seen unavailable';
    final delta = DateTime.now().difference(lastSeen!);
    if (delta.inMinutes < 1) return 'Last seen just now';
    if (delta.inHours < 1) return 'Last seen ${delta.inMinutes}m ago';
    if (delta.inDays < 1) return 'Last seen ${delta.inHours}h ago';
    return 'Last seen ${delta.inDays}d ago';
  }

  Widget _receipt(RemoteMessage message) {
    if (message.readAt != null) return const Icon(Icons.done_all, size: 15, color: Color(0xFF1685E8));
    if (message.deliveredAt != null) return const Icon(Icons.done_all, size: 15, );
    return const Icon(Icons.check, size: 15, );
  }

  @override
  Widget build(BuildContext context) => Column(children: [
    Container(color: Theme.of(context).colorScheme.surface, padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10), child: Row(children: [
      const CircleAvatar(backgroundColor: Color(0xFFE5F0FC), child: Icon(Icons.person, color: brandBlue)),
      const SizedBox(width: 10),
      Expanded(child: editingNickname
        ? TextField(
            controller: nicknameController,
            autofocus: true,
            maxLength: 30,
            decoration: const InputDecoration(
              hintText: 'Nickname for this person',
              counterText: '',
              isDense: true,
            ),
            onSubmitted: (_) => _saveNickname(),
          )
        : GestureDetector(onTap: _beginNicknameEdit, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(headerName, style: const TextStyle(fontWeight: FontWeight.w700, )),
            Text(_presenceText(), style: TextStyle(fontSize: 11, color: peerOnline ? const Color(0xFF16865A) : muted)),
          ]))),
      if (editingNickname) ...[
        IconButton(tooltip: 'Cancel nickname', onPressed: _cancelNicknameEdit, icon: const Icon(Icons.close, size: 19)),
        IconButton(tooltip: 'Save nickname', onPressed: _saveNickname, icon: const Icon(Icons.check, color: brandBlue, size: 20)),
      ] else
        IconButton(tooltip: 'Change nickname', onPressed: _beginNicknameEdit, icon: const Icon(Icons.edit_outlined, size: 19)),
      IconButton(tooltip: 'Audio call', onPressed: peerId == null ? null : () => _showCallSetup(context, video: false, recipientId: peerId), icon: const Icon(Icons.call_outlined, color: brandBlue)),
      IconButton(tooltip: 'Video call', onPressed: peerId == null ? null : () => _showCallSetup(context, video: true, recipientId: peerId), icon: const Icon(Icons.videocam_outlined, color: brandBlue)),
      PopupMenuButton<String>(tooltip: 'Chat options', onSelected: (v) { if (v == 'clear') _clearChatForMe(); }, itemBuilder: (_) => const [PopupMenuItem(value: 'clear', child: Text('Clear chat on this device'))]),
    ])),
    Container(width: double.infinity, color: Theme.of(context).brightness == Brightness.dark ? const Color(0xFF3A3326) : const Color(0xFFFFF6E8), padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8), child: Row(children: [Icon(Icons.info_outline, size: 16, color: Theme.of(context).brightness == Brightness.dark ? const Color(0xFFFFD28A) : const Color(0xFF9A6700)), const SizedBox(width: 7), Expanded(child: Text('Messages are protected in transit (TLS) and by account access controls, but are not end-to-end encrypted.', style: TextStyle(fontSize: 11, color: Theme.of(context).brightness == Brightness.dark ? const Color(0xFFFFE8BF) : const Color(0xFF7A5100))))])),
    if (_chatIncomingCall != null)
      Container(width: double.infinity, margin: const EdgeInsets.fromLTRB(12, 8, 12, 0), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFFEAF3FF), borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFB8D6F5))), child: Row(children: [Icon(_chatIncomingCall!['call_type']?.toString().toLowerCase() == 'video' ? Icons.videocam : Icons.call, color: brandBlue), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${_chatIncomingCall!['call_type']?.toString().toLowerCase() == 'video' ? 'Video' : 'Audio'} call incoming', style: const TextStyle(fontWeight: FontWeight.w700, color: ink)), const Text('Your friend is waiting for you to join.', style: TextStyle(fontSize: 12, color: ink))])), FilledButton(onPressed: _joiningChatCall ? null : _joinChatIncomingCall, child: _joiningChatCall ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Text('Join call'))])),
    Expanded(child: Stack(children: [
      Positioned.fill(child: loadError != null ? Center(child: Padding(padding: const EdgeInsets.all(20), child: Text('Could not connect to messaging backend.\n$loadError', textAlign: TextAlign.center)))
        : messagesLoading ? const Center(child: CircularProgressIndicator())
        : peerId == null ? const Center(child: Padding(padding: EdgeInsets.all(28), child: Text('Waiting for your friend to register.', textAlign: TextAlign.center, style: TextStyle())))
        : ListView.builder(
            controller: _chatScrollController,
            padding: const EdgeInsets.fromLTRB(14, 14, 14, 18),
            itemCount: _visibleMessages.length + (peerTyping ? 1 : 0) + (_visibleMessages.isEmpty && !peerTyping ? 1 : 0),
            itemBuilder: (context, i) {
              if (i >= _visibleMessages.length) {
                if (peerTyping) return const _TypingBubble();
                return const Padding(padding: EdgeInsets.all(28), child: Text('Your online conversation is ready. Send your first message!', textAlign: TextAlign.center, style: TextStyle()));
              }
              final message = _visibleMessages[i];
              final outgoing = message.senderId == messaging.currentUserId;
              final quoted = _replyTargets[message.id];
              final reactions = _messageReactions[message.id] ?? <String>{};
              return _SwipeReplyGesture(
                onReply: () { HapticFeedback.selectionClick(); _startReply(message); },
                child: GestureDetector(
                onLongPress: message.deletedForEveryoneAt == null ? () => _showMessageActions(message) : null,
                child: TweenAnimationBuilder<double>(
                  key: ValueKey('message-${message.id}'),
                  tween: Tween<double>(begin: 0, end: 1),
                  duration: const Duration(milliseconds: 220),
                  curve: Curves.easeOutCubic,
                  builder: (context, value, child) => Opacity(
                    opacity: value,
                    child: Transform.translate(offset: Offset(0, 10 * (1 - value)), child: child),
                  ),
                  child: Align(
                  alignment: outgoing ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 6),
                    padding: const EdgeInsets.fromLTRB(15, 11, 15, 9),
                    constraints: const BoxConstraints(maxWidth: 310),
                    decoration: BoxDecoration(
                      color: outgoing ? (Theme.of(context).brightness == Brightness.dark ? const Color(0xFF203B53) : const Color(0xFFE5F0FC)) : Theme.of(context).colorScheme.surface,
                      border: Border.all(color: Theme.of(context).brightness == Brightness.dark ? const Color(0xFF314454) : (outgoing ? const Color(0xFFD5E6F8) : const Color(0xFFE7EBF0))),
                      borderRadius: BorderRadius.only(topLeft: const Radius.circular(20), topRight: const Radius.circular(20), bottomLeft: Radius.circular(outgoing ? 20 : 6), bottomRight: Radius.circular(outgoing ? 6 : 20)),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(Theme.of(context).brightness == Brightness.dark ? .10 : .035), blurRadius: 10, offset: const Offset(0, 3))],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (quoted != null)
                          Container(
                            width: double.infinity,
                            margin: const EdgeInsets.only(bottom: 8),
                            padding: const EdgeInsets.fromLTRB(9, 7, 9, 7),
                            decoration: BoxDecoration(
                              color: Theme.of(context).brightness == Brightness.dark
                                  ? const Color(0xFF172B3B)
                                  : const Color(0xFFF0F5FB),
                              borderRadius: BorderRadius.circular(10),
                              border: Border(
                                left: BorderSide(
                                  color: outgoing ? const Color(0xFF55A7F5) : brandBlue,
                                  width: 3,
                                ),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  'REPLYING TO',
                                  style: TextStyle(
                                    fontSize: 9,
                                    letterSpacing: .8,
                                    fontWeight: FontWeight.w800,
                                    color: Theme.of(context).brightness == Brightness.dark
                                        ? const Color(0xFF80BDF5)
                                        : brandBlue,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  quoted,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  style: TextStyle(
                                    fontSize: 12,
                                    height: 1.2,
                                    color: Theme.of(context).colorScheme.onSurface.withOpacity(.78),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        _messageContent(message),
                        if (message.deletedForEveryoneAt == null &&
                            (message.editedAt != null ||
                                _editedMessageIds.contains(message.id)))
                          const Padding(
                            padding: EdgeInsets.only(top: 2),
                            child: Text('Edited', style: TextStyle(fontSize: 10, fontStyle: FontStyle.italic)),
                          ),
                        if (reactions.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.only(top: 5),
                            child: Wrap(spacing: 4, children: reactions.map((e) => Text(e, style: const TextStyle(fontSize: 16))).toList()),
                          ),
                        const SizedBox(height: 5),
                        Row(mainAxisSize: MainAxisSize.min, children: [
                          Text(_time(message.createdAt), style: const TextStyle(fontSize: 10, )),
                          if (outgoing) ...[const SizedBox(width: 4), _receipt(message)],
                        ]),
                      ],
                    ),
                  ),
                  ),
                ),
              ));
            },
          )),
      if (_showScrollToBottom && messages.isNotEmpty)
        Positioned(right: 18, bottom: 14, child: Material(elevation: 4, color: Theme.of(context).colorScheme.surface, shape: const CircleBorder(), child: IconButton(tooltip: 'Jump to latest message', onPressed: () => _scrollToLatest(), icon: const Icon(Icons.keyboard_arrow_down_rounded, color: brandBlue, size: 30)))),
    ])),
    if (_replyingTo != null || _editingMessageId != null)
      Container(
        margin: const EdgeInsets.fromLTRB(12, 8, 12, 2),
        padding: const EdgeInsets.fromLTRB(11, 8, 4, 8),
        decoration: BoxDecoration(
          color: Theme.of(context).brightness == Brightness.dark
              ? const Color(0xFF1A2B39)
              : const Color(0xFFF0F5FB),
          borderRadius: BorderRadius.circular(13),
          border: Border.all(
            color: Theme.of(context).brightness == Brightness.dark
                ? const Color(0xFF30485C)
                : const Color(0xFFDCE8F5),
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 3,
              height: 34,
              decoration: BoxDecoration(
                color: brandBlue,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
            const SizedBox(width: 9),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    _editingMessageId != null ? 'EDITING MESSAGE' : 'REPLYING TO ${_replyingTo!.senderId == messaging.currentUserId ? 'YOURSELF' : headerName.toUpperCase()}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 9, letterSpacing: .7, color: brandBlue, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    _editingMessageId != null ? controller.text : _messageText(_replyingTo!),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurface.withOpacity(.78)),
                  ),
                ],
              ),
            ),
            IconButton(
              visualDensity: VisualDensity.compact,
              tooltip: 'Cancel',
              onPressed: _cancelComposerMode,
              icon: const Icon(Icons.close_rounded, size: 19),
            ),
          ],
        ),
      ),
    SafeArea(top: false, child: Container(
      color: Theme.of(context).colorScheme.surface,
      padding: const EdgeInsets.fromLTRB(10, 9, 10, 9),
      child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        IconButton(onPressed: attach, tooltip: 'Attach a file', icon: const Icon(Icons.add_circle_outline_rounded, size: 25)),
        const SizedBox(width: 3),
        Expanded(child: Container(
          decoration: BoxDecoration(
            color: Theme.of(context).brightness == Brightness.dark ? const Color(0xFF24313D) : const Color(0xFFF2F5F8),
            borderRadius: BorderRadius.circular(26),
            border: Border.all(color: Theme.of(context).dividerColor.withOpacity(.35)),
          ),
          child: TextField(
            focusNode: _composerFocus, controller: controller, minLines: 1, maxLines: 5,
            textCapitalization: TextCapitalization.sentences,
            onChanged: (value) { typingTimer?.cancel(); messaging.sendTyping(value.trim().isNotEmpty).catchError((_) {}); if (value.trim().isNotEmpty) typingTimer = Timer(const Duration(seconds: 2), () => messaging.sendTyping(false).catchError((_) {})); setState(() {}); },
            onSubmitted: (_) => send(),
            decoration: InputDecoration(
              hintText: _editingMessageId != null ? 'Edit message…' : _replyingTo != null ? 'Write a reply…' : 'Message privately…',
              filled: false, border: InputBorder.none, enabledBorder: InputBorder.none, focusedBorder: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
            ),
          ),
        )),
        const SizedBox(width: 8),
        AnimatedScale(
          scale: controller.text.trim().isEmpty ? .92 : 1,
          duration: const Duration(milliseconds: 180),
          curve: Curves.easeOutBack,
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 160),
            transitionBuilder: (child, animation) => ScaleTransition(scale: animation, child: child),
            child: IconButton.filled(
              key: ValueKey('${controller.text.trim().isNotEmpty}-$saving'),
              onPressed: saving || peerId == null || controller.text.trim().isEmpty ? null : () { HapticFeedback.lightImpact(); send(); },
              style: IconButton.styleFrom(backgroundColor: brandBlue, foregroundColor: Colors.white, disabledBackgroundColor: Theme.of(context).disabledColor.withOpacity(.25)),
              icon: saving ? const SizedBox(width: 19, height: 19, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.arrow_upward_rounded),
            ),
          ),
        ),
      ]),
    )), 
  ]);
}


class _SwipeReplyGesture extends StatefulWidget {
  const _SwipeReplyGesture({required this.child, required this.onReply});
  final Widget child;
  final VoidCallback onReply;

  @override
  State<_SwipeReplyGesture> createState() => _SwipeReplyGestureState();
}

class _SwipeReplyGestureState extends State<_SwipeReplyGesture> {
  double _drag = 0;

  @override
  Widget build(BuildContext context) {
    final offset = _drag.clamp(-58.0, 58.0);
    return Stack(
      alignment: Alignment.center,
      children: [
        Positioned.fill(
          child: Align(
            alignment: _drag >= 0 ? Alignment.centerLeft : Alignment.centerRight,
            child: Opacity(
              opacity: (offset.abs() / 58).clamp(0.0, 1.0),
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: Icon(Icons.reply_rounded, color: brandBlue, size: 20),
              ),
            ),
          ),
        ),
        GestureDetector(
          behavior: HitTestBehavior.translucent,
          onHorizontalDragUpdate: (details) => setState(() => _drag = (_drag + details.delta.dx).clamp(-58.0, 58.0)),
          onHorizontalDragEnd: (details) {
            final shouldReply = _drag.abs() > 42 || (details.primaryVelocity?.abs() ?? 0) > 260;
            setState(() => _drag = 0);
            if (shouldReply) widget.onReply();
          },
          child: AnimatedContainer(
            duration: _drag == 0 ? const Duration(milliseconds: 180) : Duration.zero,
            curve: Curves.easeOutCubic,
            transform: Matrix4.translationValues(offset, 0, 0),
            child: widget.child,
          ),
        ),
      ],
    );
  }
}

class _TypingBubble extends StatefulWidget { const _TypingBubble(); @override State<_TypingBubble> createState() => _TypingBubbleState(); }
class _TypingBubbleState extends State<_TypingBubble> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 850))..repeat();
  @override void dispose() { _controller.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Align(alignment: Alignment.centerLeft, child: Container(margin: const EdgeInsets.symmetric(vertical: 5), padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12), decoration: BoxDecoration(color: Theme.of(context).colorScheme.surface, border: Border.all(color: Theme.of(context).dividerColor), borderRadius: BorderRadius.circular(18)), child: Row(mainAxisSize: MainAxisSize.min, children: [const Text('Typing ', style: TextStyle(fontSize: 12)), ...List.generate(3, (i) => AnimatedBuilder(animation: _controller, builder: (_, __) { final v = (_controller.value * 3 - i).clamp(0.0, 1.0); return Padding(padding: const EdgeInsets.symmetric(horizontal: 2), child: Transform.translate(offset: Offset(0, -4 * v), child: const CircleAvatar(radius: 3, backgroundColor: brandBlue))); }))])));
}

class _IncomingCallDialog extends StatefulWidget {
  const _IncomingCallDialog({required this.callId, required this.callerId, required this.offer, required this.withVideo});
  final String callId, callerId;
  final Map<String,dynamic> offer;
  final bool withVideo;
  @override State<_IncomingCallDialog> createState() => _IncomingCallDialogState();
}

class _IncomingCallDialogState extends State<_IncomingCallDialog> {
  late final LikedinCallService call;
  final ProximityCallController proximity = ProximityCallController();
  StreamSubscription<String>? subscription;
  bool accepting = false, accepted = false, finished = false, _checkingRemoteStatus = false;
  String status = 'Incoming call';
  Timer? _incomingStatusTimer;

  @override void initState() {
    super.initState();
    call = LikedinCallService(Supabase.instance.client);
    CallAlertController.startIncoming();
    _incomingStatusTimer = Timer.periodic(const Duration(seconds: 2), (_) => _checkIncomingStatus());
  }

  Future<void> _checkIncomingStatus() async {
    if (!mounted || accepting || accepted || finished || _checkingRemoteStatus) return;
    _checkingRemoteStatus = true;
    try {
      final row = await Supabase.instance.client.from('likedin_calls').select('status')
        .eq('id', widget.callId).maybeSingle();
      final remoteStatus = row?['status']?.toString();
      if (remoteStatus != null && remoteStatus != 'ringing' && mounted && !accepting && !accepted) {
        await CallAlertController.stop();
        setState(() { status = remoteStatus == 'missed' ? 'Missed call' : 'Call ended'; finished = true; });
        Future<void>.delayed(const Duration(milliseconds: 900), () {
          if (mounted && Navigator.of(context).canPop()) Navigator.of(context).pop();
        });
      }
    } catch (_) {
      // Keep ringing during transient network errors; the server timeout remains authoritative.
    } finally { _checkingRemoteStatus = false; }
  }

  Future<void> _accept() async {
    await CallAlertController.stop();
    setState(() { accepting = true; status = 'Connecting…'; });
    try {
      await call.initialize();
      subscription = call.changes.listen((value) {
        if (!mounted) return;
        setState(() { status = value; if (value == 'ended' || value == 'missed' || value == 'rejected' || value == 'disconnected' || value.startsWith('failed') || value.startsWith('error:')) finished = true; });
        if (finished) { Future<void>.delayed(const Duration(milliseconds: 650), () { if (mounted && Navigator.of(context).canPop()) Navigator.of(context).pop(); }); }
      });
      await call.accept(widget.callId, widget.callerId, widget.offer, withVideo: widget.withVideo);
      await proximity.update(active: !widget.withVideo, enabled: !widget.withVideo);
      if (mounted) setState(() { accepted = true; accepting = false; status = 'Connecting…'; });
    } catch (e) {
      if (mounted) setState(() { accepting = false; status = 'Could not answer: $e'; });
    }
  }

  Future<void> _toggleSpeaker() async {
    await call.toggleSpeaker();
    await proximity.update(active: accepted && !widget.withVideo, enabled: accepted && !widget.withVideo && !call.speaker);
  }

  Future<void> _reject() async {
    await CallAlertController.stop();
    try {
      await Supabase.instance.client.from('likedin_call_signals').insert({
        'call_id': widget.callId, 'sender_id': Supabase.instance.client.auth.currentUser!.id,
        'kind': 'reject', 'payload': <String,dynamic>{},
      });
      await Supabase.instance.client.from('likedin_calls').update({'status':'rejected','ended_at':DateTime.now().toUtc().toIso8601String()}).eq('id', widget.callId);
    } catch (e) { debugPrint('Reject call update failed: $e'); }
    if (mounted) Navigator.of(context).pop();
  }

  @override void dispose() { _incomingStatusTimer?.cancel(); CallAlertController.stop(); proximity.dispose(); subscription?.cancel(); call.close(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    const background = Color(0xFF071426);
    const accent = Color(0xFF4F9DFF);
    final isActive = accepted && !finished;
    return Dialog.fullscreen(
      backgroundColor: background,
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF173B63), Color(0xFF0B1B30), Color(0xFF050D18)],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 22, 24, 28),
            child: Column(
              children: [
                Row(
                  children: [
                    const Icon(Icons.lock_rounded, color: Colors.white54, size: 15),
                    const SizedBox(width: 7),
                    const Text('LIKEDIN CALL', style: TextStyle(color: Colors.white60, letterSpacing: 2.2, fontSize: 11, fontWeight: FontWeight.w700)),
                    const Spacer(),
                    Icon(widget.withVideo ? Icons.videocam_rounded : Icons.call_rounded, color: accent),
                  ],
                ),
                const Spacer(),
                if (isActive && widget.withVideo)
                  Expanded(
                    flex: 5,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(28),
                      child: Stack(fit: StackFit.expand, children: [
                        RTCVideoView(call.remoteRenderer, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover),
                        Positioned(
                          right: 14, top: 14, width: 104, height: 142,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(18),
                            child: Container(color: Colors.black45, child: RTCVideoView(call.localRenderer, mirror: true, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover)),
                          ),
                        ),
                      ]),
                    ),
                  )
                else ...[
                  Container(
                    width: 148, height: 148,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white.withOpacity(.08),
                      border: Border.all(color: accent.withOpacity(.65), width: 1.5),
                      boxShadow: [BoxShadow(color: accent.withOpacity(.22), blurRadius: 45, spreadRadius: 8)],
                    ),
                    child: Icon(widget.withVideo ? Icons.videocam_rounded : Icons.person_rounded, color: Colors.white, size: 68),
                  ),
                  const SizedBox(height: 30),
                  Text(
                    widget.withVideo ? 'Incoming video call' : 'Incoming audio call',
                    style: const TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.w700, letterSpacing: -.5),
                    textAlign: TextAlign.center,
                  ),
                ],
                const SizedBox(height: 12),
                Text(
                  accepted ? status : 'Your friend is calling',
                  style: const TextStyle(color: Color(0xFFB8C9DC), fontSize: 15),
                  textAlign: TextAlign.center,
                ),
                const Spacer(),
                if (!accepted && !finished)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _incomingCallAction(icon: Icons.call_end_rounded, label: 'Decline', color: const Color(0xFFE5485D), onTap: accepting ? null : _reject),
                      _incomingCallAction(icon: Icons.call_rounded, label: accepting ? 'Connecting' : 'Answer', color: const Color(0xFF20B879), onTap: accepting ? null : _accept),
                    ],
                  )
                else if (isActive)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _activeCallControl(call.muted ? Icons.mic_off_rounded : Icons.mic_rounded, 'Mute', call.muted, call.toggleMute),
                      if (!widget.withVideo) _activeCallControl(call.speaker ? Icons.volume_up_rounded : Icons.hearing_rounded, 'Speaker', call.speaker, _toggleSpeaker),
                      if (widget.withVideo) _activeCallControl(Icons.cameraswitch_rounded, 'Flip', false, call.switchCamera),
                      _incomingCallAction(icon: Icons.call_end_rounded, label: 'End call', color: const Color(0xFFE5485D), onTap: () async { await call.end(); if (context.mounted) Navigator.of(context).pop(); }),
                    ],
                  )
                else if (finished)
                  FilledButton.tonal(onPressed: () => Navigator.of(context).pop(), child: const Text('Close')),
                const SizedBox(height: 18),
                const Text('Private calls • Likedin', style: TextStyle(color: Colors.white38, fontSize: 11, letterSpacing: .5)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


Widget _incomingCallAction({required IconData icon, required String label, required Color color, required VoidCallback? onTap}) =>
  Column(mainAxisSize: MainAxisSize.min, children: [
    SizedBox(
      width: 76, height: 76,
      child: FloatingActionButton(
        heroTag: label,
        elevation: 0,
        backgroundColor: color,
        foregroundColor: Colors.white,
        onPressed: onTap,
        child: Icon(icon, size: 31),
      ),
    ),
    const SizedBox(height: 11),
    Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
  ]);

Widget _activeCallControl(IconData icon, String label, bool active, VoidCallback onPressed) => Column(mainAxisSize: MainAxisSize.min, children: [
  IconButton.filled(onPressed: onPressed, style: IconButton.styleFrom(backgroundColor: active ? const Color(0xFF2F80ED) : Colors.white.withOpacity(.14), foregroundColor: Colors.white, fixedSize: const Size(58,58)), icon: Icon(icon)),
  const SizedBox(height: 5), Text(label, style: const TextStyle(color: Color(0xFFB8C9D9), fontSize: 11)),
]);

class CallsPage extends StatefulWidget {
  const CallsPage({super.key});
  @override State<CallsPage> createState() => _CallsPageState();
}

class _CallsPageState extends State<CallsPage> {
  Future<List<Map<String,dynamic>>>? _history;
  RealtimeChannel? _channel;
  @override void initState() { super.initState(); _load(); _subscribe(); }
  void _load() { _history = _fetch(); }
  Future<List<Map<String,dynamic>>> _fetch() async {
    final uid = Supabase.instance.client.auth.currentUser!.id;
    final rows = await Supabase.instance.client.from('likedin_calls').select()
      .or('caller_id.eq.$uid,callee_id.eq.$uid').order('created_at', ascending: false).limit(100);
    return rows.map((e) => Map<String,dynamic>.from(e)).toList();
  }
  void _subscribe() {
    final client = Supabase.instance.client;
    final uid = client.auth.currentUser?.id;
    if (uid == null) return;
    _channel = client.channel('likedin-call-history-$uid')
      .onPostgresChanges(event: PostgresChangeEvent.insert, schema: 'public', table: 'likedin_calls', callback: (_) { if (mounted) setState(_load); })
      .onPostgresChanges(event: PostgresChangeEvent.update, schema: 'public', table: 'likedin_calls', callback: (_) { if (mounted) setState(_load); })..subscribe();
  }
  @override void dispose() { final c = _channel; if (c != null) Supabase.instance.client.removeChannel(c); super.dispose(); }
  String _label(Map<String,dynamic> row, String uid) {
    final outgoing = row['caller_id'] == uid;
    final status = row['status']?.toString() ?? 'ended';
    if (status == 'missed') return outgoing ? 'No answer' : 'Missed call';
    if (status == 'rejected') return outgoing ? 'Declined' : 'You declined';
    if (status == 'ringing') return 'Ringing';
    if (status == 'accepted' || row['answered_at'] != null) return 'Completed';
    return status == 'ended' ? 'Ended' : status;
  }
  IconData _icon(Map<String,dynamic> row, String uid) {
    if (row['status'] == 'missed' && row['callee_id'] == uid) return Icons.call_missed;
    if (row['caller_id'] == uid) return Icons.call_made;
    return Icons.call_received;
  }
  @override Widget build(BuildContext context) {
    final uid = Supabase.instance.client.auth.currentUser!.id;
    return RefreshIndicator(onRefresh: () async { setState(_load); await _history; }, child: ListView(padding: const EdgeInsets.all(16), children: [
      Row(children: [const Expanded(child: Text('Call history', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800))), IconButton(tooltip: 'Refresh', onPressed: () => setState(_load), icon: const Icon(Icons.refresh))]),
      const SizedBox(height: 4), const Text('Recent audio and video calls, including missed calls.'),
      const SizedBox(height: 14),
      Row(children: [Expanded(child: FilledButton.icon(onPressed: () => _showCallSetup(context, video: false), icon: const Icon(Icons.call), label: const Text('Audio call'))), const SizedBox(width: 10), Expanded(child: FilledButton.tonalIcon(onPressed: () => _showCallSetup(context, video: true), icon: const Icon(Icons.videocam), label: const Text('Video call')))]),
      const SizedBox(height: 14),
      FutureBuilder<List<Map<String,dynamic>>>(future: _history, builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) return const Padding(padding: EdgeInsets.all(28), child: Center(child: CircularProgressIndicator()));
        if (snapshot.hasError) return const Padding(padding: EdgeInsets.all(18), child: Text('Could not load call history. Pull down to retry.'));
        final rows = snapshot.data ?? const <Map<String,dynamic>>[];
        if (rows.isEmpty) return const Padding(padding: EdgeInsets.all(28), child: Column(children: [Icon(Icons.history, size: 42, color: muted), SizedBox(height: 10), Text('No calls yet', style: TextStyle(fontWeight: FontWeight.w700)), SizedBox(height: 4), Text('Your recent calls will appear here.') ]));
        return Column(children: rows.map((row) {
          final missed = row['status'] == 'missed';
          final isVideo = row['call_type'] == 'video';
          final created = DateTime.tryParse(row['created_at']?.toString() ?? '')?.toLocal();
          final dateText = created == null ? '' : '${created.day.toString().padLeft(2,'0')}/${created.month.toString().padLeft(2,'0')}/${created.year} · ${created.hour.toString().padLeft(2,'0')}:${created.minute.toString().padLeft(2,'0')}';
          final answered = DateTime.tryParse(row['answered_at']?.toString() ?? '');
          final ended = DateTime.tryParse(row['ended_at']?.toString() ?? '');
          final duration = answered == null || ended == null ? null : ended.difference(answered).inSeconds.clamp(0, 86400);
          return Card(child: ListTile(leading: CircleAvatar(backgroundColor: missed ? const Color(0xFFFFE8E8) : const Color(0xFFEAF2FB), child: Icon(_icon(row, uid), color: missed ? const Color(0xFFB42318) : brandBlue)), title: Text('${isVideo ? 'Video' : 'Audio'} · ${_label(row, uid)}', style: TextStyle(fontWeight: FontWeight.w700, color: missed && row['callee_id'] == uid ? const Color(0xFFB42318) : null)), subtitle: Text('$dateText${duration == null ? '' : ' · ${duration ~/ 60}m ${duration % 60}s'}')));
        }).toList());
      }),
    ]));
  }
}

Future<void> _showCallSetup(BuildContext context, {required bool video, String? recipientId}) async {
  final client = Supabase.instance.client;
  final messenger = ScaffoldMessenger.of(context);
  try {
    final peer = recipientId ?? await client.rpc('likedin_get_peer_id') as String?;
    if (peer == null) { messenger.showSnackBar(const SnackBar(content: Text('Your friend has not registered yet.'))); return; }
    if (!context.mounted) return;
    await showDialog<void>(context: context, barrierDismissible: false, builder: (_) => _LiveCallDialog(peerId: peer, video: video));
  } catch (e) {
    messenger.showSnackBar(SnackBar(content: Text('Could not start call: $e')));
  }
}

class _LiveCallDialog extends StatefulWidget {
  const _LiveCallDialog({required this.peerId, required this.video});
  final String peerId; final bool video;
  @override State<_LiveCallDialog> createState() => _LiveCallDialogState();
}
class _LiveCallDialogState extends State<_LiveCallDialog> {
  late final LikedinCallService call;
  final ProximityCallController proximity = ProximityCallController();
  StreamSubscription<String>? sub;
  Timer? durationTicker;
  Stopwatch? stopwatch;
  String status = 'Preparing call…';
  bool ready = false, failed = false, connected = false;
  int elapsedSeconds = 0;

  @override void initState() { super.initState(); _start(); }
  Future<void> _start() async {
    call = LikedinCallService(Supabase.instance.client);
    try {
      await call.initialize();
      sub = call.changes.listen((v) {
        if (!mounted) return;
        final nowConnected = v == 'connected';
        if (nowConnected && !connected) {
          connected = true;
          stopwatch = Stopwatch()..start();
          durationTicker = Timer.periodic(const Duration(seconds: 1), (_) {
            if (mounted && stopwatch != null) setState(() => elapsedSeconds = stopwatch!.elapsed.inSeconds);
          });
        }
        setState(() { status = v; if (v.startsWith('failed') || v.startsWith('error:')) failed = true; });
        if (v == 'connected') proximity.update(active: !widget.video, enabled: !widget.video && !call.speaker);
        if (v == 'ended' || v == 'missed' || v == 'rejected' || v == 'disconnected' || v.startsWith('failed') || v.startsWith('error:')) {
          Future<void>.delayed(const Duration(milliseconds: 900), () { if (mounted && Navigator.of(context).canPop()) Navigator.of(context).pop(); });
        }
      });
      await call.start(widget.peerId, withVideo: widget.video);
      if (mounted) setState(() => ready = true);
    } catch (e) { if (mounted) setState(() { status = e.toString(); failed = true; }); }
  }
  Future<void> _toggleSpeaker() async {
    await call.toggleSpeaker();
    await proximity.update(active: connected && !widget.video, enabled: connected && !widget.video && !call.speaker);
    if (mounted) setState(() {});
  }
  String get _durationLabel => '${(elapsedSeconds ~/ 60).toString().padLeft(2, '0')}:${(elapsedSeconds % 60).toString().padLeft(2, '0')}';
  String get _statusLabel {
    if (connected) return _durationLabel;
    final v = status.toLowerCase();
    if (v.contains('ring')) return 'Ringing…';
    if (v.contains('offer') || v.contains('connecting') || v.contains('preparing')) return 'Calling…';
    if (v.contains('disconnected')) return 'Connection interrupted';
    if (v.contains('failed')) return 'Call connection failed';
    if (v.contains('closed') || v.contains('ended')) return 'Call ended';
    if (v.contains('new')) return 'Connecting…';
    return 'Connecting…';
  }
  @override void dispose() { durationTicker?.cancel(); stopwatch?.stop(); proximity.dispose(); sub?.cancel(); call.close(); super.dispose(); }

  @override Widget build(BuildContext context) {
    final title = connected ? 'In ${widget.video ? 'video' : 'audio'} call' : (widget.video ? 'Video call' : 'Audio call');
    return Dialog.fullscreen(backgroundColor: const Color(0xFF0D1B2A), child: SafeArea(child: Padding(
      padding: const EdgeInsets.fromLTRB(24, 30, 24, 24),
      child: Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Row(children: [IconButton(onPressed: () async { await call.end(); if (context.mounted) Navigator.pop(context); }, icon: const Icon(Icons.keyboard_arrow_down_rounded, color: Colors.white, size: 30)), const Spacer(), Text(widget.video ? 'VIDEO CALL' : 'AUDIO CALL', style: const TextStyle(color: Color(0xFF9FB3C8), fontSize: 11, letterSpacing: 2, fontWeight: FontWeight.w700)), const Spacer(), const SizedBox(width: 48)]),
        Expanded(child: widget.video && connected
          ? ClipRRect(borderRadius: BorderRadius.circular(24), child: Stack(fit: StackFit.expand, children: [
              RTCVideoView(call.remoteRenderer, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover),
              Positioned(right: 14, top: 14, width: 108, height: 148, child: ClipRRect(borderRadius: BorderRadius.circular(18), child: DecoratedBox(decoration: const BoxDecoration(color: Colors.black45), child: RTCVideoView(call.localRenderer, mirror: true, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover)))),
              Positioned(left: 16, top: 16, child: DecoratedBox(decoration: BoxDecoration(color: Colors.black45, borderRadius: BorderRadius.circular(20)), child: Padding(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7), child: Text(_statusLabel, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))))),
            ]))
          : Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              Container(width: 142, height: 142, decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xFF173B5E), border: Border.all(color: const Color(0xFF3B82C4), width: 2), boxShadow: [BoxShadow(color: brandBlue.withOpacity(.22), blurRadius: 35, spreadRadius: 4)]), child: const Icon(Icons.person_rounded, color: Colors.white, size: 76)),
              const SizedBox(height: 30), Text('Likedin contact', style: const TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.w700)),
              const SizedBox(height: 10), Text(title, style: const TextStyle(color: Color(0xFFD6E2EF), fontSize: 15)),
              const SizedBox(height: 8), Text(_statusLabel, style: TextStyle(color: connected ? const Color(0xFF78D6A5) : const Color(0xFF9FB3C8), fontSize: 14, fontWeight: FontWeight.w600)),
              if (failed) Padding(padding: const EdgeInsets.only(top: 12), child: Text(status, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFFFFB4AB), fontSize: 12))),
            ]))),
        Column(children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            _callControl(call.muted ? Icons.mic_off_rounded : Icons.mic_rounded, call.muted ? 'Unmute' : 'Mute', ready ? () async { await call.toggleMute(); if (mounted) setState(() {}); } : null, active: call.muted),
            _callControl(call.speaker ? Icons.volume_up_rounded : Icons.hearing_rounded, call.speaker ? 'Speaker' : 'Earpiece', ready ? _toggleSpeaker : null, active: call.speaker),
            if (widget.video) _callControl(call.camera ? Icons.videocam_rounded : Icons.videocam_off_rounded, 'Camera', ready ? () async { await call.toggleCamera(); if (mounted) setState(() {}); } : null, active: !call.camera),
            if (widget.video) _callControl(Icons.cameraswitch_rounded, 'Flip', ready ? call.switchCamera : null),
          ]),
          const SizedBox(height: 28), SizedBox(width: 190, height: 58, child: FilledButton.icon(onPressed: () async { await call.end(); if (context.mounted) Navigator.pop(context); }, style: FilledButton.styleFrom(backgroundColor: const Color(0xFFE5484D), foregroundColor: Colors.white, shape: const StadiumBorder()), icon: const Icon(Icons.call_end_rounded), label: Text(failed ? 'Close' : 'End call', style: const TextStyle(fontWeight: FontWeight.w700)))),
        ]),
      ]),
    )));
  }

  Widget _callControl(IconData icon, String label, VoidCallback? action, {bool active = false}) => SizedBox(width: 72, child: Column(mainAxisSize: MainAxisSize.min, children: [IconButton(onPressed: action, style: IconButton.styleFrom(backgroundColor: active ? const Color(0xFF2F80ED) : const Color(0xFF26394D), foregroundColor: Colors.white, disabledForegroundColor: Colors.white30, fixedSize: const Size(58,58)), icon: Icon(icon)), Text(label, style: const TextStyle(color: Color(0xFFB8C9D9), fontSize: 10))]));
}

class FilesPage extends StatefulWidget {
  const FilesPage({required this.store, super.key});
  final AttachmentVaultStore store;
  @override State<FilesPage> createState() => _FilesPageState();
}

class _FilesPageState extends State<FilesPage> {
  late Future<List<LocalAttachment>> files;
  bool importing = false;
  @override void initState() { super.initState(); refresh(); }
  void refresh() => files = widget.store.list();

  Future<void> importFiles() async {
    setState(() => importing = true);
    try {
      final saved = await widget.store.importFiles();
      if (!mounted) return;
      setState(refresh);
      if (saved.isNotEmpty) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${saved.length} file(s) copied into Likedin Downloads.')));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not import those files.')));
    } finally { if (mounted) setState(() => importing = false); }
  }

  Future<void> deleteLocal(LocalAttachment file) async {
    final confirmed = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: const Text('Delete downloaded copy?'),
      content: Text('This deletes ${file.name} from this phone only. It does not delete any copy on another device or in cloud storage.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete from phone'))],
    ));
    if (confirmed != true) return;
    await widget.store.deleteLocal(file);
    if (mounted) setState(refresh);
  }

  @override Widget build(BuildContext context) => FutureBuilder<List<LocalAttachment>>(
    future: files,
    builder: (context, snapshot) {
      final items = snapshot.data ?? const <LocalAttachment>[];
      final totalBytes = items.fold<int>(0, (sum, item) => sum + item.sizeBytes);
      return ListView(padding: const EdgeInsets.all(14), children: [
        Row(children: [const Expanded(child: Text('Your downloads', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, ))), FilledButton.icon(onPressed: importing ? null : importFiles, icon: const Icon(Icons.download_outlined), label: Text(importing ? 'Saving…' : 'Save files'))]),
        const SizedBox(height: 8),
        const Text('Keep a copy on this phone before a shared cloud attachment is removed.', style: TextStyle(height: 1.4)),
        const SizedBox(height: 14),
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Row(children: [Icon(Icons.phone_android, color: brandBlue), SizedBox(width: 8), Text('Stored on this device', style: TextStyle(fontWeight: FontWeight.w700, ))]),
          const SizedBox(height: 6),
          Text('${items.length} files · ${(totalBytes / (1024 * 1024)).toStringAsFixed(1)} MB used', style: const TextStyle()),
        ]))),
        const SizedBox(height: 12),
        Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFFFFF6E8), borderRadius: BorderRadius.circular(12)), child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.cloud_off_outlined, color: Color(0xFF9A6700)), SizedBox(width: 9), Expanded(child: Text('Cloud sharing is not connected yet. These are local copies only; the “delete cloud copy for everyone” action will be enabled after the shared backend and upload system are implemented.', style: TextStyle(color: Color(0xFF7A5100), fontSize: 12, height: 1.4)))])),
        const SizedBox(height: 12),
        if (snapshot.connectionState == ConnectionState.waiting) const Center(child: Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator())),
        if (snapshot.hasError) const Text('Could not load your saved files.'),
        if (snapshot.connectionState != ConnectionState.waiting && items.isEmpty) const Padding(padding: EdgeInsets.all(28), child: Column(children: [Icon(Icons.folder_open_outlined, size: 42, ), SizedBox(height: 10), Text('No saved files yet', style: TextStyle(fontWeight: FontWeight.w700, )), SizedBox(height: 5), Text('Tap “Save files” to copy photos, videos or documents into Likedin Downloads.', textAlign: TextAlign.center, style: TextStyle())])),
        ...items.map((file) => Card(child: ListTile(
          leading: const CircleAvatar(backgroundColor: Color(0xFFEAF2FB), child: Icon(Icons.insert_drive_file_outlined, color: brandBlue)),
          title: Text(file.name, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text('${file.readableSize} · Saved on this phone'),
          trailing: IconButton(tooltip: 'Delete local copy', onPressed: () => deleteLocal(file), icon: const Icon(Icons.delete_outline, color: Color(0xFFB42318))),
        ))),
      ]);
    },
  );
}
class SettingsPage extends StatefulWidget { const SettingsPage({super.key}); @override State<SettingsPage> createState() => _SettingsPageState(); }
class _SettingsPageState extends State<SettingsPage> {
  bool get dark => likedinThemeMode.value == ThemeMode.dark;
  Future<void> _setDark(bool value) async {
    likedinThemeMode.value = value ? ThemeMode.dark : ThemeMode.light;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(likedinThemePreferenceKey, value);
    if (mounted) setState(() {});
  }
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(14), children: [
    const Text('Preferences & privacy', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
    const SizedBox(height: 12),
    Card(child: SwitchListTile.adaptive(value: dark, onChanged: _setDark, secondary: Icon(dark ? Icons.dark_mode : Icons.light_mode, color: brandBlue), title: const Text('Dark mode'), subtitle: const Text('Use a darker appearance across the app.'))),
    const SizedBox(height: 8),
    const StatusRow(icon: Icons.key_outlined, title: 'Local encryption key', subtitle: 'Protected through Android secure storage', tint: Color(0xFFEEF5FD)),
    const SizedBox(height: 8),
    const StatusRow(icon: Icons.backup_outlined, title: 'Encrypted backups', subtitle: 'Backup export and restore controls are not available in this build', tint: Color(0xFFF5F0FC)),
    const SizedBox(height: 8),
    const StatusRow(icon: Icons.verified_user_outlined, title: 'Transport security', subtitle: 'TLS and account access controls are enabled; end-to-end encryption is not implemented', tint: Color(0xFFFFF6E8)),
    const SizedBox(height: 8),
    const StatusRow(icon: Icons.info_outline, title: 'About Likedin', subtitle: 'Private two-person Android app · development build', tint: Color(0xFFEAF7F0)),
  ]);
}

class SimplePage extends StatelessWidget { const SimplePage({required this.title, required this.subtitle, required this.icon, super.key}); final String title, subtitle; final IconData icon; @override Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 44, color: brandBlue), const SizedBox(height: 12), Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, )), const SizedBox(height: 8), Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(height: 1.4))]))); }
void _notReady(BuildContext context, String feature) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$feature are planned for a later milestone.')));
