# Likedin v2.7.0+133 — OriginOS 7 Fluid Motion Physics & Interactive Finger-Glide Dock

## What's New in v2.7.0+133
1. **Interactive Finger-Glide Bottom Tab Bar (`OriginFloatingDock`):**
   - Glide your finger smoothly across **Chats ↔ Calls ↔ Files ↔ Profile** (or tap directly) — the Liquid Glass highlight pill follows your finger 1:1 in real time.
   - Features **rubber-band edge resistance**, **velocity-driven liquid squash-and-stretch**, **continuous icon proximity swelling & color morphing**, **haptic detent ticks** on every tab crossing, and **velocity-preserving spring snap** on release.
2. **App-Wide OriginOS 7 Fluid Motion Physics (`OriginPhysics`, `OriginSpringScrollPhysics`, `OriginScrollBehavior`):**
   - **Elastic Spring Scrolling:** Every list (Home, Chat, Calls, Files, Profile, Settings, Appearance) uses calibrated OriginOS 7 fast-deceleration spring overscroll physics (automatically honoring Reduce Motion).
   - **Interruptible Spring Tab Transitions:** Main tab switches use real `SpringSimulation` slide + micro depth scale (`0.976 → 1.0`) with zero unmount/remount of `ChatPage`.
   - **Elastic Rubber-Band Swipe-to-Reply (`_SwipeReplyGesture`):** Pulling a message bubble stretches with hyperbolic rubber-band resistance, triggers a haptic tick at the reply threshold, scales the reply badge, and rebounds smoothly via `SpringSimulation` (zero idle overhead during scrolling).
   - **2D Spring Toss-and-Snap Floating Video PiP (`_MinimizedVideoCallBubble`):** Flick the dual-face floating video card across the screen and it sails with your release velocity and snaps elastically to screen edges.
   - **Swipe-Up Origin Island Dismiss:** Flick transient Origin Island status pills upward to dismiss them smoothly.
