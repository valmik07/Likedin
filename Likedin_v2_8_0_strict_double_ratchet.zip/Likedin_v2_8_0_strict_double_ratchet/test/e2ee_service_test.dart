import 'dart:io';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/security/e2ee_service.dart';

class _MemorySecureStorage extends FlutterSecureStorage {
  final Map<String, String> values = <String, String>{};

  @override
  Future<String?> read({
    required String key,
    IOSOptions? iOptions,
    AndroidOptions? aOptions,
    LinuxOptions? lOptions,
    WebOptions? webOptions,
    MacOsOptions? mOptions,
    WindowsOptions? wOptions,
  }) async =>
      values[key];

  @override
  Future<void> write({
    required String key,
    required String? value,
    IOSOptions? iOptions,
    AndroidOptions? aOptions,
    LinuxOptions? lOptions,
    WebOptions? webOptions,
    MacOsOptions? mOptions,
    WindowsOptions? wOptions,
  }) async {
    if (value == null) {
      values.remove(key);
    } else {
      values[key] = value;
    }
  }

  @override
  Future<void> delete({
    required String key,
    IOSOptions? iOptions,
    AndroidOptions? aOptions,
    LinuxOptions? lOptions,
    WebOptions? webOptions,
    MacOsOptions? mOptions,
    WindowsOptions? wOptions,
  }) async {
    values.remove(key);
  }

  @override
  Future<Map<String, String>> readAll({
    IOSOptions? iOptions,
    AndroidOptions? aOptions,
    LinuxOptions? lOptions,
    WebOptions? webOptions,
    MacOsOptions? mOptions,
    WindowsOptions? wOptions,
  }) async =>
      Map<String, String>.of(values);
}

void main() {
  test('strict mode blocks plaintext send while pending, then encrypts with Double Ratchet v2', () async {
    final aliceStorage = _MemorySecureStorage();
    final bobStorage = _MemorySecureStorage();
    final alice = E2eeService.forTesting(aliceStorage);
    final bob = E2eeService.forTesting(bobStorage);

    expect(await alice.initializeLocalForTesting(userId: 'alice', peerId: 'bob'), isFalse);
    expect(alice.status, E2eeStatus.pending);
    expect(alice.canSendEncrypted, isFalse);
    await expectLater(alice.encryptIfReady('should fail closed'), throwsA(isA<StateError>()));

    await bob.initializeLocalForTesting(userId: 'bob', peerId: 'alice');
    expect(await alice.acceptPeerPublicKey(bob.ownPublicKeyBase64!), isTrue);
    expect(await bob.acceptPeerPublicKey(alice.ownPublicKeyBase64!), isTrue);

    expect(alice.status, E2eeStatus.active);
    expect(bob.status, E2eeStatus.active);
    expect(alice.hasForwardSecrecy, isTrue);
    expect(alice.safetyFingerprint, isNotNull);
    expect(alice.safetyFingerprint, bob.safetyFingerprint);

    final cipher1 = await alice.encryptIfReady('secret message 1');
    final cipher2 = await alice.encryptIfReady('secret message 2');
    expect(E2eeService.isV2Envelope(cipher1), isTrue);
    expect(E2eeService.isV2Envelope(cipher2), isTrue);
    expect(await bob.decryptIfNeeded(cipher1), 'secret message 1');
    expect(await bob.decryptIfNeeded(cipher2), 'secret message 2');

    // Re-reading already-decrypted envelopes returns cached plaintext without error.
    expect(await bob.decryptIfNeeded(cipher1), 'secret message 1');
    expect(await alice.decryptIfNeeded(cipher1), 'secret message 1');
  });

  test('peer key rotation pauses sending (keyChanged lock) until verified or accepted', () async {
    final aliceStorage = _MemorySecureStorage();
    final bobStorage1 = _MemorySecureStorage();
    final bobStorage2 = _MemorySecureStorage();

    final alice = E2eeService.forTesting(aliceStorage);
    final bobOld = E2eeService.forTesting(bobStorage1);
    final bobNew = E2eeService.forTesting(bobStorage2);

    await alice.initializeLocalForTesting(userId: 'alice', peerId: 'bob');
    await bobOld.initializeLocalForTesting(userId: 'bob', peerId: 'alice');
    await bobNew.initializeLocalForTesting(userId: 'bob', peerId: 'alice');

    await alice.acceptPeerPublicKey(bobOld.ownPublicKeyBase64!);
    await alice.markCurrentFingerprintVerified();
    expect(alice.status, E2eeStatus.verified);
    expect(alice.isVerified, isTrue);
    expect(alice.canSendEncrypted, isTrue);

    // Cold restart preserves verified badge.
    final aliceRestarted = E2eeService.forTesting(aliceStorage);
    await aliceRestarted.initializeLocalForTesting(userId: 'alice', peerId: 'bob');
    expect(aliceRestarted.status, E2eeStatus.verified);

    // Peer rotates identity key -> verification clears & sending is strictly blocked!
    await aliceRestarted.acceptPeerPublicKey(bobNew.ownPublicKeyBase64!);
    expect(aliceRestarted.status, E2eeStatus.keyChanged);
    expect(aliceRestarted.hasPeerKeyChanged, isTrue);
    expect(aliceRestarted.isVerified, isFalse);
    expect(aliceRestarted.canSendEncrypted, isFalse);
    await expectLater(
      aliceRestarted.encryptIfReady('blocked until accepted'),
      throwsA(isA<StateError>()),
    );

    // Warning & send lock persist across restart until acknowledged or verified.
    final aliceAfterRestart2 = E2eeService.forTesting(aliceStorage);
    await aliceAfterRestart2.initializeLocalForTesting(userId: 'alice', peerId: 'bob');
    expect(aliceAfterRestart2.status, E2eeStatus.keyChanged);
    await expectLater(
      aliceAfterRestart2.encryptIfReady('still blocked'),
      throwsA(isA<StateError>()),
    );

    await aliceAfterRestart2.acknowledgePeerKeyChange();
    expect(aliceAfterRestart2.status, E2eeStatus.active);
    expect(aliceAfterRestart2.canSendEncrypted, isTrue);

    await aliceAfterRestart2.markCurrentFingerprintVerified();
    expect(aliceAfterRestart2.status, E2eeStatus.verified);

    // Now Alice & bobNew can converse over the freshly reset Double Ratchet!
    await bobNew.acceptPeerPublicKey(aliceAfterRestart2.ownPublicKeyBase64!);
    final cipher = await aliceAfterRestart2.encryptIfReady('after key rotation');
    expect(await bobNew.decryptIfNeeded(cipher), 'after key rotation');
  });

  test('forward-secret per-file media key round-trips and rejects wrong key', () async {
    final tmp = await Directory.systemTemp.createTemp('likedin_e2ee_file_');
    addTearDown(() => tmp.delete(recursive: true));

    final alice = E2eeService.forTesting(_MemorySecureStorage(), cacheDirectory: tmp);
    final bob = E2eeService.forTesting(_MemorySecureStorage(), cacheDirectory: tmp);
    await alice.initializeLocalForTesting(userId: 'alice', peerId: 'bob');
    await bob.initializeLocalForTesting(userId: 'bob', peerId: 'alice');
    await alice.acceptPeerPublicKey(bob.ownPublicKeyBase64!);
    await bob.acceptPeerPublicKey(alice.ownPublicKeyBase64!);

    final plain = File('${tmp.path}/plain.bin');
    final enc = File('${tmp.path}/enc.bin');
    final originalBytes = List<int>.generate(12000, (i) => i % 251);
    await plain.writeAsBytes(originalBytes, flush: true);

    final perFileKey = E2eeService.generatePerFileMediaKeyBase64();
    expect(
      await alice.encryptFileToDestination(plain, enc, keyBase64Override: perFileKey),
      isTrue,
    );
    expect(await E2eeService.detectEncryptedMediaVersion(enc), 2);

    // Attempting to decrypt without the per-file key fails authentication.
    await expectLater(
      bob.decryptFileInPlaceIfNeeded(enc, requireEncrypted: true),
      throwsA(anything),
    );

    // Decrypting with the per-file key succeeds cleanly.
    await bob.decryptFileInPlaceIfNeeded(
      enc,
      requireEncrypted: true,
      mediaKeyBase64: perFileKey,
    );
    expect(await enc.readAsBytes(), originalBytes);
  });
}
