# Likedin v1.8.4 — upload and build

This is the complete Likedin Android project archive for version **1.8.4+81**.

## Before the APK build

1. Open `supabase/migrations/202611210001_v184_profile_avatar_and_usage_optimization.sql` in Supabase SQL Editor and run it once.
2. Do not rerun earlier migrations. This migration adds `profiles.avatar_path` and throttles online presence writes. It does not delete messages and does not change push notifications.
3. Existing v1.8.3 profile photos were stored only on their original devices. After upgrading, each account holder must select/reselect their photo once to upload it to the private `likedin-media` bucket.

## GitHub workflow upload

The existing repository workflow expects exactly one root-level project ZIP. Replace the previous `Likedin_v1.8.3_source.zip` with this archive, keeping the ZIP at the repository root. Do not leave two project ZIPs in the root.

The existing GitHub Actions workflow also requires the four persistent release-signing secrets:

- `LIKEDIN_KEYSTORE_B64`
- `LIKEDIN_STORE_PASSWORD`
- `LIKEDIN_KEY_ALIAS`
- `LIKEDIN_KEY_PASSWORD`

Run the `Likedin Android APK` workflow on `main`. The first run may generate the `likedin-pubspec-lock` artifact; preserve its `pubspec.lock` in the project source for future reproducible builds.

## After installation

Install the v1.8.4+81 APK on both paired phones and follow `docs/REGRESSION_TEST_PLAN_v1.8.4.md`. Flutter analysis and tests must pass in GitHub Actions before considering the release validated.

No push Edge Function redeployment is needed: v1.8.4 does not change notification code or payloads.
