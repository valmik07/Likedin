# Likedin v1.8.4 — chat de-duplication, media replies and cross-device avatars

## Messaging
- Optimistic and persisted message rows are merged by `client_message_id`, not only by the Postgres row ID. A single logical send renders once.
- Text sends require a confirmed server row ID. If the response is lost after a server commit, the client reconciles by the same idempotency key before retrying.
- Clearing the composer after sending no longer discards the draft's stable retry ID. A failed retry reuses the same ID instead of creating a second message.
- Realtime receipt updates can promote a still-visible optimistic row to its persisted row ID.

## Media and replies
- File attachments preserve `reply_to_message_id` from the selected reply target.
- Reply previews retrieve referenced message rows that are outside the latest loaded page, without inserting those older rows into the visible timeline.
- Sender media cache lookup tolerates an existing object-path cache file whose extension differs from the display filename.
- Media rendering retries transient signed-URL/download failures and reloads the chat after background queue completion.

## Cross-device profile photos
- Profile photos upload to the existing private `likedin-media` Storage bucket under the owner's UUID folder.
- `profiles.avatar_path` stores only the private object path; the other paired account receives a short-lived signed URL.
- Each user must select/reselect their current photo once after installing v1.8.4; v1.8.3 photos were local-only and are not automatically uploaded.

## Realtime usage controls
- Typing broadcasts are sent only on idle/typing transitions, not per keystroke.
- Message INSERT events go only to the recipient subscription; the sender reconciles from RPC/REST.
- Message UPDATE and reaction events remain subscribed where needed for read/delivery receipts, deletions and reactions.
- Profile UPDATE subscriptions are filtered to the other paired account.
- Online presence database writes are throttled to once per 55 seconds; offline transitions remain immediate.
- No chat history is automatically deleted.

## Backend migration required
Apply `supabase/migrations/202611210001_v184_profile_avatar_and_usage_optimization.sql` once before using v1.8.4. The migration is additive: it adds `profiles.avatar_path` and replaces the presence RPC with a throttled implementation. It does not alter message history or notification functions.

## Validation status
Source-level edits and archive structure were checked. Flutter/Dart tools and a live two-device Supabase test environment were not available in the packaging environment. Run `flutter analyze` and `flutter test`, then verify the two-device cases in `docs/REGRESSION_TEST_PLAN_v1.8.4.md` before calling the release production-validated.
