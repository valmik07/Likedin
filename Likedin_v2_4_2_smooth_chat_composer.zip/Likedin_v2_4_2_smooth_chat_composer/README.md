# Likedin v2.4.2+127 — Silky-Smooth Chat Scrolling, High-Contrast Ticks & Minimal Liquid Glass Composer

## Changes in v2.4.2+127
1. **Silky-Smooth Chat Page (Eliminated Jitter):**
   - Replaced per-bubble `ClipRRect` + dual `CustomPaint` shaders with a GPU-native single-draw-call `DecoratedBox` Liquid Glass bubble.
   - Removed idle `Stack`, `Opacity`, and `AnimatedContainer` animation controllers from `_SwipeReplyGesture` (zero overhead until horizontally dragged).
   - Removed per-frame `BackdropFilter` GPU readback stalls from the Chat header & composer and isolated `ListView.builder` and `PeekingBitmojiBar` with `RepaintBoundary`.
   - Memoized timeline grouping, throttled floating-date scroll updates, hoisted URL `RegExp`, and fast-pathed plain text in `_RichMessageText`.
2. **Unmistakable Read vs Delivered Ticks in Light & Dark Mode:**
   - Delivered/sent ticks now render in true neutral muted grey (`#8E99AB` light / `#8B9AB2` dark) instead of inheriting dark navy text color.
   - Read ticks render in vivid bright sky blue (`#0095F6` light / `#38D6FF` dark).
3. **Minimal, Uncluttered Liquid Glass Composer:**
   - Replaced the crowded pill-inside-a-pill layout with a sleek 3-part floating bar: detached `+` glass circle (attachments + formatting toggle), spacious single Liquid Glass input capsule (with compact emoji icon + contextual `Aa` icon when typing), and detached circular Mic/Send action button.
