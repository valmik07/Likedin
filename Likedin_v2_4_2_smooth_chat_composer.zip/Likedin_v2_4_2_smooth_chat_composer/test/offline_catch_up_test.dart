import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/backend/realtime_messaging_service.dart';
import 'package:likedin/utils/offline_catch_up.dart';

final _base = DateTime.utc(2026, 11, 1);

/// Server history of [total] messages, index 0 = oldest.
List<RemoteMessage> _history(int total) => [
      for (var i = 0; i < total; i++)
        RemoteMessage(
          id: 'id-${i.toString().padLeft(5, '0')}',
          clientMessageId: 'c-$i',
          senderId: 'peer',
          recipientId: 'me',
          text: 'm$i',
          createdAt: _base.add(Duration(minutes: i)),
        ),
    ];

void main() {
  const pageSize = 10;

  /// Emulates loadConversation(before: cursor): the page just older than it.
  Future<List<RemoteMessage>> Function(RemoteMessage) fetcher(List<RemoteMessage> all, void Function() onCall) {
    return (cursor) async {
      onCall();
      final older = all.where((m) => m.createdAt.isBefore(cursor.createdAt)).toList();
      return older.length <= pageSize ? older : older.sublist(older.length - pageSize);
    };
  }

  test('no gap: newest page overlaps what is known, nothing extra fetched', () async {
    final all = _history(30);
    var calls = 0;
    final result = await catchUpNewestPages(
      newestPage: all.sublist(20),
      known: all.sublist(15, 25),
      fetchOlder: fetcher(all, () => calls++),
      pageSize: pageSize,
    );
    expect(calls, 0);
    expect(result.capped, isFalse);
    expect(result.messages.length, 10);
  });

  test('closes a multi-page gap and reaches the known boundary', () async {
    final all = _history(60);
    var calls = 0;
    final result = await catchUpNewestPages(
      newestPage: all.sublist(50),
      known: all.sublist(0, 10), // newest known = index 9
      fetchOlder: fetcher(all, () => calls++),
      pageSize: pageSize,
    );
    expect(result.capped, isFalse);
    // The final page overlaps the known window, so the result is the whole
    // contiguous history with no hole and no duplicates.
    expect(result.messages.map((m) => m.id).toList(), all.map((m) => m.id).toList());
    expect(calls, 5);
  });

  test('is bounded: stops at maxPages and reports capped', () async {
    final all = _history(1000);
    var calls = 0;
    final result = await catchUpNewestPages(
      newestPage: all.sublist(990),
      known: all.sublist(0, 10),
      fetchOlder: fetcher(all, () => calls++),
      pageSize: pageSize,
      maxPages: 20,
    );
    expect(calls, 20);
    expect(result.capped, isTrue);
    expect(result.pagesFetched, 20);
    expect(result.messages.length, pageSize + 20 * pageSize);
  });

  test('ignores optimistic (uncommitted) messages when deciding on a gap', () async {
    final all = _history(30);
    final optimistic = RemoteMessage(
      id: 'c-new', clientMessageId: 'c-new', senderId: 'me', recipientId: 'peer',
      text: 'pending', createdAt: _base.add(const Duration(days: 1)),
    );
    var calls = 0;
    final result = await catchUpNewestPages(
      newestPage: all.sublist(20),
      known: [optimistic],
      fetchOlder: fetcher(all, () => calls++),
      pageSize: pageSize,
    );
    expect(calls, 0);
    expect(result.capped, isFalse);
  });

  test('stops if the cursor does not advance (malformed pagination)', () async {
    final all = _history(40);
    var calls = 0;
    final result = await catchUpNewestPages(
      newestPage: all.sublist(30),
      known: all.sublist(0, 5),
      fetchOlder: (cursor) async {
        calls++;
        return all.sublist(30); // always the same, never older
      },
      pageSize: pageSize,
    );
    expect(calls, 1);
    expect(result.capped, isFalse);
  });
}
