import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:likedin/security/hidden_chat_vault.dart';

class MemorySecureStorage extends FlutterSecureStorage {
  final Map<String, String> values = <String, String>{};

  @override
  Future<String?> read({required String key, IOSOptions? iOptions, AndroidOptions? aOptions, LinuxOptions? lOptions, WebOptions? webOptions, MacOsOptions? mOptions, WindowsOptions? wOptions}) async => values[key];

  @override
  Future<void> write({required String key, required String? value, IOSOptions? iOptions, AndroidOptions? aOptions, LinuxOptions? lOptions, WebOptions? webOptions, MacOsOptions? mOptions, WindowsOptions? wOptions}) async {
    if (value == null) {
      values.remove(key);
    } else {
      values[key] = value;
    }
  }

  @override
  Future<void> delete({required String key, IOSOptions? iOptions, AndroidOptions? aOptions, LinuxOptions? lOptions, WebOptions? webOptions, MacOsOptions? mOptions, WindowsOptions? wOptions}) async {
    values.remove(key);
  }

  @override
  Future<Map<String, String>> readAll({IOSOptions? iOptions, AndroidOptions? aOptions, LinuxOptions? lOptions, WebOptions? webOptions, MacOsOptions? mOptions, WindowsOptions? wOptions}) async => Map<String, String>.of(values);
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  SharedPreferences.setMockInitialValues(<String, Object>{});

  test('password verifier is salted and accepts only the correct password', () async {
    final storage = MemorySecureStorage();
    final vault = HiddenChatVault(storage: storage);

    expect(await vault.hasPassword('account-1'), isFalse);
    await vault.configurePassword('account-1', 'hidden-chat-password');

    expect(await vault.hasPassword('account-1'), isTrue);
    expect(await vault.verifyPassword('account-1', 'hidden-chat-password'), isTrue);
    expect(await vault.verifyPassword('account-1', 'incorrect-password'), isFalse);
    expect(storage.values.values.any((value) => value == 'hidden-chat-password'), isFalse);
  });

  test('hidden conversation ids round-trip and update notification redaction', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    final vault = HiddenChatVault(storage: MemorySecureStorage());
    await vault.configurePassword('account-1', 'hidden-chat-password');

    await vault.setHidden('account-1', 'peer-1', true);
    expect(await vault.isHidden('account-1', 'peer-1'), isTrue);
    expect(await vault.hasHiddenChats('account-1'), isTrue);
    expect(
      (await SharedPreferences.getInstance()).getBool(
        HiddenChatVault.notificationRedactionPreference,
      ),
      isTrue,
    );

    await vault.setHidden('account-1', 'peer-1', false);
    expect(await vault.hasHiddenChats('account-1'), isFalse);
    expect(
      (await SharedPreferences.getInstance()).getBool(
        HiddenChatVault.notificationRedactionPreference,
      ),
      isFalse,
    );
  });


  test('cannot hide a conversation before a password exists', () async {
    final vault = HiddenChatVault(storage: MemorySecureStorage());
    await expectLater(
      vault.setHidden('account-1', 'peer-1', true),
      throwsStateError,
    );
  });

  test('passwords shorter than eight characters are rejected', () async {
    final vault = HiddenChatVault(storage: MemorySecureStorage());
    await expectLater(
      vault.configurePassword('account-1', '1234567'),
      throwsArgumentError,
    );
  });
}
