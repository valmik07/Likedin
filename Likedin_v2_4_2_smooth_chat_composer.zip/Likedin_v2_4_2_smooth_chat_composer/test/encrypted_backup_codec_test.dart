import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/security/encrypted_backup_codec.dart';

void main() {
  test('encrypted backup round-trips with the correct passphrase', () async {
    final codec = EncryptedBackupCodec();
    const payload = '{"format":"project-whisper-backup","version":1}';
    final encrypted = await codec.encrypt(payload, 'correct horse battery');
    final restored = await codec.decrypt(encrypted, 'correct horse battery');
    expect(restored, payload);
  });

  test('encrypted backup rejects a short passphrase', () async {
    final codec = EncryptedBackupCodec();
    await expectLater(
      codec.encrypt('{}', 'short'),
      throwsArgumentError,
    );
  });
}
