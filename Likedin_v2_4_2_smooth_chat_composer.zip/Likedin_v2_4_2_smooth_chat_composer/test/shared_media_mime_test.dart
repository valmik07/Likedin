import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/backend/shared_media_service.dart';

void main() {
  late Directory tempDirectory;

  setUp(() async {
    tempDirectory = await Directory.systemTemp.createTemp('likedin_media_mime_test_');
  });

  tearDown(() async {
    if (await tempDirectory.exists()) {
      await tempDirectory.delete(recursive: true);
    }
  });

  Future<File> writeFixture(String name, List<int> bytes) async {
    final file = File('${tempDirectory.path}/$name');
    await file.writeAsBytes(bytes, flush: true);
    return file;
  }

  test('detects extensionless JPEG bytes as an image', () async {
    final file = await writeFixture('media_001', <int>[0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10]);

    expect(await SharedMediaService.detectMimeType(file, displayName: 'Camera Photo'), 'image/jpeg');
    expect(SharedMediaService.extensionForMime('image/jpeg'), '.jpg');
  });

  test('detects a GIF even when its display name has no extension', () async {
    final file = await writeFixture('media_002', 'GIF89a'.codeUnits + <int>[0x01, 0x00, 0x01, 0x00]);

    expect(await SharedMediaService.detectMimeType(file, displayName: 'Animation'), 'image/gif');
    expect(SharedMediaService.extensionForMime('image/gif'), '.gif');
  });

  test('file signature takes priority over a misleading extension', () async {
    final file = await writeFixture(
      'media_003.png',
      'GIF87a'.codeUnits + <int>[0x02, 0x00, 0x02, 0x00],
    );

    expect(await SharedMediaService.detectMimeType(file), 'image/gif');
  });


  test('exposes raw MIME signatures for legacy BMP and TIFF attachments', () async {
    final bmp = await writeFixture('legacy_001', <int>[0x42, 0x4D, 0x00, 0x00]);
    final tiff = await writeFixture('legacy_002', <int>[0x49, 0x49, 0x2A, 0x00]);

    expect(await SharedMediaService.detectRawMimeType(bmp), 'image/bmp');
    expect(await SharedMediaService.detectRawMimeType(tiff), 'image/tiff');
    // These formats are deliberately converted to JPEG before upload because
    // the current private Storage bucket does not permit their raw MIME types.
    expect(await SharedMediaService.detectMimeType(bmp), 'application/octet-stream');
    expect(await SharedMediaService.detectMimeType(tiff), 'application/octet-stream');
  });

  test('detects PNG and WebP from bytes', () async {
    final png = await writeFixture('media_004', <int>[
      0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A,
    ]);
    final webp = await writeFixture('media_005', <int>[
      0x52, 0x49, 0x46, 0x46, 0x00, 0x00, 0x00, 0x00,
      0x57, 0x45, 0x42, 0x50,
    ]);

    expect(await SharedMediaService.detectMimeType(png, displayName: 'No extension'), 'image/png');
    expect(await SharedMediaService.detectMimeType(webp, displayName: 'No extension'), 'image/webp');
  });


  test('detects common audio formats from file signatures', () async {
    final mp3 = await writeFixture('audio_001', 'ID3'.codeUnits + <int>[0x04, 0x00, 0x00]);
    final wav = await writeFixture('audio_002', <int>[
      ...'RIFF'.codeUnits, 0x24, 0x00, 0x00, 0x00, ...'WAVE'.codeUnits,
    ]);
    final ogg = await writeFixture('audio_003', 'OggS'.codeUnits + <int>[0x00, 0x02]);
    final flac = await writeFixture('audio_004', 'fLaC'.codeUnits + <int>[0x00, 0x00]);

    expect(await SharedMediaService.detectMimeType(mp3), 'audio/mpeg');
    expect(await SharedMediaService.detectMimeType(wav), 'audio/wav');
    expect(await SharedMediaService.detectMimeType(ogg), 'audio/ogg');
    expect(await SharedMediaService.detectMimeType(flac), 'audio/flac');
  });
}
