import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/main.dart';

void main() {
  testWidgets('Likedin logo uses the blue in mark', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: Scaffold(body: LikedinLogo())));
    expect(find.text('in'), findsOneWidget);
  });
}
