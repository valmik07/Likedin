import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/backend/realtime_messaging_service.dart';
import 'package:likedin/ui/message_search.dart';

RemoteMessage _message({
  required String id,
  required String text,
  required DateTime createdAt,
  DateTime? deletedAt,
}) => RemoteMessage(
      id: id,
      senderId: 'sender',
      recipientId: 'recipient',
      text: text,
      createdAt: createdAt,
      deletedForEveryoneAt: deletedAt,
    );

void main() {
  final timestamp = DateTime(2026, 11, 17, 12);

  group('MessageSearchFilter', () {
    test('matches ordinary text case-insensitively', () {
      final message = _message(
        id: 'text-1',
        text: 'Meet me near the station',
        createdAt: timestamp,
      );

      expect(const MessageSearchFilter(query: 'NEAR THE').matches(message), isTrue);
      expect(const MessageSearchFilter(query: 'airport').matches(message), isFalse);
    });

    test('filters photos and searches attachment names', () {
      final photo = _message(
        id: 'photo-1',
        text: '{"__likedin_media_v1":true,"kind":"image","name":"holiday.jpg"}',
        createdAt: timestamp,
      );

      expect(
        const MessageSearchFilter(
          query: 'holiday',
          media: MessageMediaFilter.photos,
        ).matches(photo),
        isTrue,
      );
      expect(
        const MessageSearchFilter(media: MessageMediaFilter.videos).matches(photo),
        isFalse,
      );
    });

    test('does not classify deleted attachments as searchable media', () {
      final deletedPhoto = _message(
        id: 'deleted-photo',
        text: '{"__likedin_media_v1":true,"kind":"image","name":"old.jpg"}',
        createdAt: timestamp,
        deletedAt: timestamp,
      );

      expect(
        const MessageSearchFilter(media: MessageMediaFilter.photos).matches(deletedPhoto),
        isFalse,
      );
      expect(const MessageSearchFilter(query: 'deleted').matches(deletedPhoto), isTrue);
    });

    test('uses inclusive calendar-day date bounds', () {
      final onSelectedDay = _message(
        id: 'date-1',
        text: 'A dated message',
        createdAt: DateTime(2026, 11, 17, 23, 59),
      );
      final nextDay = _message(
        id: 'date-2',
        text: 'A later message',
        createdAt: DateTime(2026, 11, 18, 0, 0),
      );

      final filter = MessageSearchFilter(
        fromDate: DateTime(2026, 11, 17),
        toDate: DateTime(2026, 11, 17),
      );
      expect(filter.matches(onSelectedDay), isTrue);
      expect(filter.matches(nextDay), isFalse);
    });
  });
}
