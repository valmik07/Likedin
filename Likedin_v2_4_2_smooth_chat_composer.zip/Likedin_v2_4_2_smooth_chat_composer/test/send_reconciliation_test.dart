import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/utils/send_reconciliation.dart';

void main() {
  test('happy path never performs a lookup', () async {
    var lookups = 0;
    final id = await sendWithReconciliation(
      send: () async => 'row-1',
      lookup: () async { lookups++; return null; },
    );
    expect(id, 'row-1');
    expect(lookups, 0);
  });

  test('timeout after commit: lookup finds the row and counts as success', () async {
    final id = await sendWithReconciliation(
      send: () async => throw Exception('timeout'),
      lookup: () async => 'row-7',
    );
    expect(id, 'row-7');
  });

  test('genuine failure rethrows the ORIGINAL error', () async {
    await expectLater(
      sendWithReconciliation(
        send: () async => throw ArgumentError('rejected by server'),
        lookup: () async => null,
      ),
      throwsA(isA<ArgumentError>()),
    );
  });

  test('lookup failing too (offline) still surfaces the original error', () async {
    await expectLater(
      sendWithReconciliation(
        send: () async => throw const FormatException('send failed'),
        lookup: () async => throw Exception('lookup failed'),
      ),
      throwsA(isA<FormatException>()),
    );
  });

  test('unreadable reply is confirmed by lookup', () async {
    final id = await sendWithReconciliation(
      send: () async => null,
      lookup: () async => 'row-3',
    );
    expect(id, 'row-3');
  });

  test('unreadable reply and nothing committed asks the user to retry', () async {
    await expectLater(
      sendWithReconciliation(send: () async => null, lookup: () async => null),
      throwsA(isA<StateError>()),
    );
  });
}
