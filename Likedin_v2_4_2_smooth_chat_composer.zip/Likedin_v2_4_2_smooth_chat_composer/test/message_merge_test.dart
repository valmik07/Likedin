import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/backend/realtime_messaging_service.dart';
import 'package:likedin/utils/message_merge.dart';

const _me = 'me';
const _peer = 'peer';
final _t0 = DateTime.utc(2026, 11, 23, 10);

RemoteMessage _msg({
  String id = 'row-1',
  String? client = 'c-1',
  String text = 'hello',
  String sender = _me,
  String recipient = _peer,
  DateTime? createdAt,
  DateTime? delivered,
  DateTime? read,
  DateTime? edited,
  DateTime? deleted,
  String? deletedMediaPath,
}) =>
    RemoteMessage(
      id: id,
      clientMessageId: client,
      senderId: sender,
      recipientId: recipient,
      text: text,
      createdAt: createdAt ?? _t0,
      deliveredAt: delivered,
      readAt: read,
      editedAt: edited,
      deletedForEveryoneAt: deleted,
      deletedMediaPath: deletedMediaPath,
    );

void main() {
  group('deletion precedence', () {
    test('tombstone beats a stale edited copy regardless of order', () {
      final stale = _msg(text: 'secret', edited: _t0.add(const Duration(minutes: 5)));
      final tomb = _msg(text: '[deleted]', deleted: _t0.add(const Duration(minutes: 6)));
      for (final order in [[stale, tomb], [tomb, stale]]) {
        final merged = mergeMessagesByClientId(order).single;
        expect(merged.deletedForEveryoneAt, isNotNull);
        expect(merged.text, '[deleted]');
      }
    });

    test('tombstone beats a stale copy that has a read receipt', () {
      final stale = _msg(delivered: _t0, read: _t0);
      final tomb = _msg(text: '[deleted]', deleted: _t0);
      final merged = mergeMessagesByClientId([tomb, stale]).single;
      expect(merged.text, '[deleted]');
      expect(merged.readAt, isNotNull, reason: 'receipts are still merged');
    });

    test('edited vs deleted-never-edited no longer ties', () {
      final edited = _msg(text: 'v2', edited: _t0);
      final tomb = _msg(text: '[deleted]', deleted: _t0);
      expect(mergeMessagesByClientId([tomb, edited]).single.text, '[deleted]');
      expect(mergeMessagesByClientId([edited, tomb]).single.text, '[deleted]');
    });

    test('deleted media path survives the merge', () {
      final tomb = _msg(text: '[deleted]', deleted: _t0, deletedMediaPath: 'u/file.jpg');
      final plain = _msg(text: '{"__likedin_media_v1":true}');
      final merged = mergeMessagesByClientId([tomb, plain]).single;
      expect(merged.deletedMediaPath, 'u/file.jpg');
    });
  });

  group('edit precedence and receipts', () {
    test('later edit wins even when the older copy has a read receipt', () {
      final oldRead = _msg(text: 'v1', edited: _t0, delivered: _t0, read: _t0);
      final newer = _msg(text: 'v2', edited: _t0.add(const Duration(minutes: 1)));
      final merged = mergeMessagesByClientId([newer, oldRead]).single;
      expect(merged.text, 'v2');
      expect(merged.readAt, isNotNull);
    });

    test('second edit replaces first edit', () {
      final first = _msg(text: 'v2', edited: _t0);
      final second = _msg(text: 'v3', edited: _t0.add(const Duration(seconds: 30)));
      expect(mergeMessagesByClientId([second, first]).single.text, 'v3');
      expect(mergeMessagesByClientId([first, second]).single.text, 'v3');
    });

    test('edited copy beats unedited copy', () {
      final plain = _msg(text: 'v1', delivered: _t0, read: _t0);
      final edited = _msg(text: 'v2', edited: _t0);
      expect(mergeMessagesByClientId([edited, plain]).single.text, 'v2');
    });
  });

  group('optimistic reconciliation', () {
    test('server row replaces optimistic placeholder and keeps server id', () {
      final optimistic = _msg(id: 'c-1', client: 'c-1', createdAt: _t0.add(const Duration(seconds: 2)));
      final server = _msg(id: 'row-9', client: 'c-1');
      final merged = mergeMessagesByClientId([server, optimistic]).single;
      expect(merged.id, 'row-9');
      expect(merged.createdAt, _t0);
    });

    test('messages sort chronologically with id tiebreak', () {
      final a = _msg(id: 'b', client: 'c-b', createdAt: _t0);
      final b = _msg(id: 'a', client: 'c-a', createdAt: _t0);
      final c = _msg(id: 'z', client: 'c-z', createdAt: _t0.subtract(const Duration(minutes: 1)));
      expect(mergeMessagesByClientId([a, b, c]).map((m) => m.id), ['z', 'a', 'b']);
    });
  });

  group('delivery receipt race', () {
    test('only snapshotted ids are acknowledged locally', () {
      final before = _msg(id: 'm1', client: 'c1', sender: _peer, recipient: _me);
      final arrivedDuringRpc = _msg(id: 'm2', client: 'c2', sender: _peer, recipient: _me);
      final result = applyReceiptToIds(
        [before, arrivedDuringRpc],
        me: _me,
        onlyIds: {'m1'},
        now: _t0,
        delivered: true,
      );
      expect(result[0].deliveredAt, isNotNull);
      expect(result[1].deliveredAt, isNull, reason: 'must be re-acknowledged on the next pass');
    });

    test('never touches messages sent by me', () {
      final mine = _msg(id: 'm1', sender: _me, recipient: _peer);
      final result = applyReceiptToIds([mine], me: _me, onlyIds: {'m1'}, now: _t0, delivered: true);
      expect(result.single.deliveredAt, isNull);
    });

    test('read implies delivered and keeps existing timestamps', () {
      final earlier = _t0.subtract(const Duration(minutes: 1));
      final m = _msg(id: 'm1', sender: _peer, recipient: _me, delivered: earlier);
      final result = applyReceiptToIds([m], me: _me, onlyIds: {'m1'}, now: _t0, delivered: true, read: true);
      expect(result.single.deliveredAt, earlier);
      expect(result.single.readAt, _t0);
    });
  });

  group('reaction hydration', () {
    test('hydrated ids are skipped, pending optimistic ids never fetched', () {
      final committed = _msg(id: 'm1', client: 'c1');
      final other = _msg(id: 'm2', client: 'c2');
      final pending = _msg(id: 'c3', client: 'c3');
      expect(reactionIdsToFetch([committed, other, pending], {'m1'}), ['m2']);
    });

    test('clearing the hydrated set (resume/reconnect) refetches everything', () {
      final msgs = [_msg(id: 'm1', client: 'c1'), _msg(id: 'm2', client: 'c2')];
      final hydrated = <String>{'m1', 'm2'};
      expect(reactionIdsToFetch(msgs, hydrated), isEmpty);
      hydrated.clear();
      expect(reactionIdsToFetch(msgs, hydrated), ['m1', 'm2']);
    });
  });
}
