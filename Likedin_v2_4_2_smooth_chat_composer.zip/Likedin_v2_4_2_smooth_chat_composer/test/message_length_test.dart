import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/utils/message_length.dart';

void main() {
  group('Likedin message length contract', () {
    test('counts Unicode code points rather than UTF-16 code units', () {
      expect(likedinMessageCodePointLength('A😀B'), 3);
      expect('A😀B'.length, 4);
    });

    test('uses the same code-point rule for combining sequences', () {
      // e + combining acute accent is two code points (one grapheme cluster).
      expect(likedinMessageCodePointLength('e\u0301'), 2);
    });

    test('truncates at the shared 10000-code-point boundary', () {
      final value = List<String>.filled(likedinMaxMessageCodePoints + 2, '😀').join();
      final truncated = likedinTruncateMessage(value);
      expect(likedinMessageCodePointLength(truncated), likedinMaxMessageCodePoints);
      expect(truncated.runes.first, 0x1F600);
    });
  });
}
