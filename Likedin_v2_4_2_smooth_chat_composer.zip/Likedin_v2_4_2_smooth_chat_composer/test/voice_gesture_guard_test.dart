import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/utils/voice_gesture_guard.dart';

void main() {
  test('plain tap: cancel fires but must NOT discard (tap-to-stop keeps recording)', () {
    final guard = VoiceGestureGuard();
    expect(guard.shouldDiscardOnCancel(), isFalse);
  });

  test('long press that began recording and is cancelled is discarded once', () {
    final guard = VoiceGestureGuard();
    guard.longPressStarted();
    expect(guard.shouldDiscardOnCancel(), isTrue);
    expect(guard.shouldDiscardOnCancel(), isFalse);
  });

  test('normal long-press release stops exactly once', () {
    final guard = VoiceGestureGuard();
    guard.longPressStarted();
    expect(guard.longPressEnded(), isTrue);
    expect(guard.longPressEnded(), isFalse);
  });

  test('timer auto-stop during a hold: later release does nothing', () {
    final guard = VoiceGestureGuard();
    guard.longPressStarted();
    guard.reset();
    expect(guard.longPressEnded(), isFalse);
  });

  test('a stale hold never turns a later tap into a discard', () {
    final guard = VoiceGestureGuard();
    guard.longPressStarted();
    guard.reset(); // app paused mid-hold
    expect(guard.shouldDiscardOnCancel(), isFalse);
  });
}
