import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/utils/realtime_message_payload.dart';

void main() {
  group('resolveRealtimeMessageBody', () {
    test('falls back when legacy ciphertext is present but empty', () {
      expect(
        resolveRealtimeMessageBody(
          {'body_payload': null, 'encrypted_payload': null, 'ciphertext': ''},
          fallback: 'original long message',
        ),
        'original long message',
      );
    });

    test('falls back when all payload columns are null or absent', () {
      expect(
        resolveRealtimeMessageBody({'body_payload': null, 'ciphertext': null}, fallback: 'cached text'),
        'cached text',
      );
    });

    test('uses the first non-empty payload column', () {
      expect(
        resolveRealtimeMessageBody(
          {'body_payload': null, 'encrypted_payload': 'current payload', 'ciphertext': 'legacy'},
          fallback: 'cached text',
        ),
        'current payload',
      );
    });

    test('prefers body_payload when present', () {
      expect(
        resolveRealtimeMessageBody(
          {'body_payload': 'new body', 'encrypted_payload': 'older body'},
          fallback: 'cached text',
        ),
        'new body',
      );
    });
  });
}
