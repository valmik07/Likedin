import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/utils/receipt_reconciliation.dart';

void main() {
  group('acknowledgePendingReceiptPasses', () {
    test('takes a new snapshot when a message arrives during the RPC', () async {
      final pending = <String>{'message-1'};
      final locallyAcknowledged = <String>{};
      var serverCalls = 0;

      final passes = await acknowledgePendingReceiptPasses(
        pendingIds: () => Set<String>.of(pending),
        acknowledgeOnServer: () async {
          serverCalls++;
          if (serverCalls == 1) pending.add('message-2');
        },
        applyLocally: (ids) {
          locallyAcknowledged.addAll(ids);
          pending.removeAll(ids);
        },
      );

      expect(passes, 2);
      expect(serverCalls, 2);
      expect(locallyAcknowledged, {'message-1', 'message-2'});
      expect(pending, isEmpty);
    });

    test('stops when there are no pending message IDs', () async {
      var serverCalls = 0;
      final passes = await acknowledgePendingReceiptPasses(
        pendingIds: () => <String>{},
        acknowledgeOnServer: () async { serverCalls++; },
        applyLocally: (_) {},
      );
      expect(passes, 0);
      expect(serverCalls, 0);
    });

    test('respects the configured pass limit', () async {
      final pending = <String>{'message-1'};
      var serverCalls = 0;
      final passes = await acknowledgePendingReceiptPasses(
        pendingIds: () => Set<String>.of(pending),
        acknowledgeOnServer: () async {
          serverCalls++;
          pending.add('message-${serverCalls + 1}');
        },
        applyLocally: (ids) => pending.removeAll(ids),
        maxPasses: 2,
      );
      expect(passes, 2);
      expect(serverCalls, 2);
      expect(pending, {'message-3'});
    });
  });
}
