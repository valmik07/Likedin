import 'dart:convert';
import 'dart:isolate';
import 'dart:math';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';

/// Password-encrypted backup container using PBKDF2-HMAC-SHA256 + AES-256-GCM.
/// The passphrase is never stored by this class. Keep KDF parameters versioned.
class EncryptedBackupCodec {
  static const _format = 'whisper-encrypted-backup';
  static const _version = 1;
  static const _iterations = 310000;

  Future<Uint8List> encrypt(String plaintextJson, String passphrase) async {
    _validatePassphrase(passphrase);
    return Isolate.run(() => _encryptSync(plaintextJson, passphrase));
  }

  Future<String> decrypt(Uint8List backupBytes, String passphrase) async {
    _validatePassphrase(passphrase);
    return Isolate.run(() => _decryptSync(backupBytes, passphrase));
  }

  static Future<Uint8List> _encryptSync(String plaintextJson, String passphrase) async {
    final cipher = AesGcm.with256bits();
    final kdf = Pbkdf2(
      macAlgorithm: Hmac.sha256(),
      iterations: _iterations,
      bits: 256,
    );
    final random = Random.secure();
    final salt = List<int>.generate(16, (_) => random.nextInt(256));
    final nonce = cipher.newNonce();
    final key = await kdf.deriveKey(
      secretKey: SecretKey(utf8.encode(passphrase)),
      nonce: salt,
    );
    final box = await cipher.encrypt(
      utf8.encode(plaintextJson),
      secretKey: key,
      nonce: nonce,
    );

    final envelope = {
      'format': _format,
      'version': _version,
      'kdf': 'PBKDF2-HMAC-SHA256',
      'iterations': _iterations,
      'cipher': 'AES-256-GCM',
      'salt': base64Encode(salt),
      'nonce': base64Encode(box.nonce),
      'ciphertext': base64Encode(box.cipherText),
      'mac': base64Encode(box.mac.bytes),
    };
    return Uint8List.fromList(utf8.encode(jsonEncode(envelope)));
  }

  static Future<String> _decryptSync(Uint8List backupBytes, String passphrase) async {
    final cipher = AesGcm.with256bits();
    final kdf = Pbkdf2(
      macAlgorithm: Hmac.sha256(),
      iterations: _iterations,
      bits: 256,
    );
    final envelope = jsonDecode(utf8.decode(backupBytes)) as Map<String, dynamic>;
    if (envelope['format'] != _format || envelope['version'] != _version) {
      throw const FormatException('Unsupported backup format.');
    }
    if (envelope['kdf'] != 'PBKDF2-HMAC-SHA256' ||
        envelope['cipher'] != 'AES-256-GCM' ||
        envelope['iterations'] != _iterations) {
      throw const FormatException('Unsupported backup security parameters.');
    }

    final salt = base64Decode(envelope['salt'] as String);
    final nonce = base64Decode(envelope['nonce'] as String);
    final key = await kdf.deriveKey(
      secretKey: SecretKey(utf8.encode(passphrase)),
      nonce: salt,
    );
    final box = SecretBox(
      base64Decode(envelope['ciphertext'] as String),
      nonce: nonce,
      mac: Mac(base64Decode(envelope['mac'] as String)),
    );
    final clearBytes = await cipher.decrypt(box, secretKey: key);
    return utf8.decode(clearBytes);
  }

  void _validatePassphrase(String passphrase) {
    if (passphrase.length < 12) {
      throw ArgumentError('Backup passphrase must be at least 12 characters.');
    }
  }
}
