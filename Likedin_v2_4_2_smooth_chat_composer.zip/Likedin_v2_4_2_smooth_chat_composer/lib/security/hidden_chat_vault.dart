import 'dart:convert';
import 'dart:math';

import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Device-local hidden-conversation metadata and password verifier.
///
/// No message rows, delivery state, or backend records are modified. Metadata
/// and the salted PBKDF2 verifier are stored through Android Keystore-backed
/// flutter_secure_storage. The preference flag is used only to redact message
/// notification text in the background isolate; it is not an access-control
/// source of truth.
class HiddenChatVault {
  HiddenChatVault({FlutterSecureStorage? storage})
      : _storage = storage ?? const FlutterSecureStorage();

  static const int passwordIterations = 120000;
  static const String notificationRedactionPreference =
      'likedin_hidden_chat_notification_redaction_v1';
  static const String _keyPrefix = 'likedin.hidden_chat.v1.';
  final FlutterSecureStorage _storage;
  final Pbkdf2 _kdf = Pbkdf2(
    macAlgorithm: Hmac.sha256(),
    iterations: passwordIterations,
    bits: 256,
  );

  String _hiddenKey(String uid) => '${_keyPrefix}hidden.$uid';
  String _passwordKey(String uid) => '${_keyPrefix}password.$uid';

  Future<bool> hasPassword(String uid) async {
    _validateUid(uid);
    final raw = await _storage.read(key: _passwordKey(uid));
    return raw != null && raw.isNotEmpty;
  }

  Future<bool> hasHiddenChats(String uid) async =>
      (await listHiddenChatIds(uid)).isNotEmpty;

  Future<Set<String>> listHiddenChatIds(String uid) async {
    _validateUid(uid);
    final raw = await _storage.read(key: _hiddenKey(uid));
    if (raw == null || raw.isEmpty) return <String>{};
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) {
        throw const FormatException('Hidden-chat metadata is not a list.');
      }
      return decoded
          .map((value) => value.toString())
          .where((value) => value.isNotEmpty)
          .toSet();
    } on FormatException {
      // Corrupt metadata must not silently make a hidden conversation visible.
      rethrow;
    }
  }

  Future<bool> isHidden(String uid, String peerId) async =>
      (await listHiddenChatIds(uid)).contains(peerId);

  Future<void> configurePassword(String uid, String password) async {
    _validateUid(uid);
    if (password.length < 8) {
      throw ArgumentError.value(password.length, 'password.length',
          'Hidden-chat password must contain at least 8 characters.');
    }
    final salt = List<int>.generate(
      16,
      (_) => Random.secure().nextInt(256),
      growable: false,
    );
    final hash = await _derive(password, salt);
    await _storage.write(
      key: _passwordKey(uid),
      value: jsonEncode({
        'version': 1,
        'iterations': passwordIterations,
        'salt': base64Encode(salt),
        'hash': base64Encode(hash),
      }),
    );
  }

  Future<bool> verifyPassword(String uid, String password) async {
    _validateUid(uid);
    final raw = await _storage.read(key: _passwordKey(uid));
    if (raw == null || raw.isEmpty) return false;
    try {
      final record = jsonDecode(raw) as Map<String, dynamic>;
      if (record['version'] != 1) return false;
      final iterations = record['iterations'] as int? ?? passwordIterations;
      if (iterations < 100000 || iterations > 1000000) return false;
      final salt = base64Decode(record['salt'] as String);
      final expected = base64Decode(record['hash'] as String);
      final actual = await _derive(password, salt, iterations: iterations);
      return _constantTimeEquals(actual, expected);
    } catch (_) {
      return false;
    }
  }

  Future<void> setHidden(String uid, String peerId, bool hidden) async {
    _validateUid(uid);
    if (peerId.isEmpty || peerId.length > 128) {
      throw ArgumentError.value(peerId, 'peerId', 'Invalid conversation id.');
    }
    if (hidden && !await hasPassword(uid)) {
      throw StateError('A hidden-chat password must be configured before hiding a conversation.');
    }
    final ids = await listHiddenChatIds(uid);
    if (hidden) {
      ids.add(peerId);
    } else {
      ids.remove(peerId);
    }
    if (ids.isEmpty) {
      await _storage.delete(key: _hiddenKey(uid));
    } else {
      await _storage.write(
        key: _hiddenKey(uid),
        value: jsonEncode(ids.toList()..sort()),
      );
    }
    // Redact incoming message previews while one or more chats are hidden.
    // This preference never decides whether the chat itself is accessible.
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(notificationRedactionPreference, ids.isNotEmpty);
    } catch (_) {
      // Notification redaction is best-effort; the secure metadata remains
      // authoritative and chat access continues to be password-gated.
    }
  }

  Future<List<int>> _derive(
    String password,
    List<int> salt, {
    int iterations = passwordIterations,
  }) async {
    final kdf = iterations == passwordIterations
        ? _kdf
        : Pbkdf2(macAlgorithm: Hmac.sha256(), iterations: iterations, bits: 256);
    final key = await kdf.deriveKey(
      secretKey: SecretKey(utf8.encode(password)),
      nonce: salt,
    );
    return key.extractBytes();
  }

  bool _constantTimeEquals(List<int> a, List<int> b) {
    if (a.length != b.length) return false;
    var difference = 0;
    for (var index = 0; index < a.length; index++) {
      difference |= a[index] ^ b[index];
    }
    return difference == 0;
  }

  void _validateUid(String uid) {
    if (uid.isEmpty || uid.length > 128 ||
        !RegExp(r'^[a-zA-Z0-9_.-]+$').hasMatch(uid)) {
      throw ArgumentError.value(uid, 'uid', 'Invalid account id.');
    }
  }
}
