import 'package:flutter/services.dart';

/// Bridges call ringtone/ringback and synchronized vibration to Android.
class CallAlertController {
  static const MethodChannel _channel = MethodChannel('com.example.likedin/call_alerts');

  static Future<void> startIncoming() async {
    try { await _channel.invokeMethod<void>('startIncoming'); } on PlatformException { /* Device may not support call alerts. */ }
  }

  static Future<void> startOutgoing() async {
    try { await _channel.invokeMethod<void>('startOutgoing'); } on PlatformException { /* Device may not support call alerts. */ }
  }

  static Future<void> stop() async {
    try { await _channel.invokeMethod<void>('stop'); } on PlatformException { /* Best-effort cleanup. */ }
  }

  static Future<void> startCallService({required bool video}) async {
    try {
      await _channel.invokeMethod<void>('startCallService', {'video': video});
    } catch (_) {
      // Keep call setup working on devices that cannot start the service.
    }
  }

  static Future<void> stopCallService() async {
    try {
      await _channel.invokeMethod<void>('stopCallService');
    } catch (_) {
      // Best-effort cleanup.
    }
  }
}
