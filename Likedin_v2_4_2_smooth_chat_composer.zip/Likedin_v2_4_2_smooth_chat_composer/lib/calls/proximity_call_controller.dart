import 'package:flutter/services.dart';

/// Controls Android's native proximity-screen-off wake lock during audio calls.
/// Android's proximity sensor, not a polling loop, decides when the display sleeps.
class ProximityCallController {
  static const MethodChannel _channel = MethodChannel('com.example.likedin/proximity');
  bool _active = false;
  bool _enabled = true;

  Future<void> update({required bool active, required bool enabled}) async {
    _active = active;
    _enabled = enabled;
    try {
      await _channel.invokeMethod<bool>('setAudioCallActive', {
        'active': _active,
        'enabled': _enabled,
      });
    } on PlatformException catch (_) {
      // Calls remain usable if a device/ROM does not support this feature.
    } on MissingPluginException catch (_) {
      // Defensive fallback for non-Android test environments.
    }
  }

  Future<void> dispose() => update(active: false, enabled: false);
}
