import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

class LocalAttachment {
  const LocalAttachment({required this.name, required this.path, required this.sizeBytes, required this.savedAt});
  final String name;
  final String path;
  final int sizeBytes;
  final DateTime savedAt;

  String get readableSize {
    if (sizeBytes < 1024) return '$sizeBytes B';
    if (sizeBytes < 1024 * 1024) return '${(sizeBytes / 1024).toStringAsFixed(1)} KB';
    return '${(sizeBytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
}

/// Keeps user-selected copies in Likedin's private app documents directory.
/// This is a local download vault, not cloud sync or a remote attachment service.
class AttachmentVaultStore {
  static const _folderName = 'Likedin Downloads';
  static const _uuid = Uuid();

  Future<Directory> _directory() async {
    final root = await getApplicationDocumentsDirectory();
    final directory = Directory(p.join(root.path, _folderName));
    if (!await directory.exists()) await directory.create(recursive: true);
    return directory;
  }

  Future<List<LocalAttachment>> list() async {
    final directory = await _directory();
    final entities = await directory.list(followLinks: false).toList();
    final files = <LocalAttachment>[];
    for (final entity in entities.whereType<File>()) {
      final stat = await entity.stat();
      files.add(LocalAttachment(
        name: p.basename(entity.path).split('--').skip(1).join('--'),
        path: entity.path,
        sizeBytes: stat.size,
        savedAt: stat.modified,
      ));
    }
    files.sort((a, b) => b.savedAt.compareTo(a.savedAt));
    return files;
  }

  Future<List<LocalAttachment>> importFiles() async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      withData: false,
      withReadStream: true,
    );
    if (result == null || result.files.isEmpty) return const [];
    final directory = await _directory();
    final saved = <LocalAttachment>[];
    for (final picked in result.files) {
      final safeName = picked.name.replaceAll(RegExp(r'[^A-Za-z0-9._ -]'), '_');
      final destination = File(p.join(directory.path, '${_uuid.v4()}--$safeName'));
      try {
        final sourcePath = picked.path;
        File? source;
        if (sourcePath != null && sourcePath.isNotEmpty && !sourcePath.startsWith('content://')) {
          final candidate = File(sourcePath);
          if (await candidate.exists()) source = candidate;
        }

        if (source != null) {
          await source.copy(destination.path);
        } else {
          // Android document providers may return a content URI (or no path)
          // while still exposing a readable stream through FilePicker.
          final stream = picked.readStream;
          if (stream == null) continue;
          final sink = destination.openWrite();
          try {
            await for (final chunk in stream) {
              sink.add(chunk);
            }
            await sink.flush();
            await sink.close();
          } catch (_) {
            try { await sink.close(); } catch (_) {}
            rethrow;
          }
        }

        final stat = await destination.stat();
        if (stat.size <= 0) {
          await destination.delete();
          continue;
        }
        saved.add(LocalAttachment(
          name: safeName,
          path: destination.path,
          sizeBytes: stat.size,
          savedAt: stat.modified,
        ));
      } catch (_) {
        try { if (await destination.exists()) await destination.delete(); } catch (_) {}
      }
    }
    return saved;
  }

  Future<void> deleteLocal(LocalAttachment attachment) async {
    final file = File(attachment.path);
    if (await file.exists()) await file.delete();
  }
}
