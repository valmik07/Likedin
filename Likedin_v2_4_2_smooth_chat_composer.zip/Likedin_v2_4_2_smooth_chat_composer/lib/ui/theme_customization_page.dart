import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'glassmorphism.dart';

/// App-wide appearance & Liquid Glass customization: Dark/Light mode, all 7
/// unified app themes (applied across Home, Chat, Calls, Files, Profile &
/// Settings), accent colours, live Liquid Glass chat-bubble preview, and
/// performance/motion settings.
class ThemeCustomizationPage extends StatelessWidget {
  const ThemeCustomizationPage({
    required this.themeMode,
    required this.onSetDark,
    super.key,
  });

  final ValueNotifier<ThemeMode> themeMode;
  final Future<void> Function(bool dark) onSetDark;

  Future<void> _reset(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Reset appearance?'),
        content: const Text('This restores the default Liquid Glass theme, accent colour and visual effects.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Reset')),
        ],
      ),
    );
    if (confirmed != true || !context.mounted) return;
    await LikedinAppearance.reset();
    await onSetDark(false);
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Appearance reset to Liquid Glass defaults.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AuroraBackdrop(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          title: const Text('Appearance', style: TextStyle(fontWeight: FontWeight.w800)),
          actions: [
            TextButton(onPressed: () => _reset(context), child: const Text('Reset')),
          ],
        ),
        body: ListenableBuilder(
          listenable: Listenable.merge([themeMode, LikedinAppearance.listenable]),
          builder: (context, _) {
            final brightness = Theme.of(context).brightness;
            final isDark = themeMode.value == ThemeMode.dark;
            final selectedThemeIndex = LikedinAppearance.themeIndex.value;
            return ListView(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 32),
              children: [
                _heading(context, 'Mode'),
                Row(
                  children: [
                    Expanded(
                      child: _ModeCard(
                        title: 'Dark Glass',
                        subtitle: 'Obsidian',
                        dark: true,
                        selected: isDark,
                        onTap: () {
                          HapticFeedback.selectionClick();
                          onSetDark(true);
                        },
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _ModeCard(
                        title: 'Light Glass',
                        subtitle: 'Arctic',
                        dark: false,
                        selected: !isDark,
                        onTap: () {
                          HapticFeedback.selectionClick();
                          onSetDark(false);
                        },
                      ),
                    ),
                  ],
                ),
                _heading(context, 'App theme'),
                GlassPanel(
                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
                  radius: BorderRadius.circular(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 98,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: likedinThemePresets.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 11),
                          itemBuilder: (_, idx) {
                            final preset = likedinThemePresets[idx];
                            final selected = idx == selectedThemeIndex;
                            final previewColors = preset.previewColors(brightness);
                            final orb = preset.primaryOrb(brightness);
                            final accent = likedinAccents[preset.defaultAccentIndex]
                                .forBrightness(brightness);
                            return Semantics(
                              button: true,
                              selected: selected,
                              label: '${preset.name} app theme',
                              child: GestureDetector(
                                onTap: () {
                                  HapticFeedback.selectionClick();
                                  LikedinAppearance.setTheme(idx);
                                },
                                child: Column(
                                  children: [
                                    AnimatedContainer(
                                      duration: LikedinAppearance.motionReduced(context)
                                          ? Duration.zero
                                          : const Duration(milliseconds: 180),
                                      width: 68,
                                      height: 68,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(20),
                                        gradient: LinearGradient(
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                          colors: previewColors,
                                        ),
                                        border: Border.all(
                                          color: selected
                                              ? accent
                                              : (isDark
                                                  ? Colors.white.withValues(alpha: .20)
                                                  : Colors.white.withValues(alpha: .95)),
                                          width: selected ? 2.5 : 1.1,
                                        ),
                                        boxShadow: selected
                                            ? [
                                                BoxShadow(
                                                  color: orb.withValues(alpha: isDark ? .42 : .30),
                                                  blurRadius: 14,
                                                  spreadRadius: -2,
                                                ),
                                              ]
                                            : null,
                                      ),
                                      child: Stack(
                                        children: [
                                          Positioned.fill(
                                            child: ClipRRect(
                                              borderRadius: BorderRadius.circular(18),
                                              child: DecoratedBox(
                                                decoration: BoxDecoration(
                                                  gradient: RadialGradient(
                                                    center: const Alignment(-.5, -.5),
                                                    radius: 0.9,
                                                    colors: [
                                                      orb.withValues(alpha: isDark ? .48 : .38),
                                                      orb.withValues(alpha: 0),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          if (selected)
                                            Center(
                                              child: Container(
                                                width: 28,
                                                height: 28,
                                                decoration: BoxDecoration(
                                                  color: (isDark ? Colors.black : Colors.white)
                                                      .withValues(alpha: .55),
                                                  shape: BoxShape.circle,
                                                ),
                                                child: Icon(Icons.check_rounded, color: accent, size: 18),
                                              ),
                                            ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(height: 6),
                                    Text(
                                      preset.name,
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: selected ? FontWeight.w800 : FontWeight.w500,
                                        color: selected
                                            ? likedinPrimary(brightness)
                                            : likedinOnSurface(brightness),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Applies seamlessly across Home, Chat, Calls, Files, Profile & Settings in both Dark and Light mode.',
                        style: TextStyle(
                          fontSize: 12.5,
                          height: 1.38,
                          color: likedinMutedText(brightness),
                        ),
                      ),
                    ],
                  ),
                ),
                _heading(context, 'Accent colour'),
                GlassPanel(
                  padding: const EdgeInsets.all(16),
                  radius: BorderRadius.circular(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ValueListenableBuilder<int>(
                        valueListenable: LikedinAppearance.accentIndex,
                        builder: (context, selected, _) => Wrap(
                          spacing: 14,
                          runSpacing: 12,
                          children: [
                            for (var i = 0; i < likedinAccents.length; i++)
                              _AccentSwatch(
                                accent: likedinAccents[i],
                                brightness: brightness,
                                selected: i == selected,
                                onTap: () {
                                  HapticFeedback.selectionClick();
                                  LikedinAppearance.setAccent(i);
                                },
                              ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'Mix any accent with your active ${LikedinAppearance.theme.name} theme. Contrast is tuned automatically for both modes.',
                        style: TextStyle(
                          fontSize: 13,
                          height: 1.4,
                          color: likedinMutedText(brightness),
                        ),
                      ),
                    ],
                  ),
                ),
                _heading(context, 'Liquid Glass preview'),
                GlassPanel(
                  padding: const EdgeInsets.all(16),
                  radius: BorderRadius.circular(24),
                  child: Column(
                    children: [
                      _bubble(context, 'Are we still on for tonight?', outgoing: false),
                      _bubble(context, 'Yes, see you at 8.', outgoing: true),
                    ],
                  ),
                ),
                _heading(context, 'Visual effects'),
                GlassPanel(
                  padding: const EdgeInsets.all(16),
                  radius: BorderRadius.circular(24),
                  child: ValueListenableBuilder<LikedinEffects>(
                    valueListenable: LikedinAppearance.effects,
                    builder: (context, effects, _) => Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: double.infinity,
                          child: SegmentedButton<LikedinEffects>(
                            showSelectedIcon: false,
                            segments: const [
                              ButtonSegment(value: LikedinEffects.full, label: Text('Full')),
                              ButtonSegment(value: LikedinEffects.lighter, label: Text('Lighter')),
                              ButtonSegment(value: LikedinEffects.off, label: Text('Off')),
                            ],
                            selected: {effects},
                            onSelectionChanged: (s) => LikedinAppearance.setEffects(s.first),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          switch (effects) {
                            LikedinEffects.full =>
                              'Full iOS-style Liquid Glass: optical backdrop refraction, specular glass rims and ambient orbs.',
                            LikedinEffects.lighter =>
                              'No backdrop blur or shadows. Crystal translucency and specular rims only. Great for 3 GB phones.',
                            LikedinEffects.off =>
                              'Solid surfaces and a flat background. Fastest and highest contrast.',
                          },
                          style: TextStyle(
                            fontSize: 13,
                            height: 1.4,
                            color: likedinMutedText(brightness),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                GlassPanel(
                  radius: BorderRadius.circular(24),
                  child: ValueListenableBuilder<bool>(
                    valueListenable: LikedinAppearance.reduceMotion,
                    builder: (context, reduced, _) => SwitchListTile.adaptive(
                      value: reduced,
                      onChanged: LikedinAppearance.setReduceMotion,
                      title: const Text('Reduce motion'),
                      subtitle: const Text(
                        'Skips the startup animation and call pulse. Your phone’s system setting is also respected.',
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                OutlinedButton.icon(
                  onPressed: () => _reset(context),
                  icon: const Icon(Icons.restart_alt_rounded, size: 19),
                  label: const Text('Reset appearance'),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _heading(BuildContext context, String text) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 22, 4, 10),
        child: Text(
          text,
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: -.4),
        ),
      );

  Widget _bubble(BuildContext context, String text, {required bool outgoing}) {
    final brightness = Theme.of(context).brightness;
    return Align(
      alignment: outgoing ? Alignment.centerRight : Alignment.centerLeft,
      child: LiquidGlassBubble(
        outgoing: outgoing,
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
        maxWidth: 260,
        borderRadius: BorderRadius.only(
          topLeft: const Radius.circular(20),
          topRight: const Radius.circular(20),
          bottomLeft: Radius.circular(outgoing ? 20 : 6),
          bottomRight: Radius.circular(outgoing ? 6 : 20),
        ),
        child: Text(
          text,
          style: TextStyle(color: likedinOnSurface(brightness), fontSize: 15),
        ),
      ),
    );
  }
}

/// Live preview of Dark vs Light mode using the currently active app theme.
class _ModeCard extends StatelessWidget {
  const _ModeCard({
    required this.title,
    required this.subtitle,
    required this.dark,
    required this.selected,
    required this.onTap,
  });

  final String title;
  final String subtitle;
  final bool dark;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final b = dark ? Brightness.dark : Brightness.light;
    final current = Theme.of(context).brightness;
    final primary = likedinPrimary(b);
    final preset = LikedinAppearance.theme;
    final orb = preset.primaryOrb(b);
    return Semantics(
      button: true,
      selected: selected,
      label: '$title mode',
      child: GestureDetector(
        onTap: onTap,
        child: GlassPanel(
          radius: BorderRadius.circular(24),
          glow: selected,
          padding: const EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Container(
                  height: 128,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: preset.previewColors(b),
                    ),
                  ),
                  child: Stack(
                    children: [
                      Positioned.fill(
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            gradient: RadialGradient(
                              center: const Alignment(-.6, -.6),
                              radius: 1.0,
                              colors: [
                                orb.withValues(alpha: dark ? .36 : .28),
                                orb.withValues(alpha: 0),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              height: 22,
                              decoration: BoxDecoration(
                                color: likedinSurface(b).withValues(alpha: dark ? .36 : .58),
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                  color: Colors.white.withValues(alpha: dark ? .30 : .92),
                                ),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Container(
                                width: 72,
                                height: 18,
                                decoration: BoxDecoration(
                                  color: likedinIncomingBubble(b),
                                  borderRadius: BorderRadius.circular(9),
                                  border: Border.all(
                                    color: Colors.white.withValues(alpha: dark ? .24 : .90),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 6),
                            Align(
                              alignment: Alignment.centerRight,
                              child: Container(
                                width: 58,
                                height: 18,
                                decoration: BoxDecoration(
                                  color: likedinOutgoingBubble(b).withValues(alpha: .76),
                                  borderRadius: BorderRadius.circular(9),
                                  border: Border.all(color: primary.withValues(alpha: .55)),
                                ),
                              ),
                            ),
                            const Spacer(),
                            Container(
                              height: 22,
                              decoration: BoxDecoration(
                                gradient: likedinPrimaryGradient(b),
                                borderRadius: BorderRadius.circular(11),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                            color: likedinOnSurface(current),
                          ),
                        ),
                        Text(
                          subtitle,
                          style: TextStyle(fontSize: 12, color: likedinMutedText(current)),
                        ),
                      ],
                    ),
                  ),
                  if (selected) Icon(Icons.check_circle_rounded, color: likedinPrimary(current), size: 22),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AccentSwatch extends StatelessWidget {
  const _AccentSwatch({
    required this.accent,
    required this.brightness,
    required this.selected,
    required this.onTap,
  });

  final LikedinAccent accent;
  final Brightness brightness;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = accent.forBrightness(brightness);
    return Semantics(
      button: true,
      selected: selected,
      label: '${accent.name} accent',
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: 46,
          height: 46,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [color, accent.gradientEnd],
            ),
            border: Border.all(
              color: selected ? likedinOnSurface(brightness) : Colors.transparent,
              width: 2.5,
            ),
          ),
          child: selected
              ? Icon(
                  Icons.check_rounded,
                  color: color.computeLuminance() > .4 ? const Color(0xFF04122B) : Colors.white,
                  size: 22,
                )
              : null,
        ),
      ),
    );
  }
}
