import 'dart:convert';

import '../backend/realtime_messaging_service.dart';

/// The media categories exposed by the conversation search UI.
enum MessageMediaFilter { all, photos, videos, audio, files }

/// A local, privacy-preserving filter for messages already loaded in memory.
///
/// Search deliberately does not issue a server-side body query: message bodies
/// may contain structured private attachment metadata, and older messages are
/// brought into memory through the app's existing keyset pagination flow.
class MessageSearchFilter {
  const MessageSearchFilter({
    this.query = '',
    this.media = MessageMediaFilter.all,
    this.fromDate,
    this.toDate,
  });

  final String query;
  final MessageMediaFilter media;
  final DateTime? fromDate;
  final DateTime? toDate;

  bool get isActive =>
      query.trim().isNotEmpty ||
      media != MessageMediaFilter.all ||
      fromDate != null ||
      toDate != null;

  bool matches(RemoteMessage message) {
    final localDate = message.createdAt.toLocal();
    if (fromDate != null) {
      final start = DateTime(fromDate!.year, fromDate!.month, fromDate!.day);
      if (localDate.isBefore(start)) return false;
    }
    if (toDate != null) {
      final endExclusive = DateTime(toDate!.year, toDate!.month, toDate!.day + 1);
      if (!localDate.isBefore(endExclusive)) return false;
    }

    final payload = message.deletedForEveryoneAt == null
        ? _mediaPayload(message.text)
        : null;
    if (media != MessageMediaFilter.all) {
      final kind = payload?['kind']?.toString().toLowerCase();
      final mediaMatches = switch (media) {
        MessageMediaFilter.all => true,
        MessageMediaFilter.photos => kind == 'image',
        MessageMediaFilter.videos => kind == 'video',
        MessageMediaFilter.audio => kind == 'audio',
        MessageMediaFilter.files => kind == 'file',
      };
      if (!mediaMatches) return false;
    }

    final normalizedQuery = query.trim().toLowerCase();
    if (normalizedQuery.isEmpty) return true;

    final searchableText = message.deletedForEveryoneAt != null
        ? 'this message was deleted'
        : payload == null
            ? message.text
            : '${_mediaLabel(payload['kind']?.toString())} '
                '${payload['name']?.toString() ?? 'Attachment'}';
    return searchableText.toLowerCase().contains(normalizedQuery);
  }

  static Map<String, dynamic>? _mediaPayload(String value) {
    try {
      final decoded = jsonDecode(value);
      if (decoded is Map && decoded['__likedin_media_v1'] == true) {
        return Map<String, dynamic>.from(decoded);
      }
    } catch (_) {
      // Ordinary text messages are not JSON media payloads.
    }
    return null;
  }

  static String _mediaLabel(String? kind) => switch (kind?.toLowerCase()) {
        'image' => 'photo image',
        'video' => 'video',
        'audio' => 'audio voice message',
        _ => 'file attachment',
      };
}
