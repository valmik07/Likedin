import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../backend/shared_media_service.dart';
import '../data/attachment_vault_store.dart';
import 'glassmorphism.dart';

enum _Kind { images, videos, gifs, documents, audio }

class _Bucket {
  int count = 0;
  int bytes = 0;
}

class _QueueItem {
  const _QueueItem({
    required this.name,
    required this.attempts,
    required this.nextAttemptAt,
  });
  final String name;
  final int attempts;
  final DateTime? nextAttemptAt;
}

class _Snapshot {
  _Snapshot({
    required this.saved,
    required this.cache,
    required this.temp,
    required this.pending,
    required this.queue,
  });
  final Map<_Kind, _Bucket> saved;
  final _Bucket cache; // re-downloadable media cache
  final _Bucket temp; // temporary files (older than the safety window)
  final _Bucket pending; // files waiting in the upload queue
  final List<_QueueItem> queue;

  int get savedBytes => saved.values.fold(0, (a, b) => a + b.bytes);
  int get savedCount => saved.values.fold(0, (a, b) => a + b.count);
  int get totalBytes => savedBytes + cache.bytes + temp.bytes + pending.bytes;
}

/// Storage dashboard (spec screen 14). It separates three kinds of data:
///  * your saved media (never touched by cleanup),
///  * cached/temporary data (safe to rebuild),
///  * the upload queue (shown with retry, never deleted here).
/// Every cleanup states what will be removed and asks for confirmation first.
class StoragePage extends StatefulWidget {
  const StoragePage({required this.store, super.key});
  final AttachmentVaultStore store;

  static const String cacheLimitMbPrefKey = 'likedin_media_cache_limit_mb_v1';
  static const int defaultCacheLimitMb = 300;
  static const List<int> cacheLimitOptionsMb = <int>[150, 300, 500, 1024, 0];

  /// Enforces the user's media cache cap by removing the oldest cached files
  /// in LikedinMediaCache (never touching files younger than 10 minutes or
  /// files explicitly saved by the user). Returns the number of evicted files.
  static Future<int> enforceCacheQuota({int? limitMbOverride}) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final limitMb = limitMbOverride ?? prefs.getInt(cacheLimitMbPrefKey) ?? defaultCacheLimitMb;
      if (limitMb <= 0) return 0; // 0 = Unlimited
      final maxBytes = limitMb * 1024 * 1024;
      final support = await getApplicationSupportDirectory();
      final cacheDir = Directory(p.join(support.path, 'LikedinMediaCache'));
      if (!await cacheDir.exists()) return 0;

      final entries = <({File file, int size, DateTime modified})>[];
      var totalBytes = 0;
      await for (final entity in cacheDir.list(recursive: true, followLinks: false)) {
        if (entity is! File) continue;
        try {
          final stat = await entity.stat();
          totalBytes += stat.size;
          entries.add((file: entity, size: stat.size, modified: stat.modified));
        } catch (_) {}
      }
      if (totalBytes <= maxBytes) return 0;

      // Evict oldest files first until under 90% of the cap so we don't churn.
      entries.sort((a, b) => a.modified.compareTo(b.modified));
      final targetBytes = (maxBytes * 0.90).round();
      final cutoff = DateTime.now().subtract(const Duration(minutes: 10));
      var removed = 0;
      for (final entry in entries) {
        if (totalBytes <= targetBytes) break;
        if (entry.modified.isAfter(cutoff)) continue;
        try {
          await entry.file.delete();
          totalBytes -= entry.size;
          removed++;
        } catch (_) {}
      }
      return removed;
    } catch (error) {
      debugPrint('Media cache quota enforcement skipped: $error');
      return 0;
    }
  }

  @override
  State<StoragePage> createState() => _StoragePageState();
}

class _StoragePageState extends State<StoragePage> {
  // Files younger than this are skipped so in-flight work is never disturbed.
  static const _safetyWindow = Duration(minutes: 10);
  // Mirrors SharedMediaService's private queue key prefix.
  static const _queueKeyPrefix = 'likedin_media_retry_queue_v2';

  // Retain the most recent successful read while a refresh is pending or fails.
  _Snapshot? _lastSnapshot;
  late Future<_Snapshot> _snapshot = _load();
  String? _busy; // label of the long-running operation, if any
  bool _retrying = false;
  int _cacheLimitMb = StoragePage.defaultCacheLimitMb;

  @override
  void initState() {
    super.initState();
    unawaited(_loadCacheLimit());
  }

  Future<void> _loadCacheLimit() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getInt(StoragePage.cacheLimitMbPrefKey) ?? StoragePage.defaultCacheLimitMb;
      if (mounted) setState(() => _cacheLimitMb = saved);
    } catch (_) {}
  }

  Future<void> _setCacheLimitMb(int limitMb) async {
    if (_busy != null) return;
    setState(() {
      _cacheLimitMb = limitMb;
      _busy = limitMb > 0 ? 'Applying cache limit…' : null;
    });
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(StoragePage.cacheLimitMbPrefKey, limitMb);
      final removed = limitMb > 0 ? await StoragePage.enforceCacheQuota(limitMbOverride: limitMb) : 0;
      if (!mounted) return;
      setState(() {
        _busy = null;
        _snapshot = _load();
      });
      if (removed > 0) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Trimmed $removed old cached ${removed == 1 ? 'file' : 'files'} to stay under ${_cacheLimitLabel(limitMb)}.')),
        );
      }
    } catch (_) {
      if (mounted) setState(() => _busy = null);
    }
  }

  static String _cacheLimitLabel(int mb) {
    if (mb <= 0) return 'Unlimited';
    if (mb >= 1024) return '${mb ~/ 1024} GB';
    return '$mb MB';
  }

  Widget _cacheQuotaCard(BuildContext context, _Snapshot data, bool busy) {
    final brightness = Theme.of(context).brightness;
    final primary = likedinPrimary(brightness);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GlassPanel(
        radius: BorderRadius.circular(20),
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.auto_delete_outlined, color: primary, size: 21),
                const SizedBox(width: 10),
                const Expanded(
                  child: Text(
                    'Auto-trim media cache',
                    style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                  ),
                ),
                Text(
                  _cacheLimitLabel(_cacheLimitMb),
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: primary),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              'Automatically removes the oldest cached chat media when the cache grows past this limit. Saved files are never touched.',
              style: TextStyle(fontSize: 12, color: likedinMutedText(brightness), height: 1.35),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 6,
              children: StoragePage.cacheLimitOptionsMb.map((mb) {
                final selected = _cacheLimitMb == mb;
                return ChoiceChip(
                  label: Text(_cacheLimitLabel(mb)),
                  selected: selected,
                  onSelected: busy ? null : (_) => unawaited(_setCacheLimitMb(mb)),
                  visualDensity: VisualDensity.compact,
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Future<_Snapshot> _load() async {
    final saved = {for (final k in _Kind.values) k: _Bucket()};
    try {
      for (final file in await widget.store.list()) {
        final bucket = saved[_classify(file.name)]!;
        bucket.count++;
        bucket.bytes += file.sizeBytes;
      }
    } catch (_) {}

    final support = await getApplicationSupportDirectory();
    final temp = await getTemporaryDirectory();
    final cache = await _measure(Directory(p.join(support.path, 'LikedinMediaCache')));
    final pending = await _measure(Directory(p.join(support.path, 'LikedinPendingMedia')));
    final tempBucket = await _measure(temp, olderThan: _safetyWindow, ownedTemporaryOnly: true);

    final queue = <_QueueItem>[];
    try {
      final uid = Supabase.instance.client.auth.currentUser?.id;
      if (uid != null) {
        final prefs = await SharedPreferences.getInstance();
        final raw = prefs.getString('$_queueKeyPrefix:$uid');
        if (raw != null && raw.isNotEmpty) {
          final decoded = jsonDecode(raw);
          if (decoded is List) {
            for (final item in decoded.whereType<Map>()) {
              queue.add(_QueueItem(
                name: (item['displayName'] ?? item['originalName'] ?? 'Attachment').toString(),
                attempts: (item['attempts'] as num?)?.toInt() ?? 0,
                nextAttemptAt: DateTime.tryParse(item['nextAttemptAt']?.toString() ?? '')?.toLocal(),
              ));
            }
          }
        }
      }
    } catch (_) {}

    final snapshot = _Snapshot(saved: saved, cache: cache, temp: tempBucket, pending: pending, queue: queue);
    _lastSnapshot = snapshot;
    return snapshot;
  }

  static _Kind _classify(String name) {
    final lower = name.toLowerCase();
    final ext = p.extension(lower).replaceFirst('.', '');
    if (ext == 'gif') return _Kind.gifs;
    if (const {'jpg', 'jpeg', 'png', 'webp', 'heic', 'heif', 'bmp'}.contains(ext)) return _Kind.images;
    if (const {'mp4', 'mov', 'webm', '3gp', 'mkv', 'm4v'}.contains(ext)) return _Kind.videos;
    if (const {'m4a', 'aac', 'mp3', 'wav', 'ogg', 'opus'}.contains(ext)) return _Kind.audio;
    return _Kind.documents;
  }

  static bool _isOwnedDisposableTemporary(String path) {
    final name = p.basename(path).toLowerCase();
    // Camera recovery and active voice-recording files are intentionally not
    // on this allowlist and can never be removed by the cleanup action.
    return name.startsWith('likedin_gif_') ||
        name.startsWith('likedin_thumb_') ||
        name.startsWith('likedin_download_');
  }

  static Future<_Bucket> _measure(Directory dir, {Duration? olderThan, bool ownedTemporaryOnly = false}) async {
    final bucket = _Bucket();
    try {
      if (!await dir.exists()) return bucket;
      await for (final entity in dir.list(recursive: true, followLinks: false)) {
        if (entity is! File) continue;
        if (ownedTemporaryOnly && !_isOwnedDisposableTemporary(entity.path)) continue;
        try {
          final stat = await entity.stat();
          if (olderThan != null && DateTime.now().difference(stat.modified) < olderThan) continue;
          bucket.count++;
          bucket.bytes += stat.size;
        } catch (_) {}
      }
    } catch (_) {}
    return bucket;
  }

  static Future<int> _deleteFiles(Directory dir, {bool respectWindow = true, bool ownedTemporaryOnly = false}) async {
    var removed = 0;
    try {
      if (!await dir.exists()) return 0;
      final entities = await dir.list(recursive: true, followLinks: false).toList();
      for (final entity in entities) {
        if (entity is! File) continue;
        if (ownedTemporaryOnly && !_isOwnedDisposableTemporary(entity.path)) continue;
        try {
          final stat = await entity.stat();
          final recent = DateTime.now().difference(stat.modified) < _safetyWindow;
          if (respectWindow && recent) continue;
          await entity.delete();
          removed++;
        } catch (_) {}
      }
    } catch (_) {}
    return removed;
  }

  static String _formatBytes(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }

  Future<bool> _confirm({
    required String title,
    required String body,
    required String action,
  }) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(title),
        content: Text(body),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: Text(action),
          ),
        ],
      ),
    );
    return result == true;
  }

  void _toast(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  void _refresh() {
    setState(() => _snapshot = _load());
  }

  Future<void> _clearTemporary(_Snapshot data) async {
    final ok = await _confirm(
      title: 'Clear temporary files?',
      body: data.temp.count == 0
          ? 'There are no temporary files older than 10 minutes. Previews held in memory will still be released.'
          : 'This removes ${data.temp.count} temporary '
              '${data.temp.count == 1 ? 'file' : 'files'} (${_formatBytes(data.temp.bytes)}), such as '
              'previews and compression leftovers. Your messages, saved files and queued uploads are not affected.',
      action: 'Clear',
    );
    if (!ok || !mounted) return;
    setState(() => _busy = 'Clearing temporary files…');
    final temp = await getTemporaryDirectory();
    final removed = await _deleteFiles(temp, ownedTemporaryOnly: true);
    PaintingBinding.instance.imageCache
      ..clear()
      ..clearLiveImages();
    if (!mounted) return;
    setState(() => _busy = null);
    _toast('Removed $removed temporary ${removed == 1 ? 'file' : 'files'}.');
    _refresh();
  }

  Future<void> _clearMediaCache(_Snapshot data) async {
    final ok = await _confirm(
      title: 'Clear downloaded media cache?',
      body: data.cache.count == 0
          ? 'No downloaded media is cached on this phone.'
          : 'This removes ${data.cache.count} cached '
              '${data.cache.count == 1 ? 'file' : 'files'} (${_formatBytes(data.cache.bytes)}) of photos, videos '
              'and voice messages from chats. They download again when you open them, but anything already '
              'removed from the cloud will no longer be available. Files you saved in the Files tab are not affected.',
      action: 'Clear media cache',
    );
    if (!ok || !mounted) return;
    setState(() => _busy = 'Clearing downloaded media…');
    final support = await getApplicationSupportDirectory();
    final removed = await _deleteFiles(Directory(p.join(support.path, 'LikedinMediaCache')));
    SharedMediaService.clearMemoryCaches();
    PaintingBinding.instance.imageCache
      ..clear()
      ..clearLiveImages();
    if (!mounted) return;
    setState(() => _busy = null);
    _toast('Removed $removed cached ${removed == 1 ? 'file' : 'files'}.');
    _refresh();
  }

  Future<void> _retryUploads() async {
    if (_retrying) return;
    setState(() => _retrying = true);
    String message;
    try {
      final done = await SharedMediaService.processRetryQueue(Supabase.instance.client);
      message = done
          ? 'Queued uploads were sent.'
          : (SharedMediaService.lastQueueError ?? 'Some uploads are still waiting. They will retry automatically.');
    } catch (error) {
      debugPrint('Queued upload retry failed: $error');
      message = 'Could not finish retrying uploads. Your files remain queued for another attempt.';
    }
    if (!mounted) return;
    setState(() => _retrying = false);
    _toast(message);
    _refresh();
  }

  List<Color> _palette(Brightness b) => b == Brightness.dark
      ? const [
          Color(0xFF6FA8FF), Color(0xFF3DD6F5), Color(0xFFB39DFF),
          Color(0xFFFFB86B), Color(0xFF4FDBA5), Color(0xFFFF8FB1),
        ]
      : const [
          Color(0xFF0A5FD0), Color(0xFF00758F), Color(0xFF5B3FD6),
          Color(0xFFB45309), Color(0xFF0B7A55), Color(0xFFC2255C),
        ];

  static const _kindMeta = <_Kind, (String, IconData)>{
    _Kind.images: ('Images', Icons.image_outlined),
    _Kind.videos: ('Videos', Icons.videocam_outlined),
    _Kind.gifs: ('GIFs', Icons.gif_box_outlined),
    _Kind.documents: ('Documents', Icons.description_outlined),
    _Kind.audio: ('Audio', Icons.mic_none_rounded),
  };

  Widget _section(BuildContext context, String title, {String? helper}) {
    final muted = likedinMutedText(Theme.of(context).brightness);
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 24, 4, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: -.4),
          ),
          if (helper != null) ...[
            const SizedBox(height: 4),
            Text(helper, style: TextStyle(fontSize: 13, height: 1.35, color: muted)),
          ],
        ],
      ),
    );
  }

  Widget _summary(BuildContext context, _Snapshot data) {
    final brightness = Theme.of(context).brightness;
    final muted = likedinMutedText(brightness);
    final colors = _palette(brightness);
    final segments = <(Color, int)>[
      for (var i = 0; i < _Kind.values.length; i++)
        (colors[i], data.saved[_Kind.values[i]]!.bytes),
      (likedinOutline(brightness), data.cache.bytes + data.temp.bytes + data.pending.bytes),
    ].where((s) => s.$2 > 0).toList();
    final total = data.totalBytes;
    return GlassPanel(
      padding: const EdgeInsets.all(18),
      radius: BorderRadius.circular(24),
      glow: true,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Used on this phone', style: TextStyle(fontSize: 13, color: muted)),
          const SizedBox(height: 4),
          Text(
            _formatBytes(total),
            style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800, letterSpacing: -1),
          ),
          const SizedBox(height: 14),
          Semantics(
            label: 'Storage breakdown bar',
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: SizedBox(
                height: 10,
                child: total == 0
                    ? ColoredBox(color: likedinSurfaceRaised(brightness))
                    : Row(
                        children: [
                          for (final s in segments)
                            Expanded(flex: s.$2.clamp(1, 1 << 30).toInt(), child: ColoredBox(color: s.$1)),
                        ],
                      ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            '${_formatBytes(data.savedBytes)} saved by you  ·  '
            '${_formatBytes(data.cache.bytes + data.temp.bytes)} cache and temporary files',
            style: TextStyle(fontSize: 13, height: 1.4, color: muted),
          ),
        ],
      ),
    );
  }

  Widget _categoryRow(BuildContext context, _Kind kind, _Bucket bucket, Color color) {
    final meta = _kindMeta[kind]!;
    final muted = likedinMutedText(Theme.of(context).brightness);
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: GlassPanel(
        radius: BorderRadius.circular(18),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: color.withValues(alpha: .16),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(meta.$2, color: color, size: 21),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(meta.$1, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                  Text(
                    '${bucket.count} ${bucket.count == 1 ? 'file' : 'files'}',
                    style: TextStyle(fontSize: 12, color: muted),
                  ),
                ],
              ),
            ),
            Text(_formatBytes(bucket.bytes), style: const TextStyle(fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }

  Widget _cleanupCard(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String description,
    required String sizeLabel,
    required String actionLabel,
    required VoidCallback? onPressed,
  }) {
    final muted = likedinMutedText(Theme.of(context).brightness);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GlassPanel(
        radius: BorderRadius.circular(20),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: likedinPrimary(Theme.of(context).brightness).withValues(alpha: .15),
                    borderRadius: BorderRadius.circular(11),
                  ),
                  child: Icon(icon, color: likedinPrimary(Theme.of(context).brightness), size: 19),
                ),
                const SizedBox(width: 10),
                Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15))),
                Text(sizeLabel, style: const TextStyle(fontWeight: FontWeight.w700)),
              ],
            ),
            const SizedBox(height: 6),
            Text(description, style: TextStyle(fontSize: 13, height: 1.4, color: muted)),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(onPressed: onPressed, child: Text(actionLabel)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _queueSection(BuildContext context, _Snapshot data) {
    final brightness = Theme.of(context).brightness;
    final muted = likedinMutedText(brightness);
    if (data.queue.isEmpty) {
      return GlassPanel(
        radius: BorderRadius.circular(20),
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: const Color(0xFF2FBF86).withValues(alpha: .15),
                borderRadius: BorderRadius.circular(11),
              ),
              child: const Icon(Icons.cloud_done_outlined, color: Color(0xFF2FBF86), size: 19),
            ),
            const SizedBox(width: 12),
            const Expanded(child: Text('No uploads are waiting. Everything has been sent.')),
          ],
        ),
      );
    }
    return GlassPanel(
      radius: BorderRadius.circular(20),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (final item in data.queue)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Row(
                children: [
                  Icon(
                    item.attempts > 0 ? Icons.error_outline_rounded : Icons.schedule_rounded,
                    color: item.attempts > 0 ? const Color(0xFFE5484D) : muted,
                    size: 20,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w600)),
                        Text(
                          item.attempts > 0
                              ? 'Failed ${item.attempts} ${item.attempts == 1 ? 'time' : 'times'}; will retry automatically'
                              : 'Waiting to upload',
                          style: TextStyle(fontSize: 12, color: muted),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          if (_retrying) ...[
            const LinearProgressIndicator(minHeight: 3),
            const SizedBox(height: 10),
          ],
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: _retrying ? null : _retryUploads,
              icon: const Icon(Icons.refresh_rounded, size: 18),
              label: Text(_retrying ? 'Retrying…' : 'Retry now'),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Queued files are kept safely on this phone and are never removed by cleanup.',
            style: TextStyle(fontSize: 12, color: muted),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final colors = _palette(brightness);
    return AuroraBackdrop(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          title: const Text('Storage and media', style: TextStyle(fontWeight: FontWeight.w800)),
          actions: [
            IconButton(
              tooltip: 'Refresh',
              onPressed: _busy == null ? _refresh : null,
              icon: const Icon(Icons.refresh_rounded),
            ),
          ],
          bottom: _busy == null
              ? null
              : const PreferredSize(
                  preferredSize: Size.fromHeight(3),
                  child: LinearProgressIndicator(minHeight: 3),
                ),
        ),
        body: FutureBuilder<_Snapshot>(
          future: _snapshot,
          builder: (context, snapshot) {
            final data = snapshot.data ?? _lastSnapshot;
            if (data == null && snapshot.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (data == null) {
              return const Center(child: Text('Could not read storage information.'));
            }
            final busy = _busy != null;
            return RefreshIndicator(
              onRefresh: () async {
                _refresh();
                try { await _snapshot; } catch (error) {
                  debugPrint('Storage refresh failed: $error');
                }
              },
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 48),
                children: [
                  if (_busy != null)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Text(_busy!, style: TextStyle(color: likedinMutedText(brightness))),
                    ),
                  _summary(context, data),
                  _section(
                    context,
                    'Saved by you',
                    helper: 'Files you chose to keep on this phone. Cleanup never removes these; '
                        'delete them individually from the Files tab.',
                  ),
                  for (var i = 0; i < _Kind.values.length; i++)
                    _categoryRow(context, _Kind.values[i], data.saved[_Kind.values[i]]!, colors[i]),
                  _section(
                    context,
                    'Cache and cleanup',
                    helper: 'Data Likedin can rebuild. Each action tells you what is removed before it runs.',
                  ),
                  _cacheQuotaCard(context, data, busy),
                  _cleanupCard(
                    context,
                    icon: Icons.photo_library_outlined,
                    title: 'Downloaded chat media',
                    description:
                        'Photos, videos and voice messages from chats that were downloaded to open faster.',
                    sizeLabel: _formatBytes(data.cache.bytes),
                    actionLabel: 'Clear media cache',
                    onPressed: busy ? null : () => _clearMediaCache(data),
                  ),
                  _cleanupCard(
                    context,
                    icon: Icons.cleaning_services_outlined,
                    title: 'Temporary files',
                    description:
                        'Previews and leftovers from sending or opening media. Recent files are left alone.',
                    sizeLabel: _formatBytes(data.temp.bytes),
                    actionLabel: 'Clear temporary files',
                    onPressed: busy ? null : () => _clearTemporary(data),
                  ),
                  _section(
                    context,
                    'Upload queue',
                    helper: data.queue.isEmpty
                        ? null
                        : '${data.queue.length} ${data.queue.length == 1 ? 'upload' : 'uploads'} '
                            'waiting (${_formatBytes(data.pending.bytes)}).',
                  ),
                  _queueSection(context, data),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
