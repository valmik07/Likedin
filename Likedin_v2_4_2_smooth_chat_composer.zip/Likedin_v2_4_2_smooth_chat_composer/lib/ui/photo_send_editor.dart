import 'dart:io';
import 'dart:math';
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:image/image.dart' as img;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

class _RgbaPayload {
  const _RgbaPayload({
    required this.rgba,
    required this.width,
    required this.height,
  });
  final Uint8List rgba;
  final int width;
  final int height;
}

/// Encodes captured RGBA pixels into a bounded JPEG (max 1920 px edge, q=88)
/// in a background isolate so 3 GB RAM devices stay smooth.
Uint8List? _encodeEditedPhotoJpeg(_RgbaPayload payload) {
  try {
    final decoded = img.Image.fromBytes(
      width: payload.width,
      height: payload.height,
      bytes: payload.rgba.buffer,
      numChannels: 4,
      order: img.ChannelOrder.rgba,
    );
    final longest = max(decoded.width, decoded.height);
    final sized = longest > 1920
        ? img.copyResize(
            decoded,
            width: (decoded.width * 1920 / longest).round().clamp(1, 1920).toInt(),
            height: (decoded.height * 1920 / longest).round().clamp(1, 1920).toInt(),
          )
        : decoded;
    return Uint8List.fromList(img.encodeJpg(sized, quality: 88));
  } catch (_) {
    return null;
  }
}

class _DrawStroke {
  _DrawStroke({
    required this.color,
    required this.width,
    required this.points,
  });
  final Color color;
  final double width;
  final List<Offset> points;
}

class _TextOverlay {
  _TextOverlay({
    required this.id,
    required this.text,
    required this.offset,
    required this.color,
    this.pillBackground = true,
  });
  final String id;
  String text;
  Offset offset;
  Color color;
  bool pillBackground;
}

enum _EditorTool { draw, text, crop }

/// Full-screen photo editor before sending: freehand draw, draggable text
/// stickers, 90° rotate, and aspect-ratio crop presets (Original, 1:1, 4:5, 16:9).
/// Flattens all edits into a standard JPEG so older APKs render normally.
class PhotoSendEditorPage extends StatefulWidget {
  const PhotoSendEditorPage({required this.sourceFile, super.key});
  final File sourceFile;

  @override
  State<PhotoSendEditorPage> createState() => _PhotoSendEditorPageState();
}

class _PhotoSendEditorPageState extends State<PhotoSendEditorPage> {
  static const List<Color> _palette = <Color>[
    Colors.white,
    Color(0xFF111827),
    Color(0xFFEF4444),
    Color(0xFFF59E0B),
    Color(0xFF10B981),
    Color(0xFF3B82F6),
    Color(0xFF8B5CF6),
    Color(0xFFEC4899),
  ];

  static const List<({String label, double? ratio})> _cropPresets = <({String label, double? ratio})>[
    (label: 'Original', ratio: null),
    (label: '1:1', ratio: 1.0),
    (label: '4:5', ratio: 4 / 5),
    (label: '16:9', ratio: 16 / 9),
  ];

  final GlobalKey _exportKey = GlobalKey();
  final List<_DrawStroke> _strokes = <_DrawStroke>[];
  final List<_TextOverlay> _texts = <_TextOverlay>[];

  _EditorTool _tool = _EditorTool.draw;
  Color _activeColor = const Color(0xFFEF4444);
  double _brushWidth = 5.0;
  int _quarterTurns = 0;
  int _cropIndex = 0;
  bool _saving = false;
  double? _naturalAspectRatio;

  @override
  void initState() {
    super.initState();
    _readNaturalAspectRatio();
  }

  Future<void> _readNaturalAspectRatio() async {
    try {
      final bytes = await widget.sourceFile.readAsBytes();
      final codec = await ui.instantiateImageCodec(bytes);
      final frame = await codec.getNextFrame();
      final w = frame.image.width.toDouble();
      final h = frame.image.height.toDouble();
      frame.image.dispose();
      codec.dispose();
      if (mounted && w > 0 && h > 0) {
        setState(() => _naturalAspectRatio = w / h);
      }
    } catch (_) {}
  }

  double get _effectiveAspectRatio {
    final preset = _cropPresets[_cropIndex].ratio;
    if (preset != null) return preset;
    final natural = _naturalAspectRatio ?? 0.75;
    return (_quarterTurns % 2 == 0 ? natural : (1.0 / natural)).clamp(0.45, 2.2);
  }

  Future<void> _addOrEditText({_TextOverlay? existing}) async {
    final textController = TextEditingController(text: existing?.text ?? '');
    var selectedColor = existing?.color ?? Colors.white;
    var pillBg = existing?.pillBackground ?? true;
    final result = await showDialog<String>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: Text(existing == null ? 'Add text' : 'Edit text'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: textController,
                autofocus: true,
                maxLines: 3,
                minLines: 1,
                textCapitalization: TextCapitalization.sentences,
                decoration: const InputDecoration(hintText: 'Write something…'),
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: _palette.map((c) {
                  final selected = c == selectedColor;
                  return GestureDetector(
                    onTap: () => setDialogState(() => selectedColor = c),
                    child: Container(
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                        color: c,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: selected ? Theme.of(context).colorScheme.primary : Colors.white38,
                          width: selected ? 2.5 : 1,
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 8),
              SwitchListTile.adaptive(
                contentPadding: EdgeInsets.zero,
                value: pillBg,
                onChanged: (v) => setDialogState(() => pillBg = v),
                title: const Text('Backdrop pill', style: TextStyle(fontSize: 13)),
              ),
            ],
          ),
          actions: [
            if (existing != null)
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, '__DELETE__'),
                child: const Text('Delete', style: TextStyle(color: Color(0xFFE5484D))),
              ),
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, textController.text.trim()),
              child: const Text('Done'),
            ),
          ],
        ),
      ),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) => textController.dispose());
    if (!mounted || result == null) return;
    setState(() {
      if (result == '__DELETE__' && existing != null) {
        _texts.removeWhere((t) => t.id == existing.id);
      } else if (result.isNotEmpty) {
        if (existing != null) {
          existing
            ..text = result
            ..color = selectedColor
            ..pillBackground = pillBg;
        } else {
          _texts.add(_TextOverlay(
            id: const Uuid().v4(),
            text: result,
            offset: const Offset(48, 84),
            color: selectedColor,
            pillBackground: pillBg,
          ));
        }
      }
    });
  }

  Future<void> _exportAndReturn() async {
    if (_saving) return;
    setState(() => _saving = true);
    try {
      await WidgetsBinding.instance.endOfFrame;
      final boundary = _exportKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      if (boundary == null) throw StateError('Editor surface is not ready.');
      final logicalLongest = max(boundary.size.width, boundary.size.height);
      final targetRatio = logicalLongest > 0 ? (1440 / logicalLongest).clamp(1.2, 3.0) : 2.0;
      final captured = await boundary.toImage(pixelRatio: targetRatio);
      final byteData = await captured.toByteData(format: ui.ImageByteFormat.rawRgba);
      final width = captured.width;
      final height = captured.height;
      captured.dispose();
      if (byteData == null) throw StateError('Could not read edited image pixels.');

      final jpegBytes = await compute(
        _encodeEditedPhotoJpeg,
        _RgbaPayload(
          rgba: byteData.buffer.asUint8List(),
          width: width,
          height: height,
        ),
      );
      if (jpegBytes == null || jpegBytes.isEmpty) {
        throw StateError('Could not encode edited photo.');
      }
      final tempDir = await getTemporaryDirectory();
      final outFile = File(p.join(tempDir.path, 'likedin_edited_${const Uuid().v4()}.jpg'));
      await outFile.writeAsBytes(jpegBytes, flush: true);
      if (mounted) Navigator.of(context).pop(outFile);
    } catch (error) {
      debugPrint('Photo export failed: $error');
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not save edits. Please try again.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF070B14),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.white,
        title: const Text('Edit photo', style: TextStyle(fontWeight: FontWeight.w700)),
        actions: [
          if (_strokes.isNotEmpty)
            IconButton(
              tooltip: 'Undo stroke',
              onPressed: _saving ? null : () => setState(() => _strokes.removeLast()),
              icon: const Icon(Icons.undo_rounded),
            ),
          IconButton(
            tooltip: 'Rotate 90°',
            onPressed: _saving
                ? null
                : () {
                    HapticFeedback.selectionClick();
                    setState(() => _quarterTurns = (_quarterTurns + 1) % 4);
                  },
            icon: const Icon(Icons.rotate_right_rounded),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 10),
            child: FilledButton(
              onPressed: _saving ? null : _exportAndReturn,
              child: _saving
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Text('Done'),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: AspectRatio(
                  aspectRatio: _effectiveAspectRatio,
                  child: RepaintBoundary(
                    key: _exportKey,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(14),
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          ColoredBox(
                            color: Colors.black,
                            child: InteractiveViewer(
                              panEnabled: _tool == _EditorTool.crop,
                              scaleEnabled: _tool == _EditorTool.crop,
                              minScale: 1.0,
                              maxScale: 4.0,
                              child: RotatedBox(
                                quarterTurns: _quarterTurns,
                                child: Image.file(
                                  widget.sourceFile,
                                  fit: BoxFit.cover,
                                  cacheWidth: 1440,
                                ),
                              ),
                            ),
                          ),
                          // Freehand drawing canvas
                          IgnorePointer(
                            ignoring: _tool != _EditorTool.draw,
                            child: GestureDetector(
                              behavior: HitTestBehavior.opaque,
                              onPanStart: (d) {
                                setState(() {
                                  _strokes.add(_DrawStroke(
                                    color: _activeColor,
                                    width: _brushWidth,
                                    points: <Offset>[d.localPosition],
                                  ));
                                });
                              },
                              onPanUpdate: (d) {
                                if (_strokes.isEmpty) return;
                                setState(() {
                                  _strokes.last.points.add(d.localPosition);
                                });
                              },
                              child: CustomPaint(
                                painter: _PhotoDrawPainter(strokes: _strokes),
                              ),
                            ),
                          ),
                          // Draggable text overlays
                          for (final item in _texts)
                            Positioned(
                              left: item.offset.dx,
                              top: item.offset.dy,
                              child: GestureDetector(
                                onTap: () => _addOrEditText(existing: item),
                                onPanUpdate: (d) {
                                  setState(() => item.offset += d.delta);
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
                                  decoration: item.pillBackground
                                      ? BoxDecoration(
                                          color: Colors.black.withValues(alpha: .60),
                                          borderRadius: BorderRadius.circular(14),
                                        )
                                      : null,
                                  child: Text(
                                    item.text,
                                    style: TextStyle(
                                      color: item.color,
                                      fontSize: 20,
                                      fontWeight: FontWeight.w800,
                                      shadows: item.pillBackground
                                          ? null
                                          : const [Shadow(color: Colors.black87, blurRadius: 6)],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          // Context toolbar for active tool
          SafeArea(
            top: false,
            child: Container(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
              color: const Color(0xFF0E1525),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (_tool == _EditorTool.draw) ...[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        for (final c in _palette)
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 4),
                            child: GestureDetector(
                              onTap: () {
                                HapticFeedback.selectionClick();
                                setState(() => _activeColor = c);
                              },
                              child: Container(
                                width: 28,
                                height: 28,
                                decoration: BoxDecoration(
                                  color: c,
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: _activeColor == c ? Colors.white : Colors.white24,
                                    width: _activeColor == c ? 2.5 : 1,
                                  ),
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        for (final entry in const [(label: 'Thin', w: 3.0), (label: 'Med', w: 6.0), (label: 'Thick', w: 11.0)])
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 4),
                            child: ChoiceChip(
                              label: Text(entry.label),
                              selected: _brushWidth == entry.w,
                              visualDensity: VisualDensity.compact,
                              onSelected: (_) => setState(() => _brushWidth = entry.w),
                            ),
                          ),
                        if (_strokes.isNotEmpty)
                          TextButton(
                            onPressed: () => setState(() => _strokes.clear()),
                            child: const Text('Clear'),
                          ),
                      ],
                    ),
                  ] else if (_tool == _EditorTool.text) ...[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        FilledButton.tonalIcon(
                          onPressed: () => _addOrEditText(),
                          icon: const Icon(Icons.title_rounded, size: 18),
                          label: const Text('Add text sticker'),
                        ),
                        const SizedBox(width: 10),
                        const Text(
                          'Drag to move · Tap to edit',
                          style: TextStyle(color: Colors.white60, fontSize: 12),
                        ),
                      ],
                    ),
                  ] else ...[
                    Wrap(
                      spacing: 8,
                      children: List.generate(_cropPresets.length, (i) {
                        return ChoiceChip(
                          label: Text(_cropPresets[i].label),
                          selected: _cropIndex == i,
                          visualDensity: VisualDensity.compact,
                          onSelected: (_) => setState(() => _cropIndex = i),
                        );
                      }),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'Pinch or drag photo to frame inside the crop box',
                      style: TextStyle(color: Colors.white60, fontSize: 11),
                    ),
                  ],
                  const SizedBox(height: 10),
                  SegmentedButton<_EditorTool>(
                    segments: const [
                      ButtonSegment(value: _EditorTool.draw, label: Text('Draw'), icon: Icon(Icons.brush_rounded, size: 17)),
                      ButtonSegment(value: _EditorTool.text, label: Text('Text'), icon: Icon(Icons.text_fields_rounded, size: 17)),
                      ButtonSegment(value: _EditorTool.crop, label: Text('Crop'), icon: Icon(Icons.crop_rounded, size: 17)),
                    ],
                    selected: <_EditorTool>{_tool},
                    onSelectionChanged: (s) => setState(() => _tool = s.first),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PhotoDrawPainter extends CustomPainter {
  _PhotoDrawPainter({required this.strokes});
  final List<_DrawStroke> strokes;

  @override
  void paint(Canvas canvas, Size size) {
    for (final stroke in strokes) {
      if (stroke.points.isEmpty) continue;
      final paint = Paint()
        ..color = stroke.color
        ..strokeWidth = stroke.width
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..style = PaintingStyle.stroke;
      if (stroke.points.length == 1) {
        canvas.drawCircle(stroke.points.first, stroke.width / 2, Paint()..color = stroke.color);
        continue;
      }
      final path = Path()..moveTo(stroke.points.first.dx, stroke.points.first.dy);
      for (var i = 1; i < stroke.points.length; i++) {
        path.lineTo(stroke.points[i].dx, stroke.points[i].dy);
      }
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _PhotoDrawPainter oldDelegate) => true;
}
