import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../backend/realtime_messaging_service.dart';
import '../backend/shared_media_service.dart';
import 'glassmorphism.dart';
import '../utils/chat_info_metrics.dart';

class ChatInfoSnapshot {
  const ChatInfoSnapshot({
    required this.displayName,
    required this.presence,
    required this.avatarUrl,
    this.messages,
  });

  final String displayName;
  final String presence;
  final String? avatarUrl;
  final List<RemoteMessage>? messages;
}

class ChatInfoPage extends StatefulWidget {
  const ChatInfoPage({
    required this.displayName,
    required this.presence,
    required this.avatarUrl,
    required this.messages,
    required this.mediaService,
    required this.loadSnapshot,
    required this.onOpenAvatar,
    required this.onOpenMedia,
    required this.onClearChat,
    required this.onChangeNickname,
    this.starredCount = 0,
    this.onOpenStarred,
    super.key,
  });

  final String displayName;
  final String presence;
  final String? avatarUrl;
  final List<RemoteMessage> messages;
  final SharedMediaService mediaService;
  final Future<ChatInfoSnapshot> Function({bool loadAllMessages}) loadSnapshot;
  final VoidCallback onOpenAvatar;
  final ValueChanged<Map<String, dynamic>> onOpenMedia;
  final Future<void> Function() onClearChat;
  final VoidCallback onChangeNickname;
  final int starredCount;
  final VoidCallback? onOpenStarred;

  @override
  State<ChatInfoPage> createState() => _ChatInfoPageState();
}

class _ChatInfoPageState extends State<ChatInfoPage> {
  late String _displayName = widget.displayName;
  late String _presence = widget.presence;
  String? _avatarUrl;
  late List<RemoteMessage> _messages;
  late List<Map<String, dynamic>> _mediaItems;
  late int _linkCount;
  Timer? _refreshTimer;
  Timer? _metricsRefreshTimer;
  bool _refreshing = false;
  bool _syncingCloud = false;
  bool _reloadPending = false;
  bool _pendingLoadAllMessages = false;

  @override
  void initState() {
    super.initState();
    _avatarUrl = widget.avatarUrl;
    _messages = List<RemoteMessage>.unmodifiable(widget.messages);
    _mediaItems = ChatInfoMetrics.mediaItems(_messages);
    _linkCount = ChatInfoMetrics.linkCount(_messages);
    _reload(loadAllMessages: false);
    _refreshTimer = Timer.periodic(const Duration(seconds: 120), (_) => _reload(loadAllMessages: false));
    _metricsRefreshTimer = Timer.periodic(const Duration(hours: 2), (_) => _reload(loadAllMessages: true));
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _metricsRefreshTimer?.cancel();
    super.dispose();
  }

  Future<void> _reload({bool loadAllMessages = false}) async {
    if (_refreshing) {
      _reloadPending = true;
      _pendingLoadAllMessages = _pendingLoadAllMessages || loadAllMessages;
      return;
    }
    _refreshing = true;
    try {
      final snapshot = await widget.loadSnapshot(loadAllMessages: loadAllMessages);
      if (!mounted) return;
      setState(() {
        _displayName = snapshot.displayName;
        _presence = snapshot.presence;
        _avatarUrl = snapshot.avatarUrl;
        if (snapshot.messages != null) {
          _messages = List<RemoteMessage>.unmodifiable(snapshot.messages!);
          _mediaItems = ChatInfoMetrics.mediaItems(_messages);
          _linkCount = ChatInfoMetrics.linkCount(_messages);
        }
      });
    } catch (_) {
      // Keep the last complete snapshot visible when presence/network refresh fails.
    } finally {
      _refreshing = false;
      if (mounted && _reloadPending) {
        final reloadAll = _pendingLoadAllMessages;
        _reloadPending = false;
        _pendingLoadAllMessages = false;
        unawaited(_reload(loadAllMessages: reloadAll));
      }
    }
  }

  Future<void> _syncCloudBackup() async {
    if (_syncingCloud) return;
    setState(() => _syncingCloud = true);
    try {
      final snapshot = await widget.loadSnapshot(loadAllMessages: true);
      if (!mounted) return;
      final nextMessages = snapshot.messages != null
          ? List<RemoteMessage>.unmodifiable(snapshot.messages!)
          : _messages;
      final nextMedia = ChatInfoMetrics.mediaItems(nextMessages);
      final nextLinks = ChatInfoMetrics.linkCount(nextMessages);
      final nextDocs = ChatInfoMetrics.documentCount(nextMedia);
      final nextVisual = nextMedia.length - nextDocs;
      setState(() {
        _displayName = snapshot.displayName;
        _presence = snapshot.presence;
        _avatarUrl = snapshot.avatarUrl;
        _messages = nextMessages;
        _mediaItems = nextMedia;
        _linkCount = nextLinks;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Cloud backup loaded: $nextVisual media · $nextLinks links · $nextDocs docs',
          ),
        ),
      );
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Could not download cloud backup. Check your connection and try again.'),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _syncingCloud = false);
    }
  }

  Future<void> _clearAndRefresh() async {
    await widget.onClearChat();
    if (mounted) await _reload(loadAllMessages: true);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final media = _mediaItems;
    final linkCount = _linkCount;
    final documentCount = ChatInfoMetrics.documentCount(media);
    final sharedCount = media.length + linkCount;
    // The helper is explicit about the oldest-first source order and returns
    // newest-first visual media without touching document/voice-note files.
    final newest = List<Map<String, dynamic>>.unmodifiable(media.reversed);
    final sharedLinks = ChatInfoMetrics.links(_messages).reversed.toList(growable: false);
    final previews = ChatInfoMetrics.latestVisualMedia(media, limit: 4);
    final bottomInset = MediaQuery.paddingOf(context).bottom;

    return AuroraBackdrop(
      child: Scaffold(
      backgroundColor: Colors.transparent,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: true,
            backgroundColor: Colors.transparent,
            surfaceTintColor: Colors.transparent,
            leading: IconButton(
              tooltip: 'Back to chat',
              onPressed: () => Navigator.of(context).pop(),
              icon: const Icon(Icons.arrow_back_rounded),
            ),
            title: const Text('Contact info', style: TextStyle(fontWeight: FontWeight.w700)),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(22, 18, 22, 12),
              child: Column(
                children: [
                  Semantics(
                    button: true,
                    label: 'View $_displayName profile photo',
                    child: GestureDetector(
                      onTap: _avatarUrl == null ? null : widget.onOpenAvatar,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(colors: [
                            theme.colorScheme.primary.withValues(alpha: .75),
                            theme.colorScheme.secondary.withValues(alpha: .25),
                          ]),
                        ),
                        child: CircleAvatar(
                          radius: 65,
                          backgroundColor: theme.colorScheme.surfaceContainerHighest,
                          backgroundImage: _avatarUrl == null ? null : NetworkImage(_avatarUrl!),
                          child: _avatarUrl == null
                              ? Icon(Icons.person_rounded, size: 58, color: theme.colorScheme.onSurfaceVariant)
                              : null,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 17),
                  Text(_displayName, textAlign: TextAlign.center,
                      style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 5),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(
                          color: _presence.toLowerCase() == 'online'
                              ? const Color(0xFF2FBF86)
                              : theme.colorScheme.outline,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 7),
                      Text(_presence, style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
                    ],
                  ),
                  const SizedBox(height: 10),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 8, 18, 0),
              child: GlassPanel(
                glow: false,
                radius: BorderRadius.circular(22),
                padding: const EdgeInsets.fromLTRB(16, 15, 16, 14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Semantics(
                      button: sharedCount > 0,
                      label: 'Shared media, links, and documents. $sharedCount items. Open all media.',
                      child: InkWell(
                        borderRadius: BorderRadius.circular(10),
                        onTap: sharedCount == 0 ? null : () => Navigator.of(context).push<void>(
                          MaterialPageRoute<void>(
                            builder: (_) => _SharedMediaGalleryPage(
                              items: newest,
                              links: sharedLinks,
                              service: widget.mediaService,
                              onOpenMedia: widget.onOpenMedia,
                            ),
                          ),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(children: [
                            Expanded(child: Text('Media, links, and docs', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700))),
                            if (_syncingCloud)
                              const Padding(
                                padding: EdgeInsets.only(right: 8),
                                child: SizedBox(
                                  width: 14,
                                  height: 14,
                                  child: CircularProgressIndicator(strokeWidth: 2),
                                ),
                              ),
                            Text('$sharedCount', style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
                            const SizedBox(width: 2),
                            Icon(Icons.chevron_right_rounded, size: 19, color: theme.colorScheme.onSurfaceVariant),
                          ]),
                        ),
                      ),
                    ),
                    if (previews.isNotEmpty) ...[
                      const SizedBox(height: 13),
                      SizedBox(
                        height: 76,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: previews.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 9),
                          itemBuilder: (_, index) {
                            final item = previews[index];
                            final kind = item['kind']?.toString() ?? 'image';
                            return _SharedMediaThumbnail(
                              key: ValueKey('contact-media-${item['path'] ?? index}'),
                              payload: item,
                              service: widget.mediaService,
                              isVideo: kind == 'video',
                              onTap: () => widget.onOpenMedia(item),
                            );
                          },
                        ),
                      ),

                    ] else
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 18),
                        child: Text(sharedCount == 0 ? 'No shared items yet' : 'Open to view shared links and documents', style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
                      ),
                  ],
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: EdgeInsets.fromLTRB(18, 14, 18, 28 + bottomInset),
            sliver: SliverList.list(children: [
              GlassPanel(
                radius: BorderRadius.circular(22),
                child: Column(
                  children: [
                    _InfoAction(
                      icon: Icons.cloud_download_outlined,
                      badgeColor: const Color(0xFF4C8BF5),
                      title: _syncingCloud ? 'Downloading cloud backup…' : 'Download cloud backup',
                      subtitle: 'Load all older photos, videos, links and docs without scrolling up',
                      onTap: _syncingCloud ? () {} : _syncCloudBackup,
                    ),
                    Divider(height: 1, indent: 62, endIndent: 14, color: likedinOutline(theme.brightness)),
                    if (widget.onOpenStarred != null) ...[
                      _InfoAction(
                        icon: Icons.star_rounded,
                        badgeColor: const Color(0xFFF59E0B),
                        title: 'Starred messages',
                        subtitle: widget.starredCount == 0
                            ? 'Save favorite messages by long-pressing them'
                            : '${widget.starredCount} starred ${widget.starredCount == 1 ? 'message' : 'messages'}',
                        onTap: widget.onOpenStarred!,
                      ),
                      Divider(height: 1, indent: 62, endIndent: 14, color: likedinOutline(theme.brightness)),
                    ],
                    _InfoAction(
                      icon: Icons.edit_outlined,
                      badgeColor: const Color(0xFF9B6BFF),
                      title: 'Chat nickname',
                      subtitle: 'Change how this contact appears in the chat',
                      onTap: widget.onChangeNickname,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              GlassPanel(
                radius: BorderRadius.circular(22),
                child: _InfoAction(
                  icon: Icons.delete_outline_rounded,
                  badgeColor: const Color(0xFFE5484D),
                  title: 'Clear chat',
                  subtitle: 'Clear this conversation on this device only',
                  destructive: true,
                  onTap: _clearAndRefresh,
                ),
              ),
              const SizedBox(height: 14),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Text(
                  'Shared items: ${media.length - documentCount} media · $linkCount links · $documentCount documents',
                  style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                ),
              ),
            ]),
          ),
        ],
      ),
    ),
    );
  }
}

class _SharedMediaGalleryPage extends StatelessWidget {
  const _SharedMediaGalleryPage({
    required this.items,
    required this.links,
    required this.service,
    required this.onOpenMedia,
  });
  final List<Map<String, dynamic>> items;
  final List<String> links;
  final SharedMediaService service;
  final ValueChanged<Map<String, dynamic>> onOpenMedia;

  @override
  Widget build(BuildContext context) {
    final visualMedia = items.where((item) {
      final kind = item['kind']?.toString() ?? 'file';
      return kind == 'image' || kind == 'video';
    }).toList(growable: false);
    final docsAndAudio = items.where((item) {
      final kind = item['kind']?.toString() ?? 'file';
      return kind != 'image' && kind != 'video';
    }).toList(growable: false);

    return DefaultTabController(
      length: 3,
      child: AuroraBackdrop(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            title: const Text('Shared items', style: TextStyle(fontWeight: FontWeight.w800)),
          ),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 2, 16, 10),
                child: GlassPanel(
                  radius: BorderRadius.circular(20),
                  padding: const EdgeInsets.all(4),
                  child: TabBar(
                    dividerColor: Colors.transparent,
                    indicatorSize: TabBarIndicatorSize.tab,
                    tabs: [
                      Tab(text: 'Media (${visualMedia.length})'),
                      Tab(text: 'Links (${links.length})'),
                      Tab(text: 'Docs (${docsAndAudio.length})'),
                    ],
                  ),
                ),
              ),
              Expanded(
                child: TabBarView(
                  children: [
                    if (visualMedia.isEmpty)
                      const Center(child: Text('No shared photos or videos yet'))
                    else
                      GridView.builder(
                        padding: const EdgeInsets.all(14),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3,
                          crossAxisSpacing: 8,
                          mainAxisSpacing: 8,
                        ),
                        itemCount: visualMedia.length,
                        itemBuilder: (context, index) {
                          final item = visualMedia[index];
                          return _SharedMediaThumbnail(
                            payload: item,
                            service: service,
                            isVideo: item['kind'] == 'video',
                            onTap: () => onOpenMedia(item),
                          );
                        },
                      ),
                    if (links.isEmpty)
                      const Center(child: Text('No shared links yet'))
                    else
                      ListView.separated(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                        itemCount: links.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 8),
                        itemBuilder: (context, index) {
                          final link = links[index];
                          final uri = Uri.tryParse(link);
                          return GlassPanel(
                            radius: BorderRadius.circular(20),
                            child: ListTile(
                              leading: CircleAvatar(
                                backgroundColor: Theme.of(context).colorScheme.primary.withValues(alpha: .14),
                                child: Icon(Icons.link_rounded, color: Theme.of(context).colorScheme.primary),
                              ),
                              title: Text(link, maxLines: 2, overflow: TextOverflow.ellipsis),
                              subtitle: uri == null ? null : Text(uri.host.replaceFirst('www.', ''), style: const TextStyle(fontSize: 12)),
                              onTap: () async {
                                if (uri != null && await canLaunchUrl(uri)) {
                                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                                }
                              },
                            ),
                          );
                        },
                      ),
                    if (docsAndAudio.isEmpty)
                      const Center(child: Text('No shared documents or audio yet'))
                    else
                      ListView.separated(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                        itemCount: docsAndAudio.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 8),
                        itemBuilder: (context, index) {
                          final item = docsAndAudio[index];
                          final kind = item['kind']?.toString() ?? 'file';
                          final name = item['name']?.toString() ?? 'Attachment';
                          final size = (item['size'] as num?)?.toInt() ?? 0;
                          final sizeLabel = size >= 1048576
                              ? '${(size / 1048576).toStringAsFixed(1)} MB'
                              : size > 0
                                  ? '${(size / 1024).toStringAsFixed(0)} KB'
                                  : 'Shared file';
                          return GlassPanel(
                            radius: BorderRadius.circular(20),
                            child: ListTile(
                              leading: CircleAvatar(
                                backgroundColor: Theme.of(context).colorScheme.primary.withValues(alpha: .14),
                                child: Icon(
                                  kind == 'audio' ? Icons.audiotrack_rounded : Icons.description_outlined,
                                  color: Theme.of(context).colorScheme.primary,
                                ),
                              ),
                              title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis),
                              subtitle: Text(sizeLabel, style: const TextStyle(fontSize: 12)),
                              trailing: const Icon(Icons.open_in_new_rounded, size: 18),
                              onTap: () => onOpenMedia(item),
                            ),
                          );
                        },
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _InfoAction extends StatelessWidget {
  const _InfoAction({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.badgeColor = const Color(0xFF4C8BF5),
    this.destructive = false,
  });
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final Color badgeColor;
  final bool destructive;

  @override
  Widget build(BuildContext context) {
    final color = destructive ? const Color(0xFFE5484D) : Theme.of(context).colorScheme.onSurface;
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      leading: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: badgeColor.withValues(alpha: .15),
          borderRadius: BorderRadius.circular(11),
        ),
        child: Icon(icon, color: badgeColor, size: 19),
      ),
      title: Text(title, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: color)),
      subtitle: Text(subtitle, style: const TextStyle(fontSize: 12)),
      trailing: destructive ? null : Icon(Icons.chevron_right_rounded, color: Theme.of(context).hintColor, size: 20),
      onTap: onTap,
    );
  }
}

class _SharedMediaThumbnail extends StatefulWidget {
  const _SharedMediaThumbnail({super.key, required this.payload, required this.service, required this.isVideo, required this.onTap});
  final Map<String, dynamic> payload;
  final SharedMediaService service;
  final bool isVideo;
  final VoidCallback onTap;

  @override
  State<_SharedMediaThumbnail> createState() => _SharedMediaThumbnailState();
}

class _SharedMediaThumbnailState extends State<_SharedMediaThumbnail> {
  late Future<File?> _thumbnailFuture = _loadThumbnail();

  @override
  void didUpdateWidget(covariant _SharedMediaThumbnail oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.payload['path'] != widget.payload['path']) {
      _thumbnailFuture = _loadThumbnail();
    }
  }

  Future<File?> _loadThumbnail() async {
    final sidecarPath = widget.payload['thumbnail_path']?.toString();
    if (sidecarPath != null && sidecarPath.isNotEmpty) {
      try {
        return await widget.service.cachedFile(<String, dynamic>{
          '__likedin_media_v1': true,
          'path': sidecarPath,
          'name': 'media-preview.jpg',
          'mime': 'image/jpeg',
          'kind': 'image',
        });
      } catch (_) {
        // Older messages may predate sidecar thumbnails; use the safe fallback.
      }
    }

    final kind = widget.payload['kind']?.toString();
    if (kind == 'image') {
      // Legacy photos remain viewable; cacheWidth below bounds decoded pixels.
      return widget.service.cachedFile(widget.payload);
    }
    // Never download a legacy full video merely to paint a tiny Contact Info
    // tile. New videos receive JPEG sidecars at upload time.
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Semantics(
      button: true,
      label: widget.isVideo ? 'Open shared video' :
          widget.payload['kind'] == 'image' ? 'Open shared photo' :
          'Open shared document ${widget.payload['name']?.toString() ?? 'Attachment'}',
      child: InkWell(
        onTap: widget.onTap,
        borderRadius: BorderRadius.circular(14),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: SizedBox(
            width: 76,
            height: 76,
            child: FutureBuilder<File?>(
              future: _thumbnailFuture,
              builder: (context, snapshot) {
                final file = snapshot.data;
                if (file != null) {
                  return Stack(fit: StackFit.expand, children: [
                    Image.file(file, fit: BoxFit.cover, cacheWidth: 192,
                      errorBuilder: (_, __, ___) => _fallback(theme)),
                    if (widget.isVideo)
                      const Center(child: Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 30)),
                  ]);
                }
                return _fallback(theme, loading: snapshot.connectionState == ConnectionState.waiting);
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget _fallback(ThemeData theme, {bool loading = false}) {
    final kind = widget.payload['kind']?.toString() ?? 'file';
    final icon = widget.isVideo
        ? Icons.video_library_outlined
        : kind == 'image'
            ? Icons.image_outlined
            : kind == 'audio'
                ? Icons.audio_file_outlined
                : Icons.description_outlined;
    final name = widget.payload['name']?.toString() ?? 'Attachment';
    return Container(
      color: theme.colorScheme.surfaceContainerHighest,
      alignment: Alignment.center,
      padding: const EdgeInsets.all(5),
      child: loading
          ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
          : kind == 'image' || kind == 'video'
              ? Icon(icon, color: theme.colorScheme.primary, size: 27)
              : Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(icon, color: theme.colorScheme.primary, size: 25),
                    const SizedBox(height: 3),
                    Text(name, maxLines: 2, overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 9, height: 1.05, color: theme.colorScheme.onSurface)),
                  ],
                ),
    );
  }
}
