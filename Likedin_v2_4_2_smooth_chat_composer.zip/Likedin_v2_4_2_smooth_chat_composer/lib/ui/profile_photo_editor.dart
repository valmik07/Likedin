import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;

/// A lightweight, dependency-free 1:1 profile-photo cropper.
///
/// Decoding, resizing and JPEG encoding are performed in worker isolates so
/// large source photos do not block animations or scrolling on low-memory
/// Android devices. The returned image is a bounded 1024x1024 JPEG.
class ProfilePhotoEditorPage extends StatefulWidget {
  const ProfilePhotoEditorPage({
    required this.sourceBytes,
    required this.sourceExtension,
    super.key,
  });

  final Uint8List sourceBytes;
  final String sourceExtension;

  @override
  State<ProfilePhotoEditorPage> createState() => _ProfilePhotoEditorPageState();
}

class _ProfilePhotoEditorPageState extends State<ProfilePhotoEditorPage> {
  final TransformationController _transformation = TransformationController();
  late final Future<Map<String, Object?>> _preview =
      compute<Map<String, Object>, Map<String, Object?>>(_prepareProfilePhotoPreview, <String, Object>{
        'bytes': widget.sourceBytes,
        'extension': widget.sourceExtension.toLowerCase(),
      });

  String? _initialisedLayout;
  bool _saving = false;
  double _viewportSide = 0;

  @override
  void dispose() {
    _transformation.dispose();
    super.dispose();
  }

  void _setInitialTransform({
    required double side,
    required int imageWidth,
    required int imageHeight,
  }) {
    final key = '${side.toStringAsFixed(2)}:$imageWidth:$imageHeight';
    if (_initialisedLayout == key) return;
    _initialisedLayout = key;

    final scale = math.max(side / imageWidth, side / imageHeight).toDouble();
    final dx = (side - imageWidth * scale) / 2;
    final dy = (side - imageHeight * scale) / 2;
    final initial = Matrix4.identity()
      ..setEntry(0, 0, scale)
      ..setEntry(1, 1, scale)
      ..setEntry(0, 3, dx)
      ..setEntry(1, 3, dy);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || _initialisedLayout != key) return;
      _transformation.value = initial;
    });
  }

  Future<void> _confirmCrop(Map<String, Object?> previewData, double side) async {
    if (_saving) return;
    setState(() => _saving = true);
    try {
      final previewBytes = previewData['bytes'] as Uint8List;
      final imageWidth = previewData['width'] as int;
      final imageHeight = previewData['height'] as int;
      final matrix = _transformation.value;
      final scale = matrix.entry(0, 0);
      if (!scale.isFinite || scale <= 0) {
        throw StateError('The crop position is invalid. Please adjust the image and try again.');
      }

      final cropSide = (side / scale)
          .clamp(1.0, math.min(imageWidth, imageHeight).toDouble());
      final left = (-matrix.entry(0, 3) / scale)
          .clamp(0.0, imageWidth - cropSide);
      final top = (-matrix.entry(1, 3) / scale)
          .clamp(0.0, imageHeight - cropSide);
      final x = left.round().clamp(0, imageWidth - cropSide.round()).toInt();
      final y = top.round().clamp(0, imageHeight - cropSide.round()).toInt();
      final size = cropSide.round().clamp(1, math.min(imageWidth, imageHeight)).toInt();

      final result = await compute<Map<String, Object>, Uint8List>(
        _cropProfilePhotoOnWorker,
        <String, Object>{
          'bytes': previewBytes,
          'x': x,
          'y': y,
          'size': size,
        },
      );
      if (!mounted) return;
      Navigator.of(context).pop<Uint8List>(result);
    } catch (error) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not crop this photo. Please try again.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final foreground = brightness == Brightness.dark ? Colors.white : const Color(0xFF10213D);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Adjust profile photo'),
        actions: [
          TextButton.icon(
            onPressed: _saving
                ? null
                : () async {
                    final data = await _preview;
                    if (data['width'] is! int || data['height'] is! int || !mounted) return;
                    final side = _viewportSide;
                    if (side <= 0) return;
                    await _confirmCrop(data, side);
                  },
            icon: _saving
                ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.check_rounded),
            label: const Text('Save'),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: FutureBuilder<Map<String, Object?>>(
        future: _preview,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError || !snapshot.hasData || snapshot.data!['error'] != null) {
            final reason = snapshot.data?['error']?.toString() ?? 'This image format could not be opened.';
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(28),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.image_not_supported_outlined, size: 48),
                    const SizedBox(height: 12),
                    const Text('Cannot edit this image', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 8),
                    Text(reason, textAlign: TextAlign.center),
                    const SizedBox(height: 8),
                    const Text('Choose a JPG, PNG or WebP photo.', textAlign: TextAlign.center),
                  ],
                ),
              ),
            );
          }

          final data = snapshot.data!;
          final bytes = data['bytes'] as Uint8List;
          final width = data['width'] as int;
          final height = data['height'] as int;
          return Padding(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 24),
            child: Column(
              children: [
                Text(
                  'Move and pinch to frame your photo',
                  style: TextStyle(color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .72)),
                ),
                const SizedBox(height: 18),
                Expanded(
                  child: Center(
                    child: LayoutBuilder(
                      builder: (context, constraints) {
                        final side = math.min(constraints.maxWidth, constraints.maxHeight).toDouble();
                        _viewportSide = side;
                        _setInitialTransform(side: side, imageWidth: width, imageHeight: height);
                        final fitScale = math.max(side / width, side / height).toDouble();
                        return SizedBox.square(
                          dimension: side,
                          child: ClipRect(
                            child: Stack(
                              fit: StackFit.expand,
                              children: [
                                InteractiveViewer(
                                  transformationController: _transformation,
                                  constrained: false,
                                  minScale: fitScale,
                                  maxScale: fitScale * 4,
                                  boundaryMargin: EdgeInsets.zero,
                                  clipBehavior: Clip.hardEdge,
                                  child: Image.memory(
                                    bytes,
                                    width: width.toDouble(),
                                    height: height.toDouble(),
                                    fit: BoxFit.fill,
                                    gaplessPlayback: true,
                                    filterQuality: FilterQuality.medium,
                                  ),
                                ),
                                IgnorePointer(
                                  child: DecoratedBox(
                                    decoration: BoxDecoration(
                                      border: Border.all(color: Colors.white.withValues(alpha: .94), width: 2),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Icon(Icons.crop_square_rounded, color: foreground),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Square crop · 1:1',
                        style: TextStyle(color: foreground, fontWeight: FontWeight.w700),
                      ),
                    ),
                    TextButton.icon(
                      onPressed: () {
                        _initialisedLayout = null;
                        setState(() {});
                      },
                      icon: const Icon(Icons.refresh_rounded, size: 18),
                      label: const Text('Reset'),
                    ),
                  ],
                ),
                if (_saving) const LinearProgressIndicator(),
              ],
            ),
          );
        },
      ),
    );
  }
}

/// Produces a correctly oriented, memory-bounded preview (max 1600 px).
/// JPEG camera photos are decoded with JPEG DCT down-sampling so a 50 MP
/// original does not become a full-resolution RGBA bitmap on a low-memory phone.
/// Runs in an isolate; profile photos are static, so animated sources are
/// intentionally represented by their first frame.
Map<String, Object?> _prepareProfilePhotoPreview(Map<String, Object> input) {
  try {
    final bytes = input['bytes'] as Uint8List;
    final extension = (input['extension'] as String).toLowerCase();
    img.Image? decoded;

    if (extension == 'jpg' || extension == 'jpeg') {
      // Read JPEG dimensions without allocating the pixel buffer, then choose
      // decoder-level 1/2, 1/4 or 1/8 sampling to keep the largest side near
      // 2200 px before the final 1600 px preview resize.
      const maxJpegPixels = 50 * 1024 * 1024;
      final info = img.JpegDecoder(maxPixels: maxJpegPixels).startDecode(bytes);
      if (info == null) {
        return <String, Object?>{'error': 'This JPEG photo could not be opened.'};
      }
      final maxDimension = math.max(info.width, info.height);
      var decodeScale = 1;
      while (decodeScale < 8 && maxDimension / decodeScale > 2200) {
        decodeScale *= 2;
      }
      decoded = img.decodeJpg(
        bytes,
        maxPixels: maxJpegPixels,
        scale: decodeScale,
      );
    } else {
      // PNG and WebP can be more expensive to decode than JPEG. Keep a
      // conservative decoded-pixel cap for lower-memory Android devices.
      img.Decoder.defaultMaxPixels = 16 * 1024 * 1024;
      decoded = img.decodeImage(bytes, frame: 0);
    }

    if (decoded == null) {
      return <String, Object?>{'error': 'Unsupported or damaged image.'};
    }
    final oriented = img.bakeOrientation(decoded);
    final maxDimension = math.max(oriented.width, oriented.height);
    final preview = maxDimension > 1600
        ? img.copyResize(
            oriented,
            width: (oriented.width * 1600 / maxDimension)
                .round()
                .clamp(1, 1600)
                .toInt(),
            height: (oriented.height * 1600 / maxDimension)
                .round()
                .clamp(1, 1600)
                .toInt(),
          )
        : oriented;
    return <String, Object?>{
      'bytes': Uint8List.fromList(img.encodeJpg(preview, quality: 86)),
      'width': preview.width,
      'height': preview.height,
    };
  } catch (error) {
    debugPrint('Profile photo preview decoding failed: $error');
    return <String, Object?>{'error': 'This image could not be read. Choose a JPG, PNG or WebP photo.'};
  }
}

/// Crops and compresses a square avatar off the UI isolate.
Uint8List _cropProfilePhotoOnWorker(Map<String, Object> input) {
  final bytes = input['bytes'] as Uint8List;
  img.Decoder.defaultMaxPixels = 4 * 1024 * 1024;
  final source = img.decodeImage(bytes, frame: 0);
  if (source == null) throw StateError('The preview image could not be decoded.');
  final x = input['x'] as int;
  final y = input['y'] as int;
  final size = input['size'] as int;
  final safeSize = size.clamp(1, math.min(source.width, source.height)).toInt();
  final cropped = img.copyCrop(
    source,
    x: x.clamp(0, source.width - safeSize).toInt(),
    y: y.clamp(0, source.height - safeSize).toInt(),
    width: safeSize,
    height: safeSize,
  );
  final output = img.copyResize(cropped, width: 1024, height: 1024);
  return Uint8List.fromList(img.encodeJpg(output, quality: 88));
}
