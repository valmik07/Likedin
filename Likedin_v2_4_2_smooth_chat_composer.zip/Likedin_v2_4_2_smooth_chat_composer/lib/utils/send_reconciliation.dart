/// Runs [send]; if it throws, asks [lookup] whether the server committed the
/// message anyway (e.g. the HTTP response timed out after the INSERT). A found
/// id is treated as success. If nothing was committed, or the lookup itself
/// fails, the ORIGINAL send error is rethrown so callers see the real cause.
Future<String> sendWithReconciliation({
  required Future<String?> Function() send,
  required Future<String?> Function() lookup,
}) async {
  String? id;
  try {
    id = await send();
  } catch (error, trace) {
    String? reconciled;
    try {
      reconciled = await lookup();
    } catch (_) {
      reconciled = null;
    }
    if (reconciled != null && reconciled.isNotEmpty) return reconciled;
    Error.throwWithStackTrace(error, trace);
  }
  if (id != null && id.isNotEmpty) return id;
  // The call "succeeded" but returned no readable id: confirm by client id.
  final reconciled = await lookup();
  if (reconciled != null && reconciled.isNotEmpty) return reconciled;
  throw StateError(
      'The server did not confirm this message. Retry the same draft; it will reuse the same message ID.');
}
