/// Runs bounded receipt acknowledgements against fresh ID snapshots.
///
/// A message can arrive while [acknowledgeOnServer] is in flight. The next
/// pass takes a new snapshot so that message is acknowledged separately and
/// is never marked locally by the earlier pass prematurely.
Future<int> acknowledgePendingReceiptPasses({
  required Set<String> Function() pendingIds,
  required Future<void> Function() acknowledgeOnServer,
  required void Function(Set<String> ids) applyLocally,
  int maxPasses = 3,
}) async {
  var passes = 0;
  while (passes < maxPasses) {
    final snapshot = Set<String>.of(pendingIds());
    if (snapshot.isEmpty) break;
    await acknowledgeOnServer();
    applyLocally(snapshot);
    passes++;
  }
  return passes;
}
