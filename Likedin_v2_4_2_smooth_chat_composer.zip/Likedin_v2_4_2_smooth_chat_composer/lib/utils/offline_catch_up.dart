import '../backend/realtime_messaging_service.dart';

class CatchUpResult {
  const CatchUpResult(this.messages, {required this.capped, required this.pagesFetched});

  /// Oldest-first newest page plus any gap pages that were fetched.
  final List<RemoteMessage> messages;

  /// True when the page budget ran out before the gap closed. The caller must
  /// drop its older, now non-contiguous window and let "Load older" fill in.
  final bool capped;
  final int pagesFetched;
}

bool _isAfter(RemoteMessage a, RemoteMessage b) {
  final byTime = a.createdAt.compareTo(b.createdAt);
  return byTime > 0 || (byTime == 0 && a.id.compareTo(b.id) > 0);
}

/// Fetches the missing middle when more than one page arrived while away.
/// Bounded by [maxPages] so a very long absence cannot loop for ever or load
/// an unbounded amount of history into memory.
Future<CatchUpResult> catchUpNewestPages({
  required List<RemoteMessage> newestPage,
  required List<RemoteMessage> known,
  required Future<List<RemoteMessage>> Function(RemoteMessage cursor) fetchOlder,
  required int pageSize,
  int maxPages = 20,
}) async {
  var loaded = newestPage;
  final committed = known.where((m) => m.clientMessageId == null || m.id != m.clientMessageId).toList();
  if (committed.isEmpty || loaded.length < pageSize) {
    return CatchUpResult(loaded, capped: false, pagesFetched: 0);
  }
  final knownIds = committed.map((m) => m.id).toSet();
  final newestKnown = committed.reduce((a, b) => _isAfter(a, b) ? a : b);
  var gap = loaded.every((m) => !knownIds.contains(m.id)) && _isAfter(loaded.first, newestKnown);
  var pages = 0;
  while (gap) {
    if (pages >= maxPages) {
      return CatchUpResult(loaded, capped: true, pagesFetched: pages);
    }
    final cursor = loaded.first;
    final page = await fetchOlder(cursor);
    pages++;
    if (page.isEmpty) break;
    // A malformed/unstable cursor must not create an endless catch-up loop.
    if (!_isAfter(cursor, page.last)) break;
    loaded = [...page, ...loaded];
    final overlapsKnown = page.any((m) => knownIds.contains(m.id));
    final reachedKnownBoundary = !_isAfter(page.first, newestKnown);
    gap = page.length >= pageSize && !overlapsKnown && !reachedKnownBoundary;
  }
  return CatchUpResult(loaded, capped: false, pagesFetched: pages);
}
