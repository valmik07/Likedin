import '../backend/realtime_messaging_service.dart';

bool _isServerCopy(RemoteMessage m) =>
    m.clientMessageId == null || m.id != m.clientMessageId;

/// Combines two copies of the same logical message (same client ID).
///
/// Precedence rules (v1.9.17):
///  1. Delete-for-everyone always wins. A tombstone is terminal, so a stale
///     copy that still carries text/edits can never resurrect the message.
///  2. Otherwise the copy with the later `editedAt` supplies the text; an
///     edited copy beats an unedited one; with no edits, [incoming] (the
///     copy later in the source list) wins.
///  3. Receipts are merged field by field (first non-null), so an edit never
///     loses a read tick and a read tick never reverts an edit.
///  4. The server row ID and server timestamp are kept over optimistic ones.
RemoteMessage mergeMessageCopies(RemoteMessage existing, RemoteMessage incoming) {
  final existingDeleted = existing.deletedForEveryoneAt != null;
  final incomingDeleted = incoming.deletedForEveryoneAt != null;

  RemoteMessage content;
  if (existingDeleted != incomingDeleted) {
    content = existingDeleted ? existing : incoming;
  } else if (existingDeleted && incomingDeleted) {
    content = incoming.deletedMediaPath != null || existing.deletedMediaPath == null
        ? incoming
        : existing;
  } else {
    final a = existing.editedAt;
    final b = incoming.editedAt;
    if (a != null && b != null) {
      content = b.isBefore(a) ? existing : incoming;
    } else if (a != null) {
      content = existing;
    } else {
      content = incoming;
    }
  }

  final identity = _isServerCopy(incoming) || !_isServerCopy(existing) ? incoming : existing;
  final other = identical(identity, incoming) ? existing : incoming;
  DateTime? firstNonNull(DateTime? x, DateTime? y) => x ?? y;

  return RemoteMessage(
    id: identity.id,
    clientMessageId: identity.clientMessageId ?? other.clientMessageId,
    senderId: identity.senderId,
    recipientId: identity.recipientId,
    text: content.text,
    createdAt: identity.createdAt,
    deliveredAt: firstNonNull(incoming.deliveredAt, existing.deliveredAt),
    readAt: firstNonNull(incoming.readAt, existing.readAt),
    replyToMessageId: content.replyToMessageId ?? other.replyToMessageId,
    editedAt: content.editedAt,
    deletedForEveryoneAt: content.deletedForEveryoneAt,
    deletedMediaPath: content.deletedMediaPath,
  );
}

/// Merges database rows and optimistic local rows using the stable client id,
/// then sorts chronologically (ties broken by row id).
List<RemoteMessage> mergeMessagesByClientId(Iterable<RemoteMessage> source) {
  final canonical = <String, RemoteMessage>{};
  for (final message in source) {
    final clientId = message.clientMessageId;
    final key = clientId != null && clientId.isNotEmpty
        ? 'client:$clientId'
        : 'row:${message.id}';
    final existing = canonical[key];
    canonical[key] = existing == null ? message : mergeMessageCopies(existing, message);
  }
  return canonical.values.toList()
    ..sort((a, b) {
      final byTime = a.createdAt.compareTo(b.createdAt);
      return byTime != 0 ? byTime : a.id.compareTo(b.id);
    });
}

/// Applies a local delivered/read receipt ONLY to the messages whose ids are in
/// [onlyIds]. The ids are a snapshot taken before the server call, so a message
/// that arrives while the RPC is in flight is not shown as delivered locally
/// (which would stop it from ever being acknowledged to the sender).
List<RemoteMessage> applyReceiptToIds(
  List<RemoteMessage> messages, {
  required String me,
  required Set<String> onlyIds,
  required DateTime now,
  bool delivered = false,
  bool read = false,
}) {
  return [
    for (final m in messages)
      if (m.recipientId != me || !onlyIds.contains(m.id) || (!delivered && !read))
        m
      else
        RemoteMessage(
          id: m.id,
          clientMessageId: m.clientMessageId,
          senderId: m.senderId,
          recipientId: m.recipientId,
          text: m.text,
          createdAt: m.createdAt,
          deliveredAt: m.deliveredAt ?? now,
          readAt: read ? (m.readAt ?? now) : m.readAt,
          replyToMessageId: m.replyToMessageId,
          editedAt: m.editedAt,
          deletedForEveryoneAt: m.deletedForEveryoneAt,
          deletedMediaPath: m.deletedMediaPath,
        ),
  ];
}

/// Ids of committed messages that need their reactions fetched. Passing an
/// empty [hydrated] set (after resume/reconnect) refreshes every message.
List<String> reactionIdsToFetch(Iterable<RemoteMessage> messages, Set<String> hydrated) => [
      for (final m in messages)
        if (_isServerCopy(m) && !hydrated.contains(m.id)) m.id,
    ];
