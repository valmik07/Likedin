import 'package:flutter/material.dart';

const String likedinEmojiFontFamily = 'NotoColorEmoji';

/// Matches only genuine Unicode emoji sequences (including Android 16 /
/// Unicode 16.0 glyphs, ZWJ chains, skin-tone modifiers, flags, and keycap
/// sequences like 1️⃣) while NEVER matching plain ASCII spaces, digits (0-9),
/// or punctuation so normal text always uses the native system font.
final RegExp _likedinEmojiRunRegex = RegExp(
  r'(?:[0-9#*]\uFE0F?\u20E3'
  r'|[\u{1F1E6}-\u{1F1FF}]{2}'
  r'|[\u{1F000}-\u{1FAFF}\u2600-\u27BF\u231A-\u23FA\u2B05-\u2B55\u203C\u2049\u2934\u2935\u3030\u303D\u3297\u3299]'
  r'[\uFE0F\u{1F3FB}-\u{1F3FF}\u{E0020}-\u{E007F}]*'
  r'(?:\u200D[\u{1F000}-\u{1FAFF}\u2600-\u27BF\u231A-\u23FA\u2B05-\u2B55\u2640\u2642\u2695\u2696\u2708\u2764][\uFE0F\u{1F3FB}-\u{1F3FF}\u{E0020}-\u{E007F}]*)*)',
  unicode: true,
);

/// Splits [text] into runs where only emoji sequences use [likedinEmojiFontFamily].
List<InlineSpan> likedinEmojiSpans(String text, {TextStyle? style}) {
  if (text.isEmpty) return const <InlineSpan>[];
  final matches = _likedinEmojiRunRegex.allMatches(text);
  if (matches.isEmpty) {
    return <InlineSpan>[TextSpan(text: text, style: style)];
  }
  final emojiStyle = (style ?? const TextStyle()).copyWith(
    fontFamily: likedinEmojiFontFamily,
  );
  final spans = <InlineSpan>[];
  var cursor = 0;
  for (final match in matches) {
    if (match.start > cursor) {
      spans.add(TextSpan(text: text.substring(cursor, match.start), style: style));
    }
    spans.add(TextSpan(text: match.group(0), style: emojiStyle));
    cursor = match.end;
  }
  if (cursor < text.length) {
    spans.add(TextSpan(text: text.substring(cursor), style: style));
  }
  return spans;
}

/// Builds a single [TextSpan] tree with [likedinEmojiFontFamily] scoped strictly
/// to emoji sequences.
TextSpan likedinEmojiSpan(String text, {TextStyle? style}) =>
    TextSpan(style: style, children: likedinEmojiSpans(text, style: style));

/// A [TextEditingController] that renders Android 16 emojis using the bundled
/// NotoColorEmoji font inside TextFields without affecting ASCII spaces or digits.
class EmojiTextEditingController extends TextEditingController {
  EmojiTextEditingController({super.text});

  @override
  TextSpan buildTextSpan({
    required BuildContext context,
    TextStyle? style,
    required bool withComposing,
  }) {
    final composingRegionOutOfRange =
        !value.isComposingRangeValid || !withComposing;
    if (composingRegionOutOfRange) {
      return likedinEmojiSpan(text, style: style);
    }
    final composingStyle = (style ?? const TextStyle()).merge(
      const TextStyle(decoration: TextDecoration.underline),
    );
    return TextSpan(
      style: style,
      children: <InlineSpan>[
        ...likedinEmojiSpans(value.composing.textBefore(text), style: style),
        ...likedinEmojiSpans(
          value.composing.textInside(text),
          style: composingStyle,
        ),
        ...likedinEmojiSpans(value.composing.textAfter(text), style: style),
      ],
    );
  }
}
