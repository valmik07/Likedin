/// Distinguishes a real long-press recording from a plain tap on the mic.
///
/// Flutter fires `onLongPressCancel` for every ordinary tap (the long-press
/// recogniser is rejected when the tap wins). Treating that as "discard" threw
/// away recordings that were being stopped by tapping. Cancel may only discard
/// when this guard saw the long-press actually begin recording.
class VoiceGestureGuard {
  bool _longPressRecording = false;

  bool get longPressRecording => _longPressRecording;

  void longPressStarted() => _longPressRecording = true;

  /// Forget any in-progress gesture (recording stopped by timer/app pause).
  void reset() => _longPressRecording = false;

  /// Called from onLongPressEnd. Returns true if the gesture owned a recording.
  bool longPressEnded() {
    final owned = _longPressRecording;
    _longPressRecording = false;
    return owned;
  }

  /// Called from onLongPressCancel. Returns true only when a long-press
  /// recording was in progress and should be discarded.
  bool shouldDiscardOnCancel() {
    final owned = _longPressRecording;
    _longPressRecording = false;
    return owned;
  }
}
