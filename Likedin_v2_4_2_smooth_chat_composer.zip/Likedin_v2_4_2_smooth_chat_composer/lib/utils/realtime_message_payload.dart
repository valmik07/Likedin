/// Resolves message text from either the current or legacy schema columns.
/// Realtime UPDATE payloads may include a key whose value is null/empty, so
/// key presence must never be treated as proof that message text was received.
String resolveRealtimeMessageBody(
  Map<String, dynamic> row, {
  required String fallback,
}) {
  for (final key in const <String>['body_payload', 'encrypted_payload', 'ciphertext']) {
    final value = row[key];
    if (value != null && value.toString().isNotEmpty) return value.toString();
  }
  return fallback;
}
