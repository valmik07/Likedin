/// Likedin's message limit is measured in Unicode code points, not UTF-16
/// code units or user-perceived grapheme clusters. PostgreSQL char_length(text)
/// uses the same code-point count for valid UTF-8 input.
const int likedinMaxMessageCodePoints = 10000;

int likedinMessageCodePointLength(String value) => value.runes.length;

String likedinTruncateMessage(String value) =>
    String.fromCharCodes(value.runes.take(likedinMaxMessageCodePoints));
