/// Public Supabase client configuration. These values are safe for client apps.
/// Never add a Supabase secret/service-role key to this file or an APK.
class BackendConfig {
  const BackendConfig._();

  static const supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: 'https://rjkexkvubkboexnsktsh.supabase.co',
  );
  static const supabaseAnonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: 'sb_publishable_ICqX0gxXzfzW4K84kodizA_tIvSoh7n',
  );

  static bool get isConfigured =>
      supabaseUrl.startsWith('https://') && supabaseAnonKey.startsWith('sb_publishable_');
}
