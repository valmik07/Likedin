import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/foundation.dart';

/// Retrieves TURN credentials from the authenticated Supabase Edge Function.
/// TURN credentials are never embedded in the APK or source repository.
class TurnConfigService {
  TurnConfigService(this._client);
  final SupabaseClient _client;

  /// Public STUN discovery is available immediately, even when the private
  /// TURN endpoint is cold-starting, rate-limited, or temporarily offline.
  /// STUN cannot traverse every NAT, but it is a useful direct-connect fallback.
  static const List<Map<String, dynamic>> fallbackIceServers = <Map<String, dynamic>>[
    {'urls': 'stun:stun.l.google.com:19302'},
    {'urls': 'stun:stun1.l.google.com:19302'},
  ];

  Future<List<Map<String, dynamic>>> fetchIceServers() async {
    final user = _client.auth.currentUser;
    if (user == null) return fallbackIceServers;

    try {
      final response = await _client.functions
          .invoke('get-turn-config')
          .timeout(const Duration(seconds: 3));
      final body = response.data;
      if (body is! Map || body['iceServers'] is! List) {
        debugPrint('TURN configuration response was invalid; using STUN fallback.');
        return fallbackIceServers;
      }
      final servers = (body['iceServers'] as List)
          .whereType<Map>()
          .map((item) => Map<String, dynamic>.from(item))
          .where((item) => item['urls'] != null)
          .toList(growable: true);
      // Always retain a direct STUN path even when the provider only returns
      // TURN URLs. The TURN endpoint remains an enhancement, not a hard gate.
      final merged = <Map<String, dynamic>>[...fallbackIceServers];
      for (final server in servers) {
        final urls = server['urls'];
        final key = urls is List ? urls.join(',') : urls.toString();
        final alreadyPresent = merged.any((existing) {
          final existingUrls = existing['urls'];
          final existingKey = existingUrls is List ? existingUrls.join(',') : existingUrls.toString();
          return existingKey == key;
        });
        if (!alreadyPresent) merged.add(server);
      }
      return merged;
    } catch (error) {
      debugPrint('TURN configuration fetch failed; using STUN fallback: $error');
      return fallbackIceServers;
    }
  }

  Future<Map<String, dynamic>> createPeerConnectionConfiguration() async => {
        'iceServers': await fetchIceServers(),
        'sdpSemantics': 'unified-plan',
      };
}
