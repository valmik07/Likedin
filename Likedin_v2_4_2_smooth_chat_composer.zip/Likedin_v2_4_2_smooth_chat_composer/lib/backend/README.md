Backend configuration constants are defined in `backend_config.dart`.
They are deliberately not activated by `main.dart` in this increment. The
existing app therefore keeps its known-working local behaviour until auth,
key exchange, and message synchronization are implemented together.
