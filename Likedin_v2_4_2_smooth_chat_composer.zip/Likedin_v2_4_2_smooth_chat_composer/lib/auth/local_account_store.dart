
import 'dart:convert';
import 'dart:math';

import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class LikedinAccount {
  const LikedinAccount({
    required this.displayName,
    required this.likedinId,
    required this.salt,
    required this.passwordHash,
    required this.createdAt,
  });

  final String displayName;
  final String likedinId;
  final String salt;
  final String passwordHash;
  final String createdAt;

  Map<String, Object?> toJson() => {
        'displayName': displayName,
        'likedinId': likedinId,
        'salt': salt,
        'passwordHash': passwordHash,
        'createdAt': createdAt,
      };

  factory LikedinAccount.fromJson(Map<String, dynamic> json) =>
      LikedinAccount(
        displayName: json['displayName'] as String,
        likedinId: json['likedinId'] as String,
        salt: json['salt'] as String,
        passwordHash: json['passwordHash'] as String,
        createdAt: json['createdAt'] as String,
      );
}

/// Local account registry for this installation. It intentionally stores no
/// plaintext passwords. A future shared service is required to enforce a
/// two-account limit across multiple devices.
class LocalAccountStore {
  LocalAccountStore({FlutterSecureStorage? storage})
      : _storage = storage ?? const FlutterSecureStorage();

  static const int maxAccounts = 2;
  static const String _storageKey = 'likedin.local.accounts.v1';
  static const int _iterations = 80000;
  final FlutterSecureStorage _storage;
  final Pbkdf2 _kdf = Pbkdf2(
    macAlgorithm: Hmac.sha256(),
    iterations: _iterations,
    bits: 256,
  );

  Future<List<LikedinAccount>> listAccounts() async {
    final raw = await _storage.read(key: _storageKey);
    if (raw == null || raw.isEmpty) return [];
    final decoded = jsonDecode(raw) as List<dynamic>;
    return decoded
        .map((item) =>
            LikedinAccount.fromJson(item as Map<String, dynamic>))
        .toList(growable: false);
  }

  Future<LikedinAccount> createAccount({
    required String displayName,
    required String likedinId,
    required String password,
  }) async {
    final name = displayName.trim();
    final id = likedinId.trim().toLowerCase();
    if (name.isEmpty) throw const AccountException('Enter your display name.');
    if (!RegExp(r'^[a-z0-9._]{3,20}$').hasMatch(id)) {
      throw const AccountException(
          'ID must be 3–20 characters: letters, numbers, dots or underscores.');
    }
    if (password.length < 8) {
      throw const AccountException('Password must be at least 8 characters.');
    }

    final accounts = await listAccounts();
    if (accounts.length >= maxAccounts) {
      throw const AccountException(
          'This device already has the maximum of 2 Likedin accounts.');
    }
    if (accounts.any((account) => account.likedinId == id)) {
      throw const AccountException('That Likedin ID is already taken on this device.');
    }

    final random = Random.secure();
    final saltBytes =
        List<int>.generate(16, (_) => random.nextInt(256), growable: false);
    final hash = await _derive(password, saltBytes);
    final account = LikedinAccount(
      displayName: name,
      likedinId: id,
      salt: base64Encode(saltBytes),
      passwordHash: base64Encode(hash),
      createdAt: DateTime.now().toUtc().toIso8601String(),
    );
    final updated = [...accounts, account];
    await _storage.write(
      key: _storageKey,
      value: jsonEncode(updated.map((item) => item.toJson()).toList()),
    );
    return account;
  }

  Future<LikedinAccount?> signIn({
    required String likedinId,
    required String password,
  }) async {
    final id = likedinId.trim().toLowerCase();
    final accounts = await listAccounts();
    for (final account in accounts) {
      if (account.likedinId != id) continue;
      final hash = await _derive(password, base64Decode(account.salt));
      if (_constantTimeEquals(hash, base64Decode(account.passwordHash))) {
        return account;
      }
      return null;
    }
    return null;
  }

  Future<List<int>> _derive(String password, List<int> salt) async {
    final key = await _kdf.deriveKey(
      secretKey: SecretKey(utf8.encode(password)),
      nonce: salt,
    );
    return key.extractBytes();
  }

  bool _constantTimeEquals(List<int> a, List<int> b) {
    if (a.length != b.length) return false;
    var difference = 0;
    for (var i = 0; i < a.length; i++) {
      difference |= a[i] ^ b[i];
    }
    return difference == 0;
  }
}

class AccountException implements Exception {
  const AccountException(this.message);
  final String message;
  @override
  String toString() => message;
}
