package com.example.likedin

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

class CallForegroundService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                "likedin_active_call",
                "Active call",
                NotificationManager.IMPORTANCE_LOW,
            ),
        )
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val notification = Notification.Builder(this, "likedin_active_call")
            .setSmallIcon(R.drawable.likedin_notification)
            .setContentTitle("Likedin call in progress")
            .setContentText("Tap to return to your call")
            .setOngoing(true)
            .setContentIntent(openApp)
            .build()

        var serviceType = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        if (intent?.getBooleanExtra("video", false) == true) {
            serviceType = serviceType or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(4711, notification, serviceType)
            } else {
                startForeground(4711, notification)
            }
        } catch (error: Exception) {
            android.util.Log.w("LikedinCallService", "Could not start foreground call service", error)
            stopSelf()
        }
        return START_NOT_STICKY
    }
}
