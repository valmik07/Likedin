# Likedin release shrinker rules.
# Flutter engine/plugin entry points and native/JNI-backed WebRTC types.
-keep class io.flutter.** { *; }
-keep class io.flutter.plugins.** { *; }
-keep class com.google.firebase.** { *; }
-keep class org.webrtc.** { *; }
-keep class com.cloudwebrtc.webrtc.** { *; }
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# Preserve enum values/valueOf across plugins and JSON deserializers.
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# flutter_local_notifications 18.x uses Gson TypeToken and reflection to
# restore and cancel scheduled notifications. Keep Gson metadata intact.
-keep class com.google.gson.** { *; }
-keep class com.google.gson.reflect.TypeToken { *; }
-keep class * extends com.google.gson.reflect.TypeToken
-keep class * extends com.google.gson.TypeAdapter
-keep class * implements com.google.gson.TypeAdapterFactory
-keep class * implements com.google.gson.JsonSerializer
-keep class * implements com.google.gson.JsonDeserializer
-keepclassmembers,allowobfuscation class * {
    @com.google.gson.annotations.SerializedName <fields>;
}
-keep class com.dexterous.flutterlocalnotifications.** { *; }

-dontwarn org.webrtc.**
# This app does not use Play Feature Delivery / deferred components.
-dontwarn com.google.android.play.core.**
-dontwarn io.flutter.embedding.engine.deferredcomponents.**
