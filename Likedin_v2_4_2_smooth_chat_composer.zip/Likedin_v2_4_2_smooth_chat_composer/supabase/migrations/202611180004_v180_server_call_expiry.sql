begin;

-- Server-owned no-answer expiry. The existing missed-call trigger still emits
-- the missed notification when this UPDATE changes ringing -> missed.
create index if not exists likedin_calls_ringing_expiry_idx
  on public.likedin_calls(created_at)
  where status = 'ringing';

create or replace function public.likedin_expire_ringing_calls()
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_expired integer;
begin
  update public.likedin_calls
     set status = 'missed',
         ended_at = coalesce(ended_at, now())
   where status = 'ringing'
     and created_at <= now() - interval '60 seconds';
  get diagnostics v_expired = row_count;
  return v_expired;
end;
$$;
revoke all on function public.likedin_expire_ringing_calls() from public;
grant execute on function public.likedin_expire_ringing_calls() to service_role;

-- Schedule the expiry sweep when Supabase Cron is enabled. If pg_cron is not
-- enabled in this project, the function remains ready and the job must be
-- created from Dashboard -> Integrations -> Cron.
do $$
begin
  if to_regclass('cron.job') is not null then
    begin
      execute $q$
        select cron.unschedule(jobid)
          from cron.job
         where jobname = 'likedin-expire-ringing-calls'
      $q$;
      execute $q$
        select cron.schedule(
          'likedin-expire-ringing-calls',
          '* * * * *',
          'select public.likedin_expire_ringing_calls();'
        )
      $q$;
    exception when others then
      raise notice 'Core call-expiry function installed, but Cron scheduling needs Dashboard setup: %', sqlerrm;
    end;
  else
    raise notice 'Supabase Cron is not enabled: schedule public.likedin_expire_ringing_calls() every minute in Dashboard -> Integrations -> Cron.';
  end if;
end;
$$;
commit;
notify pgrst, 'reload schema';
