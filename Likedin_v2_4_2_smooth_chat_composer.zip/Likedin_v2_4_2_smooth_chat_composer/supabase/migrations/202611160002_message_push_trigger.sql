-- Likedin v1.7.43: explicitly connect new messages to the FCM message sender.
-- The old setup relied on a Dashboard Database Webhook, which is easy to omit
-- when rebuilding the project. Reuse the existing Vault secret and Edge Function.

begin;

create or replace function public.likedin_notify_message_push()
returns trigger
language plpgsql
security definer
set search_path = public, vault, net
as $$
declare
  webhook_secret text;
begin
  if new.sender_id is null or new.recipient_id is null then
    return new;
  end if;

  select decrypted_secret
    into webhook_secret
    from vault.decrypted_secrets
   where name = 'LIKEDIN_PUSH_WEBHOOK_SECRET'
   limit 1;

  if webhook_secret is null or webhook_secret = '' then
    raise warning 'Likedin message push skipped: webhook secret is unavailable';
    return new;
  end if;

  perform net.http_post(
    url := 'https://rjkexkvubkboexnsktsh.supabase.co/functions/v1/send-message-push',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'x-likedin-webhook-secret', webhook_secret
    ),
    body := jsonb_build_object('record', to_jsonb(new)),
    timeout_milliseconds := 5000
  );

  return new;
end;
$$;

drop trigger if exists likedin_message_push on public.messages;
create trigger likedin_message_push
after insert on public.messages
for each row
when (new.sender_id is not null and new.recipient_id is not null)
execute function public.likedin_notify_message_push();

commit;
