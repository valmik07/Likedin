-- Likedin 1.7.8 compatibility migration.
-- This restores compatibility between the shipped Flutter client and the
-- earlier messages schema. It DOES NOT enable end-to-end encryption.
-- The current Flutter client still sends plaintext; do not claim E2EE.
--
-- Run only if the earlier Likedin messaging migrations have already been applied.
begin;

alter table public.messages
  add column if not exists encrypted_payload text,
  add column if not exists client_message_id uuid,
  add column if not exists delivered_at timestamptz,
  add column if not exists read_at timestamptz;

-- Preserve any existing ciphertext column contents for compatibility.
do $$
begin
  if exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='messages' and column_name='ciphertext'
  ) then
    execute 'update public.messages set encrypted_payload = ciphertext where encrypted_payload is null';
  end if;
end $$;

create unique index if not exists messages_sender_client_id_uq
  on public.messages(sender_id, client_message_id)
  where client_message_id is not null;

create or replace function public.likedin_send_message(
  p_recipient_id uuid,
  p_payload text,
  p_client_message_id uuid
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_sender uuid := auth.uid();
  v_id uuid;
begin
  if v_sender is null then raise exception 'Authentication required'; end if;
  if p_payload is null or length(p_payload) = 0 or length(p_payload) > 10000 then
    raise exception 'Message must contain 1 to 10000 characters';
  end if;
  if p_recipient_id is null or p_recipient_id = v_sender then
    raise exception 'Invalid recipient';
  end if;
  if not exists (select 1 from public.account_slots s where s.user_id = v_sender)
     or not exists (select 1 from public.account_slots s where s.user_id = p_recipient_id) then
    raise exception 'Recipient is not a registered Likedin account';
  end if;

  insert into public.messages(sender_id, recipient_id, encrypted_payload, client_message_id)
  values (v_sender, p_recipient_id, p_payload, p_client_message_id)
  on conflict (sender_id, client_message_id) where client_message_id is not null
  do update set client_message_id = excluded.client_message_id
  returning id into v_id;
  return v_id;
end;
$$;

revoke all on function public.likedin_send_message(uuid, text, uuid) from public;
grant execute on function public.likedin_send_message(uuid, text, uuid) to authenticated;

commit;
notify pgrst, 'reload schema';
