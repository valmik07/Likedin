begin;
create table if not exists public.likedin_push_tokens (
  user_id uuid not null references auth.users(id) on delete cascade,
  token text not null,
  platform text not null default 'android' check (platform in ('android')),
  updated_at timestamptz not null default now(),
  primary key (user_id, token)
);
alter table public.likedin_push_tokens enable row level security;
drop policy if exists "Users manage own push tokens" on public.likedin_push_tokens;
create policy "Users manage own push tokens"
on public.likedin_push_tokens
for all to authenticated
using (user_id = (select auth.uid()))
with check (user_id = (select auth.uid()));
commit;
notify pgrst, 'reload schema';
