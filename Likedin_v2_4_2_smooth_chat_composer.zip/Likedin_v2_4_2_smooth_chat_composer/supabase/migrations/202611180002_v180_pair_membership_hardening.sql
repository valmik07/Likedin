begin;

-- Defense in depth: only the two assigned pair members may use message,
-- call, signaling, and reaction rows. Do not restore broad UPDATE policies;
-- writes continue through the existing SECURITY DEFINER RPCs.
drop policy if exists "pair members can read their messages" on public.messages;
create policy "pair members can read their messages"
on public.messages for select to authenticated
using (
  auth.uid() in (sender_id, recipient_id)
  and public.likedin_is_pair_member(sender_id)
  and public.likedin_is_pair_member(recipient_id)
);
drop policy if exists "users can send as themselves" on public.messages;
create policy "users can send as themselves"
on public.messages for insert to authenticated
with check (
  auth.uid() = sender_id
  and public.likedin_is_pair_member(sender_id)
  and public.likedin_is_pair_member(recipient_id)
);

-- Calls are readable/creatable only when both participants are the approved pair.
drop policy if exists "participants read calls" on public.likedin_calls;
create policy "participants read calls"
on public.likedin_calls for select to authenticated
using (
  auth.uid() in (caller_id, callee_id)
  and public.likedin_is_pair_member(caller_id)
  and public.likedin_is_pair_member(callee_id)
);
drop policy if exists "caller creates call" on public.likedin_calls;
create policy "caller creates call"
on public.likedin_calls for insert to authenticated
with check (
  auth.uid() = caller_id
  and public.likedin_is_pair_member(caller_id)
  and public.likedin_is_pair_member(callee_id)
);

-- Call signaling is similarly constrained to calls involving only the pair.
drop policy if exists "participants read signals" on public.likedin_call_signals;
create policy "participants read signals"
on public.likedin_call_signals for select to authenticated
using (
  exists (
    select 1 from public.likedin_calls c
     where c.id = call_id
       and auth.uid() in (c.caller_id, c.callee_id)
       and public.likedin_is_pair_member(c.caller_id)
       and public.likedin_is_pair_member(c.callee_id)
  )
);
drop policy if exists "participants send signals" on public.likedin_call_signals;
create policy "participants send signals"
on public.likedin_call_signals for insert to authenticated
with check (
  sender_id = auth.uid()
  and public.likedin_is_pair_member(sender_id)
  and exists (
    select 1 from public.likedin_calls c
     where c.id = call_id
       and auth.uid() in (c.caller_id, c.callee_id)
       and public.likedin_is_pair_member(c.caller_id)
       and public.likedin_is_pair_member(c.callee_id)
  )
);

-- Reactions are fetched only for visible conversation messages; the server RPC
-- also rejects non-pair accounts before mutating a reaction.
drop policy if exists "pair participants can read message reactions" on public.message_reactions;
create policy "pair participants can read message reactions"
on public.message_reactions for select to authenticated
using (
  public.likedin_is_pair_member(auth.uid())
  and exists (
    select 1 from public.messages m
     where m.id = message_id
       and auth.uid() in (m.sender_id, m.recipient_id)
       and public.likedin_is_pair_member(m.sender_id)
       and public.likedin_is_pair_member(m.recipient_id)
  )
);

create or replace function public.likedin_set_message_reaction(
  p_message_id uuid, p_emoji text, p_active boolean
) returns void
language plpgsql security definer set search_path = '' as $$
declare
  v_uid uuid := auth.uid();
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  if not public.likedin_is_pair_member(v_uid) then
    raise exception 'Not an approved Likedin pair member';
  end if;
  if p_emoji is null or length(p_emoji) < 1 or length(p_emoji) > 16 then
    raise exception 'Invalid reaction';
  end if;
  if not exists (
    select 1 from public.messages m
     where m.id = p_message_id
       and v_uid in (m.sender_id, m.recipient_id)
       and public.likedin_is_pair_member(m.sender_id)
       and public.likedin_is_pair_member(m.recipient_id)
       and m.deleted_for_everyone_at is null
  ) then
    raise exception 'Message unavailable';
  end if;
  if p_active then
    insert into public.message_reactions(message_id, user_id, emoji)
    values (p_message_id, v_uid, p_emoji)
    on conflict do nothing;
  else
    delete from public.message_reactions
     where message_id = p_message_id and user_id = v_uid and emoji = p_emoji;
  end if;
end;
$$;
revoke all on function public.likedin_set_message_reaction(uuid, text, boolean) from public;
grant execute on function public.likedin_set_message_reaction(uuid, text, boolean) to authenticated;

-- Presence mutation requires an assigned pair slot; it cannot create stray profiles.
create or replace function public.likedin_set_presence(p_online boolean)
returns void
language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if not public.likedin_is_pair_member(auth.uid()) then
    raise exception 'Not an approved Likedin pair member';
  end if;
  update public.profiles
     set is_online = coalesce(p_online, false), last_seen_at = now(), updated_at = now()
   where user_id = auth.uid();
end;
$$;
revoke all on function public.likedin_set_presence(boolean) from public;
grant execute on function public.likedin_set_presence(boolean) to authenticated;

-- The call status RPC remains participant-authorized, and now also requires
-- both call participants to belong to the approved pair.
create or replace function public.likedin_update_call_status(p_call_id uuid, p_new_status text)
returns void
language plpgsql security definer set search_path = '' as $$
declare
  v_uid uuid := auth.uid();
  v_call public.likedin_calls%rowtype;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  if not public.likedin_is_pair_member(v_uid) then
    raise exception 'Not an approved Likedin pair member';
  end if;
  if p_new_status not in ('accepted', 'rejected', 'missed', 'ended') then
    raise exception 'Invalid call status transition: %', p_new_status;
  end if;
  select * into v_call from public.likedin_calls where id = p_call_id for update;
  if not found then raise exception 'Call not found'; end if;
  if v_uid <> v_call.caller_id and v_uid <> v_call.callee_id then
    raise exception 'Not a participant in this call';
  end if;
  if not public.likedin_is_pair_member(v_call.caller_id)
     or not public.likedin_is_pair_member(v_call.callee_id) then
    raise exception 'Call is not between approved pair members';
  end if;
  if p_new_status = 'accepted' then
    if v_uid <> v_call.callee_id then raise exception 'Only the callee can accept a call'; end if;
    if v_call.status <> 'ringing' then raise exception 'Call is no longer ringing'; end if;
    update public.likedin_calls set status = 'accepted', answered_at = coalesce(answered_at, now()) where id = p_call_id;
  elsif p_new_status = 'rejected' then
    if v_uid <> v_call.callee_id then raise exception 'Only the callee can reject a call'; end if;
    if v_call.status <> 'ringing' then return; end if;
    update public.likedin_calls set status = 'rejected', ended_at = coalesce(ended_at, now()) where id = p_call_id;
  elsif p_new_status = 'missed' then
    if v_uid <> v_call.caller_id then raise exception 'Only the caller can mark a call missed'; end if;
    if v_call.status <> 'ringing' then return; end if;
    update public.likedin_calls set status = 'missed', ended_at = coalesce(ended_at, now()) where id = p_call_id;
  elsif p_new_status = 'ended' then
    if v_call.status in ('ended', 'rejected', 'missed') then return; end if;
    update public.likedin_calls set status = 'ended', ended_at = coalesce(ended_at, now()) where id = p_call_id;
  end if;
end;
$$;
revoke all on function public.likedin_update_call_status(uuid, text) from public;
grant execute on function public.likedin_update_call_status(uuid, text) to authenticated;

-- Delivery acknowledgements must also come from an approved pair account.
create or replace function public.likedin_mark_message_delivered(p_message_id uuid)
returns boolean language plpgsql security definer set search_path = '' as $$
declare
  changed integer;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if not public.likedin_is_pair_member(auth.uid()) then
    raise exception 'Not an approved Likedin pair member';
  end if;
  update public.messages
     set delivered_at = coalesce(delivered_at, now())
   where id = p_message_id and recipient_id = auth.uid() and delivered_at is null;
  get diagnostics changed = row_count;
  return changed > 0;
end;
$$;
revoke all on function public.likedin_mark_message_delivered(uuid) from public;
grant execute on function public.likedin_mark_message_delivered(uuid) to authenticated;

create or replace function public.likedin_mark_delivered()
returns integer language plpgsql security definer set search_path = '' as $$
declare changed integer;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if not public.likedin_is_pair_member(auth.uid()) then
    raise exception 'Not an approved Likedin pair member';
  end if;
  update public.messages
     set delivered_at = coalesce(delivered_at, now())
   where recipient_id = auth.uid() and delivered_at is null;
  get diagnostics changed = row_count;
  return changed;
end;
$$;
revoke all on function public.likedin_mark_delivered() from public;
grant execute on function public.likedin_mark_delivered() to authenticated;

create or replace function public.likedin_mark_read()
returns integer language plpgsql security definer set search_path = '' as $$
declare changed integer;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if not public.likedin_is_pair_member(auth.uid()) then
    raise exception 'Not an approved Likedin pair member';
  end if;
  update public.messages
     set delivered_at = coalesce(delivered_at, now()), read_at = coalesce(read_at, now())
   where recipient_id = auth.uid() and read_at is null;
  get diagnostics changed = row_count;
  return changed;
end;
$$;
revoke all on function public.likedin_mark_read() from public;
grant execute on function public.likedin_mark_read() to authenticated;

create or replace function public.likedin_register_push_token(p_token text)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if not public.likedin_is_pair_member(auth.uid()) then
    raise exception 'Not an approved Likedin pair member';
  end if;
  if p_token is null or length(p_token) < 20 then raise exception 'Invalid push token'; end if;
  delete from public.likedin_push_tokens
   where token = p_token and user_id <> auth.uid();
  insert into public.likedin_push_tokens(user_id, token, platform, updated_at)
  values (auth.uid(), p_token, 'android', now())
  on conflict (user_id, token) do update set updated_at = now();
end;
$$;
revoke all on function public.likedin_register_push_token(text) from public;
grant execute on function public.likedin_register_push_token(text) to authenticated;

-- Message mutation RPCs also reject legacy/unpaired Auth sessions.
create or replace function public.likedin_edit_message(p_message_id uuid, p_new_payload text)
returns boolean language plpgsql security definer set search_path = '' as $$
declare
  v_uid uuid := auth.uid();
  v_count integer;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  if not public.likedin_is_pair_member(v_uid) then raise exception 'Not an approved Likedin pair member'; end if;
  if p_new_payload is null or length(p_new_payload) < 1 or length(p_new_payload) > 10000 then
    raise exception 'Invalid message payload';
  end if;
  update public.messages
     set encrypted_payload = p_new_payload, edited_at = now()
   where id = p_message_id and sender_id = v_uid and deleted_for_everyone_at is null
     and public.likedin_is_pair_member(recipient_id);
  get diagnostics v_count = row_count;
  if v_count = 0 then raise exception 'Message unavailable or not yours'; end if;
  return true;
end;
$$;
revoke all on function public.likedin_edit_message(uuid, text) from public;
grant execute on function public.likedin_edit_message(uuid, text) to authenticated;

create or replace function public.likedin_delete_message_for_everyone_v2(p_message_id uuid)
returns boolean language plpgsql security definer set search_path = '' as $$
declare
  v_uid uuid := auth.uid();
  v_count integer;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  if not public.likedin_is_pair_member(v_uid) then raise exception 'Not an approved Likedin pair member'; end if;
  update public.messages
     set deleted_for_everyone_at = now(), encrypted_payload = '[deleted]'
   where id = p_message_id and sender_id = v_uid and deleted_for_everyone_at is null
     and public.likedin_is_pair_member(recipient_id);
  get diagnostics v_count = row_count;
  if v_count = 0 then raise exception 'Message unavailable or not yours'; end if;
  delete from public.message_reactions where message_id = p_message_id;
  return true;
end;
$$;
revoke all on function public.likedin_delete_message_for_everyone_v2(uuid) from public;
grant execute on function public.likedin_delete_message_for_everyone_v2(uuid) to authenticated;

-- Storage policies must use the SECURITY DEFINER membership helpers because
-- account_slots intentionally has no direct authenticated SELECT policy.
drop policy if exists "Likedin media upload own folder" on storage.objects;
create policy "Likedin media upload own folder"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'likedin-media'
  and auth.uid() is not null
  and (storage.foldername(name))[1] = auth.uid()::text
  and public.likedin_is_pair_member(auth.uid())
);
drop policy if exists "Likedin pair can read media" on storage.objects;
create policy "Likedin pair can read media"
on storage.objects for select to authenticated
using (
  bucket_id = 'likedin-media'
  and public.likedin_is_pair_member(auth.uid())
  and public.likedin_is_pair_member_path((storage.foldername(name))[1])
);
drop policy if exists "Likedin media owner can delete" on storage.objects;
create policy "Likedin media owner can delete"
on storage.objects for delete to authenticated
using (
  bucket_id = 'likedin-media'
  and (storage.foldername(name))[1] = auth.uid()::text
  and public.likedin_is_pair_member(auth.uid())
);
commit;
notify pgrst, 'reload schema';
