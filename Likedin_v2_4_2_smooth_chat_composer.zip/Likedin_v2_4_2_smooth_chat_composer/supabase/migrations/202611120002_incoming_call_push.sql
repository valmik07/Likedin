-- Keep message push untouched. This trigger sends a separate, short-lived
-- high-priority FCM notification for each newly-created ringing call.
create or replace function public.likedin_notify_incoming_call_push()
returns trigger
language plpgsql
security definer
set search_path = public, vault, net
as $$
declare
  webhook_secret text;
begin
  if new.status <> 'ringing' then
    return new;
  end if;

  select decrypted_secret
    into webhook_secret
    from vault.decrypted_secrets
   where name = 'LIKEDIN_PUSH_WEBHOOK_SECRET'
   limit 1;

  if webhook_secret is null or webhook_secret = '' then
    raise warning 'Likedin incoming-call push skipped: webhook secret is unavailable';
    return new;
  end if;

  perform net.http_post(
    url := 'https://rjkexkvubkboexnsktsh.supabase.co/functions/v1/send-incoming-call-push',
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'x-likedin-webhook-secret', webhook_secret
    ),
    body := jsonb_build_object('record', to_jsonb(new)),
    timeout_milliseconds := 5000
  );
  return new;
end;
$$;

drop trigger if exists likedin_incoming_call_push on public.likedin_calls;
create trigger likedin_incoming_call_push
after insert on public.likedin_calls
for each row
when (new.status = 'ringing')
execute function public.likedin_notify_incoming_call_push();
