-- v1.9.14: saving an edit with unchanged text must not mark the message as edited.
-- Same checks as the v1.8.3 definition; the only change is the no-op short circuit.
create or replace function public.likedin_edit_message(p_message_id uuid, p_new_payload text)
returns boolean
language plpgsql security definer set search_path = '' as $$
declare
  v_uid uuid := auth.uid();
  v_current text;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  if not public.likedin_is_pair_member(v_uid) then raise exception 'Not an approved Likedin pair member'; end if;
  if p_new_payload is null or char_length(p_new_payload) < 1 or char_length(p_new_payload) > 10000 then
    raise exception 'Invalid message payload (1 to 10000 Unicode code points)';
  end if;
  select m.encrypted_payload into v_current
    from public.messages m
   where m.id = p_message_id
     and m.sender_id = v_uid
     and m.deleted_for_everyone_at is null
     and public.likedin_is_pair_member(m.recipient_id)
   for update;
  if not found then raise exception 'Message unavailable or not yours'; end if;
  -- Unchanged text: succeed without touching edited_at.
  if v_current is not distinct from p_new_payload then return true; end if;
  update public.messages
     set encrypted_payload = p_new_payload, edited_at = now()
   where id = p_message_id;
  return true;
end;
$$;
revoke all on function public.likedin_edit_message(uuid, text) from public;
grant execute on function public.likedin_edit_message(uuid, text) to authenticated;
