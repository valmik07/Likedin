-- Likedin v1.8.5: cancel ringing push on call setup failure and index shared media lookups.
-- Additive migration. Does not delete messages or alter existing RLS policies.
begin;

create or replace function public.likedin_notify_missed_call_push()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  webhook_secret text;
begin
  if old.status = 'ringing' and new.status in ('missed', 'ended', 'rejected', 'failed') then
    begin
      select decrypted_secret
        into webhook_secret
        from vault.decrypted_secrets
       where name = 'LIKEDIN_PUSH_WEBHOOK_SECRET'
       limit 1;

      if coalesce(webhook_secret, '') = '' then
        raise warning 'Likedin missed-call push skipped: webhook secret is unavailable';
      else
        perform net.http_post(
          url := 'https://rjkexkvubkboexnsktsh.supabase.co/functions/v1/send-missed-call-push',
          headers := jsonb_build_object(
            'Content-Type', 'application/json',
            'x-likedin-webhook-secret', webhook_secret
          ),
          body := jsonb_build_object('record', jsonb_build_object(
            'id', new.id,
            'caller_id', new.caller_id,
            'callee_id', new.callee_id,
            'call_type', new.call_type,
            'status', new.status
          )),
          timeout_milliseconds := 5000
        );
      end if;
    exception when others then
      raise warning 'Likedin missed-call push failed: %', sqlerrm;
    end;
  end if;
  return new;
end;
$$;

revoke all on function public.likedin_notify_missed_call_push() from public;

drop trigger if exists likedin_missed_call_push on public.likedin_calls;
create trigger likedin_missed_call_push
  after update of status on public.likedin_calls
  for each row
  when (old.status = 'ringing' and new.status in ('missed', 'ended', 'rejected', 'failed'))
  execute function public.likedin_notify_missed_call_push();

create index if not exists messages_shared_media_idx
  on public.messages (created_at desc, id desc)
  where encrypted_payload like '%"__likedin_media_v1":true%'
    and deleted_for_everyone_at is null;

commit;
notify pgrst, 'reload schema';
