begin;

-- Likedin v1.8.0 core reliability/security migration.
-- Review against the live project before applying. It does not delete Auth users.
-- Unconfirmed signups no longer consume either permanent pair slot.

-- Older live projects may have the original two-column slot table.
-- Add the metadata column idempotently before any function references it.
alter table public.account_slots
  add column if not exists occupied_at timestamptz;

-- Empty slots are represented by NULL. Older installations may have retained
-- NOT NULL from a preallocated-account schema; relax it before seeding.
alter table public.account_slots alter column user_id drop not null;

update public.account_slots
   set occupied_at = now()
 where user_id is not null
   and occupied_at is null;

-- Ensure both slot rows exist so empty slots can be reserved atomically.
insert into public.account_slots(slot, user_id)
values (1, null), (2, null)
on conflict (slot) do nothing;

-- The old guard counted every auth.users row, including unconfirmed registrations.
-- Count only confirmed users, and serialize registration/confirmation races.
create or replace function public.enforce_two_global_accounts()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  confirmed_count integer;
  new_is_confirmed boolean;
begin
  perform pg_advisory_xact_lock(734921, 2);
  new_is_confirmed := new.email_confirmed_at is not null
                   or new.phone_confirmed_at is not null;
  if not new_is_confirmed then
    return new;
  end if;

  select count(*)::integer
    into confirmed_count
    from auth.users u
   where u.email_confirmed_at is not null
      or u.phone_confirmed_at is not null;

  if confirmed_count >= 2 then
    raise exception 'LIKEDIN_PAIR_FULL: both confirmed account slots are occupied'
      using errcode = '23514';
  end if;
  return new;
end;
$$;

-- Ensure the confirmation-aware guard is attached even on a partially migrated project.
drop trigger if exists likedin_two_account_limit on auth.users;
create trigger likedin_two_account_limit
before insert on auth.users
for each row execute function public.enforce_two_global_accounts();

-- One idempotent function assigns a slot/profile only after confirmation.
create or replace function public.likedin_handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_slot smallint;
  v_display_name text;
begin
  if new.email_confirmed_at is null and new.phone_confirmed_at is null then
    return new;
  end if;

  perform pg_advisory_xact_lock(734921, 2);

  if exists (select 1 from public.account_slots a where a.user_id = new.id) then
    return new;
  end if;

  select a.slot
    into v_slot
    from public.account_slots a
   where a.user_id is null
   order by a.slot
   limit 1
   for update;

  if v_slot is null then
    raise exception 'LIKEDIN_PAIR_FULL: both confirmed account slots are occupied'
      using errcode = '23514';
  end if;

  update public.account_slots
     set user_id = new.id,
         occupied_at = now()
   where slot = v_slot and user_id is null;

  if not found then
    raise exception 'LIKEDIN_PAIR_FULL: could not reserve an account slot'
      using errcode = '23514';
  end if;

  v_display_name := coalesce(
    nullif(btrim(new.raw_user_meta_data ->> 'display_name'), ''),
    nullif(split_part(coalesce(new.email, ''), '@', 1), ''),
    'Likedin user'
  );
  insert into public.profiles(user_id, display_name)
  values (new.id, v_display_name)
  on conflict (user_id) do nothing;

  return new;
end;
$$;
revoke all on function public.likedin_handle_new_user() from public;

-- Recreate both confirmation hooks. Existing unconfirmed accounts are not assigned.
drop trigger if exists likedin_new_user on auth.users;
create trigger likedin_new_user
  after insert on auth.users
  for each row execute function public.likedin_handle_new_user();

drop trigger if exists likedin_assign_slot_on_confirmation on auth.users;
create trigger likedin_assign_slot_on_confirmation
  after update of email_confirmed_at, phone_confirmed_at on auth.users
  for each row
  when (
    (old.email_confirmed_at is distinct from new.email_confirmed_at)
    or (old.phone_confirmed_at is distinct from new.phone_confirmed_at)
  )
  execute function public.likedin_handle_new_user();

-- Free only slots belonging to unconfirmed users. Do not delete users or profiles.
update public.account_slots s
   set user_id = null,
       occupied_at = null
  from auth.users u
 where s.user_id = u.id
   and u.email_confirmed_at is null
   and u.phone_confirmed_at is null;

-- Backfill confirmed users in creation order. If more than two confirmed users
-- already exist, fail visibly rather than choosing/deleting a user silently.
do $$
declare
  u record;
  v_slot smallint;
  v_confirmed_count integer;
  v_display_name text;
begin
  perform pg_advisory_xact_lock(734921, 2);

  select count(*)::integer into v_confirmed_count
    from auth.users x
   where x.email_confirmed_at is not null
      or x.phone_confirmed_at is not null;
  if v_confirmed_count > 2 then
    raise exception 'LIKEDIN_PAIR_RECONCILIATION_REQUIRED: found % confirmed Auth users; inspect auth.users and account_slots before continuing', v_confirmed_count;
  end if;

  for u in
    select id, email, raw_user_meta_data
      from auth.users
     where email_confirmed_at is not null or phone_confirmed_at is not null
     order by created_at, id
  loop
    if not exists (select 1 from public.account_slots a where a.user_id = u.id) then
      select a.slot into v_slot
        from public.account_slots a
       where a.user_id is null
       order by a.slot
       limit 1
       for update;
      if v_slot is null then
        raise exception 'LIKEDIN_PAIR_RECONCILIATION_REQUIRED: no free slot for confirmed user %', u.id;
      end if;
      update public.account_slots
         set user_id = u.id, occupied_at = now()
       where slot = v_slot and user_id is null;
    end if;

    v_display_name := coalesce(
      nullif(btrim(u.raw_user_meta_data ->> 'display_name'), ''),
      nullif(split_part(coalesce(u.email, ''), '@', 1), ''),
      'Likedin user'
    );
    insert into public.profiles(user_id, display_name)
    values (u.id, v_display_name)
    on conflict (user_id) do nothing;
  end loop;
end;
$$;

-- Single source of truth for the two approved pair accounts. SECURITY DEFINER
-- bypasses account_slots RLS while exposing only a boolean to authenticated callers.
create or replace function public.likedin_is_pair_member(p_user_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select p_user_id is not null
     and exists (select 1 from public.account_slots s where s.user_id = p_user_id);
$$;
revoke all on function public.likedin_is_pair_member(uuid) from public;
grant execute on function public.likedin_is_pair_member(uuid) to authenticated, service_role;

-- Storage object paths use a textual first folder segment. This avoids unsafe
-- UUID casts for malformed object names while still checking the private pair.
create or replace function public.likedin_is_pair_member_path(p_user_id_text text)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select p_user_id_text is not null
     and exists (select 1 from public.account_slots s where s.user_id::text = p_user_id_text);
$$;
revoke all on function public.likedin_is_pair_member_path(text) from public;
grant execute on function public.likedin_is_pair_member_path(text) to authenticated, service_role;

-- Profile reads are limited to the two assigned pair members. Use SECURITY DEFINER
-- because account_slots intentionally has no direct client SELECT policy.
create or replace function public.likedin_can_read_profile(p_profile_user_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select public.likedin_is_pair_member(auth.uid())
     and public.likedin_is_pair_member(p_profile_user_id);
$$;
revoke all on function public.likedin_can_read_profile(uuid) from public;
grant execute on function public.likedin_can_read_profile(uuid) to authenticated;

drop policy if exists "Users can view profiles" on public.profiles;
drop policy if exists "pair members can view profiles" on public.profiles;
create policy "pair members can view profiles"
on public.profiles for select to authenticated
using (public.likedin_can_read_profile(user_id));

-- Peer lookup must prove that the requester is one of the assigned pair members.
create or replace function public.likedin_get_peer_id()
returns uuid
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
  v_peer uuid;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  if not exists (select 1 from public.account_slots me where me.user_id = v_uid) then
    raise exception 'Not an approved Likedin pair member';
  end if;
  select peer.user_id into v_peer
    from public.account_slots peer
   where peer.user_id is not null and peer.user_id <> v_uid
   order by peer.slot
   limit 1;
  return v_peer;
end;
$$;
revoke all on function public.likedin_get_peer_id() from public;
grant execute on function public.likedin_get_peer_id() to authenticated;
commit;
notify pgrst, 'reload schema';


-- Authoritative timestamp for device-local clear-chat cutoffs.
create or replace function public.likedin_server_now()
returns timestamptz
language sql
stable
security invoker
set search_path = ''
as $$ select pg_catalog.now(); $$;
grant execute on function public.likedin_server_now() to authenticated;


-- Unconfirmed Auth users do not consume either account slot. Do not delete
-- auth.users rows directly from SQL: use Supabase Auth Admin API from a
-- scheduled, service-role Edge Function to prune registrations older than
-- seven days. See docs/v1.8.2_medium_reliability.md for the safe operation.
