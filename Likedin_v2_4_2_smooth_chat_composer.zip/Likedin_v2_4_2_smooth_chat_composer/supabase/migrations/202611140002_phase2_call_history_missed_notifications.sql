-- Likedin 1.7.12 Phase 2: durable call history and missed-call push.
-- Call history uses the existing likedin_calls table. This migration adds
-- indexes and a server-side push trigger for ringing -> missed transitions.

begin;

create index if not exists likedin_calls_participant_history_idx
  on public.likedin_calls (caller_id, created_at desc);
create index if not exists likedin_calls_callee_history_idx
  on public.likedin_calls (callee_id, created_at desc);

create or replace function public.likedin_notify_missed_call_push()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  webhook_secret text;
begin
  if old.status = 'ringing' and new.status = 'missed' then
    select decrypted_secret into webhook_secret
      from vault.decrypted_secrets
      where name = 'LIKEDIN_PUSH_WEBHOOK_SECRET'
      limit 1;

    if webhook_secret is null or webhook_secret = '' then
      raise warning 'Likedin missed-call push skipped: webhook secret is unavailable';
      return new;
    end if;

    perform net.http_post(
      url := 'https://rjkexkvubkboexnsktsh.supabase.co/functions/v1/send-missed-call-push',
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        'x-likedin-webhook-secret', webhook_secret
      ),
      body := jsonb_build_object('record', to_jsonb(new)),
      timeout_milliseconds := 5000
    );
  end if;
  return new;
end;
$$;

drop trigger if exists likedin_missed_call_push on public.likedin_calls;
create trigger likedin_missed_call_push
after update of status on public.likedin_calls
for each row
when (old.status = 'ringing' and new.status = 'missed')
execute function public.likedin_notify_missed_call_push();

revoke all on function public.likedin_notify_missed_call_push() from public;

commit;
notify pgrst, 'reload schema';
