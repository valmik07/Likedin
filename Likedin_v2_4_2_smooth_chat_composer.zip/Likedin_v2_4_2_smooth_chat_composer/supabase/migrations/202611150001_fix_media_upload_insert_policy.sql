-- Likedin 1.7.25: fix Storage INSERT RLS rejection for authenticated paired users.
-- Safe boundary: a signed-in user can create objects only inside their own UUID folder.
-- Existing SELECT policy continues to restrict reads to the two paired accounts.

drop policy if exists "Likedin media upload own folder" on storage.objects;
create policy "Likedin media upload own folder"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'likedin-media'
  and auth.uid() is not null
  and (storage.foldername(name))[1] = auth.uid()::text
);
