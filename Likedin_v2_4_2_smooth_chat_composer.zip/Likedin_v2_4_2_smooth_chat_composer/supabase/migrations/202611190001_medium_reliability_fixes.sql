begin;

-- Preallocated empty slots use NULL. Some older installations kept NOT NULL.
alter table public.account_slots alter column user_id drop not null;

-- Stable server timestamp for device-local clear-chat cutoffs.
create or replace function public.likedin_server_now()
returns timestamptz
language sql
stable
security invoker
set search_path = ''
as $$ select pg_catalog.now(); $$;
grant execute on function public.likedin_server_now() to authenticated;

commit;
notify pgrst, 'reload schema';
