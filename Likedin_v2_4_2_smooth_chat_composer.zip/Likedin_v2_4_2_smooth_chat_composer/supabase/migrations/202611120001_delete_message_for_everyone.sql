-- Likedin: sender-authorized delete-for-everyone.
-- Messages remain encrypted in storage; this operation removes the selected row
-- rather than exposing or modifying encrypted_payload contents.

create or replace function public.likedin_delete_message_for_everyone(p_message_id uuid)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  deleted_count integer;
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;

  delete from public.messages
   where id = p_message_id
     and sender_id = auth.uid();

  get diagnostics deleted_count = row_count;

  if deleted_count = 0 then
    raise exception 'Message not found or you are not its sender';
  end if;

  return true;
end;
$$;

revoke all on function public.likedin_delete_message_for_everyone(uuid) from public;
grant execute on function public.likedin_delete_message_for_everyone(uuid) to authenticated;
