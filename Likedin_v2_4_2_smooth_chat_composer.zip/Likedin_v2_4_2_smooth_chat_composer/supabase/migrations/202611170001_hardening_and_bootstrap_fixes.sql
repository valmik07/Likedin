-- Likedin v1.7.45 hardening and bootstrap fixes.
-- Review this migration against the live policies before applying. All DDL is
-- idempotent; push HTTP errors are logged as warnings and never abort app writes.

begin;

-- Required for asynchronous HTTP requests from Postgres triggers.
create extension if not exists pg_net;

-- The unread index in 1.7.5 requires this column on fresh as well as upgraded projects.
alter table public.messages add column if not exists read_at timestamptz;

-- These tables are mutated through SECURITY DEFINER RPCs only. Remove broad
-- client UPDATE policies so users cannot directly rewrite message/call rows.
drop policy if exists "recipients can mark messages delivered" on public.messages;
drop policy if exists "participants update call" on public.likedin_calls;

-- A device token belongs to the currently authenticated account. Moving the
-- same FCM token between accounts prevents a signed-out account receiving pushes.
create or replace function public.likedin_register_push_token(p_token text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;
  if p_token is null or length(p_token) < 20 then
    raise exception 'Invalid push token';
  end if;

  delete from public.likedin_push_tokens
   where token = p_token
     and user_id <> auth.uid();

  insert into public.likedin_push_tokens(user_id, token, platform, updated_at)
  values (auth.uid(), p_token, 'android', now())
  on conflict (user_id, token)
  do update set updated_at = now();
end;
$$;
revoke all on function public.likedin_register_push_token(text) from public;
grant execute on function public.likedin_register_push_token(text) to authenticated;

-- Create account-slot assignment and profile rows on registration. The earlier
-- migration already enforces the global two-account limit; this trigger fills
-- the corresponding two slots, and the backfill covers existing accounts.
create or replace function public.likedin_handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_slot smallint;
  v_display_name text;
begin
  select g::smallint
    into v_slot
    from generate_series(1, 2) as g
   where not exists (
     select 1 from public.account_slots a where a.slot = g and a.user_id is not null
   )
   order by g
   limit 1;

  if v_slot is null then
    raise exception 'LIKEDIN_PAIR_FULL: no free account slot';
  end if;

  insert into public.account_slots(slot, user_id)
  values (v_slot, new.id)
  on conflict (slot) do update
    set user_id = excluded.user_id, occupied_at = now()
    where public.account_slots.user_id is null;

  v_display_name := coalesce(
    nullif(btrim(new.raw_user_meta_data ->> 'display_name'), ''),
    nullif(split_part(coalesce(new.email, ''), '@', 1), ''),
    'Likedin user'
  );
  insert into public.profiles(user_id, display_name)
  values (new.id, v_display_name)
  on conflict (user_id) do nothing;

  return new;
end;
$$;
revoke all on function public.likedin_handle_new_user() from public;
drop trigger if exists likedin_new_user on auth.users;
create trigger likedin_new_user
  after insert on auth.users
  for each row execute function public.likedin_handle_new_user();

do $$
declare
  v_user record;
  v_slot smallint;
  v_display_name text;
begin
  -- Serialize the backfill with the existing two-account BEFORE INSERT guard.
  perform pg_advisory_xact_lock(734921, 2);
  for v_user in
    select id, email, raw_user_meta_data
      from auth.users
     order by created_at, id
  loop
    if not exists (select 1 from public.account_slots a where a.user_id = v_user.id) then
      select g::smallint
        into v_slot
        from generate_series(1, 2) as g
       where not exists (
         select 1 from public.account_slots a where a.slot = g and a.user_id is not null
       )
       order by g
       limit 1;
      if v_slot is not null then
        insert into public.account_slots(slot, user_id)
        values (v_slot, v_user.id)
        on conflict (slot) do update
          set user_id = excluded.user_id, occupied_at = now()
          where public.account_slots.user_id is null;
      end if;
    end if;

    v_display_name := coalesce(
      nullif(btrim(v_user.raw_user_meta_data ->> 'display_name'), ''),
      nullif(split_part(coalesce(v_user.email, ''), '@', 1), ''),
      'Likedin user'
    );
    insert into public.profiles(user_id, display_name)
    values (v_user.id, v_display_name)
    on conflict (user_id) do nothing;
  end loop;
end;
$$;

-- Ensure all realtime tables are added only once. Guard missing relations for
-- older/newer project states; existing publication membership is preserved.
do $$
declare
  t text;
begin
  foreach t in array array['messages', 'profiles', 'likedin_calls', 'likedin_call_signals', 'message_reactions'] loop
    if to_regclass(format('public.%I', t)) is not null
       and not exists (
         select 1 from pg_publication_tables
          where pubname = 'supabase_realtime'
            and schemaname = 'public'
            and tablename = t
       ) then
      execute format('alter publication supabase_realtime add table public.%I', t);
    end if;
  end loop;
exception when undefined_object then
  raise notice 'supabase_realtime publication not found; realtime updates will require reload/polling';
end;
$$;

-- Push functions must never make a message insert or call-state update fail.
-- Only opaque IDs and call metadata leave Postgres; message bodies are excluded.
create or replace function public.likedin_notify_message_push()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  webhook_secret text;
begin
  if new.sender_id is null or new.recipient_id is null then
    return new;
  end if;

  begin
    select decrypted_secret
      into webhook_secret
      from vault.decrypted_secrets
     where name = 'LIKEDIN_PUSH_WEBHOOK_SECRET'
     limit 1;

    if coalesce(webhook_secret, '') = '' then
      raise warning 'Likedin message push skipped: webhook secret is unavailable';
    else
      perform net.http_post(
        url := 'https://rjkexkvubkboexnsktsh.supabase.co/functions/v1/send-message-push',
        headers := jsonb_build_object(
          'Content-Type', 'application/json',
          'x-likedin-webhook-secret', webhook_secret
        ),
        body := jsonb_build_object('record', jsonb_build_object(
          'id', new.id,
          'sender_id', new.sender_id,
          'recipient_id', new.recipient_id
        )),
        timeout_milliseconds := 5000
      );
    end if;
  exception when others then
    raise warning 'Likedin message push failed: %', sqlerrm;
  end;
  return new;
end;
$$;
revoke all on function public.likedin_notify_message_push() from public;
drop trigger if exists likedin_message_push on public.messages;
create trigger likedin_message_push
  after insert on public.messages
  for each row
  when (new.sender_id is not null and new.recipient_id is not null)
  execute function public.likedin_notify_message_push();

create or replace function public.likedin_notify_incoming_call_push()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  webhook_secret text;
begin
  if new.status <> 'ringing' then
    return new;
  end if;

  begin
    select decrypted_secret
      into webhook_secret
      from vault.decrypted_secrets
     where name = 'LIKEDIN_PUSH_WEBHOOK_SECRET'
     limit 1;

    if coalesce(webhook_secret, '') = '' then
      raise warning 'Likedin incoming-call push skipped: webhook secret is unavailable';
    else
      perform net.http_post(
        url := 'https://rjkexkvubkboexnsktsh.supabase.co/functions/v1/send-incoming-call-push',
        headers := jsonb_build_object(
          'Content-Type', 'application/json',
          'x-likedin-webhook-secret', webhook_secret
        ),
        body := jsonb_build_object('record', jsonb_build_object(
          'id', new.id,
          'caller_id', new.caller_id,
          'callee_id', new.callee_id,
          'call_type', new.call_type,
          'status', new.status
        )),
        timeout_milliseconds := 5000
      );
    end if;
  exception when others then
    raise warning 'Likedin incoming-call push failed: %', sqlerrm;
  end;
  return new;
end;
$$;
revoke all on function public.likedin_notify_incoming_call_push() from public;
drop trigger if exists likedin_incoming_call_push on public.likedin_calls;
create trigger likedin_incoming_call_push
  after insert on public.likedin_calls
  for each row
  when (new.status = 'ringing')
  execute function public.likedin_notify_incoming_call_push();

create or replace function public.likedin_notify_missed_call_push()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  webhook_secret text;
begin
  if old.status = 'ringing' and new.status in ('missed', 'ended', 'rejected') then
    begin
      select decrypted_secret
        into webhook_secret
        from vault.decrypted_secrets
       where name = 'LIKEDIN_PUSH_WEBHOOK_SECRET'
       limit 1;

      if coalesce(webhook_secret, '') = '' then
        raise warning 'Likedin missed-call push skipped: webhook secret is unavailable';
      else
        perform net.http_post(
          url := 'https://rjkexkvubkboexnsktsh.supabase.co/functions/v1/send-missed-call-push',
          headers := jsonb_build_object(
            'Content-Type', 'application/json',
            'x-likedin-webhook-secret', webhook_secret
          ),
          body := jsonb_build_object('record', jsonb_build_object(
            'id', new.id,
            'caller_id', new.caller_id,
            'callee_id', new.callee_id,
            'call_type', new.call_type,
            'status', new.status
          )),
          timeout_milliseconds := 5000
        );
      end if;
    exception when others then
      raise warning 'Likedin missed-call push failed: %', sqlerrm;
    end;
  end if;
  return new;
end;
$$;
revoke all on function public.likedin_notify_missed_call_push() from public;
drop trigger if exists likedin_missed_call_push on public.likedin_calls;
create trigger likedin_missed_call_push
  after update of status on public.likedin_calls
  for each row
  when (old.status = 'ringing' and new.status in ('missed', 'ended', 'rejected'))
  execute function public.likedin_notify_missed_call_push();

commit;
notify pgrst, 'reload schema';
