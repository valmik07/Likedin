-- Likedin v1.9.13: allow common audio file formats in the private media bucket.
-- Safe to run more than once; preserves every existing allowed MIME type.
update storage.buckets
set allowed_mime_types = (
  select array_agg(distinct mime order by mime)
  from unnest(
    coalesce(allowed_mime_types, array[]::text[]) || array[
      'audio/mp4', 'audio/x-m4a', 'audio/m4a', 'audio/aac',
      'audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/x-wav',
      'audio/webm', 'audio/ogg', 'audio/flac', 'audio/x-flac',
      'audio/amr', 'audio/3gpp', 'audio/3gpp2',
      'audio/x-ms-wma', 'audio/midi', 'audio/x-aiff'
    ]::text[]
  ) as mime
)
where id = 'likedin-media';

-- Keep the existing 50 MB per-file limit; a 7 MB audio file is within it.
