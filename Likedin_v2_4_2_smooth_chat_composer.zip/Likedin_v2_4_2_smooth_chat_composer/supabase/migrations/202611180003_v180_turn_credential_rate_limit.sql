begin;

-- Atomic per-user TURN credential rate limit. Only service_role may call it.
create table if not exists public.likedin_turn_credential_requests (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  requested_at timestamptz not null default now()
);
create index if not exists likedin_turn_requests_user_time_idx
  on public.likedin_turn_credential_requests(user_id, requested_at desc);
alter table public.likedin_turn_credential_requests enable row level security;
revoke all on public.likedin_turn_credential_requests from anon, authenticated;

create or replace function public.likedin_allow_turn_credential_request(
  p_user_id uuid,
  p_max_requests integer default 12,
  p_window_seconds integer default 600
)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_count integer;
begin
  if p_user_id is null or p_max_requests < 1 or p_window_seconds < 1 then
    return false;
  end if;
  perform pg_advisory_xact_lock(hashtext(p_user_id::text));
  delete from public.likedin_turn_credential_requests
   where requested_at < now() - interval '1 day';
  select count(*)::integer into v_count
    from public.likedin_turn_credential_requests
   where user_id = p_user_id
     and requested_at >= now() - make_interval(secs => p_window_seconds);
  if v_count >= p_max_requests then
    return false;
  end if;
  insert into public.likedin_turn_credential_requests(user_id) values (p_user_id);
  return true;
end;
$$;
revoke all on function public.likedin_allow_turn_credential_request(uuid, integer, integer) from public;
grant execute on function public.likedin_allow_turn_credential_request(uuid, integer, integer) to service_role;
commit;
notify pgrst, 'reload schema';
