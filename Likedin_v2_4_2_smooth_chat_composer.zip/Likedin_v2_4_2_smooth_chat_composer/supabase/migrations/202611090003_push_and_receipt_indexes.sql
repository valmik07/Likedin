-- Likedin v1.5: support push-token lookup and receipt queries.
-- Run once in Supabase SQL Editor if not already applied.
begin;
alter table public.messages add column if not exists read_at timestamptz;
create index if not exists likedin_push_tokens_user_updated_idx
  on public.likedin_push_tokens (user_id, updated_at desc);
create index if not exists likedin_messages_recipient_unread_idx
  on public.messages (recipient_id, created_at)
  where read_at is null;
commit;
notify pgrst, 'reload schema';
