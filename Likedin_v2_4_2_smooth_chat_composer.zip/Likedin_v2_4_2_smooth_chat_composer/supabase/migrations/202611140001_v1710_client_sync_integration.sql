-- Likedin 1.7.10: client integration for synchronized reply/reaction/edit/delete.
-- Additive and safe to apply after 1.7.9 Phase 1 foundation.
begin;

create or replace function public.likedin_send_message_v2(
  p_recipient_id uuid,
  p_payload text,
  p_client_message_id uuid,
  p_reply_to_message_id uuid default null
) returns uuid
language plpgsql security definer set search_path = '' as $$
declare
  v_sender uuid := auth.uid();
  v_id uuid;
begin
  if v_sender is null then raise exception 'Authentication required'; end if;
  if p_payload is null or length(p_payload) < 1 or length(p_payload) > 10000 then
    raise exception 'Message must contain 1 to 10000 characters';
  end if;
  if p_recipient_id is null or p_recipient_id = v_sender then raise exception 'Invalid recipient'; end if;
  if not exists (select 1 from public.account_slots s where s.user_id = v_sender)
     or not exists (select 1 from public.account_slots s where s.user_id = p_recipient_id) then
    raise exception 'Recipient is not a registered Likedin account';
  end if;
  if p_reply_to_message_id is not null and not exists (
    select 1 from public.messages m
    where m.id = p_reply_to_message_id
      and ((m.sender_id = v_sender and m.recipient_id = p_recipient_id)
        or (m.sender_id = p_recipient_id and m.recipient_id = v_sender))
  ) then raise exception 'Reply target is not in this conversation'; end if;

  insert into public.messages(sender_id, recipient_id, encrypted_payload, client_message_id, reply_to_message_id)
  values (v_sender, p_recipient_id, p_payload, p_client_message_id, p_reply_to_message_id)
  on conflict (sender_id, client_message_id) where client_message_id is not null
  do update set client_message_id = excluded.client_message_id
  returning id into v_id;
  return v_id;
end; $$;

revoke all on function public.likedin_send_message_v2(uuid,text,uuid,uuid) from public;
grant execute on function public.likedin_send_message_v2(uuid,text,uuid,uuid) to authenticated;

-- Realtime publication membership is added only when absent.
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='message_reactions') then
    alter publication supabase_realtime add table public.message_reactions;
  end if;
exception when undefined_object then
  raise notice 'supabase_realtime publication not found; reaction refresh will occur on message reload';
end $$;

commit;
notify pgrst, 'reload schema';
