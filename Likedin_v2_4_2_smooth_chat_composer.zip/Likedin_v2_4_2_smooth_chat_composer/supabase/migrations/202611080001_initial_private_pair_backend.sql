-- Likedin: initial shared backend schema.
-- Run in Supabase SQL Editor. Messages contain ciphertext only; never plaintext.

create or replace function public.enforce_two_global_accounts()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  account_count integer;
begin
  -- Serialize concurrent sign-ups so two simultaneous requests cannot both pass.
  perform pg_advisory_xact_lock(734921, 2);
  select count(*) into account_count from auth.users;
  if account_count >= 2 then
    raise exception 'LIKEDIN_PAIR_FULL: only two accounts are permitted globally'
      using errcode = '23514';
  end if;
  return new;
end;
$$;

 drop trigger if exists likedin_two_account_limit on auth.users;
create trigger likedin_two_account_limit
before insert on auth.users
for each row execute function public.enforce_two_global_accounts();

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references auth.users(id) on delete cascade,
  recipient_id uuid not null references auth.users(id) on delete cascade,
  ciphertext text not null,
  nonce text not null,
  encryption_version smallint not null default 1,
  created_at timestamptz not null default now(),
  delivered_at timestamptz,
  constraint messages_distinct_people check (sender_id <> recipient_id),
  constraint messages_ciphertext_not_empty check (length(ciphertext) > 0)
);

create index if not exists messages_recipient_created_idx
  on public.messages (recipient_id, created_at);
create index if not exists messages_sender_created_idx
  on public.messages (sender_id, created_at);

alter table public.messages enable row level security;

 drop policy if exists "pair members can read their messages" on public.messages;
create policy "pair members can read their messages"
on public.messages for select to authenticated
using (auth.uid() = sender_id or auth.uid() = recipient_id);

 drop policy if exists "users can send as themselves" on public.messages;
create policy "users can send as themselves"
on public.messages for insert to authenticated
with check (auth.uid() = sender_id);

 drop policy if exists "recipients can mark messages delivered" on public.messages;
create policy "recipients can mark messages delivered"
on public.messages for update to authenticated
using (auth.uid() = recipient_id)
with check (auth.uid() = recipient_id);

-- No client-side delete policy: message deletion/retention needs a deliberate
-- product decision and should not silently erase the other person's history.
