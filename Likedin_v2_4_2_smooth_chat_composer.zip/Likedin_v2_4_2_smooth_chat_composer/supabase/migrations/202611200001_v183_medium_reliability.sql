-- Likedin v1.8.3 medium-reliability remediation.
-- Apply after the v1.8.2/v1.8.1 migrations. Pending Auth users reserve one of
-- the two slots until confirmation or the 48-hour expiry; they are not pair
-- members until confirmed.
begin;

-- Keep the legacy slot-table shape compatible before seeding null reservations.
alter table public.account_slots add column if not exists occupied_at timestamptz;
alter table public.account_slots alter column user_id drop not null;

alter table public.messages
  add column if not exists deleted_media_path text;

-- A signup reservation is an occupied account_slots row. This avoids the
-- previous race where unlimited unconfirmed auth.users rows could later fail
-- during the email-confirmation trigger with a generic GoTrue database error.
create or replace function public.enforce_two_global_accounts()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_occupied integer;
begin
  perform pg_advisory_xact_lock(734921, 2);
  perform public.likedin_cleanup_unconfirmed_signups();
  select count(*)::integer into v_occupied
    from public.account_slots s
   where s.user_id is not null;
  if v_occupied >= 2 then
    raise exception 'LIKEDIN_PAIR_FULL: both Likedin account slots are reserved'
      using errcode = '23514';
  end if;
  return new;
end;
$$;
revoke all on function public.enforce_two_global_accounts() from public, anon, authenticated;

drop trigger if exists likedin_two_account_limit on auth.users;
create trigger likedin_two_account_limit
before insert on auth.users
for each row execute function public.enforce_two_global_accounts();

-- A reservation becomes an approved pair member only after Auth confirmation.
create or replace function public.likedin_is_pair_member(p_user_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select p_user_id is not null and exists (
    select 1
      from public.account_slots s
      join auth.users u on u.id = s.user_id
     where s.user_id = p_user_id
       and (u.email_confirmed_at is not null or u.phone_confirmed_at is not null)
  );
$$;
revoke all on function public.likedin_is_pair_member(uuid) from public;
grant execute on function public.likedin_is_pair_member(uuid) to authenticated, service_role;

create or replace function public.likedin_is_pair_member_path(p_user_id_text text)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select p_user_id_text is not null and exists (
    select 1
      from public.account_slots s
      join auth.users u on u.id = s.user_id
     where s.user_id::text = p_user_id_text
       and (u.email_confirmed_at is not null or u.phone_confirmed_at is not null)
  );
$$;
revoke all on function public.likedin_is_pair_member_path(text) from public;
grant execute on function public.likedin_is_pair_member_path(text) to authenticated, service_role;

-- Reserve a slot on signup, and create the profile only after confirmation.
-- The same trigger handles the confirmation update and is idempotent.
create or replace function public.likedin_handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_slot smallint;
  v_display_name text;
  v_confirmed boolean;
begin
  perform pg_advisory_xact_lock(734921, 2);
  v_confirmed := new.email_confirmed_at is not null or new.phone_confirmed_at is not null;

  select s.slot into v_slot
    from public.account_slots s
   where s.user_id = new.id
   limit 1;

  if v_slot is null then
    select s.slot into v_slot
      from public.account_slots s
     where s.user_id is null
     order by s.slot
     limit 1
     for update;
    if v_slot is null then
      raise exception 'LIKEDIN_PAIR_FULL: both Likedin account slots are reserved'
        using errcode = '23514';
    end if;
    update public.account_slots
       set user_id = new.id, occupied_at = now()
     where slot = v_slot and user_id is null;
    if not found then
      raise exception 'LIKEDIN_PAIR_FULL: could not reserve an account slot'
        using errcode = '23514';
    end if;
  end if;

  if not v_confirmed then
    return new;
  end if;

  v_display_name := coalesce(
    nullif(btrim(new.raw_user_meta_data ->> 'display_name'), ''),
    nullif(split_part(coalesce(new.email, ''), '@', 1), ''),
    'Likedin user'
  );
  insert into public.profiles(user_id, display_name)
  values (new.id, v_display_name)
  on conflict (user_id) do update
    set display_name = case
      when public.profiles.display_name = '' then excluded.display_name
      else public.profiles.display_name
    end;
  return new;
end;
$$;
revoke all on function public.likedin_handle_new_user() from public, anon, authenticated;

drop trigger if exists likedin_new_user on auth.users;
create trigger likedin_new_user
after insert on auth.users
for each row execute function public.likedin_handle_new_user();

drop trigger if exists likedin_assign_slot_on_confirmation on auth.users;
create trigger likedin_assign_slot_on_confirmation
after update of email_confirmed_at, phone_confirmed_at on auth.users
for each row
when (
  (old.email_confirmed_at is distinct from new.email_confirmed_at)
  or (old.phone_confirmed_at is distinct from new.phone_confirmed_at)
)
execute function public.likedin_handle_new_user();

-- The RPC cleans expired unconfirmed users on demand; pg_cron additionally
-- runs it hourly where that extension has been enabled.
create or replace function public.likedin_cleanup_unconfirmed_signups()
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_deleted integer := 0;
  v_expired record;
begin
  perform pg_advisory_xact_lock(734921, 2);
  -- SKIP LOCKED avoids deadlocking with a confirmation request that has
  -- already locked its Auth row and is completing the confirmation trigger.
  for v_expired in
    select u.id
      from auth.users u
     where u.email_confirmed_at is null
       and u.phone_confirmed_at is null
       and u.created_at < now() - interval '48 hours'
     for update skip locked
  loop
    update public.account_slots
       set user_id = null, occupied_at = now()
     where user_id = v_expired.id;
    delete from auth.users where id = v_expired.id;
    v_deleted := v_deleted + 1;
  end loop;

  -- Preserve the two preallocated rows on projects where the historical FK
  -- used ON DELETE CASCADE for account_slots rows.
  insert into public.account_slots(slot, user_id)
  values (1, null), (2, null)
  on conflict (slot) do nothing;
  return v_deleted;
end;
$$;
revoke all on function public.likedin_cleanup_unconfirmed_signups() from public, anon, authenticated;
grant execute on function public.likedin_cleanup_unconfirmed_signups() to service_role;

create or replace function public.likedin_can_register_account()
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
begin
  perform pg_advisory_xact_lock(734921, 2);
  perform public.likedin_cleanup_unconfirmed_signups();
  return exists (select 1 from public.account_slots s where s.user_id is null);
end;
$$;
revoke all on function public.likedin_can_register_account() from public;
grant execute on function public.likedin_can_register_account() to anon, authenticated;

-- Existing pre-reservation unconfirmed users are assigned the remaining slots
-- oldest-first. Unconfirmed accounts that cannot possibly be confirmed into
-- the two-person pair are removed instead of leaving dead confirmation links.
do $$
declare
  u record;
  v_slot smallint;
  v_confirmed_count integer;
begin
  perform pg_advisory_xact_lock(734921, 2);
  insert into public.account_slots(slot, user_id)
  values (1, null), (2, null)
  on conflict (slot) do nothing;

  perform public.likedin_cleanup_unconfirmed_signups();

  select count(*)::integer into v_confirmed_count
    from auth.users x
   where x.email_confirmed_at is not null or x.phone_confirmed_at is not null;
  if v_confirmed_count > 2 then
    raise exception 'LIKEDIN_PAIR_RECONCILIATION_REQUIRED: found % confirmed Auth users; inspect before applying v1.8.3', v_confirmed_count;
  end if;

  for u in
    select x.id, x.email, x.raw_user_meta_data
      from auth.users x
     where x.email_confirmed_at is not null or x.phone_confirmed_at is not null
     order by x.created_at, x.id
  loop
    if not exists (select 1 from public.account_slots s where s.user_id = u.id) then
      select s.slot into v_slot
        from public.account_slots s
       where s.user_id is null
       order by s.slot
       limit 1
       for update;
      if v_slot is null then
        raise exception 'LIKEDIN_PAIR_RECONCILIATION_REQUIRED: no available slot for confirmed user %', u.id;
      end if;
      update public.account_slots
         set user_id = u.id, occupied_at = now()
       where slot = v_slot and user_id is null;
    end if;
    insert into public.profiles(user_id, display_name)
    values (
      u.id,
      coalesce(
        nullif(btrim(u.raw_user_meta_data ->> 'display_name'), ''),
        nullif(split_part(coalesce(u.email, ''), '@', 1), ''),
        'Likedin user'
      )
    )
    on conflict (user_id) do nothing;
  end loop;

  for u in
    select x.id
      from auth.users x
     where x.email_confirmed_at is null
       and x.phone_confirmed_at is null
       and x.created_at >= now() - interval '48 hours'
     order by x.created_at, x.id
  loop
    if exists (select 1 from public.account_slots s where s.user_id = u.id) then
      continue;
    end if;
    select s.slot into v_slot
      from public.account_slots s
     where s.user_id is null
     order by s.slot
     limit 1
     for update;
    if v_slot is null then
      delete from auth.users where id = u.id;
    else
      update public.account_slots
         set user_id = u.id, occupied_at = now()
       where slot = v_slot and user_id is null;
    end if;
  end loop;
end;
$$;

-- Recreate the peer lookup to exclude reserved-but-unconfirmed users.
create or replace function public.likedin_get_peer_id()
returns uuid
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
  v_peer uuid;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  if not public.likedin_is_pair_member(v_uid) then
    raise exception 'Not an approved Likedin pair member';
  end if;
  select s.user_id into v_peer
    from public.account_slots s
   where s.user_id is not null
     and s.user_id <> v_uid
     and public.likedin_is_pair_member(s.user_id)
   order by s.slot
   limit 1;
  return v_peer;
end;
$$;
revoke all on function public.likedin_get_peer_id() from public;
grant execute on function public.likedin_get_peer_id() to authenticated;

-- One count definition across client and SQL: PostgreSQL char_length counts
-- Unicode code points, matching Dart String.runes (not grapheme clusters).
create or replace function public.likedin_send_message_v2(
  p_recipient_id uuid,
  p_payload text,
  p_client_message_id uuid,
  p_reply_to_message_id uuid default null
) returns uuid
language plpgsql security definer set search_path = '' as $$
declare
  v_sender uuid := auth.uid();
  v_id uuid;
begin
  if v_sender is null then raise exception 'Authentication required'; end if;
  if not public.likedin_is_pair_member(v_sender) then raise exception 'Not an approved Likedin pair member'; end if;
  if p_payload is null or char_length(p_payload) < 1 or char_length(p_payload) > 10000 then
    raise exception 'Message must contain 1 to 10000 Unicode code points';
  end if;
  if p_recipient_id is null or p_recipient_id = v_sender
     or not public.likedin_is_pair_member(p_recipient_id) then
    raise exception 'Invalid or unapproved recipient';
  end if;
  if p_reply_to_message_id is not null and not exists (
    select 1 from public.messages m
     where m.id = p_reply_to_message_id
       and ((m.sender_id = v_sender and m.recipient_id = p_recipient_id)
         or (m.sender_id = p_recipient_id and m.recipient_id = v_sender))
  ) then raise exception 'Reply target is not in this conversation'; end if;

  insert into public.messages(sender_id, recipient_id, encrypted_payload, client_message_id, reply_to_message_id)
  values (v_sender, p_recipient_id, p_payload, p_client_message_id, p_reply_to_message_id)
  on conflict (sender_id, client_message_id) where client_message_id is not null
  do update set client_message_id = excluded.client_message_id
  returning id into v_id;
  return v_id;
end;
$$;
revoke all on function public.likedin_send_message_v2(uuid, text, uuid, uuid) from public;
grant execute on function public.likedin_send_message_v2(uuid, text, uuid, uuid) to authenticated;

create or replace function public.likedin_edit_message(p_message_id uuid, p_new_payload text)
returns boolean
language plpgsql security definer set search_path = '' as $$
declare
  v_uid uuid := auth.uid();
  v_count integer;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  if not public.likedin_is_pair_member(v_uid) then raise exception 'Not an approved Likedin pair member'; end if;
  if p_new_payload is null or char_length(p_new_payload) < 1 or char_length(p_new_payload) > 10000 then
    raise exception 'Invalid message payload (1 to 10000 Unicode code points)';
  end if;
  update public.messages
     set encrypted_payload = p_new_payload, edited_at = now()
   where id = p_message_id
     and sender_id = v_uid
     and deleted_for_everyone_at is null
     and public.likedin_is_pair_member(recipient_id);
  get diagnostics v_count = row_count;
  if v_count = 0 then raise exception 'Message unavailable or not yours'; end if;
  return true;
end;
$$;
revoke all on function public.likedin_edit_message(uuid, text) from public;
grant execute on function public.likedin_edit_message(uuid, text) to authenticated;

-- Call failures are distinct from user-initiated hangups. Persist 'failed'
-- rather than writing 'ended' in the database while emitting 'failed' locally.
do $$
declare
  v_constraint record;
begin
  for v_constraint in
    select conname
      from pg_constraint
     where conrelid = 'public.likedin_calls'::regclass
       and contype = 'c'
       and pg_get_constraintdef(oid) ilike '%status%'
  loop
    execute format('alter table public.likedin_calls drop constraint %I', v_constraint.conname);
  end loop;
end;
$$;
alter table public.likedin_calls
  add constraint likedin_calls_status_check
  check (status in ('ringing', 'accepted', 'rejected', 'ended', 'missed', 'failed'));

create or replace function public.likedin_update_call_status(p_call_id uuid, p_new_status text)
returns void
language plpgsql security definer set search_path = '' as $$
declare
  v_uid uuid := auth.uid();
  v_call public.likedin_calls%rowtype;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  if not public.likedin_is_pair_member(v_uid) then
    raise exception 'Not an approved Likedin pair member';
  end if;
  if p_new_status is null or p_new_status not in ('accepted', 'rejected', 'missed', 'ended', 'failed') then
    raise exception 'Invalid call status transition: %', p_new_status;
  end if;
  select * into v_call from public.likedin_calls where id = p_call_id for update;
  if not found then raise exception 'Call not found'; end if;
  if v_uid <> v_call.caller_id and v_uid <> v_call.callee_id then
    raise exception 'Not a participant in this call';
  end if;
  if not public.likedin_is_pair_member(v_call.caller_id)
     or not public.likedin_is_pair_member(v_call.callee_id) then
    raise exception 'Call is not between approved pair members';
  end if;
  if p_new_status = 'accepted' then
    if v_uid <> v_call.callee_id then raise exception 'Only the callee can accept a call'; end if;
    if v_call.status <> 'ringing' then raise exception 'Call is no longer ringing'; end if;
    update public.likedin_calls set status = 'accepted', answered_at = coalesce(answered_at, now()) where id = p_call_id;
  elsif p_new_status = 'rejected' then
    if v_uid <> v_call.callee_id then raise exception 'Only the callee can reject a call'; end if;
    if v_call.status <> 'ringing' then return; end if;
    update public.likedin_calls set status = 'rejected', ended_at = coalesce(ended_at, now()) where id = p_call_id;
  elsif p_new_status = 'missed' then
    if v_uid <> v_call.caller_id then raise exception 'Only the caller can mark a call missed'; end if;
    if v_call.status <> 'ringing' then return; end if;
    update public.likedin_calls set status = 'missed', ended_at = coalesce(ended_at, now()) where id = p_call_id;
  elsif p_new_status = 'failed' then
    if v_call.status in ('ended', 'rejected', 'missed', 'failed') then return; end if;
    update public.likedin_calls set status = 'failed', ended_at = coalesce(ended_at, now()) where id = p_call_id;
  elsif p_new_status = 'ended' then
    if v_call.status in ('ended', 'rejected', 'missed', 'failed') then return; end if;
    update public.likedin_calls set status = 'ended', ended_at = coalesce(ended_at, now()) where id = p_call_id;
  end if;
end;
$$;
revoke all on function public.likedin_update_call_status(uuid, text) from public;
grant execute on function public.likedin_update_call_status(uuid, text) to authenticated;

-- Preserve the object path in the tombstone. The sender removes the remote
-- object through Storage API/RLS; both devices remove local cache copies.
create or replace function public.likedin_delete_message_for_everyone_v2(p_message_id uuid)
returns boolean
language plpgsql security definer set search_path = '' as $$
declare
  v_uid uuid := auth.uid();
  v_payload text;
  v_payload_json jsonb;
  v_media_path text;
  v_count integer;
begin
  if v_uid is null then raise exception 'Authentication required'; end if;
  if not public.likedin_is_pair_member(v_uid) then raise exception 'Not an approved Likedin pair member'; end if;

  select m.encrypted_payload into v_payload
    from public.messages m
   where m.id = p_message_id
     and m.sender_id = v_uid
     and m.deleted_for_everyone_at is null
     and public.likedin_is_pair_member(m.recipient_id)
   for update;
  if not found then raise exception 'Message unavailable or not yours'; end if;

  begin
    v_payload_json := v_payload::jsonb;
    if jsonb_typeof(v_payload_json) = 'object'
       and v_payload_json ->> '__likedin_media_v1' = 'true' then
      v_media_path := v_payload_json ->> 'path';
    end if;
  exception when others then
    v_media_path := null;
  end;
  if v_media_path is not null and left(v_media_path, length(v_uid::text) + 1) <> (v_uid::text || '/') then
    v_media_path := null;
  end if;

  update public.messages
     set deleted_for_everyone_at = now(),
         encrypted_payload = '[deleted]',
         deleted_media_path = v_media_path
   where id = p_message_id and sender_id = v_uid and deleted_for_everyone_at is null;
  get diagnostics v_count = row_count;
  if v_count = 0 then raise exception 'Message unavailable or not yours'; end if;
  delete from public.message_reactions where message_id = p_message_id;
  return true;
end;
$$;
revoke all on function public.likedin_delete_message_for_everyone_v2(uuid) from public;
grant execute on function public.likedin_delete_message_for_everyone_v2(uuid) to authenticated;

-- Remove policies by actual catalog identity instead of relying on historical
-- policy labels. These public tables are dedicated to the private Likedin app.
do $$
declare
  p record;
begin
  for p in
    select schemaname, tablename, policyname
      from pg_policies
     where (schemaname = 'public' and tablename in (
       'account_slots', 'profiles', 'messages', 'likedin_calls',
       'likedin_call_signals', 'message_reactions'
     ))
       or (schemaname = 'storage' and tablename = 'objects' and (
         policyname ilike '%likedin%'
         or coalesce(qual, '') ilike '%likedin-media%'
         or coalesce(with_check, '') ilike '%likedin-media%'
       ))
  loop
    execute format('drop policy %I on %I.%I', p.policyname, p.schemaname, p.tablename);
  end loop;
end;
$$;

alter table public.account_slots enable row level security;
alter table public.profiles enable row level security;
alter table public.messages enable row level security;
alter table public.likedin_calls enable row level security;
alter table public.likedin_call_signals enable row level security;
alter table public.message_reactions enable row level security;

-- account_slots intentionally has no direct client policy.
create policy "v183 pair members can view profiles"
on public.profiles for select to authenticated
using (public.likedin_can_read_profile(user_id));

create policy "v183 pair members can read messages"
on public.messages for select to authenticated
using (
  auth.uid() in (sender_id, recipient_id)
  and public.likedin_is_pair_member(sender_id)
  and public.likedin_is_pair_member(recipient_id)
);
create policy "v183 users can send as themselves"
on public.messages for insert to authenticated
with check (
  auth.uid() = sender_id
  and public.likedin_is_pair_member(sender_id)
  and public.likedin_is_pair_member(recipient_id)
);

create policy "v183 participants read calls"
on public.likedin_calls for select to authenticated
using (
  auth.uid() in (caller_id, callee_id)
  and public.likedin_is_pair_member(caller_id)
  and public.likedin_is_pair_member(callee_id)
);
create policy "v183 caller creates call"
on public.likedin_calls for insert to authenticated
with check (
  auth.uid() = caller_id
  and public.likedin_is_pair_member(caller_id)
  and public.likedin_is_pair_member(callee_id)
);

create policy "v183 participants read signals"
on public.likedin_call_signals for select to authenticated
using (exists (
  select 1 from public.likedin_calls c
   where c.id = call_id
     and auth.uid() in (c.caller_id, c.callee_id)
     and public.likedin_is_pair_member(c.caller_id)
     and public.likedin_is_pair_member(c.callee_id)
));
create policy "v183 participants send signals"
on public.likedin_call_signals for insert to authenticated
with check (
  sender_id = auth.uid()
  and public.likedin_is_pair_member(sender_id)
  and exists (
    select 1 from public.likedin_calls c
     where c.id = call_id
       and auth.uid() in (c.caller_id, c.callee_id)
       and public.likedin_is_pair_member(c.caller_id)
       and public.likedin_is_pair_member(c.callee_id)
  )
);

create policy "v183 pair participants read message reactions"
on public.message_reactions for select to authenticated
using (
  public.likedin_is_pair_member(auth.uid())
  and exists (
    select 1 from public.messages m
     where m.id = message_id
       and auth.uid() in (m.sender_id, m.recipient_id)
       and public.likedin_is_pair_member(m.sender_id)
       and public.likedin_is_pair_member(m.recipient_id)
  )
);

-- Storage policies are also replaced based on policy expressions, so projects
-- with renamed historical labels do not keep a broader legacy policy active.
create policy "Likedin v183 upload own folder"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'likedin-media'
  and auth.uid() is not null
  and (storage.foldername(name))[1] = auth.uid()::text
  and public.likedin_is_pair_member(auth.uid())
);
create policy "Likedin v183 pair can read media"
on storage.objects for select to authenticated
using (
  bucket_id = 'likedin-media'
  and public.likedin_is_pair_member(auth.uid())
  and public.likedin_is_pair_member_path((storage.foldername(name))[1])
);
create policy "Likedin v183 owner can delete media"
on storage.objects for delete to authenticated
using (
  bucket_id = 'likedin-media'
  and (storage.foldername(name))[1] = auth.uid()::text
  and public.likedin_is_pair_member(auth.uid())
);

-- Schedule cleanup when pg_cron is installed; otherwise the signup preflight
-- invokes cleanup before checking capacity and service_role can call it too.
do $$
begin
  if to_regclass('cron.job') is not null then
    begin
      execute 'select cron.unschedule(jobid) from cron.job where jobname = ''likedin-cleanup-unconfirmed-signups''';
      execute 'select cron.schedule(''likedin-cleanup-unconfirmed-signups'', ''15 * * * *'', ''select public.likedin_cleanup_unconfirmed_signups();'')';
    exception when others then
      raise notice 'pg_cron cleanup schedule was not installed: %', sqlerrm;
    end;
  else
    raise notice 'pg_cron is not enabled; cleanup runs during signup preflight and can be called by service_role';
  end if;
end;
$$;

commit;
notify pgrst, 'reload schema';
