-- Likedin v1.7.46: remove the unsafe legacy duplicate message push trigger.
-- The safe `likedin_message_push` trigger invokes
-- `likedin_notify_message_push()`, which forwards only message IDs and catches
-- webhook errors. This cleanup is safe to run if the duplicate was already
-- removed manually: DROP TRIGGER IF EXISTS becomes a no-op.

begin;

drop trigger if exists "likedin-message-push" on public.messages;

commit;
notify pgrst, 'reload schema';
