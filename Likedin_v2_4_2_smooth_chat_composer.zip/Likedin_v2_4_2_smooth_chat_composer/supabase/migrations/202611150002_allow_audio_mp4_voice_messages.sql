-- Likedin 1.7.35: allow AAC-LC voice recordings stored in an M4A/MP4 container.
-- Apply this migration in the Supabase SQL Editor for an already-created bucket.
update storage.buckets
set allowed_mime_types = case
  when allowed_mime_types is null then array['audio/mp4']::text[]
  when array_position(allowed_mime_types, 'audio/mp4') is not null then allowed_mime_types
  else array_append(allowed_mime_types, 'audio/mp4')
end
where id = 'likedin-media';
