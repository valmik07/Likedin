-- Likedin v1.5.1: acknowledge only the exact message whose FCM data push
-- was received by this authenticated device. Existing bulk sync RPC remains.
begin;

create or replace function public.likedin_mark_message_delivered(p_message_id uuid)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare changed integer;
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;

  update public.messages
     set delivered_at = coalesce(delivered_at, now())
   where id = p_message_id
     and recipient_id = auth.uid()
     and delivered_at is null;

  get diagnostics changed = row_count;
  return changed > 0;
end;
$$;

revoke all on function public.likedin_mark_message_delivered(uuid) from public;
grant execute on function public.likedin_mark_message_delivered(uuid) to authenticated;

commit;
