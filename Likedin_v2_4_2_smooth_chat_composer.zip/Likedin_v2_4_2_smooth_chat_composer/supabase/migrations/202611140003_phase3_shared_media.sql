-- Likedin 1.7.17: private shared-media bucket and paired-account policies.
-- Run once in Supabase SQL Editor. This does not alter messages/profiles/account_slots.

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'likedin-media',
  'likedin-media',
  false,
  52428800,
  array[
    'image/jpeg', 'image/png', 'image/webp', 'image/gif',
    'video/mp4', 'video/quicktime', 'video/webm',
    'audio/mp4',
    'application/pdf', 'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'text/plain', 'application/zip', 'application/octet-stream'
  ]
)
on conflict (id) do update
set public = false,
    file_size_limit = 52428800,
    allowed_mime_types = excluded.allowed_mime_types;

-- Uploads must be placed in the authenticated sender's own UUID folder.
drop policy if exists "Likedin media upload own folder" on storage.objects;
create policy "Likedin media upload own folder"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'likedin-media'
  and auth.uid() is not null
  and (storage.foldername(name))[1] = auth.uid()::text
  and exists (
    select 1 from public.account_slots s where s.user_id = auth.uid()
  )
);

-- Only the two accounts registered in account_slots can read either account's
-- media. This relies on the existing two-slot pairing table, not public URLs.
drop policy if exists "Likedin pair can read media" on storage.objects;
create policy "Likedin pair can read media"
on storage.objects for select to authenticated
using (
  bucket_id = 'likedin-media'
  and auth.uid() is not null
  and exists (
    select 1 from public.account_slots me where me.user_id = auth.uid()
  )
  and (storage.foldername(name))[1] in (
    select s.user_id::text
    from public.account_slots s
    where s.user_id is not null
  )
);

-- A sender may delete only files in their own folder.
drop policy if exists "Likedin media owner can delete" on storage.objects;
create policy "Likedin media owner can delete"
on storage.objects for delete to authenticated
using (
  bucket_id = 'likedin-media'
  and (storage.foldername(name))[1] = auth.uid()::text
  and exists (
    select 1 from public.account_slots s where s.user_id = auth.uid()
  )
);
