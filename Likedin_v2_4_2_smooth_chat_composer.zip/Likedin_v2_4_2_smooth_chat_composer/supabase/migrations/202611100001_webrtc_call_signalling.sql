create table if not exists public.likedin_calls (
  id uuid primary key,
  caller_id uuid not null references auth.users(id) on delete cascade,
  callee_id uuid not null references auth.users(id) on delete cascade,
  call_type text not null check (call_type in ('audio','video')),
  status text not null default 'ringing' check (status in ('ringing','accepted','rejected','ended','missed')),
  created_at timestamptz not null default now(),
  answered_at timestamptz,
  ended_at timestamptz,
  check (caller_id <> callee_id)
);
create table if not exists public.likedin_call_signals (
  id bigint generated always as identity primary key,
  call_id uuid not null references public.likedin_calls(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check (kind in ('offer','answer','ice','end','reject')),
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
alter table public.likedin_calls enable row level security;
alter table public.likedin_call_signals enable row level security;
drop policy if exists "participants read calls" on public.likedin_calls;
create policy "participants read calls" on public.likedin_calls for select to authenticated using (auth.uid() in (caller_id,callee_id));
drop policy if exists "caller creates call" on public.likedin_calls;
create policy "caller creates call" on public.likedin_calls for insert to authenticated with check (auth.uid()=caller_id);
drop policy if exists "participants update call" on public.likedin_calls;
create policy "participants update call" on public.likedin_calls for update to authenticated using (auth.uid() in (caller_id,callee_id)) with check (auth.uid() in (caller_id,callee_id));
drop policy if exists "participants read signals" on public.likedin_call_signals;
create policy "participants read signals" on public.likedin_call_signals for select to authenticated using (exists(select 1 from public.likedin_calls c where c.id=call_id and auth.uid() in(c.caller_id,c.callee_id)));
drop policy if exists "participants send signals" on public.likedin_call_signals;
create policy "participants send signals" on public.likedin_call_signals for insert to authenticated with check (auth.uid()=sender_id and exists(select 1 from public.likedin_calls c where c.id=call_id and auth.uid() in(c.caller_id,c.callee_id)));
create index if not exists likedin_calls_callee_status_idx on public.likedin_calls(callee_id,status,created_at desc);
create index if not exists likedin_call_signals_call_created_idx on public.likedin_call_signals(call_id,created_at);
do $$
begin
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'likedin_call_signals') then
    alter publication supabase_realtime add table public.likedin_call_signals;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'likedin_calls') then
    alter publication supabase_realtime add table public.likedin_calls;
  end if;
exception when undefined_object then
  raise notice 'supabase_realtime publication not found; call updates will require polling/reload';
end $$;
