-- Likedin 1.7.38 consolidated schema and RPC remediation migration.
-- Preserves live RLS posture on account_slots (no client SELECT policy),
-- preserves existing storage bucket MIME allow-list via non-destructive union,
-- and matches live likedin_update_call_status(uuid, text) -> void signature
-- with strict caller/callee role enforcement.

begin;

-- 1. Ensure base pairing and profile tables exist without opening direct client
-- SELECT access to account_slots (access is mediated strictly via SECURITY DEFINER RPCs).
create table if not exists public.account_slots (
  slot smallint primary key check (slot in (1, 2)),
  user_id uuid unique references auth.users(id) on delete cascade,
  occupied_at timestamptz not null default now()
);

alter table public.account_slots enable row level security;
drop policy if exists "Authenticated users can read account slots" on public.account_slots;

create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  is_online boolean not null default false,
  last_seen_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles
  add column if not exists is_online boolean not null default false,
  add column if not exists last_seen_at timestamptz,
  add column if not exists updated_at timestamptz not null default now();

alter table public.profiles enable row level security;
drop policy if exists "Users can view profiles" on public.profiles;
create policy "Users can view profiles"
on public.profiles for select to authenticated using (true);

-- 2. Drop legacy NOT NULL constraints on messages.ciphertext and messages.nonce
-- so likedin_send_message_v2 inserts succeed on databases created from 202611080001.
do $$
begin
  if exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'messages' and column_name = 'ciphertext'
  ) then
    alter table public.messages alter column ciphertext drop not null;
    alter table public.messages drop constraint if exists messages_ciphertext_not_empty;
  end if;
  if exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'messages' and column_name = 'nonce'
  ) then
    alter table public.messages alter column nonce drop not null;
  end if;
end $$;

-- 3. Ensure core peer/presence/receipt RPCs exist in supabase/migrations.
create or replace function public.likedin_get_peer_id()
returns uuid
language sql
stable
security definer
set search_path = ''
as $$
  select s.user_id
  from public.account_slots s
  where s.user_id is not null
    and s.user_id <> (select auth.uid())
  order by s.slot
  limit 1;
$$;
revoke all on function public.likedin_get_peer_id() from public;
grant execute on function public.likedin_get_peer_id() to authenticated;

create or replace function public.likedin_set_presence(p_online boolean)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  update public.profiles
     set is_online = coalesce(p_online, false),
         last_seen_at = now(),
         updated_at = now()
   where user_id = auth.uid();
end;
$$;
revoke all on function public.likedin_set_presence(boolean) from public;
grant execute on function public.likedin_set_presence(boolean) to authenticated;

create or replace function public.likedin_mark_delivered()
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare changed integer;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  update public.messages
     set delivered_at = coalesce(delivered_at, now())
   where recipient_id = auth.uid() and delivered_at is null;
  get diagnostics changed = row_count;
  return changed;
end;
$$;
revoke all on function public.likedin_mark_delivered() from public;
grant execute on function public.likedin_mark_delivered() to authenticated;

create or replace function public.likedin_mark_read()
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare changed integer;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  update public.messages
     set delivered_at = coalesce(delivered_at, now()),
         read_at = coalesce(read_at, now())
   where recipient_id = auth.uid() and read_at is null;
  get diagnostics changed = row_count;
  return changed;
end;
$$;
revoke all on function public.likedin_mark_read() from public;
grant execute on function public.likedin_mark_read() to authenticated;

-- 4. Define public.likedin_update_call_status(uuid, text) returning void
-- with strict caller/callee role checks matching the live backend function.
create or replace function public.likedin_update_call_status(
  p_call_id uuid,
  p_new_status text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
  v_call public.likedin_calls%rowtype;
begin
  if v_uid is null then
    raise exception 'Authentication required';
  end if;
  if p_new_status not in ('accepted', 'rejected', 'missed', 'ended') then
    raise exception 'Invalid call status transition: %', p_new_status;
  end if;

  select * into v_call
    from public.likedin_calls
   where id = p_call_id
   for update;

  if not found then
    raise exception 'Call not found';
  end if;
  if v_uid <> v_call.caller_id and v_uid <> v_call.callee_id then
    raise exception 'Not a participant in this call';
  end if;

  if p_new_status = 'accepted' then
    if v_uid <> v_call.callee_id then
      raise exception 'Only the callee can accept a call';
    end if;
    if v_call.status <> 'ringing' then
      raise exception 'Call is no longer ringing';
    end if;
    update public.likedin_calls
       set status = 'accepted',
           answered_at = coalesce(answered_at, now())
     where id = p_call_id;
  elsif p_new_status = 'rejected' then
    if v_uid <> v_call.callee_id then
      raise exception 'Only the callee can reject a call';
    end if;
    if v_call.status <> 'ringing' then
      return;
    end if;
    update public.likedin_calls
       set status = 'rejected',
           ended_at = coalesce(ended_at, now())
     where id = p_call_id;
  elsif p_new_status = 'missed' then
    if v_uid <> v_call.caller_id then
      raise exception 'Only the caller can mark a call missed';
    end if;
    if v_call.status <> 'ringing' then
      return;
    end if;
    update public.likedin_calls
       set status = 'missed',
           ended_at = coalesce(ended_at, now())
     where id = p_call_id;
  elsif p_new_status = 'ended' then
    if v_call.status in ('ended', 'rejected', 'missed') then
      return;
    end if;
    update public.likedin_calls
       set status = 'ended',
           ended_at = coalesce(ended_at, now())
     where id = p_call_id;
  end if;
end;
$$;
revoke all on function public.likedin_update_call_status(uuid, text) from public;
grant execute on function public.likedin_update_call_status(uuid, text) to authenticated;

-- 5. Non-destructively merge additional voice/media MIME types into likedin-media
-- without overwriting existing allowed_mime_types (such as JSON, CSV, PowerPoint, WAV, WebM audio).
update storage.buckets
set allowed_mime_types = (
  select array_agg(distinct mime order by mime)
  from unnest(
    coalesce(allowed_mime_types, array[]::text[]) || array[
      'image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/heic', 'image/heif',
      'video/mp4', 'video/quicktime', 'video/webm', 'video/3gpp', 'video/x-matroska',
      'audio/mp4', 'audio/x-m4a', 'audio/m4a', 'audio/aac', 'audio/mpeg', 'audio/mp3',
      'audio/wav', 'audio/x-wav', 'audio/webm', 'audio/ogg',
      'application/pdf', 'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/vnd.ms-powerpoint',
      'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      'text/plain', 'text/csv', 'application/json', 'application/zip', 'application/octet-stream'
    ]::text[]
  ) as mime
)
where id = 'likedin-media';

-- 6. Trigger send-missed-call-push when a ringing call transitions to missed, ended, or rejected
-- so the recipient's ongoing incoming-call notification is replaced or dismissed.
create or replace function public.likedin_notify_missed_call_push()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  webhook_secret text;
begin
  if old.status = 'ringing' and new.status in ('missed', 'ended', 'rejected') then
    select decrypted_secret into webhook_secret
      from vault.decrypted_secrets
      where name = 'LIKEDIN_PUSH_WEBHOOK_SECRET'
      limit 1;

    if webhook_secret is null or webhook_secret = '' then
      raise warning 'Likedin missed-call push skipped: webhook secret is unavailable';
      return new;
    end if;

    perform net.http_post(
      url := 'https://rjkexkvubkboexnsktsh.supabase.co/functions/v1/send-missed-call-push',
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        'x-likedin-webhook-secret', webhook_secret
      ),
      body := jsonb_build_object('record', to_jsonb(new)),
      timeout_milliseconds := 5000
    );
  end if;
  return new;
end;
$$;

drop trigger if exists likedin_missed_call_push on public.likedin_calls;
create trigger likedin_missed_call_push
after update of status on public.likedin_calls
for each row
when (old.status = 'ringing' and new.status in ('missed', 'ended', 'rejected'))
execute function public.likedin_notify_missed_call_push();

commit;
notify pgrst, 'reload schema';
