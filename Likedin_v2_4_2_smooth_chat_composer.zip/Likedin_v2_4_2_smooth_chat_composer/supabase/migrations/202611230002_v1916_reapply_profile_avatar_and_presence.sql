-- Likedin v1.8.4: cross-device profile avatars and lower-noise presence writes.
-- Additive migration. Keeps the private likedIn-media bucket and existing RLS model.
begin;

alter table public.profiles
  add column if not exists avatar_path text;

create or replace function public.likedin_set_profile_avatar(p_avatar_path text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
begin
  if v_uid is null then
    raise exception 'Authentication required';
  end if;
  if not public.likedin_is_pair_member(v_uid) then
    raise exception 'Not an approved Likedin pair member';
  end if;

  if p_avatar_path is not null then
    if p_avatar_path !~ ('^' || v_uid::text || '/avatars/[A-Za-z0-9._-]+$')
       or position('..' in p_avatar_path) > 0 then
      raise exception 'Invalid profile photo path';
    end if;
    if not exists (
      select 1 from storage.objects o
       where o.bucket_id = 'likedin-media'
         and o.name = p_avatar_path
    ) then
      raise exception 'Profile photo object does not exist in private storage';
    end if;
  end if;

  update public.profiles
     set avatar_path = p_avatar_path,
         updated_at = now()
   where user_id = v_uid;
  if not found then
    raise exception 'Profile row does not exist';
  end if;
end;
$$;
revoke all on function public.likedin_set_profile_avatar(text) from public, anon;
grant execute on function public.likedin_set_profile_avatar(text) to authenticated;

-- The app still refreshes presence every 30 seconds, but write to Postgres no
-- more than once per 55 seconds while online. Peer-online freshness remains
-- within the client's 90-second online window, and offline transitions remain immediate.
create or replace function public.likedin_set_presence(p_online boolean)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
  v_online boolean := coalesce(p_online, false);
begin
  if v_uid is null then
    raise exception 'Authentication required';
  end if;
  if not public.likedin_is_pair_member(v_uid) then
    raise exception 'Not an approved Likedin pair member';
  end if;

  update public.profiles
     set is_online = v_online,
         last_seen_at = now(),
         updated_at = now()
   where user_id = v_uid
     and (
       is_online is distinct from v_online
       or (v_online and (last_seen_at is null or last_seen_at < now() - interval '55 seconds'))
     );
end;
$$;
revoke all on function public.likedin_set_presence(boolean) from public, anon;
grant execute on function public.likedin_set_presence(boolean) to authenticated;

commit;
notify pgrst, 'reload schema';
