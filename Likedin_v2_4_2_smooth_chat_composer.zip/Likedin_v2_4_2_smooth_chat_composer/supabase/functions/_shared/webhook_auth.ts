/** Constant-time comparison for the fixed-size SHA-256 digests of webhook
 * secrets. Hashing both values first means the comparison loop always handles
 * 32 bytes even when the supplied header has a different length.
 */
export async function verifyWebhookSecret(
  expected: string,
  supplied: string,
): Promise<boolean> {
  if (!expected || !supplied || expected.length > 4096 || supplied.length > 4096) {
    return false;
  }
  const encoder = new TextEncoder();
  const [expectedDigest, suppliedDigest] = await Promise.all([
    crypto.subtle.digest("SHA-256", encoder.encode(expected)),
    crypto.subtle.digest("SHA-256", encoder.encode(supplied)),
  ]);
  const left = new Uint8Array(expectedDigest);
  const right = new Uint8Array(suppliedDigest);
  let difference = expected.length ^ supplied.length;
  for (let index = 0; index < left.length; index++) {
    difference |= left[index] ^ right[index];
  }
  return difference === 0;
}
