import { verifyWebhookSecret } from "../_shared/webhook_auth.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.8";
import { cert, getApps, initializeApp } from "npm:firebase-admin@12.7.0/app";
import { getMessaging } from "npm:firebase-admin@12.7.0/messaging";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-likedin-webhook-secret",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  const expected = Deno.env.get("LIKEDIN_PUSH_WEBHOOK_SECRET") ?? "";
  const supplied = req.headers.get("x-likedin-webhook-secret") ?? "";
  if (!(await verifyWebhookSecret(expected, supplied))) {
    return new Response("Unauthorized", { status: 401 });
  }

  try {
    const payload = await req.json();
    const row = payload.record ?? payload;
    const callId = String(row.id ?? "");
    const calleeId = String(row.callee_id ?? "");
    const callerId = String(row.caller_id ?? "");
    const callType = row.call_type === "video" ? "video" : "audio";
    if (!callId || !calleeId || !callerId || row.status !== "ringing") {
      return new Response("Missing or invalid call record", { status: 400 });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      { auth: { persistSession: false, autoRefreshToken: false } },
    );
    const { data: tokens, error } = await supabase
      .from("likedin_push_tokens")
      .select("token")
      .eq("user_id", calleeId);
    if (error) throw error;
    if (!tokens?.length) {
      return new Response(JSON.stringify({ sent: 0, reason: "no_tokens" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const serviceAccountRaw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT_JSON");
    if (!serviceAccountRaw) throw new Error("FIREBASE_SERVICE_ACCOUNT_JSON secret is missing");
    const serviceAccount = JSON.parse(serviceAccountRaw);
    const app = getApps().length ? getApps()[0] : initializeApp({
      credential: cert(serviceAccount),
      projectId: serviceAccount.project_id,
    });

    let sent = 0;
    const invalidTokens: string[] = [];
    const failures: Array<{ code: string; message: string }> = [];

    for (const item of tokens) {
      try {
        // Send data-only + high priority so Android wakes
        // likedinFirebaseBackgroundHandler to post a dismissible full-screen
        // call notification with a finite timeout.
        await getMessaging(app).send({
          token: item.token,
          data: {
            route: "incoming_call",
            call_id: callId,
            caller_id: callerId,
            call_type: callType,
            notification_title: "Likedin",
            notification_body: callType === "video" ? "Incoming video call" : "Incoming audio call",
          },
          android: {
            priority: "high",
            ttl: 60 * 1000,
            collapseKey: `likedin-call-${callId}`,
          },
        });
        sent++;
      } catch (error) {
        const code = (error as { code?: string }).code ?? "unknown";
        const message = error instanceof Error ? error.message : String(error);
        if (code.includes("registration-token-not-registered") || code.includes("invalid-registration-token")) {
          invalidTokens.push(item.token);
        } else {
          failures.push({ code, message });
          console.error("Incoming call FCM send failed", code, message);
        }
      }
    }

    if (invalidTokens.length) {
      await supabase.from("likedin_push_tokens").delete().eq("user_id", calleeId).in("token", invalidTokens);
    }

    return new Response(JSON.stringify({
      sent,
      attempted: tokens.length,
      invalid_tokens_removed: invalidTokens.length,
      failures,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Incoming call push failed", error);
    return new Response("Incoming call push failed", { status: 500 });
  }
});
