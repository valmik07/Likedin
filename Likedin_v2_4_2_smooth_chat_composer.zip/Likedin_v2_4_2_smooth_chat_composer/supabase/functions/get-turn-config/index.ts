import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.8";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const CREDENTIAL_TTL_SECONDS = 15 * 60;
const RATE_LIMIT_REQUESTS = 12;
const RATE_LIMIT_WINDOW_SECONDS = 10 * 60;

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  const authHeader = req.headers.get("Authorization") ?? "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
  if (!token) return json({ error: "Authentication required" }, 401);

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const turnUrl = Deno.env.get("TURN_SERVER_URL");
  const legacyUsername = Deno.env.get("TURN_USERNAME");
  const legacyPassword = Deno.env.get("TURN_PASSWORD");
  const sharedSecret = Deno.env.get("TURN_SHARED_SECRET");
  // Explicit opt-in prevents an accidentally present secret from switching a
  // static-credential provider to Coturn REST mode and breaking calls.
  const useTemporaryCredentials = Deno.env.get("TURN_REST_CREDENTIALS_ENABLED") === "true";
  if (
    !supabaseUrl || !anonKey || !serviceRoleKey || !turnUrl ||
    (useTemporaryCredentials && !sharedSecret) ||
    (!useTemporaryCredentials && (!legacyUsername || !legacyPassword))
  ) {
    console.error("Missing required TURN/Supabase function configuration.");
    return json({ error: "Calling service is not configured" }, 503);
  }

  // Validate the caller's access token; never trust an identity supplied by the request body.
  const authClient = createClient(supabaseUrl, anonKey, {
    global: { headers: { Authorization: `Bearer ${token}` } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data: authData, error: authError } = await authClient.auth.getUser(token);
  if (authError || !authData.user) return json({ error: "Invalid session" }, 401);
  const userId = authData.user.id;

  // Service-role access is confined to this Edge Function. account_slots has no client SELECT policy.
  const admin = createClient(supabaseUrl, serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data: member, error: memberError } = await admin
    .from("account_slots")
    .select("slot")
    .eq("user_id", userId)
    .maybeSingle();
  if (memberError) {
    console.error("Could not verify Likedin pair membership:", memberError.message);
    return json({ error: "Could not verify account membership" }, 503);
  }
  if (!member) return json({ error: "Not an approved Likedin pair member" }, 403);

  const { data: allowed, error: limitError } = await admin.rpc(
    "likedin_allow_turn_credential_request",
    {
      p_user_id: userId,
      p_max_requests: RATE_LIMIT_REQUESTS,
      p_window_seconds: RATE_LIMIT_WINDOW_SECONDS,
    },
  );
  if (limitError) {
    console.error("TURN credential rate-limit check failed:", limitError.message);
    return json({ error: "Calling service is temporarily unavailable" }, 503);
  }
  if (allowed !== true) return json({ error: "Too many call configuration requests. Try again shortly." }, 429);

  const urls = (Deno.env.get("TURN_SERVER_URLS") ?? turnUrl)
    .split(",")
    .map((value) => value.trim())
    .filter(Boolean);
  if (urls.length === 0) {
    console.error("TURN_SERVER_URLS resolved to an empty ICE server list.");
    return json({ error: "Calling service is not configured" }, 503);
  }

  if (useTemporaryCredentials && sharedSecret) {
    // Coturn TURN REST API: username is expiry:identity, password is
    // base64(HMAC-SHA1(sharedSecret, username)). The shared secret never reaches Flutter.
    const expiresAt = Math.floor(Date.now() / 1000) + CREDENTIAL_TTL_SECONDS;
    const username = `${expiresAt}:${userId}`;
    const key = await crypto.subtle.importKey(
      "raw",
      new TextEncoder().encode(sharedSecret),
      { name: "HMAC", hash: "SHA-1" },
      false,
      ["sign"],
    );
    const signature = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(username));
    const credential = btoa(String.fromCharCode(...new Uint8Array(signature)));
    return json({ iceServers: [{ urls, username, credential }], expiresAt, credentialMode: "temporary" }, 200);
  }

  // Compatibility mode for the currently documented ExpressTURN free plan,
  // which supplies static credentials rather than a Coturn REST shared secret.
  // Membership checks and rate limits still apply, but static credentials are
  // not equivalent to short-lived credentials. Keep this until a REST-capable
  // TURN service is configured, so the v1.8 build does not silently break calls.
  return json({
    iceServers: [{ urls, username: legacyUsername, credential: legacyPassword }],
    credentialMode: "legacy-static",
  }, 200);
});

function json(body: Record<string, unknown>, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json", "Cache-Control": "no-store" },
  });
}
