import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../backend/realtime_messaging_service.dart';
import '../utils/chat_info_metrics.dart';
import '../security/hidden_chat_vault.dart';
import 'glassmorphism.dart';
import 'hidden_chat_pin_dialog.dart';
import 'profile_photo_viewer.dart';

class _Preview {
  const _Preview({
    this.name,
    this.online = false,
    this.avatarUrl,
    this.avatarPath,
    this.lastText,
    this.lastAt,
    this.lastIsMine = false,
    this.unread = 0,
    this.peerId,
  });
  final String? name;
  final bool online;
  final String? avatarUrl;
  final String? avatarPath;
  final String? lastText;
  final DateTime? lastAt;
  final bool lastIsMine;
  final int unread;
  final String? peerId;
}

/// Conversation row for the home hub (spec screen 3): avatar with online
/// indicator, name, latest message, timestamp and an unread badge. It only
/// reads data through the existing messaging service and never changes it.
class ConversationCard extends StatefulWidget {
  const ConversationCard({
    required this.onOpen,
    this.onHidden,
    this.onUnhidden,
    this.isHidden = false,
    this.refreshToken = 0,
    super.key,
  });
  final VoidCallback onOpen;
  final VoidCallback? onHidden;
  final Future<void> Function()? onUnhidden;
  final bool isHidden;
  final int refreshToken;

  @override
  State<ConversationCard> createState() => _ConversationCardState();
}

class _ConversationCardState extends State<ConversationCard> {
  late Future<_Preview> _future;
  _Preview? _lastPreview;
  DateTime? _avatarUrlFetchedAt;
  RealtimeChannel? _messagesChannel;
  Timer? _refreshDebounce;
  bool _loadFailed = false;

  @override
  void initState() {
    super.initState();
    _future = _load();
    _subscribeToMessages();
  }

  void _subscribeToMessages() {
    final client = Supabase.instance.client;
    final uid = client.auth.currentUser?.id;
    if (uid == null || _messagesChannel != null) return;
    _messagesChannel = client
        .channel('likedin-home-preview-$uid')
        .onPostgresChanges(event: PostgresChangeEvent.insert, schema: 'public', table: 'messages', callback: (_) => _scheduleReload())
        .onPostgresChanges(event: PostgresChangeEvent.update, schema: 'public', table: 'messages', callback: (payload) {
          final oldRow = payload.oldRecord;
          final newRow = payload.newRecord;
          // Delivery/read timestamp updates do not change the home preview.
          // Reload only when message content or delete state changed.
          final oldHasContent = oldRow.containsKey('body_payload') ||
              oldRow.containsKey('encrypted_payload') || oldRow.containsKey('ciphertext') ||
              oldRow.containsKey('deleted_for_everyone_at');
          final contentChanged = oldHasContent
              ? oldRow['body_payload'] != newRow['body_payload'] ||
                  oldRow['encrypted_payload'] != newRow['encrypted_payload'] ||
                  oldRow['ciphertext'] != newRow['ciphertext'] ||
                  oldRow['deleted_for_everyone_at'] != newRow['deleted_for_everyone_at']
              : newRow['deleted_for_everyone_at'] != null || newRow['edited_at'] != null;
          if (contentChanged) _scheduleReload();
        })
        .onPostgresChanges(event: PostgresChangeEvent.delete, schema: 'public', table: 'messages', callback: (_) => _scheduleReload())
      ..subscribe();
  }

  void _scheduleReload() {
    _refreshDebounce?.cancel();
    _refreshDebounce = Timer(const Duration(milliseconds: 300), () {
      if (mounted) setState(() => _future = _load());
    });
  }

  @override
  void dispose() {
    _refreshDebounce?.cancel();
    final channel = _messagesChannel;
    if (channel != null) Supabase.instance.client.removeChannel(channel);
    super.dispose();
  }

  @override
  void didUpdateWidget(covariant ConversationCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.refreshToken != widget.refreshToken) {
      setState(() => _future = _load());
    }
  }

  Future<_Preview> _load() async {
    _loadFailed = false;
    final client = Supabase.instance.client;
    final service = RealtimeMessagingService(client);
    final peer = await service.getPeerProfile();
    if (peer == null) {
      _lastPreview = const _Preview();
      return _lastPreview!;
    }

    String? lastText;
    DateTime? lastAt;
    var lastIsMine = false;
    // These local-visibility values are also used by the unread-count query
    // below, so they must outlive the preview-loading try block.
    Set<String> hidden = <String>{};
    Set<String> postClearVisible = <String>{};
    int? clearedBeforeMs;
    List<RemoteMessage> postClearExceptionMessages = <RemoteMessage>[];
    try {
      final uid = service.currentUserId;
      final peerId = await service.getPeerId();
      if (peerId != null) {
        try {
          final raw = await const FlutterSecureStorage().read(key: 'likedin_local_chat_v1_${uid}_$peerId');
          if (raw != null && raw.isNotEmpty) {
            final data = Map<String, dynamic>.from(jsonDecode(raw) as Map);
            hidden = (data['hidden'] as List? ?? const []).map((e) => e.toString()).toSet();
            postClearVisible = (data['postClearVisible'] as List? ?? const []).map((e) => e.toString()).toSet();
            clearedBeforeMs = data['clearedBeforeMs'] as int?;
          }
        } catch (_) {}
      }

      if (clearedBeforeMs != null) {
        // A cleared chat has no visible pre-clear history except IDs explicitly
        // preserved as post-clear deliveries. Do one newest-page query and one
        // ID lookup for those exceptions instead of paging through old history.
        final newestPage = await service.loadConversation(limit: 100);
        if (postClearVisible.isNotEmpty) {
          postClearExceptionMessages = await service.loadMessagesByIds(postClearVisible);
        }
        final candidatesById = <String, RemoteMessage>{
          for (final message in newestPage) message.id: message,
          for (final message in postClearExceptionMessages) message.id: message,
        };
        final candidates = candidatesById.values.toList()
          ..sort((a, b) {
            final byTime = a.createdAt.compareTo(b.createdAt);
            return byTime != 0 ? byTime : a.id.compareTo(b.id);
          });
        for (final message in candidates.reversed) {
          if (!ChatInfoMetrics.isLocallyVisible(
            message,
            hiddenMessageIds: hidden,
            clearedBeforeMs: clearedBeforeMs,
            postClearVisibleMessageIds: postClearVisible,
          )) continue;
          lastText = message.deletedForEveryoneAt != null
              ? 'Message deleted'
              : _describe(message.text);
          lastAt = message.createdAt;
          lastIsMine = message.senderId == uid;
          break;
        }
      } else {
        // Without a local clear cutoff, keep paging only when individually
        // hidden messages conceal the newest preview.
        DateTime? beforeCreatedAt;
        String? beforeId;
        for (var pageIndex = 0; pageIndex < 100; pageIndex++) {
          final page = await service.loadConversation(
            beforeCreatedAt: beforeCreatedAt,
            beforeId: beforeId,
            limit: 100,
          );
          if (page.isEmpty) break;
          for (final message in page.reversed) {
            if (!ChatInfoMetrics.isLocallyVisible(
              message,
              hiddenMessageIds: hidden,
              clearedBeforeMs: clearedBeforeMs,
              postClearVisibleMessageIds: postClearVisible,
            )) continue;
            lastText = message.deletedForEveryoneAt != null
                ? 'Message deleted'
                : _describe(message.text);
            lastAt = message.createdAt;
            lastIsMine = message.senderId == uid;
            break;
          }
          if (lastAt != null || page.length < 100) break;
          beforeCreatedAt = page.first.createdAt;
          beforeId = page.first.id;
        }
      }
    } catch (error) {
      _loadFailed = true;
      debugPrint('Home conversation preview failed: $error');
    }

    var unread = 0;
    try {
      final uid = client.auth.currentUser?.id;
      if (uid != null) {
        String? cursor;
        const pageSize = 500;
        while (true) {
          var query = client
              .from('messages')
              .select('id,client_message_id,created_at')
              .eq('recipient_id', uid)
              .isFilter('read_at', null)
              .isFilter('deleted_for_everyone_at', null);
          if (clearedBeforeMs != null) {
            final cutoff = DateTime.fromMillisecondsSinceEpoch(clearedBeforeMs, isUtc: true)
                .toIso8601String();
            query = query.gt('created_at', cutoff);
          }
          if (cursor != null) query = query.gt('id', cursor);
          final rows = await query.order('id').limit(pageSize);
          if (rows.isEmpty) break;
          for (final row in rows) {
            final id = row['id']?.toString() ?? '';
            final clientId = row['client_message_id']?.toString();
            final created = DateTime.tryParse(row['created_at']?.toString() ?? '');
            final isPostClearException = postClearVisible.contains(id) ||
                (clientId != null && postClearVisible.contains(clientId));
            if (hidden.contains(id) ||
                (clientId != null && hidden.contains(clientId)) ||
                (clearedBeforeMs != null && created != null &&
                    created.millisecondsSinceEpoch <= clearedBeforeMs && !isPostClearException)) {
              continue;
            }
            unread++;
          }
          if (rows.length < pageSize) break;
          cursor = rows.last['id']?.toString();
          if (cursor == null || cursor.isEmpty) break;
        }
        // Some post-clear deliveries can carry a clock-skewed timestamp at or
        // before the cutoff. Count those explicit IDs without re-scanning the
        // cleared history, avoiding duplicates with the query above.
        if (clearedBeforeMs != null) {
          for (final message in postClearExceptionMessages) {
            if (message.recipientId == uid && message.readAt == null &&
                message.deletedForEveryoneAt == null &&
                message.createdAt.millisecondsSinceEpoch <= clearedBeforeMs &&
                !hidden.contains(message.id) &&
                (message.clientMessageId == null || !hidden.contains(message.clientMessageId))) {
              unread++;
            }
          }
        }
      }
    } catch (_) {}

    final avatarPath = peer.avatarPath;
    String? avatarUrl;
    if (avatarPath != null && avatarPath.isNotEmpty) {
      // Message events refresh the conversation preview, not the profile
      // image. Reuse even a failed/null result for the same path, and only
      // renew a signed URL periodically so realtime bursts do not refetch it.
      final cacheIsFresh = _lastPreview?.avatarPath == avatarPath &&
          _avatarUrlFetchedAt != null &&
          DateTime.now().difference(_avatarUrlFetchedAt!) < const Duration(minutes: 45);
      if (cacheIsFresh) {
        avatarUrl = _lastPreview?.avatarUrl;
      } else {
        try {
          avatarUrl = await service.profileAvatarSignedUrl(avatarPath);
        } catch (_) {
          avatarUrl = null;
        } finally {
          _avatarUrlFetchedAt = DateTime.now();
        }
      }
    } else {
      _avatarUrlFetchedAt = null;
    }

    var visibleName = peer.name;
    try {
      final peerId = await service.getPeerId();
      if (peerId != null) {
        final prefs = await SharedPreferences.getInstance();
        final nickname = prefs.getString('likedIn_nickname_$peerId')?.trim();
        if (nickname != null && nickname.isNotEmpty) visibleName = nickname;
      }
    } catch (_) {}
    final preview = _Preview(
      name: visibleName,
      online: peer.online,
      peerId: peer.id,
      avatarUrl: avatarUrl,
      avatarPath: avatarPath,
      lastText: lastText,
      lastAt: lastAt,
      lastIsMine: lastIsMine,
      unread: unread,
    );
    _lastPreview = preview;
    return preview;
  }

  Future<void> _hideConversation(BuildContext context, _Preview data) async {
    final peerId = data.peerId;
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (peerId == null || peerId.isEmpty || uid == null) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Hide this chat?'),
        content: const Text(
          'This conversation will disappear from the normal chat list and Calls tab. Open it by pressing the Likedin logo on Home. Messages, calls and delivery status will not be deleted.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Hide chat'),
          ),
        ],
      ),
    );
    if (confirmed != true || !context.mounted) return;

    final vault = HiddenChatVault();
    try {
      if (!await vault.hasPassword(uid)) {
        final passwordResult = await HiddenChatPinDialog.show(context, setup: true);
        final password = passwordResult?.password;
        if (password == null || !context.mounted) return;
        await vault.configurePassword(uid, password);
      }
      await vault.setHidden(uid, peerId, true);
      if (!context.mounted) return;
      widget.onHidden?.call();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Chat hidden. Press the Likedin logo on Home to open it.')),
      );
    } catch (error) {
      debugPrint('Could not hide conversation: $error');
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not hide this chat. Try again.')),
      );
    }
  }

  Future<void> _unhideConversation(BuildContext context, _Preview data) async {
    final peerId = data.peerId;
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (peerId == null || peerId.isEmpty || uid == null) return;
    try {
      await HiddenChatVault().setHidden(uid, peerId, false);
      if (!context.mounted) return;
      await widget.onUnhidden?.call();
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Chat restored to the normal chat list.')),
      );
    } catch (error) {
      debugPrint('Could not unhide conversation: $error');
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not restore this chat. Please try again.')),
      );
    }
  }

  static String _describe(String raw) {
    if (raw.contains('__likedin_media_v1')) {
      try {
        final decoded = jsonDecode(raw);
        if (decoded is Map) {
          switch (decoded['kind']?.toString()) {
            case 'image':
              return 'Photo';
            case 'video':
              return 'Video';
            case 'audio':
              return 'Voice message';
          }
        }
      } catch (_) {}
      return 'Attachment';
    }
    return raw.replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  static String _time(BuildContext context, DateTime value) {
    final at = value.toLocal();
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final day = DateTime(at.year, at.month, at.day);
    if (day == today) {
      return MaterialLocalizations.of(context).formatTimeOfDay(TimeOfDay.fromDateTime(at));
    }
    if (day == DateTime(today.year, today.month, today.day - 1)) return 'Yesterday';
    return MaterialLocalizations.of(context).formatMediumDate(at);
  }

  Future<void> _openProfilePhoto(BuildContext context, _Preview data) async {
    final path = data.avatarPath;
    if (path == null || path.isEmpty) return;
    try {
      // Request a fresh signed URL at the moment of opening, as the URL cached
      // for the Home thumbnail may have expired while the app was backgrounded.
      final url = await RealtimeMessagingService(Supabase.instance.client)
          .profileAvatarSignedUrl(path);
      if (!context.mounted) return;
      await Navigator.of(context).push<void>(
        MaterialPageRoute<void>(
          builder: (_) => ProfilePhotoViewerPage(
            imageUrl: url,
            displayName: data.name ?? 'Likedin friend',
          ),
        ),
      );
    } catch (_) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not open the profile photo.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final primary = likedinPrimary(brightness);
    final muted = likedinMutedText(brightness);
    return FutureBuilder<_Preview>(
      future: _future,
      builder: (context, snapshot) {
        final loading = !snapshot.hasData && _lastPreview == null && snapshot.connectionState != ConnectionState.done;
        final data = snapshot.data ?? _lastPreview ?? const _Preview();
        final name = data.name ?? 'Your conversation';
        final hasUnread = data.unread > 0;
        final hasError = snapshot.hasError || _loadFailed;
        final subtitle = loading
            ? 'Loading…'
            : hasError
                ? 'Could not load conversation. Tap to retry.'
                : data.lastText == null
                    ? 'Tap to start chatting'
                    : '${data.lastIsMine ? 'You: ' : ''}${data.lastText}';
        return GlassPanel(
          radius: BorderRadius.circular(22),
          frosted: false,
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(22),
              onTap: hasError ? () => setState(() => _future = _load()) : widget.onOpen,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                child: Row(
                  children: [
                    Stack(
                      clipBehavior: Clip.none,
                      children: [
                        Tooltip(
                          message: data.avatarPath == null ? name : 'View $name profile photo',
                          child: GestureDetector(
                            behavior: HitTestBehavior.opaque,
                            onTap: data.avatarPath == null ? null : () => _openProfilePhoto(context, data),
                            child: RepaintBoundary(
                              child: CircleAvatar(
                                radius: 27,
                                backgroundColor: primary.withValues(alpha: .16),
                                child: data.avatarUrl == null
                                    ? Text(
                                        name.isEmpty ? '?' : String.fromCharCode(name.runes.first).toUpperCase(),
                                        style: TextStyle(color: primary, fontSize: 21, fontWeight: FontWeight.w800),
                                      )
                                    : ClipOval(
                                        child: Image.network(
                                          data.avatarUrl!,
                                          width: 54,
                                          height: 54,
                                          cacheWidth: 144,
                                          fit: BoxFit.cover,
                                          gaplessPlayback: true,
                                          errorBuilder: (_, __, ___) => Center(
                                            child: Text(
                                              name.isEmpty ? '?' : String.fromCharCode(name.runes.first).toUpperCase(),
                                              style: TextStyle(color: primary, fontSize: 21, fontWeight: FontWeight.w800),
                                            ),
                                          ),
                                        ),
                                      ),
                              ),
                            ),
                          ),
                        ),
                        if (data.online)
                          Positioned(
                            right: -1,
                            bottom: -1,
                            child: Semantics(
                              label: 'Online',
                              child: Container(
                                width: 14,
                                height: 14,
                                decoration: BoxDecoration(
                                  color: const Color(0xFF2FBF86),
                                  shape: BoxShape.circle,
                                  border: Border.all(color: likedinSurface(brightness), width: 2.5),
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            subtitle,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 14,
                              color: hasUnread ? likedinOnSurface(brightness) : muted,
                              fontWeight: hasUnread ? FontWeight.w600 : FontWeight.w400,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        if (data.lastAt != null)
                          Text(_time(context, data.lastAt!), style: TextStyle(fontSize: 12, color: muted)),
                        const SizedBox(height: 6),
                        if (hasUnread)
                          Semantics(
                            label: '${data.unread} unread',
                            child: Container(
                              constraints: const BoxConstraints(minWidth: 22),
                              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                              decoration: BoxDecoration(
                                gradient: likedinPrimaryGradient(brightness),
                                borderRadius: BorderRadius.circular(11),
                              ),
                              child: Text(
                                '${data.unread}',
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                          )
                        else
                          const SizedBox(height: 22),
                      ],
                    ),
                    PopupMenuButton<String>(
                      tooltip: 'Conversation options',
                      padding: EdgeInsets.zero,
                      onSelected: (value) {
                        if (value == 'hide') unawaited(_hideConversation(context, data));
                        if (value == 'unhide') unawaited(_unhideConversation(context, data));
                      },
                      itemBuilder: (menuContext) => [
                        PopupMenuItem<String>(
                          value: widget.isHidden ? 'unhide' : 'hide',
                          child: Row(
                            children: [
                              Icon(
                                widget.isHidden ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                                size: 19,
                              ),
                              const SizedBox(width: 10),
                              Text(widget.isHidden ? 'Unhide chat' : 'Hide chat'),
                            ],
                          ),
                        ),
                      ],
                      icon: Icon(Icons.more_vert_rounded, color: muted),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
