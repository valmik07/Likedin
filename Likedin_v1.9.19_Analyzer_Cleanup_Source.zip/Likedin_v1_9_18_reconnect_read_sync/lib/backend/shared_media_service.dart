import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:http/http.dart' as http;
import 'package:mime/mime.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import 'package:video_compress/video_compress.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:image/image.dart' as img;

import 'backend_config.dart';

/// Encode a bounded contact-sheet preview off the UI isolate. The caller only
/// sends images up to 12 MB through this worker to protect low-memory phones.
Uint8List? _encodeContactThumbnail(Uint8List bytes) {
  try {
    img.Decoder.defaultMaxPixels = 16 * 1024 * 1024;
    final decoded = img.decodeImage(bytes, frame: 0);
    if (decoded == null) return null;
    final oriented = img.bakeOrientation(decoded);
    final longest = max(oriented.width, oriented.height);
    final preview = longest > 480
        ? img.copyResize(
            oriented,
            width: (oriented.width * 480 / longest).round().clamp(1, 480).toInt(),
            height: (oriented.height * 480 / longest).round().clamp(1, 480).toInt(),
          )
        : oriented;
    return Uint8List.fromList(img.encodeJpg(preview, quality: 72));
  } catch (_) {
    return null;
  }
}

/// Private shared media transport. Uploads use Supabase Storage's TUS endpoint
/// so offsets survive process death. A persisted queue is retried in the foreground when the user initiates another send.
class SharedMediaService {
  SharedMediaService(this.client);
  final SupabaseClient client;
  static const bucket = 'likedin-media';
  static const maxBytes = 50 * 1024 * 1024;
  /// Animated media has a much smaller per-item budget to protect the 1 GB bucket.
  static const maxGifBytes = 2 * 1024 * 1024;
  static const _maxGifInputBytes = 8 * 1024 * 1024;
  static final Map<String, Future<File>> _cacheLoadsInFlight = <String, Future<File>>{};
  static String? lastQueueError;
  static const _queueKey = 'likedin_media_retry_queue_v2';
  static const _quarantineKey = 'likedin_media_retry_queue_quarantine_v1';
  static const _uuid = Uuid();
  static const _chunkSize = 5 * 1024 * 1024;
  static Future<bool>? _processingQueue;
  static Future<void> _queueMutationTail = Future<void>.value();
  static bool _retryRequested = false;
  static String? _quarantineError;
  static int lastQuarantinedCount = 0;

  static const Set<String> _bucketAllowedMimeTypes = <String>{
    'image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/heic', 'image/heif',
    'video/mp4', 'video/quicktime', 'video/webm', 'video/3gpp', 'video/x-matroska',
    'audio/mp4', 'audio/x-m4a', 'audio/m4a', 'audio/aac', 'audio/mpeg', 'audio/mp3',
    'audio/wav', 'audio/x-wav', 'audio/webm', 'audio/ogg', 'audio/flac',
    'audio/x-flac', 'audio/amr', 'audio/3gpp', 'audio/3gpp2', 'audio/x-ms-wma', 'audio/midi', 'audio/x-aiff',
    'application/pdf', 'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'text/plain', 'text/csv', 'application/json', 'application/zip',
    'application/octet-stream',
  };

  static String _queueKeyFor(String uid) => '$_queueKey:$uid';

  bool isMediaPayload(String value) {
    if (!_looksLikeMediaPayload(value)) return false;
    try {
      final m = jsonDecode(value);
      return m is Map && m['__likedin_media_v1'] == true;
    } catch (_) {
      return false;
    }
  }

  Map<String, dynamic>? decode(String value) {
    if (!_looksLikeMediaPayload(value)) return null;
    try {
      final m = jsonDecode(value);
      if (m is Map && m['__likedin_media_v1'] == true) {
        return Map<String, dynamic>.from(m);
      }
    } catch (_) {}
    return null;
  }

  static bool _looksLikeMediaPayload(String value) {
    final trimmed = value.trimLeft();
    return trimmed.startsWith('{') && trimmed.contains('"__likedin_media_v1"');
  }

  /// Human-readable summary of a media payload for reply quotes and banners.
  String describePayload(Map<String, dynamic> payload) {
    final kind = payload['kind']?.toString() ?? 'file';
    final name = payload['name']?.toString() ?? 'Attachment';
    switch (kind) {
      case 'image':
        return payload['animated'] == true ? 'GIF' : 'Photo · $name';
      case 'video':
        return 'Video · $name';
      case 'audio':
        return 'Voice message';
      default:
        return 'File · $name';
    }
  }

  static String? _audioMimeForName(String filename) {
    switch (p.extension(filename).toLowerCase()) {
      case '.m4a':
      case '.m4b':
      case '.m4p':
      case '.mp4':
        return 'audio/mp4';
      case '.3gp':
        return 'audio/3gpp';
      case '.3g2':
        return 'audio/3gpp2';
      case '.webm':
        return 'audio/webm';
      case '.mp3':
        return 'audio/mpeg';
      case '.aac':
        return 'audio/aac';
      case '.wav':
        return 'audio/wav';
      case '.ogg':
        return 'audio/ogg';
      case '.flac':
        return 'audio/flac';
      case '.mkv':
        // The bytes are still stored as an opaque allowed file, but the
        // explicit kind remains audio so the chat uses the audio player.
        return 'application/octet-stream';
    }
    return null;
  }

  static String _normalizeMime(String filename, {List<int>? headerBytes}) {
    final ext = p.extension(filename).replaceFirst('.', '').toLowerCase();
    final sniffed = headerBytes == null ? null : _sniffMimeFromHeader(headerBytes);
    final detected = sniffed ?? lookupMimeType(filename, headerBytes: headerBytes) ??
        (ext == 'm4a' ? 'audio/mp4' : 'application/octet-stream');
    final normalized = switch (detected) {
      'audio/x-m4a' || 'audio/m4a' => 'audio/mp4',
      'audio/x-wav' => 'audio/wav',
      'audio/x-flac' => 'audio/flac',
      'audio/mp3' => 'audio/mpeg',
      _ => detected,
    };
    // Supabase Storage rejects a Content-Type that is not in the bucket's
    // allow-list. Unknown formats (RAR/7z/APK/SVG/AVIF/HTML, etc.) remain
    // transferable as opaque files. BMP/TIFF photos are converted to JPEG by
    // prepare() before upload. Header sniffing beats a misleading extension.
    return _bucketAllowedMimeTypes.contains(normalized)
        ? normalized
        : 'application/octet-stream';
  }

  static String? _sniffMimeFromHeader(List<int> bytes) {
    // Explicit signatures cover the media formats used by the chat pipeline.
    if (bytes.length >= 6 &&
        (String.fromCharCodes(bytes.take(6)) == 'GIF87a' ||
            String.fromCharCodes(bytes.take(6)) == 'GIF89a')) {
      return 'image/gif';
    }
    if (bytes.length >= 3 && bytes[0] == 0xFF && bytes[1] == 0xD8 && bytes[2] == 0xFF) {
      return 'image/jpeg';
    }
    if (bytes.length >= 8 &&
        bytes[0] == 0x89 && bytes[1] == 0x50 && bytes[2] == 0x4E && bytes[3] == 0x47 &&
        bytes[4] == 0x0D && bytes[5] == 0x0A && bytes[6] == 0x1A && bytes[7] == 0x0A) {
      return 'image/png';
    }
    if (bytes.length >= 12 &&
        String.fromCharCodes(bytes.sublist(0, 4)) == 'RIFF' &&
        String.fromCharCodes(bytes.sublist(8, 12)) == 'WEBP') {
      return 'image/webp';
    }
    if (bytes.length >= 2 && bytes[0] == 0x42 && bytes[1] == 0x4D) {
      return 'image/bmp';
    }
    if (bytes.length >= 4 &&
        ((bytes[0] == 0x49 && bytes[1] == 0x49 && bytes[2] == 0x2A && bytes[3] == 0x00) ||
            (bytes[0] == 0x4D && bytes[1] == 0x4D && bytes[2] == 0x00 && bytes[3] == 0x2A))) {
      return 'image/tiff';
    }
    if (bytes.length >= 12 && String.fromCharCodes(bytes.sublist(4, 8)) == 'ftyp') {
      final brand = String.fromCharCodes(bytes.sublist(8, 12)).toLowerCase();
      if (brand == 'avif' || brand == 'avis') return 'image/avif';
      if (brand == 'heic' || brand == 'heix' || brand == 'hevc' ||
          brand == 'hevx' || brand == 'mif1' || brand == 'msf1') {
        return 'image/heic';
      }
      if (brand == 'm4a ' || brand == 'm4b ' || brand == 'm4p ') return 'audio/mp4';
      if (brand == 'qt  ') return 'video/quicktime';
      if (brand.startsWith('3gp')) return 'video/3gpp';
      return 'video/mp4';
    }
    if (bytes.length >= 4 && bytes[0] == 0x1A && bytes[1] == 0x45 &&
        bytes[2] == 0xDF && bytes[3] == 0xA3) {
      return 'video/webm';
    }
    // Common audio signatures. These also cover Android document providers
    // that return extensionless cache files for selected audio assets.
    if (bytes.length >= 12 &&
        String.fromCharCodes(bytes.sublist(0, 4)) == 'RIFF' &&
        String.fromCharCodes(bytes.sublist(8, 12)) == 'WAVE') {
      return 'audio/wav';
    }
    if (bytes.length >= 3 && String.fromCharCodes(bytes.take(3)) == 'ID3') {
      return 'audio/mpeg';
    }
    if (bytes.length >= 2 && bytes[0] == 0xFF && (bytes[1] & 0xE0) == 0xE0) {
      return 'audio/mpeg';
    }
    if (bytes.length >= 4 && String.fromCharCodes(bytes.take(4)) == 'OggS') {
      return 'audio/ogg';
    }
    if (bytes.length >= 4 && String.fromCharCodes(bytes.take(4)) == 'fLaC') {
      return 'audio/flac';
    }
    if (bytes.length >= 2 && bytes[0] == 0xFF && (bytes[1] & 0xF6) == 0xF0) {
      return 'audio/aac';
    }
    if (bytes.length >= 5 && String.fromCharCodes(bytes.take(5)) == '%PDF-') {
      return 'application/pdf';
    }
    return null;
  }

  /// Returns the best-effort source type before applying the Storage allow-list.
  /// This is also used to preview older attachments whose saved metadata was
  /// generic even though the bytes are a GIF/photo/video.
  static Future<String?> detectRawMimeType(File file, {String? displayName}) async {
    if (!await file.exists()) throw StateError('The selected file is no longer available.');
    RandomAccessFile? handle;
    List<int> header = const <int>[];
    try {
      handle = await file.open();
      header = await handle.read(64);
    } finally {
      await handle?.close();
    }
    final suppliedName = displayName?.trim().isNotEmpty == true
        ? displayName!.trim()
        : file.path;
    return _sniffMimeFromHeader(header) ?? lookupMimeType(suppliedName);
  }

  /// Classifies from the file header first and uses the name only as a fallback.
  /// This matters for Android MediaStore assets whose title may not include an
  /// extension and for document providers that expose opaque cache filenames.
  static Future<String> detectMimeType(File file, {String? displayName}) async {
    if (!await file.exists()) throw StateError('The selected file is no longer available.');
    RandomAccessFile? handle;
    List<int> header = const <int>[];
    try {
      handle = await file.open();
      header = await handle.read(64);
    } finally {
      await handle?.close();
    }
    final suppliedName = displayName?.trim().isNotEmpty == true
        ? displayName!.trim()
        : file.path;
    final detected = _normalizeMime(suppliedName, headerBytes: header);
    if (detected != 'application/octet-stream' || p.extension(suppliedName).isNotEmpty) {
      return detected;
    }
    // Android MediaStore titles frequently omit extensions. If the header is
    // not self-identifying (for example, a DOCX ZIP container), retry using the
    // actual cached path's suffix before treating it as an opaque file.
    return _normalizeMime(file.path, headerBytes: header);
  }

  static String? extensionForMime(String mime) => const <String, String>{
        'image/jpeg': '.jpg',
        'image/png': '.png',
        'image/gif': '.gif',
        'image/webp': '.webp',
        'image/heic': '.heic',
        'image/heif': '.heif',
        'video/mp4': '.mp4',
        'video/quicktime': '.mov',
        'video/webm': '.webm',
        'video/3gpp': '.3gp',
        'audio/mp4': '.m4a',
        'audio/aac': '.aac',
        'audio/mpeg': '.mp3',
        'audio/wav': '.wav',
        'audio/ogg': '.ogg',
        'audio/flac': '.flac',
        'audio/amr': '.amr',
        'audio/3gpp': '.3gp',
        'audio/3gpp2': '.3g2',
        'audio/midi': '.mid',
        'audio/x-aiff': '.aiff',
        'application/pdf': '.pdf',
      }[mime];

  static String _storageNameFor(String displayName, String filePath, String mime) {
    final supplied = displayName.trim().isEmpty ? p.basename(filePath) : p.basename(displayName.trim());
    final preferredExtension = extensionForMime(mime);
    if (preferredExtension == null) return supplied.isEmpty ? p.basename(filePath) : supplied;
    final base = p.extension(supplied).isEmpty ? supplied : p.basenameWithoutExtension(supplied);
    return '$base$preferredExtension';
  }

  /// Copies a platform picker stream to a bounded app-private temporary file.
  /// Some Android document providers return a content URI without a filesystem
  /// path, but still expose readable bytes through PlatformFile.readStream.
  static Future<File> copyStreamToTemporaryFile(
    Stream<List<int>> stream,
    String fileName, {
    required int maxSizeBytes,
  }) async {
    final tempDir = await getTemporaryDirectory();
    final extension = p.extension(fileName).toLowerCase();
    final safeExtension = RegExp(r'^\.[a-z0-9]{1,10}$').hasMatch(extension) ? extension : '';
    final output = File(p.join(tempDir.path, 'likedin_picker_${_uuid.v4()}$safeExtension'));
    final sink = output.openWrite();
    var total = 0;
    try {
      await for (final chunk in stream) {
        total += chunk.length;
        if (total > maxSizeBytes) {
          throw StateError('The selected file exceeds the ${maxSizeBytes ~/ (1024 * 1024)} MB limit.');
        }
        sink.add(chunk);
      }
      await sink.flush();
      await sink.close();
      if (total <= 0) throw StateError('The selected file is empty.');
      return output;
    } catch (_) {
      try { await sink.close(); } catch (_) {}
      try { if (await output.exists()) await output.delete(); } catch (_) {}
      rethrow;
    }
  }

  /// Prepares media without modifying the user's original file.
  /// GIFs are re-encoded as animated WebP at a smaller size in a worker isolate.
  /// Video compression remains on the existing native video pipeline.
  Future<File> prepare(File source, {String? mimeType}) async {
    final mime = mimeType ?? await detectMimeType(source);
    final rawMime = await _rawMimeType(source);
    if (mime == 'image/gif' || rawMime == 'image/gif') {
      return _prepareGif(source);
    }
    // Supabase's private bucket does not allow BMP/TIFF Content-Types. Convert
    // these valid raster photos to JPEG before queueing so they still render as
    // images on the receiver instead of arriving as generic file attachments.
    if (rawMime == 'image/bmp' || rawMime == 'image/tiff' ||
        mime == 'image/bmp' || mime == 'image/tiff') {
      return _prepareStillImageAsJpeg(source);
    }
    if (!mime.startsWith('video/')) return source;
    final result = await VideoCompress.compressVideo(
      source.path,
      quality: VideoQuality.MediumQuality,
      deleteOrigin: false,
      includeAudio: true,
      frameRate: 30,
    );
    final compressed = result?.file;
    if (compressed == null || !await compressed.exists()) return source;
    final originalSize = await source.length();
    final compressedSize = await compressed.length();
    if (compressedSize >= originalSize || compressedSize == 0) return source;
    return compressed;
  }

  Future<String?> _rawMimeType(File source) => detectRawMimeType(source);

  Future<File> _prepareStillImageAsJpeg(File source) async {
    final sourceSize = await source.length();
    if (sourceSize <= 0 || sourceSize > maxBytes) {
      throw StateError('Choose a BMP/TIFF photo smaller than 50 MB.');
    }
    final bytes = await source.readAsBytes();
    final encoded = await compute<Uint8List, Uint8List?>(
      _encodeStaticImageAsJpeg,
      bytes,
      debugLabel: 'likedin-raster-photo-conversion',
    );
    if (encoded == null || encoded.isEmpty || encoded.length > maxBytes) {
      throw StateError('This BMP/TIFF photo could not be converted. Choose a JPG, PNG or WebP instead.');
    }
    final tempDir = await getTemporaryDirectory();
    final output = File(p.join(tempDir.path, 'likedin_photo_${_uuid.v4()}.jpg'));
    await output.writeAsBytes(encoded, flush: true);
    return output;
  }

  Future<File> _prepareGif(File source) async {
    final originalSize = await source.length();
    if (originalSize <= 0 || originalSize > _maxGifInputBytes) {
      throw StateError('GIFs must be 1 byte–8 MB before optimization.');
    }
    final input = await source.readAsBytes();
    Uint8List? optimized;
    try {
      optimized = await compute<Uint8List, Uint8List?>(
        _encodeCompactAnimatedWebp,
        input,
        debugLabel: 'likedin-gif-optimization',
      );
    } catch (error) {
      // A small GIF is still safe to send unmodified. Larger ones must not
      // silently consume the shared bucket when optimization failed.
      if (originalSize <= maxGifBytes) return source;
      throw StateError('This GIF is too complex to optimize on this device. Choose a smaller GIF.');
    }

    if (optimized == null || optimized.isEmpty || optimized.length >= originalSize) {
      if (originalSize <= maxGifBytes) return source;
      throw StateError('This GIF could not be reduced below the 2 MB sharing limit. Choose a smaller GIF.');
    }
    if (optimized.length > maxGifBytes) {
      if (originalSize <= maxGifBytes) return source;
      throw StateError('This GIF is still larger than 2 MB after optimization. Choose a shorter or smaller GIF.');
    }

    final tempDir = await getTemporaryDirectory();
    final output = File(p.join(tempDir.path, 'likedin_gif_${_uuid.v4()}.webp'));
    await output.writeAsBytes(optimized, flush: true);
    return output;
  }

  Future<Map<String, dynamic>> upload(
    File file, {
    String? objectPath,
    String? displayName,
    bool animated = false,
    String? kindOverride,
    void Function(double progress)? onProgress,
  }) async {
    final uid = client.auth.currentUser?.id;
    if (uid == null) throw StateError('Sign in before sharing files.');
    final stat = await file.length();
    if (stat <= 0 || stat > maxBytes) {
      throw StateError('Files must be between 1 byte and 50 MB after compression.');
    }
    final name = (displayName?.trim().isNotEmpty == true)
        ? displayName!.trim()
        : p.basename(file.path);
    var mime = await detectMimeType(file, displayName: name);
    if (kindOverride == 'audio' && mime.startsWith('video/')) {
      mime = _audioMimeForName(name) ?? 'application/octet-stream';
    }
    final ext = p.extension(name).replaceFirst('.', '').toLowerCase();
    final object = objectPath ?? '$uid/${_uuid.v4()}${ext.isEmpty ? '' : '.$ext'}';
    if (animated && stat <= maxGifBytes) {
      // A GIF is capped at 2 MB after optimization, so the SDK's single-request
      // upload is faster than creating and probing a resumable TUS session.
      // The durable queue keeps this object path stable and reconciles a lost
      // response by checking Storage before retrying.
      try {
        await client.storage.from(bucket).upload(
          object,
          file,
          fileOptions: FileOptions(
            cacheControl: '3600',
            contentType: mime,
            upsert: false,
          ),
        );
      } catch (_) {
        var alreadyUploaded = false;
        try {
          final dynamic info = await client.storage.from(bucket).info(object);
          final dynamic storedMetadata = info.metadata;
          final storedMime = storedMetadata is Map
              ? (storedMetadata['mimetype'] ?? storedMetadata['contentType'])?.toString()
              : null;
          alreadyUploaded = info.size == stat &&
              (storedMime == null || storedMime == mime);
        } catch (_) {
          // A failed info lookup is not proof that the object was committed.
        }
        if (!alreadyUploaded) {
          // Some project Storage policies or transient proxy paths may reject
          // the direct upload endpoint. Fall back to the already-tested TUS
          // transport without changing the durable object path.
          await _tusUpload(file, object, mime, onProgress: onProgress);
        }
      }
      onProgress?.call(1);
    } else {
      await _tusUpload(file, object, mime, onProgress: onProgress);
    }
    final kind = kindOverride ?? (mime.startsWith('image/')
        ? 'image'
        : mime.startsWith('video/')
            ? 'video'
            : mime.startsWith('audio/')
                ? 'audio'
                : 'file');
    final metadata = <String, dynamic>{
      '__likedin_media_v1': true,
      'path': object,
      'name': p.basename(name),
      'mime': mime,
      'size': stat,
      'kind': kind,
      if (animated) 'animated': true,
    };

    // Small JPEG sidecars let Contact Info paint previews without downloading
    // a complete video or a full-resolution photo for a 76px tile.
    File? thumbnail;
    try {
      if (kind == 'video') {
        thumbnail = await VideoCompress.getFileThumbnail(
          file.path,
          quality: 55,
          position: 0,
        );
      } else if (kind == 'image' && stat <= 12 * 1024 * 1024) {
        final sourceBytes = await file.readAsBytes();
        final thumbnailBytes = await compute(_encodeContactThumbnail, sourceBytes);
        if (thumbnailBytes != null && thumbnailBytes.isNotEmpty) {
          final temp = await getTemporaryDirectory();
          final generated = File(p.join(temp.path, 'likedin_thumb_${_uuid.v4()}.jpg'));
          thumbnail = generated;
          await generated.writeAsBytes(thumbnailBytes, flush: true);
        }
      }
      final generatedThumbnail = thumbnail;
      if (generatedThumbnail != null &&
          await generatedThumbnail.exists() &&
          await generatedThumbnail.length() > 0) {
        final thumbnailPath = '$object.thumb.jpg';
        await client.storage.from(bucket).upload(
          thumbnailPath,
          generatedThumbnail,
          fileOptions: const FileOptions(
            cacheControl: '86400',
            contentType: 'image/jpeg',
            upsert: true,
          ),
        );
        metadata['thumbnail_path'] = thumbnailPath;
        await _cacheUploadedFile(generatedThumbnail, <String, dynamic>{
          'path': thumbnailPath,
          'name': '${p.basename(name)}_thumb.jpg',
        });
      }
    } catch (error) {
      // A preview is an enhancement; do not fail a successful media upload.
      debugPrint('Media thumbnail generation/upload skipped: $error');
    } finally {
      final generatedThumbnail = thumbnail;
      if (generatedThumbnail != null) {
        try {
          if (await generatedThumbnail.exists()) await generatedThumbnail.delete();
        } catch (cleanupError) {
          debugPrint('Could not remove temporary media thumbnail: $cleanupError');
        }
      }
    }

    // Keep a local copy for the sender before the picker/cache source can be
    // removed. The sender should render the just-uploaded attachment from its
    // own cache instead of immediately downloading the same object through
    // Storage RLS. The receiver continues to download through the private bucket.
    try {
      await _cacheUploadedFile(file, metadata);
    } catch (_) {
      // A cache failure must not turn a successful remote upload into a failed send.
    }
    return metadata;
  }

  Future<File> _cacheUploadedFile(File source, Map<String, dynamic> metadata) async {
    final path = metadata['path']?.toString() ?? '';
    if (path.isEmpty) throw StateError('Uploaded media is missing its storage path.');
    final support = await getApplicationSupportDirectory();
    final cacheDir = Directory(p.join(support.path, 'LikedinMediaCache'));
    await cacheDir.create(recursive: true);
    final key = base64Url.encode(utf8.encode(path)).replaceAll('=', '');
    final ext = p.extension(metadata['name']?.toString() ?? '');
    final cached = File(p.join(cacheDir.path, '$key$ext'));
    final temp = File('${cached.path}.part');
    if (await temp.exists()) await temp.delete();
    await source.copy(temp.path);
    if (await cached.exists()) await cached.delete();
    final result = await temp.rename(cached.path);
    // Uploaded files are already in the local cache for the sender. Include
    // these writes in the same 250 MB eviction policy as downloaded files.
    await _evictMediaCache(cacheDir, preservePath: cached.path);
    return result;
  }

  Future<void> _tusUpload(
    File file,
    String object,
    String mime, {
    void Function(double progress)? onProgress,
  }) async {
    final session = client.auth.currentSession;
    if (session == null) {
      throw StateError('Your session expired. Sign in again to resume media upload.');
    }
    final prefs = await SharedPreferences.getInstance();
    final resumeKey = '$_queueKey:tus:$object';
    final total = await file.length();
    final base = BackendConfig.supabaseUrl;
    final headers = <String, String>{
      'apikey': BackendConfig.supabaseAnonKey,
      'Authorization': 'Bearer ${session.accessToken}',
      'Tus-Resumable': '1.0.0',
    };

    Future<bool> existingObjectMatches() async {
      try {
        // A conflict is success only when Storage confirms this exact immutable
        // object exists and its stored byte length matches the queued file.
        final dynamic info = await client.storage.from(bucket).info(object);
        final dynamic storedMetadata = info.metadata;
        final storedMime = storedMetadata is Map
            ? (storedMetadata['mimetype'] ?? storedMetadata['contentType'])?.toString()
            : null;
        return info.size == total && (storedMime == null || storedMime == mime);
      } catch (_) {
        return false;
      }
    }

    Future<String?> createTusSession() async {
      final metadata = {
        'bucketName': bucket,
        'objectName': object,
        'contentType': mime,
        'cacheControl': '3600',
      }.entries.map((e) => '${e.key} ${base64.encode(utf8.encode(e.value))}').join(',');
      final response = await http.post(
        Uri.parse('$base/storage/v1/upload/resumable'),
        headers: {
          ...headers,
          'Upload-Length': '$total',
          'Upload-Metadata': metadata,
        },
      );
      if (response.statusCode == 409) {
        if (await existingObjectMatches()) {
          await prefs.remove(resumeKey);
          return null;
        }
        throw const HttpException('Storage reported an upload conflict, but the expected complete object was not found. Retry the upload.');
      }
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw HttpException('Could not start resumable upload (${response.statusCode}): ${response.body}');
      }
      final location = response.headers['location'];
      if (location == null) {
        throw const HttpException('Storage did not return a resumable upload location.');
      }
      final createdUrl = Uri.parse(base).resolve(location).toString();
      await prefs.setString(resumeKey, createdUrl);
      return createdUrl;
    }

    var uploadUrl = prefs.getString(resumeKey) ?? await createTusSession();
    if (uploadUrl == null) return; // The object already exists in Storage.
    var head = await http.head(Uri.parse(uploadUrl), headers: headers);
    if (head.statusCode == 404 || head.statusCode == 410 || head.statusCode == 400 || head.statusCode == 403) {
      // Stale or expired TUS session URL; discard and create a fresh session.
      await prefs.remove(resumeKey);
      uploadUrl = await createTusSession();
      if (uploadUrl == null) return; // The object already exists in Storage.
      head = await http.head(Uri.parse(uploadUrl), headers: headers);
    }
    if (head.statusCode < 200 || head.statusCode >= 300) {
      throw HttpException('Could not resume upload (${head.statusCode}).');
    }
    var offset = int.tryParse(head.headers['upload-offset'] ?? '0') ?? 0;
    final raf = await file.open(mode: FileMode.read);
    try {
      while (offset < total) {
        await raf.setPosition(offset);
        final length = min(_chunkSize, total - offset).toInt();
        final chunk = await raf.read(length);
        final response = await http.patch(
          Uri.parse(uploadUrl),
          headers: {
            ...headers,
            'Content-Type': 'application/offset+octet-stream',
            'Upload-Offset': '$offset',
          },
          body: chunk,
        );
        if (response.statusCode == 404 || response.statusCode == 410) {
          await prefs.remove(resumeKey);
        }
        if (response.statusCode < 200 || response.statusCode >= 300) {
          throw HttpException('Upload paused at $offset/$total bytes (${response.statusCode}).');
        }
        offset = int.tryParse(response.headers['upload-offset'] ?? '') ?? (offset + chunk.length);
        onProgress?.call(offset / total);
      }
    } finally {
      await raf.close();
    }
    await prefs.remove(resumeKey);
  }

  Future<void> enqueue(
    File file,
    String recipientId, {
    String? originalName,
    String? replyToMessageId,
    bool animated = false,
    String? kindOverride,
  }) async {
    final uid = client.auth.currentUser?.id;
    if (uid == null) throw StateError('Sign in before queuing an attachment.');
    final sourceSize = await file.length();
    if (sourceSize <= 0 || sourceSize > maxBytes) {
      throw StateError('Files must be between 1 byte and 50 MB after compression.');
    }
    final displayName = (originalName?.trim().isNotEmpty == true)
        ? originalName!.trim()
        : p.basename(file.path);
    var detectedMime = await detectMimeType(file, displayName: displayName);
    if (kindOverride == 'audio' && detectedMime.startsWith('video/')) {
      detectedMime = _audioMimeForName(displayName) ?? 'application/octet-stream';
    }
    final isAnimated = animated || detectedMime == 'image/gif';
    if (isAnimated && sourceSize > maxGifBytes) {
      throw StateError('Animated GIFs have a 2 MB storage limit after optimization.');
    }
    // Storage names always describe the bytes actually uploaded. This also
    // appends an extension when Android's MediaStore title has none.
    final storageName = _storageNameFor(displayName, file.path, detectedMime);
    final storageExtension = p.extension(storageName).isNotEmpty
        ? p.extension(storageName)
        : p.extension(file.path);
    final id = _uuid.v4();
    final support = await getApplicationSupportDirectory();
    final pendingDir = Directory(p.join(support.path, 'LikedinPendingMedia'));
    await pendingDir.create(recursive: true);
    final durableFile = File(p.join(pendingDir.path, '$id$storageExtension'));
    await file.copy(durableFile.path);
    final prefs = await SharedPreferences.getInstance();
    await _withQueueMutationLock(() async {
      final queue = await _readQueueForUser(prefs, uid);
      queue.add({
        'id': id,
        'senderId': uid,
        'path': durableFile.path,
        'recipient': recipientId,
        'replyToMessageId': replyToMessageId,
        'originalName': storageName,
        'displayName': displayName,
        'mime': detectedMime,
        'kindOverride': kindOverride,
        'animated': isAnimated,
        'attempts': 0,
        'nextAttemptAt': null,
        'createdAt': DateTime.now().toUtc().toIso8601String(),
      });
      await prefs.setString(_queueKeyFor(uid), jsonEncode(queue));
    });
  }

  static List<Map<String, dynamic>> _decodeQueue(String raw) {
    try {
      final decoded = jsonDecode(raw) as List;
      return decoded.map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } catch (_) {
      return [];
    }
  }

  static Future<List<Map<String, dynamic>>> _readQueueForUser(
    SharedPreferences prefs,
    String uid,
  ) async {
    // v1.7.x used one global queue without an owner UID. Never guess which
    // account created those uploads: quarantine them for manual recovery.
    final legacy = _decodeQueue(prefs.getString(_queueKey) ?? '[]');
    if (legacy.isNotEmpty) {
      final quarantine = _decodeQueue(prefs.getString(_quarantineKey) ?? '[]');
      final additions = <String, List<Map<String, dynamic>>>{};
      for (final item in legacy) {
        final owner = item['senderId']?.toString();
        if (owner == null || owner.isEmpty) {
          quarantine.add({...item, 'quarantineReason': 'Legacy queue item has no account owner.'});
        } else {
          (additions[owner] ??= <Map<String, dynamic>>[]).add(item);
        }
      }
      for (final entry in additions.entries) {
        final existing = _decodeQueue(prefs.getString(_queueKeyFor(entry.key)) ?? '[]');
        existing.addAll(entry.value);
        await prefs.setString(_queueKeyFor(entry.key), jsonEncode(existing));
      }
      await prefs.setString(_quarantineKey, jsonEncode(quarantine));
      await prefs.remove(_queueKey);
    }
    return _decodeQueue(prefs.getString(_queueKeyFor(uid)) ?? '[]');
  }

  /// True when this account has attachments waiting to upload. Lets callers
  /// run a periodic retry without reloading the chat when there is nothing to do.
  /// Number of attachments waiting to upload for this account.
  static Future<int> queuedCount(SupabaseClient client) async {
    final uid = client.auth.currentUser?.id;
    if (uid == null) return 0;
    final prefs = await SharedPreferences.getInstance();
    final queue = await _withQueueMutationLock(() => _readQueueForUser(prefs, uid));
    return queue.length;
  }

  static Future<bool> hasQueuedItems(SupabaseClient client) async {
    final uid = client.auth.currentUser?.id;
    if (uid == null) return false;
    final prefs = await SharedPreferences.getInstance();
    final queue = await _withQueueMutationLock(() => _readQueueForUser(prefs, uid));
    return queue.isNotEmpty;
  }

  /// Summarizes pending and quarantined uploads for the currently signed-in
  /// account. The chat uses this to make failed attachments visible instead
  /// of silently removing them from the retry queue.
  static Future<Map<String, dynamic>> queueStatus(SupabaseClient client) async {
    final uid = client.auth.currentUser?.id;
    if (uid == null) {
      return <String, dynamic>{
        'pendingCount': 0,
        'quarantinedCount': 0,
        'pendingNames': <String>[],
        'quarantinedItems': <Map<String, String>>[],
      };
    }
    final prefs = await SharedPreferences.getInstance();
    return _withQueueMutationLock(() async {
      final pending = await _readQueueForUser(prefs, uid);
      final quarantined = _decodeQueue(prefs.getString(_quarantineKey) ?? '[]')
          .where((item) => item['senderId']?.toString() == uid)
          .toList(growable: false);
      return <String, dynamic>{
        'pendingCount': pending.length,
        'quarantinedCount': quarantined.length,
        'pendingNames': pending
            .map((item) => (item['displayName'] ?? item['originalName'] ?? 'Attachment').toString())
            .take(2)
            .toList(growable: false),
        'quarantinedItems': quarantined
            .take(2)
            .map((item) => <String, String>{
                  'name': (item['displayName'] ?? item['originalName'] ?? 'Attachment').toString(),
                  'reason': (item['quarantineReason'] ?? 'This attachment could not be uploaded.').toString(),
                })
            .toList(growable: false),
      };
    });
  }

  /// Restores this account's quarantined uploads to the retry queue when
  /// their durable local source files still exist. Items with missing source
  /// files remain quarantined so they are not retried forever without data.
  static Future<int> restoreQuarantinedItems(SupabaseClient client) async {
    final uid = client.auth.currentUser?.id;
    if (uid == null) return 0;
    final prefs = await SharedPreferences.getInstance();
    return _withQueueMutationLock(() async {
      final quarantine = _decodeQueue(prefs.getString(_quarantineKey) ?? '[]');
      final queue = await _readQueueForUser(prefs, uid);
      final queuedIds = queue.map((item) => item['id']?.toString()).whereType<String>().toSet();
      final remaining = <Map<String, dynamic>>[];
      var restored = 0;
      for (final item in quarantine) {
        if (item['senderId']?.toString() != uid) {
          remaining.add(item);
          continue;
        }
        final path = item['path']?.toString() ?? '';
        var sourceExists = false;
        if (path.isNotEmpty) {
          try {
            sourceExists = await File(path).exists();
          } catch (_) {}
        }
        if (!sourceExists) {
          item['quarantineReason'] = 'The local source file is missing. Select the attachment again to resend it.';
          remaining.add(item);
          continue;
        }
        final id = item['id']?.toString();
        if (id == null || id.isEmpty || !queuedIds.contains(id)) {
          item['attempts'] = 0;
          item['nextAttemptAt'] = null;
          item.remove('quarantineReason');
          item.remove('quarantinedAt');
          queue.add(item);
          if (id != null && id.isNotEmpty) queuedIds.add(id);
          restored++;
        }
      }
      await prefs.setString(_quarantineKey, jsonEncode(remaining));
      if (restored > 0) await prefs.setString(_queueKeyFor(uid), jsonEncode(queue));
      return restored;
    });
  }

  static Future<bool> processRetryQueue(SupabaseClient client) {
    final active = _processingQueue;
    if (active != null) {
      // A send can enqueue after the active run took its queue snapshot. Mark
      // that another pass is required before resolving the shared future.
      _retryRequested = true;
      return active;
    }
    lastQueueError = null;
    lastQuarantinedCount = 0;
    _quarantineError = null;
    final completer = Completer<bool>();
    final operation = completer.future;
    _processingQueue = operation;
    () async {
      try {
        var result = false;
        do {
          _retryRequested = false;
          result = await _processRetryQueue(client);
        } while (_retryRequested);
        completer.complete(result);
      } catch (error, stackTrace) {
        completer.completeError(error, stackTrace);
      } finally {
        if (identical(_processingQueue, operation)) _processingQueue = null;
      }
    }();
    return operation;
  }

  static Future<T> _withQueueMutationLock<T>(Future<T> Function() operation) {
    final previous = _queueMutationTail;
    final released = Completer<void>();
    _queueMutationTail = released.future;
    return (() async {
      await previous;
      try {
        return await operation();
      } finally {
        released.complete();
      }
    })();
  }

  static Future<void> _removeQueuedItemUnlocked(
    SharedPreferences prefs,
    String uid,
    String itemId, {
    Map<String, dynamic>? fallbackItem,
  }) async {
    final queue = _decodeQueue(prefs.getString(_queueKeyFor(uid)) ?? '[]');
    queue.removeWhere((entry) {
      if (itemId.isNotEmpty) return entry['id']?.toString() == itemId;
      return fallbackItem != null && jsonEncode(entry) == jsonEncode(fallbackItem);
    });
    await prefs.setString(_queueKeyFor(uid), jsonEncode(queue));
  }

  static Future<void> _removeQueuedItem(
    SharedPreferences prefs,
    String uid,
    String itemId,
  ) async {
    await _withQueueMutationLock(() => _removeQueuedItemUnlocked(prefs, uid, itemId));
  }

  static Future<void> _updateQueuedItem(
    SharedPreferences prefs,
    String uid,
    Map<String, dynamic> updated,
  ) async {
    await _withQueueMutationLock(() async {
      final queue = _decodeQueue(prefs.getString(_queueKeyFor(uid)) ?? '[]');
      final id = updated['id']?.toString();
      final index = queue.indexWhere((entry) => entry['id']?.toString() == id);
      if (index < 0) return;
      queue[index] = updated;
      await prefs.setString(_queueKeyFor(uid), jsonEncode(queue));
    });
  }

  static Future<void> _quarantineQueuedItem(
    SharedPreferences prefs,
    String uid,
    Map<String, dynamic> item,
    String reason,
  ) async {
    await _withQueueMutationLock(() async {
      final quarantine = _decodeQueue(prefs.getString(_quarantineKey) ?? '[]');
      final id = item['id']?.toString();
      final duplicate = id != null && id.isNotEmpty
          ? quarantine.any((entry) => entry['id']?.toString() == id)
          : quarantine.any((entry) =>
              entry['path'] == item['path'] &&
              entry['createdAt'] == item['createdAt'] &&
              entry['originalName'] == item['originalName']);
      if (!duplicate) {
        quarantine.add({
          ...item,
          'quarantinedAt': DateTime.now().toUtc().toIso8601String(),
          'quarantineReason': reason,
        });
        await prefs.setString(_quarantineKey, jsonEncode(quarantine));
      }
      await _removeQueuedItemUnlocked(prefs, uid, id ?? '', fallbackItem: item);
    });
    lastQuarantinedCount++;
    _quarantineError ??= 'Quarantined: $reason';
    lastQueueError = _quarantineError;
  }

  /// A serialized foreground processor. Failed items are kept with exponential
  /// backoff; startup, resume, connectivity recovery and manual actions share it.
  static Future<bool> _processRetryQueue(SupabaseClient client) async {
    final uid = client.auth.currentUser?.id;
    if (uid == null) {
      lastQueueError = 'Sign in before sending queued attachments.';
      return false;
    }
    final prefs = await SharedPreferences.getInstance();
    final queue = await _withQueueMutationLock(() => _readQueueForUser(prefs, uid));
    if (queue.isEmpty) return lastQuarantinedCount == 0 && _quarantineError == null;
    final service = SharedMediaService(client);
    String? peer;
    try {
      peer = await client.rpc('likedin_get_peer_id') as String?;
    } catch (error) {
      debugPrint('Could not verify paired recipient for queued upload: $error');
      lastQueueError = 'Could not verify the paired contact. Check your connection and try again.';
      return false;
    }
    if (peer == null) {
      for (final item in queue) {
        await _quarantineQueuedItem(
          prefs,
          uid,
          item,
          'The paired recipient is unavailable, so this upload cannot be routed.',
        );
      }
      return false;
    }

    for (final item in List<Map<String, dynamic>>.from(queue)) {
      if (item['senderId']?.toString() != uid) {
        // This should not happen with per-account keys, but fail closed without
        // rewriting a stale queue snapshot over jobs enqueued concurrently.
        await _quarantineQueuedItem(
          prefs,
          uid,
          item,
          'Queue owner does not match the signed-in account.',
        );
        continue;
      }
      final recipient = item['recipient']?.toString() ?? '';
      if (recipient != peer) {
        await _quarantineQueuedItem(
          prefs,
          uid,
          item,
          'The queued upload targets a different account from the current paired recipient.',
        );
        continue;
      }
      final nextAttemptRaw = item['nextAttemptAt']?.toString();
      final nextAttempt = nextAttemptRaw == null ? null : DateTime.tryParse(nextAttemptRaw);
      if (nextAttempt != null && nextAttempt.isAfter(DateTime.now().toUtc())) continue;

      try {
        final path = item['path']?.toString() ?? '';
        if (path.isEmpty || !await File(path).exists()) {
          await _quarantineQueuedItem(prefs, uid, item, 'The durable local media file is missing.');
          continue;
        }
        final file = File(path);
        final fileSize = await file.length();
        final suppliedName = (item['originalName']?.toString().trim().isNotEmpty == true)
            ? item['originalName'].toString()
            : p.basename(path);
        final detectedMime = await detectMimeType(file, displayName: suppliedName);
        final animated = item['animated'] == true || detectedMime == 'image/gif';
        if (fileSize <= 0 || fileSize > maxBytes || (animated && fileSize > maxGifBytes)) {
          await _quarantineQueuedItem(
            prefs,
            uid,
            item,
            animated
                ? 'The optimized GIF exceeds the 2 MB Storage budget ($fileSize bytes).'
                : 'The file is empty or exceeds the 50 MB Storage limit ($fileSize bytes).',
          );
          continue;
        }
        final name = _storageNameFor(suppliedName, path, detectedMime);
        if (item['originalName']?.toString() != name || item['animated'] != animated ||
            item['mime']?.toString() != detectedMime) {
          item['originalName'] = name;
          item['animated'] = animated;
          item['mime'] = detectedMime;
          await _updateQueuedItem(prefs, uid, item);
        }
        final clientMessageId = item['id']?.toString();
        if (clientMessageId == null || clientMessageId.isEmpty) {
          await _quarantineQueuedItem(prefs, uid, item, 'The upload is missing its stable message ID.');
          continue;
        }

        // A previous request may have committed remotely while its response was
        // lost. Reconcile by the same idempotency key before uploading again.
        final existing = await client
            .from('messages')
            .select('id')
            .eq('sender_id', uid)
            .eq('client_message_id', clientMessageId)
            .maybeSingle();
        if (existing == null) {
          final ext = p.extension(name).replaceFirst('.', '').toLowerCase();
          final object = '$uid/$clientMessageId${ext.isEmpty ? '' : '.$ext'}';
          final metadata = await service.upload(
            file,
            objectPath: object,
            displayName: name,
            animated: item['animated'] == true,
            kindOverride: item['kindOverride']?.toString(),
          );
          // Keep metadata.name aligned with the actual uploaded bytes (.webp
          // for optimized GIFs). animated=true supplies the GIF presentation.
          metadata['name'] = name;
          await client.rpc('likedin_send_message_v2', params: {
            'p_recipient_id': recipient,
            'p_payload': jsonEncode(metadata),
            'p_client_message_id': clientMessageId,
            'p_reply_to_message_id': item['replyToMessageId'],
          });
        }
        await _removeQueuedItem(prefs, uid, clientMessageId);
        try {
          await file.delete();
        } catch (_) {}
      } catch (error) {
        final attempts = (item['attempts'] as num?)?.toInt() ?? 0;
        final nextAttempts = attempts + 1;
        final exponent = min(nextAttempts - 1, 8).toInt();
        final delaySeconds = min(1800, 5 * (1 << exponent)).toInt();
        item['attempts'] = nextAttempts;
        item['nextAttemptAt'] = DateTime.now().toUtc()
            .add(Duration(seconds: delaySeconds))
            .toIso8601String();
        debugPrint('Queued media upload attempt failed: $error');
        lastQueueError ??= 'An upload is still waiting. Check your connection; it will retry automatically.';
        await _updateQueuedItem(prefs, uid, item);
      }
    }
    final remaining = _decodeQueue(prefs.getString(_queueKeyFor(uid)) ?? '[]');
    if (remaining.isEmpty) {
      lastQueueError = _quarantineError;
      return lastQuarantinedCount == 0;
    }
    return false;
  }

  Future<String> signedUrl(String objectPath) =>
      client.storage.from(bucket).createSignedUrl(objectPath, 900);

  Future<void> _validateMediaPath(String path) async {
    if (path.isEmpty ||
        (!path.startsWith('${client.auth.currentUser?.id ?? ''}/') &&
            !(await _isPeerPath(path)))) {
      throw StateError('This attachment is not accessible to your account.');
    }
  }

  /// Retain downloaded media in app-private persistent storage. Do not evict
  /// older attachments automatically: users expect previously opened photos,
  /// videos and audio to remain available offline. Files are removed only by
  /// explicit message deletion (delete-for-everyone) or app-data removal.
  Future<void> _evictMediaCache(Directory directory, {String? preservePath}) async {
    // Intentionally no-op. The former 250 MB LRU cap silently removed older
    // media, which made old conversations lose their offline attachments.
  }

  /// Removes every cached file for a Storage object path on this device.
  /// The message tombstone carries the path so both sender and recipient can
  /// clear their app-private copies after delete-for-everyone.
  /// Deletes an uploaded object through the Storage API (never by deleting
  /// storage.objects rows directly). RLS permits only the owning pair member.
  /// Repeating this operation is safe and lets tombstone reloads retry failures.
  Future<void> deleteRemotePath(String objectPath) async =>
      deleteRemotePaths([objectPath]);

  Future<void> deleteRemotePaths(Iterable<String> objectPaths) async {
    final uid = client.auth.currentUser?.id;
    final originals = objectPaths.toSet().where((path) => path.isNotEmpty).toList();
    final paths = <String>{
      ...originals,
      for (final path in originals) '$path.thumb.jpg',
    }.toList(growable: false);
    if (paths.isEmpty) return;
    if (uid == null || paths.any((path) => !path.startsWith('$uid/'))) {
      throw StateError('Only the owner can delete these media objects.');
    }
    // Supabase Storage accepts a batch. This keeps a long history of deleted
    // attachments from causing one network request per tombstone at startup.
    await client.storage.from(bucket).remove(paths);
  }

  Future<void> deleteCachedPath(String objectPath) async {
    if (objectPath.isEmpty) return;
    final support = await getApplicationSupportDirectory();
    final cacheDir = Directory(p.join(support.path, 'LikedinMediaCache'));
    if (!await cacheDir.exists()) return;
    final keys = <String>{
      base64Url.encode(utf8.encode(objectPath)).replaceAll('=', ''),
      base64Url.encode(utf8.encode('$objectPath.thumb.jpg')).replaceAll('=', ''),
    };
    await for (final entity in cacheDir.list(followLinks: false)) {
      if (entity is! File) continue;
      final base = p.basename(entity.path);
      if (keys.any((key) => base == key || base.startsWith('$key.') || base.startsWith('$key.part'))) {
        try { await entity.delete(); } catch (error) {
          debugPrint('Could not delete cached media file ${entity.path}: $error');
        }
      }
    }
  }

  /// Returns the locally cached copy only; never touches the network. Throws
  /// [StateError] when the attachment has not been downloaded yet. Used by
  /// small previews (reply quotes) that must not trigger a full download.
  Future<File> cachedFileIfPresent(Map<String, dynamic> metadata) async {
    final path = metadata['path']?.toString() ?? '';
    if (path.isEmpty) throw StateError('This attachment is missing its storage path.');
    final support = await getApplicationSupportDirectory();
    final cacheDir = Directory(p.join(support.path, 'LikedinMediaCache'));
    if (!await cacheDir.exists()) throw StateError('Attachment not cached.');
    final key = base64Url.encode(utf8.encode(path)).replaceAll('=', '');
    await for (final entity in cacheDir.list(followLinks: false)) {
      if (entity is! File || entity.path.endsWith('.part')) continue;
      final base = p.basename(entity.path);
      if ((base == key || base.startsWith('$key.')) && await entity.length() > 0) {
        return entity;
      }
    }
    throw StateError('Attachment not cached.');
  }

  Future<File> cachedFile(Map<String, dynamic> metadata, {void Function(double progress)? onProgress}) async {
    final path = metadata['path']?.toString() ?? '';
    if (path.isEmpty) throw StateError('This attachment is missing its storage path.');
    final existing = _cacheLoadsInFlight[path];
    if (existing != null) return existing;
    final pending = _cachedFileInternal(metadata, onProgress: onProgress);
    _cacheLoadsInFlight[path] = pending;
    try {
      return await pending;
    } finally {
      if (identical(_cacheLoadsInFlight[path], pending)) {
        _cacheLoadsInFlight.remove(path);
      }
    }
  }

  Future<File> _cachedFileInternal(Map<String, dynamic> metadata, {void Function(double progress)? onProgress}) async {
    final path = metadata['path']?.toString() ?? '';
    if (path.isEmpty) throw StateError('This attachment is missing its storage path.');

    // Check the device-private cache first. This is essential for the sender:
    // the sender already owns the uploaded bytes and must not need a Storage
    // read permission check just to display its own outgoing attachment.
    final support = await getApplicationSupportDirectory();
    final cacheDir = Directory(p.join(support.path, 'LikedinMediaCache'));
    await cacheDir.create(recursive: true);
    final key = base64Url.encode(utf8.encode(path)).replaceAll('=', '');
    final ext = p.extension(metadata['name']?.toString() ?? '');
    final cached = File(p.join(cacheDir.path, '$key$ext'));
    await _evictMediaCache(cacheDir, preservePath: cached.path);

    // Prefer the exact metadata filename, but accept an existing path-keyed
    // cache entry with a different extension. This covers older uploads whose
    // display filename was normalized after the bytes were cached.
    File? cachedCandidate;
    if (await cached.exists() && await cached.length() > 0) {
      cachedCandidate = cached;
    } else {
      await for (final entity in cacheDir.list(followLinks: false)) {
        if (entity is! File || entity.path.endsWith('.part')) continue;
        final base = p.basename(entity.path);
        if (base == key || base.startsWith('$key.')) {
          if (await entity.length() > 0) {
            cachedCandidate = entity;
            break;
          }
        }
      }
    }
    if (cachedCandidate != null) {
      try { await cachedCandidate.setLastModified(DateTime.now()); } catch (_) {}
      onProgress?.call(1);
      return cachedCandidate;
    }
    if (await cached.exists()) await cached.delete();

    // Only a cache miss needs a Storage permission/ownership check and
    // download. Receiver devices normally take this path on first display.
    await _validateMediaPath(path);
    final temp = File('${cached.path}.part');
    if (await temp.exists()) await temp.delete();
    final httpClient = http.Client();
    IOSink? sink;
    try {
      final url = await signedUrl(path);
      final response = await httpClient
          .send(http.Request('GET', Uri.parse(url)))
          .timeout(const Duration(seconds: 45));
      if (response.statusCode != 200) {
        throw HttpException('Attachment download failed (${response.statusCode}).');
      }
      sink = temp.openWrite();
      var received = 0;
      final total = response.contentLength ?? 0;
      await for (final chunk in response.stream.timeout(const Duration(seconds: 30))) {
        sink.add(chunk);
        received += chunk.length;
        if (total > 0) onProgress?.call(received / total * 0.95);
      }
      await sink.flush();
      await sink.close();
      sink = null;
      if (await temp.length() <= 0) throw const HttpException('Downloaded attachment is empty.');
      if (await cached.exists()) await cached.delete();
      await temp.rename(cached.path);
      await _evictMediaCache(cacheDir, preservePath: cached.path);
      onProgress?.call(1);
      return cached;
    } catch (_) {
      if (sink != null) {
        try { await sink.close(); } catch (_) {}
      }
      if (await temp.exists()) {
        try { await temp.delete(); } catch (_) {}
      }
      rethrow;
    } finally {
      httpClient.close();
    }
  }

  Future<File> download(Map<String, dynamic> metadata, Directory destination, {void Function(double progress)? onProgress}) async {
    final cached = await cachedFile(metadata, onProgress: onProgress);
    await destination.create(recursive: true);
    final safe = (metadata['name']?.toString() ?? 'attachment').replaceAll(RegExp(r'[^A-Za-z0-9._ -]'), '_');
    final out = File(p.join(destination.path, '${_uuid.v4()}--$safe'));
    await cached.copy(out.path);
    return out;
  }

  Future<String> downloadToPublicDownloads(Map<String, dynamic> metadata) async {
    final cached = await cachedFile(metadata);
    final originalName = (metadata['name']?.toString() ?? 'attachment').replaceAll(RegExp(r'[^A-Za-z0-9._ -]'), '_');
    final safeName = originalName.isEmpty ? 'attachment' : originalName;
    final mime = metadata['mime']?.toString() ?? _normalizeMime(safeName);
    final tempDir = await getTemporaryDirectory();
    final temp = File(p.join(tempDir.path, 'likedin_download_${_uuid.v4()}'));
    await cached.copy(temp.path);
    try {
      return await const MethodChannel('com.example.likedin/downloads').invokeMethod<String>('saveToDownloads', {
            'sourcePath': temp.path,
            'displayName': safeName,
            'mimeType': mime,
          }) ??
          safeName;
    } finally {
      if (await temp.exists()) await temp.delete();
    }
  }

  Future<bool> _isPeerPath(String path) async {
    final parts = path.split('/');
    if (parts.length < 2) return false;
    final peer = await client.rpc('likedin_get_peer_id') as String?;
    return peer != null && parts.first == peer;
  }
}


/// Convert unsupported-but-common BMP/TIFF photos to a bucket-compatible JPEG.
Uint8List? _encodeStaticImageAsJpeg(Uint8List bytes) {
  try {
    img.Decoder.defaultMaxPixels = 16 * 1024 * 1024;
    final decoded = img.decodeImage(bytes);
    if (decoded == null) return null;
    final oriented = img.bakeOrientation(decoded);
    final longest = max(oriented.width, oriented.height);
    final preview = longest > 2560
        ? img.copyResize(
            oriented,
            width: (oriented.width * 2560 / longest).round().clamp(1, 2560).toInt(),
            height: (oriented.height * 2560 / longest).round().clamp(1, 2560).toInt(),
          )
        : oriented;
    return Uint8List.fromList(img.encodeJpg(preview, quality: 88));
  } catch (_) {
    return null;
  }
}

/// Decode, sample, downscale and re-encode a GIF away from the UI isolate.
/// The decoded animation is bounded to 8 million total pixels and 24 frames,
/// with a 480 px longest edge and lossy animated WebP output.
Uint8List? _encodeCompactAnimatedWebp(Uint8List bytes) {
  final decoder = img.GifDecoder()..maxPixels = 8 * 1024 * 1024;
  final decoded = decoder.decode(bytes);
  if (decoded == null || decoded.frames.isEmpty) return null;

  final longestEdge = max(decoded.width, decoded.height);
  const maxEdge = 480;
  final scale = longestEdge > maxEdge ? maxEdge / longestEdge : 1.0;
  final targetWidth = max(1, (decoded.width * scale).round()).toInt();
  final targetHeight = max(1, (decoded.height * scale).round()).toInt();

  // copyResize preserves the animation and frame timing. It is also careful
  // about each frame's own palette and offset while resizing.
  final resized = img.copyResize(
    decoded,
    width: targetWidth,
    height: targetHeight,
    interpolation: img.Interpolation.linear,
  );
  final frames = resized.frames;
  if (frames.isEmpty) return null;

  const maxFrames = 24;
  final outputFrameCount = min(frames.length, maxFrames).toInt();
  img.Image? animation;
  for (var outputIndex = 0; outputIndex < outputFrameCount; outputIndex++) {
    final start = (outputIndex * frames.length / outputFrameCount).floor();
    final end = min(
      frames.length,
      ((outputIndex + 1) * frames.length / outputFrameCount).floor(),
    ).toInt();
    final sourceFrame = frames[start];
    final frame = img.Image.from(sourceFrame, noAnimation: true);

    var durationMs = 0;
    for (var sourceIndex = start; sourceIndex < max(start + 1, end).toInt(); sourceIndex++) {
      durationMs += frames[sourceIndex].frameDuration;
    }
    frame.frameDuration = (durationMs <= 0 ? 100 : durationMs).clamp(40, 5000).toInt();

    if (animation == null) {
      animation = frame;
      animation
        ..frameType = img.FrameType.animation
        ..loopCount = resized.loopCount;
    } else {
      animation.addFrame(frame);
    }
  }
  if (animation == null) return null;

  final encoder = img.WebPEncoder(
    lossless: false,
    quality: 68,
    method: 3,
    alphaQuality: 78,
    exact: false,
  );
  return encoder.encode(animation);
}
