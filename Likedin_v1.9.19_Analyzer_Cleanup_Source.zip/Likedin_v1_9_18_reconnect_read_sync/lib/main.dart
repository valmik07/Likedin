import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:xml/xml.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import 'backend/backend_config.dart';
import 'backend/realtime_messaging_service.dart';
import 'backend/shared_media_service.dart';
import 'notifications/notification_service.dart';
import 'calls/call_service.dart';
import 'calls/call_alert_controller.dart';
import 'calls/proximity_call_controller.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:video_player/video_player.dart';
import 'package:record/record.dart';
import 'package:just_audio/just_audio.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:photo_manager/photo_manager.dart' show AssetEntity;
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';

import 'data/attachment_vault_store.dart';
import 'auth/local_account_store.dart';
import 'security/encrypted_backup_codec.dart';
import 'security/hidden_chat_vault.dart';
import 'utils/message_length.dart';
import 'utils/chat_info_metrics.dart';
import 'utils/message_merge.dart';
import 'utils/offline_catch_up.dart';
import 'utils/realtime_message_payload.dart';
import 'utils/receipt_reconciliation.dart';
import 'utils/voice_gesture_guard.dart';
import 'ui/glassmorphism.dart';
import 'ui/message_search.dart';
import 'ui/in_app_gallery_picker.dart';
import 'ui/conversation_card.dart';
import 'ui/hidden_chat_pin_dialog.dart';
import 'ui/profile_page.dart';
import 'ui/profile_photo_editor.dart';
import 'ui/profile_photo_viewer.dart';
import 'ui/storage_page.dart';
import 'ui/theme_customization_page.dart';
import 'ui/chat_info_page.dart';

part 'ui/home_page_part.dart';
part 'ui/chat_page_part.dart';
part 'ui/calls_page_part.dart';
part 'ui/settings_page_part.dart';

/// Call screens always use a dark, flat palette regardless of the app theme.
const Color _callBackground = Color(0xFF0A101C);
const Color _callPanel = Color(0xFF152036);
const Color _callButton = Color(0xFF1E2B45);
const Color _callAccent = Color(0xFF8DB8FF);
const Color _callDanger = Color(0xFFE5484D);
const Color _callPositive = Color(0xFF2FBF86);
const Color _callMuted = Color(0xFFA6B3CC);

/// Small rounded label used for call status and the video overlay chip.
class _CallPill extends StatelessWidget {
  const _CallPill({required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: _callPanel,
          borderRadius: BorderRadius.circular(24),
        ),
        child: child,
      );
}

/// Status line with a coloured dot, e.g. "Ringing…" or "02:14".
class _CallStatusLine extends StatelessWidget {
  const _CallStatusLine({required this.text, required this.color});
  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 8),
          Text(
            text,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 17,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      );
}

/// Round toggle used for mute, speaker, camera and flip.
class _CallRoundButton extends StatelessWidget {
  const _CallRoundButton({
    required this.icon,
    required this.label,
    required this.onPressed,
    this.active = false,
  });
  final IconData icon;
  final String label;
  final VoidCallback? onPressed;
  final bool active;

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null;
    return SizedBox(
      width: 76,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Semantics(
            button: true,
            enabled: enabled,
            selected: active,
            label: label,
            child: Material(
              color: active ? Colors.white : _callButton,
              shape: const CircleBorder(),
              child: InkWell(
                customBorder: const CircleBorder(),
                onTap: onPressed,
                child: SizedBox(
                  width: 60,
                  height: 60,
                  child: Icon(
                    icon,
                    size: 26,
                    color: !enabled
                        ? Colors.white24
                        : active
                            ? _callBackground
                            : Colors.white,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: _callMuted, fontSize: 12),
          ),
        ],
      ),
    );
  }
}

/// A restrained animated focal point for the full-screen calling experience.
/// Animation is local to the active call UI and is disposed with the widget.
class _CallHaloAvatar extends StatefulWidget {
  const _CallHaloAvatar({required this.icon, this.size = 148});
  final IconData icon;
  final double size;

  @override
  State<_CallHaloAvatar> createState() => _CallHaloAvatarState();
}

class _CallHaloAvatarState extends State<_CallHaloAvatar>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulse;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    );
    if (LikedinAppearance.reduceMotion.value) {
      _pulse.value = .5;
    } else {
      _pulse.repeat(reverse: true);
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Also honour the system "remove animations" setting.
    if (MediaQuery.of(context).disableAnimations && _pulse.isAnimating) {
      _pulse.stop();
    }
  }

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _pulse,
        builder: (context, _) {
          final t = Curves.easeInOut.transform(_pulse.value);
          return SizedBox(
            width: widget.size * 1.2,
            height: widget.size * 1.2,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: widget.size * (1.04 + .16 * t),
                  height: widget.size * (1.04 + .16 * t),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _callAccent.withValues(alpha: .10 + .24 * (1 - t)),
                      width: 2,
                    ),
                  ),
                ),
                Container(
                  width: widget.size,
                  height: widget.size,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFF1B2A47),
                  ),
                  child: Icon(widget.icon, color: _callAccent, size: widget.size * .44),
                ),
              ],
            ),
          );
        },
      );
}

bool _passwordRecoveryPending = false;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Bound decoded-image memory for 3 GB Android devices. Gallery thumbnails
  // are small, while full-size media is decoded only in the viewer.
  final imageCache = PaintingBinding.instance.imageCache;
  imageCache.maximumSize = 80;
  imageCache.maximumSizeBytes = 32 * 1024 * 1024;
  try {
    await ensureLikedinFirebaseReady();
  } catch (error) {
    debugPrint('Firebase bootstrap initialization failed: $error');
  }
  runApp(const LikedinBootstrap());
}

class LikedinBootstrap extends StatefulWidget {
  const LikedinBootstrap({super.key});
  @override
  State<LikedinBootstrap> createState() => _LikedinBootstrapState();
}

class _LikedinBootstrapState extends State<LikedinBootstrap> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 600),
  )..forward();
  bool _splashDark = false;
  Widget? _readyApp;
  String? _error;
  bool _supabaseInitialized = false;
  StreamSubscription<AuthState>? _earlyAuthSubscription;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _initialize());
  }

  Future<void> _initialize() async {
    try {
      // Read saved theme/appearance first so the splash already matches the
      // user's theme (Obsidian Glass or Arctic Glass). This is a fast local read.
      try {
        final early = await SharedPreferences.getInstance();
        await LikedinAppearance.load(early);
        if (mounted) {
          setState(() => _splashDark = early.getBool(likedinThemePreferenceKey) == true);
        }
        if (LikedinAppearance.reduceMotion.value) _controller.value = 1;
      } catch (_) {}
      if (!_supabaseInitialized) {
        await Supabase.initialize(
          url: BackendConfig.supabaseUrl,
          publishableKey: BackendConfig.supabaseAnonKey,
          // Keep the persisted Supabase session alive by refreshing access
          // tokens automatically when the app resumes or a token nears expiry.
          authOptions: const FlutterAuthClientOptions(autoRefreshToken: true),
        );
        _supabaseInitialized = true;
      }
      // Subscribe immediately after Supabase restores the deep-link session.
      // The notification/bootstrap work below may take long enough for an auth
      // recovery event to otherwise be missed by the later AuthGate listener.
      _earlyAuthSubscription ??= Supabase.instance.client.auth.onAuthStateChange.listen((state) {
        // Diagnostic only: never log access/refresh tokens or user credentials.
        debugPrint('Supabase auth event: ${state.event.name}');
        if (state.event == AuthChangeEvent.passwordRecovery) {
          _passwordRecoveryPending = true;
        }
      }, onError: (Object error, StackTrace stackTrace) {
        debugPrint('Early auth listener failed: $error\n$stackTrace');
      });
      try {
        await LikedinNotificationService.instance.initialize();
      } catch (error) {
        debugPrint('Notification setup failed; continuing app startup: $error');
      }
      final attachmentVault = AttachmentVaultStore();
      final preferences = await SharedPreferences.getInstance();
      likedinThemeMode.value = preferences.getBool(likedinThemePreferenceKey) == true
          ? ThemeMode.dark
          : ThemeMode.light;
      final uid = Supabase.instance.client.auth.currentUser?.id;
      likedinProfilePhotoPath.value = uid == null ? null : preferences.getString('${likedinProfilePhotoPreferenceKey}_$uid');
      if (!mounted) return;
      setState(() => _readyApp = LikedinApp(attachmentVault: attachmentVault));
    } catch (e) {
      if (mounted) {
        setState(() => _error = 'Could not start Likedin. Check your connection and try again.');
      }
    }
  }

  @override
  void dispose() {
    _earlyAuthSubscription?.cancel();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_readyApp != null) return _readyApp!;
    final b = _splashDark ? Brightness.dark : Brightness.light;
    final primary = likedinPrimary(b);
    final sweep = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.1, 0.85, curve: Curves.easeInOut),
    );
    final nameFade = CurvedAnimation(
      parent: _controller,
      curve: const Interval(0.45, 1.0, curve: Curves.easeOut),
    );
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: _likedinTheme(b),
      home: Scaffold(
        backgroundColor: likedinBackground(b),
        body: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [likedinBackgroundTop(b), likedinBackground(b)],
            ),
          ),
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ScaleTransition(
                  scale: Tween<double>(begin: .88, end: 1).animate(
                    CurvedAnimation(parent: _controller, curve: Curves.easeOutBack),
                  ),
                  child: FadeTransition(
                    opacity: CurvedAnimation(parent: _controller, curve: const Interval(0, .5)),
                    child: Container(
                      width: 112,
                      height: 112,
                      decoration: BoxDecoration(
                        color: likedinSurface(b).withValues(alpha: _splashDark ? .75 : .9),
                        borderRadius: BorderRadius.circular(32),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: _splashDark ? .16 : .9),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: primary.withValues(alpha: _splashDark ? .38 : .22),
                            blurRadius: 36,
                            spreadRadius: -2,
                            offset: const Offset(0, 10),
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(32),
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            const LikedinLogo(size: 66),
                            // Soft light sweep across the emblem.
                            Positioned.fill(
                              child: IgnorePointer(
                                child: AnimatedBuilder(
                                  animation: sweep,
                                  builder: (context, _) => DecoratedBox(
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        begin: Alignment(-2.2 + 3.6 * sweep.value, -1),
                                        end: Alignment(-1.0 + 3.6 * sweep.value, 1),
                                        colors: [
                                          Colors.white.withValues(alpha: 0),
                                          Colors.white.withValues(alpha: _splashDark ? .34 : .6),
                                          Colors.white.withValues(alpha: 0),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 22),
                FadeTransition(
                  opacity: nameFade,
                  child: Text(
                    'Likedin',
                    style: TextStyle(
                      color: likedinOnSurface(b),
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -.5,
                    ),
                  ),
                ),
                if (_error != null) ...[
                  const SizedBox(height: 20),
                  Text(_error!, textAlign: TextAlign.center),
                  TextButton(
                    onPressed: () {
                      setState(() => _error = null);
                      _initialize();
                    },
                    child: const Text('Retry'),
                  ),
                ]
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class CodePointLengthLimitingTextInputFormatter extends TextInputFormatter {
  const CodePointLengthLimitingTextInputFormatter(this.maxCodePoints);
  final int maxCodePoints;

  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    final runes = newValue.text.runes;
    if (likedinMessageCodePointLength(newValue.text) <= maxCodePoints) return newValue;
    final limited = String.fromCharCodes(runes.take(maxCodePoints));
    final offset = newValue.selection.extentOffset.clamp(0, limited.length);
    return TextEditingValue(
      text: limited,
      selection: TextSelection.collapsed(offset: offset),
      composing: TextRange.empty,
    );
  }
}

const likedinVersion = '1.9.19+108';
bool _globalCallDialogActive = false;
Color get brandBlue => likedinPrimary(likedinThemeMode.value == ThemeMode.dark ? Brightness.dark : Brightness.light);
const MethodChannel _keyboardMediaChannel = MethodChannel('com.example.likedin/keyboard_media');
const MethodChannel _hiddenChatSecurityChannel = MethodChannel('com.example.likedin/hidden_chat_security');
const ink = Color(0xFF172B4D);
const muted = Color(0xFF667085);
const page = Color(0xFFF3F6F8);
final ValueNotifier<ThemeMode> likedinThemeMode = ValueNotifier<ThemeMode>(ThemeMode.light);
const String likedinThemePreferenceKey = 'likedin_theme_mode_v1';
const String likedinProfilePhotoPreferenceKey = 'likedin_profile_photo_path_v1';
final ValueNotifier<String?> likedinProfilePhotoPath = ValueNotifier<String?>(null);

/// Switches between Arctic Glass (light) and Obsidian Glass (dark) and saves it.
Future<void> setLikedinDarkMode(bool dark) async {
  likedinThemeMode.value = dark ? ThemeMode.dark : ThemeMode.light;
  try {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(likedinThemePreferenceKey, dark);
  } catch (_) {}
}

/// One theme definition for both brightnesses so every page, sheet, dialog and
/// control shares the same shapes, spacing and tonal surfaces.
ThemeData _likedinTheme(Brightness brightness) {
  final dark = brightness == Brightness.dark;
  final background = likedinBackground(brightness);
  final surface = likedinSurface(brightness);
  final outline = likedinOutline(brightness);
  final raised = likedinSurfaceRaised(brightness);
  // Obsidian Glass (dark) / Arctic Glass (light) with the user's accent. The
  // accent is tuned per brightness in glassmorphism.dart so text stays readable.
  final primary = likedinPrimary(brightness);
  final onPrimary = dark ? const Color(0xFF04122B) : Colors.white;
  final onSurface = likedinOnSurface(brightness);
  final scheme = ColorScheme.fromSeed(
    seedColor: primary,
    brightness: brightness,
    surface: surface,
  ).copyWith(
    primary: primary,
    onPrimary: onPrimary,
    onSurface: onSurface,
    onSurfaceVariant: likedinMutedText(brightness),
    outline: outline,
  );
  const pillShape = StadiumBorder();
  return ThemeData(
    useMaterial3: true,
    brightness: brightness,
    scaffoldBackgroundColor: background,
    colorScheme: scheme,
    dividerColor: outline,
    appBarTheme: AppBarTheme(
      backgroundColor: background,
      foregroundColor: onSurface,
      elevation: 0,
      scrolledUnderElevation: 0,
      surfaceTintColor: Colors.transparent,
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: primary,
      foregroundColor: onPrimary,
      elevation: 2,
      highlightElevation: 3,
      shape: const CircleBorder(),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      indicatorColor: primary.withValues(alpha: dark ? .24 : .14),
      indicatorShape: pillShape,
      elevation: 0,
      height: 68,
      labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
      labelTextStyle: WidgetStateProperty.resolveWith(
        (states) => TextStyle(
          fontSize: 12,
          fontWeight: states.contains(WidgetState.selected)
              ? FontWeight.w700
              : FontWeight.w500,
        ),
      ),
    ),
    cardTheme: CardThemeData(
      color: surface,
      elevation: 0,
      margin: EdgeInsets.zero,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: outline),
      ),
    ),
    dividerTheme: DividerThemeData(color: outline, thickness: 1, space: 1),
    listTileTheme: const ListTileThemeData(
      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 2),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(16)),
      ),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: dark ? const Color(0xFFE8EEF9) : const Color(0xFF16233A),
      contentTextStyle: TextStyle(
        color: dark ? const Color(0xFF0F1B2D) : Colors.white,
        fontSize: 14,
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: surface,
      surfaceTintColor: Colors.transparent,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
    ),
    dialogTheme: DialogThemeData(
      backgroundColor: surface,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
    ),
    popupMenuTheme: PopupMenuThemeData(
      color: surface,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: outline),
      ),
    ),
    chipTheme: ChipThemeData(
      shape: pillShape,
      side: BorderSide(color: outline),
      backgroundColor: raised,
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith(
        (states) => states.contains(WidgetState.selected)
            ? (dark ? const Color(0xFF0A101C) : Colors.white)
            : (dark ? const Color(0xFF8795AD) : const Color(0xFF7B8798)),
      ),
      trackColor: WidgetStateProperty.resolveWith(
        (states) => states.contains(WidgetState.selected) ? primary : raised,
      ),
      trackOutlineColor: WidgetStateProperty.resolveWith(
        (states) => states.contains(WidgetState.selected)
            ? Colors.transparent
            : (dark ? const Color(0xFF3A4963) : const Color(0xFFC9D2E0)),
      ),
    ),
    progressIndicatorTheme: ProgressIndicatorThemeData(color: primary),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        shape: pillShape,
        minimumSize: const Size(0, 48),
        padding: const EdgeInsets.symmetric(horizontal: 22),
        textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        shape: pillShape,
        minimumSize: const Size(0, 46),
        side: BorderSide(color: dark ? const Color(0xFF3A4963) : const Color(0xFFC9D2E0)),
        textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        shape: pillShape,
        textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: raised,
      hintStyle: TextStyle(color: dark ? const Color(0xFF8795AD) : const Color(0xFF7B8798)),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: primary, width: 1.6),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
    ),
  );
}

class LikedinApp extends StatelessWidget {
  const LikedinApp({required this.attachmentVault, super.key});
  final AttachmentVaultStore attachmentVault;

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<ThemeMode>(
        valueListenable: likedinThemeMode,
        builder: (context, mode, _) => ListenableBuilder(
          // Accent, effects and motion changes re-theme the whole app live.
          listenable: LikedinAppearance.listenable,
          builder: (context, _) => MaterialApp(
            title: 'Likedin',
            debugShowCheckedModeBanner: false,
            themeMode: mode,
            theme: _likedinTheme(Brightness.light),
            darkTheme: _likedinTheme(Brightness.dark),
            themeAnimationDuration: LikedinAppearance.reduceMotion.value
                ? Duration.zero
                : const Duration(milliseconds: 200),
            home: AuthGate(attachmentVault: attachmentVault),
          ),
        ),
      );
}

class AuthGate extends StatefulWidget {
  const AuthGate({required this.attachmentVault, super.key});
  final AttachmentVaultStore attachmentVault;

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  StreamSubscription<AuthState>? _authSubscription;
  bool _showingRecoveryDialog = false;

  @override
  void initState() {
    super.initState();
    _authSubscription = Supabase.instance.client.auth.onAuthStateChange.listen(
      (state) {
        if (state.event == AuthChangeEvent.passwordRecovery) {
          _passwordRecoveryPending = false;
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) _showPasswordRecoveryDialog();
          });
        }
      },
      onError: (Object error, StackTrace stackTrace) {
        debugPrint('Auth state listener failed: $error\n$stackTrace');
      },
    );
    if (_passwordRecoveryPending) {
      _passwordRecoveryPending = false;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _showPasswordRecoveryDialog();
      });
    }
  }

  @override
  void dispose() {
    _authSubscription?.cancel();
    super.dispose();
  }

  Future<void> _showPasswordRecoveryDialog() async {
    if (!mounted || _showingRecoveryDialog) return;
    _showingRecoveryDialog = true;
    final passwordController = TextEditingController();
    final confirmController = TextEditingController();
    var saving = false;
    String? errorText;
    try {
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) => PopScope<Object?>(
          canPop: false,
          child: StatefulBuilder(
          builder: (dialogContext, updateDialog) => AlertDialog(
            title: const Text('Set a new password'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: passwordController,
                  obscureText: true,
                  autofillHints: const [AutofillHints.newPassword],
                  textInputAction: TextInputAction.next,
                  decoration: const InputDecoration(labelText: 'New password (8+ characters)'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: confirmController,
                  obscureText: true,
                  textInputAction: TextInputAction.done,
                  decoration: const InputDecoration(labelText: 'Confirm new password'),
                ),
                if (errorText != null) ...[
                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(errorText!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
                  ),
                ],
              ],
            ),
            actions: [
              TextButton(
                onPressed: saving ? null : () async {
                  await Supabase.instance.client.auth.signOut();
                  if (dialogContext.mounted) Navigator.of(dialogContext).pop();
                },
                child: const Text('Back to sign in'),
              ),
              FilledButton(
                onPressed: saving ? null : () async {
                  final password = passwordController.text;
                  if (password.length < 8) {
                    updateDialog(() => errorText = 'Use at least 8 characters.');
                    return;
                  }
                  if (password != confirmController.text) {
                    updateDialog(() => errorText = 'The passwords do not match.');
                    return;
                  }
                  updateDialog(() { saving = true; errorText = null; });
                  try {
                    await Supabase.instance.client.auth.updateUser(UserAttributes(password: password));
                    if (!dialogContext.mounted) return;
                    Navigator.of(dialogContext).pop();
                    if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Your password has been updated.')),
                      );
                    }
                  } on AuthException {
                    if (dialogContext.mounted) {
                      updateDialog(() {
                        saving = false;
                        errorText = 'The password could not be updated. Check the requirements and try again.';
                      });
                    }
                  } catch (_) {
                    if (dialogContext.mounted) {
                      updateDialog(() {
                        saving = false;
                        errorText = 'Could not update the password. Request a new recovery link and try again.';
                      });
                    }
                  }
                },
                child: saving
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Text('Update password'),
              ),
            ],
          ),
          ),
        ),
      );
    } finally {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        passwordController.dispose();
        confirmController.dispose();
      });
      _showingRecoveryDialog = false;
    }
  }

  @override
  Widget build(BuildContext context) => StreamBuilder<AuthState>(
        stream: Supabase.instance.client.auth.onAuthStateChange,
        builder: (context, snapshot) {
          final user = Supabase.instance.client.auth.currentUser;
          if (user == null) return const SignInPage();
          final account = LikedinAccount(
            displayName: (user.userMetadata?['display_name'] as String?) ??
                user.email?.split('@').first ??
                'Likedin user',
            likedinId: user.email ?? user.id,
            salt: '',
            passwordHash: '',
            createdAt: user.createdAt,
          );
          return AppShell(
            attachmentVault: widget.attachmentVault,
            account: account,
            onSignOut: () async {
              try {
                await LikedinNotificationService.instance.unregisterCurrentToken();
              } catch (error) {
                debugPrint('Push-token cleanup deferred during sign-out: $error');
              }
              likedinProfilePhotoPath.value = null;
              try {
                await Supabase.instance.client.rpc('likedin_set_presence', params: {'p_online': false});
              } catch (_) {}
              await Supabase.instance.client.auth.signOut();
            },
          );
        },
      );
}

class SignInPage extends StatefulWidget {
  const SignInPage({super.key});
  @override
  State<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final nameController = TextEditingController();
  bool creating = false;
  bool busy = false;
  bool obscure = true;
  String? error;
  String? notice;

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    nameController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final email = emailController.text.trim();
    final password = passwordController.text;
    if (email.isEmpty || !email.contains('@')) {
      setState(() => error = 'Enter a valid email address.');
      return;
    }
    if (creating && password.length < 8) {
      setState(() => error = 'Password must contain at least 8 characters.');
      return;
    }
    if (creating && nameController.text.trim().isEmpty) {
      setState(() => error = 'Enter your display name.');
      return;
    }
    setState(() {
      busy = true;
      error = null;
      notice = null;
    });
    try {
      if (creating) {
        final canRegister = await Supabase.instance.client.rpc('likedin_can_register_account');
        if (canRegister != true) {
          if (mounted) setState(() => error = 'Both Likedin account slots are currently occupied.');
          return;
        }
        final response = await Supabase.instance.client.auth.signUp(
          email: email,
          password: password,
          data: {'display_name': nameController.text.trim()},
          emailRedirectTo: 'com.example.likedin://login-callback/',
        );
        if (response.session == null) {
          if (!mounted) return;
          setState(() => notice =
              'Account request accepted. Check your email and confirm it, then return here to sign in.');
        }
      } else {
        await Supabase.instance.client.auth.signInWithPassword(
          email: email,
          password: password,
        );
      }
    } on AuthException catch (e) {
      final message = e.message;
      var pairFull = message.contains('LIKEDIN_PAIR_FULL') ||
          message.toLowerCase().contains('limited to two');
      // GoTrue may wrap a BEFORE INSERT trigger rejection as the generic
      // "Database error saving new user" message. Re-check slot availability
      // before translating that error; do not mislabel unrelated Auth failures.
      if (creating && !pairFull && message.toLowerCase().contains('database error')) {
        try {
          final available = await Supabase.instance.client.rpc('likedin_can_register_account');
          pairFull = available != true;
        } catch (_) {
          // Preserve the original Auth error when the diagnostic RPC is down.
        }
      }
      if (mounted) {
        setState(() => error = pairFull
            ? 'Both Likedin account slots are currently occupied.'
            : message);
      }
    } catch (e) {
      if (mounted) setState(() => error = 'Could not connect. Check your internet and try again.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _sendPasswordReset() async {
    final email = emailController.text.trim();
    if (email.isEmpty || !email.contains('@')) {
      setState(() => error = 'Enter your account email first.');
      return;
    }
    setState(() { busy = true; error = null; notice = null; });
    try {
      await Supabase.instance.client.auth.resetPasswordForEmail(
        email,
        redirectTo: 'com.example.likedin://login-callback/',
      );
      if (!mounted) return;
      setState(() => notice = 'If an account exists for that email, a password-reset link has been sent.');
    } on AuthException catch (e) {
      if (mounted) setState(() => error = e.message);
    } catch (_) {
      if (mounted) setState(() => error = 'Could not send the reset email. Check your connection and try again.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => AuroraBackdrop(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 430),
                  child: GlassPanel(
                    padding: const EdgeInsets.fromLTRB(22, 24, 22, 22),
                    radius: BorderRadius.circular(28),
                    blur: 12,
                    frosted: true,
                    glow: true,
                    child: AutofillGroup(
                      child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Align(alignment: Alignment.centerLeft, child: LikedinLogo(size: 52)),
                    const SizedBox(height: 22),
                    const Text(
                      'Your space.\nYour people.',
                      style: TextStyle(fontSize: 36, height: 1.06, fontWeight: FontWeight.w800, letterSpacing: -1.3),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Private messages, calls and files, just for the two of you.',
                      style: TextStyle(fontSize: 15, height: 1.4, color: Theme.of(context).hintColor),
                    ),
                    const SizedBox(height: 28),
                    Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: likedinSurfaceRaised(Theme.of(context).brightness),
                        borderRadius: BorderRadius.circular(30),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: _AuthTab(
                              label: 'Sign in',
                              selected: !creating,
                              onTap: () => setState(() {
                                creating = false;
                                passwordController.clear();
                                error = null;
                                notice = null;
                              }),
                            ),
                          ),
                          Expanded(
                            child: _AuthTab(
                              label: 'Create account',
                              selected: creating,
                              onTap: () => setState(() {
                                creating = true;
                                passwordController.clear();
                                error = null;
                                notice = null;
                              }),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 22),
                    Text(
                      creating ? 'Create your Likedin account' : 'Welcome back',
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: -.3),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      creating
                          ? 'Use your own email address. The server enforces the two-account limit.'
                          : 'Sign in from any device using your email.',
                      style: TextStyle(height: 1.4, color: Theme.of(context).hintColor),
                    ),
                    const SizedBox(height: 20),
                    if (creating) ...[
                      _AuthField(
                        controller: nameController,
                        label: 'Your name',
                        hint: 'How should we call you?',
                        icon: Icons.person_outline,
                        autofillHints: const [AutofillHints.name],
                        textInputAction: TextInputAction.next,
                      ),
                      const SizedBox(height: 13),
                    ],
                    _AuthField(
                      controller: emailController,
                      label: 'Email address',
                      hint: 'you@example.com',
                      icon: Icons.email_outlined,
                      keyboardType: TextInputType.emailAddress,
                      autofillHints: const [AutofillHints.email],
                      textInputAction: TextInputAction.next,
                    ),
                    const SizedBox(height: 13),
                    _AuthField(
                      controller: passwordController,
                      label: 'Password',
                      hint: 'At least 8 characters',
                      icon: Icons.lock_outline,
                      obscure: obscure,
                      autofillHints: creating ? const [AutofillHints.newPassword] : const [AutofillHints.password],
                      textInputAction: TextInputAction.done,
                      onSubmitted: (_) => _submit(),
                      suffix: IconButton(
                        tooltip: obscure ? 'Show password' : 'Hide password',
                        onPressed: () => setState(() => obscure = !obscure),
                        icon: Icon(obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                      ),
                    ),
                    if (!creating)
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton(
                          onPressed: busy ? null : _sendPasswordReset,
                          child: const Text('Forgot password?'),
                        ),
                      ),
                    const SizedBox(height: 8),
                    if (error != null) _AuthError(message: error!),
                    if (notice != null)
                      Container(
                        padding: const EdgeInsets.all(12),
                        margin: const EdgeInsets.only(bottom: 12),
                        decoration: BoxDecoration(
                          color: const Color(0xFF16865A).withValues(alpha: .14),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Text(
                          notice!,
                          style: TextStyle(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? const Color(0xFF7FDDB5)
                                : const Color(0xFF176B45),
                            fontSize: 13,
                          ),
                        ),
                      ),
                    GradientButton(
                      onPressed: busy ? null : _submit,
                      child: busy
                          ? const SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                            )
                          : Text(creating ? 'Create account' : 'Sign in'),
                    ),
                    ],
                  ),
                      ),
                    ),
                ),
              ),
            ),
          ),
        ),
      );
}

class _AuthTab extends StatelessWidget {
  const _AuthTab({required this.label, required this.selected, required this.onTap});
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: selected ? likedinSurface(Theme.of(context).brightness) : Colors.transparent,
            borderRadius: BorderRadius.circular(26),
            boxShadow: selected
                ? [const BoxShadow(color: Color(0x14000000), blurRadius: 6, offset: Offset(0, 1))]
                : null,
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontWeight: FontWeight.w700,
              color: selected ? Theme.of(context).colorScheme.primary : Theme.of(context).hintColor,
            ),
          ),
        ),
      );
}

class _AuthField extends StatelessWidget {
  const _AuthField({
    required this.controller,
    required this.label,
    required this.hint,
    required this.icon,
    this.obscure = false,
    this.suffix,
    this.keyboardType,
    this.autofillHints,
    this.textInputAction,
    this.onSubmitted,
  });
  final TextEditingController controller;
  final String label;
  final String hint;
  final IconData icon;
  final bool obscure;
  final Widget? suffix;
  final TextInputType? keyboardType;
  final Iterable<String>? autofillHints;
  final TextInputAction? textInputAction;
  final ValueChanged<String>? onSubmitted;

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
          const SizedBox(height: 7),
          TextField(
            controller: controller,
            obscureText: obscure,
            keyboardType: keyboardType,
            autofillHints: autofillHints,
            textInputAction: textInputAction,
            onSubmitted: onSubmitted,
            autocorrect: false,
            enableSuggestions: !obscure,
            decoration: InputDecoration(
              hintText: hint,
              prefixIcon: Icon(icon, size: 19),
              suffixIcon: suffix,
            ),
          ),
        ],
      );
}

Color _errorTone(BuildContext context) =>
    Theme.of(context).brightness == Brightness.dark ? const Color(0xFFFF9AA0) : const Color(0xFFB42318);

class _AuthError extends StatelessWidget {
  const _AuthError({required this.message});
  final String message;
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(11),
        decoration: BoxDecoration(
          color: const Color(0xFFE5484D).withValues(alpha: .13),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            Icon(Icons.error_outline, color: _errorTone(context), size: 18),
            const SizedBox(width: 8),
            Expanded(child: Text(message, style: TextStyle(color: _errorTone(context), fontSize: 13))),
          ],
        ),
      );
}

class LikedinLogo extends StatelessWidget {
  const LikedinLogo({super.key, this.size = 36});
  final double size;
  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        alignment: Alignment.center,
        decoration: BoxDecoration(color: likedinPrimary(Theme.of(context).brightness), borderRadius: BorderRadius.circular(size * .19)),
        child: Text(
          'in',
          style: TextStyle(
            color: Theme.of(context).colorScheme.onPrimary,
            fontSize: size * .61,
            fontWeight: FontWeight.w800,
            letterSpacing: -1.5,
            height: 1,
          ),
        ),
      );
}

class AppShell extends StatefulWidget {
  const AppShell({
    required this.attachmentVault,
    required this.account,
    required this.onSignOut,
    super.key,
  });
  final AttachmentVaultStore attachmentVault;
  final LikedinAccount account;
  final Future<void> Function() onSignOut;
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> with WidgetsBindingObserver {
  int index = 0;
  final Set<int> _visitedTabs = <int>{0};
  final HiddenChatVault _hiddenChatVault = HiddenChatVault();
  RealtimeChannel? _incomingCallsChannel;
  final Set<String> _handledIncomingCallIds = <String>{};
  bool _incomingDialogOpen = false;
  bool _openingProtectedTab = false;
  bool _hiddenChatSessionUnlocked = false;
  bool _hiddenChatsExist = false;
  bool _hiddenChatsStateReady = false;
  bool _showHiddenChatsPage = false;
  int _hiddenPasswordFailures = 0;
  DateTime? _hiddenPasswordBlockedUntil;

  bool _isHiddenDataTab(int tabIndex) => tabIndex == 1 || tabIndex == 3;

  void _switchTab(int nextIndex) {
    if (!mounted) return;

    // The hidden conversation is entered only from the logo-opened private
    // chat list. Notifications, shortcuts and other routes cannot jump into it.
    if (_hiddenChatsExist && nextIndex == 1) {
      _activateTab(0);
      return;
    }
    // Verify secure metadata before opening Calls, including when a
    // notification arrives before the initial startup check has completed.
    if (nextIndex == 2) {
      unawaited(_requestOpenCallsTab());
      return;
    }
    if (_isHiddenDataTab(nextIndex)) {
      unawaited(_requestOpenProtectedTab(nextIndex));
      return;
    }
    _activateTab(nextIndex);
  }

  void _activateTab(int nextIndex) {
    if (!mounted) return;
    final wasChat = index == 1;
    setState(() {
      index = nextIndex;
      _visitedTabs.add(nextIndex);
    });
    if (wasChat && nextIndex != 1) {
      LikedinNotificationService.instance.setConversationVisible(false);
      unawaited(_recoverIncomingCalls());
    }
  }

  Future<void> _requestOpenCallsTab() async {
    try {
      final hidden = await _hasHiddenConversation();
      if (!mounted) return;
      if (hidden) {
        setState(() {
          _hiddenChatsExist = true;
          _hiddenChatsStateReady = true;
        });
        _activateTab(0);
        return;
      }
      setState(() {
        _hiddenChatsExist = false;
        _hiddenChatsStateReady = true;
      });
      _activateTab(2);
    } catch (error) {
      debugPrint('Calls tab access check failed: $error');
      if (!mounted) return;
      // Fail closed: if hidden-chat status is unknown, keep Calls unavailable.
      setState(() {
        _hiddenChatsExist = true;
        _hiddenChatsStateReady = true;
      });
      _activateTab(0);
    }
  }

  Future<void> _refreshHiddenChatsPresence() async {
    try {
      final hidden = await _hasHiddenConversation();
      if (!mounted) return;
      setState(() {
        _hiddenChatsExist = hidden;
        _hiddenChatsStateReady = true;
        if (!hidden) {
          _showHiddenChatsPage = false;
          _hiddenChatSessionUnlocked = false;
        }
        if (hidden && index == 2) index = 0;
      });
      if (!hidden) _setHiddenChatWindowSecure(false);
    } catch (error) {
      debugPrint('Hidden-chat navigation state could not be read: $error');
      if (!mounted) return;
      // Fail closed: hide Calls and keep the hidden-chat entry available.
      setState(() {
        _hiddenChatsExist = true;
        _hiddenChatsStateReady = true;
        if (index == 2) index = 0;
      });
    }
  }

  void _onHiddenChatsChanged() {
    _setHiddenChatWindowSecure(true);
    if (!mounted) return;
    setState(() {
      _hiddenChatsExist = true;
      _hiddenChatsStateReady = true;
      _showHiddenChatsPage = false;
    });
  }

  void _openHiddenConversation() {
    if (!mounted || !_hiddenChatsExist || !_hiddenChatSessionUnlocked) return;
    setState(() {
      _showHiddenChatsPage = false;
      index = 1;
      _visitedTabs.add(1);
    });
  }

  void _closeHiddenChatsPage() {
    if (!mounted) return;
    setState(() => _showHiddenChatsPage = false);
  }

  Future<void> _changeHiddenChatsPassword() async {
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (uid == null || !mounted) return;
    final result = await HiddenChatPinDialog.show(
      context,
      setup: true,
      title: 'Change hidden-chat password',
    );
    final password = result?.password;
    if (!mounted || password == null) return;
    await _hiddenChatVault.configurePassword(uid, password);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Hidden-chat password changed.')),
      );
    }
  }

  Future<bool> _hasHiddenConversation() async {
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (uid == null) return false;
    return _hiddenChatVault.hasHiddenChats(uid);
  }

  Future<bool> _unlockHiddenChatSession() async {
    final blockedUntil = _hiddenPasswordBlockedUntil;
    if (blockedUntil != null && DateTime.now().isBefore(blockedUntil)) {
      final seconds = blockedUntil.difference(DateTime.now()).inSeconds + 1;
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Too many attempts. Try again in $seconds seconds.')),
        );
      }
      return false;
    }
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (uid == null) return false;
    if (!await _hiddenChatVault.hasPassword(uid)) {
      if (!mounted) return false;
      return _recoverHiddenChatPassword(uid);
    }
    if (!mounted) return false;
    final passwordResult = await HiddenChatPinDialog.show(context, setup: false);
    if (!mounted || passwordResult == null) return false;
    if (passwordResult.requestRecovery) {
      return _recoverHiddenChatPassword(uid);
    }
    final password = passwordResult.password;
    if (password == null) return false;
    final valid = await _hiddenChatVault.verifyPassword(uid, password);
    if (!valid) {
      _hiddenPasswordFailures++;
      if (_hiddenPasswordFailures >= 5) {
        _hiddenPasswordFailures = 0;
        _hiddenPasswordBlockedUntil = DateTime.now().add(const Duration(seconds: 30));
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(_hiddenPasswordBlockedUntil == null
              ? 'Incorrect hidden-chats password.'
              : 'Too many attempts. Hidden chats are locked for 30 seconds.')),
        );
      }
      return false;
    }
    _hiddenPasswordFailures = 0;
    _hiddenPasswordBlockedUntil = null;
    _startHiddenChatSession();
    return true;
  }

  Future<bool> _recoverHiddenChatPassword(String uid) async {
    String enteredAccountPassword = '';
    final accountPassword = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
          title: const Text('Verify your Likedin account'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Enter your regular Likedin sign-in password to reset the hidden-chats password.'),
              const SizedBox(height: 14),
              TextField(
                autofocus: true,
                obscureText: true,
                autocorrect: false,
                enableSuggestions: false,
                textInputAction: TextInputAction.done,
                onChanged: (value) => enteredAccountPassword = value,
                onSubmitted: (_) => Navigator.of(dialogContext).pop(enteredAccountPassword),
                decoration: const InputDecoration(
                  labelText: 'Likedin account password',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(dialogContext).pop(enteredAccountPassword),
              child: const Text('Verify'),
            ),
          ],
        ),
    );
    if (!mounted || accountPassword == null || accountPassword.isEmpty) return false;

    try {
      final email = Supabase.instance.client.auth.currentUser?.email ??
          widget.account.likedinId;
      final response = await Supabase.instance.client.auth.signInWithPassword(
        email: email,
        password: accountPassword,
      );
      if (response.user?.id != uid) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Your Likedin account password was not accepted.')),
          );
        }
        return false;
      }
      if (!mounted) return false;
      final newPasswordResult = await HiddenChatPinDialog.show(context, setup: true);
      final newPassword = newPasswordResult?.password;
      if (!mounted || newPassword == null) return false;
      await _hiddenChatVault.configurePassword(uid, newPassword);
      _hiddenPasswordFailures = 0;
      _hiddenPasswordBlockedUntil = null;
      _startHiddenChatSession();
      return true;
    } catch (error) {
      debugPrint('Hidden-chat password recovery failed: $error');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not reset the hidden-chats password. Please try again.')),
        );
      }
      return false;
    }
  }

  void _setHiddenChatWindowSecure(bool secure) {
    unawaited(_hiddenChatSecurityChannel
        .invokeMethod<bool>('setSecure', <String, Object>{'secure': secure})
        .then<void>((_) {})
        .catchError((Object _) {}));
  }

  Future<void> _syncHiddenChatWindowSecurity() async {
    try {
      final hasHidden = await _hasHiddenConversation();
      if (!mounted) return;
      setState(() {
        _hiddenChatsExist = hasHidden;
        _hiddenChatsStateReady = true;
        if (hasHidden && index == 2) index = 0;
      });
      _setHiddenChatWindowSecure(hasHidden);
    } catch (error) {
      // Fail closed if secure metadata cannot be read at startup.
      debugPrint('Could not sync hidden-chat screenshot protection: $error');
      if (mounted) {
        setState(() {
          _hiddenChatsExist = true;
          _hiddenChatsStateReady = true;
          if (index == 2) index = 0;
        });
        _setHiddenChatWindowSecure(true);
      }
    }
  }

  // This flag is intentionally memory-only. It stays unlocked for the life of
  // this app process and resets naturally after app termination/force-stop.
  void _startHiddenChatSession() {
    // Memory-only session: remains unlocked until this process is destroyed.
    _hiddenChatSessionUnlocked = true;
    _setHiddenChatWindowSecure(true);
  }

  Future<void> _requestOpenProtectedTab(int destination) async {
    if (!mounted || _openingProtectedTab) return;
    _openingProtectedTab = true;
    try {
      final hasHidden = await _hasHiddenConversation();
      if (hasHidden && destination == 1) {
        // Never allow notification taps or legacy routes to bypass the logo
        // entry page, even while the startup secure-store check is in flight.
        if (mounted) {
          _activateTab(0);
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Press the Likedin logo on Home to open the private chat.')),
          );
        }
        return;
      }
      if (hasHidden && !_hiddenChatSessionUnlocked) {
        // Authentication always begins from the Home logo. Files may be
        // opened afterwards in the same unlocked process session.
        if (destination == 3) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Press the Likedin logo on Home to unlock private content first.')),
            );
          }
          return;
        }
        if (!await _unlockHiddenChatSession()) return;
      }
      if (mounted) _activateTab(destination);
    } catch (error) {
      debugPrint('Hidden-data access check failed: $error');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not verify chat security. The conversation remains locked.')),
        );
      }
    } finally {
      _openingProtectedTab = false;
    }
  }

  Future<void> _openHiddenChats() async {
    if (!mounted || _openingProtectedTab || !_hiddenChatsExist) return;
    _openingProtectedTab = true;
    try {
      final uid = Supabase.instance.client.auth.currentUser?.id;
      if (uid == null) return;
      final hiddenIds = await _hiddenChatVault.listHiddenChatIds(uid);
      if (hiddenIds.isEmpty) {
        await _refreshHiddenChatsPresence();
        return;
      }
      if (!_hiddenChatSessionUnlocked && !await _unlockHiddenChatSession()) return;
      if (!mounted) return;
      setState(() {
        index = 0;
        _visitedTabs.add(0);
        _showHiddenChatsPage = true;
      });
    } catch (error) {
      debugPrint('Hidden chats could not be opened: $error');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not open hidden chats. Please try again.')),
        );
      }
    } finally {
      _openingProtectedTab = false;
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    unawaited(_syncHiddenChatWindowSecurity());
    LikedinNotificationService.instance.setOnOpenChat(() {
      if (_hiddenChatsExist) {
        _activateTab(0);
        return;
      }
      _switchTab(1);
    });
    LikedinNotificationService.instance.setOnOpenIncomingCall(_openIncomingCallById);
    LikedinNotificationService.instance.setOnOpenCalls(() {
      if (_hiddenChatsExist) {
        _activateTab(0);
        return;
      }
      _switchTab(2);
    });
    LikedinNotificationService.instance.registerCurrentToken();
    _loadAccountProfilePhoto();
    _watchIncomingCalls();
  }

  Future<void> _loadAccountProfilePhoto() async {
    try {
      final client = Supabase.instance.client;
      final uid = client.auth.currentUser?.id;
      if (uid == null) {
        likedinProfilePhotoPath.value = null;
        return;
      }
      final prefs = await SharedPreferences.getInstance();
      final prefKey = '${likedinProfilePhotoPreferenceKey}_$uid';
      final localPath = prefs.getString(prefKey);
      if (localPath != null && localPath.isNotEmpty && File(localPath).existsSync()) {
        if (mounted) {
          likedinProfilePhotoPath.value = localPath;
        }
        return;
      }
      final remotePath = await RealtimeMessagingService(client).getOwnProfileAvatarPath();
      if (remotePath == null || remotePath.isEmpty) {
        if (mounted) {
          likedinProfilePhotoPath.value = null;
        }
        return;
      }
      final cached = await SharedMediaService(client).cachedFile(<String, dynamic>{
        'path': remotePath,
        'name': p.basename(remotePath),
      });
      final support = await getApplicationSupportDirectory();
      final ext = p.extension(remotePath).isNotEmpty ? p.extension(remotePath) : '.jpg';
      final restored = File('${support.path}/likedin_profile_photo_${uid}_restored$ext');
      await cached.copy(restored.path);
      await prefs.setString(prefKey, restored.path);
      if (mounted) {
        likedinProfilePhotoPath.value = restored.path;
      }
    } catch (error) {
      debugPrint('Could not load account profile photo: $error');
    }
  }

  @override
  void didHaveMemoryPressure() {
    // Release decoded bitmaps promptly on lower-memory Android devices.
    final cache = PaintingBinding.instance.imageCache;
    cache.clear();
    cache.clearLiveImages();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Deliberately do not lock on pause/background: a successful unlock remains
    // valid until this AppShell process is destroyed (including force-stop).
    // Reconcile incoming calls after the app returns to the foreground.
    if (state == AppLifecycleState.resumed) {
      unawaited(_recoverIncomingCalls());
    }
  }

  Future<void> _openIncomingCallById(String callId) async {
    try {
      final row = await Supabase.instance.client
          .from('likedin_calls')
          .select()
          .eq('id', callId)
          .eq('status', 'ringing')
          .maybeSingle();
      if (row != null && mounted) await _showIncomingCall(Map<String, dynamic>.from(row));
    } catch (e) {
      debugPrint('Could not open call from notification: $e');
    }
  }

  Future<void> _watchIncomingCalls() async {
    final client = Supabase.instance.client;
    final uid = client.auth.currentUser?.id;
    if (uid == null) return;
    _incomingCallsChannel = client
        .channel('likedin-incoming-calls-$uid')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'likedin_calls',
          filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'callee_id', value: uid),
          callback: (payload) {
            final row = payload.newRecord;
            if (row['status'] == 'ringing') _showIncomingCall(Map<String, dynamic>.from(row));
          },
        )
      ..subscribe();
    await _recoverIncomingCalls();
  }

  Future<void> _recoverIncomingCalls() async {
    final client = Supabase.instance.client;
    final uid = client.auth.currentUser?.id;
    if (uid == null) return;
    try {
      final pending = await client
          .from('likedin_calls')
          .select()
          .eq('callee_id', uid)
          .eq('status', 'ringing')
          .order('created_at', ascending: false)
          .limit(3);
      for (final row in pending) {
        await _showIncomingCall(Map<String, dynamic>.from(row));
        if (_incomingDialogOpen) break;
      }
    } catch (e) {
      debugPrint('Incoming-call recovery query failed: $e');
    }
  }

  Future<void> _showIncomingCall(Map<String, dynamic> callRow) async {
    // When the conversation is already visible, its inline invitation owns the
    // accept/decline action and starts the ringtone alert.
    if (LikedinNotificationService.instance.isConversationVisible) return;
    final id = callRow['id']?.toString();
    if (!mounted || id == null || _incomingDialogOpen || !_handledIncomingCallIds.add(id)) return;
    await LikedinNotificationService.instance.cancelIncomingCall(id);
    final client = Supabase.instance.client;
    var ownsIncomingDialog = false;
    var ownsGlobalDialog = false;
    try {
      Map<String, dynamic>? offer;
      for (var attempt = 0; attempt < 60 && offer == null; attempt++) {
        final rows = await client
            .from('likedin_call_signals')
            .select('payload')
            .eq('call_id', id)
            .eq('kind', 'offer')
            .order('created_at', ascending: false)
            .limit(1);
        if (rows.isNotEmpty) offer = Map<String, dynamic>.from(rows.first['payload'] as Map);
        if (offer == null) {
          final latest = await client.from('likedin_calls').select('status').eq('id', id).maybeSingle();
          if (latest == null || latest['status'] != 'ringing') break;
          await Future<void>.delayed(const Duration(milliseconds: 500));
        }
      }
      if (offer == null || !mounted) {
        _handledIncomingCallIds.remove(id);
        return;
      }
      if (_globalCallDialogActive) {
        _handledIncomingCallIds.remove(id);
        return;
      }
      _incomingDialogOpen = true;
      ownsIncomingDialog = true;
      _globalCallDialogActive = true;
      ownsGlobalDialog = true;
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (_) => _IncomingCallDialog(
          callId: id,
          callerId: callRow['caller_id'].toString(),
          offer: offer!,
          withVideo: callRow['call_type']?.toString().toLowerCase() == 'video',
        ),
      );
    } catch (e) {
      debugPrint('Could not present incoming call: $e');
      _handledIncomingCallIds.remove(id);
    } finally {
      if (ownsIncomingDialog) _incomingDialogOpen = false;
      if (ownsGlobalDialog) _globalCallDialogActive = false;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    final channel = _incomingCallsChannel;
    if (channel != null) Supabase.instance.client.removeChannel(channel);
    super.dispose();
  }

  Future<void> _pickProfilePhoto() async {
    File? destination;
    File? stagedSource;
    var stage = 'opening the photo picker';
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: const ['jpg', 'jpeg', 'png', 'webp'],
        allowMultiple: false,
        withData: false,
        withReadStream: true,
      );
      if (result == null) return;

      stage = 'reading the selected photo';
      final selectedFile = result.files.single;
      final selectedPath = selectedFile.path;
      late final File source;
      if (selectedPath != null && selectedPath.isNotEmpty && !selectedPath.startsWith('content://') &&
          await File(selectedPath).exists()) {
        source = File(selectedPath);
      } else {
        final stream = selectedFile.readStream;
        if (stream == null) {
          throw StateError('Android could not read this photo. Please choose it again from Gallery or Files.');
        }
        final staged = await SharedMediaService.copyStreamToTemporaryFile(
          stream,
          selectedFile.name,
          maxSizeBytes: 15 * 1024 * 1024,
        );
        stagedSource = staged;
        source = staged;
      }

      final sourceSize = await source.length();
      if (sourceSize <= 0 || sourceSize > 15 * 1024 * 1024) {
        throw StateError('Choose a profile photo smaller than 15 MB.');
      }

      stage = 'preparing the photo editor';
      final sourceBytes = await source.readAsBytes();
      final sourceMime = await SharedMediaService.detectMimeType(
        source,
        displayName: selectedFile.name,
      );
      final sourceExtension = SharedMediaService.extensionForMime(sourceMime)
              ?.replaceFirst('.', '') ??
          selectedFile.extension?.toLowerCase() ??
          p.extension(selectedPath ?? '').replaceFirst('.', '').toLowerCase();
      if (!const {'image/jpeg', 'image/png', 'image/webp'}.contains(sourceMime)) {
        throw StateError('Choose a JPG, PNG or WebP photo.');
      }
      if (!mounted) return;
      final croppedBytes = await Navigator.of(context).push<Uint8List>(
        MaterialPageRoute<Uint8List>(
          fullscreenDialog: true,
          builder: (_) => ProfilePhotoEditorPage(
            sourceBytes: sourceBytes,
            sourceExtension: sourceExtension,
          ),
        ),
      );
      if (croppedBytes == null || croppedBytes.isEmpty || !mounted) return;
      if (croppedBytes.length > 15 * 1024 * 1024) {
        throw StateError('The edited photo is too large. Please crop it again.');
      }

      stage = 'checking your signed-in account';
      final client = Supabase.instance.client;
      final uid = client.auth.currentUser?.id;
      if (uid == null) {
        throw StateError('Your session has expired. Sign in again before changing your profile photo.');
      }
      final prefs = await SharedPreferences.getInstance();
      final accountPhotoKey = '${likedinProfilePhotoPreferenceKey}_$uid';
      final previousLocalPath = prefs.getString(accountPhotoKey);

      // Reading the old avatar is only needed for post-success cleanup. It must
      // never block a new upload: the RPC below is the authoritative profile
      // update, and an unreadable old path can safely be left for later cleanup.
      String? previousRemotePath;
      try {
        final oldProfile = await client
            .from('profiles')
            .select('avatar_path')
            .eq('user_id', uid)
            .maybeSingle();
        previousRemotePath = oldProfile?['avatar_path']?.toString();
      } catch (error, stackTrace) {
        debugPrint('[ProfilePhoto] Could not read previous avatar path; continuing upload: $error');
        debugPrintStack(stackTrace: stackTrace);
      }

      stage = 'saving the edited photo on this device';
      final support = await getApplicationSupportDirectory();
      final outputFile = File(
        '${support.path}/likedin_profile_photo_${uid}_${DateTime.now().millisecondsSinceEpoch}.jpg',
      );
      destination = outputFile;
      await outputFile.writeAsBytes(croppedBytes, flush: true);
      await FileImage(outputFile).evict();

      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final objectPath = '$uid/avatars/profile_$timestamp.jpg';
      stage = 'uploading the photo to private Storage';
      await client.storage.from('likedin-media').upload(
        objectPath,
        outputFile,
        fileOptions: const FileOptions(
          cacheControl: '86400',
          upsert: false,
          contentType: 'image/jpeg',
        ),
      );

      stage = 'saving the new avatar path to your profile';
      try {
        await RealtimeMessagingService(client).setProfileAvatarPath(objectPath);
      } catch (error, stackTrace) {
        // Do not leave an orphaned object when the profile update is rejected.
        try {
          await client.storage.from('likedin-media').remove([objectPath]);
        } catch (cleanupError) {
          debugPrint('[ProfilePhoto] Failed to remove uncommitted upload: $cleanupError');
        }
        debugPrint('[ProfilePhoto] Profile avatar RPC failed: $error');
        debugPrintStack(stackTrace: stackTrace);
        rethrow;
      }

      // Commit local state only after Storage and the profile row both update.
      stage = 'saving the profile photo on this device';
      await prefs.setString(accountPhotoKey, outputFile.path);
      likedinProfilePhotoPath.value = outputFile.path;
      if (previousLocalPath != null && previousLocalPath != outputFile.path) {
        final previousFile = File(previousLocalPath);
        await FileImage(previousFile).evict();
        if (await previousFile.exists()) {
          try {
            await previousFile.delete();
          } catch (error) {
            debugPrint('[ProfilePhoto] Could not remove previous local avatar: $error');
          }
        }
      }
      if (previousRemotePath != null &&
          previousRemotePath.isNotEmpty &&
          previousRemotePath != objectPath &&
          previousRemotePath.startsWith('$uid/avatars/')) {
        try {
          await client.storage.from('likedin-media').remove([previousRemotePath]);
        } catch (error) {
          // The new avatar is already committed. A stale old object is harmless
          // and must not turn a successful profile update into a reported failure.
          debugPrint('[ProfilePhoto] Could not remove previous remote avatar: $error');
        }
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Profile photo updated and synced to your friend.')),
        );
      }
    } catch (error, stackTrace) {
      debugPrint('[ProfilePhoto] Failed while $stage: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (destination != null &&
          likedinProfilePhotoPath.value != destination.path) {
        try {
          if (await destination.exists()) await destination.delete();
        } catch (cleanupError) {
          debugPrint('[ProfilePhoto] Could not remove temporary edited photo: $cleanupError');
        }
      }
      if (mounted) {
        final rawDetails = error.toString().trim();
        final details = rawDetails.isEmpty
            ? 'The server returned no additional error details.'
            : (rawDetails.length > 240 ? '${rawDetails.substring(0, 240)}…' : rawDetails);
        final message = error is StateError
            ? error.message.toString()
            : 'Profile photo failed while $stage. $details';
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(message),
            duration: const Duration(seconds: 8),
          ),
        );
      }
    } finally {
      if (stagedSource != null) {
        try {
          if (await stagedSource.exists()) await stagedSource.delete();
        } catch (cleanupError) {
          debugPrint('[ProfilePhoto] Could not remove temporary picker source: $cleanupError');
        }
      }
    }
  }

  void _openAppearance() {
    Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => ThemeCustomizationPage(
        themeMode: likedinThemeMode,
        onSetDark: setLikedinDarkMode,
      ),
    ));
  }

  void _openStorage() {
    Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => StoragePage(store: widget.attachmentVault),
    ));
  }

  Widget _profileAvatar(bool dark) => ValueListenableBuilder<String?>(
        valueListenable: likedinProfilePhotoPath,
        builder: (context, path, _) {
          return CircleAvatar(
            radius: 18,
            backgroundColor: dark ? const Color(0xFF29445B) : const Color(0xFFDCEBFA),
            child: path == null || path.isEmpty
                ? Icon(Icons.person, color: likedinPrimary(Theme.of(context).brightness), size: 20)
                : RepaintBoundary(
                    child: ClipOval(
                      child: Image.file(
                        File(path),
                        width: 36,
                        height: 36,
                        cacheWidth: 108,
                        fit: BoxFit.cover,
                        gaplessPlayback: true,
                        errorBuilder: (_, __, ___) => Icon(Icons.person, color: likedinPrimary(Theme.of(context).brightness), size: 20),
                      ),
                    ),
                  ),
          );
        },
      );

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final callsTabVisible = _hiddenChatsStateReady && !_hiddenChatsExist;
    final pages = List<Widget>.generate(6, (pageIndex) {
      if (!_visitedTabs.contains(pageIndex)) return const SizedBox.shrink();
      late final Widget page;
      switch (pageIndex) {
        case 0:
          page = _showHiddenChatsPage
              ? HiddenChatsPage(
                  onBack: _closeHiddenChatsPage,
                  onOpenChat: _openHiddenConversation,
                  onUnhidden: _refreshHiddenChatsPresence,
                  onChangePassword: () => unawaited(_changeHiddenChatsPassword()),
                )
              : HomePage(
                  displayName: widget.account.displayName,
                  onOpenChat: () => _switchTab(1),
                  onHiddenChatsChanged: _onHiddenChatsChanged,
                  isActive: index == 0,
                );
          break;
        case 1:
          page = ChatPage(attachmentVault: widget.attachmentVault, isActive: index == 1, onBack: () => _switchTab(0));
          break;
        case 2:
          page = _hiddenChatsExist ? const SizedBox.shrink() : const CallsPage();
          break;
        case 3:
          page = FilesPage(
            store: widget.attachmentVault,
            isActive: index == 3,
            allowHiddenConversationMedia: _hiddenChatSessionUnlocked,
          );
          break;
        case 4:
          page = SettingsPage(
            account: widget.account,
            onSignOut: widget.onSignOut,
            attachmentVault: widget.attachmentVault,
          );
          break;
        default:
          page = ProfilePage(
            displayName: widget.account.displayName,
            email: widget.account.likedinId,
            photoPath: likedinProfilePhotoPath,
            onEditPhoto: _pickProfilePhoto,
            onOpenSettings: () => _switchTab(4),
            onOpenAppearance: _openAppearance,
            onOpenStorage: _openStorage,
            onOpenFiles: () => _switchTab(3),
            onSignOut: () => widget.onSignOut(),
          );
      }
      return TickerMode(enabled: index == pageIndex, child: page);
    }, growable: false);
    return PopScope<Object?>(
      canPop: index == 0 && !_showHiddenChatsPage,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop || !mounted) return;
        if (_showHiddenChatsPage) {
          _closeHiddenChatsPage();
        } else if (index != 0) {
          _switchTab(0);
        }
      },
      child: AuroraBackdrop(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: SafeArea(
            child: Column(
              children: [
                if (index != 1)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 8, 12, 2),
                    child: Row(
                      children: [
                        Tooltip(
                          message: _hiddenChatsExist && index == 0
                              ? 'Open private chat'
                              : 'Likedin home',
                          child: InkWell(
                            borderRadius: BorderRadius.circular(10),
                            onTap: index == 0 && _hiddenChatsExist
                                ? _openHiddenChats
                                : null,
                            child: const Padding(
                              padding: EdgeInsets.all(2),
                              child: LikedinLogo(size: 34),
                            ),
                          ),
                        ),
                        const SizedBox(width: 11),
                        const Expanded(
                          child: Text(
                            'Likedin',
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w800,
                              letterSpacing: -.6,
                            ),
                          ),
                        ),
                        IconButton(
                          tooltip: 'Settings',
                          onPressed: () => _switchTab(4),
                          icon: const Icon(Icons.settings_outlined),
                        ),
                        IconButton(
                          tooltip: 'Profile',
                          onPressed: () => _switchTab(5),
                          icon: _profileAvatar(dark),
                        ),
                      ],
                    ),
                  ),
                Expanded(child: IndexedStack(index: index, children: pages)),
              ],
            ),
          ),
          floatingActionButton: index == 0 && !_hiddenChatsExist && !_showHiddenChatsPage
              ? FloatingActionButton.small(
                  tooltip: 'New message',
                  onPressed: () => _switchTab(1),
                  child: const Icon(Icons.edit_outlined),
                )
              : null,
          bottomNavigationBar: index == 1
              ? null
              : GlassPanel(
                  radius: const BorderRadius.vertical(top: Radius.circular(24)),
                  frosted: true,
                  blur: 14,
                  child: SafeArea(
                    top: false,
                    child: NavigationBar(
                      height: 68,
                      elevation: 0,
                      backgroundColor: Colors.transparent,
                      surfaceTintColor: Colors.transparent,
                      // The Calls destination is removed whenever any chat is
                      // hidden. Incoming call alerts and active call screens
                      // continue to work independently of this tab.
                      selectedIndex: callsTabVisible
                          ? (index <= 1 ? 0 : (index == 2 ? 1 : (index == 3 ? 2 : 3)))
                          : (index <= 1 ? 0 : (index == 3 ? 1 : 2)),
                      onDestinationSelected: (v) => _switchTab(
                        callsTabVisible ? const [0, 2, 3, 5][v] : const [0, 3, 5][v],
                      ),
                      destinations: [
                        const NavigationDestination(
                          icon: Icon(Icons.chat_bubble_outline_rounded),
                          selectedIcon: Icon(Icons.chat_bubble_rounded),
                          label: 'Chats',
                        ),
                        if (callsTabVisible)
                          const NavigationDestination(
                            icon: Icon(Icons.call_outlined),
                            selectedIcon: Icon(Icons.call),
                            label: 'Calls',
                          ),
                        const NavigationDestination(
                          icon: Icon(Icons.perm_media_outlined),
                          selectedIcon: Icon(Icons.perm_media),
                          label: 'Files',
                        ),
                        const NavigationDestination(
                          icon: Icon(Icons.person_outline_rounded),
                          selectedIcon: Icon(Icons.person_rounded),
                          label: 'Profile',
                        ),
                      ],
                    ),
                  ),
                ),
        ),
      ),
    );
  }
}

class _VoiceMessagePlayer extends StatefulWidget {
  const _VoiceMessagePlayer({super.key, required this.payload});
  final Map<String, dynamic> payload;
  @override
  State<_VoiceMessagePlayer> createState() => _VoiceMessagePlayerState();
}

class _VoiceMessagePlayerState extends State<_VoiceMessagePlayer>
    with AutomaticKeepAliveClientMixin<_VoiceMessagePlayer> {
  static AudioPlayer? _activePlayer;
  AudioPlayer? _player;
  StreamSubscription<PlayerState>? _stateSubscription;
  final ValueNotifier<double?> _pendingSeekMsNotifier = ValueNotifier<double?>(null);
  bool _loading = false;
  bool _loaded = false;
  double _speed = 1.0;
  String? _error;

  AudioPlayer _ensurePlayer() {
    final existing = _player;
    if (existing != null) return existing;
    final created = AudioPlayer();
    _player = created;
    _stateSubscription = created.playerStateStream.listen((state) {
      if (state.processingState == ProcessingState.completed) {
        created.pause();
        created.seek(Duration.zero);
      }
      // Re-evaluate keep-alive whenever playback starts, pauses or finishes.
      if (mounted) {
        updateKeepAlive();
        setState(() {});
      }
    });
    return created;
  }

  /// Keep the row (and its player) alive while a clip is playing or paused
  /// part-way, so scrolling it out of the lazy list does not stop playback.
  /// Idle rows are released as before.
  @override
  bool get wantKeepAlive {
    final player = _player;
    return _loaded &&
        player != null &&
        (player.playing ||
            (player.position > Duration.zero &&
                player.processingState != ProcessingState.completed));
  }

  Future<void> _load() async {
    if (_loading || _loaded) return;
    setState(() { _loading = true; _error = null; });
    try {
      final file = await SharedMediaService(Supabase.instance.client).cachedFile(widget.payload);
      final player = _ensurePlayer();
      await player.setFilePath(file.path);
      _loaded = true;
    } catch (e) {
      _error = e.toString();
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _cycleSpeed() async {
    final next = _speed == 1.0 ? 1.5 : _speed == 1.5 ? 2.0 : 1.0;
    setState(() => _speed = next);
    final player = _player;
    if (player == null) return;
    try {
      await player.setSpeed(next);
    } catch (_) {}
  }

  @override
  void dispose() {
    final player = _player;
    if (player != null) {
      if (identical(_activePlayer, player)) {
        _activePlayer = null;
      }
      _stateSubscription?.cancel();
      player.dispose();
    }
    _pendingSeekMsNotifier.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return SizedBox(
        width: (MediaQuery.sizeOf(context).width * .66).clamp(190.0, 320.0).toDouble(),
        child: Row(
          children: [
            IconButton.filled(
              onPressed: _loading
                  ? null
                  : () async {
                      if (!_loaded) {
                        await _load();
                        if (!_loaded) return;
                      }
                      final player = _ensurePlayer();
                      if (player.playing) {
                        await player.pause();
                      } else {
                        final previous = _activePlayer;
                        if (previous != null && !identical(previous, player)) {
                          try {
                            await previous.pause();
                          } catch (_) {}
                        }
                        _activePlayer = player;
                        if (player.processingState == ProcessingState.completed) {
                          await player.seek(Duration.zero);
                        }
                        await player.setSpeed(_speed);
                        await player.play();
                      }
                      if (mounted) setState(() {});
                    },
              icon: Icon((_player?.playing ?? false) ? Icons.pause : Icons.play_arrow),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Expanded(
                        child: Text('Voice message', style: TextStyle(fontWeight: FontWeight.w700)),
                      ),
                      InkWell(
                        onTap: _cycleSpeed,
                        borderRadius: BorderRadius.circular(8),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          child: Text(
                            '${_speed == _speed.roundToDouble() ? _speed.toInt() : _speed}x',
                            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: likedinPrimary(Theme.of(context).brightness)),
                          ),
                        ),
                      ),
                    ],
                  ),
                  if (_loading)
                    const LinearProgressIndicator(minHeight: 2)
                  else if (_error != null)
                    const Text(
                      'Audio unavailable',
                      style: TextStyle(fontSize: 12, color: Colors.red),
                    ),
                  if (_error != null)
                    TextButton(onPressed: _load, child: const Text('Retry download'))
                  else if (_loaded && _player != null)
                    StreamBuilder<Duration>(
                      stream: _player!.positionStream,
                      builder: (_, snap) {
                        final pos = snap.data ?? Duration.zero;
                        final total = _player?.duration ?? Duration.zero;
                        return Column(
                          children: [
                            ValueListenableBuilder<double?>(
                              valueListenable: _pendingSeekMsNotifier,
                              builder: (_, pendingSeekMs, __) => Slider(
                                value: total.inMilliseconds == 0
                                    ? 0
                                    : (pendingSeekMs ?? pos.inMilliseconds.toDouble())
                                        .clamp(0, total.inMilliseconds.toDouble()),
                                max: total.inMilliseconds == 0 ? 1 : total.inMilliseconds.toDouble(),
                                onChanged: (v) => _pendingSeekMsNotifier.value = v,
                                onChangeEnd: (v) async {
                                  await _player?.seek(Duration(milliseconds: v.round()));
                                  if (mounted) _pendingSeekMsNotifier.value = null;
                                },
                              ),
                            ),
                            Text(
                              '${_fmt(pos)} / ${_fmt(total)}',
                              style: TextStyle(fontSize: 12, color: likedinMutedText(Theme.of(context).brightness)),
                            ),
                          ],
                        );
                      },
                    ),
                ],
              ),
            ),
          ],
        ),
      );
  }

  String _fmt(Duration d) => '${d.inMinutes}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';
}

class _ChatMediaMessage extends StatefulWidget {
  const _ChatMediaMessage({
    super.key,
    required this.payload,
    required this.name,
    required this.sizeLabel,
    this.autoLoadVideo = false,
  });
  final Map<String, dynamic> payload;
  final String name;
  final String sizeLabel;
  final bool autoLoadVideo;
  @override
  State<_ChatMediaMessage> createState() => _ChatMediaMessageState();
}

class _ChatMediaMessageState extends State<_ChatMediaMessage> {
  File? _file;
  bool _loading = false;
  String? _error;
  int _loadGeneration = 0;

  bool get _isVideo => widget.payload['kind'] == 'video';
  bool get _isGif => widget.payload['animated'] == true ||
      widget.name.toLowerCase().endsWith('.gif') || widget.payload['mime'] == 'image/gif';

  @override
  void initState() {
    super.initState();
    // Normal chat bubbles keep video downloads manual. Contact Info opens the
    // selected item explicitly, so it can load the requested video immediately.
    if (!_isVideo || widget.autoLoadVideo) _loadFile();
  }

  @override
  void didUpdateWidget(covariant _ChatMediaMessage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.payload['path'] != widget.payload['path'] ||
        oldWidget.payload['kind'] != widget.payload['kind']) {
      _loadGeneration++;
      _file = null;
      _error = null;
      _loading = false;
      if (!_isVideo || widget.autoLoadVideo) _loadFile();
    }
  }

  Future<void> _loadFile() async {
    if (_loading || _file != null) return;
    final generation = ++_loadGeneration;
    setState(() { _loading = true; _error = null; });
    Object? lastError;
    try {
      final media = SharedMediaService(Supabase.instance.client);
      for (var attempt = 0; attempt < 3; attempt++) {
        try {
          final payload = Map<String, dynamic>.from(widget.payload);
          final file = await media.cachedFile(payload);
          if (!mounted || generation != _loadGeneration) return;
          setState(() => _file = file);
          return;
        } catch (error) {
          lastError = error;
          if (generation != _loadGeneration) return;
          if (attempt < 2) {
            await Future<void>.delayed(Duration(milliseconds: 350 * (attempt + 1)));
          }
        }
      }
      if (mounted && generation == _loadGeneration) {
        setState(() => _error = lastError?.toString() ?? 'Media could not be loaded.');
      }
    } finally {
      if (mounted && generation == _loadGeneration) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final file = _file;
    if (file == null) {
      if (_error != null) {
        return _mediaError('Media unavailable. Tap to retry.', _loadFile);
      }
      return SizedBox(
        width: 270,
        height: 190,
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: .6),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Center(
            child: _loading
                ? const CircularProgressIndicator()
                : Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(_isVideo ? Icons.movie_outlined : Icons.image_outlined, size: 38),
                      const SizedBox(height: 8),
                      Text(_isVideo ? 'Video not downloaded' : 'Loading photo'),
                      const SizedBox(height: 5),
                      Text('${widget.name} · ${widget.sizeLabel}', style: const TextStyle(fontSize: 12)),
                      if (_isVideo) ...[
                        const SizedBox(height: 8),
                        FilledButton.tonalIcon(
                          onPressed: _loadFile,
                          icon: const Icon(Icons.download_rounded),
                          label: const Text('Tap to download'),
                        ),
                      ],
                    ],
                  ),
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        if (_isVideo)
          _ChatVideoPreview(file: file, title: widget.name)
        else
          GestureDetector(
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => _LikedinImageViewer(file: file, title: widget.name)),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 300, maxHeight: 360, minWidth: 210),
                child: Image.file(
                  file,
                  fit: _isGif ? BoxFit.contain : BoxFit.cover,
                  width: 300,
                  cacheWidth: 640,
                  frameBuilder: (context, child, frame, sync) => frame != null
                      ? child
                      : const SizedBox(width: 270, height: 190, child: Center(child: CircularProgressIndicator())),
                  errorBuilder: (_, __, ___) => const SizedBox(
                    width: 270, height: 150,
                    child: Center(child: Icon(Icons.broken_image_outlined, size: 42)),
                  ),
                ),
              ),
            ),
          ),
        const SizedBox(height: 5),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(_isVideo ? Icons.videocam_outlined : Icons.image_outlined, size: 17),
            const SizedBox(width: 6),
            Flexible(
              child: Text('${widget.name} · ${widget.sizeLabel}', maxLines: 1,
                overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, color: likedinMutedText(Theme.of(context).brightness))),
            ),
            IconButton(
              visualDensity: VisualDensity.compact,
              tooltip: 'Save to Downloads',
              icon: const Icon(Icons.download_rounded, size: 20),
              onPressed: () async {
                // Capture the messenger before awaiting. After the operation,
                // use the State's mounted guard rather than reading context
                // across the asynchronous gap.
                final messenger = ScaffoldMessenger.of(context);
                try {
                  final saved = await SharedMediaService(Supabase.instance.client)
                      .downloadToPublicDownloads(widget.payload);
                  if (!mounted) return;
                  messenger.showSnackBar(
                    SnackBar(content: Text('Saved $saved to Downloads.')),
                  );
                } catch (e) {
                  if (!mounted) return;
                  messenger.showSnackBar(
                    const SnackBar(content: Text('Download failed. Check your connection and storage, then try again.')),
                  );
                }
              },
            ),
          ],
        ),
      ],
    );
  }

  Widget _mediaError(String message, VoidCallback retry) => SizedBox(
    width: 270,
    child: TextButton.icon(onPressed: retry, icon: const Icon(Icons.refresh), label: Text(message)),
  );
}

class _ChatVideoPreview extends StatelessWidget {
  const _ChatVideoPreview({required this.file, required this.title});
  final File file;
  final String title;

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => _LikedinVideoViewer(file: file, title: title),
          ),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: Container(
            width: 300,
            height: 176,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF172B4D), Color(0xFF0A192F)],
              ),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                const Icon(
                  Icons.play_circle_fill_rounded,
                  color: Colors.white,
                  size: 64,
                ),
                Positioned(
                  left: 12,
                  right: 12,
                  bottom: 10,
                  child: Row(
                    children: [
                      const Icon(Icons.videocam_rounded, color: Colors.white70, size: 16),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
}

class _LikedinImageViewer extends StatelessWidget {
  const _LikedinImageViewer({required this.file, required this.title});
  final File file;
  final String title;

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
          title: Text(title),
        ),
        body: Center(
          child: InteractiveViewer(
            minScale: 0.8,
            maxScale: 5,
            child: Image.file(
              file,
              fit: BoxFit.contain,
              cacheWidth: 1400,
              errorBuilder: (_, __, ___) => const Icon(
                Icons.broken_image_outlined,
                color: Colors.white,
                size: 56,
              ),
            ),
          ),
        ),
      );
}

class _LikedinVideoViewer extends StatefulWidget {
  const _LikedinVideoViewer({required this.file, required this.title});
  final File file;
  final String title;
  @override
  State<_LikedinVideoViewer> createState() => _LikedinVideoViewerState();
}

class _LikedinVideoViewerState extends State<_LikedinVideoViewer> with WidgetsBindingObserver {
  late final VideoPlayerController _controller = VideoPlayerController.file(widget.file);
  String? _error;

  void _onControllerUpdated() {
    if (mounted) setState(() {});
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _controller.addListener(_onControllerUpdated);
    _controller.initialize().then((_) async {
      if (!mounted) return;
      setState(() {});
      if (!mounted) return;
      await _controller.play();
    }).catchError((Object e) {
      if (mounted) setState(() => _error = e.toString());
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused || state == AppLifecycleState.inactive) {
      if (_controller.value.isInitialized && _controller.value.isPlaying) {
        _controller.pause();
      }
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _controller.removeListener(_onControllerUpdated);
    _controller.dispose();
    super.dispose();
  }

  String _formatDuration(Duration d) =>
      '${d.inMinutes.toString().padLeft(2, '0')}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
          title: Text(widget.title),
        ),
        body: Column(
          children: [
            Expanded(
              child: Center(
                child: _error != null
                    ? const Padding(
                        padding: EdgeInsets.all(24),
                        child: Text(
                          'Could not play this video file.',
                          style: TextStyle(color: Colors.white70),
                        ),
                      )
                    : _controller.value.isInitialized
                        ? AspectRatio(
                            aspectRatio: _controller.value.aspectRatio,
                            child: VideoPlayer(_controller),
                          )
                        : const CircularProgressIndicator(),
              ),
            ),
            if (_error == null && _controller.value.isInitialized)
              SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      VideoProgressIndicator(
                        _controller,
                        allowScrubbing: true,
                        colors: VideoProgressColors(
                          playedColor: likedinPrimary(Theme.of(context).brightness),
                          bufferedColor: Colors.white38,
                          backgroundColor: Colors.white12,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          IconButton(
                            onPressed: () {
                              setState(() {
                                _controller.value.isPlaying
                                    ? _controller.pause()
                                    : _controller.play();
                              });
                            },
                            icon: Icon(
                              _controller.value.isPlaying ? Icons.pause : Icons.play_arrow,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            '${_formatDuration(_controller.value.position)} / ${_formatDuration(_controller.value.duration)}',
                            style: const TextStyle(color: Colors.white70, fontSize: 12),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      );
}


/// Compact quote renderer. Image/GIF replies use the same cached media file as
/// the message bubble; concurrent requests are coalesced by SharedMediaService.
class _ReplyQuotePreview extends StatefulWidget {
  const _ReplyQuotePreview({
    required this.original,
    required this.fallbackText,
    this.compact = false,
  });

  final RemoteMessage? original;
  final String fallbackText;
  final bool compact;

  @override
  State<_ReplyQuotePreview> createState() => _ReplyQuotePreviewState();
}

class _ReplyQuotePreviewState extends State<_ReplyQuotePreview> {
  Future<File>? _imageFuture;
  Map<String, dynamic>? _payload;

  @override
  void initState() {
    super.initState();
    _prepare();
  }

  @override
  void didUpdateWidget(covariant _ReplyQuotePreview oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.original?.id != widget.original?.id ||
        oldWidget.original?.text != widget.original?.text) {
      _prepare();
    }
  }

  void _prepare() {
    _payload = null;
    _imageFuture = null;
    final original = widget.original;
    if (original == null || original.deletedForEveryoneAt != null) return;
    final payload = SharedMediaService(Supabase.instance.client).decode(original.text);
    if (payload == null) return;
    _payload = payload;
    if (payload['kind'] == 'image') {
      _imageFuture = SharedMediaService(Supabase.instance.client).cachedFileIfPresent(payload);
    }
  }

  String _mediaLabel(Map<String, dynamic> payload) {
    final kind = payload['kind']?.toString() ?? 'file';
    if (kind == 'image') {
      final animated = payload['animated'] == true ||
          payload['mime'] == 'image/gif' ||
          (payload['name']?.toString().toLowerCase().endsWith('.gif') ?? false);
      return animated ? 'GIF' : 'Photo';
    }
    if (kind == 'video') return 'Video';
    if (kind == 'audio') return 'Voice message';
    return 'Attachment';
  }

  Widget _iconPreview(IconData icon, {Color? color}) => Container(
        width: widget.compact ? 52 : 60,
        height: widget.compact ? 42 : 48,
        decoration: BoxDecoration(
          color: likedinPrimary(Theme.of(context).brightness).withValues(alpha: .10),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, color: color ?? likedinPrimary(Theme.of(context).brightness), size: 23),
      );

  @override
  Widget build(BuildContext context) {
    final payload = _payload;
    if (payload == null) {
      return Text(
        widget.fallbackText,
        maxLines: widget.compact ? 1 : 2,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          fontSize: 12,
          height: 1.2,
          color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .78),
        ),
      );
    }

    final kind = payload['kind']?.toString() ?? 'file';
    final label = _mediaLabel(payload);
    Widget preview;
    if (kind == 'image' && _imageFuture != null) {
      preview = FutureBuilder<File>(
        future: _imageFuture,
        builder: (context, snapshot) {
          final file = snapshot.data;
          if (snapshot.hasError) {
            return _iconPreview(Icons.image_not_supported_outlined);
          }
          if (file == null || !snapshot.hasData) {
            return SizedBox(
              width: widget.compact ? 52 : 60,
              height: widget.compact ? 42 : 48,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: likedinPrimary(Theme.of(context).brightness).withValues(alpha: .10),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Center(
                  child: SizedBox(width: 15, height: 15, child: CircularProgressIndicator(strokeWidth: 1.7)),
                ),
              ),
            );
          }
          return ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.file(
              file,
              width: widget.compact ? 52 : 60,
              height: widget.compact ? 42 : 48,
              fit: BoxFit.cover,
              cacheWidth: 120,
              filterQuality: FilterQuality.low,
              errorBuilder: (_, __, ___) => _iconPreview(Icons.image_outlined),
            ),
          );
        },
      );
    } else if (kind == 'video') {
      preview = _iconPreview(Icons.play_circle_outline_rounded);
    } else if (kind == 'audio') {
      preview = _iconPreview(Icons.graphic_eq_rounded);
    } else {
      preview = _iconPreview(Icons.insert_drive_file_outlined);
    }

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        preview,
        const SizedBox(width: 8),
        Flexible(
          child: Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: .82),
            ),
          ),
        ),
      ],
    );
  }
}
