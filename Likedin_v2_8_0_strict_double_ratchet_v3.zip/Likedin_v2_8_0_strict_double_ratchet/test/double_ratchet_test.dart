import 'dart:convert';

import 'package:cryptography/cryptography.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:likedin/security/double_ratchet.dart';

Future<({DoubleRatchetSession alice, DoubleRatchetSession bob})> _makePair() async {
  final x25519 = X25519();
  final aPair = await x25519.newKeyPair();
  final bPair = await x25519.newKeyPair();
  final aPriv = await aPair.extractPrivateKeyBytes();
  final aPub = (await aPair.extractPublicKey()).bytes;
  final bPriv = await bPair.extractPrivateKeyBytes();
  final bPub = (await bPair.extractPublicKey()).bytes;

  final alice = await DoubleRatchetSession.create(
    userId: '00000000-0000-0000-0000-000000000001',
    peerId: '00000000-0000-0000-0000-000000000002',
    ownIdentityPriv: aPriv,
    ownIdentityPub: aPub,
    peerIdentityPub: bPub,
  );
  final bob = await DoubleRatchetSession.create(
    userId: '00000000-0000-0000-0000-000000000002',
    peerId: '00000000-0000-0000-0000-000000000001',
    ownIdentityPriv: bPriv,
    ownIdentityPub: bPub,
    peerIdentityPub: aPub,
  );
  return (alice: alice, bob: bob);
}

void main() {
  test('alternating turns rotate ephemeral DH keys for forward secrecy', () async {
    final pair = await _makePair();
    final seenDhKeys = <String>{};

    for (var turn = 0; turn < 5; turn++) {
      final aEnv = await pair.alice.encrypt('Alice turn $turn');
      final aMap = jsonDecode(aEnv) as Map<String, dynamic>;
      seenDhKeys.add(aMap['dh'].toString());
      expect(await pair.bob.decrypt(aEnv), 'Alice turn $turn');

      final bEnv = await pair.bob.encrypt('Bob turn $turn');
      final bMap = jsonDecode(bEnv) as Map<String, dynamic>;
      seenDhKeys.add(bMap['dh'].toString());
      expect(await pair.alice.decrypt(bEnv), 'Bob turn $turn');
    }

    // Every single turn generated a brand-new ephemeral X25519 key pair.
    expect(seenDhKeys.length, 10);
  });

  test('out-of-order messages decrypt cleanly via skipped keys and delete keys after use', () async {
    final pair = await _makePair();
    final m0 = await pair.alice.encrypt('msg 0');
    final m1 = await pair.alice.encrypt('msg 1');
    final m2 = await pair.alice.encrypt('msg 2');
    final m3 = await pair.alice.encrypt('msg 3');

    // Deliver m3 first -> Bob skips & stores m0, m1, m2.
    expect(await pair.bob.decrypt(m3), 'msg 3');
    expect(pair.bob.skippedKeyCount, 3);

    // Deliver m1, m0, m2 in scrambled order -> skipped keys are consumed & deleted.
    expect(await pair.bob.decrypt(m1), 'msg 1');
    expect(pair.bob.skippedKeyCount, 2);
    expect(await pair.bob.decrypt(m0), 'msg 0');
    expect(pair.bob.skippedKeyCount, 1);
    expect(await pair.bob.decrypt(m2), 'msg 2');
    expect(pair.bob.skippedKeyCount, 0);

    // Replaying an already-consumed message fails (forward secrecy).
    await expectLater(pair.bob.decrypt(m1), throwsA(anything));
  });

  test('simultaneous crossing first messages both decrypt and converge cleanly', () async {
    final pair = await _makePair();

    // Both Alice and Bob send before receiving each other's first message!
    final a1 = await pair.alice.encrypt('Alice first!');
    final a2 = await pair.alice.encrypt('Alice second!');
    final b1 = await pair.bob.encrypt('Bob simultaneous first!');
    final b2 = await pair.bob.encrypt('Bob simultaneous second!');

    expect(await pair.bob.decrypt(a1), 'Alice first!');
    expect(await pair.bob.decrypt(a2), 'Alice second!');
    expect(await pair.alice.decrypt(b1), 'Bob simultaneous first!');
    expect(await pair.alice.decrypt(b2), 'Bob simultaneous second!');

    // Subsequent alternating replies converge onto the standard Double Ratchet.
    final b3 = await pair.bob.encrypt('Bob after converge');
    expect(await pair.alice.decrypt(b3), 'Bob after converge');
    final a3 = await pair.alice.encrypt('Alice after converge');
    expect(await pair.bob.decrypt(a3), 'Alice after converge');
  });

  test('rejects tampered header AAD without corrupting ratchet state', () async {
    final pair = await _makePair();
    final env = await pair.alice.encrypt('authentic message');
    final map = Map<String, dynamic>.from(jsonDecode(env) as Map);
    map['pn'] = 999; // Tamper authenticated header
    final tampered = jsonEncode(map);

    await expectLater(pair.bob.decrypt(tampered), throwsA(anything));
    // Original untampered message still decrypts cleanly (state was not corrupted).
    expect(await pair.bob.decrypt(env), 'authentic message');
  });

  test('JSON serialization round-trips ratchet state across restarts', () async {
    final pair = await _makePair();
    final m1 = await pair.alice.encrypt('before restart');
    expect(await pair.bob.decrypt(m1), 'before restart');

    final aliceRestored = DoubleRatchetSession.fromJson(
      pair.alice.toJson(),
      userId: pair.alice.userId,
      peerId: pair.alice.peerId,
      ownIdentityPriv: pair.alice.ownIdentityPriv,
      ownIdentityPub: pair.alice.ownIdentityPub,
      peerIdentityPub: pair.alice.peerIdentityPub,
    )!;
    final bobRestored = DoubleRatchetSession.fromJson(
      pair.bob.toJson(),
      userId: pair.bob.userId,
      peerId: pair.bob.peerId,
      ownIdentityPriv: pair.bob.ownIdentityPriv,
      ownIdentityPub: pair.bob.ownIdentityPub,
      peerIdentityPub: pair.bob.peerIdentityPub,
    )!;

    final m2 = await bobRestored.encrypt('after restart');
    expect(await aliceRestored.decrypt(m2), 'after restart');
  });
}
