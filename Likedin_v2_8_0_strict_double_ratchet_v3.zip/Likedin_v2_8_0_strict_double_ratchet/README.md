# Likedin v2.8.0+134 — Strict E2EE, Pure-Dart Double Ratchet Forward Secrecy & Unrestricted Screenshots

## What's New in v2.8.0+134
1. **Strict Fail-Closed E2EE & Key-Change Send Lock:**
   - Plaintext send fallback is permanently disabled for both messages and media uploads.
   - If a peer's identity key changes (`E2eeStatus.keyChanged`), sending pauses automatically until you compare fingerprints and verify or accept the new key.
2. **Pure-Dart Signal-Style Double Ratchet (`lib/security/double_ratchet.dart`):**
   - Ephemeral X25519 Diffie-Hellman ratchet + HKDF-SHA256 root KDF + HMAC-SHA256 symmetric chain ratchet + AES-256-GCM AEAD with header AAD.
   - Zero native/Rust dependencies (compact ARM64 APK and lightweight on 3 GB Android 11 phones).
   - Handles out-of-order delivery (bounded skipped-key store), simultaneous crossing first messages, cross-isolate sync (background inline replies), and preserves older `v1`/legacy history on read.
3. **Forward-Secret Encrypted Media & Encrypted Media Metadata:**
   - Every uploaded photo, video, voice note, document, and thumbnail is encrypted with a unique 256-bit per-file key (`mk`), and the media metadata JSON itself is Double-Ratchet encrypted in `messages`.
   - Updated the **Files** tab to decrypt encrypted media metadata seamlessly alongside older media.
4. **Screenshots Enabled Everywhere (Including Hidden Chats):**
   - Removed `FLAG_SECURE` window blocking across the entire app so you can take screenshots anywhere — including when hidden chats exist and inside hidden chats — while keeping hidden-chat password/biometric lock and notification redaction active.
