part of '../main.dart';

class FilesPage extends StatefulWidget {
  const FilesPage({
    required this.store,
    required this.isActive,
    this.allowHiddenConversationMedia = false,
    super.key,
  });
  final AttachmentVaultStore store;
  final bool isActive;
  final bool allowHiddenConversationMedia;
  @override
  State<FilesPage> createState() => _FilesPageState();
}

class _FilesPageState extends State<FilesPage> {
  List<LocalAttachment> _localItems = const <LocalAttachment>[];
  List<Map<String, dynamic>> _sharedItems = const <Map<String, dynamic>>[];
  bool _hasLoadedOnce = false;
  bool _loading = false;
  bool importing = false;
  DateTime? _lastLoadedAt;

  static const Set<String> _imageExts = <String>{'.jpg', '.jpeg', '.png', '.webp', '.gif'};
  static const Set<String> _videoExts = <String>{'.mp4', '.mov', '.webm', '.mkv', '.3gp'};
  static const Set<String> _audioExts = <String>{'.m4a', '.mp3', '.wav', '.aac', '.ogg', '.opus', '.flac'};

  @override
  void initState() {
    super.initState();
    unawaited(_loadData(force: true));
  }

  @override
  void didUpdateWidget(covariant FilesPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isActive && !oldWidget.isActive) {
      final stale = _lastLoadedAt == null ||
          DateTime.now().difference(_lastLoadedAt!) > const Duration(seconds: 45);
      if (!_hasLoadedOnce || stale) {
        unawaited(_loadData(force: false));
      }
    }
  }

  String _sharedFingerprint(List<Map<String, dynamic>> list) =>
      list.map((e) => '${e['path'] ?? ''}:${e['created_at'] ?? ''}').join('|');

  String _localFingerprint(List<LocalAttachment> list) =>
      list.map((e) => '${e.path}:${e.sizeBytes}').join('|');

  Future<void> _loadData({required bool force}) async {
    if (_loading) return;
    _loading = true;
    if (!_hasLoadedOnce && mounted) setState(() {});
    try {
      final results = await Future.wait<Object>(<Future<Object>>[
        widget.store.list(),
        _loadSharedFiles(),
      ]);
      if (!mounted) return;
      final nextLocal = results[0] as List<LocalAttachment>;
      final nextShared = results[1] as List<Map<String, dynamic>>;
      _lastLoadedAt = DateTime.now();
      final changed = !_hasLoadedOnce ||
          force ||
          _localFingerprint(nextLocal) != _localFingerprint(_localItems) ||
          _sharedFingerprint(nextShared) != _sharedFingerprint(_sharedItems);
      _hasLoadedOnce = true;
      if (changed) {
        setState(() {
          _localItems = List<LocalAttachment>.unmodifiable(nextLocal);
          _sharedItems = List<Map<String, dynamic>>.unmodifiable(nextShared);
        });
      }
    } catch (error) {
      debugPrint('Files refresh failed: $error');
      if (!_hasLoadedOnce && mounted) {
        setState(() => _hasLoadedOnce = true);
      }
    } finally {
      _loading = false;
    }
  }

  Future<List<Map<String, dynamic>>> _loadSharedFiles() async {
    final client = Supabase.instance.client;
    final uid = client.auth.currentUser?.id;
    if (uid == null) return [];
    // This app currently has one active peer. Hide that peer's shared media
    // from the Files gallery while the conversation is hidden, so the gallery
    // cannot become a side door around the chat password.
    try {
      final hiddenIds = await HiddenChatVault().listHiddenChatIds(uid);
      final activePeerId = await RealtimeMessagingService(client).getPeerId();
      if (activePeerId != null &&
          hiddenIds.contains(activePeerId) &&
          !widget.allowHiddenConversationMedia) {
        return <Map<String, dynamic>>[];
      }
    } catch (error) {
      debugPrint('Hidden-chat media access could not be verified: $error');
      return <Map<String, dynamic>>[]; // Fail closed.
    }
    final hiddenIds = <String>{};
    final postClearVisibleIds = <String>{};
    int? clearedBeforeMs;
    String? peerId;
    try {
      peerId = await RealtimeMessagingService(client).getPeerId();
      if (peerId != null) {
        final rawState = await const FlutterSecureStorage().read(
          key: 'likedin_local_chat_v1_${uid}_$peerId',
        );
        if (rawState != null && rawState.isNotEmpty) {
          final data = Map<String, dynamic>.from(jsonDecode(rawState) as Map);
          hiddenIds.addAll((data['hidden'] as List? ?? const []).map((e) => e.toString()));
          postClearVisibleIds.addAll((data['postClearVisible'] as List? ?? const []).map((e) => e.toString()));
          clearedBeforeMs = data['clearedBeforeMs'] as int?;
        }
      }
    } catch (_) {}

    if (peerId != null && !E2eeService.instance.isActive) {
      try {
        await E2eeService.instance.initialize(client, userId: uid, peerId: peerId);
      } catch (_) {}
    }

    // Load recent conversation messages and decrypt via E2eeService (handles
    // v2 Double-Ratchet-encrypted media metadata JSON AND legacy plaintext JSON).
    final messaging = RealtimeMessagingService(client);
    final rawMessages = await messaging.loadAllConversation(
      pageSize: 200,
      maxMessages: 2000,
    );
    final decryptedMessages = await E2eeService.instance.decryptMessages(rawMessages);
    final mediaService = SharedMediaService(client);
    final result = <Map<String, dynamic>>[];

    for (final message in decryptedMessages.reversed) {
      if (message.deletedForEveryoneAt != null) continue;
      final rowId = message.id;
      final clientMessageId = message.clientMessageId;
      if (hiddenIds.contains(rowId) ||
          (clientMessageId != null && hiddenIds.contains(clientMessageId))) {
        continue;
      }
      final isPostClearException = postClearVisibleIds.contains(rowId) ||
          (clientMessageId != null && postClearVisibleIds.contains(clientMessageId));
      if (!isPostClearException &&
          clearedBeforeMs != null &&
          message.createdAt.millisecondsSinceEpoch <= clearedBeforeMs) {
        continue;
      }
      final payload = mediaService.decode(message.text);
      if (payload != null) {
        result.add({
          ...payload,
          'created_at': message.createdAt.toUtc().toIso8601String(),
          'sender_id': message.senderId,
        });
      }
    }
    return result;
  }

  Future<void> _openShared(Map<String, dynamic> payload) async {
    final kind = payload['kind']?.toString() ?? 'file';
    final title = payload['name']?.toString() ?? 'Attachment';
    if (kind == 'audio') {
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: Text(title),
          content: _VoiceMessagePlayer(payload: payload),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Close'),
            ),
          ],
        ),
      );
      return;
    }
    if (kind != 'image' && kind != 'video') {
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Save shared document?'),
          content: Text('Save $title to the Downloads folder on this phone?'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Save')),
          ],
        ),
      );
      if (confirmed == true) await _saveShared(payload);
      return;
    }
    try {
      final file = await SharedMediaService(Supabase.instance.client).cachedFile(payload);
      if (!mounted) return;
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => kind == 'image'
              ? _LikedinImageViewer(file: file, title: title, payload: payload)
              : _LikedinVideoViewer(file: file, title: title, payload: payload),
        ),
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not open this attachment. Please try again.')),
        );
      }
    }
  }

  Future<void> _openLocal(LocalAttachment attachment) async {
    final file = File(attachment.path);
    if (!await file.exists()) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('This local file is no longer available.')),
        );
      }
      return;
    }
    final ext = p.extension(attachment.name).toLowerCase();
    if (['.jpg', '.jpeg', '.png', '.webp', '.gif'].contains(ext)) {
      if (!mounted) return;
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => _LikedinImageViewer(file: file, title: attachment.name),
        ),
      );
      return;
    }
    if (['.mp4', '.mov', '.webm', '.mkv', '.3gp'].contains(ext)) {
      if (!mounted) return;
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => _LikedinVideoViewer(file: file, title: attachment.name),
        ),
      );
      return;
    }
    try {
      await const MethodChannel('com.example.likedin/downloads').invokeMethod<bool>('openLocalFile', {
        'sourcePath': file.path,
        'displayName': attachment.name,
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No compatible app could open this file.')),
        );
      }
    }
  }

  Future<void> _saveShared(Map<String, dynamic> payload) async {
    try {
      final saved =
          await SharedMediaService(Supabase.instance.client).downloadToPublicDownloads(payload);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Saved $saved to Downloads.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Download failed. Check your connection and storage, then try again.')),
        );
      }
    }
  }

  Future<void> importFiles() async {
    setState(() => importing = true);
    try {
      final saved = await widget.store.importFiles();
      if (!mounted) return;
      await _loadData(force: true);
      if (saved.isNotEmpty && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${saved.length} file(s) copied into Likedin Downloads.')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not import those files.')),
        );
      }
    } finally {
      if (mounted) setState(() => importing = false);
    }
  }

  Future<void> deleteLocal(LocalAttachment file) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete downloaded copy?'),
        content: Text(
          'This deletes ${file.name} from this phone only. It does not delete any copy on another device or in cloud storage.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete from phone'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await widget.store.deleteLocal(file);
    if (mounted) await _loadData(force: true);
  }

  String _formatSharedSubtitle(BuildContext context, Map<String, dynamic> item, String fallbackKind) {
    final size = (item['size'] as num?)?.toInt() ?? 0;
    final sizeStr = size >= 1048576
        ? '${(size / 1048576).toStringAsFixed(1)} MB'
        : size > 0
            ? '${(size / 1024).toStringAsFixed(0)} KB'
            : fallbackKind;
    final when = DateTime.tryParse(item['created_at']?.toString() ?? '')?.toLocal();
    if (when == null) return sizeStr;
    final loc = MaterialLocalizations.of(context);
    return '$sizeStr · ${loc.formatMediumDate(when)} · ${loc.formatTimeOfDay(TimeOfDay.fromDateTime(when))}';
  }

  Widget _emptyTabState(BuildContext context, IconData icon, String title, String subtitle) => Center(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(28, 48, 28, 120),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  color: brandBlue.withValues(alpha: .12),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, size: 28, color: brandBlue),
              ),
              const SizedBox(height: 14),
              Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text(
                subtitle,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: Theme.of(context).hintColor, height: 1.35),
              ),
            ],
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final localItems = _localItems;
    final shared = _sharedItems;
    final totalLocalBytes = localItems.fold<int>(0, (sum, item) => sum + item.sizeBytes);
    final initialLoading = !_hasLoadedOnce && _loading;

    final sharedMedia = shared.where((item) {
      final kind = item['kind']?.toString() ?? 'file';
      return kind == 'image' || kind == 'video';
    }).toList(growable: false);
    final sharedAudio = shared.where((item) {
      final kind = item['kind']?.toString() ?? 'file';
      return kind == 'audio';
    }).toList(growable: false);
    final sharedDocs = shared.where((item) {
      final kind = item['kind']?.toString() ?? 'file';
      return kind != 'image' && kind != 'video' && kind != 'audio';
    }).toList(growable: false);

    final localMedia = localItems.where((f) {
      final ext = p.extension(f.name).toLowerCase();
      return _imageExts.contains(ext) || _videoExts.contains(ext);
    }).toList(growable: false);
    final localAudio = localItems.where((f) {
      final ext = p.extension(f.name).toLowerCase();
      return _audioExts.contains(ext);
    }).toList(growable: false);
    final localDocs = localItems.where((f) {
      final ext = p.extension(f.name).toLowerCase();
      return !_imageExts.contains(ext) && !_videoExts.contains(ext) && !_audioExts.contains(ext);
    }).toList(growable: false);

    final mediaCount = sharedMedia.length + localMedia.length;
    final audioCount = sharedAudio.length + localAudio.length;
    final docsCount = sharedDocs.length + localDocs.length;

    return DefaultTabController(
      length: 3,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 10, 12, 10),
            child: Row(
              children: [
                const Expanded(
                  child: Text(
                    'Files',
                    style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, letterSpacing: -1.1),
                  ),
                ),
                IconButton(
                  tooltip: 'Save files to this phone',
                  onPressed: importing ? null : importFiles,
                  icon: importing
                      ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.add_circle_outline_rounded),
                ),
                IconButton(
                  tooltip: 'Refresh',
                  onPressed: () => unawaited(_loadData(force: true)),
                  icon: const Icon(Icons.refresh_rounded),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: GlassPanel(
              radius: BorderRadius.circular(20),
              padding: const EdgeInsets.all(4),
              blur: 6,
              glow: false,
              child: TabBar(
                dividerColor: Colors.transparent,
                indicatorSize: TabBarIndicatorSize.tab,
                labelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800),
                unselectedLabelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                tabs: [
                  Tab(text: mediaCount > 0 ? 'Media ($mediaCount)' : 'Media'),
                  Tab(text: audioCount > 0 ? 'Audio ($audioCount)' : 'Audio'),
                  Tab(text: docsCount > 0 ? 'Docs ($docsCount)' : 'Docs'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: TabBarView(
              children: [
                // 1. MEDIA PAGE (True lazy virtualized SliverGrid — zero eager decode jank!)
                _KeepAliveTab(
                  child: RefreshIndicator(
                    onRefresh: () => _loadData(force: true),
                    child: initialLoading
                        ? const Center(child: CircularProgressIndicator())
                        : (sharedMedia.isEmpty && localMedia.isEmpty)
                            ? ListView(
                                key: const PageStorageKey<String>('files-media-empty'),
                                physics: const AlwaysScrollableScrollPhysics(),
                                children: [
                                  _emptyTabState(
                                    context,
                                    Icons.photo_library_outlined,
                                    'No media yet',
                                    'Photos, GIFs and videos shared in chat will appear here as thumbnails.',
                                  ),
                                ],
                              )
                            : CustomScrollView(
                                key: const PageStorageKey<String>('files-media-grid'),
                                physics: const AlwaysScrollableScrollPhysics(),
                                slivers: [
                                  if (sharedMedia.isNotEmpty)
                                    SliverPadding(
                                      padding: const EdgeInsets.fromLTRB(20, 4, 20, 12),
                                      sliver: SliverGrid(
                                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                          crossAxisCount: 3,
                                          crossAxisSpacing: 8,
                                          mainAxisSpacing: 8,
                                        ),
                                        delegate: SliverChildBuilderDelegate(
                                          (context, idx) {
                                            final item = sharedMedia[idx];
                                            return RepaintBoundary(
                                              child: _FilesMediaThumbnailTile(
                                                key: ValueKey('files-shared-${item['path'] ?? idx}'),
                                                payload: item,
                                                onTap: () => _openShared(item),
                                                onSave: () => _saveShared(item),
                                              ),
                                            );
                                          },
                                          childCount: sharedMedia.length,
                                        ),
                                      ),
                                    ),
                                  if (localMedia.isNotEmpty) ...[
                                    SliverPadding(
                                      padding: const EdgeInsets.fromLTRB(20, 8, 20, 10),
                                      sliver: SliverToBoxAdapter(
                                        child: Text(
                                          'Saved on this phone',
                                          style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w800,
                                            color: likedinMutedText(brightness),
                                          ),
                                        ),
                                      ),
                                    ),
                                    SliverPadding(
                                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
                                      sliver: SliverGrid(
                                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                          crossAxisCount: 3,
                                          crossAxisSpacing: 8,
                                          mainAxisSpacing: 8,
                                        ),
                                        delegate: SliverChildBuilderDelegate(
                                          (context, idx) {
                                            final f = localMedia[idx];
                                            final ext = p.extension(f.name).toLowerCase();
                                            final isVid = _videoExts.contains(ext);
                                            final isGif = ext == '.gif';
                                            return RepaintBoundary(
                                              child: GestureDetector(
                                                onTap: () => _openLocal(f),
                                                onLongPress: () => deleteLocal(f),
                                                child: ClipRRect(
                                                  borderRadius: BorderRadius.circular(14),
                                                  child: Stack(
                                                    fit: StackFit.expand,
                                                    children: [
                                                      if (!isVid)
                                                        Image.file(
                                                          File(f.path),
                                                          fit: BoxFit.cover,
                                                          cacheWidth: 220,
                                                          filterQuality: FilterQuality.low,
                                                          gaplessPlayback: true,
                                                          errorBuilder: (_, __, ___) => ColoredBox(
                                                            color: Theme.of(context).colorScheme.surfaceContainerHighest,
                                                            child: const Icon(Icons.broken_image_outlined),
                                                          ),
                                                        )
                                                      else
                                                        Container(
                                                          decoration: const BoxDecoration(
                                                            gradient: LinearGradient(
                                                              begin: Alignment.topLeft,
                                                              end: Alignment.bottomRight,
                                                              colors: [Color(0xFF172B4D), Color(0xFF0A192F)],
                                                            ),
                                                          ),
                                                          child: const Center(
                                                            child: Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 34),
                                                          ),
                                                        ),
                                                      if (isGif)
                                                        Positioned(
                                                          left: 6,
                                                          top: 6,
                                                          child: Container(
                                                            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                                                            decoration: BoxDecoration(
                                                              color: Colors.black.withValues(alpha: .62),
                                                              borderRadius: BorderRadius.circular(6),
                                                            ),
                                                            child: const Text(
                                                              'GIF',
                                                              style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w800),
                                                            ),
                                                          ),
                                                        ),
                                                      Positioned(
                                                        right: 4,
                                                        top: 4,
                                                        child: GestureDetector(
                                                          onTap: () => deleteLocal(f),
                                                          child: Container(
                                                            padding: const EdgeInsets.all(4),
                                                            decoration: BoxDecoration(
                                                              color: Colors.black.withValues(alpha: .54),
                                                              shape: BoxShape.circle,
                                                            ),
                                                            child: const Icon(Icons.delete_outline, color: Colors.white, size: 14),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            );
                                          },
                                          childCount: localMedia.length,
                                        ),
                                      ),
                                    ),
                                  ],
                                  const SliverToBoxAdapter(child: SizedBox(height: 112)),
                                ],
                              ),
                  ),
                ),
                // 2. AUDIO PAGE (Voice notes & music files)
                _KeepAliveTab(
                  child: RefreshIndicator(
                    onRefresh: () => _loadData(force: true),
                    child: initialLoading
                        ? const Center(child: CircularProgressIndicator())
                        : (sharedAudio.isEmpty && localAudio.isEmpty)
                            ? ListView(
                                key: const PageStorageKey<String>('files-audio-empty'),
                                physics: const AlwaysScrollableScrollPhysics(),
                                children: [
                                  _emptyTabState(
                                    context,
                                    Icons.graphic_eq_rounded,
                                    'No audio yet',
                                    'Voice messages and shared audio tracks will appear here for quick playback.',
                                  ),
                                ],
                              )
                            : ListView(
                                key: const PageStorageKey<String>('files-audio-list'),
                                physics: const AlwaysScrollableScrollPhysics(),
                                padding: const EdgeInsets.fromLTRB(20, 4, 20, 118),
                                children: [
                                  ...sharedAudio.map((item) {
                                    final name = item['name']?.toString() ?? 'Voice message';
                                    return Padding(
                                      padding: const EdgeInsets.only(bottom: 8),
                                      child: GlassPanel(
                                        padding: EdgeInsets.zero,
                                        radius: BorderRadius.circular(20),
                                        blur: 5,
                                        glow: false,
                                        child: ListTile(
                                          onTap: () => _openShared(item),
                                          leading: CircleAvatar(
                                            backgroundColor: brandBlue.withValues(alpha: .14),
                                            child: Icon(Icons.mic_rounded, color: brandBlue, size: 20),
                                          ),
                                          title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                                          subtitle: Text(_formatSharedSubtitle(context, item, 'Audio'), style: const TextStyle(fontSize: 12)),
                                          trailing: IconButton(
                                            tooltip: 'Save to Downloads',
                                            onPressed: () => _saveShared(item),
                                            icon: const Icon(Icons.download_outlined),
                                          ),
                                        ),
                                      ),
                                    );
                                  }),
                                  if (localAudio.isNotEmpty) ...[
                                    if (sharedAudio.isNotEmpty) const SizedBox(height: 12),
                                    Text(
                                      'Saved on this phone',
                                      style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w800,
                                        color: likedinMutedText(brightness),
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    ...localAudio.map((file) => Padding(
                                          padding: const EdgeInsets.only(bottom: 8),
                                          child: GlassPanel(
                                            padding: EdgeInsets.zero,
                                            radius: BorderRadius.circular(20),
                                            blur: 5,
                                            glow: false,
                                            child: ListTile(
                                              onTap: () => _openLocal(file),
                                              leading: CircleAvatar(
                                                backgroundColor: brandBlue.withValues(alpha: .14),
                                                child: Icon(Icons.audiotrack_rounded, color: brandBlue, size: 20),
                                              ),
                                              title: Text(file.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                                              subtitle: Text('${file.readableSize} · saved on this phone', style: const TextStyle(fontSize: 12)),
                                              trailing: IconButton(
                                                tooltip: 'Delete local copy',
                                                onPressed: () => deleteLocal(file),
                                                icon: const Icon(Icons.delete_outline, color: Color(0xFFB42318)),
                                              ),
                                            ),
                                          ),
                                        )),
                                  ],
                                ],
                              ),
                  ),
                ),
                // 3. DOCS PAGE (Shared documents + phone vault)
                _KeepAliveTab(
                  child: RefreshIndicator(
                    onRefresh: () => _loadData(force: true),
                    child: initialLoading
                        ? const Center(child: CircularProgressIndicator())
                        : ListView(
                            key: const PageStorageKey<String>('files-docs-list'),
                            physics: const AlwaysScrollableScrollPhysics(),
                            padding: const EdgeInsets.fromLTRB(20, 4, 20, 118),
                            children: [
                              if (sharedDocs.isEmpty && localDocs.isEmpty)
                                _emptyTabState(
                                  context,
                                  Icons.description_outlined,
                                  'No documents yet',
                                  'Shared PDFs, archives and saved phone documents will appear here.',
                                ),
                              ...sharedDocs.map((item) {
                                final name = item['name']?.toString() ?? 'Document';
                                return Padding(
                                  padding: const EdgeInsets.only(bottom: 8),
                                  child: GlassPanel(
                                    padding: EdgeInsets.zero,
                                    radius: BorderRadius.circular(20),
                                    blur: 5,
                                    glow: false,
                                    child: ListTile(
                                      onTap: () => _openShared(item),
                                      leading: CircleAvatar(
                                        backgroundColor: brandBlue.withValues(alpha: .14),
                                        child: Icon(Icons.insert_drive_file_outlined, color: brandBlue, size: 20),
                                      ),
                                      title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                                      subtitle: Text(_formatSharedSubtitle(context, item, 'Document'), style: const TextStyle(fontSize: 12)),
                                      trailing: IconButton(
                                        tooltip: 'Save to Downloads',
                                        onPressed: () => _saveShared(item),
                                        icon: const Icon(Icons.download_outlined),
                                      ),
                                    ),
                                  ),
                                );
                              }),
                              if (localDocs.isNotEmpty) ...[
                                if (sharedDocs.isNotEmpty) const SizedBox(height: 12),
                                Text(
                                  'Saved on this phone (${(totalLocalBytes / (1024 * 1024)).toStringAsFixed(1)} MB total)',
                                  style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w800,
                                    color: likedinMutedText(brightness),
                                  ),
                                ),
                                const SizedBox(height: 8),
                                ...localDocs.map((file) => Padding(
                                      padding: const EdgeInsets.only(bottom: 8),
                                      child: GlassPanel(
                                        padding: EdgeInsets.zero,
                                        radius: BorderRadius.circular(20),
                                        blur: 5,
                                        glow: false,
                                        child: ListTile(
                                          onTap: () => _openLocal(file),
                                          leading: CircleAvatar(
                                            backgroundColor: brandBlue.withValues(alpha: .14),
                                            child: Icon(Icons.description_outlined, color: brandBlue, size: 20),
                                          ),
                                          title: Text(file.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                                          subtitle: Text('${file.readableSize} · saved on this phone', style: const TextStyle(fontSize: 12)),
                                          trailing: IconButton(
                                            tooltip: 'Delete local copy',
                                            onPressed: () => deleteLocal(file),
                                            icon: const Icon(Icons.delete_outline, color: Color(0xFFB42318)),
                                          ),
                                        ),
                                      ),
                                    )),
                              ],
                              const SizedBox(height: 10),
                              SizedBox(
                                width: double.infinity,
                                child: OutlinedButton.icon(
                                  onPressed: importing ? null : importFiles,
                                  icon: const Icon(Icons.download_outlined, size: 18),
                                  label: Text(importing ? 'Saving…' : 'Save files to this phone'),
                                ),
                              ),
                            ],
                          ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _KeepAliveTab extends StatefulWidget {
  const _KeepAliveTab({required this.child});
  final Widget child;

  @override
  State<_KeepAliveTab> createState() => _KeepAliveTabState();
}

class _KeepAliveTabState extends State<_KeepAliveTab>
    with AutomaticKeepAliveClientMixin<_KeepAliveTab> {
  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return widget.child;
  }
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({
    required this.attachmentVault,
    super.key,
  });
  final AttachmentVaultStore attachmentVault;
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> with WidgetsBindingObserver {
  bool _testingNotification = false;
  bool _checkingUpdates = false;
  bool _biometricAvailable = false;
  bool _biometricEnabled = true;
  bool _e2eeBusy = false;

  Future<void> _checkForUpdates() async {
    if (_checkingUpdates) return;
    setState(() => _checkingUpdates = true);
    try {
      await AppUpdater.checkAndPrompt(
        context,
        currentVersion: likedinVersion,
        manual: true,
      );
    } finally {
      if (mounted) setState(() => _checkingUpdates = false);
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refreshNotificationStatus();
    unawaited(_loadSecurityControls());
  }

  Future<void> _loadSecurityControls() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final enabled = prefs.getBool(likedinHiddenBiometricPrefKey) ?? true;
      final available = await _hiddenChatSecurityChannel
          .invokeMethod<bool>('canAuthenticateBiometric') ?? false;
      final client = Supabase.instance.client;
      final uid = client.auth.currentUser?.id;
      if (uid != null && !E2eeService.instance.isActive) {
        final peer = await RealtimeMessagingService(client).getPeerId();
        if (peer != null) {
          await E2eeService.instance.initialize(client, userId: uid, peerId: peer);
        }
      }
      if (mounted) {
        setState(() {
          _biometricAvailable = available;
          _biometricEnabled = enabled;
        });
      }
    } catch (_) {}
  }

  Future<void> _setBiometricEnabled(bool value) async {
    setState(() => _biometricEnabled = value);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(likedinHiddenBiometricPrefKey, value);
    } catch (_) {}
  }

  Future<void> _runE2eePassphraseFlow({required bool restore}) async {
    if (_e2eeBusy) return;
    final passController = TextEditingController();
    final confirmController = TextEditingController();
    String? validationError;
    final passphrase = await showDialog<String>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, updateDialog) => AlertDialog(
          title: Text(restore ? 'Restore E2EE key' : 'Back up E2EE key'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                restore
                    ? 'Enter your recovery passphrase to restore your private E2EE key and unlock encrypted history on this phone.'
                    : 'Your private key is encrypted on this phone with your passphrase before saving to Supabase so you can recover encrypted messages if you switch phones.',
                style: const TextStyle(fontSize: 12, height: 1.35),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: passController,
                obscureText: true,
                textInputAction: restore ? TextInputAction.done : TextInputAction.next,
                decoration: const InputDecoration(
                  labelText: 'Recovery passphrase (12+ characters)',
                ),
              ),
              if (!restore) ...[
                const SizedBox(height: 10),
                TextField(
                  controller: confirmController,
                  obscureText: true,
                  textInputAction: TextInputAction.done,
                  decoration: const InputDecoration(labelText: 'Confirm recovery passphrase'),
                ),
              ],
              if (validationError != null) ...[
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    validationError!,
                    style: TextStyle(color: Theme.of(context).colorScheme.error, fontSize: 12),
                  ),
                ),
              ],
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
            FilledButton(
              onPressed: () {
                final value = passController.text;
                if (value.length < 12) {
                  updateDialog(() => validationError = 'Use at least 12 characters.');
                  return;
                }
                if (!restore && value != confirmController.text) {
                  updateDialog(() => validationError = 'The passphrases do not match.');
                  return;
                }
                Navigator.pop(dialogContext, value);
              },
              child: Text(restore ? 'Restore' : 'Back up'),
            ),
          ],
        ),
      ),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      passController.dispose();
      confirmController.dispose();
    });
    if (passphrase == null || !mounted) return;
    setState(() => _e2eeBusy = true);
    final messenger = ScaffoldMessenger.of(context);
    try {
      if (restore) {
        await E2eeService.instance.restoreKeyWithPassphrase(Supabase.instance.client, passphrase);
        if (mounted) {
          messenger.showSnackBar(
            const SnackBar(content: Text('E2EE key restored! Encrypted messages are now readable.')),
          );
        }
      } else {
        await E2eeService.instance.backupKeyWithPassphrase(Supabase.instance.client, passphrase);
        if (mounted) {
          messenger.showSnackBar(
            const SnackBar(content: Text('Encrypted E2EE key backup saved to your account.')),
          );
        }
      }
    } catch (error) {
      if (mounted) {
        final msg = error is StateError
            ? error.message.toString()
            : 'Could not complete E2EE key ${restore ? 'restore' : 'backup'}. Make sure the likedin_e2ee_keys table is created in Supabase.';
        messenger.showSnackBar(SnackBar(content: Text(msg)));
      }
    } finally {
      if (mounted) setState(() => _e2eeBusy = false);
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _refreshNotificationStatus();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> _refreshNotificationStatus() async {
    await LikedinNotificationService.instance.registerCurrentToken();
    await LikedinNotificationService.instance.refreshNotificationPermissionStatus();
    if (mounted) setState(() {});
  }

  Future<void> _sendNotificationTest() async {
    if (_testingNotification) return;
    setState(() => _testingNotification = true);
    final result = await LikedinNotificationService.instance.showTestNotification();
    if (!mounted) return;
    setState(() => _testingNotification = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(result.message), duration: const Duration(seconds: 7)),
    );
    await _refreshNotificationStatus();
  }

  Future<void> _setDark(bool value) async {
    await setLikedinDarkMode(value);
    if (mounted) setState(() {});
  }

  Future<void> _exportEncryptedBackup() async {
    // Backup export is another route to the conversation contents, so it must
    // honor the hidden-chat password gate as well.
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (uid != null) {
      final hiddenVault = HiddenChatVault();
      if (await hiddenVault.hasHiddenChats(uid)) {
        if (!mounted) return;
        final hiddenPassword = await HiddenChatPinDialog.show(context, setup: false);
        if (!mounted || hiddenPassword == null) return;
        if (hiddenPassword.requestRecovery) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Reset the hidden-chats password from the Hidden chats section on Home, then retry the backup.')),
          );
          return;
        }
        final valid = hiddenPassword.password != null &&
            await hiddenVault.verifyPassword(uid, hiddenPassword.password!);
        if (!mounted) return;
        if (!valid) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Incorrect hidden-chats password. Backup was not created.')),
          );
          return;
        }
      }
    }
    if (!mounted) return;
    final passController = TextEditingController();
    final confirmController = TextEditingController();
    String? validationError;
    final passphrase = await showDialog<String>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, updateDialog) => AlertDialog(
          title: const Text('Encrypt chat backup'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: passController,
                obscureText: true,
                autofillHints: const [AutofillHints.newPassword],
                textInputAction: TextInputAction.next,
                decoration: const InputDecoration(
                  labelText: 'Passphrase (12+ characters)',
                  hintText: 'Enter a strong passphrase',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: confirmController,
                obscureText: true,
                textInputAction: TextInputAction.done,
                decoration: const InputDecoration(labelText: 'Confirm passphrase'),
              ),
              if (validationError != null) ...[
                const SizedBox(height: 8),
                Align(alignment: Alignment.centerLeft, child: Text(validationError!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
              ],
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
            FilledButton(
              onPressed: () {
                final value = passController.text;
                if (value.length < 12) {
                  updateDialog(() => validationError = 'Use at least 12 characters.');
                  return;
                }
                if (value != confirmController.text) {
                  updateDialog(() => validationError = 'The passphrases do not match.');
                  return;
                }
                Navigator.pop(dialogContext, value);
              },
              child: const Text('Export'),
            ),
          ],
        ),
      ),
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      passController.dispose();
      confirmController.dispose();
    });
    if (passphrase == null || !mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    try {
      final service = RealtimeMessagingService(Supabase.instance.client);
      final uid = service.currentUserId;
      final peerId = await service.getPeerId();
      if (peerId != null && !E2eeService.instance.isActive) {
        try {
          await E2eeService.instance.initialize(
            Supabase.instance.client,
            userId: uid,
            peerId: peerId,
          );
        } catch (_) {}
      }
      final allMessages = await E2eeService.instance.decryptMessages(
        await service.loadAllConversation(),
      );
      final hiddenIds = <String>{};
      final postClearVisibleIds = <String>{};
      int? clearedBeforeMs;
      if (peerId != null) {
        try {
          final rawState = await const FlutterSecureStorage().read(
            key: 'likedin_local_chat_v1_${uid}_$peerId',
          );
          if (rawState != null && rawState.isNotEmpty) {
            final localState = Map<String, dynamic>.from(jsonDecode(rawState) as Map);
            hiddenIds.addAll((localState['hidden'] as List? ?? const []).map((value) => value.toString()));
            postClearVisibleIds.addAll((localState['postClearVisible'] as List? ?? const []).map((value) => value.toString()));
            clearedBeforeMs = localState['clearedBeforeMs'] as int?;
          }
        } catch (error) {
          debugPrint('Local chat visibility could not be read for backup: $error');
        }
      }
      final completeConversation = ChatInfoMetrics.visibleMessages(
        allMessages,
        hiddenMessageIds: hiddenIds,
        clearedBeforeMs: clearedBeforeMs,
        postClearVisibleMessageIds: postClearVisibleIds,
      );
      final payload = jsonEncode({
        'format': 'project-whisper-backup',
        'version': 1,
        'createdAt': DateTime.now().toUtc().toIso8601String(),
        'messages': completeConversation
            .map((m) => {
                  'id': m.id,
                  'senderId': m.senderId,
                  'recipientId': m.recipientId,
                  'text': m.text,
                  'createdAt': m.createdAt.toUtc().toIso8601String(),
                })
            .toList(),
      });
      final encrypted = await EncryptedBackupCodec().encrypt(payload, passphrase);
      final tempDir = await getTemporaryDirectory();
      final stamp = DateTime.now().millisecondsSinceEpoch;
      final fileName = 'likedin_backup_$stamp.json';
      final tempFile = File(p.join(tempDir.path, fileName));
      await tempFile.writeAsBytes(encrypted, flush: true);
      try {
        final saved = await const MethodChannel('com.example.likedin/downloads')
                .invokeMethod<String>('saveToDownloads', {
              'sourcePath': tempFile.path,
              'displayName': fileName,
              'mimeType': 'application/json',
            }) ??
            fileName;
        if (!mounted) return;
        messenger.showSnackBar(
          SnackBar(content: Text('Encrypted backup saved to Downloads as $saved. ${completeConversation.length} messages included.')),
        );
      } finally {
        if (await tempFile.exists()) await tempFile.delete();
      }
    } catch (error) {
      debugPrint('Encrypted backup export failed: $error');
      if (!mounted) return;
      messenger.showSnackBar(
        const SnackBar(content: Text('Could not export backup. Check your connection and available storage, then try again.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 118),
        children: [
          const Text(
            'Settings',
            style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, letterSpacing: -1.1),
          ),
          const SizedBox(height: 18),
          const _SettingsHeading('Appearance and themes'),
          GlassPanel(
            padding: EdgeInsets.zero,
            radius: BorderRadius.circular(20),
            child: Column(
              children: [
                ValueListenableBuilder<ThemeMode>(
                  valueListenable: likedinThemeMode,
                  builder: (context, mode, _) => SwitchListTile.adaptive(
                    value: mode == ThemeMode.dark,
                    onChanged: _setDark,
                    secondary: Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: const Color(0xFF4C8BF5).withValues(alpha: .15),
                        borderRadius: BorderRadius.circular(11),
                      ),
                      child: Icon(
                        mode == ThemeMode.dark ? Icons.dark_mode_outlined : Icons.light_mode_outlined,
                        color: const Color(0xFF4C8BF5),
                        size: 19,
                      ),
                    ),
                    title: Text(mode == ThemeMode.dark ? 'Dark Glass' : 'Light Glass'),
                    subtitle: Text(
                      'OriginOS 7 · ${LikedinAppearance.theme.name} · ${LikedinAppearance.textureLabel} glass',
                    ),
                  ),
                ),
                Divider(height: 1, indent: 62, endIndent: 14, color: likedinOutline(Theme.of(context).brightness)),
                _SettingsNavTile(
                  icon: Icons.palette_outlined,
                  badgeColor: const Color(0xFF9B6BFF),
                  title: 'OriginOS 7 Appearance',
                  subtitle: 'Themes, glass texture (Real / Natural / Soft), Glint & motion',
                  onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
                    builder: (_) => ThemeCustomizationPage(
                      themeMode: likedinThemeMode,
                      onSetDark: setLikedinDarkMode,
                    ),
                  )),
                ),

              ],
            ),
          ),
          const SizedBox(height: 26),
          const _SettingsHeading('Notifications'),
          GlassPanel(
            padding: const EdgeInsets.all(14),
            radius: BorderRadius.circular(20),
            blur: 5,
            glow: false,
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 34,
                        height: 34,
                        decoration: BoxDecoration(
                          color: const Color(0xFFF59E0B).withValues(alpha: .15),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.notifications_active_outlined, color: Color(0xFFF59E0B), size: 19),
                      ),
                      const SizedBox(width: 10),
                      const Text('Notifications', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Android app permission: ${LikedinNotificationService.instance.notificationsAllowed == null ? 'Unknown' : LikedinNotificationService.instance.notificationsAllowed! ? 'Allowed' : 'Blocked'}',
                  ),
                  if (LikedinNotificationService.instance.notificationsAllowed == false) ...[
                    const SizedBox(height: 4),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: TextButton.icon(
                        onPressed: () async {
                          await openAppSettings();
                          await _refreshNotificationStatus();
                        },
                        icon: const Icon(Icons.settings_outlined),
                        label: const Text('Open Android notification settings'),
                      ),
                    ),
                  ],
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: _testingNotification ? null : _sendNotificationTest,
                      icon: _testingNotification
                          ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.notifications_outlined),
                      label: Text(_testingNotification ? 'Posting test…' : 'Send test notification'),
                    ),
                  ),

                ],
              ),
          ),
          const SizedBox(height: 26),
          const _SettingsHeading('Privacy and security'),
          const StatusRow(
            icon: Icons.key_outlined,
            title: 'Local chat state',
            subtitle: 'Protected through Android Keystore secure storage',
          ),
          const SizedBox(height: 8),
          GlassPanel(
            padding: const EdgeInsets.all(14),
            radius: BorderRadius.circular(20),
            blur: 5,
            glow: false,
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 34,
                        height: 34,
                        decoration: BoxDecoration(
                          color: const Color(0xFF2FBF86).withValues(alpha: .15),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.backup_outlined, color: Color(0xFF2FBF86), size: 19),
                      ),
                      const SizedBox(width: 10),
                      const Text('Encrypted chat backup', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                    ],
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Export a password-encrypted AES-256-GCM snapshot of all messages visible in this chat on this device to Downloads.',
                    style: TextStyle(fontSize: 12),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: _exportEncryptedBackup,
                      icon: const Icon(Icons.lock_outline, size: 18),
                      label: const Text('Export encrypted backup'),
                    ),
                  ),
                ],
              ),
          ),
          const SizedBox(height: 8),
          ValueListenableBuilder<E2eeStatus>(
            valueListenable: E2eeService.instance.statusNotifier,
            builder: (context, e2eeStatus, _) {
              final e2ee = E2eeService.instance;
              final fingerprint = e2ee.safetyFingerprint;
              final Color badgeColor = switch (e2eeStatus) {
                E2eeStatus.verified => const Color(0xFF2FBF86),
                E2eeStatus.active => const Color(0xFF2FBF86),
                E2eeStatus.keyChanged => const Color(0xFFF59E0B),
                E2eeStatus.error => const Color(0xFFE5484D),
                E2eeStatus.pending => const Color(0xFF4C8BF5),
              };
              final IconData badgeIcon = switch (e2eeStatus) {
                E2eeStatus.verified => Icons.verified_user_rounded,
                E2eeStatus.active => Icons.enhanced_encryption_rounded,
                E2eeStatus.keyChanged => Icons.gpp_maybe_rounded,
                E2eeStatus.error => Icons.error_outline_rounded,
                E2eeStatus.pending => Icons.lock_clock_outlined,
              };
              final String statusText = switch (e2eeStatus) {
                E2eeStatus.verified => 'Strict Double Ratchet · Verified · Forward Secrecy active',
                E2eeStatus.active => 'Strict Double Ratchet active · verify fingerprint below',
                E2eeStatus.keyChanged => 'Sending paused · peer security key changed',
                E2eeStatus.error => e2ee.lastError ?? 'Strict E2EE error · restore your key to resume',
                E2eeStatus.pending => 'Strict E2EE waiting · open Chat on both phones to exchange keys',
              };
              return GlassPanel(
                padding: const EdgeInsets.all(14),
                radius: BorderRadius.circular(20),
                blur: 5,
                glow: false,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 34,
                          height: 34,
                          decoration: BoxDecoration(
                            color: badgeColor.withValues(alpha: .15),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Icon(badgeIcon, color: badgeColor, size: 19),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'End-to-End Encryption (E2EE)',
                                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                              ),
                              Text(
                                statusText,
                                style: TextStyle(
                                  fontSize: 12,
                                  color: e2eeStatus == E2eeStatus.pending
                                      ? Theme.of(context).hintColor
                                      : badgeColor,
                                  fontWeight: e2eeStatus == E2eeStatus.pending
                                      ? FontWeight.w400
                                      : FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    if (e2eeStatus == E2eeStatus.keyChanged) ...[
                      const SizedBox(height: 10),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Color(0xFFF59E0B).withValues(alpha: .14),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Color(0xFFF59E0B).withValues(alpha: .45)),
                        ),
                        child: const Text(
                          'Sending is paused because your friend’s security key changed (e.g., reinstall or new phone). Compare the safety fingerprint below in person or over a call, then tap Mark as verified or Accept.',
                          style: TextStyle(fontSize: 12, height: 1.35),
                        ),
                      ),
                    ],
                    if (fingerprint != null) ...[
                      const SizedBox(height: 10),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: likedinSurfaceRaised(Theme.of(context).brightness),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Safety fingerprint (compare on both phones)',
                              style: TextStyle(fontSize: 11, color: Theme.of(context).hintColor),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              fingerprint,
                              style: const TextStyle(
                                fontFamily: 'monospace',
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                                letterSpacing: .8,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                Expanded(
                                  child: FilledButton.tonalIcon(
                                    onPressed: _e2eeBusy
                                        ? null
                                        : () async {
                                            if (e2eeStatus == E2eeStatus.verified) {
                                              await e2ee.clearFingerprintVerification();
                                            } else {
                                              await e2ee.markCurrentFingerprintVerified();
                                              OriginIslandHost.show(
                                                title: 'Identity verified',
                                                subtitle: 'E2EE safety fingerprint confirmed',
                                                icon: Icons.verified_user_rounded,
                                                accent: const Color(0xFF2FBF86),
                                              );
                                            }
                                          },
                                    icon: Icon(
                                      e2eeStatus == E2eeStatus.verified
                                          ? Icons.verified_user_rounded
                                          : Icons.verified_user_outlined,
                                      size: 17,
                                    ),
                                    label: Text(
                                      e2eeStatus == E2eeStatus.verified
                                          ? 'Verified'
                                          : 'Mark as verified',
                                    ),
                                  ),
                                ),
                                if (e2eeStatus == E2eeStatus.keyChanged) ...[
                                  const SizedBox(width: 8),
                                  TextButton(
                                    onPressed: _e2eeBusy
                                        ? null
                                        : () => unawaited(e2ee.acknowledgePeerKeyChange()),
                                    child: const Text('Accept'),
                                  ),
                                ],
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: _e2eeBusy ? null : () => _runE2eePassphraseFlow(restore: false),
                            icon: const Icon(Icons.key_rounded, size: 17),
                            label: const Text('Back up key'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: _e2eeBusy ? null : () => _runE2eePassphraseFlow(restore: true),
                            icon: const Icon(Icons.restore_rounded, size: 17),
                            label: const Text('Restore key'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            },
          ),
          if (_biometricAvailable) ...[
            const SizedBox(height: 8),
            GlassPanel(
              padding: EdgeInsets.zero,
              radius: BorderRadius.circular(20),
              child: SwitchListTile.adaptive(
                value: _biometricEnabled,
                onChanged: _setBiometricEnabled,
                secondary: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: const Color(0xFF9B6BFF).withValues(alpha: .15),
                    borderRadius: BorderRadius.circular(11),
                  ),
                  child: const Icon(Icons.fingerprint_rounded, color: Color(0xFF9B6BFF), size: 20),
                ),
                title: const Text('Fingerprint unlock for hidden chats', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                subtitle: const Text('Use fingerprint when tapping the Home logo; password remains fallback.', style: TextStyle(fontSize: 12)),
              ),
            ),
          ],
          const SizedBox(height: 26),
          const _SettingsHeading('Media and storage'),
          GlassPanel(
            padding: EdgeInsets.zero,
            radius: BorderRadius.circular(20),
            child: _SettingsNavTile(
              icon: Icons.pie_chart_outline_rounded,
              badgeColor: const Color(0xFF2FBF86),
              title: 'Storage and media',
              subtitle: 'See what uses space, clear cache and retry uploads',
              onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
                builder: (_) => StoragePage(store: widget.attachmentVault),
              )),
            ),
          ),
          const SizedBox(height: 26),
          const _SettingsHeading('About Likedin'),
          GlassPanel(
            padding: EdgeInsets.zero,
            radius: BorderRadius.circular(20),
            child: Column(
              children: [
                _SettingsNavTile(
                  icon: Icons.system_update_rounded,
                  badgeColor: const Color(0xFF4C8BF5),
                  title: _checkingUpdates ? 'Checking for updates…' : 'Check for updates',
                  subtitle: 'Download and install new releases automatically',
                  onTap: _checkingUpdates ? () {} : _checkForUpdates,
                ),
                Divider(height: 1, indent: 62, endIndent: 14, color: likedinOutline(Theme.of(context).brightness)),
                ListTile(
                  leading: Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: const Color(0xFF9B6BFF).withValues(alpha: .15),
                      borderRadius: BorderRadius.circular(11),
                    ),
                    child: const Icon(Icons.info_outline, color: Color(0xFF9B6BFF), size: 19),
                  ),
                  title: const Text('Likedin', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                  subtitle: const Text('Version $likedinVersion', style: TextStyle(fontSize: 12)),
                ),
              ],
            ),
          ),
        ],
      );
}

class _SettingsNavTile extends StatelessWidget {
  const _SettingsNavTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.badgeColor = const Color(0xFF4C8BF5),
  });
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final Color badgeColor;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    return ListTile(
      onTap: onTap,
      leading: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: badgeColor.withValues(alpha: .15),
          borderRadius: BorderRadius.circular(11),
        ),
        child: Icon(icon, color: badgeColor, size: 19),
      ),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
      subtitle: Text(subtitle, style: const TextStyle(fontSize: 12)),
      trailing: Icon(Icons.chevron_right_rounded, color: likedinMutedText(brightness)),
    );
  }
}

class _SettingsHeading extends StatelessWidget {
  const _SettingsHeading(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 0, 4, 10),
        child: Text(
          text,
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: -.4),
        ),
      );
}



class _FilesMediaThumbnailTile extends StatefulWidget {
  const _FilesMediaThumbnailTile({
    super.key,
    required this.payload,
    required this.onTap,
    required this.onSave,
  });

  final Map<String, dynamic> payload;
  final VoidCallback onTap;
  final VoidCallback onSave;

  @override
  State<_FilesMediaThumbnailTile> createState() => _FilesMediaThumbnailTileState();
}

class _FilesMediaThumbnailTileState extends State<_FilesMediaThumbnailTile> {
  static final Map<String, File> _memoryThumbCache = <String, File>{};
  File? _file;
  bool _loading = false;

  bool get _isVideo => widget.payload['kind']?.toString() == 'video';
  bool get _isGif =>
      widget.payload['animated'] == true ||
      widget.payload['mime'] == 'image/gif' ||
      (widget.payload['name']?.toString().toLowerCase().endsWith('.gif') ?? false);

  String get _cacheKey =>
      widget.payload['thumbnail_path']?.toString().isNotEmpty == true
          ? widget.payload['thumbnail_path'].toString()
          : (widget.payload['path']?.toString() ?? '');

  @override
  void initState() {
    super.initState();
    _initThumb();
  }

  @override
  void didUpdateWidget(covariant _FilesMediaThumbnailTile oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.payload['path'] != widget.payload['path']) {
      _file = null;
      _loading = false;
      _initThumb();
    }
  }

  static void clearMemoryCache() => _memoryThumbCache.clear();

  void _initThumb() {
    final key = _cacheKey;
    final cached = key.isEmpty ? null : _memoryThumbCache[key];
    if (cached != null && cached.existsSync()) {
      _file = cached;
      return;
    }
    if (cached != null) _memoryThumbCache.remove(key);
    unawaited(_resolveThumb(key));
  }

  Future<void> _resolveThumb(String key) async {
    if (_loading) return;
    _loading = true;
    File? resolved;
    final service = SharedMediaService(Supabase.instance.client);
    final sidecar = widget.payload['thumbnail_path']?.toString();
    if (sidecar != null && sidecar.isNotEmpty) {
      try {
        resolved = await service.cachedFile(<String, dynamic>{
          '__likedin_media_v1': true,
          'path': sidecar,
          'name': 'media-thumb.jpg',
          'mime': 'image/jpeg',
          'kind': 'image',
          if (widget.payload['e2ee'] == true) 'e2ee': true,
          if (widget.payload['mk'] != null) 'mk': widget.payload['mk'],
        });
      } catch (_) {}
    }
    if (resolved == null && !_isVideo) {
      try {
        resolved = await service.cachedFile(widget.payload);
      } catch (_) {}
    }
    if (resolved != null && key.isNotEmpty) {
      if (_memoryThumbCache.length > 400) _memoryThumbCache.clear();
      _memoryThumbCache[key] = resolved;
    }
    _loading = false;
    if (mounted && _cacheKey == key) {
      setState(() => _file = resolved);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final file = _file;
    return GestureDetector(
      onTap: widget.onTap,
      onLongPress: widget.onSave,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (file != null)
              Image.file(
                file,
                fit: BoxFit.cover,
                cacheWidth: 220,
                filterQuality: FilterQuality.low,
                gaplessPlayback: true,
                errorBuilder: (_, __, ___) => _placeholder(theme, false),
              )
            else
              _placeholder(theme, _loading),
            if (_isVideo)
              Center(
                child: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: .54),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 24),
                ),
              ),
            if (_isGif)
              Positioned(
                left: 6,
                top: 6,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: .62),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: const Text(
                    'GIF',
                    style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w800),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _placeholder(ThemeData theme, bool loading) => Container(
        decoration: _isVideo
            ? const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF172B4D), Color(0xFF0A192F)],
                ),
              )
            : BoxDecoration(color: theme.colorScheme.surfaceContainerHighest),
        child: Center(
          child: loading
              ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
              : Icon(
                  _isVideo ? Icons.videocam_rounded : Icons.image_outlined,
                  color: _isVideo ? Colors.white70 : theme.colorScheme.primary,
                  size: 28,
                ),
        ),
      );
}
