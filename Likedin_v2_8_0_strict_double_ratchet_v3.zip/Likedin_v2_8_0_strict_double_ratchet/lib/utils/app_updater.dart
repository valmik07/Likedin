import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../ui/glassmorphism.dart';

class AppReleaseInfo {
  const AppReleaseInfo({
    required this.version,
    required this.apkUrl,
    required this.notes,
  });

  final String version;
  final String apkUrl;
  final String notes;
}

/// Checks GitHub Releases for a newer signed Likedin ARM64 APK, streams the
/// download with live progress, and triggers Android's native package installer.
class AppUpdater {
  static const String _githubLatestReleaseUrl =
      'https://api.github.com/repos/valmik07/Likedin/releases/latest';
  static const String _lastCheckPrefKey = 'likedin_last_update_check_ms_v1';
  static const String _lastFailurePrefKey = 'likedin_last_update_fail_ms_v1';
  static const Duration _successCheckInterval = Duration(hours: 6);
  static const Duration _failureRetryInterval = Duration(minutes: 15);
  static const MethodChannel _downloadsChannel =
      MethodChannel('com.example.likedin/downloads');
  static bool _dialogShowing = false;

  /// Returns true when an automatic startup update check should run:
  /// waits 6 hours after a successful check, or 15 minutes after a failed one.
  static bool shouldRunAutomaticCheck({
    required int nowMs,
    required int lastSuccessMs,
    required int lastFailureMs,
  }) {
    if (lastSuccessMs > 0 &&
        nowMs - lastSuccessMs < _successCheckInterval.inMilliseconds) {
      return false;
    }
    if (lastFailureMs > 0 &&
        nowMs - lastFailureMs < _failureRetryInterval.inMilliseconds) {
      return false;
    }
    return true;
  }

  /// Strictly selects an HTTPS ARM64 APK asset from a GitHub Release asset list.
  /// Never silently falls back to an x86 or 32-bit ARM APK.
  static String? selectArm64ApkUrl(List<dynamic> assets) {
    for (final asset in assets.whereType<Map>()) {
      final assetName = asset['name']?.toString().toLowerCase() ?? '';
      final downloadUrl = asset['browser_download_url']?.toString() ?? '';
      if (!assetName.endsWith('.apk') || !downloadUrl.startsWith('https://')) {
        continue;
      }
      final isArm64 =
          assetName.contains('arm64-v8a') || assetName.contains('arm64');
      final isIncompatibleAbi =
          assetName.contains('x86') || assetName.contains('armeabi-v7a');
      if (isArm64 && !isIncompatibleAbi) {
        return downloadUrl;
      }
    }
    return null;
  }

  /// Parses versions like "2.1.0+110", "v2.1.0+110", or "v2.1.0".
  static bool isNewerVersion(String remoteRaw, String currentRaw) {
    final remote = _parseVersion(remoteRaw);
    final current = _parseVersion(currentRaw);
    for (var i = 0; i < 3; i++) {
      if (remote.$1[i] != current.$1[i]) return remote.$1[i] > current.$1[i];
    }
    if (remote.$2 != null && current.$2 != null) {
      return remote.$2! > current.$2!;
    }
    return false;
  }

  static (List<int>, int?) _parseVersion(String raw) {
    final cleaned = raw.trim().replaceFirst(RegExp(r'^[vV]'), '');
    final parts = cleaned.split('+');
    final semver = parts.first
        .split('.')
        .map((s) => int.tryParse(s.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0)
        .toList();
    while (semver.length < 3) {
      semver.add(0);
    }
    final build = parts.length > 1 ? int.tryParse(parts[1].trim()) : null;
    return (semver.take(3).toList(), build);
  }

  static Future<AppReleaseInfo?> fetchLatestRelease() async {
    final response = await http
        .get(
          Uri.parse(_githubLatestReleaseUrl),
          headers: const {
            'Accept': 'application/vnd.github+json',
            'User-Agent': 'Likedin-Updater',
          },
        )
        .timeout(const Duration(seconds: 10));
    if (response.statusCode != 200) return null;
    final decoded = jsonDecode(response.body);
    if (decoded is! Map) return null;
    final tag = decoded['tag_name']?.toString().trim() ?? '';
    final name = decoded['name']?.toString().trim() ?? '';
    final body = decoded['body']?.toString().trim() ?? '';
    final assets = decoded['assets'];
    final apkUrl = assets is List ? selectArm64ApkUrl(assets) : null;
    final versionText = tag.isNotEmpty ? tag : name;
    if (versionText.isEmpty) return null;
    if (apkUrl == null) {
      throw StateError(
        'No compatible ARM64 APK is attached to release ${versionText.replaceFirst(RegExp(r'^[vV]'), '')} yet.',
      );
    }
    return AppReleaseInfo(
      version: versionText.replaceFirst(RegExp(r'^[vV]'), ''),
      apkUrl: apkUrl,
      notes: body.isEmpty ? 'Bug fixes, visual polish, and new features.' : body,
    );
  }

  /// Silent check on startup: waits 6 hours after a successful check, and
  /// retries after 15 minutes when a previous check failed due to connectivity.
  static Future<void> checkAutomatically(
    BuildContext context, {
    required String currentVersion,
  }) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final nowMs = DateTime.now().millisecondsSinceEpoch;
      final lastSuccessMs = prefs.getInt(_lastCheckPrefKey) ?? 0;
      final lastFailureMs = prefs.getInt(_lastFailurePrefKey) ?? 0;
      if (!shouldRunAutomaticCheck(
        nowMs: nowMs,
        lastSuccessMs: lastSuccessMs,
        lastFailureMs: lastFailureMs,
      )) {
        return;
      }
      if (!context.mounted) return;
      final succeeded = await checkAndPrompt(
        context,
        currentVersion: currentVersion,
        manual: false,
      );
      final doneMs = DateTime.now().millisecondsSinceEpoch;
      if (succeeded) {
        await prefs.setInt(_lastCheckPrefKey, doneMs);
        await prefs.remove(_lastFailurePrefKey);
      } else {
        await prefs.setInt(_lastFailurePrefKey, doneMs);
      }
    } catch (_) {}
  }

  static Future<bool> checkAndPrompt(
    BuildContext context, {
    required String currentVersion,
    required bool manual,
  }) async {
    if (_dialogShowing) return false;
    AppReleaseInfo? release;
    try {
      release = await fetchLatestRelease();
    } on StateError catch (error) {
      debugPrint('Update check asset validation: $error');
      if (manual && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(error.message.toString())),
        );
      }
      return false;
    } catch (error) {
      debugPrint('Update check skipped: $error');
      if (manual && context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Could not check for updates right now. Check your connection and try again.'),
          ),
        );
      }
      return false;
    }

    if (!context.mounted) return true;
    if (release == null || !isNewerVersion(release.version, currentVersion)) {
      if (manual) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Likedin v$currentVersion is up to date.')),
        );
      }
      return true;
    }

    _dialogShowing = true;
    try {
      await showDialog<void>(
        context: context,
        barrierDismissible: true,
        builder: (_) => _UpdateDialog(
          currentVersion: currentVersion,
          release: release!,
        ),
      );
    } finally {
      _dialogShowing = false;
    }
    return true;
  }
}

class _UpdateDialog extends StatefulWidget {
  const _UpdateDialog({
    required this.currentVersion,
    required this.release,
  });

  final String currentVersion;
  final AppReleaseInfo release;

  @override
  State<_UpdateDialog> createState() => _UpdateDialogState();
}

class _UpdateDialogState extends State<_UpdateDialog> {
  bool _downloading = false;
  double? _progress;
  String? _statusMessage;
  String? _downloadedPath;

  Future<void> _downloadAndInstall() async {
    if (_downloading) return;
    if (_downloadedPath != null && await File(_downloadedPath!).exists()) {
      await _triggerInstall(_downloadedPath!);
      return;
    }
    if (!mounted) return;
    setState(() {
      _downloading = true;
      _progress = 0;
      _statusMessage = 'Downloading update…';
    });
    final client = http.Client();
    IOSink? sink;
    try {
      final request = http.Request('GET', Uri.parse(widget.release.apkUrl));
      request.headers['User-Agent'] = 'Likedin-Updater';
      final response = await client.send(request).timeout(const Duration(seconds: 25));
      if (response.statusCode != 200) {
        throw StateError('Server returned HTTP ${response.statusCode}');
      }
      final support = await getApplicationSupportDirectory();
      final apkFile = File(p.join(support.path, 'likedin_update.apk'));
      if (await apkFile.exists()) await apkFile.delete();
      sink = apkFile.openWrite();
      final total = response.contentLength ?? 0;
      var received = 0;
      await for (final chunk in response.stream) {
        sink.add(chunk);
        received += chunk.length;
        if (mounted) {
          setState(() {
            _progress = total > 0 ? (received / total).clamp(0.0, 1.0) : null;
            final mb = (received / (1024 * 1024)).toStringAsFixed(1);
            final totalMb = total > 0 ? ' / ${(total / (1024 * 1024)).toStringAsFixed(1)} MB' : ' MB';
            _statusMessage = 'Downloading… $mb$totalMb';
          });
        }
      }
      await sink.flush();
      await sink.close();
      sink = null;
      _downloadedPath = apkFile.path;
      if (mounted) {
        setState(() {
          _downloading = false;
          _progress = 1.0;
          _statusMessage = 'Opening Android installer…';
        });
      }
      await _triggerInstall(apkFile.path);
    } catch (error) {
      debugPrint('APK download failed: $error');
      if (mounted) {
        setState(() {
          _downloading = false;
          _progress = null;
          _statusMessage = 'Download failed. Check your connection and try again.';
        });
      }
    } finally {
      try {
        await sink?.close();
      } catch (_) {}
      client.close();
    }
  }

  Future<void> _triggerInstall(String path) async {
    try {
      final outcome = await AppUpdater._downloadsChannel.invokeMethod<String>(
        'installApk',
        <String, Object>{'sourcePath': path},
      );
      if (!mounted) return;
      if (outcome == 'PERMISSION_REQUIRED') {
        setState(() {
          _statusMessage = 'Enable "Allow from this source" for Likedin, then tap Install update again.';
        });
      } else {
        Navigator.of(context).pop();
      }
    } catch (error) {
      debugPrint('APK install launch failed: $error');
      if (mounted) {
        setState(() {
          _statusMessage = 'Could not launch the Android installer. Please try again.';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final primary = likedinPrimary(brightness);
    return AlertDialog(
      title: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: primary.withValues(alpha: .15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(Icons.system_update_rounded, color: primary, size: 21),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Update available', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                Text(
                  'v${widget.currentVersion} → v${widget.release.version}',
                  style: TextStyle(fontSize: 12, color: likedinMutedText(brightness), fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
        ],
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.release.notes, style: const TextStyle(fontSize: 13, height: 1.45)),
            if (_downloading || _statusMessage != null) ...[
              const SizedBox(height: 16),
              if (_downloading)
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(value: _progress, minHeight: 6),
                ),
              if (_statusMessage != null) ...[
                const SizedBox(height: 8),
                Text(
                  _statusMessage!,
                  style: TextStyle(fontSize: 12, color: likedinMutedText(brightness)),
                ),
              ],
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: _downloading ? null : () => Navigator.of(context).pop(),
          child: const Text('Later'),
        ),
        FilledButton.icon(
          onPressed: _downloading ? null : _downloadAndInstall,
          icon: Icon(
            _downloadedPath != null ? Icons.install_mobile_rounded : Icons.download_rounded,
            size: 18,
          ),
          label: Text(_downloadedPath != null ? 'Install update' : 'Update now'),
        ),
      ],
    );
  }
}
