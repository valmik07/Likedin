import 'dart:async';
import 'dart:convert';
import 'dart:ui' as ui;
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../backend/backend_config.dart';

const likedinMessageChannelId = 'likedin_messages_v1';
const likedinCallChannelId = 'likedin_calls_v1';
const likedinDiagnosticChannelId = 'likedin_diagnostics_v1';
const _callLaunchChannel = MethodChannel('com.example.likedin/call_alerts');

@pragma('vm:entry-point')
Future<void> likedinFirebaseBackgroundHandler(RemoteMessage message) async {
  // Register plugins in the Firebase background isolate before invoking
  // flutter_local_notifications or any other platform plugin.
  WidgetsFlutterBinding.ensureInitialized();
  ui.DartPluginRegistrant.ensureInitialized();

  // Display first. A delivery receipt must never be written before the local
  // notification attempt, otherwise a failed display can look delivered.
  try {
    final local = FlutterLocalNotificationsPlugin();
    const android = AndroidInitializationSettings('@drawable/likedin_notification');
    await local.initialize(const InitializationSettings(android: android));
    final route = message.data['route']?.toString();
    final callId = message.data['call_id']?.toString();
    if (route == 'call_ended' || route == 'call_cancelled') {
      if (callId != null && callId.isNotEmpty) {
        await local.cancel(callId.hashCode);
      }
      return;
    }
    final isCall = route == 'incoming_call' || route == 'missed_call' || route == 'call_history';
    final isMissed = route == 'missed_call' || route == 'call_history';
    final details = NotificationDetails(
      android: AndroidNotificationDetails(
        isCall ? likedinCallChannelId : likedinMessageChannelId,
        isCall ? 'Likedin calls' : 'Likedin messages',
        channelDescription: isCall ? 'Incoming calls' : 'New messages from your Likedin chat',
        importance: isCall ? Importance.max : Importance.high,
        priority: isCall ? Priority.max : Priority.high,
        playSound: true,
        sound: RawResourceAndroidNotificationSound(isCall ? 'likedin_call' : 'likedin_message'),
        category: isMissed
            ? AndroidNotificationCategory.missedCall
            : isCall
                ? AndroidNotificationCategory.call
                : AndroidNotificationCategory.message,
        fullScreenIntent: route == 'incoming_call',
        ongoing: route == 'incoming_call',
        autoCancel: route != 'incoming_call',
        visibility: NotificationVisibility.public,
      ),
    );
    final title = message.data['notification_title']?.toString() ??
        message.notification?.title ??
        'Likedin';
    final body = message.data['notification_body']?.toString() ??
        message.notification?.body ??
        (isMissed ? 'You missed a call.' : isCall ? 'Incoming call' : 'You received a new message.');
    final payloadMap = isMissed
        ? {'route': 'missed_call', 'call_id': callId}
        : isCall
            ? {'route': 'incoming_call', 'call_id': callId}
            : {'route': 'chat'};
    await local.show(
      (callId != null && callId.isNotEmpty ? callId.hashCode : null) ??
          message.messageId?.hashCode ??
          DateTime.now().millisecondsSinceEpoch.remainder(100000),
      title,
      body,
      details,
      payload: jsonEncode(payloadMap),
    );
  } catch (error) {
    debugPrint('Could not display background Likedin notification: $error');
  }

  // Acknowledge after the notification display attempt. If the background
  // isolate cannot restore the Supabase session, foreground sync will retry.
  try {
    if (Firebase.apps.isEmpty) await Firebase.initializeApp();
    await Supabase.initialize(
      url: BackendConfig.supabaseUrl,
      anonKey: BackendConfig.supabaseAnonKey,
    );
    final messageId = message.data['message_id']?.toString();
    if (messageId != null && messageId.isNotEmpty) {
      await Supabase.instance.client.rpc(
        'likedin_mark_message_delivered',
        params: {'p_message_id': messageId},
      );
    }
  } catch (error) {
    debugPrint('Background delivery acknowledgement deferred: $error');
  }
}

class NotificationTestResult {
  const NotificationTestResult({required this.success, required this.message});
  final bool success;
  final String message;
}

class LikedinNotificationService {
  LikedinNotificationService._();
  static final instance = LikedinNotificationService._();
  final FlutterLocalNotificationsPlugin _local = FlutterLocalNotificationsPlugin();
  bool _localReady = false;
  bool _pushReady = false;
  bool _tokenRegistered = false;
  bool? _notificationsAllowed;
  StreamSubscription<dynamic>? _authStateSubscription;
  bool isConversationVisible = false;
  bool openedFromNotification = false;
  void Function()? onOpenChat;
  void Function(String callId)? onOpenIncomingCall;
  void Function()? onOpenCalls;
  String? _pendingIncomingCallId;

  bool get pushConfigured => _pushReady;
  bool get tokenRegistered => _tokenRegistered;
  bool? get notificationsAllowed => _notificationsAllowed;

  Future<void> refreshNotificationPermissionStatus() async {
    try {
      final androidPlugin = _local.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      _notificationsAllowed = await androidPlugin?.areNotificationsEnabled();
    } catch (error) {
      debugPrint('Could not read Android notification permission: $error');
    }
  }

  Future<NotificationTestResult> showTestNotification() async {
    if (!_localReady) {
      return const NotificationTestResult(
        success: false,
        message: 'The local notification plugin is not initialized. Close and reopen Likedin, then try again.',
      );
    }

    try {
      final androidPlugin = _local.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      var enabled = await androidPlugin?.areNotificationsEnabled();
      _notificationsAllowed = enabled;
      if (enabled == false) {
        final granted = await androidPlugin?.requestNotificationsPermission();
        enabled = granted ?? await androidPlugin?.areNotificationsEnabled();
        _notificationsAllowed = enabled;
      }
      if (enabled == false) {
        return const NotificationTestResult(
          success: false,
          message: 'Android reports that Likedin notifications are blocked. Enable them in Android Settings → Apps → Likedin → Notifications.',
        );
      }

      // Use a brand-new, silent channel for diagnostics. This avoids a muted
      // message/call channel or a custom sound resource hiding the real result.
      const channel = AndroidNotificationChannel(
        likedinDiagnosticChannelId,
        'Likedin notification test',
        description: 'Temporary diagnostic notifications from Likedin',
        importance: Importance.high,
        playSound: false,
        enableVibration: false,
      );
      await androidPlugin?.createNotificationChannel(channel);
      await _local.show(
        DateTime.now().millisecondsSinceEpoch.remainder(100000),
        'Likedin notification test',
        'Android accepted a local notification from this phone.',
        const NotificationDetails(
          android: AndroidNotificationDetails(
            likedinDiagnosticChannelId,
            'Likedin notification test',
            channelDescription: 'Temporary diagnostic notifications from Likedin',
            importance: Importance.high,
            priority: Priority.high,
            icon: 'likedin_notification',
            playSound: false,
            enableVibration: false,
            category: AndroidNotificationCategory.status,
          ),
        ),
      );
      return const NotificationTestResult(
        success: true,
        message: 'Android accepted the test notification. Check the notification shade; this tests local display only, not Firebase push delivery.',
      );
    } on PlatformException catch (error) {
      final detail = (error.message?.isNotEmpty == true) ? error.message : error.details?.toString();
      debugPrint('Local notification test PlatformException ${error.code}: $detail');
      return NotificationTestResult(
        success: false,
        message: 'Android notification error (${error.code}): ${detail ?? 'No additional details returned.'}',
      );
    } catch (error, stackTrace) {
      debugPrint('Local notification test failed: $error\n$stackTrace');
      return NotificationTestResult(
        success: false,
        message: 'Local notification test failed: $error',
      );
    }
  }

  void setConversationVisible(bool visible) {
    isConversationVisible = visible;
  }

  void setOnOpenIncomingCall(void Function(String callId) callback) {
    onOpenIncomingCall = callback;
    final pending = _pendingIncomingCallId;
    if (pending != null) {
      _pendingIncomingCallId = null;
      callback(pending);
    }
  }

  void _dispatchTap({String? payload, Map<String, dynamic>? data}) {
    String? route;
    String? callId;
    if (data != null) {
      route = data['route']?.toString();
      callId = data['call_id']?.toString();
    }
    if (payload != null && payload.isNotEmpty) {
      try {
        final decoded = jsonDecode(payload);
        if (decoded is Map) {
          route ??= decoded['route']?.toString();
          callId ??= decoded['call_id']?.toString();
        }
      } catch (_) {}
    }
    if (route == 'call_history' || route == 'missed_call') {
      final callback = onOpenCalls;
      if (callback != null) callback();
      return;
    }
    if (route == 'incoming_call' && callId != null && callId.isNotEmpty) {
      final callback = onOpenIncomingCall;
      if (callback == null) { _pendingIncomingCallId = callId; } else { callback(callId); }
      return;
    }
    _handleNotificationTap();
  }

  void setOnOpenCalls(void Function() callback) { onOpenCalls = callback; }

  void setOnOpenChat(void Function() callback) {
    onOpenChat = callback;
    if (openedFromNotification) {
      openedFromNotification = false;
      callback();
    }
  }

  void _handleNotificationTap() {
    final callback = onOpenChat;
    if (callback == null) {
      openedFromNotification = true;
    } else {
      callback();
    }
  }

  Future<void> initialize() async {
    const android = AndroidInitializationSettings('@drawable/likedin_notification');
    const settings = InitializationSettings(android: android);
    await _local.initialize(settings, onDidReceiveNotificationResponse: (response) => _dispatchTap(payload: response.payload));
    final launchDetails = await _local.getNotificationAppLaunchDetails();
    if (launchDetails?.didNotificationLaunchApp == true) {
      final payload = launchDetails?.notificationResponse?.payload;
      if (payload != null && payload.isNotEmpty) { _dispatchTap(payload: payload); } else { openedFromNotification = true; }
    }
    const callChannel = AndroidNotificationChannel(
      likedinCallChannelId,
      'Likedin calls',
      description: 'Incoming audio and video calls',
      importance: Importance.max,
      playSound: true,
      sound: RawResourceAndroidNotificationSound('likedin_call'),
      enableVibration: true,
    );
    await _local.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.createNotificationChannel(callChannel);
    const channel = AndroidNotificationChannel(
      likedinMessageChannelId,
      'Likedin messages',
      description: 'New messages from your Likedin chat',
      importance: Importance.high,
      playSound: true,
      sound: RawResourceAndroidNotificationSound('likedin_message'),
      enableVibration: true,
    );
    await _local.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.createNotificationChannel(channel);
    final androidPlugin = _local.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    final permissionResult = await androidPlugin?.requestNotificationsPermission();
    _notificationsAllowed = permissionResult ?? await androidPlugin?.areNotificationsEnabled();
    // Android 14+ can restrict full-screen intents. The native bridge opens
    // the dedicated system permission screen only when access is not granted.
    try { await _callLaunchChannel.invokeMethod<bool>('ensureFullScreenCallPermission'); } catch (error) { debugPrint('Full-screen call permission check failed: $error'); }
    _localReady = true;

    // Firebase Android configuration is supplied by google-services.json.
    // FCM still depends on deployed Supabase senders/webhooks and valid tokens.
    try {
      if (Firebase.apps.isEmpty) await Firebase.initializeApp();
      FirebaseMessaging.onBackgroundMessage(likedinFirebaseBackgroundHandler);
      await FirebaseMessaging.instance.requestPermission(alert: true, badge: true, sound: true);
      FirebaseMessaging.onMessage.listen((message) {
        final route = message.data['route']?.toString();
        final callId = message.data['call_id']?.toString();
        if (route == 'call_ended' || route == 'call_cancelled') {
          if (callId != null && callId.isNotEmpty) {
            cancelIncomingCall(callId);
          }
          return;
        }
        if (route == 'incoming_call') {
          // Keep the in-app call routing, but also post a visible system
          // notification while foregrounded so the alert is not silent.
          final incomingCallId = callId ?? DateTime.now().millisecondsSinceEpoch.toString();
          showIncomingCall(callId: incomingCallId,
            video: message.data['call_type'] == 'video');
          _dispatchTap(data: message.data);
          return;
        }
        if (route == 'missed_call') {
          showMissedCall(
            callId: callId ?? DateTime.now().millisecondsSinceEpoch.toString(),
            video: message.data['call_type'] == 'video',
          );
          return;
        }
        if (!isConversationVisible) _showForegroundPush(message);
      });
      FirebaseMessaging.onMessageOpenedApp.listen((message) => _dispatchTap(data: message.data));
      FirebaseMessaging.instance.onTokenRefresh.listen((token) {
        _saveToken(token).catchError((error) => debugPrint('Could not update Likedin push token: $error'));
      });
      _pushReady = true;

      // Auth can be restored or completed after Firebase initialization.
      // Re-register the same device token whenever a user session becomes
      // available, rather than silently losing the one startup attempt.
      _authStateSubscription ??= Supabase.instance.client.auth.onAuthStateChange.listen((state) {
        if (state.event == AuthChangeEvent.initialSession ||
            state.event == AuthChangeEvent.signedIn ||
            state.event == AuthChangeEvent.tokenRefreshed) {
          unawaited(registerCurrentToken());
        }
      }, onError: (Object error, StackTrace stackTrace) {
        debugPrint('Likedin auth-state listener notification registration error: $error');
      });

      final initialMessage = await FirebaseMessaging.instance.getInitialMessage();
      if (initialMessage != null) _dispatchTap(data: initialMessage.data);
      final token = await FirebaseMessaging.instance.getToken();
      if (token != null) await _saveToken(token);
    } catch (error) {
      debugPrint('Likedin Firebase messaging initialization failed: $error');
      _pushReady = false;
    }
  }

  Future<void> _showForegroundPush(RemoteMessage message) async {
    final title = message.data['notification_title']?.toString() ??
        message.notification?.title ??
        'Likedin';
    final body = message.data['notification_body']?.toString() ??
        message.notification?.body ??
        'You received a new message.';
    await showMessage(title: title, body: body, id: message.messageId?.hashCode ?? DateTime.now().millisecondsSinceEpoch);
  }

  Future<void> showMessage({required String title, required String body, int? id}) async {
    if (!_localReady) return;
    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        likedinMessageChannelId,
        'Likedin messages',
        channelDescription: 'New messages from your Likedin chat',
        importance: Importance.high,
        priority: Priority.high,
        playSound: true,
        sound: RawResourceAndroidNotificationSound('likedin_message'),
        category: AndroidNotificationCategory.message,
      ),
    );
    await _local.show(id ?? DateTime.now().millisecondsSinceEpoch.remainder(100000), title, body, details, payload: jsonEncode({'route': 'chat'}));
  }

  Future<void> cancelIncomingCall(String callId) async {
    if (!_localReady || callId.isEmpty) return;
    await _local.cancel(callId.hashCode);
  }

  Future<void> showIncomingCall({required String callId, required bool video}) async {
    if (!_localReady || callId.isEmpty) return;
    const details = NotificationDetails(android: AndroidNotificationDetails(
      likedinCallChannelId, 'Likedin calls',
      channelDescription: 'Incoming audio and video calls',
      importance: Importance.max, priority: Priority.max,
      playSound: true,
      sound: RawResourceAndroidNotificationSound('likedin_call'),
      category: AndroidNotificationCategory.call,
      fullScreenIntent: true,
      ongoing: true,
      autoCancel: false,
      visibility: NotificationVisibility.public,
    ));
    await _local.show(callId.hashCode, 'Incoming ${video ? 'video' : 'audio'} call',
      'Your friend is calling.', details,
      payload: jsonEncode({'route':'incoming_call','call_id':callId}));
  }

  Future<void> showMissedCall({required String callId, required bool video}) async {
    if (!_localReady) return;
    const details = NotificationDetails(android: AndroidNotificationDetails(
      likedinCallChannelId, 'Likedin calls', channelDescription: 'Missed call alerts',
      importance: Importance.max, priority: Priority.high, playSound: true,
      sound: RawResourceAndroidNotificationSound('likedin_call'),
      category: AndroidNotificationCategory.missedCall,
    ));
    await _local.show(callId.hashCode, 'Missed ${video ? 'video' : 'audio'} call', 'Your friend tried to reach you.', details,
      payload: jsonEncode({'route':'missed_call','call_id':callId}));
  }

  Future<String?> getPushToken() async {
    if (!_pushReady) return null;
    return FirebaseMessaging.instance.getToken();
  }

  Future<void> registerCurrentToken() async {
    if (!_pushReady) return;
    try {
      final token = await FirebaseMessaging.instance.getToken();
      if (token != null) await _saveToken(token);
    } catch (error) {
      _tokenRegistered = false;
      debugPrint('Could not register Likedin push token: $error');
    }
  }

  Future<void> _saveToken(String token) async {
    final client = Supabase.instance.client;
    final user = client.auth.currentUser;
    if (user == null) {
      _tokenRegistered = false;
      debugPrint('FCM token exists, but no Supabase user is signed in yet.');
      return;
    }
    try {
      await client.from('likedin_push_tokens').upsert({
        'user_id': user.id,
        'token': token,
        'platform': 'android',
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      });
      _tokenRegistered = true;
      debugPrint('Likedin FCM token registered for the signed-in account.');
    } catch (error) {
      _tokenRegistered = false;
      debugPrint('FCM token could not be saved to likedin_push_tokens: $error');
    }
  }
}
