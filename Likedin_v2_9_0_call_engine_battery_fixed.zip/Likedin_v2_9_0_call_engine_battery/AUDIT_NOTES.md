# Likedin v2.9.0+139 — Call Engine & Battery Optimization Audit Log

## 1. New in v2.9.0+139

| Area | Improvement | Files |
| :--- | :--- | :--- |
| **Wi-Fi ↔ 4G/5G Call Handoff** | Subscribed to `connectivity_plus` during active calls and implemented glare-safe (`polite`/`impolite`) full ICE-restart renegotiation (`createOffer({'iceRestart': true})` + refreshed TURN config) using `kind: 'offer'`/`'answer'` + `iceRestart: true` (100% compatible with existing `likedin_call_signals` DB check constraint). | `lib/calls/call_service.dart`, `lib/calls/call_quality_engine.dart` |
| **Hardware Voice Processing & Opus FEC/DTX** | Replaced bare `'audio': true` with full hardware AEC/NS/AGC/highpass constraints and tuned Opus SDP (`useinbandfec=1`, `usedtx=1`, `minptime=10`, dedicated audio bitrate floor). | `lib/calls/call_service.dart`, `lib/calls/call_quality_engine.dart` |
| **Adaptive Video Bitrate & Hardware Codecs** | Reordered video SDP to prioritize hardware H.264/VP8, polled `pc.getStats()` every 2.5s, and dynamically applied `RTCRtpSender.setParameters()` (`RTCDegradationPreference.BALANCED`, `maxBitrate`, `maxFramerate`, `scaleResolutionDownBy`) across HD/Good/Fair/Weak/Saver tiers. | `lib/calls/call_service.dart`, `lib/calls/call_quality_engine.dart` |
| **Live Call Quality Pill & Data Saver** | Added `_CallQualityBadge` (`HD`/`Good`/`Fair`/`Weak`/`Saver`/`Reconnecting` + RTT ms) and a 1-tap **Saver** button to both outgoing and incoming call screens. | `lib/ui/calls_page_part.dart` |
| **Battery Fix #1 — Soft Glass Accelerometer** | `OriginGlintController.sync()` now unregisters the accelerometer in `LikedinEffects.soft` (as well as `off`) while keeping Soft Glass visuals 100% untouched. | `lib/ui/glassmorphism.dart` |
| **Battery Fix #2 — 60 Hz Call Refresh Cap** | `MainActivity.kt` drops display refresh rate to 60 Hz while `CallForegroundService` is active and restores max Hz (90/120 Hz) automatically when the call ends. | `android/app/src/main/kotlin/com/example/likedin/MainActivity.kt` |
| **Battery Fix #3 — Opus DTX Silence Suppression** | Enabled `usedtx=1` in Opus `a=fmtp` so radio & CPU sleep during quiet pauses. | `lib/calls/call_quality_engine.dart` |
| **Battery Fix #4 — Real Camera Sensor Shutdown** | `toggleCamera()` calls `videoSender.replaceTrack(null)` + `track.stop()` when turning camera off (and cleanly re-acquires on unmute), powering down Android's Camera2 sensor & ISP. | `lib/calls/call_service.dart`, `lib/ui/calls_page_part.dart` |
| **CI Concurrency Guard** | Added a workflow `concurrency:` group (`cancel-in-progress: false`) to prevent two rapid pushes from racing on the same release tag. | `android-build-v2.9.0.yml` |
| **Unit Tests (21 Suites Total)** | Added `test/call_quality_engine_test.dart` covering Opus FEC/DTX SDP tuning, H.264/VP8 codec ordering, adaptive quality ladder, Data Saver caps, stats parsing/loss delta, and polite/impolite ICE glare tie-breaking. | `test/call_quality_engine_test.dart` |
