part of '../main.dart';

class _SwipeReplyGesture extends StatefulWidget {
  const _SwipeReplyGesture({super.key, required this.child, required this.onReply});
  final Widget child;
  final VoidCallback? onReply;

  @override
  State<_SwipeReplyGesture> createState() => _SwipeReplyGestureState();
}

class _SwipeReplyGestureState extends State<_SwipeReplyGesture>
    with SingleTickerProviderStateMixin {
  late final AnimationController _reboundCtrl = AnimationController.unbounded(
    vsync: this,
    value: 0.0,
  );
  double _rawDrag = 0.0;
  bool _thresholdReached = false;

  static const double _triggerDistance = 42.0;
  static const double _maxVisualDrag = 66.0;

  void _springBack({double velocity = 0.0}) {
    _rawDrag = 0.0;
    _thresholdReached = false;
    if (LikedinAppearance.reduceMotion.value) {
      _reboundCtrl.value = 0.0;
      return;
    }
    _reboundCtrl.animateWith(
      SpringSimulation(
        OriginPhysics.swipeReplySpring,
        _reboundCtrl.value,
        0.0,
        velocity.clamp(-1200.0, 1200.0).toDouble(),
      ),
    );
  }

  @override
  void dispose() {
    _reboundCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final canReply = widget.onReply != null;
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onHorizontalDragStart: canReply
          ? (_) {
              _reboundCtrl.stop();
              _rawDrag = _reboundCtrl.value;
              _thresholdReached = _reboundCtrl.value.abs() >= _triggerDistance;
            }
          : null,
      onHorizontalDragUpdate: canReply
          ? (details) {
              _rawDrag += details.delta.dx;
              // Progressive rubber-band resistance for authentic OriginOS 7 elastic feel.
              final visual = OriginPhysics.rubberBand(_rawDrag, _maxVisualDrag);
              _reboundCtrl.value = visual;
              final crossed = visual.abs() >= _triggerDistance;
              if (crossed && !_thresholdReached) {
                _thresholdReached = true;
                HapticFeedback.selectionClick();
              } else if (!crossed && _thresholdReached) {
                _thresholdReached = false;
              }
            }
          : null,
      onHorizontalDragEnd: canReply
          ? (details) {
              final drag = _reboundCtrl.value;
              final vel = details.primaryVelocity ?? 0.0;
              final shouldReply = drag.abs() >= _triggerDistance || vel.abs() > 320.0;
              _springBack(velocity: vel * 0.35);
              if (shouldReply) widget.onReply?.call();
            }
          : null,
      onHorizontalDragCancel: canReply ? () => _springBack() : null,
      child: AnimatedBuilder(
        animation: _reboundCtrl,
        child: widget.child,
        builder: (context, bubbleChild) {
          final offset = _reboundCtrl.value;
          // Zero overhead while at rest: keeps 120fps scrolling completely untouched!
          if (offset.abs() < 0.25 && !_reboundCtrl.isAnimating) {
            return bubbleChild!;
          }
          final progress = (offset.abs() / _triggerDistance).clamp(0.0, 1.0).toDouble();
          final iconScale = 0.62 + 0.48 * Curves.easeOutBack.transform(progress);
          return Stack(
            alignment: Alignment.center,
            children: [
              Positioned.fill(
                child: Align(
                  alignment: offset >= 0 ? Alignment.centerLeft : Alignment.centerRight,
                  child: Opacity(
                    opacity: canReply ? progress : 0.0,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Transform.scale(
                        scale: iconScale,
                        child: Container(
                          width: 32,
                          height: 32,
                          decoration: BoxDecoration(
                            color: likedinPrimary(Theme.of(context).brightness)
                                .withValues(alpha: .16 + progress * .14),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            Icons.reply_rounded,
                            color: likedinPrimary(Theme.of(context).brightness),
                            size: 18,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Transform.translate(
                offset: Offset(offset, 0),
                child: bubbleChild,
              ),
            ],
          );
        },
      ),
    );
  }
}

class _RichMessageText extends StatefulWidget {
  const _RichMessageText({
    required this.text,
    required this.style,
    required this.linkColor,
  });
  final String text;
  final TextStyle style;
  final Color linkColor;

  @override
  State<_RichMessageText> createState() => _RichMessageTextState();
}

class _RichMessageTextState extends State<_RichMessageText> {
  static final RegExp _tokenRegex = RegExp(
    r'((https?:\/\/|www\.)[^\s<>"]+)|\|\|([^|\n]+)\|\||\*([^*\n]+)\*|_([^_\n]+)_|~([^~\n]+)~|`([^`\n]+)`',
    caseSensitive: false,
  );
  final List<TapGestureRecognizer> _recognizers = <TapGestureRecognizer>[];

  @override
  void dispose() {
    for (final r in _recognizers) {
      r.dispose();
    }
    _recognizers.clear();
    super.dispose();
  }

  Future<void> _openUrl(String raw) async {
    final normalized = raw.startsWith('http://') || raw.startsWith('https://')
        ? raw
        : 'https://$raw';
    final uri = Uri.tryParse(normalized);
    if (uri == null) return;
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    for (final r in _recognizers) {
      r.dispose();
    }
    _recognizers.clear();

    final txt = widget.text;
    final maybeRich = txt.contains('*') ||
        txt.contains('_') ||
        txt.contains('~') ||
        txt.contains('`') ||
        txt.contains('||') ||
        txt.contains('http') ||
        txt.contains('www.') ||
        txt.contains('HTTP') ||
        txt.contains('WWW.');
    if (!maybeRich) {
      return Text.rich(
        likedinEmojiSpan(txt, style: widget.style),
        softWrap: true,
      );
    }
    final matches = _tokenRegex.allMatches(txt).toList();
    if (matches.isEmpty) {
      return Text.rich(
        likedinEmojiSpan(txt, style: widget.style),
        softWrap: true,
      );
    }
    final dark = Theme.of(context).brightness == Brightness.dark;
    final spans = <InlineSpan>[];
    var lastEnd = 0;
    for (final m in matches) {
      if (m.start > lastEnd) {
        spans.addAll(likedinEmojiSpans(widget.text.substring(lastEnd, m.start)));
      }
      final urlText = m.group(1);
      final spoilerText = m.group(3);
      final boldText = m.group(4);
      final italicText = m.group(5);
      final strikeText = m.group(6);
      final codeText = m.group(7);

      if (urlText != null) {
        final recognizer = TapGestureRecognizer()..onTap = () => _openUrl(urlText);
        _recognizers.add(recognizer);
        spans.add(TextSpan(
          text: urlText,
          style: TextStyle(
            color: widget.linkColor,
            decoration: TextDecoration.underline,
            decorationColor: widget.linkColor,
            fontWeight: FontWeight.w600,
          ),
          recognizer: recognizer,
        ));
      } else if (spoilerText != null) {
        spans.add(WidgetSpan(
          alignment: PlaceholderAlignment.baseline,
          baseline: TextBaseline.alphabetic,
          child: _SpoilerChip(text: spoilerText, style: widget.style),
        ));
      } else if (boldText != null) {
        spans.addAll(likedinEmojiSpans(boldText, style: const TextStyle(fontWeight: FontWeight.w800)));
      } else if (italicText != null) {
        spans.addAll(likedinEmojiSpans(italicText, style: const TextStyle(fontStyle: FontStyle.italic)));
      } else if (strikeText != null) {
        spans.addAll(likedinEmojiSpans(
          strikeText,
          style: const TextStyle(decoration: TextDecoration.lineThrough),
        ));
      } else if (codeText != null) {
        spans.add(TextSpan(
          text: ' $codeText ',
          style: TextStyle(
            fontFamily: 'monospace',
            fontSize: (widget.style.fontSize ?? 15) - 1,
            backgroundColor: (dark ? Colors.white : Colors.black).withValues(alpha: .10),
          ),
        ));
      }
      lastEnd = m.end;
    }
    if (lastEnd < widget.text.length) {
      spans.addAll(likedinEmojiSpans(widget.text.substring(lastEnd)));
    }
    return Text.rich(
      TextSpan(style: widget.style, children: spans),
      softWrap: true,
    );
  }
}

class _SpoilerChip extends StatefulWidget {
  const _SpoilerChip({required this.text, required this.style});
  final String text;
  final TextStyle style;

  @override
  State<_SpoilerChip> createState() => _SpoilerChipState();
}

class _SpoilerChipState extends State<_SpoilerChip> {
  bool _revealed = false;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() => _revealed = !_revealed);
      },
      child: AnimatedContainer(
        duration: LikedinAppearance.reduceMotion.value
            ? Duration.zero
            : const Duration(milliseconds: 220),
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
        decoration: BoxDecoration(
          color: _revealed
              ? (dark ? Colors.white : Colors.black).withValues(alpha: .06)
              : (dark ? const Color(0xFF475569) : const Color(0xFFCBD5E1)),
          borderRadius: BorderRadius.circular(6),
        ),
        child: AnimatedOpacity(
          duration: LikedinAppearance.reduceMotion.value
              ? Duration.zero
              : const Duration(milliseconds: 200),
          opacity: _revealed ? 1.0 : 0.0,
          child: Text.rich(likedinEmojiSpan(widget.text, style: widget.style)),
        ),
      ),
    );
  }
}

class _LinkPreviewData {
  const _LinkPreviewData({
    required this.title,
    required this.siteName,
    this.imageUrl,
  });
  final String title;
  final String siteName;
  final String? imageUrl;
}

class _LinkPreviewCard extends StatefulWidget {
  const _LinkPreviewCard({required this.url});
  final String url;

  @override
  State<_LinkPreviewCard> createState() => _LinkPreviewCardState();
}

class _LinkPreviewCardState extends State<_LinkPreviewCard> {
  static final Map<String, _LinkPreviewData?> _cache = <String, _LinkPreviewData?>{};
  static final Map<String, Future<_LinkPreviewData?>> _inFlight =
      <String, Future<_LinkPreviewData?>>{};
  _LinkPreviewData? _data;

  String get _normalizedUrl =>
      widget.url.startsWith('http://') || widget.url.startsWith('https://')
          ? widget.url
          : 'https://${widget.url}';

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant _LinkPreviewCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.url != widget.url) _load();
  }

  Future<void> _load() async {
    final url = _normalizedUrl;
    if (_cache.containsKey(url)) {
      if (mounted) setState(() => _data = _cache[url]);
      return;
    }
    final future = _inFlight.putIfAbsent(url, () => _fetchMetadata(url));
    final result = await future;
    _inFlight.remove(url);
    if (_cache.length > 120) _cache.clear();
    _cache[url] = result;
    if (mounted) setState(() => _data = result);
  }

  static String _decodeHtml(String raw) => raw
      .replaceAll('&amp;', '&')
      .replaceAll('&quot;', '"')
      .replaceAll('&#39;', "'")
      .replaceAll('&apos;', "'")
      .replaceAll('&lt;', '<')
      .replaceAll('&gt;', '>')
      .replaceAll('&nbsp;', ' ')
      .trim();

  static String? _extractMeta(String html, String property) {
    final p1 = RegExp(
      '<meta[^>]+(?:property|name)=["\']$property["\'][^>]+content=["\']([^"\']+)["\']',
      caseSensitive: false,
    ).firstMatch(html);
    if (p1 != null) return _decodeHtml(p1.group(1)!);
    final p2 = RegExp(
      '<meta[^>]+content=["\']([^"\']+)["\'][^>]+(?:property|name)=["\']$property["\']',
      caseSensitive: false,
    ).firstMatch(html);
    return p2 == null ? null : _decodeHtml(p2.group(1)!);
  }

  static Future<_LinkPreviewData?> _fetchMetadata(String url) async {
    final uri = Uri.tryParse(url);
    if (uri == null || (uri.scheme != 'https' && uri.scheme != 'http')) return null;
    try {
      final response = await http
          .get(uri, headers: const {'User-Agent': 'Mozilla/5.0 (compatible; LikedinPreview/1.0)'})
          .timeout(const Duration(seconds: 5));
      if (response.statusCode != 200) return null;
      final contentType = response.headers['content-type']?.toLowerCase() ?? '';
      if (!contentType.contains('text/html') && !contentType.contains('application/xhtml')) {
        return null;
      }
      final body = response.body.length > 65536 ? response.body.substring(0, 65536) : response.body;
      var title = _extractMeta(body, 'og:title') ?? _extractMeta(body, 'twitter:title');
      if (title == null || title.isEmpty) {
        final titleMatch = RegExp(r'<title[^>]*>([^<]+)</title>', caseSensitive: false).firstMatch(body);
        if (titleMatch != null) title = _decodeHtml(titleMatch.group(1)!);
      }
      if (title == null || title.isEmpty) return null;
      var image = _extractMeta(body, 'og:image') ?? _extractMeta(body, 'twitter:image');
      if (image != null && image.startsWith('/')) {
        image = '${uri.scheme}://${uri.host}$image';
      }
      if (image != null && !image.startsWith('http://') && !image.startsWith('https://')) {
        image = null;
      }
      final site = _extractMeta(body, 'og:site_name') ?? uri.host.replaceFirst('www.', '');
      return _LinkPreviewData(title: title, siteName: site, imageUrl: image);
    } catch (_) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final data = _data;
    if (data == null) return const SizedBox.shrink();
    final dark = Theme.of(context).brightness == Brightness.dark;
    final accent = likedinPrimary(Theme.of(context).brightness);
    return GestureDetector(
      onTap: () async {
        final uri = Uri.tryParse(_normalizedUrl);
        if (uri != null) {
          try {
            await launchUrl(uri, mode: LaunchMode.externalApplication);
          } catch (_) {}
        }
      },
      child: Container(
        margin: const EdgeInsets.only(top: 8),
        padding: const EdgeInsets.all(9),
        decoration: BoxDecoration(
          color: (dark ? Colors.white : Colors.black).withValues(alpha: dark ? .06 : .04),
          borderRadius: BorderRadius.circular(12),
          border: Border(left: BorderSide(color: accent, width: 3)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (data.imageUrl != null) ...[
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.network(
                  data.imageUrl!,
                  width: 52,
                  height: 52,
                  cacheWidth: 160,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                ),
              ),
              const SizedBox(width: 9),
            ],
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    data.siteName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: accent),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    data.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, height: 1.25),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ViewOncePhotoTile extends StatelessWidget {
  const _ViewOncePhotoTile({
    required this.opened,
    required this.outgoing,
    required this.onOpen,
  });
  final bool opened;
  final bool outgoing;
  final VoidCallback? onOpen;

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final accent = likedinPrimary(brightness);
    final mutedColor = likedinMutedText(brightness);
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: opened ? null : onOpen,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 4),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: (opened ? mutedColor : accent).withValues(alpha: .15),
                border: Border.all(
                  color: opened ? mutedColor.withValues(alpha: .4) : accent,
                  width: 1.5,
                ),
              ),
              child: Icon(
                opened ? Icons.check_rounded : Icons.looks_one_outlined,
                size: 18,
                color: opened ? mutedColor : accent,
              ),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  opened ? 'Opened' : 'Photo',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    fontStyle: opened ? FontStyle.italic : FontStyle.normal,
                    color: opened ? mutedColor : null,
                  ),
                ),
                if (!opened)
                  Text(
                    outgoing ? 'Sent as view-once' : 'Tap to view once',
                    style: TextStyle(fontSize: 11, color: mutedColor),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}


class _PhotoAlbumGrid extends StatefulWidget {
  const _PhotoAlbumGrid({required this.items});
  final List<({Map<String, dynamic> payload, String name})> items;

  @override
  State<_PhotoAlbumGrid> createState() => _PhotoAlbumGridState();
}

class _PhotoAlbumGridState extends State<_PhotoAlbumGrid> {
  final Map<String, Future<File>> _cachedFutures = <String, Future<File>>{};

  Future<File> _futureFor(({Map<String, dynamic> payload, String name}) item) {
    final path = item.payload['path']?.toString() ?? item.name;
    return _cachedFutures.putIfAbsent(
      path,
      () => SharedMediaService(Supabase.instance.client).cachedFile(item.payload),
    );
  }

  @override
  void didUpdateWidget(covariant _PhotoAlbumGrid oldWidget) {
    super.didUpdateWidget(oldWidget);
    final activePaths = widget.items
        .map((e) => e.payload['path']?.toString() ?? e.name)
        .toSet();
    _cachedFutures.removeWhere((key, _) => !activePaths.contains(key));
  }

  void _openAt(BuildContext context, int index) {
    Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (_) => _AlbumViewerPage(items: widget.items, initialIndex: index),
      ),
    );
  }

  Widget _tile(BuildContext context, int idx, {int extraCount = 0}) {
    final item = widget.items[idx];
    return GestureDetector(
      onTap: () => _openAt(context, idx),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: FutureBuilder<File>(
          future: _futureFor(item),
          builder: (context, snap) {
            final file = snap.data;
            return Stack(
              fit: StackFit.expand,
              children: [
                if (file != null)
                  Image.file(
                    file,
                    fit: BoxFit.cover,
                    cacheWidth: 360,
                    errorBuilder: (_, __, ___) => const ColoredBox(
                      color: Color(0x22000000),
                      child: Center(child: Icon(Icons.broken_image_outlined)),
                    ),
                  )
                else
                  ColoredBox(
                    color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: .55),
                    child: const Center(
                      child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
                    ),
                  ),
                if (extraCount > 0)
                  ColoredBox(
                    color: Colors.black.withValues(alpha: .52),
                    child: Center(
                      child: Text(
                        '+$extraCount',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final visibleCount = widget.items.length > 4 ? 4 : widget.items.length;
    final extra = widget.items.length - 4;
    if (visibleCount == 2) {
      return SizedBox(
        width: 268,
        height: 150,
        child: Row(
          children: [
            Expanded(child: _tile(context, 0)),
            const SizedBox(width: 4),
            Expanded(child: _tile(context, 1)),
          ],
        ),
      );
    }
    if (visibleCount == 3) {
      return SizedBox(
        width: 268,
        height: 236,
        child: Column(
          children: [
            Expanded(
              child: Row(
                children: [
                  Expanded(child: _tile(context, 0)),
                  const SizedBox(width: 4),
                  Expanded(child: _tile(context, 1)),
                ],
              ),
            ),
            const SizedBox(height: 4),
            Expanded(child: _tile(context, 2)),
          ],
        ),
      );
    }
    return SizedBox(
      width: 268,
      height: 268,
      child: Column(
        children: [
          Expanded(
            child: Row(
              children: [
                Expanded(child: _tile(context, 0)),
                const SizedBox(width: 4),
                Expanded(child: _tile(context, 1)),
              ],
            ),
          ),
          const SizedBox(height: 4),
          Expanded(
            child: Row(
              children: [
                Expanded(child: _tile(context, 2)),
                const SizedBox(width: 4),
                Expanded(child: _tile(context, 3, extraCount: extra > 0 ? extra : 0)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
