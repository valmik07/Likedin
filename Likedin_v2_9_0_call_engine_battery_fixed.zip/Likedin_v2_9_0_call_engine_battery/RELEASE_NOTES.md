What's New in Likedin v2.9.0+139:

• Upgraded Voice & Video Call Engine: Added real Wi-Fi to 4G/5G handoff with automatic ICE-restart renegotiation and fresh TURN servers so calls recover smoothly instead of dropping.
• Clearer Voice & Hardware Video Codecs: Enabled Android hardware echo cancellation, noise suppression, Opus in-band FEC for choppy mobile data, and hardware H.264/VP8 codec priority.
• Adaptive Video Quality & Live Network Pill: Calls now monitor RTT and packet loss every 2.5 seconds, automatically scaling video bitrate/resolution with a live HD/Good/Fair/Weak badge and a 1-tap Data & Battery Saver toggle.
• Four Battery-Saving Fixes: Turning off your camera during a video call now fully powers down the camera sensor, active calls drop display refresh rate from 120 Hz to 60 Hz, Opus silence suppression (DTX) cuts radio draw during pauses, and Soft Glass no longer keeps the accelerometer awake.
