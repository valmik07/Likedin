# Likedin v2.4.0+125 — Floating Call Multitasking, Direct Share, High Refresh Rate & Snapchat Bitmoji

## What's New in v2.4.0+125
1. **Use the App During Audio & Video Calls:**
   - **Audio calls:** Tap **Minimize** (or press Back) to collapse the call into a sleek floating Liquid Glass top bar (`Peer · MM:SS · Mute / Speaker / End / Tap to return`) while browsing Home, Chat, Files, Profile, or Settings.
   - **Video calls:** Minimizes into a draggable floating in-app PiP card showing **both the other person's face AND your own face** in a rounded top-right inset, snapping smoothly to screen edges with quick Mute / Expand / End controls.
2. **High Refresh Rate Fix + Android 11 / 3 GB RAM Optimization:**
   - Native Android refresh-rate selection now matches the display's active physical resolution (`physicalWidth x physicalHeight`) and re-applies on `onCreate`, `onResume`, and `onWindowFocusChanged`.
   - Removed `AnimatedOpacity` full-page `saveLayer` overhead on tab switches and dropped redundant blur passes on secondary chat overlays.
   - Auto-detects 3 GB RAM / low-RAM Android 11 devices (`com.example.likedin/device_info`) to automatically tune `imageCache` (48 entries / 18 MB) and default to lightweight Liquid Glass (keeping all specular rims & translucency without heavy multi-pass blur), while 4+ GB RAM / newer phones run full optical Liquid Glass at 90/120Hz.
3. **Snapchat-Style Bitmoji for Viewing & Taking Photos:**
   - Opening any photo/album in chat broadcasts `viewingPhoto` so your peer's peeking Bitmoji holds up a glossy photo card with a `Viewing` glass pill.
   - Opening the camera broadcasts `takingPhoto` (staying visible while the system camera is open) so your peer's Bitmoji winks and holds a flashing camera with a `Snapping` glass pill.
4. **Smooth Directional Tab Transitions:**
   - Switching between **Chats ↔ Calls ↔ Files ↔ Profile** now uses a silky 210ms directional slide + cross-fade transition with zero idle GPU layer overhead.
5. **Direct Share From Other Android Apps (`ACTION_SEND` / `ACTION_SEND_MULTIPLE`):**
   - Likedin now appears in Android's native Share menu for text, links, photos, videos, audio, and documents — copying shared files safely on a background thread and opening Chat with a Liquid Glass confirmation sheet (respecting hidden-chat security).
